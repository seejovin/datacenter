"""Validate content, refresh portable study exports, and package a clean project."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from core.engine import anki_package, default_progress, flashcard_export, load_lessons
from core.programme import load_cases, load_programme, outcome_rows, rows_csv, study_sequence, validate_programme
from core.depth_audit import load_depth_audit, validate_depth_audit
from core.academy import load_courses, validate_courses
from academy_exports import export_academy

LESSON_FILES = ['facility.json','engineering.json','network_advanced.json','hardware_advanced.json',
                'controls_advanced.json','security_advanced.json','integration_advanced.json']


def refresh_exports():
    certificates = json.loads((ROOT/'content/certificates.json').read_text(encoding="utf-8"))
    # One canonical mapping serves certificate pages, question filters and Anki.
    for name in LESSON_FILES:
        path = ROOT/'content'/name
        lessons = json.loads(path.read_text(encoding="utf-8"))
        for lesson in lessons:
            lesson['certificates'] = [cert['id'] for cert in certificates
                if any(lesson['id'] in group['lesson_ids'] for group in cert['topic_groups'])]
        path.write_text(json.dumps(lessons, ensure_ascii=False, indent=2)+'\n')
    lessons, programme, cases = load_lessons(), load_programme(), load_cases()
    courses = load_courses()
    validate_courses(courses, release=True)
    known_outcomes = {o["id"] for o in programme["outcomes"]}
    for course in courses:
        for objective in course["objectives"]:
            if not set(objective["capability_ids"]) <= known_outcomes:
                raise ValueError("Unknown curriculum outcome: " + objective["id"])
    validate_programme(programme, lessons)
    validate_depth_audit(load_depth_audit(), lessons)
    ids = {lesson['id'] for lesson in lessons}
    for certificate in certificates:
        for group in certificate['topic_groups']:
            if not set(group['lesson_ids']) <= ids:
                raise ValueError(f"Unresolved certificate mapping: {certificate['id']} / {group['name']}")
    for case in cases:
        if not set(case['prerequisites']) <= ids:
            raise ValueError('Unresolved case prerequisite: '+case['id'])
    export = ROOT/'exports'
    export.mkdir(exist_ok=True)
    (export/'curriculum-coverage.csv').write_text(rows_csv(outcome_rows(programme, lessons, default_progress())), encoding='utf-8')
    sequence = [{'Order':i,'ID':lesson['id'],'Title':lesson['title'],'Level':lesson['level'],
                 'Domain':lesson['domain'],'Prerequisites':', '.join(lesson['prerequisites']),
                 'Study minutes':lesson['minutes']} for i,lesson in enumerate(study_sequence(lessons),1)]
    (export/'study-sequence.csv').write_text(rows_csv(sequence), encoding='utf-8')
    guides = ROOT/'docs/study-guides'
    guides.mkdir(exist_ok=True)
    for name in LESSON_FILES:
        track = json.loads((ROOT/'content'/name).read_text(encoding="utf-8"))
        parts = [f"# {name.removesuffix('.json').replace('_',' ').title()} — overview notes",
                 'These are short introductory overviews, including overviews of advanced topics. They are introductory companion notes. The new detailed course books are in docs/academy, with their own source mappings and scope limits. Answers follow each question. Practical assignment briefs require further instruction and execution.']
        for lesson in track:
            parts += [f"## {lesson['id']} — {lesson['title']}",
                      f"Overview · Target topic stage: {lesson['level']} · {lesson['minutes']} estimated overview study minutes · Prerequisites: {', '.join(lesson['prerequisites']) or 'none'}",
                      lesson['summary'], '### Learning objectives', '\n'.join('- '+objective for objective in lesson['objectives']),
                      lesson['body'], '### Worked example', lesson['worked_example'], '### Guided practice',
                      lesson['guided_practice']['prompt'], '**Hint:** '+lesson['guided_practice']['hint'],
                      '**Worked solution:** '+lesson['guided_practice']['solution']]
            for question in lesson['questions']:
                parts += [f"#### {question['id']} — {question['prompt']}",
                          '\n'.join(f"{i+1}. {option}" for i,option in enumerate(question['options'])),
                          '**Answer:** '+', '.join(str(index+1) for index in question['correct']),
                          '\n'.join(f"- Option {i+1}: {explanation}" for i,explanation in enumerate(question['explanations']))]
            if lesson.get('practical_assignment'):
                task = lesson['practical_assignment']
                parts += ['### Independent assignment', 'Environment: '+task['environment'], task['brief']]
                for key in ('steps','deliverables','acceptance_criteria'):
                    parts += ['**'+key.replace('_',' ').title()+'**', '\n'.join('- '+item for item in task[key])]
                parts.append(task['limitations'])
            parts += ['### Sources', '\n'.join(f"- [{source['title']}]({source['url']})" for source in lesson['sources'])]
        (guides/(name.removesuffix('.json')+'.md')).write_text('\n\n'.join(parts)+'\n', encoding='utf-8')
    stats = {'version':'3.1.0','baseline':programme['baseline'], 'lessons':len(lessons),
             'content_status':'Original course programme with separate orientation notes, assessments and practical evidence requirements',
             'overview_lessons':sum(l.get('content_class','overview')=='overview' for l in lessons),
             'level_note':'These level counts refer to retained orientation notes. Course material has its own module/chapter inventory; learner proficiency requires demonstrated evidence.',
             'levels':dict(Counter(lesson['level'] for lesson in lessons)),
             'domains':dict(Counter(lesson['domain'] for lesson in lessons)),
             'questions':sum(len(lesson['questions']) for lesson in lessons),
             'flashcards':len({card['id'] for lesson in lessons for card in lesson['cards']}),
             'interactive_cases':len(cases),'case_decisions':sum(len(case['steps']) for case in cases),
             'mandatory_outcomes':len(programme['outcomes']), 'curriculum_register_entries':len(programme['course_register']),
             'portfolio_case_assignments':len(programme['practical_cases']), 'certificate_paths':len(certificates),
             'lesson_body_words':sum(len(lesson['body'].split()) for lesson in lessons),
             'estimated_app_study_hours':round(sum(lesson['minutes'] for lesson in lessons)/60,1),
             'estimate_note':'App study estimate only; excludes required provider instruction, repeated practice, equipment work and independent review.'}
    stats.update(export_academy(ROOT, courses, programme, lessons))
    stats['total_questions'] = stats['questions'] + stats['course_questions']
    stats['total_flashcards'] = stats['flashcards'] + stats['course_cards']
    (export/'content-manifest.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({key:value for key,value in stats.items() if key!='baseline'},indent=2))
    return stats


def package(output):
    excluded = {'.git','.venv','__pycache__','.pytest_cache','.DS_Store','review'}
    output = output.resolve()
    if output.is_relative_to(ROOT):
        raise ValueError('Write the release ZIP outside the project directory.')
    temporary = output.with_name(output.name+'.tmp')
    with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path in sorted(ROOT.rglob('*')):
            relative = path.relative_to(ROOT)
            if not path.is_file() or set(relative.parts)&excluded or path.suffix in ('.pyc','.zip'):
                continue
            archive.write(path,relative)
    with zipfile.ZipFile(temporary) as archive:
        if archive.testzip() is not None:
            raise ValueError('Release archive failed its CRC check.')
    os.replace(temporary, output)
    print(f"Package: {output.name}; {output.stat().st_size:,} bytes; SHA256 {hashlib.sha256(output.read_bytes()).hexdigest()}")


if __name__=='__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,help='Optional clean ZIP path outside the project')
    args = parser.parse_args()
    refresh_exports()
    if args.output:
        package(args.output)
