"""Portable teaching, assessment and scope exports from canonical course JSON."""
from collections import Counter
import json
import random
import re
from pathlib import Path
from core.academy import (CREDENTIAL_IDS, capability_course_rows, course_rows,
                          learning_units, provider_rows, rows_csv)
from core.engine import anki_package, flashcard_export


def programme_guide(courses, programme):
    """A readable delivery inventory and explanation tied to the controlled baseline."""
    parts=["# Data Center Academy — programme guide",
           "The programme combines credential preparation with the broader engineering identity in your charter. Study is organised into courses, modules and chapters; the curriculum view connects that material to the work and evidence you must demonstrate.",
           "## Your target identity",
           "Your Charter Revision 3.5 makes networks (D4), OT/controls (D6) and cybersecurity (D7) the principal specialisations. All ten hardware outcomes (D5) remain mandatory. Power and cooling (D2/D3) provide required foundations and integration now; full specialist ownership is a later supervised pathway. Building engineering ownership (D1) is excluded.",
           "Curriculum Revision 14 supplies the teaching assignments; Portfolio Version 2.5 supplies the acceptance structure. The app retains all 48 NET/HW/OT/SEC/CN outcomes, 69 core teaching-register entries, 16 practical case assignments and Releases 0–5. The referenced Track 1/MUDT document was not supplied, so its completion is not assumed.",
           "## Delivered course inventory",
           "The first table contains the fourteen planned items after CCNA. ISA Expert is the integration milestone earned through its four constituent provider certificates; its bank is additional study, not an invented examination.",
           "| Pathway | Modules | Chapters | Original questions | Recall cards |",
           "|---|---:|---:|---:|---:|"]
    for c in courses:
        if c['id'] in CREDENTIAL_IDS:
            parts.append(f"| {c['id']} | {len(c['modules'])} | {len(c['lessons'])} | {len(c['questions']):,} | {sum(len(l['cards']) for l in c['lessons']):,} |")
    parts += ["The additional engineering courses preserve requirements beyond the examination list.",
              "| Engineering extension | Chapters | Questions | Recall cards |", "|---|---:|---:|---:|"]
    for c in courses:
        if c['kind']=='engineering_extension':
            parts.append(f"| {c['title']} | {len(c['lessons'])} | {len(c['questions'])} | {sum(len(l['cards']) for l in c['lessons'])} |")
    parts += ["The original 88 orientation lessons remain available with their original progress identities. They are separate from the expanded courses. The inventory counts supplied material; it does not measure a learner's proficiency or prove psychometric validity.",
              "## How to study",
              "1. Open Programme → Study route and check course prerequisites. Reuse demonstrated CCNA foundations through your existing app.\n2. Open a course chapter and study its explanation before attempting the worked demonstration yourself.\n3. Complete the guided exercise before revealing its solution.\n4. Answer the chapter questions, read every relevant rationale and revisit the mechanism behind errors. Use Practice for unanswered questions or targeted remediation.\n5. Select Review this chapter's flashcards, or open Flashcards and choose a course/chapter. Recall the answer, reveal it, then rate Again, Hard, Good or Easy. The app saves ratings and due dates; Anki is optional.\n6. Execute the independent task in its declared environment, retain actual results and complete the corresponding curriculum work package.\n7. Review cumulative release evidence and provider requirements separately from study checkpoints.",
              "Built-in flashcards show due cards before new cards, with counts for new, due, scheduled and reviewed cards. Review intervals are fixed: Again 10 minutes, Hard 1 day, Good 3 days and Easy 7 days. Use Refresh due cards after waiting. Review history is saved on this browser and included in Progress → Backup & restore. No external flashcard application or account is needed.",
              "Foundation, Applied and Advanced describe increasing difficulty and independence within subjects. You do not need to finish every subject at one level before starting the next level in another. The course prerequisites and practical release gates provide the dependencies. Cross-domain work joins these strands as your evidence grows.",
              "All nine lifecycle responsibilities recur: design, implementation, commissioning, day-to-day operations, maintenance, optimisation, troubleshooting, incident response and recovery. Advanced work increases ambiguity, scale and integration; it does not postpone operations or recovery until the end.",
              "## Why this fits the curriculum and charter",
              "A certificate-only route would leave parts of the intended identity untracked. Data-center networking alone does not establish campus/WAN/wireless engineering; an OT-security qualification does not establish PLC application behaviour; a facilities course does not demonstrate server diagnosis and restoration. The three engineering extensions, 48 work packages and retained vendor assignments keep those requirements visible.",
              "Shared work can support several outcomes when each claim has its own criteria and evidence links. The course-to-outcome crosswalk identifies supporting chapters and questions; the work package preserves the complete requirement. A large number of links is not a claim that every aspect has been independently assessed.",
              "## What establishes the intended identity",
              "This package supplies original instruction, explained assessments, executable local exercises and a structured route through the specified work. Achieving the identity requires completing that route: retained platform instruction, physical and supervised practice, repeated operating campaigns, trusted recovery, measured improvement and accepted portfolio releases. Software progress alone cannot establish professional competence or authority.",
              "The local labs distinguish actual file/database operations from synthetic network, process and authority models. They do not claim that Cisco, Siemens, electrical, cooling or safety equipment was operated. Vendor commands and platform workbooks require their stated supported lab and acceptance evidence.",
              "## Scope verification and external requirements"]
    for c in courses:
        bp=c['blueprint']
        parts += ["### "+c['id'], f"[{bp['title']}]({bp['url']}) — {bp['version']}; checked {bp['checked_on']}.",bp['scope_note']]
        parts += ['- '+x for x in bp['limitations']]
    parts += ["## Files and deployment",
              "The project contains offline books in docs/academy, Anki decks in exports/course-decks, executable exercises and workbooks in course_labs, source/objective/question registers in exports, and evidence templates in templates/evidence. README.md explains local use and GitHub/Streamlit deployment.",
              "Upload the extracted project contents to seejovin/datacenter, then choose app.py and Python 3.12 in Streamlit Community Cloud. No API keys are required. This delivery provides the project files; it does not claim a GitHub push or public deployment."]
    return re.sub(r'(?m)(^\|.*\|)\n\n(?=\|)', r'\1\n', '\n\n'.join(parts))+'\n'


def course_book(course):
    bp=course['blueprint']
    parts=[f"# {course['id']} — {course['title']}",
           "Original independent instruction and practice. Read the teaching, work the demonstrations and guided exercise, then attempt questions before reading their explanations. Independent tasks require your own evidence.",
           f"Source baseline: [{bp['title']}]({bp['url']}) · {bp['version']} · checked {bp['checked_on']}",
           bp['scope_note'], '## Scope and external requirements']
    if course['kind']=='milestone_integration':
        parts.append('ISA Expert is awarded through the four constituent provider certificates. This is an integration study bank, not an additional ISA examination.')
    parts += ['- '+x for x in bp['limitations']+course['external_requirements']]
    parts += ['## Preparation', 'Prior courses: '+(', '.join(course['prerequisites']['course_ids']) or 'See the knowledge prerequisites below.')]
    parts += ['- '+x for x in course['prerequisites']['external']]
    for module in course['modules']:
        parts.append(f"## {module['id']} — {module['title']}")
        for lesson in (l for l in course['lessons'] if l['id'] in module['lesson_ids']):
            lid=lesson['id']
            parts += [f"### {lid} — {lesson['title']}",
                      f"Estimated study time: {lesson['minutes']} minutes before independent work. Prerequisite chapters: {', '.join(lesson['prerequisites']) or 'Use the course prerequisites.'}",
                      lesson['body'], '#### Worked demonstrations']
            for example in lesson['worked_examples']:
                parts += ['**'+example['title']+'**',example['scenario'],'**Reasoning:** '+example['solution']]
            gp=lesson['guided_practice']
            parts += ['#### Guided practice',gp['prompt'],'**Hint:** '+gp['hint'],'**Worked solution:** '+gp['solution'],
                      '#### Independent task','Environment: '+lesson['independent_task']['environment'],lesson['independent_task']['brief']]
            for field,label in [('starter_artifacts','Packaged starter material'),('deliverables','Evidence to produce'),('acceptance_criteria','Acceptance criteria')]:
                parts += ['**'+label+'**','\n'.join('- '+str(x) for x in lesson['independent_task'][field])]
            parts += [lesson['independent_task']['limitations'], '#### Chapter practice']
            # Print each item once using its primary teaching chapter; linked chapters remain in the source register.
            for q in (q for q in course['questions'] if q['lesson_ids'][0]==lid):
                parts += [f"**{q['id']} · {q['type']} · {q['cognitive_skill']}**",q['prompt']]
                if q.get('exhibit'): parts.append(q['exhibit'])
                # The app shuffles display order per attempt. Books need their own
                # stable presentation order without changing persisted answer indices.
                order=list(range(len(q['options'])))
                random.Random('course-book:'+q['id']).shuffle(order)
                parts.append('\n'.join(f"{i+1}. {q['options'][original]}" for i,original in enumerate(order)))
                label='Correct sequence' if q['type']=='order' else 'Correct option(s)'
                answer=[order.index(i)+1 for i in q['correct']]
                if q['type']!='order': answer.sort()
                parts += ['**'+label+':** '+', '.join(str(i) for i in answer),
                          '\n'.join(f"- Option {i+1}: {q['explanations'][original]}" for i,original in enumerate(order))]
            parts += ['#### Recall','\n\n'.join('**'+x['front']+'**\n\n'+x['back'] for x in lesson['cards']),
                      '#### References','\n'.join(f"- [{x['title']}]({x['url']})" for x in lesson['sources'])]
    return '\n\n'.join(x for x in parts if x)+'\n'


def export_academy(root: Path,courses: list[dict],programme: dict,overviews: list[dict]):
    exports=root/'exports';books=root/'docs/academy';decks=exports/'course-decks'
    books.mkdir(parents=True,exist_ok=True);decks.mkdir(parents=True,exist_ok=True)
    units=learning_units(courses)
    all_units=overviews+units
    (exports/'Data-Center-Academy.apkg').write_bytes(anki_package(all_units))
    (exports/'Data-Center-Academy.tsv').write_text(flashcard_export(all_units),encoding='utf-8')
    (exports/'course-inventory.csv').write_text(rows_csv(course_rows(courses)),encoding='utf-8')
    (exports/'curriculum-course-crosswalk.csv').write_text(rows_csv(capability_course_rows(programme,courses)),encoding='utf-8')
    question_rows=[];objective_rows=[];source_rows=[];stats=[];sequence=[]
    for course in courses:
        cid=course['id'];course_units=learning_units([course])
        (books/(cid+'.md')).write_text(course_book(course),encoding='utf-8')
        (decks/(cid+'.apkg')).write_bytes(anki_package(course_units))
        (decks/(cid+'.tsv')).write_text(flashcard_export(course_units),encoding='utf-8')
        for i,lesson in enumerate(course['lessons'],1):
            sequence.append({'Course':cid,'Chapter order':i,'ID':lesson['id'],'Title':lesson['title'],'Module':lesson['module_id'],
                             'Prerequisites':', '.join(lesson['prerequisites']),'Study minutes':lesson['minutes']})
        for q in course['questions']:
            question_rows.append({'Course':cid,'Question':q['id'],'Module':q['module_id'],'Authored objective':q['objective_id'],
                                  'Chapters':', '.join(q['lesson_ids']),'Type':q['type'],'Difficulty':q['difficulty'],'Cognitive skill':q['cognitive_skill'],
                                  'Prompt':q['prompt'],'Has exhibit':bool(q.get('exhibit'))})
        for obj in course['objectives']:
            objective_rows.append({'Course':cid,'Objective':obj['id'],'Text':obj['text'],'Source reference':obj['source_ref'],
                                   'Chapters':', '.join(obj['lesson_ids']),'Curriculum outcomes':', '.join(obj['capability_ids']),
                                   'Supporting questions':sum(q['objective_id']==obj['id'] for q in course['questions'])})
        source_rows += [{'Course':cid,**row} for row in provider_rows(course)]
        body=sum(len(l['body'].split()) for l in course['lessons'])
        examples=sum(len(e['scenario'].split())+len(e['solution'].split()) for l in course['lessons'] for e in l['worked_examples'])
        guided=sum(len(v.split()) for l in course['lessons'] for v in l['guided_practice'].values())
        stats.append({'id':cid,'title':course['title'],'kind':course['kind'],'modules':len(course['modules']),'chapters':len(course['lessons']),
                      'questions':len(course['questions']),'question_types':dict(Counter(q['type'] for q in course['questions'])),
                      'question_skills':dict(Counter(q['cognitive_skill'] for q in course['questions'])),
                      'cards':sum(len(l['cards']) for l in course['lessons']),
                      'teaching_body_words':body,'worked_example_words':examples,'guided_practice_words':guided,
                      'authored_objectives':len(course['objectives']),'provider_mapping_records':len(course.get('provider_objectives',[])),
                      'blueprint':course['blueprint'],'external_requirements':course['external_requirements']})
    for name,rows in [('question-register.csv',question_rows),('authored-objectives.csv',objective_rows),('provider-objective-crosswalk.csv',source_rows),('course-study-sequence.csv',sequence)]:
        (exports/name).write_text(rows_csv(rows),encoding='utf-8')
    (exports/'course-manifest.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (root/'docs/PROGRAMME_GUIDE.md').write_text(programme_guide(courses,programme),encoding='utf-8')
    by_id={c['id']:c for c in courses}
    return {'course_count':len(courses),'credential_banks':len([c for c in courses if c['id'] in CREDENTIAL_IDS]),
            'engineering_extensions':len([c for c in courses if c['kind']=='engineering_extension']),
            'course_chapters':sum(s['chapters'] for s in stats),'course_questions':sum(s['questions'] for s in stats),
            'course_cards':sum(s['cards'] for s in stats),'course_teaching_body_words':sum(s['teaching_body_words'] for s in stats),
            'course_worked_example_words':sum(s['worked_example_words'] for s in stats),
            'course_guided_practice_words':sum(s['guided_practice_words'] for s in stats),
            'all_credential_banks_have_at_least_500':all(cid in by_id and len(by_id[cid]['questions'])>=500 for cid in CREDENTIAL_IDS),
            'course_question_counts':{s['id']:s['questions'] for s in stats},
            'scope_note':'Authored instruction and mapped assessments are distinct from provider endorsement, unseen/proprietary scope verification, psychometric validation and accepted practical competence. Read each course baseline and limitations.'}
