"""Data Center Academy — credential courses and lifecycle engineering study."""
from __future__ import annotations

import html
import json
import random
import uuid
from datetime import datetime, timezone
from pathlib import Path

import streamlit as st

from core.engine import (
    add_credential, add_evidence, anki_package, default_progress,
    flashcard_export, grade_question, load_lessons, mark_complete,
    normalize_progress, objective_stats, recommend_lessons, record_attempt,
    record_review, validate_catalog,
)
from core.persistence import render_device_store
from core.recall import review_queue
from core.programme import load_cases, load_programme, validate_programme
from ui.programme import render_programme
from core.academy import load_courses, learning_units, question_index, course_rows
from ui.academy import render_courses, open_course

ROOT = Path(__file__).parent
VERSION = "3.1.0"
DOMAINS = {
    "systems": "Systems & dependencies", "power": "Power & electrical interfaces",
    "cooling": "Cooling & thermal interfaces", "network": "Networks & communications",
    "hardware": "IT hardware", "controls": "OT & controls",
    "security": "Cybersecurity", "operations": "Operations & assurance",
}
DOMAIN_CODES = {"systems": "SYS", "power": "PWR", "cooling": "THM", "network": "NET",
                "hardware": "HW", "controls": "OT", "security": "SEC", "operations": "OPS"}
PAGES = ["Today", "Courses", "Programme", "Learn", "Practice", "Cases", "Certificates", "Flashcards", "Progress"]

st.set_page_config(page_title="Data Center Academy", page_icon="◈", layout="wide",
                   initial_sidebar_state="expanded")
st.markdown("""<style>
.stApp {background:#faf8f4;}
.block-container{max-width:1190px;padding-top:4.5rem;padding-bottom:4rem;}
[data-testid="stSidebar"]{background:#f0ece5;border-right:1px solid #e2ddd4;}
[data-testid="stSidebar"] .block-container{padding-top:1.5rem;}
h1,h2,h3{font-family:Georgia,'Times New Roman',serif!important;font-weight:400!important;letter-spacing:-.035em!important;}
h1{font-size:3rem!important;line-height:1.1!important;padding-top:.1rem!important;}
h2{font-size:1.85rem!important;} h3{font-size:1.4rem!important;}
p,li{line-height:1.7;}
.eyebrow{font-size:11px;font-weight:700;letter-spacing:.17em;text-transform:uppercase;color:#8c6956;margin-bottom:13px;}
.brand{font-family:Georgia,serif;font-size:25px;line-height:1.16;color:#242320;margin:12px 0 7px;}
.brand-mark{display:inline-flex;background:#bd5d3c;color:#fff;width:35px;height:35px;align-items:center;justify-content:center;font-size:23px;border-radius:8px;}
.muted{color:#77746c;font-size:13px;}
.hero-sub{font-size:17px;max-width:680px;color:#6b675f;line-height:1.65;margin:14px 0 25px;}
.stat{padding:19px 22px;background:#f1ede6;border-radius:12px;border:1px solid #e5ded3;min-height:112px;}
.stat-num{font-family:Georgia,serif;font-size:32px;letter-spacing:-.04em;line-height:1.25;}
.stat-label{font-size:12px;color:#757066;margin-top:7px;}
.tag{display:inline-block;padding:3px 9px;margin:3px 5px 3px 0;background:#eee8df;border-radius:5px;color:#726151;font-size:11px;font-weight:600;letter-spacing:.03em;}
.tag-accent{background:#f3e4dc;color:#9b482e;}
.lesson-number{font-family:Georgia,serif;font-size:30px;color:#ba5b3e;line-height:1.2;margin-bottom:8px;}
.card-title{font-size:20px;font-family:Georgia,serif;line-height:1.3;color:#262420;margin:8px 0 10px;}
.card-summary{font-size:13px;color:#777168;min-height:62px;line-height:1.65;}
.divider{height:1px;background:#e0d9cd;margin:26px 0;}
.flashcard{background:#fffdf9;border:1px solid #ded5c7;border-radius:18px;padding:40px;min-height:230px;margin:14px 0;}
.flashcard-front{font-family:Georgia,serif;font-size:27px;line-height:1.4;}
.flashcard-back{font-size:18px;line-height:1.7;color:#625d54;white-space:pre-line;}
.scope-note{font-size:12px;color:#7b7469;border-left:2px solid #bfae98;padding-left:12px;line-height:1.6;margin:14px 0;}
div[data-testid="stVerticalBlockBorderWrapper"] > div{border-radius:12px!important;}
button[kind="primary"]{border-radius:7px!important;}
div[data-testid="stMetric"]{background:#f2eee7;padding:15px;border-radius:9px;}
div[data-testid="stMetricLabel"]{color:#736d63;}
.stDownloadButton button{width:100%;}
.stRadio label{font-size:14px;}
footer{visibility:hidden;}
@media(max-width:700px){h1{font-size:2.3rem!important;}.block-container{padding-top:4.2rem;padding-left:1rem;padding-right:1rem;}.flashcard{padding:24px;}.card-summary{min-height:0;}}
</style>""", unsafe_allow_html=True)


@st.cache_data(show_spinner=False)
def catalog():
    lessons = load_lessons()
    validate_catalog(lessons)
    certificates = json.loads((ROOT / "content/certificates.json").read_text(encoding="utf-8"))
    cases = load_cases()
    programme = load_programme()
    validate_programme(programme, lessons)
    return lessons, certificates, cases, programme


LESSONS, CERTIFICATES, CASES, PROGRAMME = catalog()
@st.cache_data(show_spinner=False)
def academy_catalog():
    return load_courses()

COURSES = academy_catalog()
COURSE_UNITS = learning_units(COURSES)
ALL_UNITS = LESSONS + COURSE_UNITS
BY_ID = {x["id"]: x for x in LESSONS}
ALL_BY_ID = {x["id"]: x for x in ALL_UNITS}
COURSE_BY_ID = {c["id"]: c for c in COURSES}
OBJECTIVES_BY_ID = {o["id"]: o for c in COURSES for o in c["objectives"]}
CERT_BY_ID = {x["id"]: x for x in CERTIFICATES}
QUESTIONS = {q["id"]: {**q, "lesson_id": l["id"], "domain": l["domain"]}
             for l in LESSONS for q in l["questions"]}
QUESTIONS.update(question_index(COURSES))


def escape(value):
    return html.escape(str(value), quote=True)


def now():
    return datetime.now(timezone.utc).isoformat()


def progress():
    return st.session_state["progress"]


def update(new_progress):
    st.session_state["progress"] = new_progress


def go(page, lesson=None, certificate=None):
    st.session_state["page"] = page
    if lesson:
        st.session_state["lesson_id"] = lesson
    if certificate:
        st.session_state["certificate_id"] = certificate
        st.session_state["cert_picker"] = certificate


def go_workbench(lesson_id):
    st.session_state["programme_view"] = "Practical workbench"
    matches = [item["id"] for item in PROGRAMME["outcomes"] if lesson_id in item["lesson_ids"]]
    if matches:
        st.session_state["workbench_outcome"] = matches[0]
    go("Programme")


def heading(eyebrow, title, description=None):
    st.markdown(f'<div class="eyebrow">{escape(eyebrow)}</div>', unsafe_allow_html=True)
    st.title(title)
    if description:
        st.markdown(f'<div class="hero-sub">{escape(description)}</div>', unsafe_allow_html=True)


def tags(*items):
    st.markdown("".join(f'<span class="tag">{escape(i)}</span>' for i in items if i), unsafe_allow_html=True)


def lesson_score(lesson_id):
    attempts = [a for a in progress()["attempts"] if a.get("mode") == "lesson"
                and a.get("results") and all(r.get("lesson_id") == lesson_id for r in a["results"])]
    return max((a["score"] / a["total"] * 100 for a in attempts if a.get("total")), default=0)


def question_results(attempt):
    for result in attempt.get("results", []):
        q = QUESTIONS.get(result["question_id"])
        if not q:
            continue
        title = ("Correct · " if result["correct"] else "Review · ") + q["prompt"]
        with st.expander(title, expanded=not result["correct"]):
            selected = attempt.get("answers", {}).get(q["id"], [])
            if q.get("exhibit"):
                st.markdown(q["exhibit"])
            if q.get("type") == "order":
                st.markdown("**Correct sequence:** " + " → ".join(q["options"][i] for i in q["correct"]))
                st.markdown("**Your sequence:** " + " → ".join(q["options"][i] for i in selected))
            for idx, option in enumerate(q["options"]):
                label = (f"Step {q['correct'].index(idx)+1}" if q.get("type") == "order"
                         else "Correct answer" if idx in q["correct"] else "Alternative")
                chosen = " · Your selection" if idx in selected else ""
                st.markdown(f"**{label}{chosen}: {option}**")
                st.write(q["explanations"][idx])
            objective = OBJECTIVES_BY_ID.get(q["objective"], {}).get("text", q["objective"])
            st.caption(f"{ALL_BY_ID[q['lesson_id']]['title']} · {objective}")
            if q.get("course_id"):
                st.button("Study the related chapter", key="feedback_"+attempt["id"]+q["id"],
                          on_click=open_course, args=(q["course_id"], q["lesson_id"]))


def create_attempt(qs, answers, mode, identifier):
    results = [{"question_id": q["id"], "lesson_id": q["lesson_id"],
                "objective": q["objective"], "correct": grade_question(q, answers[q["id"]])}
               for q in qs]
    return {"id": identifier, "timestamp": now(), "mode": mode,
            "question_ids": [q["id"] for q in qs], "answers": answers, "results": results,
            "score": sum(r["correct"] for r in results), "total": len(results)}


def render_assessment(qs, key, mode, intro=True):
    """Submit once, persist the exact attempt, then render option-level feedback."""
    result_key, attempt_key = key + "_result", key + "_attempt"
    if attempt_key not in st.session_state:
        st.session_state[attempt_key] = str(uuid.uuid4())
    if result_key in st.session_state:
        attempt = st.session_state[result_key]
        pct = 100 * attempt["score"] / attempt["total"]
        st.metric("Knowledge check", f"{attempt['score']} / {attempt['total']}", f"{pct:.0f}%", delta_color="off")
        st.caption("This measures performance on these questions, not professional competence or exam readiness.")
        question_results(attempt)
        if st.button("Try a new attempt", key=key + "_retry"):
            del st.session_state[result_key]
            st.session_state[attempt_key] = str(uuid.uuid4())
            st.rerun()
        return attempt
    if intro:
        st.caption("Answer every question. Select-all questions require the exact set; sequence questions require every step in order.")
    with st.form(key + "_form", border=False):
        answers = {}
        for number, q in enumerate(qs, 1):
            st.markdown(f"**{number}. {q['prompt']}**")
            if q.get("exhibit"):
                st.markdown(q["exhibit"])
            order = list(range(len(q["options"])))
            random.Random(st.session_state[attempt_key] + q["id"]).shuffle(order)
            widget_key = st.session_state[attempt_key] + "_" + q["id"]
            if q.get("type") == "order":
                answers[q["id"]] = st.multiselect("Select every step in the order it should occur", order,
                    format_func=lambda idx, q=q: q["options"][idx], key=widget_key,
                    help="Selection order is your answer. Remove and reselect a step to move it.")
            elif q.get("type") == "multi":
                answers[q["id"]] = st.multiselect("Select all that apply", order,
                    format_func=lambda idx, q=q: q["options"][idx], key=widget_key)
            else:
                choice = st.radio("Choose one answer", order, index=None,
                    format_func=lambda idx, q=q: q["options"][idx], key=widget_key,
                    label_visibility="collapsed")
                answers[q["id"]] = [] if choice is None else [choice]
            st.write("")
        submitted = st.form_submit_button("Submit answers", type="primary")
    if submitted:
        if any(not a for a in answers.values()) or any(q.get("type") == "order" and len(answers[q["id"]]) != len(q["options"]) for q in qs):
            st.warning("Answer each question before submitting. Your selections are retained.")
            return None
        attempt = create_attempt(qs, answers, mode, st.session_state[attempt_key])
        try:
            update(record_attempt(progress(), attempt))
        except ValueError as exc:
            st.error(str(exc))
            st.download_button("Export current progress", json.dumps(progress(), ensure_ascii=False, separators=(",", ":")),
                               file_name="datacenter-progress.json", mime="application/json", key=key+"_backup")
            return None
        st.session_state[result_key] = attempt
        st.rerun()
    return None


def lesson_card(lesson, key):
    completed = lesson["id"] in progress()["completed"]
    missing = [p for p in lesson["prerequisites"] if p not in progress()["completed"]]
    with st.container(border=True):
        tags(DOMAIN_CODES[lesson["domain"]], "Target stage: " + lesson["level"], "Overview", f"{lesson['minutes']} min")
        st.markdown(f'<div class="card-title">{escape(lesson["title"])}</div>', unsafe_allow_html=True)
        st.markdown(f'<div class="card-summary">{escape(lesson["summary"])}</div>', unsafe_allow_html=True)
        if completed:
            st.caption("✓ Overview checkpoint completed")
        elif missing:
            st.caption("Recommended first: " + ", ".join(missing))
        else:
            st.caption("Ready to study")
        st.button("Review lesson" if completed else "Open lesson", key=key, width="stretch",
                  on_click=go, args=("Learn", lesson["id"]))


def flow_diagram(nodes):
    if not nodes:
        return
    # Deterministic SVG from authored labels. No remote renderer or execution.
    count = len(nodes)
    height = count * 64 + 8
    bits = [f'<svg xmlns="http://www.w3.org/2000/svg" role="img" aria-label="System flow" viewBox="0 0 700 {height}" style="max-height:{height}px;width:100%">',
            '<defs><marker id="arr" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6" fill="#ad654a"/></marker></defs>']
    for i, text in enumerate(nodes):
        y = 6 + i * 64
        bits.append(f'<rect x="80" y="{y}" width="540" height="43" rx="8" fill="#f0e9df" stroke="#d9cbbb"/>')
        bits.append(f'<text x="350" y="{y+27}" text-anchor="middle" fill="#493a30" font-size="15" font-family="sans-serif">{escape(text)}</text>')
        if i < count - 1:
            bits.append(f'<line x1="350" y1="{y+44}" x2="350" y2="{y+60}" stroke="#ad654a" marker-end="url(#arr)"/>')
    bits.append('</svg>')
    st.markdown(''.join(bits), unsafe_allow_html=True)


def today_page():
    heading("Data Center Academy", "Build knowledge. Demonstrate capability.",
            "Study credential courses, then connect the knowledge through network, hardware, controls and security engineering work.")
    course_ids = {l["id"] for l in COURSE_UNITS}
    done = len(set(progress()["completed"]) & course_ids)
    distinct = {r["question_id"] for a in progress()["attempts"] for r in a["results"] if r["question_id"] in QUESTIONS}
    for col, value, label in zip(st.columns(3), [f"{done} / {len(COURSE_UNITS)}", f"{len(distinct):,}", str(len(progress()["reviews"]))],
                                ["Course chapter checkpoints", "Distinct questions attempted", "Cards reviewed here"]):
        with col:
            st.markdown(f'<div class="stat"><div class="stat-num">{escape(value)}</div><div class="stat-label">{escape(label)}</div></div>', unsafe_allow_html=True)
    st.write("")
    st.subheader("Continue your programme")
    if COURSES:
        incomplete = [c for c in COURSES if any(l["id"] not in progress()["completed"] for l in c["lessons"])]
        ready = [c for c in incomplete if all(all(l["id"] in progress()["completed"] for l in COURSE_BY_ID[p]["lessons"])
                 for p in c["prerequisites"]["course_ids"] if p in COURSE_BY_ID)]
        suggestions = (ready or incomplete)[:3]
        for col, course in zip(st.columns(max(1,len(suggestions))), suggestions):
            with col:
                with st.container(border=True):
                    st.markdown("**"+course["id"]+"**")
                    st.write(course["title"])
                    st.caption(f"{len(course['modules'])} modules · {len(course['lessons'])} chapters · {len(course['questions']):,} questions")
                    st.button("Open course", key="nextcourse_"+course["id"], on_click=open_course, args=(course["id"],), type="primary")
        with st.expander("Course inventory"):
            st.dataframe(course_rows(COURSES), hide_index=True, width="stretch")
    st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
    a,b = st.columns(2)
    with a:
        st.subheader("Knowledge before assessment")
        st.write("Courses organise teaching by credential, module and chapter. Each chapter supplies explanations, worked demonstrations, guided practice, questions and an independent task. Course diagnostics separate question coverage from answer accuracy.")
        st.button("Explore courses", on_click=go, args=("Courses",))
    with b:
        st.subheader("Engineering across the lifecycle")
        st.write("The curriculum workspace retains all 48 capability outcomes, the mandatory hardware scope, independent network branches, practical work packages and six cumulative portfolio releases.")
        st.button("Open the curriculum workspace", on_click=go, args=("Programme",))
    with st.expander("How this follows your charter"):
        st.write("D4 networks, D6 controls and D7 cybersecurity require the main depth. All ten D5 hardware outcomes remain compulsory. Power and cooling support integration now; full D2/D3 engineering ownership is a later horizon. D1 civil, structural and architectural engineering stays outside the ownership scope.")
        st.write("Course scope pages record source versions and verification limits. Chapter checkpoints record study; provider awards, practical acceptance and permission to operate remain separate.")
    st.caption("Learn contains the original orientation overviews. Courses contains the expanded credential teaching and question banks.")


def learn_page():
    selected = st.session_state.get("lesson_id")
    if selected in BY_ID:
        lesson = BY_ID[selected]
        if st.button("← All lessons"):
            st.session_state["lesson_id"] = None
            st.rerun()
        heading(f"{lesson['id']} · {DOMAINS[lesson['domain']]}", lesson["title"], lesson["summary"])
        tags("Target stage: " + lesson["level"], "Overview", f"{lesson['minutes']} min", *lesson["certificates"])
        st.info("This is a short overview. The target stage labels the subject, not delivered course depth. Detailed instruction, platform practice and comprehensive assessment are still needed.")
        missing = [x for x in lesson["prerequisites"] if x not in progress()["completed"]]
        if missing:
            with st.expander("Recommended prerequisites"):
                for item in missing:
                    st.button(BY_ID[item]["title"], key="prereq_"+item, on_click=go, args=("Learn", item))
                st.caption("You can preview this lesson now. Complete prerequisite checkpoints before adding it to your completed learning path.")
        tab_names = ["Learn", "Worked example", "Guided practice", "Knowledge check", "Sources & application"]
        if lesson.get("practical_assignment"):
            tab_names.append("Independent assignment")
        tabs = st.tabs(tab_names)
        with tabs[0]:
            st.subheader("What you will understand")
            for obj in lesson["objectives"]:
                st.markdown("- " + obj)
            st.markdown(lesson["body"])
            if lesson.get("diagram"):
                flow_diagram(lesson["diagram"].get("nodes", []))
        with tabs[1]:
            st.subheader("Follow the reasoning")
            st.markdown(lesson["worked_example"])
        with tabs[2]:
            task = lesson["guided_practice"]
            st.subheader("Your turn")
            st.markdown(task["prompt"])
            st.text_area("Your reasoning", key=selected+"_scratch", height=150,
                         help="A scratchpad for this session. Save important work in your own notes or an evidence record.")
            with st.expander("Show a hint"):
                st.markdown(task["hint"])
            with st.expander("Compare with the worked solution"):
                st.markdown(task["solution"])
        with tabs[3]:
            qs = [QUESTIONS[q["id"]] for q in lesson["questions"]]
            render_assessment(qs, "lesson_" + selected, "lesson")
            best = lesson_score(selected)
            st.caption(f"Best overview check: {best:.0f}% · Overview checkpoint threshold: 80%. This small check does not assess complete topic coverage or a course pass.")
            reviewed = st.checkbox("I have studied the explanation and attempted the guided practice.", key=selected+"_read")
            if selected in progress()["completed"]:
                st.success("Overview checkpoint completed. Detailed course learning, comprehensive assessment and practical acceptance remain separate requirements.")
            elif st.button("Complete overview checkpoint", disabled=not (reviewed and best >= 80 and not missing),
                           type="primary", key=selected+"_complete"):
                update(mark_complete(progress(), selected))
                st.rerun()
        with tabs[4]:
            if lesson.get("teaching_resources"):
                st.subheader("Assigned teaching and demonstration")
                for resource in lesson["teaching_resources"]:
                    with st.container(border=True):
                        st.markdown(f"**[{resource['title']}]({resource['url']})**")
                        st.markdown(resource["assignment"])
                        st.caption(resource["access"])
            st.subheader("Continue with the source material")
            for source in lesson["sources"]:
                st.markdown(f"- [{source['title']}]({source['url']})")
            st.caption("These references support further study. The teaching and questions here are independently authored; certificate mappings indicate relevance, not verified examination coverage.")
            st.markdown("**Curriculum links:** " + ", ".join(lesson["curriculum_refs"]))
            st.markdown("**Lifecycle connections:** " + ", ".join(lesson["lifecycle"]))
            st.download_button("Download this lesson's Anki cards", flashcard_export([lesson]),
                               file_name=selected+"-Anki.tsv", mime="text/tab-separated-values", key=selected+"_anki")
        if lesson.get("practical_assignment"):
            with tabs[5]:
                task = lesson["practical_assignment"]
                st.subheader("Demonstrate the capability")
                st.caption("Required environment: " + task["environment"])
                st.markdown(task["brief"])
                st.markdown("**Execution and investigation**")
                for number, step in enumerate(task["steps"], 1):
                    st.markdown(f"{number}. {step}")
                st.markdown("**Evidence to submit**")
                for item in task["deliverables"]:
                    st.markdown("- " + item)
                st.markdown("**Acceptance criteria**")
                for item in task["acceptance_criteria"]:
                    st.markdown("- " + item)
                st.info(task["limitations"])
                st.button("Open the practical workbench", on_click=go_workbench, args=(selected,), key=selected+"_workbench")
        return
    heading("The subject library", "Build your understanding.",
            "Browse short topic overviews. Open Courses for the expanded teaching and assessment banks.")
    c1, c2, c3 = st.columns([1.3, 1, 1])
    search = c1.text_input("Find a lesson", placeholder="Try EPMS, redundancy, cooling…")
    domain = c2.selectbox("Subject", ["All subjects"] + list(DOMAINS), format_func=lambda x: DOMAINS.get(x, x))
    level = c3.selectbox("Target topic stage", ["All levels", "Foundation", "Applied", "Advanced"])
    selected_lessons = [l for l in LESSONS if (domain == "All subjects" or l["domain"] == domain)
                        and (level == "All levels" or l["level"] == level)
                        and (not search or search.lower() in json.dumps({k:l[k] for k in ['id','title','summary','objectives','curriculum_refs']}).lower())]
    st.caption(f"{len(selected_lessons)} overview lessons · Stage labels describe intended topics, not complete instructional depth.")
    if not selected_lessons:
        st.info("No lessons match these filters. Try another subject, level or search term.")
        return
    pages = max(1, (len(selected_lessons)+11)//12)
    page = st.selectbox("Lesson page", range(1, pages+1), format_func=lambda x:f"{x} of {pages}")
    visible = selected_lessons[(page-1)*12:page*12]
    for start in range(0, len(visible), 3):
        for col, lesson in zip(st.columns(3), visible[start:start+3]):
            with col:
                lesson_card(lesson, "library_" + lesson["id"])


def practice_page():
    heading("Recall meets reasoning", "Test what you understand.",
            "Use focused practice or a mixed assessment. Every answer links back to a specific learning objective.")
    if st.session_state.get("practice_ids"):
        qs = [QUESTIONS[i] for i in st.session_state["practice_ids"] if i in QUESTIONS]
        st.caption(f"{len(qs)} questions · {st.session_state.get('practice_label', 'Mixed practice')}")
        render_assessment(qs, st.session_state["practice_key"], "practice")
        if st.button("Choose another practice set"):
            del st.session_state["practice_ids"]
            st.rerun()
        return
    left, right = st.columns([1.2, 1])
    with left:
        domain = st.selectbox("Subject", ["All subjects"]+list(DOMAINS), format_func=lambda x: DOMAINS.get(x, x), key="practice_domain")
        cert = st.selectbox("Certificate relevance", ["All certificates"]+list(CERT_BY_ID), key="practice_cert")
        depth = st.selectbox("Target topic stage", ["All levels", "Foundation", "Applied", "Advanced"], key="practice_depth")
        mode = st.radio("Question pool", ["Completed lessons", "All available lessons", "Previously incorrect questions"], key="practice_scope")
        size = st.select_slider("Questions", options=[5, 10, 15, 20, 30], value=10)
        eligible = [l for l in LESSONS if (domain == "All subjects" or l["domain"] == domain)
                    and (cert == "All certificates" or cert in l["certificates"])
                    and (depth == "All levels" or l["level"] == depth)]
        if mode == "Completed lessons":
            eligible = [l for l in eligible if l["id"] in progress()["completed"]]
        qs = [QUESTIONS[q["id"]] for l in eligible for q in l["questions"]]
        if mode == "Previously incorrect questions":
            latest = {}
            for a in progress()["attempts"]:
                for r in a.get("results", []):
                    latest[r["question_id"]] = r["correct"]
            qs = [q for q in qs if latest.get(q["id"]) is False]
        st.caption(f"{len(qs)} questions available for this selection.")
        if st.button("Start practice", type="primary", disabled=not qs):
            chosen = random.sample(qs, min(size, len(qs)))
            st.session_state["practice_ids"] = [q["id"] for q in chosen]
            st.session_state["practice_key"] = "practice_"+uuid.uuid4().hex
            st.session_state["practice_label"] = mode
            st.rerun()
    with right:
        with st.container(border=True):
            st.subheader("Practise with a purpose")
            st.write("Begin with the lessons you have studied, then mix subjects to practise distinguishing similar-looking problems.")
            st.write("The results explain each option and identify the exact objective to revisit. Incorrect answers remain available for targeted practice until you answer them correctly.")
            st.caption("These questions sample the supplied overviews. They do not cover the full teaching objectives or provide a complete course assessment or mock examination.")


def cases_page():
    heading("Connect the systems", "Make the next decision.",
            "Work through synthetic operating cases using requirements, observations, and competing explanations.")
    case_id = st.selectbox("Case", [x["id"] for x in CASES], format_func=lambda x: next(c['title'] for c in CASES if c['id']==x))
    case = next(x for x in CASES if x["id"] == case_id)
    tags("Target stage: " + case["level"], case["environment"], *[DOMAIN_CODES[x] for x in case["domains"]])
    st.markdown(case["brief"])
    a, b = st.columns([1, 1.35])
    with a:
        st.subheader("Available evidence")
        for e in case["evidence"]:
            with st.container(border=True):
                st.markdown("**"+e["label"]+"**")
                st.markdown(e["text"])
        with st.expander("Prepare for this case"):
            for lid in case["prerequisites"]:
                st.button(BY_ID[lid]["title"], key="case_prereq_"+case_id+lid, on_click=go, args=("Learn", lid))
    with b:
        key = "case_" + case_id
        state = st.session_state.setdefault(key, {"step":0,"choices":[],"id":str(uuid.uuid4())})
        if state["step"] < len(case["steps"]):
            step = case["steps"][state["step"]]
            st.subheader(f"Decision {state['step']+1} of {len(case['steps'])}")
            st.write(step["prompt"])
            choice = st.radio("Your decision", list(range(len(step["options"]))), index=None,
                              format_func=lambda x:step["options"][x], key=state["id"]+step["id"])
            if "feedback" not in state:
                if st.button("Check decision", type="primary", key=key+"check", disabled=choice is None):
                    state["feedback"] = choice
                    state["choices"].append(choice)
                    st.rerun()
            else:
                correct = state["feedback"] == step["correct"]
                (st.success if correct else st.warning)("Sound decision." if correct else "Reconsider this decision.")
                st.markdown(step["explanations"][state["feedback"]])
                if not correct:
                    st.markdown("**Preferred decision:** " + step["options"][step["correct"]])
                    st.markdown(step["explanations"][step["correct"]])
                if st.button("Continue case", key=key+"next"):
                    state["step"] += 1
                    del state["feedback"]
                    st.rerun()
        else:
            results = [{"question_id":step["id"],"lesson_id":case["prerequisites"][0],
                        "objective":step["objective"],"correct":choice==step["correct"]}
                       for step, choice in zip(case["steps"], state["choices"])]
            attempt = {"id":state["id"],"timestamp":now(),"mode":"case",
                       "question_ids":[s["id"] for s in case["steps"]],
                       "answers":{s["id"]:[c] for s,c in zip(case["steps"],state["choices"])},
                       "results":results,"score":sum(r["correct"] for r in results),"total":len(results)}
            if not any(a["id"] == attempt["id"] for a in progress()["attempts"]):
                update(record_attempt(progress(), attempt))
                st.rerun()
            st.success(f"Case completed · {attempt['score']} / {attempt['total']} initial decisions correct")
            st.markdown(case["debrief"])
            with st.expander("Take this into a practical exercise"):
                st.markdown(case["practical_extension"])
            st.caption("This record demonstrates work on a synthetic decision exercise. It does not establish laboratory, field, or production competence.")
            if st.button("Restart case", key=key+"reset"):
                del st.session_state[key]
                st.rerun()
    st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
    with st.expander("Explore a simple capacity model"):
        st.caption("An illustrative steady-state capacity model. It ignores transients, individual equipment limits, and shared dependencies unless declared below.")
        m1,m2,m3 = st.columns(3)
        units = m1.number_input("Installed identical units", min_value=1, max_value=12, value=3)
        rating = m2.number_input("Capacity per unit (kW)", min_value=1, max_value=10000, value=100)
        load = m3.number_input("Required load (kW)", min_value=1, max_value=100000, value=160)
        unavailable = st.slider("Units unavailable during maintenance or failure", 0, int(units), min(1,int(units)))
        shared_failure = st.checkbox("A shared dependency disables every remaining unit")
        remaining = 0 if shared_failure else (units-unavailable)*rating
        margin = remaining-load
        x,y = st.columns(2)
        x.metric("Available capacity", f"{remaining:,.0f} kW")
        y.metric("Capacity margin", f"{margin:+,.0f} kW")
        (st.success if margin>=0 else st.error)("Static capacity is sufficient in this model. Independence and dynamic performance still require evidence." if margin>=0 else "The declared state cannot meet the required load. Change the plan or reduce the requirement before proceeding.")


def certificates_page():
    heading("Preparation with a clear destination", "Your certificate pathways.",
            "Open the credential course, inspect its source scope and track provider awards separately from app study.")
    identifiers = [c["id"] for c in sorted(CERTIFICATES, key=lambda c:c["sequence"])]
    initial = st.session_state.get("certificate_id", "DCCA")
    if initial not in identifiers:
        initial = "DCCA"
    cert_id = st.selectbox("Choose a certificate", identifiers, index=identifiers.index(initial),
                           format_func=lambda x:f"{CERT_BY_ID[x]['sequence']:02d} · {x} — {CERT_BY_ID[x]['name']}", key="cert_picker")
    st.session_state["certificate_id"] = cert_id
    cert = CERT_BY_ID[cert_id]
    tags(cert["provider"], cert["status"])
    st.subheader(cert["name"])
    st.write(cert["description"])
    if cert_id in COURSE_BY_ID:
        course = COURSE_BY_ID[cert_id]
        st.button("Open " + cert_id + " course", on_click=open_course, args=(cert_id,), type="primary", key="cert_course_"+cert_id)
        st.caption(f"{len(course['lessons'])} chapters · {len(course['questions']):,} questions · See course scope for current source verification and external requirements.")
        st.info(course["blueprint"]["scope_note"])
    else:
        st.info(cert["scope_note"])
    st.link_button("Official programme and requirements", cert["url"])
    available_ids = list(dict.fromkeys(lid for group in cert["topic_groups"] for lid in group["lesson_ids"] if lid in BY_ID))
    completed = sum(lid in progress()["completed"] for lid in available_ids)
    if available_ids:
        st.progress(completed/len(available_ids), text=f"{completed} / {len(available_ids)} linked overview checkpoints · not course completion or exam readiness")
    st.subheader("Orientation overviews")
    for group in cert["topic_groups"]:
        with st.expander(f"{group['name']} · {group['status']}"):
            if group["lesson_ids"]:
                for lid in group["lesson_ids"]:
                    if lid in BY_ID:
                        done = "✓ " if lid in progress()["completed"] else ""
                        st.button(done + BY_ID[lid]["title"], key="certlesson_"+cert_id+group['name']+lid,
                                  on_click=go, args=("Learn", lid), width="stretch")
            if group["status"] != "Available":
                st.caption("These links are orientation overviews. Use Courses for the credential chapters and question bank.")
    if cert.get("external_assignments"):
        with st.expander("Required external preparation"):
            for assignment in cert["external_assignments"]:
                if isinstance(assignment, str):
                    st.markdown("- " + assignment)
                else:
                    st.markdown(f"**[{assignment['title']}]({assignment['url']})**")
                    st.markdown(assignment["assignment"])
                    st.caption(assignment["access"])
    if cert.get("coverage_limits"):
        with st.expander("What this certificate view does and does not cover"):
            for item in cert["coverage_limits"]:
                st.markdown("- " + item)
    with st.expander("Provider requirements and earned credential record"):
        st.write(cert["requirements_note"])
        has_credential = cert_id in progress()["credentials"]
        st.caption("Self-reported credential record, separate from app learning results. It is not independently verified.")
        confirmed = st.checkbox("I have earned this credential from the provider.", value=has_credential, key="earned_confirm_"+cert_id)
        if st.button("Save credential record", key="savecert_"+cert_id):
            if confirmed:
                update(add_credential(progress(), cert_id))
            else:
                p = json.loads(json.dumps(progress()))
                p["credentials"] = [x for x in p["credentials"] if x != cert_id]
                p["revision"] += 1
                update(p)
            st.rerun()
    st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
    left,right = st.columns([1,1])
    with left:
        st.subheader("ISA Expert milestone · #14")
        if "ISA-EXPERT" in COURSE_BY_ID:
            st.button("Open Expert integration course", on_click=open_course, args=("ISA-EXPERT",), key="expert_integration")
        earned = [x for x in ["IC32","IC33","IC34","IC37"] if x in progress()["credentials"]]
        st.progress(len(earned)/4, text=f"{len(earned)} / 4 constituent certificates recorded")
        st.caption("ISA awards the Expert certificate after all four specialist certificates are earned. App quiz completion does not award a credential.")
        if len(earned)==4:
            st.success("All four credentials are recorded. Confirm your Expert award in your ISA account.")
    with right:
        st.subheader("CCNA remains separate")
        st.write("Use your existing CCNA app for networking foundations and CCNA exam practice.")
        st.link_button("Open CCNA practice", "https://seejovin-ccna.streamlit.app/")
    st.caption("Your planned order is retained. Course/exam eligibility, official syllabus editions, and renewal requirements must be checked with the provider before booking. Topic relevance is not an equivalence claim.")


def flashcards_page():
    heading("Built-in flashcards", "Make knowledge retrievable.",
            "Review every card here: recall, reveal, rate, and return when it is due. Your ratings and next review dates are saved with your app progress.")
    scope = st.radio("Card collection", ["Courses", "Orientation overviews", "All material"], horizontal=True, key="card_collection")
    card_units = COURSE_UNITS if scope == "Courses" else LESSONS if scope == "Orientation overviews" else ALL_UNITS
    a,b,c = st.columns(3)
    domain = a.selectbox("Subject", ["All subjects"]+list(DOMAINS), format_func=lambda x:DOMAINS.get(x,x), key="card_domain")
    cert = b.selectbox("Course or certificate", ["All certificates"]+list(dict.fromkeys(list(CERT_BY_ID)+list(COURSE_BY_ID))), key="card_cert")
    depth = c.selectbox("Target topic stage", ["All levels", "Course", "Foundation", "Applied", "Advanced"], key="card_depth")
    studied_only = st.checkbox("Only lessons I have completed", value=False, key="card_completed")
    filtered = [l for l in card_units if (domain=="All subjects" or l["domain"]==domain)
                and (cert=="All certificates" or cert in l["certificates"])
                and (depth=="All levels" or l["level"]==depth)
                and (not studied_only or l["id"] in progress()["completed"])]
    chapters = {l["id"]: l for l in filtered if l["cards"]}
    chapter_options = ["All chapters"] + list(chapters)
    target = st.session_state.pop("card_chapter_target", None)
    if target in chapter_options:
        st.session_state["card_chapter"] = target
    if st.session_state.get("card_chapter") not in chapter_options:
        st.session_state["card_chapter"] = "All chapters"
    chapter = st.selectbox("Chapter or lesson", chapter_options, key="card_chapter",
                           format_func=lambda lid: f"{lid} · {chapters[lid]['title']}" if lid in chapters else lid)
    if chapter != "All chapters":
        filtered = [chapters[chapter]]
    cards = [{**c,"lesson_id":l["id"]} for l in filtered for c in l["cards"]]
    if not cards:
        st.info("No cards match this selection. Complete a lesson or broaden your filters.")
        return
    review_early = st.checkbox("Include cards scheduled for later", value=False, key="review_early")
    current_time = datetime.now(timezone.utc)
    queue, counts = review_queue(cards, progress()["reviews"], current_time, review_early)
    for col, key, label in zip(st.columns(4), ["due", "new", "scheduled", "reviewed"],
                               ["Due now", "New cards", "Scheduled for later", "Cards reviewed"]):
        col.metric(label, counts[key])
    st.caption(f"{counts['total']} cards in this selection. Due cards come first. Reviews save on this browser; use Progress → Backup & restore to move your history.")
    st.button("Refresh due cards", key="card_refresh")
    with st.expander("Review intervals and optional export"):
        st.write("Again: 10 minutes · Hard: 1 day · Good: 3 days · Easy: 7 days. Each rating schedules the card from now using these fixed intervals.")
        st.write("All cards can be reviewed in this app. Anki export is optional and has a separate review history.")
        if st.checkbox("Show optional Anki downloads", key="show_anki_downloads"):
            export_col1,export_col2 = st.columns(2)
            export_col1.download_button(f"Download Anki deck · {counts['total']} cards", anki_package(filtered),
                                      file_name="Data-Center-Academy.apkg",mime="application/octet-stream")
            export_col2.download_button("Download editable Anki TSV", flashcard_export(filtered),
                                      file_name="Data-Center-Academy.tsv",mime="text/tab-separated-values")
            st.caption("Open .apkg in Anki. For TSV use fields NoteID, Front, Back, Source; map column five to Tags and enable HTML. These exports contain cards, without the app's scheduling history.")
    if not queue:
        st.session_state["active_card"] = None
        st.session_state["card_revealed"] = False
        st.success("Your review queue is clear for now. Return when cards are due, or include scheduled cards to review early.")
        return
    filter_key = (scope, domain, cert, depth, studied_only, chapter, review_early)
    if (st.session_state.get("card_filter") != filter_key
            or st.session_state.get("active_card") not in {c["id"] for c in queue}):
        st.session_state["card_filter"] = filter_key
        st.session_state["active_card"] = queue[0]["id"]
        st.session_state["card_revealed"] = False
    card = next(c for c in queue if c["id"]==st.session_state["active_card"])
    tags(card["lesson_id"], ALL_BY_ID[card["lesson_id"]]["title"])
    st.markdown(f'<div class="flashcard"><div class="eyebrow">Recall before revealing</div><div class="flashcard-front">{escape(card["front"])}</div></div>',unsafe_allow_html=True)
    if not st.session_state.get("card_revealed"):
        if st.button("Reveal answer",type="primary"):
            st.session_state["card_revealed"] = True
            st.rerun()
    else:
        st.markdown(f'<div class="flashcard"><div class="eyebrow">Check your reasoning</div><div class="flashcard-back">{escape(card["back"])}</div></div>',unsafe_allow_html=True)
        for col,rating,label in zip(st.columns(4),["again","hard","good","easy"],["Again","Hard","Good","Easy"]):
            if col.button(label,key="rate_"+rating,width="stretch"):
                update(record_review(progress(),card["id"],rating))
                next_cards = [c for c in queue if c["id"]!=card["id"]]
                st.session_state["active_card"] = next_cards[0]["id"] if next_cards else card["id"]
                st.session_state["card_revealed"] = False
                st.rerun()
        st.caption("Again means you did not recall the answer. Hard means you recalled it with difficulty. Ratings update this app's independent review schedule.")
    record = progress()["reviews"].get(card["id"])
    if record:
        st.caption(f"Reviewed {record['count']} times · Last rating: {record['rating'].title()}")
    source_unit = ALL_BY_ID[card["lesson_id"]]
    if source_unit.get("course_id"):
        st.button("Revisit the source chapter", on_click=open_course, args=(source_unit["course_id"], card["lesson_id"]))
    else:
        st.button("Revisit the source lesson",on_click=go,args=("Learn",card["lesson_id"]))


def progress_page():
    heading("Evidence of learning", "See what needs attention.",
            "Keep knowledge checks, scenario decisions, and practical evidence distinct. Use your results to choose the next useful exercise.")
    tabs = st.tabs(["Subject progress","Weak objectives","Attempt history","Practical evidence","Backup & restore"])
    with tabs[0]:
        if COURSES:
            st.subheader("Course chapters")
            for course in COURSES:
                done = sum(l["id"] in progress()["completed"] for l in course["lessons"])
                st.progress(done/len(course["lessons"]), text=f"{course['id']} · {done} / {len(course['lessons'])} chapter checkpoints")
            st.subheader("Orientation overviews")
        for domain,name in DOMAINS.items():
            lessons = [l for l in LESSONS if l["domain"]==domain]
            if not lessons:
                continue
            done = sum(l["id"] in progress()["completed"] for l in lessons)
            st.markdown(f"**{name}**")
            st.progress(done/len(lessons),text=f"{done} / {len(lessons)} available overview checkpoints")
            levels = []
            for level in ["Foundation","Applied","Advanced"]:
                subset = [l for l in lessons if l["level"]==level]
                if subset:
                    levels.append(f"{level} target topics: {sum(l['id'] in progress()['completed'] for l in subset)}/{len(subset)}")
            st.caption(" · ".join(levels)+" · Orientation progress only. Course checkpoints are shown separately above.")
        st.caption("Near-term focus: networks, IT hardware, OT/controls and cybersecurity. Power/cooling foundations support integration; full engineering ownership is a later development horizon. Civil/structural/architectural engineering is excluded.")
    with tabs[1]:
        stats = objective_stats(ALL_UNITS,progress())
        if not stats:
            st.info("Complete a knowledge check or practice set to see objective-level feedback.")
        else:
            weak = sorted(stats,key=lambda s:(s["accuracy"],-s["total"]))
            for row in weak:
                with st.container(border=True):
                    st.markdown("**"+OBJECTIVES_BY_ID.get(row["objective"], {}).get("text", row["objective"])+"**")
                    st.caption(f"{DOMAINS.get(row['domain'],row['domain'])} · {row['correct']}/{row['total']} correct · {row['accuracy']:.0f}% historical accuracy")
                    if row["total"]<3:
                        st.caption("Limited evidence: fewer than three answers. Use further questions before drawing a strong conclusion.")
                    for lid in row.get("lesson_ids",[])[:1]:
                        if lid in BY_ID:
                            st.button("Revisit "+BY_ID[lid]["title"],key="weak_"+row["objective"]+lid,on_click=go,args=("Learn",lid))
    with tabs[2]:
        attempts = progress()["attempts"]
        if not attempts:
            st.info("Your completed assessments will appear here.")
        for a in reversed(attempts[-50:]):
            with st.expander(f"{a['timestamp'][:16].replace('T',' ')} UTC · {a['mode'].title()} · {a['score']}/{a['total']}"):
                if a["mode"]=="case":
                    st.write("Synthetic decision exercise. Initial decisions were recorded before feedback.")
                    for r in a["results"]:
                        st.write(("✓ " if r["correct"] else "Review: ")+r["objective"])
                else:
                    question_results(a)
    with tabs[3]:
        st.write("Record external practical work separately from lessons. These entries are self-reported and do not provide independent acceptance or authorisation.")
        environments = {"analytical":"Analytical design","simulation":"Computational simulation","emulation":"Network emulation","vendor_simulation":"Vendor simulation","physical_lab":"Physical laboratory","supervised_field":"Supervised field work","production":"Production operation"}
        with st.form("evidence_form"):
            title = st.text_input("Exercise title", max_chars=200)
            lesson = st.selectbox("Related lesson",list(ALL_BY_ID),format_func=lambda x:ALL_BY_ID[x]["title"])
            env = st.selectbox("Evidence environment",list(environments),format_func=lambda x:environments[x])
            notes = st.text_area("Requirements, observations, validation, and remaining limitations",height=150,max_chars=6000)
            submitted = st.form_submit_button("Save evidence note",type="primary")
        if submitted:
            if not title.strip() or not notes.strip():
                st.warning("Add a title and a description of your evidence.")
            else:
                update(add_evidence(progress(),{"title":title,"lesson_id":lesson,"environment":env,"review_status":"self_reported","notes":notes}))
                st.rerun()
        for e in reversed(progress()["evidence"]):
            with st.expander(e["title"]):
                st.caption(environments.get(e["environment"],e["environment"])+" · Self-reported")
                st.write(e.get("notes",""))
                if e.get("url"):
                    st.link_button("Open linked evidence or review", e["url"])
    with tabs[4]:
        st.subheader("Keep a portable copy")
        st.write("Progress is saved in this browser on this device. It survives a normal page reload and app restart, but clearing site data or changing devices removes access to that copy. Export a backup to move or preserve your progress.")
        st.download_button("Export progress backup",json.dumps(progress(),ensure_ascii=False,separators=(",", ":")),
                           file_name="progress-datacenter-"+datetime.now().strftime('%Y-%m-%d')+".json",mime="application/json")
        uploaded = st.file_uploader("Restore a progress backup",type=["json"],help="Maximum 16 MB. A restore replaces the current device's progress.")
        if uploaded:
            if uploaded.size > 16*1024*1024:
                st.error("This backup exceeds the 16 MB size limit.")
            else:
                try:
                    imported = normalize_progress(uploaded.getvalue())
                    unknown = set(imported["completed"])-set(ALL_BY_ID)
                    st.caption(f"Backup: {len(imported['completed'])} checkpoints, {len(imported['attempts'])} attempts, {len(imported['evidence'])} evidence notes.")
                    if unknown:
                        st.warning("This backup includes lessons from another content version; unmatched records are retained but do not count toward current progress.")
                    acknowledge = st.checkbox("Replace this device's current progress with this backup.")
                    if st.button("Restore backup",disabled=not acknowledge,type="primary"):
                        imported["revision"] = max(progress()["revision"],imported["revision"])+1
                        update(imported)
                        st.session_state["restore_token"] = str(uuid.uuid4())
                        st.session_state["guest_mode"] = False
                        for key in list(st.session_state):
                            if key.endswith("_result") or key.startswith("case_"):
                                del st.session_state[key]
                        st.success("Backup restored.")
                        st.rerun()
                except (ValueError,TypeError,KeyError,UnicodeDecodeError,json.JSONDecodeError) as exc:
                    st.error(f"Cannot import this backup: {exc}")
        st.caption("Personal progress and evidence notes are not written to GitHub. On a hosted app, they are processed by that app's server during use, while the durable copy stays in your browser. Avoid storing confidential workplace data.")


def main():
    st.session_state.setdefault("progress",default_progress())
    st.session_state.setdefault("page","Today")
    with st.sidebar:
        st.markdown('<span class="brand-mark">◈</span><div class="brand">Data Center<br>Academy</div><div class="muted">Understand. Apply. Sustain.</div>',unsafe_allow_html=True)
        st.write("")
    test_mode = st.session_state.get("_test_mode",False)
    if not test_mode:
        outgoing = progress() if st.session_state.get("device_loaded") and not st.session_state.get("guest_mode") else None
        message = render_device_store(outgoing, restore_token=st.session_state.get("restore_token"))
        if message and message.get("ready") and not st.session_state.get("device_loaded"):
            try:
                if message.get("progress"):
                    update(normalize_progress(message["progress"]))
                st.session_state["device_loaded"] = True
                st.session_state["save_error"] = message.get("error")
                st.rerun()
            except (ValueError,TypeError) as exc:
                st.error(f"Saved progress could not be opened: {exc}. Your stored data has not been replaced.")
                if st.button("Continue for this session only"):
                    st.session_state["guest_mode"] = True
                    st.session_state["device_loaded"] = True
                    st.rerun()
                st.stop()
        if not st.session_state.get("device_loaded"):
            heading("Data Center Academy","Preparing your learning space…","Loading your saved progress from this browser.")
            st.caption("If browser storage is blocked, you can continue for this session and export a backup before leaving.")
            if st.button("Continue without device saving"):
                st.session_state["guest_mode"] = True
                st.session_state["device_loaded"] = True
                st.rerun()
            st.stop()
        if message and message.get("error"):
            st.session_state["save_error"] = message["error"]
        elif message and message.get("saved_revision") == progress()["revision"]:
            st.session_state["save_error"] = None
            st.session_state["last_saved_revision"] = message["saved_revision"]
            # A restore is a one-shot explicit replacement. Do not leave its
            # permission active if the component iframe is later remounted.
            st.session_state.pop("restore_token", None)
        if message and message.get("external_change"):
            st.warning("Progress changed in another tab. Export your current work before reloading to use the other tab's progress.")
            if st.button("Load the other tab's saved progress"):
                try:
                    update(normalize_progress(message["progress"]) if message.get("progress") else default_progress())
                    for key in list(st.session_state):
                        if key.endswith("_result") or key.startswith("case_"):
                            del st.session_state[key]
                    st.rerun()
                except (ValueError, TypeError) as exc:
                    st.error(f"The other tab's data could not be loaded: {exc}")
    with st.sidebar:
        st.radio("Explore",PAGES,key="page",label_visibility="collapsed")
        st.markdown('<div class="divider"></div>',unsafe_allow_html=True)
        done = len(set(progress()["completed"])&set(BY_ID))
        if COURSE_UNITS:
            done = len(set(progress()["completed"]) & {l["id"] for l in COURSE_UNITS})
            st.caption("COURSE STUDY PROGRESS")
            st.progress(done/len(COURSE_UNITS),text=f"{done} of {len(COURSE_UNITS)} chapter checkpoints")
        else:
            st.caption("OVERVIEW STUDY PROGRESS")
            st.progress(done/len(LESSONS),text=f"{done} of {len(LESSONS)} overview checkpoints")
        if st.session_state.get("guest_mode") or st.session_state.get("save_error"):
            st.warning("Device saving unavailable. Export your progress before leaving.")
        elif not test_mode and st.session_state.get("last_saved_revision") != progress()["revision"]:
            st.caption("Saving progress… Keep this page open until the save completes.")
        else:
            st.caption("Saved on this device. Use Backup & restore to move your progress.")
        st.caption(f"Release {VERSION} · {len(QUESTIONS)} original questions")
        with st.expander("About this programme"):
            st.write("Traced to Curriculum Revision 14, Charter Revision 3.5 and Portfolio Version 2.5. The curriculum workspace preserves all 48 capability requirements and their practical acceptance boundaries.")
            st.write("Courses contains credential instruction and question banks, including an ISA Expert integration bank. Source scope, coverage limits and external requirements are shown for each course.")
            st.write("Independent learning aid. No affiliation with certification providers. All assessment items are original.")
    {"Today":today_page,"Courses":lambda:render_courses(COURSES, progress(), update, render_assessment),
     "Programme":lambda:render_programme(PROGRAMME, LESSONS, progress(), go, update, COURSES),
     "Learn":learn_page,"Practice":practice_page,"Cases":cases_page,
     "Certificates":certificates_page,"Flashcards":flashcards_page,"Progress":progress_page}[st.session_state["page"]]()


if __name__=="__main__":
    main()
