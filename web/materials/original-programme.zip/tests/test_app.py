"""User-facing Streamlit flows; browser storage is exercised by browser tests.

These checks verify learning records, assessment gates and scope separation through
actual widgets. They do not infer learning outcomes from merely rendering pages.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

from core.engine import load_lessons
from core.academy import load_courses
from core.programme import load_cases

ROOT = Path(__file__).resolve().parents[1]
LESSONS = load_lessons()
BY_ID = {lesson['id']: lesson for lesson in LESSONS}
QUESTIONS = {question['id']: question for lesson in LESSONS for question in lesson['questions']}
CASES = load_cases()
CERTIFICATES = json.loads((ROOT / 'content/certificates.json').read_text())


def app(page='Today', lesson_id=None):
    at = AppTest.from_file(str(ROOT / 'app.py'), default_timeout=30)
    at.session_state['_test_mode'] = True
    at.session_state['page'] = page
    if lesson_id:
        at.session_state['lesson_id'] = lesson_id
    return at.run()


def healthy(at):
    assert not at.exception, '\n'.join(str(exc.message) for exc in at.exception)


def by_label(elements, label):
    matches = [element for element in elements if element.label == label]
    assert len(matches) == 1, f'Expected one {label!r}, found {len(matches)}'
    return matches[0]


def submit_answers(at, attempt_id, questions, wrong_id=None):
    """Select authored answer values, independent of random visual ordering."""
    for question in questions:
        answer = question['correct']
        if question['id'] == wrong_id:
            answer = [next(index for index in range(len(question['options'])) if index not in answer)]
        key = attempt_id + '_' + question['id']
        if question.get('type') == 'multi':
            at.multiselect(key=key).set_value(answer)
        else:
            at.radio(key=key).set_value(answer[0])
    by_label(at.button, 'Submit answers').click().run()
    healthy(at)


def test_all_content_references_resolve_and_case_answers_are_well_formed():
    assert len(CERTIFICATES) == 13
    assert [cert['sequence'] for cert in CERTIFICATES] == [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 15]
    for cert in CERTIFICATES:
        for group in cert['topic_groups']:
            assert set(group['lesson_ids']) <= BY_ID.keys(), (cert['id'], group['name'])
    for lesson in LESSONS:
        expected_certificates = {
            cert['id'] for cert in CERTIFICATES
            if any(lesson['id'] in group['lesson_ids'] for group in cert['topic_groups'])
        }
        assert set(lesson['certificates']) == expected_certificates, lesson['id']
    for case in CASES:
        assert set(case['prerequisites']) <= BY_ID.keys(), case['id']
        assert case['environment'] == 'Synthetic scenario'
        for decision in case['steps']:
            assert len(decision['options']) == len(decision['explanations'])
            assert 0 <= decision['correct'] < len(decision['options'])


@pytest.mark.parametrize('page', ['Today', 'Programme', 'Learn', 'Practice', 'Cases', 'Certificates', 'Flashcards', 'Progress'])
def test_main_navigation_renders_each_page(page):
    at = app()
    at.radio(key='page').set_value(page).run()
    healthy(at)
    assert at.session_state['page'] == page
    assert at.title
    assert at.session_state['progress']['attempts'] == []
    assert at.session_state['progress']['completed'] == []


def test_lesson_requires_answers_and_study_acknowledgement_before_completion():
    lesson = BY_ID['DC-01']
    at = app('Learn', lesson['id'])
    healthy(at)
    assert [tab.label for tab in at.tabs] == [
        'Learn', 'Worked example', 'Guided practice', 'Knowledge check', 'Sources & application'
    ]
    assert at.button(key='DC-01_complete').disabled
    by_label(at.button, 'Submit answers').click().run()
    healthy(at)
    assert any('Answer each question' in warning.value for warning in at.warning)
    assert at.session_state['progress']['attempts'] == []

    submit_answers(at, at.session_state['lesson_DC-01_attempt'], lesson['questions'])
    attempt = at.session_state['progress']['attempts'][0]
    assert attempt['score'] == attempt['total'] == len(lesson['questions'])
    assert at.session_state['progress']['completed'] == []
    assert at.button(key='DC-01_complete').disabled
    at.checkbox(key='DC-01_read').check().run()
    assert not at.button(key='DC-01_complete').disabled
    at.button(key='DC-01_complete').click().run()
    healthy(at)
    assert at.session_state['progress']['completed'] == ['DC-01']
    at.run()
    assert len(at.session_state['progress']['attempts']) == 1
    assert at.session_state['progress']['evidence'] == []
    assert at.session_state['progress']['credentials'] == []


def test_prerequisites_prevent_a_checkpoint_even_after_a_perfect_score():
    lesson = next(lesson for lesson in LESSONS if lesson['prerequisites'])
    at = app('Learn', lesson['id'])
    submit_answers(at, at.session_state['lesson_' + lesson['id'] + '_attempt'], lesson['questions'])
    at.checkbox(key=lesson['id'] + '_read').check().run()
    healthy(at)
    assert at.button(key=lesson['id'] + '_complete').disabled
    assert lesson['id'] not in at.session_state['progress']['completed']


def test_practice_records_mistake_and_offers_targeted_retry():
    at = app('Practice')
    healthy(at)
    assert by_label(at.button, 'Start practice').disabled
    at.radio(key='practice_scope').set_value('All available lessons').run()
    by_label(at.select_slider, 'Questions').set_value(5).run()
    by_label(at.button, 'Start practice').click().run()
    healthy(at)
    qids = at.session_state['practice_ids']
    assert len(qids) == 5
    assert len(set(qids)) == 5
    key = at.session_state['practice_key']
    submit_answers(at, at.session_state[key + '_attempt'], [QUESTIONS[qid] for qid in qids], wrong_id=qids[0])
    attempt = at.session_state['progress']['attempts'][0]
    assert attempt['mode'] == 'practice'
    assert attempt['score'] == 4
    assert [result['question_id'] for result in attempt['results'] if not result['correct']] == [qids[0]]
    by_label(at.button, 'Choose another practice set').click().run()
    at.radio(key='practice_scope').set_value('Previously incorrect questions').run()
    by_label(at.button, 'Start practice').click().run()
    assert at.session_state['practice_ids'] == [qids[0]]
    retry_key = at.session_state['practice_key']
    submit_answers(at, at.session_state[retry_key + '_attempt'], [QUESTIONS[qids[0]]])
    assert len(at.session_state['progress']['attempts']) == 2
    by_label(at.button, 'Choose another practice set').click().run()
    at.radio(key='practice_scope').set_value('Previously incorrect questions').run()
    assert by_label(at.button, 'Start practice').disabled


@pytest.mark.parametrize('case', CASES, ids=lambda case: case['id'])
def test_cases_record_initial_decisions_once_without_practical_credit(case):
    at = app('Cases')
    by_label(at.selectbox, 'Case').set_value(case['id']).run()
    healthy(at)
    assert by_label(at.button, 'Check decision').disabled
    for number, decision in enumerate(case['steps']):
        # An initial error in one case must remain recorded after explanatory feedback.
        choice = decision['correct']
        if case['id'] == CASES[0]['id'] and number == 0:
            choice = (choice + 1) % len(decision['options'])
        by_label(at.radio, 'Your decision').set_value(choice).run()
        by_label(at.button, 'Check decision').click().run()
        healthy(at)
        assert at.session_state['progress']['attempts'] == []
        if case['id'] == CASES[0]['id'] and number == 0:
            # Learning the answer from feedback must not rewrite the initial score.
            by_label(at.radio, 'Your decision').set_value(decision['correct']).run()
        by_label(at.button, 'Continue case').click().run()
        healthy(at)
    attempts = at.session_state['progress']['attempts']
    assert len(attempts) == 1
    expected_score = len(case['steps']) - (case['id'] == CASES[0]['id'])
    assert attempts[0]['mode'] == 'case'
    assert attempts[0]['score'] == expected_score
    assert attempts[0]['total'] == len(case['steps'])
    at.run()
    assert len(at.session_state['progress']['attempts']) == 1
    assert at.session_state['progress']['completed'] == []
    assert at.session_state['progress']['evidence'] == []


def test_certificate_switch_retains_scope_and_distinguishes_earned_credentials():
    at = app('Certificates')
    healthy(at)
    assert any(button.key and button.key.startswith('certlesson_DCCA') for button in at.button)
    assert any(info.value == next(c['blueprint']['scope_note'] for c in load_courses() if c['id']=='DCCA') for info in at.info)
    at.selectbox(key='cert_picker').set_value('CCIE-DC').run()
    healthy(at)
    at.run()
    assert at.session_state['certificate_id'] == 'CCIE-DC'
    assert at.info  # Scope limitations stay visible even with advanced linked lessons.
    assert any(button.key and button.key.startswith('certlesson_CCIE') for button in at.button)
    at.selectbox(key='cert_picker').set_value('IC32').run()
    at.checkbox(key='earned_confirm_IC32').check().run()
    at.button(key='savecert_IC32').click().run()
    healthy(at)
    assert at.session_state['progress']['credentials'] == ['IC32']
    assert at.session_state['progress']['completed'] == []
    assert at.session_state['progress']['attempts'] == []


def test_flashcard_reveal_and_rating_changes_only_recall_progress():
    at = app('Flashcards')
    healthy(at)
    first_card = at.session_state['active_card']
    assert not any(button.key == 'rate_good' for button in at.button)
    by_label(at.button, 'Reveal answer').click().run()
    assert at.session_state['card_revealed'] is True
    at.button(key='rate_good').click().run()
    healthy(at)
    assert first_card in at.session_state['progress']['reviews']
    assert at.session_state['active_card'] != first_card
    assert at.session_state['card_revealed'] is False
    assert at.session_state['progress']['completed'] == []
    assert at.session_state['progress']['attempts'] == []
    at.checkbox(key='card_completed').check().run()
    assert any('No cards match' in info.value for info in at.info)


def test_evidence_requires_content_and_preserves_declared_environment():
    at = app('Progress')
    healthy(at)
    assert [tab.label for tab in at.tabs] == [
        'Subject progress', 'Weak objectives', 'Attempt history', 'Practical evidence', 'Backup & restore'
    ]
    by_label(at.button, 'Save evidence note').click().run()
    assert any('Add a title' in warning.value for warning in at.warning)
    assert at.session_state['progress']['evidence'] == []
    by_label(at.text_input, 'Exercise title').set_value('Synthetic stale-point investigation')
    by_label(at.selectbox, 'Evidence environment').set_value('emulation')
    by_label(at.text_area, 'Requirements, observations, validation, and remaining limitations').set_value(
        'Emulated the polling failure, observed a stale flag, restored delivery. No physical meter or field work.'
    )
    by_label(at.button, 'Save evidence note').click().run()
    healthy(at)
    evidence = at.session_state['progress']['evidence']
    assert len(evidence) == 1
    assert evidence[0]['environment'] == 'emulation'
    assert evidence[0]['review_status'] == 'self_reported'
    assert evidence[0]['title'] == 'Synthetic stale-point investigation'
    assert at.session_state['progress']['completed'] == []
    assert at.session_state['progress']['credentials'] == []


@pytest.mark.parametrize('view', ['Teaching depth','Study route','Outcome coverage','Required teaching','Practical workbench','Alignment & limits'])
def test_programme_views_render_without_granting_completion(view):
    at = app('Programme')
    at.radio(key='programme_view').set_value(view).run()
    healthy(at)
    assert at.session_state['progress']['completed'] == []
    assert at.session_state['progress']['evidence'] == []
    assert at.session_state['progress']['credentials'] == []


def test_advanced_lesson_opens_its_actual_work_package_and_records_only_a_note():
    at = app('Learn','L-NET-04X')
    healthy(at)
    assert 'Independent assignment' in [tab.label for tab in at.tabs]
    assert at.button(key='L-NET-04X_complete').disabled
    at.button(key='L-NET-04X_workbench').click().run()
    healthy(at)
    assert at.session_state['page'] == 'Programme'
    assert at.session_state['programme_view'] == 'Practical workbench'
    assert at.selectbox(key='workbench_outcome').value == 'NET-04'
    by_label(at.text_input,'Event or test title').set_value('Route-policy data review')
    by_label(at.selectbox,'Actual evidence environment').set_value('analytical')
    by_label(at.text_area,'Evidence IDs, measured results, acceptance decision and remaining gaps').set_value(
        'Analysed fictional routes R1–R8. Static policy only; live control-plane and vendor configuration remain untested.'
    )
    by_label(at.button,'Save work-package note').click().run()
    healthy(at)
    record = at.session_state['progress']['evidence'][0]
    assert record['title'].startswith('WP-NET-04')
    assert record['environment']=='analytical'
    assert record['review_status']=='self_reported'
    assert record['lesson_id']=='L-NET-04'
    assert at.session_state['progress']['completed']==[]
    assert at.session_state['progress']['credentials']==[]
