"""Tests for learner data integrity, diagnostic scope, and portable recall."""

import copy
import csv
import io
import json
import sqlite3
import zipfile

import pytest

from core.engine import (
    add_evidence,
    anki_package,
    default_progress,
    flashcard_export,
    grade_question,
    mark_complete,
    normalize_progress,
    objective_stats,
    recommend_lessons,
    record_attempt,
    record_review,
    validate_catalog,
)


def lesson(lid="DC-01", prerequisite=None, domain="Networks"):
    return {
        "id": lid, "title": "Trace a signal", "domain": domain,
        "level": "Foundation", "minutes": 20, "summary": "An engineering lesson.",
        "objectives": ["Distinguish transport from application success"],
        "prerequisites": prerequisite or [], "certificates": ["DCCA"],
        "curriculum_refs": ["D4"], "lifecycle": ["troubleshooting"],
        "body": "Teaching content.", "worked_example": "A successful ping cannot validate an EPMS value.",
        "guided_practice": {"prompt": "What evidence is needed?", "hint": "Follow the value.", "solution": "Inspect timestamps."},
        "questions": [{"id": lid + "-Q1", "objective": "Measurement freshness", "type": "single", "prompt": "Which evidence?", "options": ["Ping", "Timestamp"], "correct": [1], "explanations": ["Tests a path.", "Tests freshness."], "difficulty": "Foundation"}],
        "cards": [{"id": lid + "-C1", "front": "What does <ping> prove?\nExplain.", "back": "A response, not application delivery.\t<script>alert(1)</script>", "tags": ["signal path"]}],
        "sources": [{"title": "Source & specification", "url": "https://example.com/spec?a=1&b=2"}],
    }


def attempt(lid="DC-01", correct=False, aid="attempt-1", stamp="2026-09-19T12:00:00+00:00"):
    qid = lid + "-Q1"
    return {"id": aid, "timestamp": stamp, "mode": "lesson", "question_ids": [qid], "answers": {qid: [1] if correct else [0]}, "results": [{"question_id": qid, "lesson_id": lid, "objective": "Measurement freshness", "correct": correct}], "score": int(correct), "total": 1}


def test_exact_multi_answer_grading_and_invalid_selections():
    question = {"type": "multi", "options": ["a", "b", "c", "d"], "correct": [1, 3]}
    assert grade_question(question, [3, 1])
    for selected in ([], [1], [1, 2, 3], [1, 1, 3], [True, 3], [1, 9], None, "1,3"):
        assert not grade_question(question, selected)
    assert not grade_question(dict(question, type="single"), [1, 3])


def test_roundtrip_and_mutations_do_not_change_source():
    original = default_progress()
    progressed = record_attempt(original, attempt())
    completed = mark_complete(progressed, "DC-01")
    assert original == default_progress()
    assert progressed["completed"] == []
    assert completed["revision"] == 2
    assert normalize_progress(json.dumps(completed).encode()) == completed
    copied = normalize_progress(completed)
    copied["completed"].append("DC-02")
    assert completed["completed"] == ["DC-01"]
    assert mark_complete(completed, "DC-01")["revision"] == 2


def test_attempt_idempotency_and_conflicting_id_rejection():
    data = attempt()
    progress = record_attempt(default_progress(), data)
    assert record_attempt(progress, data) == progress
    changed = attempt(correct=True)
    with pytest.raises(ValueError, match="cannot be reused"):
        record_attempt(progress, changed)


@pytest.mark.parametrize("mutation,match", [
    (lambda p: p.update(schema_version=2), "Unsupported progress schema"),
    (lambda p: p.update(revision=True), "must be an integer"),
    (lambda p: p.update(credentials=["DCCA", "DCCA"]), "duplicate"),
    (lambda p: p.update(unexpected="payload"), "fields do not match"),
    (lambda p: p.update(completed="DC-01"), "must be a list"),
])
def test_import_rejects_bad_schema_and_field_types(mutation, match):
    data = default_progress()
    mutation(data)
    with pytest.raises(ValueError, match=match):
        normalize_progress(data)


def test_import_rejects_inconsistent_results_and_oversized_data():
    data = default_progress()
    bad = attempt()
    bad["score"] = 1
    data["attempts"] = [bad]
    with pytest.raises(ValueError, match="must match"):
        normalize_progress(data)
    with pytest.raises(ValueError, match="16 MB"):
        normalize_progress(" " * (16 * 1024 * 1024 + 1))
    with pytest.raises(ValueError, match="valid JSON"):
        normalize_progress("{broken}")


def test_prerequisite_aware_recommendation_and_scoped_weakness():
    lessons = [lesson(), lesson("DC-02", ["DC-01"]), lesson("DC-03", domain="Networks")]
    assert [item["id"] for item in recommend_lessons(lessons, default_progress())] == ["DC-01", "DC-03"]
    progress = mark_complete(default_progress(), "DC-01")
    progress = record_attempt(progress, attempt("DC-03"))
    suggestions = recommend_lessons(lessons, progress)
    assert [item["id"] for item in suggestions] == ["DC-03", "DC-02"]
    assert "missed" in suggestions[0]["recommendation_reason"]
    assert "missed" not in suggestions[1]["recommendation_reason"]
    # A later correct answer resolves this specific diagnostic priority.
    progress = record_attempt(progress, attempt("DC-03", True, "attempt-2", "2026-09-20T12:00:00Z"))
    assert recommend_lessons(lessons, progress)[0]["id"] == "DC-02"


def test_objective_stats_uses_question_metadata_and_retains_case_scope():
    progress = record_attempt(default_progress(), attempt())
    modified = attempt(correct=True, aid="attempt-2")
    modified["results"][0]["objective"] = "Incorrect imported label"
    progress = record_attempt(progress, modified)
    progress = record_attempt(progress, attempt("CASE-01", False, "case-1"))
    stats = objective_stats([lesson()], progress)
    networking = next(item for item in stats if item["domain"] == "Networks")
    assert networking["objective"] == "Measurement freshness"
    assert networking["correct"] == 1 and networking["total"] == 2
    assert networking["accuracy"] == 50.0
    assert any(item["domain"] == "Integrated cases" for item in stats)


def test_evidence_does_not_count_as_learning_or_award_credentials():
    progress = add_evidence(default_progress(), {"title": "Lab restoration", "environment": "physical_lab", "review_status": "self_reported", "notes": "Measured only in a lab."})
    assert progress["completed"] == [] and progress["attempts"] == [] and progress["credentials"] == []
    assert normalize_progress(progress) == progress
    with pytest.raises(ValueError, match="environment"):
        add_evidence(progress, {"title": "Wrong environment", "environment": "real expert", "review_status": "reviewed"})
    with pytest.raises(ValueError, match="https"):
        add_evidence(progress, {"title": "Unsafe URL", "environment": "analytical", "review_status": "reviewed", "url": "javascript:alert(1)"})


def test_in_app_reviews_are_separate_from_anki_and_roundtrip():
    progress = record_review(default_progress(), "DC-01-C1", "good", "2026-09-19T12:00:00Z")
    assert progress["reviews"]["DC-01-C1"]["due"] == "2026-09-22T12:00:00+00:00"
    assert progress["reviews"]["DC-01-C1"]["interval_days"] == 3
    assert normalize_progress(progress) == progress


def test_catalog_rejects_duplicate_question_and_prerequisite_cycles():
    validate_catalog([lesson(), lesson("DC-02", ["DC-01"])])
    with pytest.raises(ValueError, match="cycle"):
        validate_catalog([lesson("DC-01", ["DC-02"]), lesson("DC-02", ["DC-01"])])
    two = lesson("DC-02")
    two["questions"] = copy.deepcopy(lesson()["questions"])
    with pytest.raises(ValueError, match="Duplicate question"):
        validate_catalog([lesson(), two])
    with pytest.raises(ValueError, match="unknown prerequisite"):
        validate_catalog([lesson("DC-01", ["DC-99"])])


def test_anki_tsv_stable_ids_deduplicate_mapping_and_escape_text():
    first, second = lesson(), lesson("DC-02")
    second["cards"] = copy.deepcopy(first["cards"])
    second["certificates"] = ["IC32"]
    exported = flashcard_export([first, second])
    lines = [line for line in exported.splitlines() if not line.startswith("#")]
    rows = list(csv.reader(lines, delimiter="\t"))
    assert len(rows) == 1 and len(rows[0]) == 5
    assert rows[0][0] == "DC-01-C1"
    assert "&lt;ping&gt;" in rows[0][1] and "<br>" in rows[0][1]
    assert "<script>" not in rows[0][2] and "&lt;script&gt;" in rows[0][2]
    assert "certificate::DCCA" in rows[0][4] and "certificate::IC32" in rows[0][4]
    changed = copy.deepcopy(first)
    changed["cards"][0]["back"] = "A corrected answer."
    assert flashcard_export([changed]).splitlines()[-1].startswith("DC-01-C1\t")


def test_anki_package_has_stable_note_guid_across_wording_updates(tmp_path):
    def notes(package, suffix):
        with zipfile.ZipFile(io.BytesIO(package)) as archive:
            db = tmp_path / (suffix + ".anki2")
            db.write_bytes(archive.read("collection.anki2"))
        with sqlite3.connect(db) as connection:
            return connection.execute("SELECT guid, flds FROM notes ORDER BY guid").fetchall()
    original = lesson()
    first = notes(anki_package([original]), "first")
    changed = copy.deepcopy(original)
    changed["cards"][0]["back"] = "Corrected factual explanation."
    second = notes(anki_package([changed]), "second")
    assert len(first) == len(second) == 1
    assert first[0][0] == second[0][0]
    assert first[0][1] != second[0][1]


def test_available_catalog_validates():
    from core.engine import CONTENT_DIR, load_lessons
    if not all((CONTENT_DIR / name).exists() for name in ("facility.json", "engineering.json")):
        pytest.skip("Content authors have not written both catalog files yet.")
    assert len(load_lessons()) >= 10
