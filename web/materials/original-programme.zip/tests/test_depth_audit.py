import copy

import pytest

from core.engine import default_progress, load_lessons
from core.depth_audit import load_depth_audit, validate_depth_audit, course_status_rows


def test_existing_overviews_do_not_establish_course_teaching_completeness():
    lessons, audit = load_lessons(), load_depth_audit()
    validate_depth_audit(audit, lessons)
    assert all(lesson.get("content_class") == "overview" for lesson in lessons)
    assert all(row["Detailed teaching"] == "Incomplete" for row in course_status_rows(audit))
    assert all(row["Completeness percentage"] == "Not established" for row in course_status_rows(audit))
    p = default_progress()
    p["completed"] = [lesson["id"] for lesson in lessons]
    assert all(row["Detailed teaching"] == "Incomplete" for row in course_status_rows(audit))
    assert not p["credentials"]


@pytest.mark.parametrize("field", ["teaching_state", "assessment_state"])
def test_mapping_to_overviews_cannot_be_promoted_to_reviewed_detailed_content(field):
    lessons, audit = load_lessons(), copy.deepcopy(load_depth_audit())
    requirement = next(req for c in audit["courses"] for req in c["requirements"] if req["current_lesson_ids"])
    requirement[field] = "reviewed"
    requirement["detailed_lesson_ids"] = requirement["current_lesson_ids"]
    requirement["objective_ids"] = ["claimed-objective"]
    requirement["artifact_ids"] = ["claimed-artifact"]
    requirement["review_record_ids"] = ["claimed-review"]
    with pytest.raises(ValueError, match="overview lessons cannot"):
        validate_depth_audit(audit, lessons)


def test_missing_lesson_and_uncontrolled_audit_state_are_rejected():
    lessons, audit = load_lessons(), copy.deepcopy(load_depth_audit())
    audit["courses"][0]["requirements"][0]["current_lesson_ids"] = ["unknown-lesson"]
    with pytest.raises(ValueError, match="unresolved lesson"):
        validate_depth_audit(audit, lessons)
