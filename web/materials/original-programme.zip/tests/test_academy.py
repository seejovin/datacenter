"""Regression checks for sequence scoring, coverage and large-course progress."""
import json
from core.academy import assessment_rows, chapter_status, select_questions
from core.engine import default_progress, grade_question, normalize_progress, record_attempt


def attempt(qs, answers, identity='attempt-1'):
    results=[{'question_id':q['id'],'lesson_id':q['lesson_ids'][0],
              'objective':q['objective_id'],'correct':grade_question(q,answers[q['id']])} for q in qs]
    return {'id':identity,'timestamp':'2026-09-19T12:00:00+00:00','mode':'course_practice',
            'question_ids':[q['id'] for q in qs],'answers':answers,'results':results,
            'score':sum(x['correct'] for x in results),'total':len(qs)}


def questions():
    return [{'id':f'COURSE-Q{i}','objective_id':'O1' if i<3 else 'O2','lesson_ids':['L1' if i<3 else 'L2'],
             'options':['A','B','C'],'correct':[0],'type':'single'} for i in range(6)]


def test_sequence_requires_order_not_just_the_same_steps():
    q={'options':['Restore trusted control','Check physical state','Authorise return'], 'correct':[1,0,2], 'type':'order'}
    assert grade_question(q,[1,0,2])
    assert not grade_question(q,[0,1,2])
    assert not grade_question(q,{0,1,2})
    assert not grade_question(q,[1,0])
    assert not grade_question(q,[1,0,2,2])


def test_repeated_easy_answers_do_not_inflate_distinct_coverage_or_clear_unseen_work():
    qs=questions()
    p=record_attempt(default_progress(),attempt(qs[:1],{qs[0]['id']:[0]}))
    p=record_attempt(p,attempt(qs[:1],{qs[0]['id']:[0]},'attempt-2'))
    course={'questions':qs,'objectives':[{'id':'O1','text':'First objective','source_ref':'1'}, {'id':'O2','text':'Second objective','source_ref':'2'}]}
    rows=assessment_rows(course,p)
    assert rows[0]['Attempted']==1
    assert rows[0]['Coverage %']==33.3
    assert rows[1]['Accuracy %'] is None
    assert not chapter_status(course,'L1',p)['checkpoint_eligible']
    assert {q['id'] for q in select_questions(qs,p,20,'Unanswered','seed')}=={q['id'] for q in qs[1:]}


def test_latest_incorrect_answer_returns_to_remediation_and_selection_balances_objectives():
    qs=questions()
    p=record_attempt(default_progress(),attempt(qs[:1],{qs[0]['id']:[0]}))
    p=record_attempt(p,attempt(qs[:1],{qs[0]['id']:[1]},'attempt-2'))
    assert [q['id'] for q in select_questions(qs,p,5,'Previously incorrect','seed')]==[qs[0]['id']]
    chosen=select_questions(qs,p,4,'All questions','seed')
    assert len({q['id'] for q in chosen})==4
    assert sum(q['objective_id']=='O1' for q in chosen)==2
    assert sum(q['objective_id']=='O2' for q in chosen)==2


def test_repeated_study_of_7500_questions_and_recall_history_survives_backup_validation():
    p=default_progress()
    for batch in range(150):
        qs=[{'id':f'COURSE-Q{(batch%75)*100+i:05}','objective_id':f'COURSE-O{i%25:02}',
             'lesson_ids':[f'COURSE-L{i%25:02}'],'options':['A','B','C'],
             'correct':[0],'type':'single'} for i in range(100)]
        p['attempts'].append(attempt(qs,{q['id']:[0] for q in qs},f'attempt-{batch}'))
    p['reviews']={f'CARD-{i}':{'rating':'good','last_reviewed':'2026-09-19T12:00:00+00:00',
                    'due':'2026-09-22T12:00:00+00:00','interval_days':3,'count':1} for i in range(5000)}
    encoded=json.dumps(p)
    assert len(encoded)>2*1024*1024  # The old limit could not retain this study record.
    restored=normalize_progress(encoded)
    assert sum(a['total'] for a in restored['attempts'])==15000
    assert len(restored['reviews'])==5000
    assert restored==p
