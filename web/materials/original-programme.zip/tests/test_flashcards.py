"""Built-in recall ordering, direct study navigation and saved review behavior."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from streamlit.testing.v1 import AppTest

from core.academy import load_courses
from core.engine import default_progress, normalize_progress, record_review
from core.recall import review_queue


ROOT = Path(__file__).resolve().parents[1]


def healthy(at):
    assert not at.exception, "\n".join(str(exc.message) for exc in at.exception)


def app(page="Flashcards", **state):
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=30)
    at.session_state["_test_mode"] = True
    at.session_state["page"] = page
    for key, value in state.items():
        at.session_state[key] = value
    at.run()
    healthy(at)
    return at


def reveal(at):
    buttons = [button for button in at.button if button.label == "Reveal answer"]
    assert len(buttons) == 1
    buttons[0].click().run()
    healthy(at)
    assert at.session_state["card_revealed"] is True


def assert_answer_hidden(at):
    healthy(at)
    assert at.session_state["card_revealed"] is False
    assert any(button.label == "Reveal answer" for button in at.button)
    assert not any(button.key == "rate_good" for button in at.button)
    assert not any('class="flashcard-back"' in item.value for item in at.markdown)


def test_due_cards_precede_new_cards_using_absolute_time_and_unique_counts():
    now = datetime(2026, 9, 20, 12, tzinfo=timezone.utc)
    ids = ["new", "scheduled", "later", "equal", "earlier", "new"]
    cards = [{"id": cid, "front": cid, "back": "Answer " + cid} for cid in ids]
    # Lexical timestamp ordering would put 09:00 before 12:30, although the
    # offsets make the 12:30 item due half an hour earlier in absolute time.
    due = {
        "earlier": "2026-09-20T12:30:00+02:00",
        "later": "2026-09-20T09:00:00-02:00",
        "equal": "2026-09-20T12:00:00Z",
        "scheduled": "2026-09-20T12:01:00+00:00",
        "outside-this-selection": "2026-09-19T00:00:00Z",
    }
    reviews = {
        cid: {
            "rating": "good", "last_reviewed": "2026-09-17T12:00:00Z",
            "due": timestamp, "interval_days": 3, "count": 1,
        }
        for cid, timestamp in due.items()
    }
    queue, stats = review_queue(cards, reviews, now)
    assert [card["id"] for card in queue] == ["earlier", "later", "equal", "new"]
    assert stats == {"new": 1, "due": 3, "scheduled": 1, "reviewed": 4, "total": 5}

    queue, early_stats = review_queue(cards, reviews, now, include_scheduled=True)
    assert [card["id"] for card in queue] == ["earlier", "later", "equal", "new", "scheduled"]
    assert early_stats == stats
    assert len(cards) == 6 and len(reviews) == 5  # Neither input was mutated.


def test_empty_selection_does_not_count_reviews_from_other_decks():
    queue, stats = review_queue([], {"unrelated": {"due": "2026-01-01T00:00:00Z"}},
                                datetime(2026, 9, 20, tzinfo=timezone.utc))
    assert queue == []
    assert stats == {"new": 0, "due": 0, "scheduled": 0, "reviewed": 0, "total": 0}


def test_chapter_launch_resets_incompatible_filters_and_opens_its_own_cards():
    course = next(course for course in load_courses() if course["id"] == "DCCA")
    chapter = course["lessons"][0]
    at = app(
        "Courses", academy_course="DCCA", academy_view="Study",
        card_collection="Orientation overviews", card_domain="cooling",
        card_cert="GICSP", card_depth="Foundation", card_completed=True,
        card_chapter="DC-01", review_early=True,
    )
    at.button(key="academy_flashcards_" + chapter["id"]).click().run()
    healthy(at)
    assert at.session_state["page"] == "Flashcards"
    assert at.radio(key="card_collection").value == "Courses"
    assert at.selectbox(key="card_cert").value == "DCCA"
    assert at.selectbox(key="card_chapter").value == chapter["id"]
    assert at.selectbox(key="card_domain").value == "All subjects"
    assert at.selectbox(key="card_depth").value == "All levels"
    assert at.checkbox(key="card_completed").value is False
    assert at.checkbox(key="review_early").value is False
    assert at.session_state["active_card"] in {card["id"] for card in chapter["cards"]}
    assert_answer_hidden(at)
    assert at.session_state["progress"] == default_progress()


def test_removing_a_revealed_active_card_from_due_queue_hides_the_next_answer():
    at = app()
    first = at.session_state["active_card"]
    reveal(at)
    # Represents a restored or cross-tab progress record arriving while a
    # revealed card is on screen, without changing any selection widgets.
    at.session_state["progress"] = record_review(
        at.session_state["progress"], first, "good", "2090-01-01T12:00:00Z"
    )
    at.run()
    assert at.session_state["active_card"] != first
    assert_answer_hidden(at)


def test_turning_off_early_review_cannot_reveal_a_different_cards_answer():
    at = app()
    scheduled = at.session_state["active_card"]
    at.session_state["progress"] = record_review(
        at.session_state["progress"], scheduled, "good", "2090-01-01T12:00:00Z"
    )
    at.checkbox(key="review_early").check().run()
    healthy(at)
    at.session_state["active_card"] = scheduled
    at.session_state["card_revealed"] = False
    at.run()
    reveal(at)
    assert at.session_state["active_card"] == scheduled
    at.checkbox(key="review_early").uncheck().run()
    assert at.session_state["active_card"] != scheduled
    assert_answer_hidden(at)


def test_rating_is_saved_and_restored_without_anki_or_quiz_credit():
    at = app()
    first = at.session_state["active_card"]
    reveal(at)
    at.button(key="rate_good").click().run()
    healthy(at)
    saved = at.session_state["progress"]
    review = saved["reviews"][first]
    assert review["rating"] == "good" and review["count"] == 1
    assert review["interval_days"] == 3
    assert datetime.fromisoformat(review["due"]) > datetime.fromisoformat(review["last_reviewed"])
    assert saved["completed"] == [] and saved["attempts"] == []
    assert saved["credentials"] == [] and saved["evidence"] == []
    assert_answer_hidden(at)

    backup = json.dumps(saved)
    restored = app(progress=normalize_progress(backup))
    assert restored.session_state["progress"]["reviews"][first] == review
    assert restored.session_state["active_card"] != first
    assert_answer_hidden(restored)
