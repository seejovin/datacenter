"""Programme integrity and practical/knowledge boundary checks."""
import copy
import importlib.util
import json
from pathlib import Path

import pytest

from core.engine import default_progress, load_lessons
from core.programme import (EXPECTED_OUTCOMES, evidence_packet, load_programme,
                            outcome_rows, study_sequence, validate_programme)

ROOT = Path(__file__).resolve().parents[1]


def test_every_mandatory_outcome_keeps_teaching_practice_and_source_links():
    programme, lessons = load_programme(), load_lessons()
    validate_programme(programme, lessons)
    assert {item['id'] for item in programme['outcomes']} == EXPECTED_OUTCOMES
    assert {str(item['id']) for item in programme['course_register']} == {str(i) for i in range(1,66)} | {'03A','03B','03C','07A'}
    assert len(programme['practical_cases']) == 16
    assert {item['id'] for item in programme['releases']} == set(range(6))
    assert len(programme['lifecycle']) == 9
    by_id = {lesson['id']:lesson for lesson in lessons}
    for outcome in programme['outcomes']:
        assert any(by_id[lid].get('practical_assignment') for lid in outcome['lesson_ids'])
        assert any(by_id[lid].get('teaching_resources') for lid in outcome['lesson_ids'])


def test_overview_sequence_preserves_prerequisites_and_target_stages():
    lessons = load_lessons()
    sequence = study_sequence(lessons)
    emitted = set()
    for lesson in sequence:
        assert set(lesson['prerequisites']) <= emitted
        emitted.add(lesson['id'])
    assert len(emitted) == len(lessons)
    assert {lesson['level'] for lesson in sequence} == {'Foundation','Applied','Advanced'}


def test_even_completed_study_and_review_claims_do_not_auto_accept_outcomes():
    lessons, programme = load_lessons(), load_programme()
    progress = default_progress()
    progress['completed'] = [lesson['id'] for lesson in lessons]
    # Imported review status remains a claim, not authenticated independent review.
    progress['evidence'] = [{'lesson_id':'L-NET-01','review_status':'reviewed','environment':'production'}]
    rows = outcome_rows(programme, lessons, progress)
    assert all(row['Practical acceptance']=='External review required' for row in rows)
    assert next(row for row in rows if row['Outcome']=='NET-01')['Related evidence notes']==1
    assert progress['credentials']==[]
    packet = evidence_packet(programme['outcomes'][0])
    assert 'UNPERFORMED / UNREVIEWED' in packet
    assert 'Independent reviewer' in packet


def test_unresolved_links_and_removed_requirements_cannot_pass_validation():
    lessons, programme = load_lessons(), load_programme()
    bad = copy.deepcopy(programme)
    bad['outcomes'].pop()
    with pytest.raises(ValueError,match='40 engineering'):
        validate_programme(bad, lessons)
    bad = copy.deepcopy(programme)
    bad['outcomes'][0]['lesson_ids'] = ['missing-lesson']
    with pytest.raises(ValueError,match='unresolved lesson'):
        validate_programme(bad, lessons)


def test_new_question_objectives_and_assignment_fields_are_consistent():
    for lesson in load_lessons():
        if not lesson['id'].startswith('L-'):
            continue
        assert all(question['objective'] in lesson['objectives'] for question in lesson['questions']), lesson['id']
        task = lesson['practical_assignment']
        assert all(task.get(field) for field in ['environment','brief','steps','deliverables','acceptance_criteria','limitations']), lesson['id']


def load_lab_checker():
    spec = importlib.util.spec_from_file_location('lab_checker', ROOT/'labs/check_submission.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.mark.parametrize('lab', ['network','hardware','controls','security'])
def test_synthetic_lab_feedback_rejects_empty_submissions_and_accepts_worked_conclusions(lab):
    module = load_lab_checker()
    templates = json.loads((ROOT/'labs/submission_templates.json').read_text())
    assert not all(module.assess(lab,templates[lab]).values())
    assert all(module.assess(lab,module.EXPECTED[lab]).values())
    wrong = copy.deepcopy(module.EXPECTED[lab])
    if lab=='network':
        wrong['accepted'].append('R1')
        assert not module.assess(lab,wrong)['accepted']
    if lab=='controls':
        wrong['initial_freshness_accepted']=0
        assert not module.assess(lab,wrong)['initial_freshness_accepted']
    if lab=='security':
        wrong['chronological_event_ids'].reverse()
        assert not module.assess(lab,wrong)['chronological_event_ids']


def test_all_overview_checkpoints_cannot_complete_teaching_assessment_or_courses():
    lessons, programme = load_lessons(), load_programme()
    before = default_progress()
    after = copy.deepcopy(before)
    after["completed"] = [lesson["id"] for lesson in lessons]
    pristine = copy.deepcopy(after)
    open_rows = outcome_rows(programme, lessons, before)
    done_rows = outcome_rows(programme, lessons, after)
    for initial, completed in zip(open_rows, done_rows):
        for field in ("Requirement mapping", "Detailed teaching", "Assessment coverage",
                      "Course completion", "Practical acceptance"):
            assert completed[field] == initial[field]
        assert completed["Requirement mapping"] == "Mapped"
        assert completed["Detailed teaching"] == "Not established by overview links"
        assert completed["Assessment coverage"] == "Overview checks only; incomplete"
        assert completed["Course completion"] == "Not established"
        assert completed["Overview checkpoints"].split(" / ")[0] == completed["Overview checkpoints"].split(" / ")[1]
        assert "Study checkpoints" not in completed
        assert "Depth" not in completed
    assert after == pristine
    assert programme["delivery_status"]["kind"] == "authored_course_programme"


def test_advanced_tag_and_many_links_do_not_establish_instructional_coverage():
    lessons, programme = load_lessons(), load_programme()
    changed = copy.deepcopy(lessons)
    for lesson in changed:
        lesson["level"] = "Advanced"
    expanded = copy.deepcopy(programme)
    expanded["outcomes"][0]["lesson_ids"] = [lesson["id"] for lesson in changed]
    row = outcome_rows(expanded, changed, default_progress())[0]
    assert row["Target topic stages"] == "Advanced"
    assert row["Detailed teaching"] == "Not established by overview links"
    assert row["Assessment coverage"] == "Overview checks only; incomplete"
    assert row["Course completion"] == "Not established"
