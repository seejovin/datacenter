/**
 * Browser-component protocol regression tests, requiring only Node.js.
 * Run from the repository root: node tests/device_store_test.mjs
 *
 * The VM supplies parent postMessage, localStorage and browser events. This
 * checks protocol/data-integrity behavior; it does not replace live browser QA.
 */
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import vm from "node:vm";

const componentPath = new URL("../components/device_store/index.html", import.meta.url);
const html = readFileSync(componentPath, "utf8");
const match = html.match(/<script>([\s\S]*?)<\/script>/);
assert.ok(match, "Component must contain its inline JavaScript.");
const script = match[1];
const KEY = "datacenter.learning.v1";

function progress(revision = 0, completed = []) {
  return {schema_version: 1, revision, completed, attempts: [], reviews: {}, evidence: [], credentials: []};
}

function browser(initial = null, {storageBlocked = false} = {}) {
  let stored = initial;
  let writes = 0;
  const listeners = new Map();
  const messages = [];
  const parent = {postMessage(message) { messages.push(message); }};
  const window = {
    parent,
    localStorage: {
      getItem(key) {
        assert.equal(key, KEY);
        if (storageBlocked) throw new Error("Storage blocked by browser policy.");
        return stored;
      },
      setItem(key, value) {
        assert.equal(key, KEY);
        if (storageBlocked) throw new Error("Storage blocked by browser policy.");
        stored = value;
        writes += 1;
      },
    },
    addEventListener(type, listener) { listeners.set(type, listener); },
  };
  vm.runInNewContext(script, {window, TextEncoder, Uint8Array, Blob, Response, CompressionStream, DecompressionStream, btoa, atob}, {filename: componentPath.pathname});
  return {
    render(outgoing = null, restoreToken = null) {
      return listeners.get("message")({source: parent, data: {
        type: "streamlit:render", args: {outgoing, restore_token: restoreToken},
      }});
    },
    external(value, {clearAll = false} = {}) {
      stored = value;
      return listeners.get("storage")({key: clearAll ? null : KEY, newValue: value});
    },
    get latest() {
      const value = messages.filter(item => item.type === "streamlit:setComponentValue").at(-1)?.value;
      return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
    },
    get valueMessages() {
      return messages.filter(item => item.type === "streamlit:setComponentValue").length;
    },
    get stored() { return stored; },
    get writes() { return writes; },
  };
}

let passed = 0;
async function test(name, callback) {
  await callback();
  passed += 1;
  console.log(`PASS ${name}`);
}

await test("initial hydration reads saved progress before accepting any write", async () => {
  const saved = progress(7, ["DC-01", "DC-02"]);
  const tab = browser(JSON.stringify(saved));
  await tab.render(progress());
  assert.equal(tab.writes, 0);
  assert.equal(tab.latest.ready, true);
  assert.equal(tab.latest.saved_revision, 7);
  assert.deepEqual(tab.latest.progress, saved);
  assert.deepEqual(JSON.parse(tab.stored), saved);
});

await test("new state is acknowledged and identical reruns cannot loop", async () => {
  const tab = browser();
  await tab.render();
  assert.equal(tab.stored, null);
  await tab.render(progress());
  assert.equal(tab.latest.saved_revision, 0);
  assert.equal(tab.writes, 1);
  const emitted = tab.valueMessages;
  for (let i = 0; i < 5; i += 1) await tab.render(progress());
  assert.equal(tab.valueMessages, emitted);
  assert.equal(tab.writes, 1);
  await tab.render(progress(1, ["DC-01"]));
  assert.equal(tab.latest.saved_revision, 1);
  assert.equal(tab.valueMessages, emitted + 1);
});

await test("a fresh component restores progress after a page reload", async () => {
  const first = browser();
  await first.render();
  await first.render(progress(4, ["DC-01", "DC-02"]));
  const reloaded = browser(first.stored);
  await reloaded.render();
  assert.equal(reloaded.writes, 0);
  assert.equal(reloaded.latest.saved_revision, 4);
  assert.deepEqual(reloaded.latest.progress.completed, ["DC-01", "DC-02"]);
});

await test("another tab's change blocks stale writes even with a larger local revision", async () => {
  const tab = browser(JSON.stringify(progress(1, ["DC-01"])));
  await tab.render();
  const other = progress(2, ["DC-01", "DC-02"]);
  await tab.external(JSON.stringify(other));
  await tab.render(progress(3, ["DC-01", "DC-03"]));
  assert.equal(tab.latest.external_change, true);
  assert.equal(tab.writes, 0);
  assert.deepEqual(JSON.parse(tab.stored), other);
  await tab.render(other); // Explicit UI hydration acknowledges the other tab.
  assert.equal(tab.latest.external_change, false);
  await tab.render(progress(3, ["DC-01", "DC-02", "DC-03"]));
  assert.equal(tab.latest.saved_revision, 3);
  assert.equal(tab.writes, 1);
});

await test("equal-revision conflicting contents cannot silently replace stored state", async () => {
  const saved = progress(2, ["DC-01"]);
  const tab = browser(JSON.stringify(saved));
  await tab.render();
  await tab.render(progress(2, ["DC-02"]));
  assert.equal(tab.latest.external_change, true);
  assert.equal(tab.writes, 0);
  assert.deepEqual(JSON.parse(tab.stored), saved);
});

await test("state equality does not depend on JSON key order", async () => {
  const saved = progress(2, ["DC-01"]);
  const tab = browser(JSON.stringify(saved));
  await tab.render();
  const reordered = {
    credentials: [], evidence: [], reviews: {}, attempts: [],
    completed: ["DC-01"], revision: 2, schema_version: 1,
  };
  await tab.render(reordered);
  assert.equal(tab.latest.external_change, false);
  assert.equal(tab.latest.saved_revision, 2);
  assert.equal(tab.writes, 0);
});

await test("clearing site storage in another tab requires accepting the empty state", async () => {
  const tab = browser(JSON.stringify(progress(3, ["DC-01"])));
  await tab.render();
  await tab.external(null, {clearAll: true});
  await tab.render(progress(4, ["DC-01", "DC-02"]));
  assert.equal(tab.latest.external_change, true);
  assert.equal(tab.stored, null);
  await tab.render(progress()); // UI explicitly accepts the other tab's cleared state.
  assert.equal(tab.latest.external_change, false);
  assert.equal(tab.latest.saved_revision, 0);
  assert.deepEqual(JSON.parse(tab.stored), progress());
});

await test("corrupt storage is preserved until an explicit validated restore", async () => {
  const tab = browser("{corrupt-json");
  await tab.render();
  assert.match(tab.latest.error, /unavailable/);
  await tab.render(progress());
  assert.equal(tab.stored, "{corrupt-json");
  assert.equal(tab.writes, 0);
  await tab.render(progress(1, ["DC-01"]), "user-requested-import-1");
  assert.equal(tab.latest.error, null);
  assert.equal(tab.latest.saved_revision, 1);
  assert.equal(tab.writes, 1);
  assert.deepEqual(JSON.parse(tab.stored), progress(1, ["DC-01"]));
});

await test("a restore token authorizes one replacement rather than subsequent stale writes", async () => {
  const tab = browser(JSON.stringify(progress(5, ["DC-01"])));
  await tab.render();
  await tab.render(progress(1, ["DC-02"]), "explicit-restore");
  assert.equal(tab.latest.saved_revision, 1);
  await tab.external(JSON.stringify(progress(2, ["DC-02", "DC-03"])));
  await tab.render(progress(1, ["DC-02"]), "explicit-restore");
  assert.equal(tab.latest.external_change, true);
  assert.equal(tab.writes, 1);
  assert.equal(JSON.parse(tab.stored).revision, 2);
});

await test("consuming a restore token after acknowledgement protects component remounts", async () => {
  const first = browser();
  await first.render();
  await first.render(progress(1, ["DC-01"]), "explicit-restore");
  assert.equal(first.latest.saved_revision, 1);
  // Python consumes its restore_token after the matching acknowledgement.
  const current = progress(2, ["DC-01", "DC-02"]);
  const remounted = browser(JSON.stringify(current));
  await remounted.render(progress(1, ["DC-01"]), null);
  await remounted.render(progress(1, ["DC-01"]), null);
  assert.equal(remounted.latest.external_change, true);
  assert.equal(remounted.writes, 0);
  assert.deepEqual(JSON.parse(remounted.stored), current);
});

await test("blocked localStorage surfaces an error and never claims a saved revision", async () => {
  const tab = browser(null, {storageBlocked: true});
  await tab.render();
  assert.equal(tab.latest.ready, true);
  assert.equal(tab.latest.saved_revision, null);
  assert.match(tab.latest.error, /blocked/i);
  await tab.render(progress(1, ["DC-01"]));
  assert.equal(tab.writes, 0);
  assert.equal(tab.latest.saved_revision, null);
});

await test("large course histories compress and survive a fresh component", async () => {
  const large = progress(44);
  large.attempts = Array.from({length: 1600}, (_, i) => ({id: "attempt-"+i, data: "repeated educational result " .repeat(120)}));
  const tab = browser();
  await tab.render();
  await tab.render(large);
  assert.match(tab.stored, /^dc-gzip-v1:/);
  assert.ok(tab.stored.length < JSON.stringify(large).length / 10);
  const reload = browser(tab.stored);
  await reload.render();
  assert.deepEqual(reload.latest.progress, large);
});

await test("corrupt compressed history is preserved until explicit restore", async () => {
  const tab = browser("dc-gzip-v1:not-gzip");
  await tab.render();
  assert.match(tab.latest.error, /unavailable/);
  await tab.render(progress(1));
  assert.equal(tab.writes, 0);
  await tab.render(progress(2), "restore-corrupt-gzip");
  assert.equal(tab.latest.saved_revision, 2);
});
console.log(`\n${passed} browser storage protocol checks passed.`);
