"""Study, evidence and practice behaviour through real Streamlit widgets."""
import json
from pathlib import Path
from streamlit.testing.v1 import AppTest
from core.academy import CREDENTIAL_IDS, capability_course_rows, load_courses, validate_courses
from core.programme import load_programme

ROOT=Path(__file__).resolve().parents[1]


def healthy(at):
    assert not at.exception, '\n'.join(str(e.message) for e in at.exception)


def label(elements,text):
    found=[e for e in elements if e.label==text]
    assert len(found)==1,(text,len(found))
    return found[0]


def app(cid='DCCA',view='Study'):
    at=AppTest.from_file(str(ROOT/'app.py'),default_timeout=30)
    at.session_state['_test_mode']=True
    at.session_state['page']='Courses'
    at.session_state['academy_course']=cid
    at.session_state['academy_view']=view
    at.run();healthy(at)
    return at


def answer(at,key,qs,wrong=None):
    attempt=at.session_state[key+'_attempt']
    for q in qs:
        chosen=q['correct']
        if q['id']==wrong:
            chosen=list(reversed(chosen)) if q['type']=='order' else [next(i for i in range(len(q['options'])) if i not in chosen)]
        widget_key=attempt+'_'+q['id']
        if q['type'] in ('order','multi'):
            at.multiselect(key=widget_key).set_value(chosen)
        else:
            at.radio(key=widget_key).set_value(chosen[0])
    label(at.button,'Submit answers').click().run();healthy(at)


def test_release_meets_bank_requirements_and_all_curriculum_outcomes_have_authored_support():
    cs=load_courses();validate_courses(cs,release=True)
    counts={c['id']:len(c['questions']) for c in cs}
    assert all(counts[cid]>=500 for cid in CREDENTIAL_IDS)
    assert counts['CCNP-DC']>=1000
    rows=capability_course_rows(load_programme(),cs)
    assert len(rows)==48
    assert all(r['Supporting chapters'] and r['Supporting distinct questions'] for r in rows)


def test_course_checkpoint_requires_all_questions_and_reading_without_granting_credentials():
    course=next(c for c in load_courses() if c['id']=='DCCA')
    chapter=course['lessons'][0];lid=chapter['id']
    qs=[q for q in course['questions'] if lid in q['lesson_ids']]
    assert len(qs)<=20 # This selected chapter fits in one displayed set.
    at=app();key=f'academy_chapter_{lid}_1'
    assert at.button(key='academy_complete_'+lid).disabled
    label(at.button,'Submit answers').click().run()
    assert any('Answer each question' in x.value for x in at.warning)
    answer(at,key,qs)
    assert at.button(key='academy_complete_'+lid).disabled
    at.checkbox(key='academy_read_'+lid).check().run()
    assert not at.button(key='academy_complete_'+lid).disabled
    at.button(key='academy_complete_'+lid).click().run();healthy(at)
    assert at.session_state['progress']['completed']==[lid]
    assert at.session_state['progress']['credentials']==[]
    assert at.session_state['progress']['evidence']==[]
    assert len(at.session_state['progress']['attempts'])==1
    at.run();assert len(at.session_state['progress']['attempts'])==1
    at.radio(key='academy_view').set_value('Diagnostics').run();healthy(at)
    assert any(x.value==f'{len(qs):,} / {len(course["questions"]):,}' for x in at.metric)


def test_mixed_question_types_keep_sequence_order_and_latest_wrong_items_for_remediation():
    course=next(c for c in load_courses() if c['id']=='GICSP')
    qs=[next(q for q in course['questions'] if q['type']==t) for t in ['single','multi','order']]
    at=app('GICSP','Practice')
    key='regression_mixed_practice'
    at.session_state['academy_practice_GICSP']={'ids':[q['id'] for q in qs],'key':key,'label':'Mixed-type check'}
    at.run();healthy(at)
    answer(at,key,qs,wrong=qs[2]['id'])
    result=at.session_state['progress']['attempts'][-1]
    assert result['score']==2 and result['total']==3
    assert result['answers'][qs[2]['id']]==list(reversed(qs[2]['correct']))
    label(at.button,'Choose another practice set').click().run()
    at.selectbox(key='ps_GICSP').set_value('Previously incorrect').run()
    at.button(key='start_GICSP').click().run();healthy(at)
    active=at.session_state['academy_practice_GICSP']
    assert active['ids']==[qs[2]['id']]
    answer(at,active['key'],[qs[2]])
    assert at.session_state['progress']['attempts'][-1]['score']==1
    assert at.session_state['progress']['completed']==[]


def test_curriculum_course_link_opens_the_actual_chapter():
    at=app()
    at.radio(key='page').set_value('Programme').run()
    at.radio(key='programme_view').set_value('Outcome coverage').run();healthy(at)
    cs=load_courses();oid='NET-01'
    course=next(c for c in cs if any(oid in o['capability_ids'] for o in c['objectives']))
    obj=next(o for o in course['objectives'] if oid in o['capability_ids'])
    lid=obj['lesson_ids'][0]
    at.button(key='coverage_'+oid+lid).click().run();healthy(at)
    assert at.session_state['page']=='Courses'
    assert at.session_state['academy_course']==course['id']
    assert any(lid in x.value for x in at.caption)
    assert at.session_state['progress']['completed']==[]


def test_isa_expert_bank_keeps_provider_milestone_distinction():
    at=app('ISA-EXPERT','Diagnostics')
    assert any('not an additional ISA examination' in x.value for x in at.info)
    assert at.session_state['progress']['credentials']==[]
