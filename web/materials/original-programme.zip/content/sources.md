# Certificate maps and scenario sources

Reviewed 19 September 2026. Public provider pages establish broad programme topics and requirements. The topic groups are navigation summaries, not an objective-by-objective audit or a reproduction of proprietary teaching. All teaching, questions and scenario data in this release are original. No actual examination questions are used.

## Coverage convention

- **Foundation path available**: the app's original introductory route is available. This does not assert full examination readiness.
- **Overview links; detailed course teaching incomplete**: short introductory explanations exist, including overviews of advanced topics. They do not deliver the required professional or expert instruction, demonstrations or assessment breadth. Missing work includes theoretical teaching, not only external labs or experience.
- **Planned**: no credential-level learning or assessment is claimed.
- Topic status **Partial** means a related overview exists; it establishes no proportion of required detailed instruction. Source links and lesson mappings are not authored course content. **Planned** means teaching remains to be built.
- Provider credential awards, experience requirements, prerequisites and official examinations are independent of app progress.
- The certificate sequence is the user's study sequence. It is not a claim that each certificate is a formal prerequisite for the next.

## Official sources

| Path | Primary page | Use in this release |
|---|---|---|
| DCCA | [Schneider Electric University](https://www.se.com/ww/en/about-us/university/) | Seven publicly stated physical-infrastructure areas; exact provider-course/exam alignment remains unverified. |
| IC32 | [ISA IC32](https://www.isa.org/training/course-description/ic32) | Broad course structure and Fundamentals Specialist route. |
| CDCP | [EPI CDCP](https://www.epi-ap.com/services/1/3/4) | Public facility-topic breadth; site/building subjects retained as exam/interface knowledge. |
| CDFOS | [EPI CDFOS](https://www.epi-ap.com/services/1/3/136) | Operations-topic breadth and recommended preparation. |
| CCNP Data Center | [Cisco CCNP Data Center](https://www.cisco.com/site/us/en/learn/training-certifications/certifications/datacenter/ccnp-data-center/index.html) | Core-plus-concentration structure; no concentration silently selected. |
| GICSP | [GIAC GICSP](https://www.giac.org/certifications/global-industrial-cyber-security-professional-gicsp/) | Public objective families; full objective and practical coverage remains open. |
| GRID | [GIAC GRID](https://www.giac.org/certifications/response-industrial-defense-grid/) | Visibility, detection, investigation and response objective families. |
| CISSP | [ISC2 CISSP outline](https://www.isc2.org/certifications/cissp/cissp-certification-exam-outline) | All eight domains retained; credential and exam passage remain distinct. |
| CDCS | [EPI CDCS](https://www.epi-ap.com/services/1/3/5) | Advanced facility-study breadth and building interfaces. |
| IC33 | [ISA IC33](https://www.isa.org/training/course-description/ic33) | Risk-assessment route and Fundamentals Specialist prerequisite. |
| IC34 | [ISA IC34](https://www.isa.org/training/course-description/ic34) | Design and acceptance route and prerequisite. |
| IC37 | [ISA IC37](https://www.isa.org/training/course-description/ic37) | Maintenance and recovery route and prerequisite. |
| ISA Expert milestone | [ISA certificate programme](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program) | Automatic provider award after earning all four constituent certificates; no separate exam path. |
| CCIE Data Center | [Cisco CCIE Data Center](https://www.cisco.com/site/us/en/learn/training-certifications/certifications/datacenter/ccie-data-center/index.html) | Separate expert teaching and practical preparation required; current overview filters do not implement this course. |

## Engineering and evidence basis

The supplied Programme Charter Rev 3.5, Curriculum — Data Center Rev 14, and Portfolio Architecture and Evidence Plan v2.5 establish the programme scope and evidence distinctions. Their contents were inspected from the supplied local copies. These documents are not embedded in the public app.

Near-term owned engineering scope is D4–D7; power and cooling foundations support integration. Long-term D2–D7 adds power and cooling engineering. D1 civil, structural and architectural engineering is excluded from both owned targets. Explanations of building interfaces and examination topics do not change that boundary.

The cases correspond to the portfolio's measurement assurance, maintenance under reduced redundancy, control-chain verification, management-plane security and trusted-recovery work packages. Each case is an original **synthetic decision exercise**. Values, times, thresholds, capacities, device addresses, logs and incidents are fictional. Passing a case provides evidence of answers given to that exercise, not of physical work, commissioning, field operation or production capability.

[NIST SP 800-82 Rev. 3, Guide to Operational Technology (OT) Security, final](https://csrc.nist.gov/pubs/sp/800/82/r3/final) is the supporting public OT-security reference for the programme. Any later draft is a separate source and is not silently substituted for a final publication.

## Before expanding a certificate path

Record the official blueprint/course version and effective date, map every objective, identify prerequisites, add original teaching and assessments, validate each practical outcome at its declared evidence level, and independently review coverage. Until that work is complete, keep the path visibly partial. Provider policies and exam versions must be rechecked before making registration or readiness recommendations.
