#!/usr/bin/env python3
"""Offline synthetic IC33 analytical lab. No sockets, subprocesses or vendor access."""
import argparse
import copy
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def version(value):
    parts = str(value).split('.')
    if not parts or any(not p.isdigit() for p in parts):
        raise ValueError('Version must contain numeric dotted components for this synthetic product.')
    return tuple(int(p) for p in parts)


def first_match(rules, source, destination, protocol, port):
    for rule in rules:
        if (rule['source'] in (source, 'any') and rule['destination'] in (destination, 'any')
                and rule['protocol'] in (protocol, 'any') and rule['port'] in (port, 'any')):
            return rule['id'], rule['action']
    return None, 'deny'


def paths(edges, source, destination):
    adjacency = {}
    for a, b in edges:
        adjacency.setdefault(a, set()).add(b)
    found = []
    def walk(node, trail):
        if node == destination:
            found.append(trail)
            return
        for nxt in sorted(adjacency.get(node, ())):
            if nxt not in trail:
                walk(nxt, trail + [nxt])
    walk(source, [source])
    return found


def recovery_minutes(tasks):
    cache, active = {}, set()
    def finish(name):
        if name in cache:
            return cache[name]
        if name in active:
            raise ValueError('Recovery dependency cycle')
        if name not in tasks:
            raise ValueError('Unknown recovery prerequisite: ' + name)
        task = tasks[name]
        duration = task['minutes']
        if isinstance(duration, bool) or not isinstance(duration, (int, float)) or duration < 0:
            raise ValueError('Recovery duration must be a nonnegative number')
        active.add(name)
        value = duration + max((finish(p) for p in task['after']), default=0)
        active.remove(name)
        cache[name] = value
        return value
    return max((finish(name) for name in tasks), default=0)


def applicability(asset, advisory):
    if asset['component_version'] is None:
        return 'unknown_version'
    v = version(asset['component_version'])
    if v >= version(advisory['fixed_from']):
        return 'fixed_branch'
    if asset.get('verified_hotfix') == advisory['hotfix'] and v == version(advisory['hotfix_base']):
        return 'fixed_hotfix'
    affected = version(advisory['affected_from']) <= v <= version(advisory['affected_through'])
    if not affected:
        return 'outside_stated_range'
    feature = asset.get('remote_write')
    if feature is None:
        return 'feature_unknown'
    return 'affected_enabled' if feature else 'affected_feature_disabled'


def expected(case):
    answers = {}
    answers['advisory_status'] = {a['id']: applicability(a, case['advisory']) for a in case['assets']}
    answers['flow_results'] = {f['id']: {'rule': first_match(case['rules'], f['source'], f['destination'], f['protocol'], f['port'])[0], 'action': first_match(case['rules'], f['source'], f['destination'], f['protocol'], f['port'])[1]} for f in case['flows']}
    answers['bypass_paths'] = [p for p in paths(case['edges'], 'Vendor', 'Controller') if 'R' not in p]
    answers['recovery_minutes'] = recovery_minutes(case['recovery_tasks'])
    answers['rto_margin_minutes'] = case['rto_minutes'] - answers['recovery_minutes']
    answers['rpo_excess_minutes'] = max(0, case['backup_age_minutes'] - case['rpo_minutes'])
    probability = 1.0
    for p in case['conditional_probabilities']:
        if not 0 <= p <= 1:
            raise ValueError('Probabilities must be in [0, 1]')
        probability *= p
    answers['illustrative_joint_probability'] = round(probability, 9)
    answers['expected_annual_loss'] = sum(x['probability'] * x['loss'] for x in case['exclusive_outcomes'])
    # These are explicit case facts to interpret, not inferred from traffic volume.
    answers['port_rule_proves_read_only'] = False
    answers['training_proves_path_coverage'] = False
    answers['backup_with_shared_admin_is_independent'] = False
    answers['required_unresolved_evidence'] = sorted(['active_session_revocation', 'command_function_enforcement', 'independent_recovery_access', 'physical_process_consequence_validation'])
    return answers


def check(submission, case):
    failures = []
    wanted = expected(case)
    for key, value in wanted.items():
        got = submission.get(key)
        if key == 'bypass_paths' and isinstance(got, list):
            got = sorted(got)
            value = sorted(value)
        if key == 'required_unresolved_evidence' and isinstance(got, list):
            got = sorted(got)
        if isinstance(value, float) and isinstance(got, (int, float)) and not isinstance(got, bool):
            good = abs(got - value) < 1e-8
        else:
            good = type(got) is type(value) and got == value
        if not good:
            failures.append(key + ': submitted analysis does not match the supplied evidence/model.')
    for key in ('assumptions', 'limitations', 'treatment_acceptance_criteria'):
        entries = submission.get(key)
        if not isinstance(entries, list) or len(entries) < 3 or any(not isinstance(x, str) or len(x.split()) < 8 for x in entries):
            failures.append(key + ': provide at least three specific reasoned statements (eight or more words each).')
    return failures


def selftest():
    import unittest
    class Tests(unittest.TestCase):
        def test_version_order(self): self.assertGreater(version('2.10'), version('2.9'))
        def test_bad_version(self):
            with self.assertRaises(ValueError): version('2.x')
        def test_shadow(self):
            r=[{'id':'broad','source':'J','destination':'C','protocol':'TCP','port':'any','action':'allow'}, {'id':'specific','source':'J','destination':'C','protocol':'TCP','port':502,'action':'deny'}]
            self.assertEqual(first_match(r,'J','C','TCP',502),('broad','allow'))
        def test_implicit_deny(self): self.assertEqual(first_match([], 'A','B','TCP',502),(None,'deny'))
        def test_paths_cycle(self): self.assertEqual(paths([['A','B'],['B','A'],['B','C']],'A','C'),[['A','B','C']])
        def test_parallel_recovery(self): self.assertEqual(recovery_minutes({'a':{'minutes':5,'after':[]},'b':{'minutes':7,'after':[]},'c':{'minutes':3,'after':['a','b']}}),10)
        def test_recovery_cycle(self):
            with self.assertRaises(ValueError): recovery_minutes({'a':{'minutes':1,'after':['a']}})
        def test_negative_duration(self):
            with self.assertRaises(ValueError): recovery_minutes({'a':{'minutes':-1,'after':[]}})
        def test_hotfix_scope(self):
            a={'affected_from':'2.7','affected_through':'2.9','fixed_from':'2.10','hotfix':'HF-21','hotfix_base':'2.8'}
            self.assertEqual(applicability({'component_version':'2.8','verified_hotfix':'HF-21','remote_write':True},a),'fixed_hotfix')
            self.assertEqual(applicability({'component_version':'2.9','verified_hotfix':'HF-21','remote_write':True},a),'affected_enabled')
        def test_unknown_feature(self):
            a={'affected_from':'2.7','affected_through':'2.9','fixed_from':'2.10','hotfix':'HF-21','hotfix_base':'2.8'}
            self.assertEqual(applicability({'component_version':'2.8','remote_write':None},a),'feature_unknown')
        def test_solution(self):
            case=json.loads((ROOT/'scenario.json').read_text())
            self.assertEqual(check(json.loads((ROOT/'solution.json').read_text()),case),[])
        def test_flawed_starter_rejected(self):
            case=json.loads((ROOT/'scenario.json').read_text())
            self.assertGreaterEqual(len(check(json.loads((ROOT/'starter.json').read_text()),case)),10)
        def test_changed_topology_changes_answer(self):
            case=json.loads((ROOT/'scenario.json').read_text())
            case['edges']=[e for e in case['edges'] if e!=['Vendor','Cellular']]
            self.assertEqual(expected(case)['bypass_paths'],[])
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    return 0 if result.wasSuccessful() else 1


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('submission',nargs='?',help='Path to your analytical answer JSON')
    parser.add_argument('--self-test',action='store_true')
    args=parser.parse_args()
    if args.self_test:
        return selftest()
    if not args.submission:
        parser.error('Provide a submission JSON or --self-test')
    case=json.loads((ROOT/'scenario.json').read_text())
    failures=check(json.loads(Path(args.submission).read_text()),case)
    print('SYNTHETIC OFFLINE ANALYSIS — no device or network was contacted.')
    for failure in failures: print('REVIEW:',failure)
    print('Analytical checks passed.' if not failures else f'{len(failures)} analytical checks need review.')
    print('Narrative quality, process safety, standard conformance and field competence require qualified human review.')
    return 1 if failures else 0

if __name__=='__main__':
    raise SystemExit(main())
