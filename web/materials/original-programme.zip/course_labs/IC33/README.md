# IC33 independent assessment laboratory

This is an original synthetic analytical assessment. No network, controller, vendor
command, scanner or CSET instance is contacted or executed. Python 3 standard
library is sufficient. A passing result verifies selected calculations and model
interpretations only; it does not establish field competence, process safety,
ISA/IEC 62443 conformance or an ISA credential.

## Preparation and evidence

Complete the 25 IC33 chapters and their independent tasks. Each chapter supplies
its own distinct case, evidence and acceptance criteria. Retain those deliverables
in your portfolio; this integrated lab adds a machine-checkable reasoning task.

Read `scenario.json` as an evidence bundle. Its versions and advisories are
invented for the exercise. Dotted numeric versions in this synthetic product use
component-wise ordering. The firewall is first-match and has no application
inspection. Graph edges are possible directed access transitions, not proof that
any actor has compromised a device. The recovery task graph uses minutes and
requires all listed predecessors to finish. Probability inputs are sequential
conditional teaching assumptions over one year. Financial outcomes are mutually
exclusive and omit safety/environmental valuation.

## Independent work

1. Copy `starter.json` to `my_assessment.json`. The starter is deliberately wrong.
2. For A–F, classify advisory applicability using one of `fixed_branch`,
   `fixed_hotfix`, `affected_enabled`, `affected_feature_disabled`,
   `feature_unknown`, `unknown_version`, or `outside_stated_range`. Preserve
   unknown facts rather than treating them as safe or compromised.
3. Trace each supplied flow through the ordered rules. Record its first matching
   rule and action. Separately judge whether a permitted port proves read-only
   application behavior.
4. Enumerate Vendor-to-Controller paths that do not contain R. Use ordered node
   lists. Explain why a gateway's successful logins cannot prove absence of bypass.
5. Calculate the recovery critical path, RTO margin, RPO excess, illustrative joint
   scenario probability and expected annual financial loss. Keep their units and
   interpretations separate.
6. Identify the four unresolved evidence topics from the case: active-session
   revocation, command-function enforcement, independent recovery access and
   physical process consequence validation. Use the identifier spellings in the
   starter/solution field documentation or checker; explaining these in your memo
   is more important than memorizing labels.
7. Write at least three specific assumptions, limitations and treatment acceptance
   criteria in the corresponding arrays. The checker only checks that prose is
   present; a reviewer must assess technical quality.
8. Create a one-page zone/conduit proposal, a risk decision memo and six CRS
   requirements with positive, negative and degraded-state tests. Trace each to a
   scenario and name its evidence owner. These require human review.

Run from the repository root:

```bash
python course_labs/IC33/check.py course_labs/IC33/my_assessment.json
python course_labs/IC33/check.py --self-test
```

Inspect `solution.json` only after completing your analysis. It is one supported
answer to this synthetic evidence, not a production template. The helper's path
and critical-path functions can handle changed synthetic graphs; do not interpret
that flexibility as support for operating live infrastructure.

## Challenge variants

Create a separate copy of the lab before editing the evidence. Remove the cellular
edge and explain which control assumption changes. Make backup retrieval faster
than spare preparation and identify the new critical branch. Add an unaffected
version or a hotfix on the wrong base version and revisit applicability. Introduce
a recovery dependency cycle and explain why it describes an impossible procedure.
The checker rejects cycles and negative task durations rather than silently
inventing a recovery time.

For an optional CSET exercise, use the current approved release and instructions
from [CISA's official project](https://github.com/cisagov/cset) in an isolated,
authorized environment with synthetic facility data. Record release, selected
assessment scope, answer evidence and differences from the technical case. This
repository neither bundles CSET nor claims to have executed it. A questionnaire
report does not replace the technical or licensed-standard evidence gates.

## Acceptance and fidelity

A complete portfolio submission contains the corrected JSON, calculations with
units, applicability reasoning, policy/path analysis, a consequence model with
qualified-review gaps, traceable requirements, a treatment/acceptance memo and an
evidence manifest. Distinguish authored simulation from real observation. Actual
plant testing requires the owner's activity authorization, supported equipment,
qualified process/safety participation, approved change controls and recovery
arrangements. Actual ISA training and examination remain external requirements.
