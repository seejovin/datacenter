# IC37 maintenance, evidence and recovery laboratory

This standard-library Python exercise reads synthetic local JSON and prints model results. It does not connect to any equipment, execute vendor PLC code, establish a safe physical state or confer operational authorization. Versions and advisory lists are illustrative, not real product vulnerability information.

Run from the repository root:

```bash
python course_labs/IC37/lab.py report
python course_labs/IC37/lab.py self-test
```

Copy `starter.json` to your own working file, preserve the original, and select the copy using `--input path/to/copy.json`. Record predictions before executing each experiment.

## 1. Counter diagnosis and uncertain event order

Predict the error rate from the two counter observations. Repeat with a changed counter generation and explain why subtraction is then invalid. Do not repair this by blindly replacing a negative delta with zero. Change the time interval without changing the counts and distinguish rate from total.

For the events, calculate corrected intervals by hand using reported time minus known offset, with the stated residual uncertainty. Predict whether either event must precede the other. Change only one uncertainty bound and identify the smallest nonoverlap that supports a strict order. Explain why the model cannot attribute an actor or prove causation from chronology.

Deliver the calculation, output and an investigation statement that preserves original records and uncertainty. Acceptance: every order claim follows the interval relation; reset counters are explicitly rejected.

## 2. Patch and change guards

The installed package is fixed but the runtime is old, a denial test failed and standby readiness is false. Identify each independent acceptance failure. Correct one condition at a time and retain the intermediate results. Explain why an installer success, functional test or approved ticket alone does not close the campaign.

Add a disconnected spare with an unknown running version as a separate experimental input. Decide what evidence would resolve applicability in real supported tools. The model uses exact enumerated versions and cannot infer semantic version ranges or exploitability.

Deliver a target-state register, guarded execution procedure, abort condition and post-activation evidence plan. Acceptance: no unavailable prerequisite is silently passed; installed and running state remain separate; required and denied operations are both verified.

## 3. Dependency and authority reconciliation

The starter contains a bootstrap cycle: identity needs a credential whose vault needs identity. Explain the blocked set. Model a separately controlled bootstrap credential by putting `bootstrap_credential` in `available`; preserve the original graph and justify custody of that independent input. Compare the recovery waves.

A historical backup restores an obsolete supplier identity but omits a currently required recovery identity. Reconcile both excess and missing authority. The model identifies sessions requiring review; it does not terminate them or know any platform's token semantics. Add a hypothetical independent API token to your written dependency model and explain why deleting the login account may not revoke it.

Deliver a recovery graph, bootstrap custody plan, current-authority reconciliation and positive/negative acceptance tests. Acceptance: every dependency is available before its consumer, obsolete authority has an effective revocation plan, and necessary service access is retained.

## 4. Illustrative control handback

The starter denies a start because its permissive data is stale. Restore freshness and predict the transition to STARTING. Test missing feedback at the five-second limit, both feedback and flow proven, loss of a permissive while running, maintenance mode and reset from FAULT. Demonstrate that reset returns to STOPPED and does not issue a fresh start.

This small model intentionally omits sensor physics, hardware faults, electrical protection, real PLC scan scheduling, process-specific safe outputs, redundant control and detailed stopping states. Identify which omitted mechanism matters to your selected system. Extend the state model on paper before proposing supported vendor implementation.

Deliver a state-transition table, normal/fault/restart test matrix and a clear list of simulated versus physically untested claims. Acceptance: command receipt is never substituted for run/flow feedback; stale or bad-quality permissives cannot authorize starting; reset and start remain separate actions under this illustrative specification.

## Independent challenge

Combine the four exercises into one maintenance handback: a controller replacement requires a gateway update, a restored identity dependency and verification of a pump sequence. Create a defect that passes one layer's test while failing another. Supply the evidence needed to distinguish it, correct the specific cause, and state the remaining vendor and physical gates. Do not label synthetic outputs as production observations.
