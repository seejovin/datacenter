#!/usr/bin/env python3
"""Offline synthetic maintenance evidence exercises. No network/device access."""
import argparse
import copy
import json
from pathlib import Path


def counter_rate(before, after):
    if before['generation'] != after['generation']:
        return {'valid': False, 'reason': 'Counter generation changed; subtraction is not valid.'}
    elapsed = after['time_s'] - before['time_s']
    delta = after['value'] - before['value']
    if elapsed <= 0 or delta < 0:
        return {'valid': False, 'reason': 'Nonpositive interval or reset/wrap needs explicit treatment.'}
    return {'valid': True, 'delta': delta, 'interval_s': elapsed, 'rate_per_s': delta / elapsed}


def event_interval(event):
    # reported = true + known offset + remaining error
    centre = event['reported_s'] - event['offset_s']
    uncertainty = event['uncertainty_s']
    if uncertainty < 0:
        raise ValueError('Uncertainty must be nonnegative.')
    return [centre - uncertainty, centre + uncertainty]


def compare_events(a, b):
    ai, bi = event_interval(a), event_interval(b)
    order = 'A_before_B' if ai[1] < bi[0] else 'B_before_A' if bi[1] < ai[0] else 'unresolved'
    return {'A_interval_s': ai, 'B_interval_s': bi, 'supported_order': order}


def patch_gate(asset, advisory, prerequisites):
    """Illustrative exact-version advisory; not a real vulnerability version parser."""
    missing = sorted(name for name, ok in prerequisites.items() if ok is not True)
    runtime = asset.get('running_version')
    applicable = 'unknown' if runtime is None else runtime in advisory['affected_versions']
    installed_fixed = asset['installed_version'] in advisory['fixed_versions']
    verified_fixed = runtime in advisory['fixed_versions'] and asset['functional_test_pass'] and asset['denial_test_pass']
    return {'applicability': applicable, 'unmet_prerequisites': missing,
            'execution_permitted_by_model': not missing,
            'installed_fixed': installed_fixed,
            'running_remediation_verified': bool(verified_fixed),
            'activation_gap': installed_fixed and runtime != asset['installed_version']}


def recovery_plan(objects, available):
    available = set(available)
    remaining = {o['id']: set(o['requires']) for o in objects if o['id'] not in available}
    waves = []
    while remaining:
        ready = sorted(name for name, reqs in remaining.items() if reqs <= available)
        if not ready:
            return {'waves': waves, 'blocked': {n: sorted(r - available) for n, r in remaining.items()}}
        waves.append(ready)
        available.update(ready)
        for name in ready:
            del remaining[name]
    return {'waves': waves, 'blocked': {}}


def reconcile_authority(restored, approved, active_sessions):
    restored, approved = set(restored), set(approved)
    obsolete = restored - approved
    return {'remove_restored_authority': sorted(obsolete),
            'missing_required_authority': sorted(approved - restored),
            'sessions_requiring_explicit_review': sorted((s for s in active_sessions if s['identity'] in obsolete), key=lambda s: s['id'])}


def sequence_step(state, command, inputs, elapsed_s):
    """Illustrative handback model only; no safety claim or real PLC execution."""
    if state not in {'STOPPED', 'STARTING', 'RUNNING', 'FAULT'}:
        raise ValueError('Unknown state')
    permit = inputs['quality_good'] and inputs['fresh'] and inputs['permissive'] and not inputs['maintenance']
    if state == 'FAULT':
        return 'STOPPED' if command == 'RESET' and permit and not inputs['run_feedback'] else 'FAULT'
    if state in {'STARTING', 'RUNNING'} and (not permit or command == 'STOP'):
        return 'STOPPED'
    if state == 'STOPPED':
        return 'STARTING' if command == 'START' and permit else 'STOPPED'
    if state == 'STARTING':
        if inputs['run_feedback'] and inputs['flow_proven']:
            return 'RUNNING'
        return 'FAULT' if elapsed_s >= 5 else 'STARTING'
    return 'FAULT' if not (inputs['run_feedback'] and inputs['flow_proven']) else 'RUNNING'


def report(data):
    return {
        'evidence_status': 'Synthetic local model outputs; no physical or vendor execution.',
        'counter': counter_rate(data['counter_before'], data['counter_after']),
        'event_order': compare_events(*data['events']),
        'patch': patch_gate(data['asset'], data['advisory'], data['change_prerequisites']),
        'recovery': recovery_plan(data['recovery_objects'], data['available']),
        'authority': reconcile_authority(data['restored_authority'], data['approved_authority'], data['sessions']),
        'sequence': sequence_step(**data['sequence_case'])}


def self_test():
    checks = 0
    def check(observed, expected):
        nonlocal checks
        assert observed == expected, (observed, expected)
        checks += 1
    b = {'generation': 'boot1', 'time_s': 10, 'value': 500}
    a = {'generation': 'boot1', 'time_s': 20, 'value': 520}
    check(counter_rate(b, a)['rate_per_s'], 2)
    check(counter_rate(b, {**a, 'generation':'boot2'})['valid'], False)
    check(counter_rate(b, {**a, 'value': 10})['valid'], False)
    e = {'reported_s': 10, 'offset_s': 1, 'uncertainty_s': 2}
    check(compare_events(e, {**e, 'reported_s': 11})['supported_order'], 'unresolved')
    check(compare_events(e, {**e, 'reported_s': 20})['supported_order'], 'A_before_B')
    asset = {'running_version': '1', 'installed_version': '2', 'functional_test_pass': True, 'denial_test_pass': True}
    advisory = {'affected_versions':['1'], 'fixed_versions':['2']}
    check(patch_gate(asset, advisory, {'standby_ready':False})['execution_permitted_by_model'], False)
    check(patch_gate(asset, advisory, {})['running_remediation_verified'], False)
    check(patch_gate({**asset,'running_version':'2'}, advisory, {})['running_remediation_verified'], True)
    check(recovery_plan([{'id':'a','requires':['b']},{'id':'b','requires':['a']}],[])['blocked'], {'a':['b'],'b':['a']})
    check(recovery_plan([{'id':'app','requires':['identity']},{'id':'identity','requires':[]}],[])['waves'], [['identity'],['app']])
    check(reconcile_authority(['old','operator'],['operator','new'],[])['remove_restored_authority'], ['old'])
    good={'quality_good':True,'fresh':True,'permissive':True,'maintenance':False,'run_feedback':False,'flow_proven':False}
    check(sequence_step('STOPPED','START',{**good,'fresh':False},0),'STOPPED')
    check(sequence_step('STOPPED','START',good,0),'STARTING')
    check(sequence_step('STARTING','NONE',good,5),'FAULT')
    check(sequence_step('STARTING','NONE',{**good,'run_feedback':True,'flow_proven':True},2),'RUNNING')
    check(sequence_step('FAULT','RESET',good,0),'STOPPED')
    check(sequence_step('STOPPED','RESET',good,0),'STOPPED')
    return {'checks_passed':checks, 'scope':'Only deterministic synthetic model behaviour.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['report','self-test'])
    parser.add_argument('--input',type=Path,default=Path(__file__).with_name('starter.json'))
    args=parser.parse_args()
    result=self_test() if args.action=='self-test' else report(json.loads(args.input.read_text()))
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
