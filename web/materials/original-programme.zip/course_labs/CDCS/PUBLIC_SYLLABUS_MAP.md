# CDCS public-syllabus teaching map

Scope checked against [EPI's public CDCS outline](https://www.epi-ap.com/services/1/3/5) on 2026-09-19. These are original chapters and questions. The outline does not disclose protected provider teaching or exam weighting. Coverage of public headings is not a guaranteed exam pass or formal professional qualification.

| Public syllabus area | Authored chapter(s) | Mechanisms and assessed evidence |
|---|---|---|
| Data-centre design/lifecycle | 1 | Requirements, feasibility, assumptions, equivalent procurement, interface control, commissioning, handover, operation/recovery and retirement |
| Standards and rating definitions | 2 | Scheme/edition/scope, N, distributed redundancy, maintenance, fault response, substation/common dependencies and topology evidence |
| Building considerations | 3 | Site dependency/hazard review, floor/hanging/rolling loads, fire/glazing/security assemblies; D1 interface literacy only |
| Raised floor and suspended ceiling | 3 | Supports, alignment, cut panels, airflow leakage, seismic load paths, ceiling/support and detection interfaces |
| Advanced power | 4–6 | Electrical formulas, SLD, protection/earth leakage/surges, cables/PDUs, generators/fuel/paralleling, UPS modes/sharing/harmonics, battery sizing/charging/testing/cabinets, flywheel and fuel-cell models |
| Advanced electromagnetic fields | 7 | Sources, single/three-phase geometry, coupling, suitable measurement, uncertainty, attenuation and bounded distance models |
| Advanced cooling | 8 | Psychrometrics, current-envelope interpretation, heat/airflow/unit derivations, layout/tiles/doors, CFD, SHR/COP, humidity/setpoints/calibration, maintenance and direct-liquid/CDU interfaces |
| Advanced fire protection | 9 | Fire triangle, detection transport, panels, water/gas alternatives, illustrative volume/retention arithmetic, release/hold distinctions, cause-and-effect, inspection and restoration |
| Scalable network cabling | 10 | Structured distribution, ToR/EoR, copper boundaries, fiber budgets/polarity/tests, installation, bonding and administration |
| Environmental specifications/contamination | 11 | Noise quantities/surveys/controls, particle-bin validation, corrosive gases, filters and representative acceptance |
| Data-centre efficiency | 12 | Business drivers, PUE boundaries/categories, useful-work metrics, cooling economics, lighting functions, OCP interfaces and lifecycle evidence |

The JSON course contains 50 objective IDs, each linked to its original worked case, chapter and ten independently written decisions. Shared cases provide evidence for distinct decisions rather than numeric reskins. There are 500 questions in total.

Formal limits, ratings and legal duties must use the applicable actual standard/edition and authority. No invented gas factor, training environmental threshold, floor average, battery energy estimate, fan law or emulator result is a certified real design. The 12 chapters include 16,118 words of original explanatory teaching before examples and practice; length alone is not proof of competence. External provider, vendor and physical evidence gates remain.
