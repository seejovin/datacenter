"""Bounded synthetic calculation checker. No network, subprocess or plant access."""
import argparse,json,math
from pathlib import Path

def analyze(d):
    o={}
    x=d['three_phase'];o['load_kva']=x['sqrt3']*x['line_v']*x['line_a']/1000;o['load_kw']=o['load_kva']*x['pf'];o['source_kw_excess']=o['load_kw']-x['source_kw']
    x=d['rack'];o['rack_kn']=x['mass_kg']*x['g']/1000;o['footprint_average_kpa']=o['rack_kn']/(x['width_m']*x['depth_m']);o['lift_mass_excess_kg']=x['mass_kg']+x['cradle_kg']-x['lift_limit_kg']
    x=d['fuel'];o['usable_fuel_l']=x['tank_l']-x['unusable_l']-x['reserve_l'];o['fuel_hours']=o['usable_fuel_l']/x['rate_lph'];o['fuel_gap_l']=x['rate_lph']*x['required_h']-o['usable_fuel_l']
    x=d['battery'];o['bank_v']=x['block_v']*x['series_blocks'];o['bank_ah']=x['block_ah']*x['parallel_strings'];o['bank_nominal_kwh']=o['bank_v']*o['bank_ah']/1000;o['bank_model_ac_kwh']=o['bank_nominal_kwh']*x['usable_fraction']*x['efficiency'];o['bank_model_minutes']=60*o['bank_model_ac_kwh']/x['load_kw']
    x=d['flywheel'];o['flywheel_usable_mj']=0.5*x['inertia_kgm2']*(x['omega_max_rad_s']**2-x['omega_min_rad_s']**2)/1e6;o['flywheel_model_seconds']=o['flywheel_usable_mj']*1000*x['efficiency']/x['load_kw']
    x=d['air'];o['air_kg_s']=x['heat_kw']/(x['cp_kj_kgk']*x['delta_k']);o['air_m3_s']=o['air_kg_s']/x['rho_kg_m3'];o['air_m3_h']=o['air_m3_s']*3600;o['air_cfm']=o['air_m3_s']*x['cfm_per_m3s']
    x=d['liquid'];o['liquid_heat_kw']=x['rack_kw']*x['liquid_fraction'];o['residual_air_kw']=x['rack_kw']-o['liquid_heat_kw'];o['liquid_kg_s']=o['liquid_heat_kw']/(x['cp_kj_kgk']*x['delta_k']);o['liquid_l_s']=o['liquid_kg_s']/x['rho_kg_l']
    x=d['psychrometric'];o['vapor_pressure_kpa']=x['humidity_ratio']*x['pressure_kpa']/(0.622+x['humidity_ratio']);o['relative_humidity_percent']=100*o['vapor_pressure_kpa']/x['saturation_kpa']
    x=d['optical'];o['optical_loss_db']=x['fiber_km']*x['fiber_db_km']+x['connector_pairs']*x['connector_pair_db']+x['splices']*x['splice_db'];o['received_dbm']=x['tx_min_dbm']-o['optical_loss_db'];o['sensitivity_margin_db']=o['received_dbm']-x['rx_min_dbm'];o['unreserved_margin_db']=o['sensitivity_margin_db']-x['required_margin_db']
    x=d['gas_training_only'];o['gas_model_volume_m3']=x['area_m2']*sum(x['protected_heights_m'])-x['deduction_m3'];o['gas_model_mass_kg']=o['gas_model_volume_m3']*x['illustrative_kg_m3'];o['gas_model_shortfall_kg']=o['gas_model_mass_kg']-x['available_units']*x['usable_kg_each'];o['gas_model_c10_percent']=x['initial_percent']*math.exp(-x['loss_per_minute']*x['time_minutes']);o['changed_gas_model_c10_percent']=x['initial_percent']*math.exp(-x['changed_loss_per_minute']*x['time_minutes'])
    x=d['fan'];o['fan_model_kw']=x['baseline_kw']*x['speed_ratio']**3;o['fan_model_annual_kwh_saved']=(x['baseline_kw']-o['fan_model_kw'])*x['annual_hours'];o['fan_model_net_annual_saving']=o['fan_model_annual_kwh_saved']*x['energy_charge']-x['added_annual_maintenance'];o['fan_model_simple_payback_years']=x['capital']/o['fan_model_net_annual_saving']
    return o

def check(actual,expected):
    errors=[]
    for k,v in expected.items():
        if k not in actual or type(actual[k]) not in (int,float) or not math.isclose(actual[k],v,rel_tol=0.001,abs_tol=0.001):errors.append(f'{k}: expected {v:.6g}, received {actual.get(k)!r}')
    if errors:raise ValueError('\n'.join(errors))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--submission',type=Path);p.add_argument('--self-check',action='store_true');a=p.parse_args()
    result=analyze(json.loads(Path(__file__).with_name('fixture.json').read_text()))
    if a.self_check:
        check(result,{'load_kva':69.28,'load_kw':62.352,'source_kw_excess':2.352,'rack_kn':11.772,'footprint_average_kpa':16.35,'lift_mass_excess_kg':50,'usable_fuel_l':6000,'fuel_hours':100/3,'fuel_gap_l':480,'bank_v':480,'bank_ah':200,'bank_nominal_kwh':96,'bank_model_ac_kwh':69.12,'bank_model_minutes':20.736,'flywheel_usable_mj':3.75,'flywheel_model_seconds':33.75,'air_m3_s':9.950248756,'air_cfm':21083.38,'liquid_heat_kw':425,'residual_air_kw':75,'liquid_kg_s':20.33492823,'vapor_pressure_kpa':1.603243671,'relative_humidity_percent':53.71000573,'optical_loss_db':2.6,'received_dbm':-4.6,'sensitivity_margin_db':3.4,'unreserved_margin_db':1.4,'gas_model_volume_m3':300,'gas_model_mass_kg':195,'gas_model_shortfall_kg':35,'gas_model_c10_percent':6.549846025,'changed_gas_model_c10_percent':5.362560368,'fan_model_kw':10.24,'fan_model_annual_kwh_saved':39040,'fan_model_net_annual_saving':4856,'fan_model_simple_payback_years':10.29654036})
        print('Synthetic numerical reference checks passed. No physical design or protective function was tested.')
    elif a.submission:
        check(json.loads(a.submission.read_text()),result);print('Numerical submission passed within 0.1% tolerance. Interpretation requires reviewer assessment.')
    else:print(json.dumps(result,indent=2))
