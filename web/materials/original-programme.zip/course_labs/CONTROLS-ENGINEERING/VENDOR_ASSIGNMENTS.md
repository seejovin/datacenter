# Required external teaching and practical access

These are retained assignments from the supplied curriculum, not optional links or completed enrolments. Agree selected versions, instructors, assessment, lab rights and continued access. An app chapter or local Python result does not reproduce a protected provider course or award its certificate.

## 27 — Smart Buildings Academy — BAS200: Control Sequence Fundamentals

Full; required controls-sequence teaching and assessment.

Access/evidence status: Assigned; completion and access unverified.

- [BAS200](https://courses.smartbuildingsacademy.com/products/control-sequence-fundamentals)

## 28 — The BACnet Institute — The Facility Manager’s Guide to Building Automation Systems

Full: specification, procurement, construction and commissioning.

Access/evidence status: Assigned; completion and access unverified.

- [Facility Manager’s Guide](https://thebacnetinstitute.org/courses-overview/)

## 29 — Schneider — EcoStruxure Building Operation Introduction → Operators

Full, both named courses in order.

Access/evidence status: Assigned; completion and access unverified.

- [Building Management Training](https://www.se.com/uk/en/work/services/training/ecobuildings/building-management-training/)

## 30 — Schneider — EcoStruxure Building Operation Certification

Full engineering course. Choose the regular or Intensive Route—not both.

Access/evidence status: Assigned; completion and access unverified.

- [EBO engineering training](https://www.se.com/uk/en/work/services/training/ecobuildings/building-management-training/)

## 31 — Schneider — HVAC Applications & Programming

Full.

Access/evidence status: Assigned; completion and access unverified.

- [HVAC training](https://www.se.com/uk/en/work/services/training/ecobuildings/building-management-training/)

## 32 — Schneider — Control Panels & Field Equipment

Full: field equipment, pre-commissioning and fault-finding.

Access/evidence status: Assigned; completion and access unverified.

- [Field-equipment training](https://www.se.com/uk/en/work/services/training/ecobuildings/building-management-training/)

## 33 — Schneider — Introduction to EcoStruxure Power Monitoring Expert

Full: monitoring, analysis, reporting and configuration.

Access/evidence status: Assigned; completion and access unverified.

- [PME training listing](https://www.se.com/za/en/work/services/training/)

## 34 — Siemens SITRAIN — RC-SWIROR

Full: Switching and Routing in Industrial Networks with RUGGEDCOM. Industrial network implementation, operation, diagnostics and troubleshooting.

Access/evidence status: Assigned; completion and access unverified.

- [RC-SWIROR](https://www.sitrain-learning.siemens.com/DE/en/rw7781/Switching-and-Routing-in-Industrial-Networks-with-RUGGEDCOM-Online-Training)

## 35 — Cisco — REP teaching packet

Overview → Configure and Verify a REP Ring Segment → Configure REP VLAN Load Balancing. Use the matching industrial-switch guide for implementation.

Access/evidence status: Assigned; completion and access unverified.

- [Overview](https://video.cisco.com/detail/video/6360658877112)
- [Configuration](https://video.cisco.com/detail/video/6347711020112)
- [Load balancing](https://video.cisco.com/detail/video/6353026730112)
- [Platform guide](https://www.cisco.com/c/en/us/td/docs/switches/lan/industrial/software/configuration/guide/b-configuring-resilient-ethernet-protocol/m-how-to-configure-rep.html)

## 36 — SEL University — eCOM 202: Introduction to IEC 61850

Full.

Access/evidence status: Assigned; completion and access unverified.

- [eCOM 202](https://selinc.com/selu/courses/ecom/202/)

## 37 — Siemens SITRAIN — RC-ASWIROR

Full, after 34 or equivalent competence. PRP, HSR, network coupling, QuadBox, NTP/SNTP, PTP and IRIG-B, alongside advanced routing. Classroom teaching—not a verified recorded-video course.

Access/evidence status: Assigned; completion and access unverified.

- [Advanced RUGGEDCOM training](https://www.sitrain-learning.siemens.com/DE/en/rw75347/Advanced-Switching-and-Routing-in-Industrial-Networks-with-RUGGEDCOM-Face-to-face-Training)

## 38 — Siemens SITRAIN — Security in Industrial Networks with SCALANCE

Full; required industrial-network security outcomes. Use the selected SCALANCE route or document an assessed equivalent implementation.

Access/evidence status: Assigned; completion and access unverified.

- [SCALANCE security training](https://www.sitrain-learning.siemens.com/DE/en/rw34777/Security-in-Industrial-Networks-with-SCALANCE)

## 03A — Siemens controller engineering and service

TIA-PRO1 → practical application → TIA-PRO2 → SCL fundamentals where needed → practical application → TIA-PRO3. Retain TIA-SERV2/SERV3 diagnostics and service outcomes with assessed nonduplicative teaching. Assign explicit PLCSIM Advanced instruction and lab rights; they remain unresolved. CPT-FAP and CPT-FAST2 are separate credential choices with provider eligibility.

Access/evidence status: Assigned; selected instruction and access require confirmation.

- [Course / entry](https://www.sitrain-learning.siemens.com/en/rw1105/Online-Training-SIMATIC-Programming-1-in-TIA-Portal)
- [Course / entry](https://www.sitrain-learning.siemens.com/en/rw73126/Online-Training-SIMATIC-Programming-2-in-TIA-Portal)
- [Course / entry](https://www.sitrain-learning.siemens.com/en/rw6449/Online-Training-SIMATIC-Programming-1-with-SCL-in-TIA-Portal)
- [Course / entry](https://www.sitrain-learning.siemens.com/en/rw24951/Online-Training-SIMATIC-Programming-3-in-TIA-Portal)
- [Course / assessment](https://www.sitrain-learning.siemens.com/en/rw48055/SIMATIC-Service-2-in-TIA-Portal)
- [Course / assessment](https://www.sitrain-learning.siemens.com/en/rw96384/SIMATIC-Service-3-in-TIA-Portal)
- [Certification](https://www.sitrain-learning.siemens.com/en/rw88365/Siemens-Certified-Programmer-in-TIA-Portal)
- [Certification / entry](https://www.sitrain-learning.siemens.com/en/rw42961/Siemens-Certified-Service-Technician-Level-2-in-TIA-Portal)

## 03B — Sunbird DCIM operation and administration

Agree complete End-User and System Administration training for selected dcTrack/Power IQ versions. Confirm capacity/dependency records, MAC workflows, integrations, permissions, freshness, diagnosis, backup, upgrade and restoration teaching plus continuing lab access. Product-specific lifecycle coverage is a teaching-agreement requirement, not an inferred course promise.

Access/evidence status: Assigned; selected instruction and access require confirmation.

- [Training services](https://www.sunbirddcim.com/dcim-training-services)
- [Support resources](https://www.sunbirddcim.com/dcim-technical-support)

## 03C — Selected CMMS: maintenance work and application lifecycle

DL25606G introduction; choose MAX4350G OR MAX4348G Work Management fundamentals; then MAX4352G Advanced Work Management. Separately assign selected-product administration, integrations, backup and recovery teaching. Confirm version and lab access. Work-management learning alone does not establish application-recovery capability.

Access/evidence status: Assigned; selected instruction and access require confirmation.

- [IBM course](https://www.ibm.com/training/course/maximo-application-suite-manage-introduction-DL25606G)
- [Self-paced route](https://www.ibm.com/training/course/maximo-manage-fundamentals-of-work-management-MAX4350G)
- [Instructor-led route](https://www.ibm.com/training/course/maximo-manage-fundamentals-of-work-management-MAX4348G)
- [IBM course](https://www.ibm.com/training/course/maximo-manage-advanced-work-management-MAX4352G)
- [IBM credential](https://www.ibm.com/training/certification/ibm-certified-maximo-manage-v9-work-management-associate-C9008600)
- [IBM-issued credential](https://www.credly.com/org/ibm-professional-certification-program/badge/ibm-certified-maximo-manage-v9-0-functional-deploym)

## Protocol and application gap assignments

- BACnet: retain Basics, Device Profiles, Cybersecurity and facility-manager teaching; add named selected-device MS/TP wiring/token/diagnosis instruction and lab. Implement discovery, object identity, COV, reliability and priority/relinquish cases.
- Modbus: orientation is followed by full selected TCP/RTU register, signedness/order, gateway cache, serial wiring/timing and failure/restore instruction. Use the current [Modbus specifications page](https://www.modbus.org/modbus-specifications) because older PDF links may move.
- OPC UA and MQTT: selected-server/broker instruction and actual identity, trust/permissions, subscriptions/queues, schema, age, retained/duplicate and reconnect tests. The fixture implements neither stack.
- IEC 61850: retain full SEL eCOM202 and add device-specific MMS/GOOSE engineering-file, data-set/configuration and subscriber-loss tests where not demonstrated. No protection setting changes without the appropriate authority.
- Time/resilience: separately assess NTP, PTP profile/domain/timestamping and IRIG-B physical interfaces; PRP, HSR, REP, RSTP/MSTP and HSRP/VRRP remain distinct. RC-ASWIROR classroom delivery is not assumed to be a recorded-video entitlement.
- Management: selected SCALANCE/NGFW, OOB, IPsec/VPN, NMS, SNMP/syslog, packet-broker and OT-monitoring demonstrations. Record collection coverage, dropped traffic and recovery dependencies; not every employer-named brand is mandated.
- Hosts/data: assigned Hyper-V/server/database lessons and Inductive University, including store-and-forward and gateway restoration; restore current telemetry, alarm delivery and history as well as guests.
- Automation: reuse Git/Python/SQL and Item50 foundations with one suitable tool. Complete the assigned Ansible concepts, network differences, first command/playbook, inventory and beyond-basics sections; apply to reviewed inventory, backup, deployment validation and rollback.
- T-LAB-05: named instructor/session with actual selected AI model/MCP client/server after telemetry/API readiness. Read-only evidence queries, cited hypotheses, unsupported-claim, untrusted-input and access tests; any execution requires separate permissions and change procedure.
- T-LAB-06: reviewed functional design; supervised low-energy sensing/actuation and calibration; PLC/DDC/ST/ladder and dynamics/PID; power/cooling interfaces; actual maintenance, trusted restore and recommissioning. Record real equipment, authority and reviewer.

## Access and credential distinctions

Siemens provider prerequisites and local course/lab entitlements must be checked for the selected delivery. TIA-SCL1 formal entry is not assumed to require PRO2 in every route; use the published entry assessment. SERV2/SERV3 and CPT-FAST2 attendance/knowledge rules must not be silently waived. PLCSIM Advanced instruction and licenses remain explicit. SCE modules support learning but do not close every advanced/service gap.

Sunbird end-user and administration outcomes both matter; public training does not establish an additional exam-based personnel certification. CMMS work-management learning does not establish deployment/administration/recovery. Retain the Maximo Work Management Associate v9 target; the Functional Deployment Professional reference is not imposed as a new graduation gate.

Full provider instruction and actual practice are requirements; budget and access affect the schedule, not whether the stated capability is needed. The curriculum access gate register remains the authority for unresolved arrangements.
