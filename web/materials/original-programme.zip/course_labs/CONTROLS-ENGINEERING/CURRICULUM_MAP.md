# Exact curriculum outcome map

Governing scope: supplied Curriculum Rev14, Charter Rev3.5 and Portfolio Rev2.5. Authored instruction is available; actual capability remains subject to executed practical evidence and authority.

| Outcome | Exact title | Authored chapters |
|---|---|---|
| OT-01 | Requirements, control narratives and interface design | CE-L01, CE-L21 |
| OT-02 | Instrumentation, I/O and measurement assurance | CE-L02, CE-L03, CE-L21, CE-L22 |
| OT-03 | PLC/DDC programming and control application lifecycle | CE-L04, CE-L05, CE-L06, CE-L21 |
| OT-04 | Feedback control and dynamic behaviour | CE-L07, CE-L08, CE-L10, CE-L22 |
| OT-05 | Power controls and independent protection interfaces | CE-L09, CE-L16, CE-L21 |
| OT-06 | Cooling controls and mechanical operating sequences | CE-L03, CE-L05, CE-L07, CE-L08, CE-L10, CE-L21 |
| OT-07 | Supervisory systems and operational interfaces | CE-L06, CE-L09, CE-L11, CE-L14, CE-L18, CE-L21 |
| OT-08 | DCIM, maintenance systems and operational records | CE-L12, CE-L22 |
| OT-09 | Industrial communications, time and availability | CE-L13, CE-L14, CE-L15, CE-L16, CE-L17, CE-L21 |
| OT-10 | Commissioning, daily operation, maintenance and recovery | CE-L06, CE-L12, CE-L19, CE-L21, CE-L22 |
| CN-01 | Requirements, reference design and supplier review | CE-L01, CE-L09, CE-L17, CE-L21 |
| CN-02 | Layer 2/3 architecture, resilience and security | CE-L17 |
| CN-03 | Industrial protocols and timing | CE-L13, CE-L14, CE-L15, CE-L16 |
| CN-04 | Secure management and observability | CE-L18, CE-L20 |
| CN-05 | Virtualised controls and relational data | CE-L11, CE-L12, CE-L18 |
| CN-06 | Commissioning, diagnosis and day-two ownership | CE-L13, CE-L17, CE-L18, CE-L19, CE-L21, CE-L22 |
| CN-07 | Network automation and operational analytics | CE-L15, CE-L19, CE-L20 |
| CN-08 | AI agents or MCP-connected diagnostics | CE-L20 |

Each chapter contains two objective-linked teaching outcomes, eight original scenario questions, worked examples, guided practice, an independent assignment and three recall cards. The map does not claim every external course or physical requirement is completed.

D4–D7 are the near-term owned engineering scope. D2/D3 power and mechanical work is integrated through approved interfaces and specialist review; deeper design authority remains separate. D1 civil/structural/architectural engineering remains excluded. CN-08 is required after usable evidence/API foundations and is not a prerequisite for core Release 2.
