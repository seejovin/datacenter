# Controls engineering practical programme

This laboratory supports CE-L01–22. It contains original bounded Python models and synthetic evidence. It has no network access, PLC connection, broker, LLM, MCP server, credentials or deployment operation. It does not emulate a vendor runtime or establish physical commissioning.

Run from the project directory with Python 3.10 or later:

```bash
python course_labs/CONTROLS-ENGINEERING/lab.py
```

The command creates a new temporary local results directory and prints its path. To retain a named run, choose a **new** directory:

```bash
python course_labs/CONTROLS-ENGINEERING/lab.py --out controls_run_01
```

Existing result files are refused so prior evidence is preserved. The run writes `report.json` and two PI trace CSV files. `executed_example/` contains the actual author validation run, not learner completion evidence. All 15 invariant checks passed in that run. The thermal controller with conditional integration first reached 36 °C or below 19 s after the unreachable setpoint was reduced; the uncontrolled-integral comparison did not reach that boundary during the next 300 s. This is a result of this deliberately bounded model, not a tuning recommendation for a real plant.

The pump trace uses a one-second illustrative scan. The proof timer starts after entry to STARTING; feedback wins over timeout when both are observed together in this declared model. Inhibit dominates. Reset requires an edge and does not restart a held start request. Stopping is instantaneous in the model. Real drive ramps, debounce, contactors, physical inertia, safety functions and vendor scheduling are omitted.

The thermal model is a heating analogy: equilibrium temperature = 20 + 0.3 × output + disturbance, time constant 30 s, exact first-order update each second, perfect measurement, output limited to 0–100%. Kp = 4 %/°C and Ki = 0.12 %/(°C·s). The setpoint is intentionally unreachable at 80 °C for 300 s, then becomes 35 °C. At 600 s an equivalent −3 °C load disturbance is introduced. It contains no hydraulic, refrigerant, electrical, spatial or protective model.

## Independent assignment sequence

Complete the chapter's guided exercise before its independent task. Keep your own source/fixture revision and result files. The worked examples are references; submit your reasoning and evidence rather than copying the answer.

| Chapter | Local task and independent variation | Evidence and external completion boundary |
|---|---|---|
| 01 | Write the pump transition table, including start+inhibit, maintenance and reboot. Allocate a source-to-screen age budget. | Reviewed design/point/flow package; T-LAB-06 design review remains required. |
| 02 | Recalculate 15.2 mA scaling, uncertainty interval and compliance decision. Change the fixture range in a separate copy and explain the result. | As-found/as-left worksheet; actual safe instrument/reference comparison remains required. |
| 03 | Draw the loop voltage budget. Diagnose command=true/feedback=false using at least three discriminating observations. | Supervised low-energy circuit and physical actuator/measurement proof remain required. |
| 04 | Explain why the 8 ms pulse is missed. Create a second pulse that spans a sample and compare. Review a duplicate-output-write trace. | Selected CPU/task/I/O timing and type conversion must be executed in the vendor tool. |
| 05 | Trace every pump scan. Add a separate test for reset while inhibit remains, and for unexpected feedback before start. | Reviewed ST/ladder implementation and actual vendor compilation remain required. |
| 06 | Assemble hardware/firmware, source, library, HMI and recovery manifests. Calculate rollback deadline including checks. | TIA PRO/SCL/SERV and PLCSIM Advanced access, service and actual application tests remain required. |
| 07 | Reproduce the exact first-order update. Estimate K, τ and delay from the worked step response. Compare raw and filtered synthetic records. | Physical/model-equivalent dynamic loop and reviewed model limits remain required. |
| 08 | Compare PV, output and integral in both CSV traces. Explain the windup mechanism. In a separate copy change Ki, retaining limits, and assess the result. | Selected vendor PID form/unit map and authorised physical tuning remain required. |
| 09 | Recalculate power/energy and reject stale restart permission. Write a breaker-status truth table with explicit unknowns. | PME, IED/protection interface and authorised electrical specialist review remain required. |
| 10 | Calculate the heat balance and continuous staging timer. Add maintenance/fault eligibility cases. | BAS200/HVAC/field teaching, actual cooling sequence and mechanical/OEM review remain required. |
| 11 | Distinguish backfill from live data; calculate time-weighted energy; design a bad-quality HMI view and alarm lifecycle. | EBO/PME/Ignition configuration and alarm/history restore must be executed separately. |
| 12 | Correct a duplicated capacity reservation and reconcile a work-order completion after database restore. | Sunbird end-user/admin and CMMS work-management/admin practice plus actual maintenance remain required. |
| 13 | Decode 0xFF9C and the serial poll budget. Explain why a CRC-valid frame can still carry a misinterpreted point. | Actual selected Modbus TCP/RTU endpoints, register maps and safe serial-bus tests remain required. |
| 14 | Resolve the priority 8/16 conflict. Compare direct read success with cross-subnet discovery failure. | BACnet/IP and MS/TP device/router, token, wiring and service tests remain separate. |
| 15 | Explain every accepted/rejected telemetry record; add a future timestamp and missing field in a copied fixture. | Actual OPC UA trust/subscription and MQTT broker/topic/reconnect tests remain required. |
| 16 | Reproduce overlap and holdover calculations. Compare MMS/TCP, GOOSE multicast and dedicated IRIG-B evidence. | SEL, IED and NTP/PTP/IRIG-B hardware/profile tests remain independent external gates. |
| 17 | Build a flow/ACL matrix and common-cause diagram. Assess 0.2 s link versus 12 s application recovery against a 2 s limit. | PRP, HSR, REP, RSTP/MSTP, HSRP/VRRP, MACsec and platform security each retain distinct evidence. |
| 18 | Explain the left-join missing asset, delayed rows, counter wrap assumptions and SQLite restored contents. | OOB/VPN, NMS/packet capture, Hyper-V and actual application/database restoration remain required. |
| 19 | Specify pagination, per-target reporting and retry identity. Review the local parser as a read-only workflow. | Git and one automation tool must be applied to selected authorised inventory/backup/change/validation work. |
| 20 | Inspect accepted read evidence and rejected write/scope queries. Write a diagnosis citing E-GATEWAY without inventing a sensor test. | The deterministic function is not an AI/MCP evaluation; complete T-LAB-05 with actual selected tools and an instructor. |
| 21 | Convert selected checks into requirement/stimulus/limit/evidence/restoration test records. Include a failed case. | Actual FWT/SAT/cutover requires the appropriate supervised authority. |
| 22 | Build a campaign journal and trusted restore plan. Distinguish VM boot from validated process handback. | Actual maintenance, operating history, optimisation and supervised recovery remain separate achievements. |

## Acceptance

- Reproduce calculations with units and assumptions; investigate any failed invariant rather than deleting it.
- Preserve invalid, stale, duplicate, missing and out-of-scope evidence with explicit reasons.
- Explain at least one mechanism and one remaining uncertainty for each fault case.
- Keep model, vendor-emulated, physically measured, observed and supervised evidence distinct.
- Complete the provider/physical assignments in `VENDOR_ASSIGNMENTS.md`; this local run does not close them.
- Index all nine lifecycle responsibilities using `assessment_template.md` and the exact OT/CN map.
