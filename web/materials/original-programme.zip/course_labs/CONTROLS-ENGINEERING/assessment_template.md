# Controls engineering evidence record

Learner / date / reviewer:

Chapter / curriculum outcome / portfolio work package:

Evidence fidelity: analytical / original Python model / vendor emulator / physical measurement / supervised field work.

Selected platform, version, firmware, modules, licences and access status:

Requirement and authority boundary:

Source/fixture/project revision and integrity reference:

Starting state and prerequisites:

Stimulus or work actually performed:

Expected result, time/tolerance limit and abort condition:

Observed raw evidence, units, quality, source/receipt times and clock uncertainty:

Calculation or query and reproducible result:

Hypotheses supported / rejected / still unresolved:

Defect, correction, rollback and relevant regression:

As-found / actual maintenance / as-left evidence:

Removed forces, overrides, temporary credentials and restored authority:

Restored points, sequences, alarm delivery, roles, history and integrations:

Model limitations, unperformed vendor/physical tests and assigned owner/date:

Reviewer disposition:

## Nine-responsibility index

| Responsibility | Concrete evidence reference | Actual fidelity / authority | Open gap |
|---|---|---|---|
| Design | Approved narrative, point/flow and dependency package | | |
| Implementation | Versioned controller/HMI/integration configuration | | |
| Commissioning | Requirement-linked normal/degraded/restart results | | |
| Day-to-day operation | Time-spanning observations and decisions | | |
| Maintenance | Authorised actual work with as-found/as-left proof | | |
| Optimisation | Comparable baseline/trial and adverse-effect limits | | |
| Troubleshooting | Discriminating tests and supported cause | | |
| Incident response | Authorised containment and preserved evidence | | |
| Recovery | Trusted restore, recommission and process handback | | |
