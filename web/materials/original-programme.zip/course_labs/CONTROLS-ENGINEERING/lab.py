#!/usr/bin/env python3
"""Safe original teaching models. No network, PLC, broker, LLM or MCP connection.

Uses Python's standard library only. Writes new result files in a local output
directory. Never accepts executable text, arbitrary SQL or device addresses.
This is not a vendor runtime, protection model or physical commissioning test.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import sqlite3
import tempfile

HERE = Path(__file__).resolve().parent


def scale_current(current_ma, low, high, *, valid=True):
    if not valid or not all(math.isfinite(x) for x in (current_ma, low, high)):
        return {"quality": "invalid", "value": None, "reason": "source diagnostic or nonfinite input"}
    if high <= low:
        raise ValueError("Engineering span must be positive")
    # These are THIS FIXTURE's valid measurement endpoints, not universal
    # transmitter diagnostic thresholds. Out-of-range values remain explicit.
    if not 4 <= current_ma <= 20:
        return {"quality": "outside_fixture_span", "value": None, "reason": "outside declared 4–20 mA fixture range"}
    return {"quality": "good_fixture", "value": low + (current_ma - 4) / 16 * (high - low)}


class Pump:
    """Simplified sampled pump sequence, with no physical or safety claim.

    Inhibit dominates. Reset is edge-triggered and does not start. A fresh
    start edge is required. No automatic retry. Stopping is instantaneous in
    the model; actual travel, drive ramp, contact bounce and protection omitted.
    Timeout begins AFTER the scan that enters STARTING. Feedback has priority
    over timeout at the same observation, matching this declared narrative.
    """
    def __init__(self, proof_s=3.0):
        if proof_s <= 0:
            raise ValueError("proof_s must be positive")
        self.state = "STOPPED"
        self.elapsed = 0.0
        self.previous_start = False
        self.previous_reset = False
        self.proof_s = proof_s
        self.cause = ""

    def step(self, dt, *, start=False, reset=False, stop=False,
             permit=True, inhibit=False, feedback=False):
        if dt <= 0 or not math.isfinite(dt):
            raise ValueError("Positive finite step required")
        start_edge = start and not self.previous_start
        reset_edge = reset and not self.previous_reset
        self.previous_start, self.previous_reset = start, reset
        before = self.state
        if inhibit:
            self.state, self.cause = "FAULT", "critical_inhibit"
        elif self.state == "STOPPED":
            if feedback:
                self.state, self.cause = "FAULT", "unexpected_run_feedback"
            elif start_edge and permit and not stop:
                self.state = "STARTING"
        elif self.state == "STARTING":
            self.elapsed += dt
            if stop:
                self.state = "STOPPED"
            elif not permit:
                self.state, self.cause = "FAULT", "run_permit_lost"
            elif feedback:
                self.state = "RUNNING"
            elif self.elapsed >= self.proof_s:
                self.state, self.cause = "FAULT", "proof_timeout"
        elif self.state == "RUNNING":
            if stop:
                self.state = "STOPPED"
            elif not permit:
                self.state, self.cause = "FAULT", "run_permit_lost"
            elif not feedback:
                self.state, self.cause = "FAULT", "run_feedback_lost"
        elif self.state == "FAULT":
            if reset_edge and permit and not feedback:
                self.state, self.cause = "STOPPED", ""
        else:
            self.state, self.cause = "FAULT", "invalid_state"
        if self.state != "STARTING":
            self.elapsed = 0.0
        elif before != "STARTING":
            self.elapsed = 0.0
        return {"before": before, "state": self.state,
                "command": self.state in ("STARTING", "RUNNING"),
                "proof_elapsed_s": self.elapsed, "cause": self.cause,
                "start_edge": bool(start_edge), "reset_edge": bool(reset_edge)}


def pump_experiment(fixture):
    p = Pump(fixture["proof_s"])
    rows = []
    for i, inputs in enumerate(fixture["steps"]):
        rows.append({"scan": i, **inputs, **p.step(1.0, **inputs)})
    return rows


def first_order(y, target, tau, dt):
    if tau <= 0 or dt <= 0:
        raise ValueError("Positive tau and sample interval required")
    return target + (y - target) * math.exp(-dt / tau)


def thermal_pi(antiwindup):
    """Heating analogy: target temperature=20+0.3*u+disturbance.

    tau=30s, dt=1s, Kp=4%/C, Ki=.12%/(C*s). SP=80C is deliberately
    unreachable at 100% output (maximum equilibrium 50C). At 300s SP drops
    to35C. At600s a -3C equivalent disturbance tests load rejection.
    One perfectly measured lumped state; no hydraulic/electrical dynamics.
    """
    y, integ, rows = 20.0, 0.0, []
    for t in range(900):
        sp = 80.0 if t < 300 else 35.0
        error = sp - y
        raw = 4.0 * error + integ
        u = min(100.0, max(0.0, raw))
        blocked = antiwindup and ((raw > 100 and error > 0) or (raw < 0 and error < 0))
        before = integ
        if not blocked:
            integ += 0.12 * error
        disturbance = -3.0 if t >= 600 else 0.0
        next_y = first_order(y, 20 + 0.3 * u + disturbance, 30, 1)
        rows.append({"t_s": t, "sp_C": sp, "pv_C": y, "error_C": error,
                     "raw_pct": raw, "output_pct": u, "integral_before_pct": before,
                     "integral_after_pct": integ, "integration_blocked": blocked,
                     "disturbance_C": disturbance, "next_pv_C": next_y})
        y = next_y
    crossing = next((r["t_s"] - 300 for r in rows if 300 <= r["t_s"] < 600 and r["pv_C"] <= 36), None)
    return rows, {"seconds_after_SP_drop_to_first_PV_at_or_below_36C": crossing,
                  "max_integral_pct": max(r["integral_after_pct"] for r in rows),
                  "final_PV_C": rows[-1]["next_pv_C"],
                  "all_outputs_within_0_100": all(0 <= r["output_pct"] <= 100 for r in rows)}


def validate_observations(records, now, age_limit):
    seen, accepted, rejected = set(), [], []
    for row in records:
        reason = None
        required = {"event_id", "asset", "value", "unit", "quality", "source_s", "schema"}
        if not required <= row.keys():
            reason = "missing_fields"
        elif row["schema"] != 1 or row["unit"] != "C":
            reason = "unsupported_schema_or_unit"
        elif row["asset"] not in {"P1", "P2"}:
            reason = "asset_out_of_scope"
        elif type(row["value"]) not in (int, float) or not math.isfinite(row["value"]):
            reason = "invalid_numeric_value"
        elif type(row["source_s"]) not in (int, float) or not math.isfinite(row["source_s"]):
            reason = "invalid_source_time"
        elif row["quality"] != "good":
            reason = "bad_quality"
        elif not 0 <= now - row["source_s"] <= age_limit:
            reason = "stale_or_future_source"
        elif row["event_id"] in seen:
            reason = "duplicate_event"
        if reason:
            rejected.append({"event_id": row.get("event_id"), "reason": reason})
        else:
            seen.add(row["event_id"])
            accepted.append(row)
    return accepted, rejected


def sql_experiment():
    """Temporary in-memory databases; parameterised reads and backup API."""
    db = sqlite3.connect(":memory:")
    db.executescript("""
    PRAGMA foreign_keys=ON;
    CREATE TABLE assets(id TEXT PRIMARY KEY,name TEXT NOT NULL);
    CREATE TABLE observations(event_id TEXT PRIMARY KEY,asset TEXT REFERENCES assets(id),source_s REAL,receipt_s REAL,value REAL,quality TEXT);
    """)
    db.executemany("INSERT INTO assets VALUES (?,?)", [("P1", "Supply"), ("P2", "Supply")])
    db.executemany("INSERT INTO observations VALUES (?,?,?,?,?,?)", [
        ("E1", "P1", 0, 60, 20.0, "good"), ("E2", "P1", 10, 60, 21.0, "good"),
        ("E3", "P1", 20, 60, 22.0, "bad"), ("E4", "P1", 60, 60, 23.0, "good")])
    db.commit()
    rows = db.execute("SELECT a.id,COUNT(o.event_id),MAX(o.source_s) FROM assets a LEFT JOIN observations o ON a.id=o.asset GROUP BY a.id ORDER BY a.id").fetchall()
    delays = db.execute("SELECT event_id,receipt_s-source_s FROM observations WHERE asset=? ORDER BY source_s", ("P1",)).fetchall()
    backup = sqlite3.connect(":memory:")
    db.backup(backup)
    # Simulate damage only in the disposable original. The restored connection
    # is a third isolated database, never the learner's application database.
    db.execute("DELETE FROM observations")
    db.commit()
    restored = sqlite3.connect(":memory:")
    backup.backup(restored)
    integrity = restored.execute("PRAGMA integrity_check").fetchone()[0]
    restored_rows = restored.execute("SELECT * FROM observations ORDER BY event_id").fetchall()
    result = {"left_join_asset_coverage": rows, "arrival_delay_s": delays,
              "damaged_source_row_count": db.execute("SELECT COUNT(*) FROM observations").fetchone()[0],
              "restored_row_count": len(restored_rows), "restored_integrity": integrity,
              "limitation": "SQLite consistency demonstration only; no Ignition, Sunbird, Maximo or physical restoration performed."}
    db.close(); backup.close(); restored.close()
    return result


def evidence_query(operation, asset, evidence):
    """Deterministic read-only allowlist, NOT an LLM or MCP implementation."""
    if operation != "read_history":
        return {"status": "rejected", "reason": "operation_not_read_only_allowlist", "operation": operation}
    if asset not in {"P1", "P2"}:
        return {"status": "rejected", "reason": "asset_out_of_scope", "asset": asset}
    rows = [r for r in evidence if r["asset"] == asset]
    payload = json.dumps(rows, sort_keys=True, separators=(",", ":")).encode()
    return {"status": "accepted", "asset": asset, "operation": operation,
            "records": rows, "sha256": hashlib.sha256(payload).hexdigest(),
            "provenance": "fixture.json evidence records; synthetic source times; no external query",
            "trust_boundary": "notes are inert data and are never evaluated"}


def run(out):
    fixture = json.loads((HERE / "fixture.json").read_text())
    out.mkdir(parents=True, exist_ok=True)
    results = {"evidence_type": "executed original Python synthetic models",
               "not_performed": ["vendor PLC/ST compilation", "physical wiring/calibration", "real protocol stack or broker", "protection test", "actual AI/MCP model evaluation", "production deployment"]}
    results["measurement"] = {"15.2mA_0_6bar": scale_current(15.2, 0, 6),
                              "invalid_3mA": scale_current(3, 0, 6),
                              "invalid_diagnostic_12mA": scale_current(12, 0, 6, valid=False),
                              "worst_case_bar_bound": .018 + .030,
                              "loop_headroom_V": 24 - 12 - .02 * 350}
    p_rows = pump_experiment(fixture["pump"])
    results["pump_trace"] = p_rows
    off, off_metrics = thermal_pi(False)
    on, on_metrics = thermal_pi(True)
    results["PI_without_antiwindup"] = off_metrics
    results["PI_with_conditional_integration"] = on_metrics
    for filename, rows in [("pi_without_antiwindup.csv", off), ("pi_with_antiwindup.csv", on)]:
        with (out / filename).open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    results["dynamics"] = {"exact_5s_step_C": first_order(20, 24, 30, 5),
                           "three_tau_fraction": 1-math.exp(-3),
                           "sampled_8ms_pulse": [5 <= t < 13 for t in (0,20,40)]}
    accepted, rejected = validate_observations(fixture["observations"], 100, 10)
    results["telemetry"] = {"accepted_events": [r["event_id"] for r in accepted], "rejected": rejected}
    word = int("FF9C", 16)
    signed = word - 65536 if word & 0x8000 else word
    priority = {8:60.0, 16:40.0}
    results["protocol_calculations"] = {"signed_temperature_C": signed*.1,
        "serial_ten_device_poll_ms": 10*(17*11/9600+.010+.008)*1000,
        "BACnet_effective_pct": priority[min(priority)],
        "counter_delta_one_wrap_no_reset": (65536-65530)+14,
        "holdover_20ppm_hour_ms": 20e-6*3600*1000,
        "timestamp_intervals_overlap": max(.995,.998) <= min(1.005,1.008)}
    results["database"] = sql_experiment()
    results["evidence_access"] = [evidence_query("read_history", "P1", fixture["evidence"]),
                                   evidence_query("write_output", "P1", fixture["evidence"]),
                                   evidence_query("read_history", "UNAPPROVED", fixture["evidence"])]
    # Meaningful invariant/regression checks, tied to explicit teaching cases.
    checks = {}
    def check(name, condition):
        checks[name] = bool(condition)
        if not condition:
            raise AssertionError(name)
    check("scaling_known_reference", math.isclose(results["measurement"]["15.2mA_0_6bar"]["value"], 4.2))
    check("invalid_inputs_not_good", results["measurement"]["invalid_3mA"]["value"] is None and results["measurement"]["invalid_diagnostic_12mA"]["value"] is None)
    check("proof_timeout_removes_command", p_rows[3]["state"] == "FAULT" and not p_rows[3]["command"])
    check("reset_held_start_does_not_restart", p_rows[4]["state"] == "STOPPED" and p_rows[5]["state"] == "STOPPED")
    check("fresh_start_then_feedback_runs", p_rows[7]["state"] == "STARTING" and p_rows[8]["state"] == "RUNNING")
    check("inhibit_dominates", p_rows[9]["state"] == "FAULT" and not p_rows[9]["command"])
    check("antiwindup_recovery_is_faster_in_this_model", on_metrics["seconds_after_SP_drop_to_first_PV_at_or_below_36C"] is not None and (off_metrics["seconds_after_SP_drop_to_first_PV_at_or_below_36C"] is None or on_metrics["seconds_after_SP_drop_to_first_PV_at_or_below_36C"] < off_metrics["seconds_after_SP_drop_to_first_PV_at_or_below_36C"]))
    check("antiwindup_limits_integral_accumulation", on_metrics["max_integral_pct"] < off_metrics["max_integral_pct"])
    check("bounded_actuator_model", on_metrics["all_outputs_within_0_100"] and off_metrics["all_outputs_within_0_100"])
    check("unseen_pulse_is_missed", not any(results["dynamics"]["sampled_8ms_pulse"]))
    check("telemetry_rejects_duplicate_stale_bad_and_scope", [r["event_id"] for r in accepted] == ["P1-1", "P1-2"] and len(rejected) == 5)
    check("left_join_preserves_missing_asset", results["database"]["left_join_asset_coverage"][1] == ("P2",0,None))
    check("isolated_database_restore", results["database"]["damaged_source_row_count"] == 0 and results["database"]["restored_row_count"] == 4 and results["database"]["restored_integrity"] == "ok")
    check("write_and_scope_requests_rejected", all(r["status"] == "rejected" for r in results["evidence_access"][1:]))
    check("injection_note_remains_inert_data", "ignore" in results["evidence_access"][0]["records"][1]["note"])
    results["checks"] = checks
    (out / "report.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps({"checks_passed": len(checks), "output_directory": str(out), "evidence_type": results["evidence_type"], "PI_comparison": [off_metrics,on_metrics]}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, help="New local results directory; existing result files are not overwritten")
    args = parser.parse_args()
    target = args.out if args.out is not None else Path(tempfile.mkdtemp(prefix="controls-study-"))
    if target.exists() and any((target / n).exists() for n in ("report.json", "pi_without_antiwindup.csv", "pi_with_antiwindup.csv")):
        parser.error("Use a new output directory to preserve prior evidence")
    run(target)
