# CISSP security engineering casebook

This casebook joins risk, identity, cryptography, data handling, application logic and lifecycle evidence. It uses fictional data. The executable exercises use only local Python standard-library operations; they do not contact equipment, alter accounts or validate production cryptography.

From the extracted project root, run:

```bash
python course_labs/CISSP/study_lab.py
python course_labs/CISSP/study_lab.py --self-test
```

Edit a **copy** of `casebook_fixture.json`, then supply it using `--fixture path/to/your-copy.json`. Keep the original fixture for the supplied self-checks. Record the exact changed inputs, prediction, observed output and explanation. The built-in checks validate the exercise implementation against fixed expectations; passing them is not evidence that you performed an independent workplace task.

## 1. Risk arithmetic and the decision it cannot make

The synthetic asset value is200,000 monetary units, exposure factor0.25 and annual occurrence rate0.20. The proposed control changes that estimated rate to0.05 and costs3,000 annually.

Calculate single-loss expectancy, before/after annualised loss and net expected annual benefit **before** opening the report. Independently derive50,000;10,000;2,500;and4,500 respectively. Explain why those point estimates do not decide safety, legal obligations, rare catastrophic loss, interdependencies or acceptable residual risk. Vary occurrence estimates and control cost; identify which assumptions change the decision. Deliver a risk record with accountable owner, uncertainty, treatment alternatives and acceptance evidence.

## 2. Authorisation and stale evidence

The model permits assigned reads to engineer/viewer/diagnostic-agent roles using attributes no older than300seconds. Writes additionally require engineer role, an active approved window and maintenance process mode. This is a deliberately narrow policy model, not a safe real-plant operating procedure.

Predict P1–P5, then run the model. Explain every denial. Change one condition at a time and test a diagnostic agent attempting to write, an unassigned resource and stale/malformed attributes. Do not treat strings such as`"false"` as Booleanfalse. Deliver a permission matrix, authoritative attribute sources and a revocation/failure test plan. Explain what a production policy decision/enforcement design would additionally need.

## 3. Measurements preserve value, unit, quality and time

The fixture scales4,000–20,000 raw counts to0–10bar. At12,000counts the value is5bar. Bad quality or age beyond30seconds produces an explicit invalid result with no manufactured numeric value. Test wrong units, out-of-range values, zero span and nonfinite input.

Explain why returning0 on every error can mislead a control or operator. The script is a data-assurance model and does not calibrate a physical transmitter, establish uncertainty or verify a protection function. Deliver scaling arithmetic, quality/freshness policy and the physical/vendor evidence needed for a real measurement path.

## 4. Approval is checked when delayed work executes

A1 is inside its time/target/action scope. A2 executes after expiry. A3 attempts a different target and action. The synthetic policy rejects execution at the exact expiry instant as well as after it. Test a revoked role, an absent timezone and scope changes.

Deliver an execution-authority state model. Include submission, queue retention, cancellation, execution, replay and evidence. Explain why a signed or previously accepted request can still be stale or unauthorised now.

## 5. SQL values, tenant authority and capacity invariants

The executable uses an actual in-memory SQLite database. TenantA can read its own job but not tenantB's job through the parameterised, tenant-bound lookup. Two sequential conditional capacity updates attempt to reserve the single available unit; only the first succeeds.

Inspect the code and explain two separate controls: safe query parameter binding and server-side tenant scoping. Explain why a local sequential example does not prove distributed concurrency correctness. Draw an unsafe interleaving in which two independent read-then-write workers both observe one unit. Propose an appropriate transaction/conditional-state design and independent concurrent test plan.

## 6. Provenance is evidence, not approval

The fixture explicitly assumes a trusted mechanism has already verified a provenance signature. **This script does not verify signatures or implement cryptography.** It checks further policy: approved builder/source, matching artifact subject and required test stage. The original fixture fails source, artifact and test-stage conditions despite its verification input beingtrue.

Repair a copy of the fixture, then remove the trusted-verification result and observe rejection again. Explain why authenticity of a statement and acceptability of its contents differ. Deliver an artifact-to-evidence chain and key/issuer trust, rollover and compromise requirements for a real system.

## Apply the other chapters to one coherent case

Use a fictional monitoring service with an enterprise identity provider, a read-only diagnostic agent, a privileged engineering workflow, a database, an encrypted evidence archive and a supplier maintenance route. Define your own assumptions rather than using real workplace secrets.

For governance and assets, produce a stakeholder/role matrix, legal and contractual questions for appropriate review, classification, data flows, retention and sanitisation decisions. For architecture and networks, identify trust/data/control/management boundaries, cryptographic endpoints, certificate and key dependencies, permitted/denied flows, shared physical dependencies and degraded modes. For identity, define enrollment, roles, federation claims, session revocation, service ownership and emergency recovery. For software, define input schemas, tenant permissions, pipeline authority, artifact provenance, vulnerability response and retirement.

Use the separate `course_labs/CISSP-D67` exercises for assessment, investigation and operations when following those chapters. Keep analytical, executed local, vendor, physical, supervised and production evidence distinct.

## Evidence record

- Requirement and scoped claim:
- Environment, versions and configuration:
- Inputs and independent expected result:
- Method and actual commands/actions performed:
- Observed result and retained evidence identity:
- Alternative explanations and untested paths:
- Acceptance decision, authority and reviewer:
- Corrective action and regression/negative tests:
- Remaining physical, vendor, legal or operational limits:

A chapter's independent task supplies the specific deliverables and acceptance criteria. This casebook supplies a consistent fictional environment and runnable starting models; it does not award professional competence or certify a real deployment.
