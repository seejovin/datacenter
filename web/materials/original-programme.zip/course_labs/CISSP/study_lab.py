"""Offline CISSP reasoning models. No network, production control or real credentials.

These checks implement only the synthetic policies in security_casebook.md.
Token/signature verification and real cryptography are deliberately not simulated
as proven: the provenance exercise takes an explicit trusted-verification result
as an input and then checks additional policy conditions.
"""
from __future__ import annotations
import argparse
from datetime import datetime
from decimal import Decimal
import json
from pathlib import Path
import sqlite3
import unittest

HERE = Path(__file__).resolve().parent


def decimal_value(value):
    if isinstance(value, bool):
        raise ValueError("Boolean is not a numeric measurement")
    try:
        result = Decimal(str(value))
    except Exception as error:
        raise ValueError("Invalid numeric value") from error
    if not result.is_finite():
        raise ValueError("Nonfinite numeric value")
    return result


def risk_case(item):
    value, ef, rate, treated, cost = [decimal_value(item[k]) for k in
        ("asset_value", "exposure_factor", "annual_rate", "treated_annual_rate", "annual_control_cost")]
    if value < 0 or not 0 <= ef <= 1 or min(rate, treated, cost) < 0:
        raise ValueError("Risk inputs outside the exercise model")
    sle = value * ef
    before, after = sle * rate, sle * treated
    return {"single_loss": str(sle), "ale_before": str(before), "ale_after": str(after),
            "annual_expected_reduction": str(before-after),
            "net_expected_annual_benefit": str(before-after-cost),
            "limit": "Point estimates; not a guarantee, safety acceptance or complete decision model."}


def policy_decision(item):
    # This policy is illustrative, not a production OT authorisation service.
    if type(item.get("assigned")) is not bool or type(item.get("window_active")) is not bool:
        return {"permit": False, "reason": "Invalid Boolean policy attributes"}
    age = item.get("attribute_age_seconds")
    if type(age) is not int or age < 0 or age > 300:
        return {"permit": False, "reason": "Missing, invalid or stale policy attributes"}
    if not item["assigned"]:
        return {"permit": False, "reason": "Resource is not assigned"}
    action, role = item.get("action"), item.get("role")
    if action == "read" and role in {"engineer", "diagnostic_agent", "viewer"}:
        return {"permit": True, "reason": "Assigned read under current attributes"}
    if action == "write" and role == "engineer" and item["window_active"] and item.get("process_mode") == "maintenance":
        return {"permit": True, "reason": "All synthetic write-policy conditions hold"}
    return {"permit": False, "reason": "Action, role or operating conditions are not permitted"}


def measurement(item):
    if item.get("quality") != "good":
        return {"valid": False, "value": None, "reason": "Source quality is not good"}
    age = item.get("age_seconds")
    if type(age) is not int or not 0 <= age <= 30:
        return {"valid": False, "value": None, "reason": "Invalid or stale age"}
    if item.get("unit") != "bar":
        return {"valid": False, "value": None, "reason": "Unexpected unit for this exercise"}
    try:
        raw, low, high, emin, emax = [decimal_value(item[k]) for k in
            ("raw", "minimum_raw", "maximum_raw", "engineering_min", "engineering_max")]
    except (KeyError, ValueError):
        return {"valid": False, "value": None, "reason": "Invalid numeric/schema input"}
    if high <= low or emax <= emin or not low <= raw <= high:
        return {"valid": False, "value": None, "reason": "Range/span violation"}
    value = emin + (raw-low) * (emax-emin) / (high-low)
    return {"valid": True, "value": str(value), "unit": "bar", "reason": "Scaled value with accepted synthetic quality/age"}


def queued_action(item):
    try:
        expiry, execution = [datetime.fromisoformat(item[k]) for k in ("expires", "execute_at")]
        if expiry.tzinfo is None or execution.tzinfo is None:
            raise ValueError("Timezone required")
    except (KeyError, TypeError, ValueError):
        return {"permit": False, "reason": "Invalid time evidence"}
    if type(item.get("role_revoked")) is not bool or item["role_revoked"]:
        return {"permit": False, "reason": "Authority revoked or unknown"}
    if execution >= expiry:
        return {"permit": False, "reason": "Approval expired at execution"}
    if item.get("requested_asset") != item.get("approved_asset") or item.get("requested_action") != item.get("approved_action"):
        return {"permit": False, "reason": "Target/action outside approval scope"}
    if not item.get("subject") or not item.get("approved_asset") or item.get("approved_action") not in {"read", "write"}:
        return {"permit": False, "reason": "Missing or invalid scoped identity/action"}
    return {"permit": True, "reason": "Synthetic current scoped approval holds"}


def provenance_decision(item, policy):
    reasons = []
    if item.get("signature_verified_by_trusted_mechanism") is not True:
        reasons.append("No trusted verification result")
    if item.get("builder") != policy["approved_builder"]:
        reasons.append("Unapproved builder")
    if item.get("source") != policy["approved_source"]:
        reasons.append("Unapproved source")
    if not item.get("subject_digest") or item["subject_digest"] != item.get("deployed_digest"):
        reasons.append("Artifact subject mismatch")
    if policy["required_test_stage"] not in item.get("test_stages", []):
        reasons.append("Required stage absent")
    return {"permit": not reasons, "reasons": reasons,
            "limit": "Does not perform cryptographic verification; it checks policy after an externally established verification input."}


def database_demo():
    with sqlite3.connect(":memory:") as db:
        db.executescript("CREATE TABLE jobs(tenant TEXT, job TEXT, status TEXT); CREATE TABLE pool(id INTEGER PRIMARY KEY, remaining INTEGER CHECK(remaining>=0));")
        db.executemany("INSERT INTO jobs VALUES(?,?,?)", [("A", "job-1", "ready"), ("B", "job-2", "private")])
        db.execute("INSERT INTO pool VALUES(1,1)")
        def read_job(authorised_tenant, requested_job):
            return db.execute("SELECT status FROM jobs WHERE tenant=? AND job=?", (authorised_tenant, requested_job)).fetchone()
        allowed, denied = read_job("A", "job-1"), read_job("A", "job-2")
        first = db.execute("UPDATE pool SET remaining=remaining-1 WHERE id=1 AND remaining>0").rowcount
        second = db.execute("UPDATE pool SET remaining=remaining-1 WHERE id=1 AND remaining>0").rowcount
        remaining = db.execute("SELECT remaining FROM pool WHERE id=1").fetchone()[0]
        return {"tenant_A_own_job": list(allowed), "tenant_A_other_job": denied,
                "conditional_reservations_succeeded": [first, second], "remaining": remaining,
                "limit": "Actual local SQLite operations; sequential conditional updates illustrate the invariant, not a distributed concurrency/load qualification."}


def report(data):
    return {"scope": data["scope"], "risk": risk_case(data["risk"]),
            "policy": {x["id"]: policy_decision(x) for x in data["policy_requests"]},
            "measurements": {x["id"]: measurement(x) for x in data["samples"]},
            "queued_actions": {x["id"]: queued_action(x) for x in data["queued_actions"]},
            "provenance": provenance_decision(data["provenance"], data["artifact_policy"]),
            "database": database_demo()}


class Checks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = json.loads((HERE/"casebook_fixture.json").read_text())
    def test_risk_arithmetic_independent_expected_values(self):
        r = risk_case(self.data["risk"])
        self.assertEqual(Decimal(r["single_loss"]), Decimal("50000"))
        self.assertEqual(Decimal(r["ale_before"]), Decimal("10000"))
        self.assertEqual(Decimal(r["ale_after"]), Decimal("2500"))
        self.assertEqual(Decimal(r["net_expected_annual_benefit"]), Decimal("4500"))
    def test_risk_rejects_invalid_exposure_and_nonfinite(self):
        for value in ("1.2", "NaN", "Infinity"):
            with self.assertRaises(ValueError): risk_case({**self.data["risk"], "exposure_factor":value})
    def test_policy_binds_assignment_and_action(self):
        outcomes = [policy_decision(x)["permit"] for x in self.data["policy_requests"]]
        self.assertEqual(outcomes, [True, False, False, False, True])
    def test_policy_rejects_ambiguous_types(self):
        for changes in ({"assigned":"false"}, {"attribute_age_seconds":True}, {"attribute_age_seconds":-1}):
            self.assertFalse(policy_decision({**self.data["policy_requests"][0], **changes})["permit"])
    def test_measurement_value_quality_and_freshness(self):
        outcomes = [measurement(x) for x in self.data["samples"]]
        self.assertEqual(Decimal(outcomes[0]["value"]), Decimal("5"))
        self.assertIsNone(outcomes[1]["value"])
        self.assertIsNone(outcomes[2]["value"])
    def test_measurement_rejects_boolean_and_wrong_unit(self):
        for changes in ({"raw":True}, {"raw":"NaN"}, {"unit":"psi"}, {"maximum_raw":4000}):
            self.assertFalse(measurement({**self.data["samples"][0], **changes})["valid"])
    def test_queued_scope_and_expiry(self):
        self.assertEqual([queued_action(x)["permit"] for x in self.data["queued_actions"]], [True, False, False])
    def test_exact_expiry_and_revocation_deny(self):
        x=self.data["queued_actions"][0]
        self.assertFalse(queued_action({**x,"execute_at":x["expires"]})["permit"])
        self.assertFalse(queued_action({**x,"role_revoked":True})["permit"])
    def test_unzoned_time_is_not_accepted(self):
        self.assertFalse(queued_action({**self.data["queued_actions"][0],"execute_at":"2030-01-01T11:00:00"})["permit"])
    def test_provenance_valid_signature_does_not_override_policy(self):
        r=provenance_decision(self.data["provenance"],self.data["artifact_policy"])
        self.assertFalse(r["permit"])
        self.assertEqual(set(r["reasons"]), {"Unapproved source","Artifact subject mismatch","Required stage absent"})
    def test_provenance_repaired_scope_still_requires_trusted_verification(self):
        x={**self.data["provenance"],"source":"repo/main@abc123","deployed_digest":"sha256:fixture-A","test_stages":["security-tests"]}
        self.assertTrue(provenance_decision(x,self.data["artifact_policy"])["permit"])
        self.assertFalse(provenance_decision({**x,"signature_verified_by_trusted_mechanism":False},self.data["artifact_policy"])["permit"])
    def test_local_database_tenant_and_capacity_invariants(self):
        r=database_demo()
        self.assertEqual(r["tenant_A_own_job"],["ready"])
        self.assertIsNone(r["tenant_A_other_job"])
        self.assertEqual(r["conditional_reservations_succeeded"],[1,0])
        self.assertEqual(r["remaining"],0)


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test",action="store_true")
    parser.add_argument("--fixture",type=Path,default=HERE/"casebook_fixture.json")
    args=parser.parse_args()
    if args.self_test:
        result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Checks))
        raise SystemExit(0 if result.wasSuccessful() else 1)
    print(json.dumps(report(json.loads(args.fixture.read_text())),indent=2))
