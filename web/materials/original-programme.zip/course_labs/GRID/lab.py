#!/usr/bin/env python3
"""Offline GRID analytical lab. Standard library only; no sockets or device access.

PCAP subset: classic little-endian microsecond PCAP; Ethernet, unfragmented IPv4,
TCP data packets from one declared direction/connection, no SYN/FIN/sequence wrap.
The fixture omits a handshake and is not a captured real conversation. Reassembly
requires an explicit expected byte range and rejects gaps/conflicting overlaps.
PE-like fixture is inert/incomplete, never loaded or executed. Policy and dynamic
behaviour are deterministic models, not production controls or real malware.
"""
import argparse, hashlib, ipaddress, json, struct
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SEGMENTS=[{'seq':1008,'hex':'00100001'}, {'seq':1000,'hex':'0051000000060203'}, {'seq':1000,'hex':'0051000000060203'}, {'seq':1012,'hex':'005200000006020300110001'}]

def checksum(data):
    if len(data)%2:data+=b'\0'
    total=sum(struct.unpack('!%dH'%(len(data)//2),data))
    while total>>16:total=(total&65535)+(total>>16)
    return (~total)&65535

def frame(seq,payload,number):
    src=ipaddress.ip_address('192.0.2.10').packed;dst=ipaddress.ip_address('192.0.2.20').packed
    tcp=struct.pack('!HHIIBBHHH',40000,502,seq,2000,80,24,8192,0,0)
    pseudo=src+dst+struct.pack('!BBH',0,6,len(tcp)+len(payload))
    tcp=tcp[:16]+struct.pack('!H',checksum(pseudo+tcp+payload))+tcp[18:]
    ip=struct.pack('!BBHHHBBH4s4s',69,0,40+len(payload),number,0x4000,64,6,0,src,dst)
    ip=ip[:10]+struct.pack('!H',checksum(ip))+ip[12:]
    return bytes.fromhex('0200000000200200000000100800')+ip+tcp+payload

def capture_bytes(segments):
    out=bytearray(struct.pack('<IHHIIII',0xa1b2c3d4,2,4,0,0,65535,1))
    for n,s in enumerate(segments):
        packet=frame(s['seq'],bytes.fromhex(s['hex']),n)
        out+=struct.pack('<IIII',1789800000,n*10000,len(packet),len(packet))+packet
    return bytes(out)

def capture_segments(data):
    if len(data)<24:raise ValueError('Truncated PCAP header')
    magic,major,minor,_,_,snap,link=struct.unpack('<IHHIIII',data[:24])
    if (magic,major,minor,link)!=(0xa1b2c3d4,2,4,1):raise ValueError('Unsupported capture format')
    pos=24;result=[];connection=None
    while pos<len(data):
        if len(data)-pos<16:raise ValueError('Truncated record header')
        sec,usec,caplen,origlen=struct.unpack('<IIII',data[pos:pos+16]);pos+=16
        if usec>=1000000 or caplen!=origlen or caplen>snap or pos+caplen>len(data):raise ValueError('Incomplete/inconsistent capture record')
        packet=data[pos:pos+caplen];pos+=caplen
        if len(packet)<54 or packet[12:14]!=b'\x08\x00':raise ValueError('Unsupported Ethernet frame')
        ip=packet[14:];ihl=(ip[0]&15)*4
        if ip[0]>>4!=4 or ihl<20 or len(ip)<ihl:raise ValueError('Invalid IPv4 header')
        total=struct.unpack('!H',ip[2:4])[0];frag=struct.unpack('!H',ip[6:8])[0]
        if total>len(ip) or total<ihl+20 or ip[9]!=6 or frag&0x3fff:raise ValueError('Unsupported IP length/protocol/fragment')
        if checksum(ip[:ihl]):raise ValueError('IPv4 checksum mismatch')
        tcp=ip[ihl:total];off=(tcp[12]>>4)*4
        if off<20 or off>len(tcp) or tcp[13]&7:raise ValueError('Unsupported TCP header/SYN/FIN/RST')
        pseudo=ip[12:20]+struct.pack('!BBH',0,6,len(tcp))
        if checksum(pseudo+tcp):raise ValueError('TCP checksum mismatch; offload artefacts are outside this fixture')
        sport,dport,seq=struct.unpack('!HHI',tcp[:8]);key=(ip[12:16].hex(),sport,ip[16:20].hex(),dport)
        if connection is None:connection=key
        if key!=connection:raise ValueError('Only one declared direction/connection supported')
        result.append({'seq':seq,'hex':tcp[off:].hex(),'capture_time':sec+usec/1000000})
    return result

def reassemble(segments,start,end):
    if not 0<=start<end<2**32 or end-start>1000000:raise ValueError('Invalid/oversized explicit range; sequence wrap unsupported')
    seen={};identical_overlap=0
    for segment in segments:
        seq=segment['seq'];payload=bytes.fromhex(segment['hex'])
        if seq<start or seq+len(payload)>end:raise ValueError('Segment outside explicit expected range')
        for offset,value in enumerate(payload):
            at=seq+offset
            if at in seen:
                if seen[at]!=value:raise ValueError('Conflicting TCP overlap at sequence %d'%at)
                identical_overlap+=1
            seen[at]=value
    missing=[i for i in range(start,end) if i not in seen]
    if missing:raise ValueError('Capture gap begins at sequence %d'%missing[0])
    return bytes(seen[i] for i in range(start,end)),identical_overlap

def modbus_requests(stream):
    rows=[];pos=0
    while pos<len(stream):
        if len(stream)-pos<7:raise ValueError('Incomplete MBAP')
        tid,pid,length=struct.unpack('!HHH',stream[pos:pos+6])
        if pid!=0 or not 2<=length<=254 or pos+6+length>len(stream):raise ValueError('Invalid/incomplete MBAP length')
        adu=stream[pos:pos+6+length];pos+=6+length
        if adu[7]!=3 or len(adu)!=12:raise ValueError('Only complete function03 read requests are supported')
        start,quantity=struct.unpack('!HH',adu[8:12])
        if not 1<=quantity<=125 or start+quantity>65536:raise ValueError('Invalid read range')
        rows.append({'transaction':tid,'unit':adu[6],'function':3,'start':start,'quantity':quantity,'evidence':'request only; no acceptance or physical outcome supplied'})
    return rows

def pe_fixture():
    data=bytearray(0x600);data[:2]=b'MZ';struct.pack_into('<I',data,0x3c,0x80);data[0x80:0x84]=b'PE\0\0'
    struct.pack_into('<HHIIIHH',data,0x84,0x14c,1,0,0,0,0,0)
    struct.pack_into('<8sIIIIIIHHI',data,0x98,b'.text\0\0\0',0x200,0x1000,0x200,0x200,0,0,0,0,0)
    text=b'10.20.0.15\0diagnostic mode\0WriteProcessMemory\0INERT TRAINING DATA\0';data[0x320:0x320+len(text)]=text
    return bytes(data)

def pe_map(data,rva,length=1):
    if len(data)<64 or data[:2]!=b'MZ':raise ValueError('Missing bounded DOS header')
    off=struct.unpack_from('<I',data,0x3c)[0]
    if off+24>len(data) or data[off:off+4]!=b'PE\0\0':raise ValueError('Invalid/out-of-bounds PE signature')
    _,count,_,_,_,optional,_=struct.unpack_from('<HHIIIHH',data,off+4)
    section_start=off+24+optional
    if not 1<=count<=96 or section_start+40*count>len(data):raise ValueError('Invalid section table bounds')
    candidates=[]
    for i in range(count):
        name,virtual_size,va,raw_size,raw,*_=struct.unpack_from('<8sIIIIIIHHI',data,section_start+40*i)
        if va<=rva and rva+length<=va+raw_size:
            location=raw+rva-va
            if length<1 or location+length>len(data):raise ValueError('Raw mapping outside file')
            candidates.append({'section':name.rstrip(b'\0').decode('ascii'),'rva':rva,'file_offset':location,'bytes_hex':data[location:location+length].hex()})
    if len(candidates)!=1:raise ValueError('No unique stored-byte mapping; virtual-only/overlapping cases unsupported')
    return {'mapping':candidates[0],'limits':'Header/section mapping only. Inert incomplete fixture; no loader validity or behaviour claim.'}

def evaluate(event,approval):
    required={'event_id':str,'actor':str,'target':str,'operation':str,'time':int,'accepted':bool}
    if any(k not in event or type(event[k]) is not t for k,t in required.items()):raise ValueError('Invalid event schema')
    if not event['accepted']:return 'ATTEMPTED_REJECTED'
    if approval is None:return 'UNKNOWN'
    fields={'actor':str,'target':str,'operation':str,'start':int,'end':int}
    if any(k not in approval or type(approval[k]) is not t for k,t in fields.items()) or approval['start']>=approval['end']:raise ValueError('Invalid approval schema')
    match=all(event[k]==approval[k] for k in ('actor','target','operation')) and approval['start']<=event['time']<approval['end']
    return 'APPROVED' if match else 'VIOLATION'

def policy_fixture():
    approval={'actor':'eng1','target':'C1','operation':'project_transfer','start':90,'end':110}
    base={'event_id':'E1','actor':'eng1','target':'C1','operation':'project_transfer','time':100,'accepted':True}
    return [{'event':base,'approval':approval,'expected':'APPROVED'}, {'event':dict(base,event_id='E2',target='C2'),'approval':approval,'expected':'VIOLATION'}, {'event':dict(base,event_id='E3'),'approval':None,'expected':'UNKNOWN'}, {'event':dict(base,event_id='E4',time=110),'approval':approval,'expected':'VIOLATION'}, {'event':dict(base,event_id='E5',accepted=False),'approval':approval,'expected':'ATTEMPTED_REJECTED'}]

def run_policy(rows):
    seen={};results=[]
    for row in rows:
        event=row['event'];key=event.get('event_id');encoded=json.dumps(event,sort_keys=True)
        if key in seen:
            if seen[key]!=encoded:raise ValueError('Same event ID has conflicting content')
            results.append({'event_id':key,'result':'DUPLICATE_DELIVERY'});continue
        result=evaluate(event,row['approval']);seen[key]=encoded
        results.append({'event_id':key,'result':result,'expected':row.get('expected'),'matches_expected':result==row.get('expected')})
    return results

def simulate(run_id,config_present=True,end=60):
    # A benign event model: never executes arbitrary code, opens a socket or runs a subprocess.
    if not config_present:return {'run_id':run_id,'events':[{'t':0,'event':'config_missing'},{'t':1,'event':'exit','code':2}],'limits':'Synthetic model only'}
    events=[{'t':0,'event':'config_read','target':'203.0.113.10'},{'t':1,'event':'connection_attempt','result':'blocked_by_model'},{'t':2,'event':'report_write_model','name':'report.json'},{'t':3,'event':'scheduled_followup','due':600}]
    if end>=600:events.append({'t':600,'event':'followup_model','result':'recorded_only'})
    return {'run_id':run_id,'simulated_end':end,'events':events,'limits':'Benign model; no real network, malware execution or physical actions'}

def must_fail(fn):
    try:fn()
    except ValueError:return
    raise AssertionError('Expected validation failure did not occur')

def self_check():
    data=capture_bytes(SEGMENTS);segments=capture_segments(data);stream,overlap=reassemble(segments,1000,1024)
    assert overlap==8
    requests=modbus_requests(stream);assert [(r['transaction'],r['start']) for r in requests]==[(81,16),(82,17)]
    must_fail(lambda:reassemble(SEGMENTS+[{'seq':1006,'hex':'0206'}],1000,1024))
    must_fail(lambda:reassemble(SEGMENTS[1:],1000,1024))
    must_fail(lambda:capture_segments(data[:-1]))
    must_fail(lambda:capture_segments(data[:-1]+bytes([data[-1]^1])))
    must_fail(lambda:modbus_requests(stream[:-1]))
    pe=pe_fixture();assert pe_map(pe,0x1120)['mapping']['file_offset']==0x320
    malformed=bytearray(pe);struct.pack_into('<I',malformed,0x3c,0x1000);must_fail(lambda:pe_map(malformed,0x1120))
    must_fail(lambda:pe_map(pe,0x1400))
    rows=policy_fixture();assert all(r['matches_expected'] for r in run_policy(rows))
    assert run_policy(rows+[rows[0]])[-1]['result']=='DUPLICATE_DELIVERY'
    bad=dict(rows[0]['event'],target='C2');must_fail(lambda:run_policy(rows+[{'event':bad,'approval':rows[0]['approval']}]))
    bad=dict(rows[0]['event'],accepted='true');must_fail(lambda:evaluate(bad,rows[0]['approval']))
    assert len(simulate('R1')['events'])==4 and len(simulate('R3',end=600)['events'])==5
    assert simulate('R2',False)['events'][-1]['code']==2
    return {'status':'PASS','checks':['out-of-order reassembly','identical retransmission deduplication','conflicting overlap rejection','gap rejection','PCAP truncation/checksum rejection','MBAP framing','PE bounds/RVA mapping','policy approved/violation/unknown/end-exclusive/rejected states','duplicate/conflicting event IDs','schema type rejection','benign simulated branch timing'],'limits':__doc__}

def make_fixtures():
    files={'stream_segments.json':json.dumps({'provenance':'synthetic','start':1000,'end':1024,'segments':SEGMENTS},indent=2).encode(),'stream_synthetic.pcap':capture_bytes(SEGMENTS),'inert_pe_like.bin':pe_fixture(),'policy_cases.json':json.dumps(policy_fixture(),indent=2).encode()}
    report=[]
    for name,data in files.items():
        (ROOT/name).write_bytes(data);report.append({'file':name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
    return report

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['self-check','make-fixtures','reassemble','static','detect','simulate']);p.add_argument('--file',type=Path);p.add_argument('--end',type=int,default=60);p.add_argument('--missing-config',action='store_true');a=p.parse_args()
    if a.action=='self-check':result=self_check()
    elif a.action=='make-fixtures':result=make_fixtures()
    elif a.action=='reassemble':
        data=(a.file or ROOT/'stream_synthetic.pcap').read_bytes();stream,overlap=reassemble(capture_segments(data),1000,1024);result={'stream_hex':stream.hex(),'identical_overlap_bytes':overlap,'requests':modbus_requests(stream)}
    elif a.action=='static':result=pe_map((a.file or ROOT/'inert_pe_like.bin').read_bytes(),0x1120,16)
    elif a.action=='detect':result=run_policy(json.loads((a.file or ROOT/'policy_cases.json').read_text()))
    else:result=simulate('user-model-run',not a.missing_config,a.end)
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
