# GRID offline evidence laboratory

This original laboratory uses Python's standard library. It opens no sockets, captures no live traffic, sends no device commands and executes no malware. The supplied PCAP is generated synthetic traffic, the PE-like file is inert and incomplete, and the policy and dynamic traces are explicit models. The fifty `cases/GRID-Lxxx.json` files contain the independent case evidence and acceptance tasks for the course.

From the repository root:

```bash
python course_labs/GRID/lab.py self-check
python course_labs/GRID/lab.py reassemble
python course_labs/GRID/lab.py static
python course_labs/GRID/lab.py detect
python course_labs/GRID/lab.py simulate
python course_labs/GRID/lab.py simulate --end 600
python course_labs/GRID/lab.py simulate --missing-config
```

`make-fixtures` regenerates only the four named local training fixtures. Other commands read the fixtures or calculate in memory and print JSON. Save your actual outputs as your own evidence; the course does not record an unperformed run as complete.

## Exercise 1: TCP evidence and conflicting overlaps

Study `stream_segments.json` and predict the byte stream before running `reassemble`. The PCAP presents one direction with a split first request, out-of-order arrival, an identical retransmission and a second request. The explicit expected sequence interval is `[1000,1024)`.

Expected original result: eight identical overlapping bytes are deduplicated; transaction 81 reads one register at offset 16 on unit 2; transaction 82 reads one register at offset 17. These are requests only. No response, acceptance or physical action is supplied.

Independent work: import `lab` from a local Python script, copy `SEGMENTS`, remove the first segment, and call `reassemble` with the same expected range. Record the gap rejection. Then restore the data and append `{'seq':1006,'hex':'0206'}`. Record the conflicting-overlap rejection at sequence 1007. Explain why selecting whichever bytes arrive last would manufacture an unqualified interpretation. Finally truncate a copy of the PCAP by one byte and verify the decoder rejects it.

Acceptance: preserve the original fixture hash, your separate modified inputs, the actual error/output records and a paragraph separating capture facts from endpoint behaviour. Do not claim a real TCP conversation was observed: the synthetic PCAP has no handshake or complete bidirectional session. The decoder supports classic little-endian microsecond PCAP, Ethernet, unfragmented IPv4/TCP and one direction/connection only. It does not implement sequence wrap, SYN/FIN accounting, IP fragmentation, VLAN parsing, pcapng, checksum offload exceptions or production-scale stream management.

## Exercise 2: Inert PE-like structure

`inert_pe_like.bin` contains a DOS magic, an e_lfanew pointer, a PE signature, a minimal COFF/section description and invented strings. It has no optional executable header and is not a loadable program. Never rename or attempt to run it as an application.

Predict the mapping of RVA `0x1120`: `.text` begins at RVA `0x1000` and raw file offset `0x200`, so the result is `0x320`. Run `static` and verify the calculation. In a copied byte array, change e_lfanew to `0x1000`; the bounds check must reject it. Query RVA `0x1400` and explain the absence of a unique stored-byte mapping.

Acceptance: include arithmetic, original and malformed results, and a statement that strings such as `WriteProcessMemory` are not evidence of import-table membership, execution or injection. This is a header-mapping exercise, not a complete PE validator, signature verifier, disassembler or malware classifier.

## Exercise 3: Detection policy and independent expected results

Read `policy_cases.json` before `detect`. Predict E1=APPROVED, E2=VIOLATION, E3=UNKNOWN, E4=VIOLATION and E5=ATTEMPTED_REJECTED. The approval interval is start-inclusive and end-exclusive. Run the detector and compare its actual outputs with the predictions.

Independent work: add an event exactly at the start boundary; add a wrong actor; add a string `"true"` instead of Boolean `true`; replay an identical event ID; then reuse an ID with conflicting event content. Preserve each input and output. Explain the difference between an unknown approval feed, a known nonmatching approval and a rejected request. Review the function before changing the missing-approval return to APPROVED in a separate copy; explain which independent fixture catches that defect, then restore your copy.

Acceptance: correct boundary and unknown-state handling, explicit schema rejection, duplicate-delivery classification, conflicting-ID rejection, code/input versions and actual run results. This policy model has no identity server, work-order connector, production event source or enforcement API. Production coverage, feed freshness and operating authority remain external acceptance gates.

## Exercise 4: Benign dynamic model

Run the three `simulate` variants. The default model records a configuration read, a model-blocked connection attempt, a modelled report write and a scheduled follow-up at simulated second 600; it stops at second 60. Extending the simulated end to 600 records the follow-up branch. Missing configuration exits before the connection-attempt branch. No actual connection or unknown executable is run, and `report_write_model` is an event label, not a file-write operation.

Acceptance: distinguish scheduled from executed model branches, attempted from completed operations, and model traces from real execution. Create a run/provenance table and explain how a shared output folder in a real approved sandbox could contaminate attribution across runs.

## Practical route beyond this offline lab

Use separately authorised isolated Windows/Linux replicas to collect and correlate real authentication, process, service, file and network evidence. Use licensed vendor tools and an approved controller/HMI simulator or training rig to compare project/runtime identity, task schedules, I/O maps, force tables and retained state. Perform permitted protocol captures in that isolated environment with documented profiles, clocks and source quality. Real malware execution belongs only in an authorised specialist sandbox with verified isolation and no production credentials or routes.

Physical protection, cooling, electrical, commissioning and live operating decisions require the responsible discipline and site authority. Independently assess the actual alarm/freshness path, failover/fencing, trusted recovery, credentials and functional acceptance. Record real evidence for all nine lifecycle duties across the curriculum's D4–D7 scope, with integral D5 work and honest D2/D3 specialist boundaries. Passing these offline exercises or the course question bank is not a GIAC credential, a field authorisation or proof of physical competence.
