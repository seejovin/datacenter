"""Offline calculations and policy checks; never contacts a network or device."""
import argparse,copy,ipaddress,json,math
from pathlib import Path

def assess(x):
 findings=[];computed={}
 def need(ok,msg):
  if not ok:findings.append(msg)
 o=x['optics'];rx=o['tx_min_dbm']-o['loss_db']-o['repair_allowance_db'];margin=rx-o['sensitivity_dbm'];high=o['tx_max_dbm']-o['minimum_loss_db'];computed.update(rx_worst_dbm=rx,margin_db=margin,rx_best_dbm=high)
 need(margin>=o['required_margin_db'],'Optical sensitivity margin fails after repair allowance.')
 need(high<=o['overload_dbm'],'Best-case received power exceeds the overload bound.')
 s=x['serial']
 need(type(s['baud']) in (int,float) and s['baud']>0,'Serial baud must be a positive number.')
 if not(type(s['baud']) in (int,float) and s['baud']>0):return computed,findings
 tx=(s['request_chars']+s['response_chars'])*s['bits_per_char']/s['baud']+s['turnaround_s'];cycle=tx*s['devices']+s['fault_budget_s'];computed.update(serial_transaction_s=tx,serial_cycle_s=cycle)
 need(cycle<=s['freshness_limit_s'],'The modeled serial poll cycle exceeds freshness after the allowed fault budget.')
 need(s['baud']>0 and s['bits_per_char'] in (10,11,12),'Serial format assumptions are invalid for this exercise.')
 need(x['rf']['measured_p999_ms']<=x['rf']['required_p999_ms'],'RF application tail latency fails; a lower percentile cannot substitute.')
 need(x['nac']['effective_role']==x['nac']['authorized_role'],'NAC effective enforcement differs from current authorization.')
 need(x['nac']['server_certificate_validation'] is True,'The supplicant must validate the authentication server.')
 need(x['telemetry']['source_age_s']<=x['telemetry']['max_age_s'],'Controls measurement is stale.')
 need(x['telemetry']['quality_preserved'] is True,'Do not discard the measurement quality flag.')
 allowed=ipaddress.ip_network('10.10.0.0/16')
 need(x['customer_exports']==[str(allowed)],'The customer export policy must match the exact authorized prefix.')
 need(len(set(x['path_failure_domains']))>=2,'Nominal paths still share one modeled failure domain.')
 return computed,findings

def self_test():
 good=json.loads((Path(__file__).parent/'solution.json').read_text());assert not assess(good)[1]
 mutations=[('serial','baud',0),('optics','repair_allowance_db',3),('serial','fault_budget_s',1),('rf','measured_p999_ms',140),('nac','effective_role','production'),('nac','server_certificate_validation',False),('telemetry','source_age_s',1200),('telemetry','quality_preserved',False)]
 for branch,key,value in mutations:
  bad=copy.deepcopy(good);bad[branch][key]=value;assert assess(bad)[1],(branch,key)
 bad=copy.deepcopy(good);bad['customer_exports'].append('0.0.0.0/0');assert assess(bad)[1]
 bad=copy.deepcopy(good);bad['path_failure_domains']=['shared-switch','shared-switch'];assert assess(bad)[1]
 print('11 meaningful model checks passed; no RF, optical or vendor measurement was performed.')

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('proposal',nargs='?',default=str(Path(__file__).parent/'starter.json'));p.add_argument('--self-test',action='store_true');a=p.parse_args()
 if a.self_test:self_test()
 else:
  computed,findings=assess(json.loads(Path(a.proposal).read_text()));print(json.dumps({'model_pass':not findings,'computed':computed,'findings':findings,'claim_limit':'Synthetic calculations and supplied-state checks only.'},indent=2));raise SystemExit(bool(findings))
