# Independent network-engineering workbooks

The course has separate campus,edge,wireless/NAC,hybrid,AI,controls,storage andoperations branches. Each needs its own acceptance evidence. Passing one data-center fabric lab does not close the other branches.

## Offline constraint exercise

Run with Python3.10+:

```bash
python course_labs/NETWORK-ENGINEERING/check.py course_labs/NETWORK-ENGINEERING/starter.json
python course_labs/NETWORK-ENGINEERING/check.py --self-test
```

The checker uses no network access and no external packages. It calculates optical margins and serial polling time, then checks supplied RF,NAC,telemetry,route-policy andfailure-domain facts. The values are synthetic training data. Do not edit an observed latency or source timestamp merely to make a check pass; propose the engineering intervention and explain what new measurement would be needed. `solution.json` describes one conforming hypothetical state, not an executed physical repair.

For each finding, submit the requirement,calculation/observation,mechanism,narrow correction,negative test andrecovery test. Explain all units. The optical model does not measure actual loss; the serial model omits some real timing effects; the RF value is a supplied scenario percentile,not a survey.

## Branch-specific implementation evidence

| Branch | Minimum independent implementation evidence |
|---|---|
| Media | Supported optic/cable/lane selection,calibrated loss/physical tests,error/FEC observations andactual route diversity |
| Campus | Multi-area/dual-stack routing,loop/first-hop protection,DHCP/DNS/multicast correctness,forbidden-prefix tests andmaintenance recovery |
| Edge/PoP | Isolated multi-AS import/export policy,leak rejection,next-hop recursion,carrier boundary evidence andsurviving application path |
| Wireless | Real site/client survey,loaded capacity,roaming event trace,AP/controller loss andnew-client admission |
| NAC/AAA | Mutual certificate trust,role enforcement,CoA/reauthentication,revocation/outage behavior andaccountable emergency access |
| Hybrid | Actual client DNS path,route domain,NAT tuple,policy andreturn-path trace; tunnel rekey andfailure |
| AI | Supported host/NIC/firmware stack,RDMA errors/locality,RoCE congestion,independent IB partition/manager/link tests andrepresentative collectives |
| Controls | Serial physical/timing checks,protocol identity/quality/freshness,time distribution andsafe modeled/authorized command tests |
| Storage | Separate FC andIP-storage identity/access,multipath,deadline andintegrity evidence |
| Operations | Sustained checks,planned change,unknown fault,trusted restore andmeasured improvement withindependent review |

Use the course's focused component chapters for topology,requirements,commands orpolicy traces andfault cases. Read-only command examples are version-dependent andwere not executed on vendor hardware during authoring. Capture actual output in your own lawful lab andretain raw evidence alongside parsed summaries.

## Evidence rules

Record environment type,hardware/software versions,topology,authority,clock quality,actual commands/API requests,results andassistance. Distinguish a forecast,a model,an emulator result,a physical measurement andproduction observation. Do not claim measured gigabit throughput from a capacity calculation. Do not claim electrical/RF/controls competence from a packet-only emulator. Each independent task has explicit acceptance criteria; a question score reinforces knowledge but does not replace the task.
