# DCCA analytical workbook

This is a synthetic, offline exercise. It never connects to a facility. Work the problems by hand before using the checker.

1. Read `scenario.json`. For each quantity, state the formula, units and assumptions in a separate review note.
2. Calculate the current on the one surviving rack feed. Decide whether the supplied 32 A limit passes. Do not select a conductor or breaker from this exercise.
3. Integrate the unequal-duration load profile. Explain why a simple average of the two power values is wrong.
4. Calculate UPS margin after the stated module loss. Identify a shared dependency that this arithmetic does not evaluate.
5. Calculate battery source energy. List the supplier discharge and condition information still required for a runtime claim.
6. Calculate ideal air and liquid flow, residual air heat and usable fuel autonomy. Explain the difference between calculated demand and delivered physical performance.
7. Complete the optical loss budget and identify the separate overload and polarity checks.
8. Compare PUE before and after consolidation. Explain how total energy falls while PUE worsens.
9. Trace the high-alarm state through every sample using activation and clearing thresholds. Acknowledge that this model does not include persistence delay or sensor faults.
10. Copy `answers-template.json` to a new filename and replace null values. Run `python workbook.py --check your-answers.json` from this directory. Values have a 0.5% numerical tolerance; boolean decisions must be exact.

`python workbook.py --demo` prints a reference only after an independent attempt. Arithmetic success does not establish field competence. Submit the calculation sheet and a claim-limit paragraph, not just a green checker result.

Acceptance: correct dimensions, all stated limits checked, unknown requirements identified, and no analytical result described as a physical measurement. For stronger evidence, repeat selected tasks using approved vendor tools or supervised measurements and retain those as separate evidence categories.
