# DCCA authored coverage and evidence limits

Public scope checked: Schneider Electric University, 19 September 2026. The public page identifies seven broad physical-infrastructure areas; it does not provide an item-level examination blueprint or weights. This independently authored course therefore maps to the published subject scope and does not claim provider equivalence or endorsement.

| Public area | Authored chapters |
|---|---|
| Power | 2–7, with electrical quantities, distribution, UPS modes, stored energy, generators and failure-state independence |
| Cooling | 8–11, with heat balance, air distribution, moisture and liquid interfaces |
| Racks | 12, with installation constraints and serviceability |
| Cabling | 13–15, with copper, optics, loss budgets, routes and administration |
| Fire protection | 16–17, with detection chains, suppression interfaces and controlled response |
| Physical security | 18–19, with access lifecycle, surveillance and evidence |
| Management | 1 and 20–25, with dependencies, monitoring, alarms, capacity, change, efficiency, cost and recovery |

The course contains 25 chapters, 500 independently authored single-answer questions, worked examples, guided exercises, 25 independent analytical tasks and 125 recall cards. There is no question multiplication from numeric variants or cross-case option pools. Ninety-four implausible distractors across DCCA/CDCP were replaced during the editorial pass; continued independent review is appropriate for an authored bank of this size.

The offline workbook exercises current, energy, capacity, air/liquid heat balance, fuel duration, optical margin, PUE and alarm hysteresis. Its Python arithmetic and state checks were executed during authoring. All supplied records are synthetic. The checker does not demonstrate equipment performance, award DCCA or authorize facility interventions.

The complete current Schneider learning programme and provider examination process remain external requirements. The detailed exam weighting, proprietary course content and psychometric behavior of this original bank have not been independently verified. A 500-question count is a practice resource, not a probability-of-passing guarantee.

Power and cooling instruction here supports near-term systems integration. It does not claim the later complete D2/D3 specialist engineering capability. D1 is excluded from owned engineering; building and fire-barrier interfaces remain dependencies requiring qualified evidence.
