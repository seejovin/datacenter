"""Offline analytical workbook. No network or equipment interaction."""
import argparse,json,math,pathlib
HERE=pathlib.Path(__file__).resolve().parent

def solve(d):
    p=d['power']; u=d['ups']; b=d['battery']; a=d['air']; l=d['liquid']; f=d['fuel']; o=d['optical']; e=d['pue']
    active=False; states=[]
    for value in d['alarm']['values_c']:
        if not active and value>=d['alarm']['activate_c']: active=True
        elif active and value<=d['alarm']['clear_c']: active=False
        states.append(active)
    current=p['servers']*p['server_watts']/(p['voltage_v']*p['power_factor'])
    return {
      'single_feed_current_a': current,
      'single_feed_within_supplied_limit': current<=p['single_feed_limit_a'],
      'energy_kwh': sum(x['kw']*x['hours'] for x in d['energy']),
      'ups_remaining_margin_kw': (u['modules']-u['unavailable'])*u['module_kw']-u['load_kw'],
      'battery_source_kwh': b['load_kw']*b['duration_minutes']/60/b['delivery_efficiency'],
      'airflow_m3_s': a['heat_kw']/(a['density_kg_m3']*a['cp_kj_kg_k']*a['rise_k']),
      'liquid_flow_kg_s': l['captured_kw']/(l['cp_kj_kg_k']*l['rise_k']),
      'residual_air_kw': l['rack_kw']-l['captured_kw'],
      'fuel_hours': (f['gross_l']-f['unusable_l']-f['reserve_l'])/f['consumption_l_h'],
      'optical_headroom_db': o['tx_min_dbm']-o['rx_sensitivity_dbm']-o['fiber_loss_db']-o['connection_loss_db']-o['reserve_db'],
      'pue_before': (e['it_before_mwh']+e['overhead_before_mwh'])/e['it_before_mwh'],
      'pue_after': (e['it_after_mwh']+e['overhead_after_mwh'])/e['it_after_mwh'],
      'absolute_energy_saving_mwh': e['it_before_mwh']+e['overhead_before_mwh']-e['it_after_mwh']-e['overhead_after_mwh'],
      'alarm_active_sequence': states,
    }

def check(expected, supplied):
    errors=[]
    if not isinstance(supplied,dict):return ['Submission must be a JSON object.']
    if set(supplied)!=set(expected):errors.append('Submission keys must exactly match the answer template.')
    for key,target in expected.items():
        value=supplied.get(key)
        if isinstance(target,bool): ok=type(value) is bool and value is target
        elif isinstance(target,list):ok=isinstance(value,list) and all(type(x) is bool for x in value) and value==target
        else:ok=type(value) in (int,float) and math.isfinite(value) and math.isclose(value,target,rel_tol=0.005,abs_tol=0.001)
        if not ok: errors.append(key+': revise the result or type; show your calculation in the review note.')
    return errors

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--demo',action='store_true');parser.add_argument('--check',type=pathlib.Path);args=parser.parse_args()
    expected=solve(json.loads((HERE/'scenario.json').read_text()))
    if args.demo:print(json.dumps({'evidence_type':'computed synthetic reference, not measured facility performance','answers':expected},indent=2));return
    if args.check:
        supplied=json.loads(args.check.read_text());errors=check(expected,supplied)
        print(json.dumps({'arithmetic_pass':not errors,'errors':errors,'claim_limit':'This checks supplied analytical results only, not practical competence or operating authorization.'},indent=2));raise SystemExit(bool(errors))
    print('Read README.md and scenario.json. Complete answers-template.json independently. Use --check your-answers.json. Use --demo only after your attempt.')
if __name__=='__main__':main()
