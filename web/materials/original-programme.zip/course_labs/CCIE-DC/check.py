"""Offline engineering-state validator. No network access or vendor emulation."""
import argparse, copy, ipaddress, json
from pathlib import Path

def assess(state):
    errors=[]
    def require(condition, message):
        if not condition: errors.append(message)
    require(state.get('environment') == 'synthetic_model', 'Label this artifact synthetic_model; it is not hardware evidence.')
    required_mtu=1500+14+8+8+20
    for path in state.get('underlay_paths',[]):
        require(path.get('vtep_route') is True, f"{path.get('id')}: VTEP route is missing.")
        require(path.get('ip_mtu',0)>=required_mtu, f"{path.get('id')}: outer IP MTU must carry the modeled {required_mtu} bytes.")
    require(len(state.get('underlay_paths',[]))>=2, 'Provide at least two transport paths.')
    require(set(state.get('blue_import_rts',[]))=={'65000:50100'}, 'BLUE import must match only its approved route target.')
    require(set(state.get('red_import_rts',[]))=={'65000:50200'}, 'RED import must match only its approved route target.')
    require(state.get('blue_export_rt')=='65000:50100', 'BLUE export target does not match intended membership.')
    approved={('Web','App','tcp',443),('App','DB','tcp',5432)}
    actual={tuple(x)for x in state.get('contracts',[])}
    require(actual==approved, 'Contract matrix must contain exactly the two approved service relationships.')
    require(state.get('boot_lun')==7, 'Boot policy must select the assigned LUN7.')
    require(state.get('array_initiator')==state.get('host_wwpn'), 'Array masking must match the current approved host WWPN.')
    require(state.get('host_wwpn')=='20:00:00:00:00:00:00:11', 'Do not solve masking by inventing a new host identity.')
    require(state.get('monitoring_role')=='read_only', 'Monitoring must not retain configuration authority.')
    require(state.get('telemetry_max_age_s',99999)<=30, 'The proposed freshness limit exceeds the required30 seconds.')
    require(state.get('measured_recovery_s',99999)<=5, 'Supplied recovery observation exceeds the required5 seconds.')
    require(state.get('data_checksum_before')==state.get('data_checksum_after') and bool(state.get('data_checksum_before')), 'The modeled data integrity result fails.')
    for prefix in state.get('customer_exports',[]):
        try: allowed=ipaddress.ip_network(prefix)==ipaddress.ip_network('10.10.0.0/16')
        except ValueError: allowed=False
        require(allowed, f'Unauthorized customer export: {prefix}')
    require(state.get('customer_exports')==['10.10.0.0/16'], 'The required customer route must remain advertised.')
    return errors

def self_test():
    good=json.loads((Path(__file__).parent/'solution.json').read_text())
    assert not assess(good)
    changes=[('blue_import_rts',['65000:50100','65000:50200']),('boot_lun',0),('monitoring_role','admin'),('customer_exports',['0.0.0.0/0']),('measured_recovery_s',12),('data_checksum_after','changed')]
    for key,value in changes:
        bad=copy.deepcopy(good);bad[key]=value
        assert assess(bad),key
    bad=copy.deepcopy(good);bad['underlay_paths'][1]['ip_mtu']=1500
    assert assess(bad)
    bad=copy.deepcopy(good);bad['underlay_paths'][1]['vtep_route']=False
    assert assess(bad)
    print('9 meaningful model checks passed; no vendor platform was contacted.')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('proposal',nargs='?',default=str(Path(__file__).parent/'starter.json'));p.add_argument('--self-test',action='store_true');a=p.parse_args()
    if a.self_test:self_test()
    else:
        errors=assess(json.loads(Path(a.proposal).read_text()))
        print(json.dumps({'model_pass':not errors,'findings':errors,'claim_limit':'Static synthetic-state checks only; not a Cisco configuration parser, lab execution result or certification readiness score.'},indent=2))
        raise SystemExit(bool(errors))
