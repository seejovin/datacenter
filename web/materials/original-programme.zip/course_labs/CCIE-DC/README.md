# Expert integration workbook

This workbook has two distinct evidence routes. The runnable Python exercise validates an authored **synthetic state model**. The vendor route uses lawful supported Cisco lab equipment and the course's implementation walkthroughs. Passing the model does not establish hardware operation or CCIE readiness.

## Requirements

- BLUE and RED remain isolated. BLUE uses RT65000:50100; RED uses65000:50200. No cross-tenant import is authorized.
- Two usable underlay paths carry an ordinary1500-byte innerIPv4 packet over Ethernet/VXLAN/UDP/outerIPv4. Model outerIP size as1550bytes, with the assumptions explicitly retained.
- Web may reach App onTCP443; App may reach DB onTCP5432. No permit-all workaround is allowed.
- The approved initiator WWPN ending11 boots from assignedLUN7. Do not invent a new identity to bypass masking.
- Monitoring is read-only; current telemetry may be no older than30seconds.
- Recovery must be within5seconds with unchanged expected data. In the model these are supplied synthetic observations, not measurements you may relabel as real.
- The customer exports only10.10.0.0/16. No experimental public routing is permitted.

## Run the analytical exercise

Use Python3.10+ and no third-party packages:

```bash
python course_labs/CCIE-DC/check.py course_labs/CCIE-DC/starter.json
python course_labs/CCIE-DC/check.py --self-test
```

Copy `starter.json` to your own proposal. Read the requirements and diagnose each finding. For every edit, write the failed dependency, the evidence, the narrow correction and the positive/negative verification. Do not change supplied recovery observations merely to pass: propose the engineering work and collect new **synthetic scenario** evidence separately. `solution.json` is an instructor reference showing a conforming hypothetical final state, not proof of an executed repair.

The checker deliberately covers multiple independent constraints. It can reject a broad RT import, a missing route, insufficient modeled MTU, wrong boot identity, excess privilege, stale data, slow recovery, changed checksum or unauthorized export. It does not parse Cisco CLI, emulate APIC/UCS/MDS, verify every blueprint topic or contact any device.

## Supported-platform implementation route

1. Record exact Nexus/APIC/UCS/MDS hardware and software. Compare with the current Cisco practical equipment baseline and each feature's support matrix. The official v3.1 leaf-objective page could not be retrieved during authoring; reconcile it before claiming complete exam coverage.
2. Build separate component labs for underlay/EVPN, vPC, ACI attachment/contracts, UCS identity/boot and FC access. Use the course's actual dependency and output interpretation walkthroughs.
3. Capture raw command/API output before normalizing it. Mark source device,time,clock quality and observation scope.
4. Introduce only authorized isolated faults. Initial drills use one fault; independent assessment combines two or more unfamiliar faults.
5. Validate application function, isolation, degraded capacity, recovery and data integrity. Preserve the last accepted checkpoint and an independent console path.
6. Have a reviewer compare evidence with the requirements and record assistance, untested branches and fidelity limits.

## Original timed practice

The eight-hour allocation in the course is an original training design, not Cisco's task distribution or scoring. Use60minutes for requirements/design,180 for component builds,120 for integrated faults,60 for automation/assurance and60 for recovery/closeout. Report incomplete tasks honestly at expiry. A quiz score or local model pass never awards a provider credential or operating authority.
