# CISSP assessment and operations evidence laboratory

This offline laboratory accompanies chapters 26–34. It uses original synthetic records to make assessment, detection, custody, change and recovery reasoning inspectable. It has no network client, device connection, vulnerability scanner, exploit, patch installer or live restoration function. Running it does not establish a real organization's control effectiveness, legal admissibility or certification readiness.

Use Python 3.10 or later. The code uses only the standard library. From the project root:

```bash
python course_labs/CISSP-D67/evidence_lab.py fixtures
python course_labs/CISSP-D67/evidence_lab.py demo
python course_labs/CISSP-D67/evidence_lab.py selftest
```

The supplied fixture file and demonstration output are also retained as `synthetic_fixtures.json` and `synthetic_demo.json`. The authoring run executed all 29 unit tests successfully. Those tests check the local functions' stated behavior. They do not validate external sensors, a backup product or a real incident process.

For experiments, import `evidence_lab.py` from this directory using an ordinary Python interpreter. `fixtures()` returns a new dictionary, so change a local copy rather than modifying the evidence record you intend to retain. Preserve each prediction, changed input, observed output and conclusion. State whether a result is a calculated fact, a model assumption or an untested operational claim.

## Exercise 1: coverage is not a completion counter

The population contains `GW-A`, `GW-B` and `GW-C`. A has authenticated assessment evidence, B has only unauthenticated evidence, and C has no observation. Call `assessment_coverage(population, observations)` and explain each output.

The correct conclusion is one authenticated asset, one unauthenticated asset and one missing observation. It is not “two clean gateways” and not complete authenticated coverage. The result does not itself say that either observed gateway is secure; it describes the supplied observation scope.

Add a record for `GW-Z`, which is not in the authorized population. The function should reject it. Add a duplicate observation for A and explain why the function refuses to silently count it twice. Then create a legitimate observation for C and compare the result. Decide what external evidence would be needed to establish that the population itself is complete.

**Independent challenge:** create a population with distinct production, recovery and unsupported-device classes. Design a sample that includes the relevant classes and explain which conclusion can and cannot be generalized. A random choice from an incomplete inventory does not correct the inventory.

## Exercise 2: choose the metric's denominator

Call `confusion_metrics(16, 24, 4, 956)`. The parameters are true positives, false positives, false negatives and true negatives. The output expresses ratios as fractions, not percentages.

Expected calculations:

| Metric | Calculation | Result |
|---|---|---|
| Precision | 16 / (16 + 24) | 40% |
| Recall | 16 / (16 + 4) | 80% |
| False-positive rate | 24 / (24 + 956) | About 2.45% |
| Accuracy | (16 + 956) / 1,000 | 97.2% |

Explain why an apparently high accuracy does not remove the analyst workload associated with 24 false alerts or the consequence of four missed malicious cases. Add more true negatives without changing the other counts. Observe which metrics change and why; do not call the changed accuracy an improvement in detection of malicious cases.

An empty labeled population returns `None` for undefined ratios. Zero observations do not justify 100% success. Negative counts, fractional counts and booleans are rejected. Explain why Python's treatment of booleans as a subtype of integers would be dangerous if the validation used only `isinstance(value, int)`.

**Independent challenge:** propose a decision threshold for a defined service using false-positive cost, false-negative consequence and collection coverage. State the evaluation population and label uncertainty. Do not optimize a metric without naming the operational decision it supports.

## Exercise 3: byte integrity and custody are different claims

`digest_matches` compares supplied bytes with a trusted recorded SHA-256 digest. First compare unchanged bytes, then alter the payload without changing the recorded digest. Record the differing results.

Now inspect `custody_report`. The fixture records acquisition by `collector-A` and a later transfer from A to `analyst-B`. Replace the releasing custodian with an unrecorded person. The report should identify the inconsistent transfer even though an independently checked payload could still have matching bytes. Move a transfer before acquisition and observe the separate chronological defect.

Neither function proves that the original source recorded the truth, that collection was authorized or that evidence is legally admissible in a particular proceeding. The custody function evaluates the supplied record's consistency; an entirely fabricated but internally consistent record would still require external authenticity evidence. Explain this boundary in the report.

**Independent challenge:** design a complete evidence manifest and acquisition/transfer procedure for an authorized synthetic gateway investigation. Include source identity, collection method, tool version, clock context, hashes, original/working-copy handling, authorized custodians and restrictions. Record a missing transfer honestly and specify how it would be investigated; do not backdate a replacement.

## Exercise 4: normalize time without erasing the source

The fixture's login is at `09:00:00Z`; its configuration write is at `11:01:00+02:00`. After normalization, the write is at `09:01:00+00:00`, one minute after login. Read both the normalized value and the preserved original record.

Remove the offset from one timestamp. The function rejects the event because it cannot responsibly infer the timezone. Duplicate an event ID; the function also rejects that ambiguous duplicate instead of counting it as another independent event. A real system may need deduplication or update semantics, but those rules must be designed rather than guessed.

Change the fixture's `actor_id` field to `principal_id`. The parser should reject the changed schema. A heartbeat can remain current while every consequential event is rejected for exactly this kind of schema change. Silently dropping the event and reporting no administrative activity would convert a collection failure into a false security conclusion.

**Independent challenge:** implement a version-aware parser that accepts two explicitly documented schemas. If both actor fields are present and disagree, return an error requiring investigation. Preserve the original event and record which schema interpretation was applied. Test one valid record per schema, a conflict, a missing field and an unsupported version.

## Exercise 5: observe a pipeline's health limits

`source_status` examines only the supplied timestamp and parser-error count. A recent source with no parser errors returns `collection_current`; it does not return “secure.” A stale source, future timestamp or nonzero parser-error count returns `unknown` with a reason.

Demonstrate all four cases. Explain why a future timestamp can make a naive age check falsely regard a source as fresh. Explain why a heartbeat is insufficient proof that the security-event category is enabled. The function cannot discover events never generated or sensors outside its supplied inventory.

**Independent challenge:** extend the model with an expected source population and sequence-gap reporting. Keep availability, successful parsing and detection coverage separate in the output. Write a report for a period where raw events were retained but the parser failed, including recovery of evidence and the remaining response-time limitation.

## Exercise 6: verify a recovery chain before claiming a recovery point

The synthetic backup manifest contains full `F0`, incremental `I1`, incremental `I2` and differential `D2`. `I2` depends on I1, which depends on F0. D2 identifies F0 as its full baseline. The content is teaching text, not a real backup format.

Calling `restore_chain` for I2 should produce `F0, I1, I2`. Calling it for D2 should produce `F0, D2`. Remove I1 and explain why I2 cannot supply the missing changes. Alter I1's payload without replacing its digest and observe the integrity failure. Remove the fictional key identifier `LAB-K1` from the available-key set and observe the unavailable recovery dependency. Create a parent cycle and verify that it is rejected.

For incident time 12:00 UTC and recovery point 11:20 UTC, point age is forty minutes. Against a fifteen-minute RPO, the gap is twenty-five minutes. Scheduled job frequency is not an input to this achieved-point calculation.

The function checks a manifest, digests and supplied key availability. It explicitly reports that no actual restoration occurred and that application consistency and cleanliness remain unproven. The key identifier is a fictional label; no secret is stored in the fixture. A production recovery workflow would need to verify actual protected key access, restore the data, assess compromise scope and validate the resulting service.

**Independent challenge:** add a bounded report of the newest valid candidate point when a later chain is broken. Preserve the distinction between a fallback point being usable under the model and meeting the service's RPO. Do not silently accept extra data loss or label a manifest validation as a restore test.

## Exercise 7: a validated plan still is not execution

`change_gate` compares a plan with an authorized target set and an observed inventory entry. The fixture binds `GW-A` to `LAB-SERIAL-A`, expects version `1.0` and proposes `1.1`. Its approval, capacity and recovery flags are supplied assertions.

Change the serial to represent a replaced or misidentified device. Change the expected current version to represent a stale plan. Change a boolean gate to the string `"true"`. Remove verification of the recovery plan. Each case should be rejected for a different reason.

The valid result is eligibility for the authorized reviewed workflow, with `executed: false`. No API call, shell command or installation is performed. Also note that a caller could falsely supply `approval: true`; this offline function does not authenticate an approver or measure actual spare capacity. Specify what the real workflow must use as trustworthy evidence for each assertion.

**Independent challenge:** design per-target reconciliation for eight completed and two failed installations. Identify which actions are safe to retry, how the actual running versions will be read and what condition triggers rollback or another recovery path. Include an incompatible schema migration for which uninstalling the package is not sufficient.

## Exercise 8: physical and personnel decisions remain operational

Use chapter 34's supplier visit as a tabletop. The approved work covers a sensor in tenant A, but the temporary badge and remote role both exceed that scope. One participant represents the service owner, one facilities operations, one security and one the supplier coordinator. Assign real responsibilities without pretending that one role has every specialist competence.

Record the permitted work, required supervision, allowed/denied physical and logical actions, media/photo handling and revocation at completion. Inject an unexpected MFA prompt, a lost maintenance device and an ambiguous duress report as separate events. For each, identify known facts, personal-safety concerns, response authority and the information needed for the next decision.

The tabletop can demonstrate reasoning and communication. It cannot establish actual door egress behavior, physical protection operation or a production response time. Any physical validation must use the competent authorized personnel, applicable design and required controls.

## Acceptance and portfolio evidence

For each exercise, retain a prediction, original fixture, changed input, observed output and an explanation of the claim supported. Include negative cases and unresolved limitations. Add at least four meaningfully new independent tests selected by an assessor, rather than only changing names or numbers in existing cases.

For the operational portfolio, extend the analysis with authorized real control evidence or a supported representative lab. Demonstrate the actual source-to-alert path, a witnessed access revocation, a bounded approved change and a real restoration/validation where your role and environment permit it. Keep synthetic, simulated and observed evidence clearly distinguished. Completion of this lab does not award a credential or replace provider eligibility, experience, examinations or independent competence review.
