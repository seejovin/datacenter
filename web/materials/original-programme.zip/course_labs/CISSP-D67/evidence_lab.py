#!/usr/bin/env python3
"""Offline evidence reasoning exercises; no network access or system mutation.

All supplied records are synthetic. This validates local decision logic, not
forensic admissibility, deployed control effectiveness or actual recovery.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import math
import unittest
from datetime import datetime, timezone


class ValidationError(ValueError):
    """The supplied teaching record cannot support the requested calculation."""


def utc(value):
    if not isinstance(value, str):
        raise ValidationError('Timestamp must be text with an explicit UTC offset')
    try:
        result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    except ValueError as exc:
        raise ValidationError('Invalid timestamp') from exc
    if result.tzinfo is None or result.utcoffset() is None:
        raise ValidationError('Naive timestamp: timezone cannot be inferred')
    return result.astimezone(timezone.utc)


def nonnegative_integer(value, label):
    if type(value) is not int or value < 0:
        raise ValidationError(label + ' must be a nonnegative integer')
    return value


def confusion_metrics(tp, fp, fn, tn):
    """Ratios are fractions. Undefined denominators produce None, not 100%."""
    counts = {k: nonnegative_integer(v, k) for k, v in
              zip(('tp', 'fp', 'fn', 'tn'), (tp, fp, fn, tn))}
    ratio = lambda n, d: n / d if d else None
    return {**counts, 'precision': ratio(tp, tp + fp),
            'recall': ratio(tp, tp + fn),
            'false_positive_rate': ratio(fp, fp + tn),
            'accuracy': ratio(tp + tn, tp + fp + fn + tn)}


def assessment_coverage(population, observations):
    """Separate submitted observations, missing assets and authenticated depth."""
    if len(set(population)) != len(population) or not all(isinstance(x, str) and x for x in population):
        raise ValidationError('Population needs unique nonempty stable IDs')
    allowed = set(population)
    seen = {}
    for item in observations:
        if not isinstance(item, dict) or set(item) != {'asset_id', 'depth'}:
            raise ValidationError('Observation requires asset_id and depth')
        asset = item['asset_id']
        if asset not in allowed or asset in seen:
            raise ValidationError('Unexpected or duplicate assessment asset')
        if item['depth'] not in {'authenticated', 'unauthenticated', 'not_assessed'}:
            raise ValidationError('Unsupported depth status')
        seen[asset] = item['depth']
    return {'population': len(population),
            'authenticated': sum(v == 'authenticated' for v in seen.values()),
            'unauthenticated': sum(v == 'unauthenticated' for v in seen.values()),
            'explicitly_not_assessed': sum(v == 'not_assessed' for v in seen.values()),
            'missing_observations': sorted(allowed - set(seen)),
            'full_authenticated_coverage': bool(population) and all(seen.get(x) == 'authenticated' for x in population)}


def digest_matches(payload, expected):
    if not isinstance(payload, bytes) or not isinstance(expected, str):
        raise ValidationError('Digest comparison requires bytes and a hex string')
    if len(expected) != 64 or any(x not in '0123456789abcdef' for x in expected):
        raise ValidationError('Expected a lowercase SHA-256 digest')
    return hashlib.sha256(payload).hexdigest() == expected


def custody_report(evidence_id, collector, acquired_at, transfers):
    """Validate recorded continuity, not whether unobserved transfers occurred."""
    if not all(isinstance(x, str) and x for x in (evidence_id, collector)):
        raise ValidationError('Evidence and collector identifiers are required')
    last_time, current = utc(acquired_at), collector
    gaps = []
    for position, transfer in enumerate(transfers, 1):
        fields = {'evidence_id', 'from', 'to', 'time', 'purpose'}
        if not isinstance(transfer, dict) or set(transfer) != fields:
            raise ValidationError('Incomplete transfer record')
        if not all(isinstance(transfer[x], str) and transfer[x] for x in fields):
            raise ValidationError('Transfer values must be nonempty strings')
        when = utc(transfer['time'])
        if transfer['evidence_id'] != evidence_id:
            gaps.append(f'transfer {position}: wrong evidence identity')
        if transfer['from'] != current:
            gaps.append(f'transfer {position}: releasing custodian does not match prior record')
        if when < last_time:
            gaps.append(f'transfer {position}: time precedes prior custody record')
        current, last_time = transfer['to'], when
    return {'evidence_id': evidence_id, 'recorded_current_custodian': current,
            'recorded_chain_consistent': not gaps, 'gaps': gaps,
            'proves_source_truth_or_legal_admissibility': False}


def normalize_events(records):
    """Normalize the exact teaching schema while retaining the original record."""
    result, seen = [], set()
    required = {'event_id', 'actor_id', 'asset_id', 'action', 'event_time'}
    for record in records:
        if not isinstance(record, dict) or not required <= set(record):
            raise ValidationError('Event missing required schema fields')
        if not all(isinstance(record[x], str) and record[x] for x in required):
            raise ValidationError('Event fields must be nonempty strings')
        if record['event_id'] in seen:
            raise ValidationError('Duplicate event identity needs explicit reconciliation')
        seen.add(record['event_id'])
        result.append({'original': copy.deepcopy(record),
                       'event_time_utc': utc(record['event_time']).isoformat(),
                       'event_id': record['event_id'], 'actor_id': record['actor_id'],
                       'asset_id': record['asset_id'], 'action': record['action']})
    return sorted(result, key=lambda x: (x['event_time_utc'], x['event_id']))


def source_status(last_received, now, maximum_age_seconds, parser_errors):
    if isinstance(maximum_age_seconds, bool) or not isinstance(maximum_age_seconds, (int, float)) or not math.isfinite(maximum_age_seconds) or maximum_age_seconds <= 0:
        raise ValidationError('Maximum age must be positive and finite')
    nonnegative_integer(parser_errors, 'parser_errors')
    age = (utc(now) - utc(last_received)).total_seconds()
    if age < 0:
        return {'status': 'unknown', 'reason': 'future timestamp or clock inconsistency'}
    if parser_errors:
        return {'status': 'unknown', 'reason': 'event interpretation has errors'}
    if age > maximum_age_seconds:
        return {'status': 'unknown', 'reason': 'source observation is stale'}
    return {'status': 'collection_current', 'reason': 'only the supplied freshness/parser checks passed; no claim of complete detection'}


def restore_chain(objects, target_id, available_keys, incident_time):
    """Validate a synthetic dependency manifest and its UTF-8 payload digests.

    full: no parent; incremental: preceding full/incremental/differential;
    differential: parent must be its full baseline. No data is restored.
    """
    path, visiting = [], set()
    def visit(object_id):
        if object_id in visiting:
            raise ValidationError('Backup dependency cycle')
        if object_id not in objects:
            raise ValidationError('Required backup object missing: ' + object_id)
        item = objects[object_id]
        required = {'kind', 'parent', 'point', 'payload', 'sha256', 'required_key'}
        if not isinstance(item, dict) or set(item) != required:
            raise ValidationError('Malformed backup manifest entry')
        if not isinstance(item['payload'], str):
            raise ValidationError('Teaching payload must be UTF-8 text')
        if not digest_matches(item['payload'].encode(), item['sha256']):
            raise ValidationError('Backup digest mismatch: ' + object_id)
        if item['required_key'] not in available_keys:
            raise ValidationError('Recovery key unavailable: ' + str(item['required_key']))
        point = utc(item['point'])
        kind, parent = item['kind'], item['parent']
        visiting.add(object_id)
        if kind == 'full':
            if parent is not None:
                raise ValidationError('Full backup must not require a parent in this model')
        elif kind in {'incremental', 'differential'}:
            if not isinstance(parent, str) or not parent:
                raise ValidationError('Dependent backup needs a parent identity')
            visit(parent)
            if kind == 'differential' and objects[parent]['kind'] != 'full':
                raise ValidationError('Differential must identify its full baseline')
            if point <= utc(objects[parent]['point']):
                raise ValidationError('Dependent recovery point must follow its parent')
        else:
            raise ValidationError('Unsupported backup kind')
        visiting.remove(object_id)
        path.append(object_id)
    visit(target_id)
    age = (utc(incident_time) - utc(objects[target_id]['point'])).total_seconds() / 60
    if age < 0:
        raise ValidationError('Recovery point cannot postdate the stated incident')
    return {'required_chain': path, 'recovery_point_age_minutes': age,
            'synthetic_manifest_checks': 'passed', 'actual_restore_performed': False,
            'application_consistency_or_cleanliness_proven': False}


def change_gate(plan, inventory, authorized_targets):
    """Pure validation of supplied authority/identity/version claims. No apply."""
    required = {'asset_id', 'serial', 'from_version', 'to_version', 'approval',
                'service_capacity_verified', 'recovery_plan_verified'}
    if not isinstance(plan, dict) or set(plan) != required:
        raise ValidationError('Unexpected or missing change-plan field')
    asset = plan['asset_id']
    if asset not in authorized_targets or asset not in inventory:
        raise ValidationError('Target outside authorized inventory')
    observed = inventory[asset]
    if plan['serial'] != observed['serial']:
        raise ValidationError('Asset identity mismatch')
    if plan['from_version'] != observed['running_version']:
        raise ValidationError('Stale version precondition')
    for field in ('approval', 'service_capacity_verified', 'recovery_plan_verified'):
        if plan[field] is not True:
            raise ValidationError('Required gate is not verified: ' + field)
    if not isinstance(plan['to_version'], str) or not plan['to_version']:
        raise ValidationError('Target version is required')
    return {'asset_id': asset, 'proposed_version': plan['to_version'],
            'decision': 'eligible_for_authorized_reviewed_workflow', 'executed': False,
            'note': 'Input assertions require external evidence; this function does not verify real capacity or approval.'}


def fixtures():
    def backup(kind, parent, point, payload):
        return {'kind': kind, 'parent': parent, 'point': point, 'payload': payload,
                'sha256': hashlib.sha256(payload.encode()).hexdigest(), 'required_key': 'LAB-K1'}
    return {
      'notice': 'Synthetic teaching records, not captured production evidence.',
      'population': ['GW-A', 'GW-B', 'GW-C'],
      'observations': [{'asset_id': 'GW-A', 'depth': 'authenticated'},
                       {'asset_id': 'GW-B', 'depth': 'unauthenticated'}],
      'events': [
        {'event_id': 'EV-2', 'actor_id': 'LAB-U1', 'asset_id': 'GW-A', 'action': 'config_write', 'event_time': '2026-09-19T11:01:00+02:00'},
        {'event_id': 'EV-1', 'actor_id': 'LAB-U1', 'asset_id': 'GW-A', 'action': 'login', 'event_time': '2026-09-19T09:00:00Z'}],
      'transfers': [{'evidence_id': 'EVIMG-1', 'from': 'collector-A', 'to': 'analyst-B', 'time': '2026-09-19T09:30:00Z', 'purpose': 'working-copy examination'}],
      'backups': {
        'F0': backup('full', None, '2026-09-19T10:00:00Z', 'Synthetic full state: a=1; b=2'),
        'I1': backup('incremental', 'F0', '2026-09-19T10:30:00Z', 'Synthetic change: a=3'),
        'I2': backup('incremental', 'I1', '2026-09-19T11:20:00Z', 'Synthetic change: b=4'),
        'D2': backup('differential', 'F0', '2026-09-19T11:20:00Z', 'Synthetic changes since F0: a=3; b=4')},
      'inventory': {'GW-A': {'serial': 'LAB-SERIAL-A', 'running_version': '1.0'}},
      'plan': {'asset_id': 'GW-A', 'serial': 'LAB-SERIAL-A', 'from_version': '1.0',
               'to_version': '1.1', 'approval': True, 'service_capacity_verified': True,
               'recovery_plan_verified': True}}


class EvidenceTests(unittest.TestCase):
    def setUp(self): self.f = fixtures()
    def test_metrics_have_correct_denominators(self):
        m = confusion_metrics(16, 24, 4, 956)
        self.assertEqual(m['precision'], .4); self.assertEqual(m['recall'], .8)
        self.assertAlmostEqual(m['false_positive_rate'], 24/980)
    def test_empty_metrics_are_unknown(self):
        self.assertIsNone(confusion_metrics(0, 0, 0, 0)['accuracy'])
    def test_boolean_and_negative_counts_rejected(self):
        for bad in (True, -1, 1.5):
            with self.assertRaises(ValidationError): confusion_metrics(bad, 0, 0, 0)
    def test_population_gap_is_not_clean_coverage(self):
        result = assessment_coverage(self.f['population'], self.f['observations'])
        self.assertEqual(result['missing_observations'], ['GW-C'])
        self.assertFalse(result['full_authenticated_coverage'])
    def test_duplicate_asset_observation_rejected(self):
        with self.assertRaises(ValidationError): assessment_coverage(self.f['population'], self.f['observations']*2)
    def test_unexpected_target_rejected(self):
        with self.assertRaises(ValidationError): assessment_coverage(['GW-A'], [{'asset_id':'GW-Z','depth':'authenticated'}])
    def test_digest_detects_altered_bytes(self):
        digest = hashlib.sha256(b'original').hexdigest()
        self.assertTrue(digest_matches(b'original', digest))
        self.assertFalse(digest_matches(b'changed', digest))
    def test_custody_continuity_passes_but_not_admissibility(self):
        result = custody_report('EVIMG-1', 'collector-A', '2026-09-19T09:00:00Z', self.f['transfers'])
        self.assertTrue(result['recorded_chain_consistent'])
        self.assertFalse(result['proves_source_truth_or_legal_admissibility'])
    def test_wrong_releasing_custodian_is_gap(self):
        self.f['transfers'][0]['from'] = 'unrecorded-person'
        self.assertFalse(custody_report('EVIMG-1','collector-A','2026-09-19T09:00:00Z',self.f['transfers'])['recorded_chain_consistent'])
    def test_custody_time_reversal_is_gap(self):
        self.f['transfers'][0]['time'] = '2026-09-19T08:00:00Z'
        self.assertFalse(custody_report('EVIMG-1','collector-A','2026-09-19T09:00:00Z',self.f['transfers'])['recorded_chain_consistent'])
    def test_timezone_normalization_preserves_original(self):
        result = normalize_events(self.f['events'])
        self.assertEqual([x['event_id'] for x in result], ['EV-1','EV-2'])
        self.assertEqual(result[1]['event_time_utc'], '2026-09-19T09:01:00+00:00')
        self.assertEqual(result[1]['original']['event_time'], '2026-09-19T11:01:00+02:00')
    def test_naive_event_time_rejected(self):
        self.f['events'][0]['event_time'] = '2026-09-19T09:00:00'
        with self.assertRaises(ValidationError): normalize_events(self.f['events'])
    def test_changed_actor_schema_fails_closed(self):
        event = self.f['events'][0]; event['principal_id'] = event.pop('actor_id')
        with self.assertRaises(ValidationError): normalize_events([event])
    def test_duplicate_events_need_reconciliation(self):
        with self.assertRaises(ValidationError): normalize_events(self.f['events']*2)
    def test_parser_errors_make_source_unknown(self):
        self.assertEqual(source_status('2026-09-19T09:00:00Z','2026-09-19T09:00:10Z',60,1)['status'],'unknown')
    def test_stale_source_is_not_healthy(self):
        self.assertEqual(source_status('2026-09-19T09:00:00Z','2026-09-19T09:05:00Z',60,0)['status'],'unknown')
    def test_future_source_time_is_unknown(self):
        self.assertEqual(source_status('2026-09-19T10:00:00Z','2026-09-19T09:05:00Z',60,0)['status'],'unknown')
    def test_incremental_chain_and_rpo(self):
        result = restore_chain(self.f['backups'],'I2',{'LAB-K1'},'2026-09-19T12:00:00Z')
        self.assertEqual(result['required_chain'],['F0','I1','I2'])
        self.assertEqual(result['recovery_point_age_minutes'],40)
        self.assertFalse(result['actual_restore_performed'])
    def test_differential_uses_full_baseline(self):
        self.assertEqual(restore_chain(self.f['backups'],'D2',{'LAB-K1'},'2026-09-19T12:00:00Z')['required_chain'],['F0','D2'])
    def test_missing_incremental_rejected(self):
        del self.f['backups']['I1']
        with self.assertRaises(ValidationError): restore_chain(self.f['backups'],'I2',{'LAB-K1'},'2026-09-19T12:00:00Z')
    def test_backup_tampering_rejected(self):
        self.f['backups']['I1']['payload'] = 'altered'
        with self.assertRaises(ValidationError): restore_chain(self.f['backups'],'I2',{'LAB-K1'},'2026-09-19T12:00:00Z')
    def test_unavailable_recovery_key_rejected(self):
        with self.assertRaises(ValidationError): restore_chain(self.f['backups'],'I2',set(),'2026-09-19T12:00:00Z')
    def test_backup_cycle_rejected(self):
        self.f['backups']['I1']['parent'] = 'I2'
        with self.assertRaises(ValidationError): restore_chain(self.f['backups'],'I2',{'LAB-K1'},'2026-09-19T12:00:00Z')
    def test_differential_cannot_use_incremental_parent(self):
        self.f['backups']['D2']['parent'] = 'I1'
        with self.assertRaises(ValidationError): restore_chain(self.f['backups'],'D2',{'LAB-K1'},'2026-09-19T12:00:00Z')
    def test_change_gate_never_executes(self):
        self.assertFalse(change_gate(self.f['plan'],self.f['inventory'],{'GW-A'})['executed'])
    def test_recycled_asset_identity_rejected(self):
        self.f['plan']['serial'] = 'different-device'
        with self.assertRaises(ValidationError): change_gate(self.f['plan'],self.f['inventory'],{'GW-A'})
    def test_stale_version_precondition_rejected(self):
        self.f['plan']['from_version'] = '0.9'
        with self.assertRaises(ValidationError): change_gate(self.f['plan'],self.f['inventory'],{'GW-A'})
    def test_text_true_is_not_verified_gate(self):
        self.f['plan']['approval'] = 'true'
        with self.assertRaises(ValidationError): change_gate(self.f['plan'],self.f['inventory'],{'GW-A'})
    def test_unverified_recovery_blocks_plan(self):
        self.f['plan']['recovery_plan_verified'] = False
        with self.assertRaises(ValidationError): change_gate(self.f['plan'],self.f['inventory'],{'GW-A'})


def demo():
    f = fixtures()
    gap = copy.deepcopy(f['transfers']); gap[0]['from'] = 'unrecorded-person'
    return {'notice': f['notice'], 'metrics': confusion_metrics(16,24,4,956),
            'coverage': assessment_coverage(f['population'], f['observations']),
            'normalized_events': normalize_events(f['events']),
            'custody_gap': custody_report('EVIMG-1','collector-A','2026-09-19T09:00:00Z',gap),
            'source_with_parser_error': source_status('2026-09-19T09:00:00Z','2026-09-19T09:00:10Z',60,1),
            'recovery_manifest': restore_chain(f['backups'],'I2',{'LAB-K1'},'2026-09-19T12:00:00Z'),
            'change_plan': change_gate(f['plan'],f['inventory'],{'GW-A'})}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['demo','fixtures','selftest'])
    args = parser.parse_args()
    if args.action == 'demo': print(json.dumps(demo(), indent=2))
    elif args.action == 'fixtures': print(json.dumps(fixtures(), indent=2))
    else:
        result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(EvidenceTests))
        raise SystemExit(0 if result.wasSuccessful() else 1)
