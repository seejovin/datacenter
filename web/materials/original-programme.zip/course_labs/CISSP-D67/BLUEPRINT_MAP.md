# CISSP domains 6 and 7 source crosswalk

Original scope paraphrases mapped to the public outline effective 15 April 2024, checked on 19 September 2026. Section numbers are provider references; the scope item wording below is authored. Supporting questions are shared within chapter banks and are counted once.

[ISC2 public outline](https://www.isc2.org/certifications/cissp/cissp-certification-exam-outline)

| Source section | Authored scope | Chapters | Subtopic coverage |
|---|---|---|---|
| 6.1 | Assessment design and authority | CISSP-L26 | Internal/external roles; Supplier boundaries; Hosted and mixed environments; Scope, independence and sampling |
| 6.2 | Control testing methods | CISSP-L27, CISSP-L28 | Weakness applicability; Authorized adversarial validation; Event examination; Representative transactions and benchmarks; Static/dynamic/manual code evaluation; Abuse scenarios; Coverage limits; Interface authority; Behavior simulation; Requirement conformity |
| 6.3 | Operational process evidence | CISSP-L27, CISSP-L29, CISSP-L33, CISSP-L34 | Identity lifecycle records; Informed approval; Performance and exposure measures; Restore verification; Awareness outcomes; Continuity evidence |
| 6.4 | Findings and accountable treatment | CISSP-L29 | Corrective verification; Bounded exceptions; Coordinated disclosure |
| 6.5 | Audit execution and assurance limits | CISSP-L26, CISSP-L27, CISSP-L29 | Internal/external assessment roles; Supplier evidence; Local/hosted boundaries; Attributable reporting |
| 7.1 | Investigation and forensic evidence | CISSP-L30 | Artifact acquisition; Custody and integrity; Reproducible analysis; Competent tools; Host/network/mobile/cloud context |
| 7.2 | Observation and detection pipeline | CISSP-L31 | Detection/prevention sensors; Cross-source correlation; Collection and tuning; Outgoing communication; Retention and integrity; Intelligence and hunting; Behavior-based analysis |
| 7.3 | Approved and observed configuration | CISSP-L32 | Provisioning; Baseline governance; Automation ownership; Drift interpretation |
| 7.4 | Accountable operating authority | CISSP-L30, CISSP-L32, CISSP-L34 | Information and action scope; Independent duties; Privileged access; Staff rotation; Service commitments |
| 7.5 | Protected operating resources | CISSP-L33, CISSP-L34 | Media custody; Protected storage and transfer; Recovery-key availability; Sanitization and disposition |
| 7.6 | Coordinated incident handling | CISSP-L30 | Validation and scope; Response authority; Harm limitation; Communication; Trusted restoration; Cause correction; Verified improvement |
| 7.7 | Preventive and detective operation | CISSP-L31 | Network/application enforcement; Intrusion controls; Permitted/denied execution; External monitoring authority; Constrained analysis; Isolated deception; Endpoint protection; AI/tool boundaries |
| 7.8 | Exposure treatment and updates | CISSP-L32 | Applicability; Risk-based priority; Compatibility classes; Staged correction; Verified exception treatment |
| 7.9 | Authorized service change | CISSP-L32 | Impact review; Approvals and timing; Emergency governance; Partial outcomes; Recovery and acceptance |
| 7.10 | Recovery architecture and capacity | CISSP-L33 | Copy locations and dependencies; Prepared alternate capacity; Multi-site authority; Availability and fault scope; Traffic-class treatment |
| 7.11 | Restoration coordination | CISSP-L33 | Declaration and action; People and contacts; Operational communication; Damage/dependency assessment; Restoration acceptance; Training; Follow-up correction |
| 7.12 | Recovery exercise fidelity | CISSP-L33 | Document and decision review; Procedure walkthrough; Selected-behavior simulation; Parallel capability; Controlled interruption; Stakeholder coordination |
| 7.13 | Continuity of priority functions | CISSP-L33 | Function-level objectives; People/supplier/workaround needs; Exercise and acceptance |
| 7.14 | Physical access boundaries | CISSP-L34 | Site perimeter; Internal zones; Entry/egress dependencies; Visitor closure |
| 7.15 | Personnel protection | CISSP-L34 | Travel and device trust; Awareness and approval fatigue; Emergency roles; Coercion response; Proportionate insider review |

The current public page also discusses AI assessment and operation. Chapters 28 and 31 cover controlled model robustness/disclosure tests, source-grounded interpretation, drift and bounded response automation. These applications do not invent extra numbered provider objectives.

Offline laboratory execution validates only the supplied local functions. Practical organizational observation, examination eligibility, provider examination and professional experience remain separate.
