# GICSP offline practical work

These files contain original synthetic data and an offline analytical model. They do not connect to devices, exercise a real firewall, implement Modbus authentication, or establish physical/production competence.

Run from the repository root with Python 3.12 (standard library only):

```bash
python course_labs/GICSP/lab.py signals
python course_labs/GICSP/lab.py policy
python course_labs/GICSP/lab.py self-check
```

For the signal exercise, independently calculate every scaled value and source age. Distinguish an out-of-range measurement from an in-range but stale one; define quality and freshness requirements separately. Copy `fixture.json` to a new local file and supply `--input your-file.json` to investigate a justified changed scenario. Do not change limits merely to make a failed requirement pass.

For the policy exercise, inspect the identity and operation checks in the model. Explain why an ordinary transport ACL permitting TCP 502 would not enforce the same read/write distinction. Produce a required/forbidden flow matrix and verify every row. The model's application fields represent an enforcement requirement; they are not a claim that classic Modbus carries authenticated user identities.

Each file under `cases/` is a separately authored scenario with deliverables and acceptance criteria. Build an evidence ledger containing requirement, source/version, observations, consequence, accept/hold/reject decision, correction/retest and limitations. A self-check validates the supplied calculation/model implementation, not your independent professional competence.

## Protocol evidence lab

`protocol_lab.py` uses only Python's standard library. It generates and decodes
`modbus_synthetic.pcap`, a **synthetic** four-record evidence fixture corresponding
to lesson GICSP-L036. The records have valid generated IPv4/TCP checksums, but are
independent data records, not a captured complete TCP conversation. No network
connection, packet transmission or physical operation occurs.

From the project root:

```bash
python course_labs/GICSP/protocol_lab.py self-check
python course_labs/GICSP/protocol_lab.py decode
```

The expected read starts at offset 100, quantity 2, unit 1. Returned unsigned
registers are 250 and 260; the supplied lesson scale yields 25.0 and 26.0 °C.
The later function-06 write receives exception 02. Do not report a successful
write or physical effect from this exception.

To reproduce the fixture locally:

```bash
python course_labs/GICSP/protocol_lab.py make-fixture --file /tmp/gicsp_synthetic.pcap
python course_labs/GICSP/protocol_lab.py decode --file /tmp/gicsp_synthetic.pcap
```

On Windows, use a writable local filename instead of `/tmp/…`.

Independent exercise: annotate each MBAP and PDU field; explain why the response
length is 7 while the complete ADU is 13 bytes; compare the write response with a
normal write echo; create a **copy** with its final byte removed and verify that
the decoder rejects incomplete evidence. Record the exact command and output you
actually execute. Keep the original fixture and its digest with your report.

The parser deliberately supports only classic little-endian microsecond PCAP,
Ethernet, unfragmented IPv4/TCP, and one complete supported Modbus ADU per packet.
It does not reassemble TCP streams or IP fragments, interpret other protocols,
handle checksum-offload artefacts, infer user identity, enforce access policy or
measure a physical process. A rejection means the input is outside this subset or
invalid under its checks; it is not automatically evidence of a malicious packet.

## Practical progression beyond the offline programs

These programs exercise calculations and evidence parsing. For the declared
external practical route, use separately authorised isolated systems and record
actual execution:

1. Windows/Linux replicas: implement a restricted reporting/service identity,
   audit a permitted and denied operation, verify effective permissions and
   restore from a tested copy. Record supported versions and operational limits.
2. Vendor controller/HMI simulator: trace scan and edge logic, bad-quality data,
   command versus feedback, alarm delay/hysteresis, forced-state restoration and
   project comparison. Preserve which simulated features differ from hardware.
3. Isolated protocol endpoints: verify read-only versus write authority, source
   timestamps, OPC namespace mapping, MQTT retained/duplicate handling and
   certificate rejection using synthetic process data and no physical outputs.
4. Supervised physical equipment: complete the site-approved receiving,
   commissioning, maintenance, diagnosis and recovery tasks with competent
   supervision and explicit authority. Independent protection and live process
   actions stay within their specialist-approved procedures.
5. Sustained operations: maintain evidence of real operating history, review,
   changes and recovery drills. A one-time lab or a high question score does not
   establish this duty.

The programme's near-term target is D4–D7, with D5 mandatory and integral.
D2/D3 specialist ownership needs its later teaching and practical evidence; D1
building engineering remains excluded. All nine lifecycle responsibilities apply
at the appropriate evidence level throughout.
