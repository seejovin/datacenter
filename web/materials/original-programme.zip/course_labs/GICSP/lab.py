#!/usr/bin/env python3
"""Offline synthetic signal/policy lab. Never connects to a device or network."""
import argparse,json,ipaddress
from pathlib import Path

def scale_4_20(value,low,high):
    if not 4<=value<=20:
        return {'quality':'out_of_range','value':None}
    return {'quality':'good','value':low+(value-4)*(high-low)/16}

def evaluate(rules,flow):
    for n,r in enumerate(rules,1):
        if ipaddress.ip_address(flow['src']) not in ipaddress.ip_network(r['src']):continue
        if ipaddress.ip_address(flow['dst']) not in ipaddress.ip_network(r['dst']):continue
        if r['protocol']!=flow['protocol']:continue
        if r.get('port') is not None and r['port']!=flow.get('port'):continue
        # This model can represent a separate application enforcement point.
        if r.get('operation') not in (None,flow.get('operation')):continue
        if r.get('identity') not in (None,flow.get('identity')):continue
        return {'decision':r['action'],'rule':n,'layer':r.get('layer','transport')}
    return {'decision':'deny','rule':None,'layer':'default'}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('exercise',choices=['signals','policy','self-check'])
    ap.add_argument('--input',type=Path,help='Optional local JSON file; see fixture.json schema')
    a=ap.parse_args()
    fixture=json.loads((a.input or Path(__file__).with_name('fixture.json')).read_text())
    if a.exercise=='signals':
        result=[{'point':s['point'],'source_age_s':fixture['now_s']-s['source_s'],**scale_4_20(s['mA'],s['low'],s['high'])} for s in fixture['signals']]
    elif a.exercise=='policy':
        result=[{'flow':f,**evaluate(fixture['rules'],f)} for f in fixture['flows']]
    else:
        assert scale_4_20(12,0,100)=={'quality':'good','value':50.0}
        assert scale_4_20(3.5,0,100)['quality']=='out_of_range'
        outcomes=[evaluate(fixture['rules'],f)['decision'] for f in fixture['flows']]
        assert outcomes==['allow','deny','deny','allow'],outcomes
        # A transport-only permit cannot distinguish read from write.
        broad=[{'src':'192.0.2.10/32','dst':'192.0.2.20/32','protocol':'tcp','port':502,'action':'allow'}]
        assert evaluate(broad,fixture['flows'][1])['decision']=='allow'
        result={'status':'checks passed','scope':'Offline arithmetic and policy model only; no device or protocol implementation was exercised.'}
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
