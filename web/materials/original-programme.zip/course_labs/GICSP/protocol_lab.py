#!/usr/bin/env python3
"""Offline synthetic Modbus/PCAP decoder. No sockets, live capture or device writes.

Supported capture subset: classic little-endian microsecond PCAP, Ethernet,
unfragmented IPv4/TCP, one complete Modbus ADU in each packet. This is deliberately
NOT a TCP stream reassembler or production intrusion-detection system.
"""
import argparse, hashlib, ipaddress, json, struct
from pathlib import Path

ADUS=[
 ('request','00 2a 00 00 00 06 01 03 00 64 00 02'),
 ('response','00 2a 00 00 00 07 01 03 04 00 fa 01 04'),
 ('request','00 2b 00 00 00 06 01 06 00 64 01 2c'),
 ('response','00 2b 00 00 00 03 01 86 02'),
]

def checksum(data):
    if len(data)%2:data+=b'\0'
    total=sum(struct.unpack('!%dH'%(len(data)//2),data))
    while total>>16:total=(total&0xffff)+(total>>16)
    return (~total)&0xffff

def decode_adu(data,direction):
    if direction not in ('request','response'):raise ValueError('Direction must be explicit.')
    if len(data)<8:raise ValueError('Truncated MBAP/PDU; a complete reassembled ADU is required.')
    tid,pid,length=struct.unpack('!HHH',data[:6])
    if pid!=0:raise ValueError('Unsupported protocol identifier.')
    if length<2 or length>254 or len(data)!=6+length:
        raise ValueError('Length mismatch: truncated/coalesced/segmented ADU; stream reassembly is outside this lab.')
    unit,fc=data[6],data[7];pdu=data[7:]
    result={'transaction':tid,'unit':unit,'function':fc,'direction':direction,'mbap_length':length}
    if fc&0x80:
        if direction!='response' or len(pdu)!=2:raise ValueError('Malformed exception response.')
        result.update(request_function=fc&0x7f,exception=pdu[1],outcome='application exception')
    elif direction=='request' and fc in (3,4):
        if len(pdu)!=5:raise ValueError('Read request must contain address and quantity.')
        start,quantity=struct.unpack('!HH',pdu[1:])
        if not 1<=quantity<=125:raise ValueError('Read quantity outside supported protocol bounds.')
        if start+quantity>65536:raise ValueError('Read crosses the address space.')
        result.update(start=start,quantity=quantity,operation='read')
    elif direction=='response' and fc in (3,4):
        if len(pdu)<2 or pdu[1]!=len(pdu)-2 or pdu[1]%2 or pdu[1]>250:
            raise ValueError('Read response byte count is inconsistent.')
        result.update(registers=list(struct.unpack('!%dH'%(pdu[1]//2),pdu[2:])),outcome='read response')
    elif fc==6:
        if len(pdu)!=5:raise ValueError('Function06 must contain address and value.')
        start,value=struct.unpack('!HH',pdu[1:])
        result.update(start=start,value=value,operation='write request' if direction=='request' else 'write echo')
    else:raise ValueError('Function outside this intentionally bounded decoder.')
    return result

def packet(payload,direction,number):
    src,dst=('192.0.2.10','192.0.2.20') if direction=='request' else ('192.0.2.20','192.0.2.10')
    sport,dport=(40000,502) if direction=='request' else (502,40000)
    srcb,dstb=ipaddress.ip_address(src).packed,ipaddress.ip_address(dst).packed
    # Synthetic independent data records; no complete handshake/session is implied.
    tcp=struct.pack('!HHIIBBHHH',sport,dport,1000+number*100,2000,5<<4,0x18,8192,0,0)
    pseudo=srcb+dstb+struct.pack('!BBH',0,6,len(tcp)+len(payload))
    tcp=tcp[:16]+struct.pack('!H',checksum(pseudo+tcp+payload))+tcp[18:]
    ip=struct.pack('!BBHHHBBH4s4s',0x45,0,20+len(tcp)+len(payload),number,0x4000,64,6,0,srcb,dstb)
    ip=ip[:10]+struct.pack('!H',checksum(ip))+ip[12:]
    ethernet=bytes.fromhex('0200000000200200000000100800')
    return ethernet+ip+tcp+payload

def make_capture(path):
    out=bytearray(struct.pack('<IHHIIII',0xa1b2c3d4,2,4,0,0,65535,1))
    for n,(direction,hexdata) in enumerate(ADUS):
        frame=packet(bytes.fromhex(hexdata),direction,n)
        out+=struct.pack('<IIII',1789800000,n*100000,len(frame),len(frame))+frame
    path.write_bytes(out)
    return {'path':str(path),'sha256':hashlib.sha256(out).hexdigest(),'provenance':'Generated synthetic data packets; no live capture or complete TCP session.'}

def decode_capture(data):
    if len(data)<24:raise ValueError('Truncated PCAP global header.')
    magic,major,minor,zone,sig,snap,link=struct.unpack('<IHHIIII',data[:24])
    if (magic,major,minor,link)!=(0xa1b2c3d4,2,4,1):raise ValueError('Unsupported PCAP format; see documented subset.')
    pos=24;rows=[]
    while pos<len(data):
        if len(data)-pos<16:raise ValueError('Truncated PCAP record header.')
        sec,usec,caplen,origlen=struct.unpack('<IIII',data[pos:pos+16]);pos+=16
        if caplen!=origlen or caplen>snap or pos+caplen>len(data):raise ValueError('Truncated or inconsistent captured frame.')
        frame=data[pos:pos+caplen];pos+=caplen
        if len(frame)<54 or frame[12:14]!=b'\x08\x00':raise ValueError('Expected Ethernet IPv4/TCP fixture.')
        ip=frame[14:];ihl=(ip[0]&15)*4
        if ip[0]>>4!=4 or ihl<20 or len(ip)<ihl:raise ValueError('Invalid IPv4 header.')
        total=struct.unpack('!H',ip[2:4])[0];frag=struct.unpack('!H',ip[6:8])[0]
        if total>len(ip) or total<ihl+20 or ip[9]!=6:raise ValueError('Invalid IPv4/TCP lengths or protocol.')
        if frag&0x3fff:raise ValueError('Fragment reassembly is outside this lab.')
        if checksum(ip[:ihl])!=0:raise ValueError('IPv4 checksum failed in synthetic fixture.')
        tcp=ip[ihl:total];off=(tcp[12]>>4)*4
        if off<20 or off>len(tcp):raise ValueError('Invalid TCP data offset.')
        pseudo=ip[12:20]+struct.pack('!BBH',0,6,len(tcp))
        if checksum(pseudo+tcp)!=0:raise ValueError('TCP checksum failed; this lab does not model offload artefacts.')
        sport,dport=struct.unpack('!HH',tcp[:4])
        direction='request' if dport==502 else 'response' if sport==502 else None
        if direction is None:raise ValueError('No fixture Modbus port direction.')
        rows.append({'capture_time_s':sec+usec/1_000_000,'src':str(ipaddress.ip_address(ip[12:16])),'dst':str(ipaddress.ip_address(ip[16:20])),**decode_adu(tcp[off:],direction)})
    return rows

def self_check():
    decoded=[decode_adu(bytes.fromhex(h),d) for d,h in ADUS]
    assert decoded[0]['start']==100 and decoded[0]['quantity']==2
    assert decoded[1]['registers']==[250,260]
    assert decoded[3]['request_function']==6 and decoded[3]['exception']==2
    for invalid in (bytes.fromhex(ADUS[0][1])[:-1],bytes.fromhex(ADUS[0][1])+b'\0',b'\0'):
        try:decode_adu(invalid,'request')
        except ValueError:pass
        else:raise AssertionError('Malformed ADU was accepted.')
    frame=packet(bytes.fromhex(ADUS[0][1]),'request',1)
    cap=struct.pack('<IHHIIII',0xa1b2c3d4,2,4,0,0,65535,1)+struct.pack('<IIII',1,0,len(frame),len(frame))+frame
    assert decode_capture(cap)[0]['start']==100
    for badcap in (cap[:-1],cap[:-1]+bytes([cap[-1]^1])):
        try:decode_capture(badcap)
        except ValueError:pass
        else:raise AssertionError('Truncated/corrupted capture was accepted.')
    return {'status':'checks passed','tested':'Modbus lengths/fields/exceptions, generated IPv4/TCP checksums, truncation and corruption rejection','limits':'Offline synthetic subset; no stream reassembly, endpoint authority or physical process execution.'}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('action',choices=['self-check','make-fixture','decode'])
    ap.add_argument('--file',type=Path,default=Path(__file__).with_name('modbus_synthetic.pcap'))
    a=ap.parse_args()
    result=self_check() if a.action=='self-check' else make_capture(a.file) if a.action=='make-fixture' else decode_capture(a.file.read_bytes())
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
