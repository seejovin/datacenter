#!/usr/bin/env python3
"""Offline integration model. No network, PLC, vendor or physical execution."""
import argparse
import copy
import json
from pathlib import Path


def first_match(rules, transaction):
    for rule in rules:
        if all(rule.get(k, '*') in ('*', transaction[k]) for k in ('source', 'target', 'service', 'operation')):
            return {'action': rule['action'], 'rule_id': rule['id']}
    return {'action': 'deny', 'rule_id': 'implicit-default'}


def check_point(point, now_s):
    age = now_s - point['source_time_s']
    in_range = point['valid_raw_low'] <= point['raw'] <= point['valid_raw_high']
    value = point['raw'] * point['scale'] + point['offset']
    usable = point['quality'] == 'good' and 0 <= age < point['maximum_age_s'] and in_range
    return {'engineering_value': value, 'unit': point['unit'], 'age_s': age,
            'raw_in_range': in_range, 'usable_under_model': usable}


def identity_check(identity, action, now_s, revoked):
    reasons = []
    if identity['id'] in revoked:
        reasons.append('identity is currently revoked')
    if not identity['valid_from_s'] <= now_s < identity['valid_until_s']:
        reasons.append('outside defined validity interval')
    if action not in identity['operations']:
        reasons.append('operation outside role')
    return {'permitted_under_model': not reasons, 'reasons': reasons}


def recovery_schedule(tasks, available):
    """Unlimited parallelism per ready wave; named shared resources serialize tasks.

    This deliberately simple list scheduler models declared dependencies/resources
    only. Results are estimates from synthetic durations, never site RTO evidence.
    """
    done = {x: 0 for x in available}
    resources = {}
    pending = {t['id']: t for t in tasks if t['id'] not in done}
    schedule = []
    while pending:
        ready = [t for t in pending.values() if all(d in done for d in t['requires'])]
        if not ready:
            return {'schedule': schedule, 'blocked': {k: [d for d in t['requires'] if d not in done] for k,t in pending.items()}, 'model_completion_min': None}
        # Deterministic earliest available start, then identifier. Not an optimizer.
        def start(t):
            return max([done[d] for d in t['requires']] + [resources.get(r, 0) for r in t.get('resources', [])] + [0])
        task = min(ready, key=lambda t: (start(t), t['id']))
        began = start(task); ended = began + task['duration_min']
        done[task['id']] = ended
        for resource in task.get('resources', []):
            resources[resource] = ended
        schedule.append({'id':task['id'], 'start_min':began, 'end_min':ended})
        del pending[task['id']]
    return {'schedule':schedule, 'blocked':{}, 'model_completion_min':max(done.values(),default=0)}


def assess_claims(requirements, tests, baseline):
    by_req = {}
    for test in tests:
        by_req.setdefault(test['requirement'], []).append(test)
    findings = []
    for req in requirements:
        relevant = by_req.get(req['id'], [])
        matching = [t for t in relevant if t['baseline'] == baseline]
        missing = sorted(set(req['required_modes']) - {t['mode'] for t in matching if t['status']=='pass'})
        failed = [t['id'] for t in matching if t['status']=='fail']
        stale = [t['id'] for t in relevant if t['baseline'] != baseline]
        findings.append({'requirement':req['id'], 'missing_passing_modes':missing, 'failed_tests':failed,
                         'different_baseline_tests':stale, 'supported_in_synthetic_register':not missing and not failed})
    return findings


def audit(data):
    flow_results=[]
    for transaction in data['transactions']:
        result=first_match(data['rules'],transaction)
        flow_results.append({'id':transaction['id'], **result, 'required_action':transaction['expected_action'],
                             'matches_requirement':result['action']==transaction['expected_action']})
    identity_results=[{'request':r['id'], **identity_check(data['identities'][r['identity']],r['operation'],data['now_s'],data['revoked'])} for r in data['identity_requests']]
    recovery=recovery_schedule(data['recovery_tasks'],data['initially_available'])
    completion=recovery['model_completion_min']
    recovery['within_declared_model_rto']=completion is not None and completion <= data['rto_min']
    return {'evidence_status':'Synthetic model output, not physical/vendor execution or normative SL assessment.',
            'flows':flow_results,
            'points':{p['id']:check_point(p,data['now_s']) for p in data['points']},
            'identity':identity_results,
            'recovery':recovery,
            'claims':assess_claims(data['requirements'],data['tests'],data['effective_baseline'])}


def self_test():
    n=0
    def check(actual,expected):
        nonlocal n
        assert actual==expected,(actual,expected);n+=1
    tx={'source':'collector','target':'plc','service':'tcp502','operation':'write'}
    broad={'id':'broad','source':'collector','target':'plc','service':'tcp502','operation':'*','action':'permit'}
    deny={'id':'deny-write','source':'collector','target':'plc','service':'tcp502','operation':'write','action':'deny'}
    check(first_match([broad,deny],tx)['action'],'permit')
    check(first_match([deny,broad],tx)['action'],'deny')
    check(first_match([],tx)['action'],'deny')
    p={'raw':40,'scale':0.1,'offset':0,'unit':'bar','quality':'good','source_time_s':100,'maximum_age_s':5,'valid_raw_low':0,'valid_raw_high':120}
    check(check_point(p,104.9)['usable_under_model'],True)
    check(check_point(p,105)['usable_under_model'],False)
    check(check_point({**p,'quality':'bad'},101)['usable_under_model'],False)
    check(check_point({**p,'raw':-1},101)['usable_under_model'],False)
    identity={'id':'old','valid_from_s':0,'valid_until_s':100,'operations':['read']}
    check(identity_check(identity,'read',50,[])['permitted_under_model'],True)
    check(identity_check(identity,'write',50,[])['permitted_under_model'],False)
    check(identity_check(identity,'read',100,[])['permitted_under_model'],False)
    check(identity_check(identity,'read',50,['old'])['permitted_under_model'],False)
    cycle=[{'id':'a','requires':['b'],'duration_min':1},{'id':'b','requires':['a'],'duration_min':1}]
    check(recovery_schedule(cycle,[])['model_completion_min'],None)
    tasks=[{'id':'hall-a','requires':[],'resources':['tool'],'duration_min':70},{'id':'hall-b','requires':[],'resources':['tool'],'duration_min':70}]
    check(recovery_schedule(tasks,[])['model_completion_min'],140)
    for task in tasks: task['resources']=[]
    check(recovery_schedule(tasks,[])['model_completion_min'],70)
    req=[{'id':'R','required_modes':['normal','restore']}]
    tests=[{'id':'T1','requirement':'R','mode':'normal','baseline':'v2','status':'pass'},{'id':'T2','requirement':'R','mode':'restore','baseline':'v1','status':'pass'}]
    check(assess_claims(req,tests,'v2')[0]['supported_in_synthetic_register'],False)
    tests[1]['baseline']='v2'
    check(assess_claims(req,tests,'v2')[0]['supported_in_synthetic_register'],True)
    tests[1]['status']='fail'
    check(assess_claims(req,tests,'v2')[0]['supported_in_synthetic_register'],False)
    return {'checks_passed':n,'scope':'Deterministic offline model only; no device or physical verification.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['audit','self-test'])
    parser.add_argument('--input',type=Path,default=Path(__file__).with_name('starter.json'))
    args=parser.parse_args()
    print(json.dumps(self_test() if args.action=='self-test' else audit(json.loads(args.input.read_text())),indent=2))
if __name__=='__main__': main()
