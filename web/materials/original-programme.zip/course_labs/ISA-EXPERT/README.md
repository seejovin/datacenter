# ISA Expert integration capstone

This is an original integration exercise across the four specialist learning paths. It is not an additional official ISA examination. The provider's Expert certificate follows its four specialist certificate requirements.

The supplied Python model is entirely local and uses only the standard library. It reads synthetic JSON, evaluates declared rules and prints model results. It does not contact equipment, compile vendor PLC code, validate licensed standard clauses, perform physical safety analysis or measure site recovery time.

```bash
python course_labs/ISA-EXPERT/capstone.py audit
python course_labs/ISA-EXPERT/capstone.py self-test
```

Copy `starter.json` to a working file and select it with `--input path/to/working.json`. Preserve the starting file and predict results before running each experiment. Keep versions of each justified change. The self-test validates only the deterministic model functions.

## The system under consideration

A collector obtains process data from a controller gateway. Engineering uses a separate role. Two halls share identity, a recovery vault and a licensed workstation. The current effective baseline is `site-v3`; some historical tests concern `site-v2`.

The starter deliberately contains several distinct gaps:

- A broad first-match permit shadows the intended collector write denial.
- One plausible pressure value is stale; one recent temperature has bad quality.
- A retired supplier identity still exists in historical material, a current observer has read scope, and an engineer credential has expired.
- The vault and identity recovery form a bootstrap cycle.
- Both hall restorations contend for one licensed workstation.
- The evidence register has failed, unperformed, missing and different-baseline tests.

These facts are supplied synthetic evidence. They are not observations from the user's site.

## Stage 1: scope, risk and requirements

Draw physical-function, information and authority views. Identify what the model includes and excludes. Write at least four consequence-linked scenarios: collector write access, stale/bad measurement interpretation, shared recovery authority failure and simultaneous hall restoration.

Derive a small requirements specification. Include allowed collection, prohibited writes, valid/fresh data, current identity authority, a justified recovery objective and required lifecycle test modes. State owner, integrator, supplier and operator responsibilities. Keep target requirements, capability assumptions and achieved evidence separate; the script does not calculate an ISA security level.

Acceptance: every requirement names a function or authority property, applicable conditions, evidence and accountable decision. A list of vulnerabilities or products is insufficient.

## Stage 2: policy and point interpretation

Predict the first matching rule for each transaction. Correct the policy so required reads still work and collector writes are denied. Explain why deleting every permit would not satisfy the combined requirement. Add a distinct forbidden operation and an alternate source to challenge the proposed scope. The model matches only its four declared fields and does not model NAT, stateful sessions, routing, real protocol inspection or local bypasses; include those in the field-validation plan.

Calculate each point's scaled value and age. Explain why a plausible number, a current gateway refresh or an authenticated source does not prove a usable measurement. Test the exact strict age boundary, a future source timestamp, out-of-range raw input and bad quality. Do not “repair” a simulated failed sensor merely by changing its quality flag without explaining the real evidence that would justify such a state change.

Acceptance: calculations match the model; freshness, quality and physical accuracy remain distinct; each unmodeled physical or vendor property has a specific external test.

## Stage 3: identity and restoration authority

Predict the outcome of every identity request. Distinguish revoked, expired and role-denied conditions. Explain why the historical supplier entry must not regain authority during restore. Add a hypothetical independently valid API token to the written authority model: the supplied script intentionally does not implement all token/session semantics, so explain which additional revocation evidence would be needed.

Prepare a controlled renewal/enrollment plan for the expired engineering identity. Editing the synthetic validity numbers represents a modeled authorized new state, not permission to extend real credentials. Verify required engineering access and denied observer/supplier operations separately.

Acceptance: the restoration design supplies necessary current access while removing obsolete authority; it accounts for alternate interfaces and existing sessions beyond the simple model.

## Stage 4: dependency and resource recovery

Explain the bootstrap cycle from the initial audit. Model an independently controlled bootstrap credential by adding `bootstrap` to `initially_available`, with a written custody, authorization and post-use procedure. Re-run the schedule and explain the remaining shared-workstation constraint.

The scheduler is a deterministic list scheduler, not a global optimization solver. Tasks may overlap if declared dependencies and named resources permit it. A resource name represents one exclusive resource. Durations are synthetic estimates; output is not measured site RTO.

Compare these designs:

1. One shared licensed workstation.
2. Two separately available supported workstations, one per hall, with justified licensing and custody.
3. A staged service objective that the owner explicitly accepts, with different hall priorities.

Do not change the RTO merely to make the result green. Any requirement revision needs a consequence and owner-decision basis. Include identity, licence and final acceptance time in the declared boundary.

Acceptance: no unresolved dependency cycle is hidden; resource contention is represented; the reported objective corresponds to the service endpoint; simulated duration is labeled as such.

## Stage 5: acceptance evidence and incident challenge

Inspect the evidence register. Distinguish failed tests, missing modes, unperformed tests and passing results from another baseline. The script trusts the supplied status fields only to illustrate evidence bookkeeping. Editing a status to `pass` does not create an observed test result. Retain actual model inputs/outputs or separately authorized external evidence behind every reported pass.

Create a new synthetic incident: the old supplier identity is used through an alternate management path while one hall is in maintenance mode. Provide the minimum evidence needed to distinguish unauthorized authority, ordinary communications failure and a stale display. Choose bounded containment, preserve relevant evidence, and explain the three recovery paths: network/platform, controller/engineering and supervisory/data.

Acceptance: the response preserves the declared operating envelope and qualified physical authority; recovery removes the old path and verifies current function; uncertainty and evidence gaps remain visible.

## Final independent deliverables

Submit the requirement/risk trace, zone/conduit and identity models, versioned JSON changes, actual local output files, diagnosis record, acceptance matrix and recovery plan. Include one failed attempt and its correction. Map demonstrated analytical/model capability to the broader curriculum and list the specific licensed-standard, vendor-tool, representative-hardware, calibrated-instrument and site-authorization gates still needed.

A reviewer should be able to reproduce the local results, identify each claim's environment, and understand what would change if an assumption fails. A passing model or question score is not an official credential or universal operating authorization.
