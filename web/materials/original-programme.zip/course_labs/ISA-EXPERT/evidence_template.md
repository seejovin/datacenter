# Integrated lifecycle evidence record

## Claim and scope

System/service; operating envelope; included assets; external dependencies; owner; applicable source editions; authorization; excluded physical/vendor claims.

## Risk and requirement trace

| Scenario | Consequence and assumptions | Requirement | Implementation | Test | Result | Limitation | Owner |
|---|---|---|---|---|---|---|---|
| | | | | | Not performed | | |

Keep target requirements, component capability evidence and achieved system evidence separate. Do not derive a normative security level from this template or the supplied script.

## Effective baseline and provenance

Artifact/version; tool/dependencies; target identity; observation point; time basis; raw evidence location; changes from approved intent; recovery-source state.

## Tests

| Mode | Preconditions | Stimulus | Expected observable outcome | Actual outcome | Evidence and environment |
|---|---|---|---|---|---|
| Normal | | | | Not performed | |
| Prohibited action | | | | Not performed | |
| Fault/degraded | | | | Not performed | |
| Maintenance | | | | Not performed | |
| Restart/recovery | | | | Not performed | |

## Diagnosis and change

Observed facts; competing hypotheses; discriminating tests; causal conclusion; uncertainty; proposed correction; authority; live prerequisites; abort limits; rollback; actual execution and deviations.

## Trusted recovery

Network/platform path; controller/engineering path; supervisory/data path; independent bootstrap; current-authority reconciliation; required physical handback; RPO/RTO start and end; synthetic versus measured timing.

## Acceptance and continuing ownership

Met, failed and untested requirements; conditional acceptance; accountable reviewer; exception expiry; monitoring; supplier support; updated restoration material; retirement duties.

## Competence gates

Analytical and model outcomes demonstrated; supported vendor work completed; representative hardware evidence; calibrated physical measurement; site authorization; official certificate requirements; outstanding tasks and acceptance criteria.
