# vPC construction and a failure-state matrix

Use two supported Nexus switches and a downstream LACP-capable lab device. This authored configuration is illustrative and was not run on equipment here. Pin the exact NX-OS release and platform support before execution. Build management/keepalive reachability first and preserve console or authorized out-of-band recovery.

**Topology and intent.** A and B form vPC domain 10. Their management addresses are 192.0.2.11 and 192.0.2.12 in the management VRF. Ethernet1/49–50 form peer-link Po100. Ethernet1/10 on each peer forms downstream vPC 20 toward a server or switch. VLAN120 is the only tenant VLAN in this bounded exercise. The keepalive path must remain independent of the peer-link failure being tested.

```text
feature lacp
feature vpc
vlan 120
vpc domain 10
  peer-keepalive destination 192.0.2.12 source 192.0.2.11 vrf management
interface port-channel100
  switchport
  switchport mode trunk
  switchport trunk allowed vlan 120
  spanning-tree port type network
  vpc peer-link
interface Ethernet1/49-50
  switchport
  switchport mode trunk
  channel-group 100 mode active
  no shutdown
interface port-channel20
  switchport
  switchport mode trunk
  switchport trunk allowed vlan 120
  vpc 20
interface Ethernet1/10
  switchport
  switchport mode trunk
  channel-group 20 mode active
  no shutdown
```

This is A's shape; B reverses keepalive source/destination and uses the same intended vPC/domain and VLAN relationships. Interface range syntax, supported peer-link member ports and defaults must be checked on the selected model. Do not add optional peer-gateway, peer-switch or auto-recovery settings without a separate explanation of the failure they solve and their documented constraints.

Read `show vpc brief`, the supported vPC consistency-parameter output, `show port-channel summary`, LACP neighbor state and VLAN/STP state. The downstream device should see the intended logical LACP relationship. Compare per-member collecting/distributing state; a physical up member may still be suspended.

| Fault | Expected question | Evidence required |
|---|---|---|
| One downstream member lost | Does the surviving member carry the application within capacity? | LACP state, counters, application interruption |
| Peer-link lost; keepalive live | Does the secondary enter the supported protective state? | Peer role, peer-link/keepalive status, member suspension |
| Keepalive lost; peer-link live | What diagnostic independence has been lost? | Liveness alarm, continuing synchronization/forwarding |
| One peer unavailable | Which dual-homed and orphan workloads survive? | Per-attachment path and gateway evidence |
| VLAN mismatch | Which consistency or forwarding gate detects it? | Effective VLAN sets and exact fault scope |

Perform disruptive fault injection only in an isolated authorized lab with a recovery path. A production change window is not blanket permission to simulate every failure. Preserve before-state and test one fault at a time. For each event, predict behavior, observe it, restore the dependency and verify the return transition. Include at least one orphan workload in the analysis; dual-homed success does not establish orphan continuity.
