# Routed underlay: construct, observe, break and recover

This is an original isolated-lab configuration exercise. It has not been executed on Cisco equipment in this package. Use a supported Nexus 9000/NX-OS 10.x lab and check the exact interface/OSPF command support for the selected release. The addresses below are documentation or private lab addresses. Do not connect the experiment to a public routing domain.

**Requirement.** Leaf A and Leaf B must reach each other's routing loopback and dedicated VTEP loopback through a routed spine. Each link uses the same approved IP MTU. Management remains on a separate authorized path. A lost link must produce a predictable route withdrawal; adding a second spine later must preserve required capacity and MTU.

| Node | Routing loopback0 | Dedicated VTEP loopback1 | Spine-facing subnet |
|---|---|---|---|
| Spine | 10.255.0.1/32 | Not used in this lab | .0/31 and .2/31 |
| Leaf A | 10.255.0.11/32 | 10.255.1.11/32 | 10.0.0.1/31; spine .0 |
| Leaf B | 10.255.0.12/32 | 10.255.1.12/32 | 10.0.0.3/31; spine .2 |

A /31 point-to-point link has two endpoint addresses without reserving a conventional network/broadcast pair. Both ends must support the intended use. Keep the VTEP loopback separate from the BGP update-source loopback in this design.

Illustrative Leaf A construction:

```text
feature ospf
feature bgp
router ospf UNDERLAY
  router-id 10.255.0.11
interface loopback0
  ip address 10.255.0.11/32
  ip router ospf UNDERLAY area 0.0.0.0
interface loopback1
  ip address 10.255.1.11/32
  ip router ospf UNDERLAY area 0.0.0.0
interface Ethernet1/1
  no switchport
  mtu 9216
  ip address 10.0.0.1/31
  ip ospf network point-to-point
  ip router ospf UNDERLAY area 0.0.0.0
  no shutdown
```

Leaf B uses its corresponding addresses; the spine configures both routed interfaces and advertises loopback0 into the same area. The `no switchport` line changes the interface's forwarding role. The OSPF interface association activates the protocol on that link; the router process name is locally significant, whereas area compatibility and actual protocol settings must agree across the adjacency. The MTU value is a lab choice requiring support, not a universal production recommendation.

Collect the supported forms of `show ip ospf neighbors`, `show ip ospf interface`, `show ip route 10.255.1.12`, `show interface Ethernet1/1` and a source-specific reachability test. Record the exact command syntax accepted by the chosen image. Expected relationships are: neighbor reaches FULL on the point-to-point link; remote loopbacks appear through the spine; next-hop resolution uses the routed link; the selected packet size crosses the whole path.

Now add an iBGP EVPN control relationship, retaining the OSPF underlay:

```text
! Leaf A — illustrative neighbor structure
router bgp 65000
  router-id 10.255.0.11
  neighbor 10.255.0.1
    remote-as 65000
    update-source loopback0
    address-family l2vpn evpn
      send-community
      send-community extended
! Spine — repeat this neighbor structure for .11 and .12
router bgp 65000
  router-id 10.255.0.1
  neighbor 10.255.0.11
    remote-as 65000
    update-source loopback0
    address-family l2vpn evpn
      send-community
      send-community extended
      route-reflector-client
```

The route reflector distributes EVPN information but is not automatically the VTEP endpoint for tenant packets. BGP TCP establishment, address-family exchange and tenant import remain separate checks. Verify the supported `show bgp l2vpn evpn summary` and route detail commands. At this point, a healthy EVPN session can still have no endpoint routes because the access/VNI service has not yet been constructed.

**Guided faults.** First change only Leaf B's interface MTU and observe adjacency exchange and data-plane size behavior. Restore the approved MTU. Next remove only Leaf A's EVPN address-family activation, leaving the base BGP/IPv4 state intact. Explain why the two faults produce different evidence. Do not use broad protocol resets as the initial diagnostic step.

**Independent acceptance.** Supply baseline configurations, supported feature/version evidence, the packet walk, observed neighbor/route state, two fault timelines and a rollback record. If the lab has only one spine, explicitly state that it cannot demonstrate spine-loss continuity. An emulated route result is not a measurement of physical ASIC forwarding rate or optic resilience.
