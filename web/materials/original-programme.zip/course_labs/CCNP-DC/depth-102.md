# HSRP, VRRPv3 and IPv6 first-hop failure behavior

### Redundant gateways must represent usable service

Use Nexus 9000 NX-OS 10.3(x) HSRP and VRRP procedures. Build each protocol in a separate test VLAN rather than placing competing virtual gateways on the same test address. Verify platform and release support for IPv6, object tracking, timer granularity and vPC interactions. These examples are original and unexecuted.

A host needs a stable first-hop identity even when one router fails. An IPv4 virtual gateway combines an IP address with a virtual MAC learned through ARP. The routers retain their own physical interface identities for management and protocol operation. A forwarding host should not need a new configured default gateway after the active member fails. That stable identity does not guarantee an upstream route, sufficient surviving bandwidth or a working application return path.

HSRP elects active and standby roles; additional members can remain listeners. VRRP uses a primary/master role with backups, with terminology varying across documentation generations. Their election and default behaviors are not interchangeable. In the cited NX-OS HSRP workflow, preemption is disabled unless configured. VRRP normally allows a higher-priority candidate to preempt according to its protocol and implementation settings, with special behavior for an address owner. Inspect the actual version and configuration rather than transferring one protocol's defaults to the other.

### Priority, preemption and object tracking

Priority chooses preference among candidates, but liveness and preemption control when a better candidate takes over. A recovered high-priority HSRP router can remain standby if preemption is disabled. That can be a deliberate stability choice. A preemption delay allows routing and interfaces to stabilize before traffic returns to the preferred router. It is not a timer that guarantees the application has recovered; verify the dependencies it is meant to protect.

Tracking links the gateway role to another observation. Tracking only a local interface line protocol detects cable or carrier loss, but it can miss an upstream routing failure while the link stays up. Route-reachability tracking or a supported tracked service model can cover a different failure class. Choose the tracked object from the service dependency graph and consider false positives, shared paths and recursive dependencies.

For a synthetic HSRP group, A has priority 120 and B has 100. A tracks its upstream with decrement 30. When that object fails, A's effective priority becomes 90. If B is healthy and allowed to preempt, B can become active according to timers and state. A decrement of 10 would leave A at 110 and would not make B preferred. The arithmetic belongs in the design review, not only the troubleshooting session.

Faster Hellos and hold timers can reduce detection time but raise sensitivity to control-plane delay and loss. Total application interruption also includes election, MAC/neighbor updates, routing convergence and workload retry. Measure the end-to-end interval. A one-second role change does not prove a database transaction recovered in one second.

### IPv6 requires its own evidence

IPv6 first-hop behavior relies on Neighbor Discovery and Router Advertisements rather than ARP. HSRP for IPv6 uses HSRP version 2 and a virtual link-local first-hop identity. Hosts can learn a default router from advertisements associated with that virtual role. A global unicast address being reachable does not prove that a host's default-router list contains the intended virtual link-local address.

Inspect Router Advertisements, Neighbor Solicitations/Advertisements, router lifetime and neighbor-cache state during failover. A security policy that blocks necessary ICMPv6 can break address discovery or default routing while an IPv4 ping still succeeds. RA Guard placement must distinguish trusted router-facing ports from untrusted host-facing ports. Do not disable every IPv6 control simply because one legitimate RA was filtered; correct the trusted boundary and validate rogue advertisements remain blocked.

VRRPv3 supports separate IPv4 and IPv6 address-family groups in the documented NX-OS workflow. A working IPv4 group does not automatically create an IPv6 virtual gateway. Configure and verify the intended address family explicitly, including the interface's IPv6 addressing and the proper virtual address model. Do not copy legacy VRRPv2 syntax and assume it enables IPv6.

### Build two protocol-specific experiments

For HSRP IPv4, VLAN 102 contains gateway virtual IP 10.102.0.1/24, A at .2 and B at .3. Both routers have independent usable upstream paths. The following original fragment for A assumes the VLAN/SVI and routing prerequisites have been created:

```text
feature hsrp
track 102 interface Ethernet1/48 line-protocol
interface Vlan102
  ip address 10.102.0.2/24
  hsrp version 2
  hsrp 102
    ip 10.102.0.1
    priority 120
    track 102 decrement 30
    preempt delay minimum 30
```

Configure B with its unique interface address, the same group and virtual address, priority 100 and the intended preemption policy. Inspect `show hsrp`, the track object and host ARP state. Shut only the authorized test upstream and verify the effective priority, new role and continuous application traffic. Then create a failure beyond the local link and demonstrate the limitation of line-protocol tracking before replacing it with an appropriately designed route/service observation.

For the IPv6 HSRP experiment, use a separate supported interface or VLAN with documentation prefix 2001:db8:102::/64. Configure version 2, an IPv6 HSRP group and the documented virtual address method; `hsrp 102 ipv6` with `ip autoconfig` illustrates generation of the virtual link-local address. Record the host's actual learned default router and RAs before and after the transition.

For VRRPv3, use a separate VLAN and the `feature vrrpv3` and `vrrpv3 <group> address-family ipv4` or `ipv6` workflow. Set the intended virtual addresses and priorities, then inspect `show vrrpv3` and `show fhrp` with release-confirmed interface options. Do not enable HSRP and VRRP on the same virtual identity as a shortcut to a comparison; compare two isolated, fully specified services.

### Test independence and rollback

A vPC pair may have platform-specific first-hop forwarding optimizations, so distinguish the protocol role from the actual data-plane handling on each peer. Verify the supported vPC/FHRP design rather than assuming the standby never forwards or that both peers form an independent failure domain. Shared line cards, power, uplinks or a common upstream service can defeat a two-router diagram.

Acceptance includes normal operation, active-member loss, upstream failure with link still up, restoration delay, IPv4 and IPv6 host behavior and surviving capacity. Roll back by restoring the accepted gateway identities and tracking configuration, then observe roles and host caches. Keep an independent console path and ensure the virtual address remains unique. Recovery is proven by the application and the preserved control boundary, not solely by the word Active on one switch.

## Worked cases

### Tracking arithmetic does not meet the requirement

Synthetic: A 120 minus 10 remains above B 100. Upstream failure leaves A preferred.

Choose a decrement and preemption design that reflects the service requirement, then measure the actual transition. Also verify that the tracked object detects the failure class; arithmetic alone cannot fix an observation that stays up.

### IPv4 healthy, IPv6 default router missing

Synthetic: IPv4 ARP and HSRP work. IPv6 RAs from the legitimate router-facing port are blocked by an incorrect trust classification.

Inspect host default-router state and the RA policy. Restore the trusted router path while retaining anti-rogue protection on host ports. Verify the virtual link-local default and application behavior through failover.

## Guided build and fault isolation

Build HSRP and VRRPv3 in separate laboratory VLANs, with IPv4 and IPv6 host observations.

Hint: Do not infer the address-family state or preemption default from another protocol.

Instructor reasoning: Capture priorities, tracked objects, roles, ARP/ND/RA evidence and application interruption. Demonstrate a remote failure that local line tracking cannot detect.

## Independent assignment

Design and implement a gateway pair for a dual-stack application with a specified outage budget. Inject active-router loss, link-up upstream failure and restoration. Prove surviving capacity and identify every common physical dependency.

## Verified primary references

- [NX-OS 10.3(x): HSRP and IPv6](https://www.cisco.com/c/en/us/td/docs/dcn/nx-os/nexus9000/103x/unicast-routing-configuration/cisco-nexus-9000-series-nx-os-unicast-routing-configuration-guide-release-103x/m_configuring_hsrp.html)
- [NX-OS 10.3(x): VRRP and VRRPv3](https://www.cisco.com/c/en/us/td/docs/dcn/nx-os/nexus9000/103x/unicast-routing-configuration/cisco-nexus-9000-series-nx-os-unicast-routing-configuration-guide-release-103x/m_configuring_vrrp.html)
- [IPv6 Neighbor Discovery, RFC 4861](https://www.rfc-editor.org/rfc/rfc4861.html)
