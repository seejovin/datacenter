# NDO 4.2: build two ACI sites, deploy schemas and reconcile versions

### Pin the orchestration model

This workbook uses NDO 4.2(x) workflows with on-premises ACI sites and APIC 5.2(x) feature assumptions. Verify the exact Nexus Dashboard host release and supported APIC maintenance images before installation. The public NDO guide allows mixed APIC releases subject to onboarding and feature compatibility checks; that is not permission to assume every NDO feature works on every APIC release. Earlier CCNP examples used APIC 6.x where stated. This chapter deliberately supplies a bridge to the APIC 5.x family listed in the retrieved CCIE equipment baseline. No live Cisco execution is claimed.

Nexus Dashboard hosts services. NDO manages policy across separately controlled fabrics. Each site's APIC remains its local controller. NDO is not a substitute for the site's access-policy graph, and its presence does not turn two fabrics into one APIC cluster. The inter-site network carries the required control and data traffic; a working HTTPS session from NDO to APIC does not prove that inter-site encapsulated traffic can cross it.

Design three planes independently: management access between controllers, inter-site infrastructure reachability and tenant policy. Give every site a unique identity, allocate non-overlapping infrastructure addressing and record ASNs and transport MTU. Keep the original fabric's internal TEP pool distinct from the inter-site addresses required by the chosen procedure. A copied address worksheet can create a data-plane conflict even when site onboarding succeeds.

### Prepare and onboard two sites

Use Site EAST and Site WEST, each with a supported APIC cluster, a spine path to a dedicated inter-site network and a leaf pair for endpoints. First prove that each site works independently. Prepare the required pod policy and the spine external attachment graph in each APIC: the documented VLAN pool, external routed domain, AEP, interface policy group and selectors must lead to the intended spine ports. For this NDO baseline the guide uses VLAN 4 for the inter-site subinterface attachment. Treat it as part of this documented workflow, not a universal tenant VLAN convention.

Add the controllers to Nexus Dashboard, validate trust and reachability, then enable them for NDO management with unique site IDs. A site existing in the hosting platform is not yet proof that NDO manages it. If NDI will also use the site, follow the in-band connectivity requirements; do not select a convenient out-of-band address and assume every service shares the same access model.

In NDO's site-to-site connectivity workflow, configure the selected BGP peering design and each site's overlay, pod and spine details. Choose the documented underlay method consistently and verify the external routed domain binding. Deploy infrastructure and inspect the status of each site separately. Refresh topology information after an authorized spine or node-ID change. A previously discovered node list is not guaranteed to track such a change without reconciliation.

### Build the policy graph before stretching anything

A schema organizes application templates. A template is a deployment and versioning unit, while its site association determines where policy is instantiated. Some attributes are common and others are local to a site. Write the desired graph first: tenant ACADEMY, VRF BLUE, one application profile, two bridge domains, EPG WEB at EAST and EPG API at WEST, and a contract permitting WEB to initiate TCP 443 to API. Keep an unrelated EPG denied. Initially avoid unnecessary Layer-2 stretch; the requirement is a routed application exchange.

Create the required tenant and routing context, then bridge domains and EPGs with their references, then filters/contracts and consumer/provider relationships. Associate templates to the intended sites and fill local attachment properties. A correct global EPG name does not populate a missing local domain or path binding. Review dependency order across templates before deployment; an application template cannot reference a missing prerequisite merely because both are saved in the same schema.

NDO can create shadow objects in another site to represent policy dependencies, such as a remote provider or consumer. Those objects are generated parts of the cross-site policy graph. Deleting them directly in APIC can break the relationship and create drift. The absence of a local endpoint binding on a shadow EPG can be expected. Check object ownership and the deployment plan before treating a similarly named remote object as a duplicate to remove.

### Review a concrete deployment plan

Save the template, associate it with sites and inspect the deployment plan's additions, modifications and deletions for every affected site. A contract added at WEST can require generated objects at EAST. Filtering the visual display to show only additions does not remove hidden deletions from the operation. Review the complete plan and payload, record the template version and obtain the configured approvals. Then deploy and record per-site results.

Use three acceptance layers. First, confirm NDO's intended version and site status. Second, inspect the effective APIC managed objects and faults. Third, run WEB-to-API TCP 443 and meaningful negative tests, including an unrelated EPG and an unauthorized destination port. Repeat a local service test during inter-site transport loss. This separates application requirements from a broad claim that all traffic survives every partition.

A partial deployment requires a state ledger: intended version, version accepted at EAST, version accepted at WEST, and observed application behavior. Do not repeatedly redeploy the whole schema while ignoring one site's unsupported feature or trust failure. Repair the identified prerequisite, recompute the plan and decide whether to complete forward or restore an accepted version. Preserve the known-good local service while resolving remote policy.

### API concurrency and rollback

The NDO 4.2 template operations guide documents optimistic version checks for supported Site and Schema PUT/PATCH operations. A client first reads the object and retains its `_updateVersion`. It enables version checking explicitly; ordinary API use must not be assumed to inherit the GUI's protection. An original unexecuted PATCH teaching example is:

```text
PATCH /mso/api/v1/schemas/lab-schema-98?enableVersionCheck=true
[
  {
    "op": "replace",
    "path": "/templates/APP/displayName",
    "value": "Reviewed application template",
    "_updateVersion": 7
  }
]
```

If another writer saved version 8 after the read, the client should treat the stale-version rejection as a conflict: read current state, compare both changes and prepare a new authorized proposal. Blindly changing the version number to the newest value without reconciling the payload defeats the protection. Use trusted TLS and an authorized secret source in a real client; no credentials belong in this workbook.

Restoring an earlier template version creates a new current version containing the older configuration. It does not erase history or guarantee that every external dependency still exists. Check referenced sites and objects, site association differences and approval requirements before deploying the restoration. A missing dependency can legitimately block rollback. Back up the controller state independently and preserve the per-site evidence ledger. Successful recovery means the accepted policy and actual application behavior agree, with generated objects and ownership reconciled.

## Worked cases

### Remote contract produces local shadow state

Synthetic: adding WEB-consumer to API-provider across EAST/WEST yields generated objects at both sites. Reviewer expects changes only at WEST.

Follow references in the complete deployment plan. The remote relationship can require shadow state at EAST; validate its purpose and ownership. Review all sites before approval, then test the permitted TCP exchange and denied flows.

### Concurrent edit plus one-site rejection

Synthetic: a stale API edit is rejected at schema version 7; after reconciliation, EAST deploys the new plan but WEST rejects a feature.

Handle these as separate failures. First reconcile optimistic concurrency without overwriting the other author. Then inspect WEST compatibility and retain a per-site version ledger. Choose a reviewed forward correction or supported restoration; do not repeatedly submit the stale payload.

## Guided build and fault isolation

Prepare two independent ACI sites, onboard them to ND and NDO, deploy inter-site infrastructure, then build the BLUE routed application contract.

Hint: Keep management, infrastructure and tenant policy in separate evidence columns.

Instructor reasoning: The result must show correct site ownership, infrastructure status, template associations, generated dependencies, effective APIC policy and positive/negative application tests. Simulate a concurrent API writer offline before any real API mutation.

## Independent assignment

Recreate the two-site policy from the requirement graph. Inject a missing site-local binding and a stale version update. Restore an earlier accepted template while preserving history and explain any dependency that blocks rollback. Record exact APIC, NDO and Nexus Dashboard compatibility evidence.

## Verified primary references

- [NDO 4.2: site onboarding and APIC compatibility](https://www.cisco.com/c/en/us/td/docs/dcn/ndo/4x/configuration/cisco-nexus-dashboard-orchestrator-configuration-guide-aci-421/ndo-configuration-aci-infra-add-sites-42x.html)
- [NDO 4.2: APIC site preparation](https://www.cisco.com/c/en/us/td/docs/dcn/ndo/4x/configuration/cisco-nexus-dashboard-orchestrator-configuration-guide-aci-421/ndo-configuration-aci-infra-config-sites-42x.html)
- [NDO 4.2: infrastructure settings](https://www.cisco.com/c/en/us/td/docs/dcn/ndo/4x/configuration/cisco-nexus-dashboard-orchestrator-configuration-guide-aci-421/ndo-configuration-aci-infra-apic-42x.html)
- [NDO 4.2: schema and shadow-object model](https://www.cisco.com/c/en/us/td/docs/dcn/ndo/4x/configuration/cisco-nexus-dashboard-orchestrator-configuration-guide-aci-421/ndo-configuration-aci-managing-schemas-42x.html)
- [NDO 4.2: template operations and concurrency](https://www.cisco.com/c/en/us/td/docs/dcn/ndo/4x/configuration/cisco-nexus-dashboard-orchestrator-configuration-guide-aci-421/ndo-configuration-aci-common-template-actions-42x.html)
