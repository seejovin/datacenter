# CFS transport, application scope, regions, locks and merge semantics

### CFS distributes application state

Use the Cisco MDS NX-OS 9.x CFS guide and the separate guide for each application being distributed. Cisco Fabric Services is a shared mechanism for discovering peers and coordinating application databases. It is not the Fibre Channel forwarding protocol and does not mean every switch has an identical entire running configuration. The application decides what data exists, which peers participate and how conflicting databases are reconciled.

Make a distribution ledger before enabling anything. For each application, record its support on every platform, distribution enabled state, logical or physical scope, transport, region where applicable, session owner, pending changes and active result. A healthy ISL proves a physical relationship; it does not prove that an application is registered or accepting distribution. Global CFS enablement and per-application enablement are separate gates. A disabled application can refuse both sending and accepting its database even though another application synchronizes normally.

A logical scope is associated with a VSAN. A physical scope spans the relevant physical topology rather than one VSAN. Some applications use a selected subset of switches or VSANs. These scopes are capabilities of the application and implementation, not arbitrary interchangeable settings. In the cited MDS baseline, CFSoIP supports physical-scope distribution; it does not carry every logical VSAN-scoped application merely because IP connectivity exists.

### Transport is not semantic compatibility

CFSoFC carries CFS using the Fibre Channel infrastructure. CFSoIP permits suitable distribution across IP reachability, including supported mixed FC/IP topologies. Enabling both does not mean an operator should manually duplicate every update through both paths. The implementation coordinates delivery; the engineer still verifies the intended participants and application results.

IP discovery can use a multicast mechanism or a configured static-peer model. Static peers can be useful where multicast discovery is unavailable, but they change discovery scope and must be maintained. A configured peer address that routes through the wrong VRF or fails the applicable policy remains unusable. DNS labels, a working web login and generic management ping do not establish the actual CFS path.

Mixed Nexus and MDS support requires two checks: transport compatibility and application compatibility. A common CFS transport does not make a new command understood by an older application version. A release upgrade can add fields that a peer cannot accept. Before distributing a new feature, compare exact releases and supported application semantics. Use a harmless isolated change to validate participation, then examine every peer's effective database rather than relying on one successful local message.

### Coordinated sessions and recovery

A coordinated change obtains the relevant fabric/application lock, holds pending state, distributes the accepted database through its commit operation, and releases the lock. Other distribution modes exist for data whose updates have different coordination needs. Do not infer that all applications share one universal global transaction with identical failure semantics. Use each application's documented commit, abort and status commands.

For the DPVM application from chapter 095, inspect the pending difference and owner before deciding to commit. `dpvm abort` from the originating editing context and the documented session-recovery commands have different implications from disabling CFS globally. A global disable isolates all affected application distribution on that switch while leaving physical connectivity; it can create a wider state divergence than the one blocked edit. Preserve evidence before clearing a lock because it identifies who was changing which database.

Commit success is an operational result that still needs scope verification. Confirm all intended peers, the accepted database revision or content, the absence of unresolved pending state and the separate active/application state. Persistence remains another step: accepted running state should be saved using the supported procedure and independently backed up. A command that saves configuration cannot turn an uncommitted pending proposal into an accepted distributed change.

### Regions and the default-scope trap

CFS regions can limit supported application distribution within a physical fabric. They are assigned per application, so two applications on the same switch may have different distribution boundaries. A region is not a VSAN and is not cryptographic authentication. Check application support before relying on a region to constrain a particular feature.

The default region has special operational significance. Removing an application from its configured region returns it to the default distribution context; deleting a region can return all its applications there. In the documented behavior, that can broaden scope rather than stop distribution. Therefore 'delete the region to isolate this switch' is a dangerous mental model. Predict the resulting peer set before changing region membership and confirm it afterward.

For an original synthetic example, switches A and B share region 7 for a supported NTP distribution application, while C remains in the default region. The requirement is that A/B share the laboratory time-server configuration while C keeps a different approved source. Deleting region 7 is not an acceptable cleanup unless the resulting default scope is intended. Compare the expected peer set and application database before and after the proposed edit offline.

### A build and merge workbook

Begin with three isolated supported switches and a disposable application configuration. Capture these read-only commands, using local help for release-specific optional syntax:

```text
show cfs status
show cfs application
show cfs lock
show cfs peers
show cfs regions
```

Use the application guide to enable distribution deliberately on all intended peers. For the region experiment, the following unexecuted fragment illustrates assigning the supported NTP application to a region; it does not configure the time servers themselves:

```text
cfs region 7
  ntp
```

Change one approved laboratory value through the application's transaction workflow, inspect the pending result, commit and verify each intended participant. Then disable distribution for that application on one peer in the isolated lab and repeat with a harmless change. Explain the difference between physical reachability and acceptance of application state. Restore and reconcile the peer before continuing.

For a merge test, keep two test fabrics apart while creating one compatible and one conflicting application mapping. Joining them introduces a merge event: CFS coordinates the exchange, while the application decides whether the databases can be combined. Compare the application-specific outcome rather than assuming 'ISL up' means 'all policy merged'. If the result is rejected, preserve the conflict, separate the test fabrics under the approved plan, reconcile the intended values, and repeat. Never resolve a conflict by widening every access policy.

Acceptance includes a participant matrix, before/after databases, an intentional rejected or blocked change, a successful reconciled merge and a restoration of the original boundaries. It also includes workload evidence where the application affects storage access. The goal is to reason about distributed state and ownership, not memorize one global enable command.

## Worked cases

### Reachable peer, excluded application

Synthetic: three CFS peers appear; one switch has distribution disabled for the target application and retains an older database.

Do not debug the whole FC fabric first. Compare global state, application registration and enablement, scope and pending session. Restore approved participation, reconcile the accepted database and verify every intended peer.

### Cleanup broadens scope

Synthetic: A/B use a region for NTP distribution; C uses default scope. A proposed cleanup deletes the region.

Model the resulting default membership before any change. The deletion can broaden distribution instead of isolating A/B. Preserve or deliberately redesign the scope and prove C keeps its approved configuration.

## Guided build and fault isolation

Build a participant ledger for three switches and two applications. Demonstrate one application-specific disablement and one region boundary.

Hint: Separate transport, registration, enablement, scope, transaction and persistence.

Instructor reasoning: The ledger must explain why a physical neighbor can remain outside an application update. Predict the peer set after region removal without performing an unreviewed broad change.

## Independent assignment

Construct compatible and conflicting synthetic merge cases for DPVM and a supported physical-scope application. In a supported isolated lab, reproduce one rejected merge, reconcile the database, and capture per-peer acceptance plus a rollback to the original boundaries.

## Verified primary references

- [MDS 9.x: CFS infrastructure, transport and regions](https://www.cisco.com/c/en/us/td/docs/dcn/mds9000/sw/9x/configuration/system-management/cisco-mds-9000-nx-os-system-management-configuration-guide-9x/using_the_cfs_infrastructure.html)
- [MDS 9.x: DPVM application workflow](https://www.cisco.com/c/en/us/td/docs/dcn/mds9000/sw/9x/configuration/fabric/cisco-mds-9000-nx-os-fabric-configuration-guide-9x/creating_dynamic_vsans.html)
