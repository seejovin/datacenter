# DPVM identity selection, distributed state and storage mobility

### Membership follows an identity, not a cable label

Use Cisco MDS NX-OS 9.x with the exact selected maintenance release recorded. DPVM is Dynamic Port VSAN Membership: it associates a device identity with a VSAN so a supported attachment can retain its intended logical fabric when moved. The decision is made using the active mapping during fabric login. Static interface configuration, a configured mapping database, the active mapping database and observed login state are four different records. Reading only the configuration is therefore an incomplete diagnosis.

The device port WWN identifies the relevant port identity; a node WWN can identify the broader device node. Where both mappings match, the port-specific mapping takes precedence on this baseline. That precedence makes a narrow exception possible, but it can also leave an old exception overriding a recently changed node policy. Do not confuse these identifiers with a dynamically assigned FCID, a human-readable device alias or a LUN number. DPVM selects VSAN membership; it is not an address allocator, zoning policy or storage array masking policy.

A correct target VSAN must exist and be operational. The selected attachment is a supported F port, and the static port VSAN must also satisfy the documented validity requirements. A mapping does not magically create or reactivate a suspended VSAN. If an effective dynamic VSAN is removed or suspended, the device path can be shut down. That behavior is much safer to predict before a cleanup change than discover during a production boot failure.

### Configuration, distribution and activation

DPVM uses CFS to coordinate its mapping database. A pending change is neither a completed distribution nor an activated forwarding decision. Work in one authorized editing session, inspect its pending differences, commit the accepted database and activate it through the documented workflow. Inspect the active database after activation and confirm behavior at the next appropriate login event. If activation reports a conflict, record the conflicting identity and current mapping. A force option is not a reasoning step: it chooses to override state whose service impact must first be understood.

The baseline guide requires enhanced device-alias mode for this feature. Enhanced device aliases and enhanced zoning are separate mechanisms; enabling one does not establish the mode of the other. A device alias can improve readability but requires a verified mapping to the intended WWPN. A familiar alias name pointing to a replaced HBA is still the wrong identity. Retain raw WWPNs in the change evidence even when the operational command uses an alias.

Autolearn can derive mapping information from observed attachments. It is useful for discovery and migration, but it can also preserve a mistaken initial port placement. Learned state must be reviewed against the approved host-to-fabric design. Do not treat 'learned automatically' as proof of authority. Before moving a device, record whether a matching entry is explicit or learned, where it was observed and whether all relevant switches share the accepted active database.

### Build a controlled mobility exercise

Use two MDS switches in one laboratory fabric and a dual-path test host whose other path remains available. Keep the A and B fabrics independent; do not connect them merely to distribute a convenience database. Create test VSANs 95 and 96 with appropriate ISL transport and zoning prerequisites. The approved port identity `20:00:00:00:00:00:00:95` belongs in VSAN 95 even if attached to a port whose static VSAN is 96. These identifiers are invented examples, not discovered hardware identities.

The following unexecuted teaching sequence assumes the support and VSAN prerequisites have already been checked. Changing alias mode is itself a reviewed fabric operation, so do it only in the isolated initial build and inspect the current mode before reuse:

```text
feature dpvm
device-alias mode enhanced
device-alias commit
dpvm database
  pwwn 20:00:00:00:00:00:00:95 vsan 95
exit
show dpvm pending
show dpvm pending-diff
dpvm commit
show dpvm database
dpvm activate
show dpvm database active
show dpvm status
```

Confirm exact prompt context and distribution settings on the chosen image. Compare databases on both switches. Then log in the test device and inspect FLOGI and name-server state in VSAN 95. Moving the cable should be an authorized disruption with a verified alternate path, not an unannounced live experiment. After the move, correlate WWPN, VSAN, new attachment and FCID. Do not assume FCID persistence: identity-based VSAN selection does not promise that all address allocation remains unchanged after a move.

Finally, verify the active zone permits the approved initiator-target pair and the array exposes only the assigned test LUN. Successful FLOGI proves attachment to the fabric, not the final storage service. Perform bounded read/write verification to a disposable volume, check multipath state and test that an unrelated initiator cannot see the volume. Preserve the storage team's masking evidence alongside the switch evidence.

### Diagnose four different mobility failures

First, leave the accepted mapping only in the configured database without activation. Predict that the active database remains authoritative at login. Second, configure a conflicting port-specific mapping alongside the desired node mapping and explain precedence. Third, suspend the intended VSAN and identify the difference between an identity match and a usable logical fabric. Fourth, let fabric membership succeed while retaining stale zoning for the old initiator. These faults have different repair points even if the user sees the same symptom: a missing disk.

For rollback, restore the accepted mapping and database state rather than inventing a new WWPN or assigning every host to the default VSAN. Reconcile pending sessions, active state and persistence. Schedule any required logout/login or port disruption with the host owner; do not assume activation immediately repairs every established session without impact. Record which path carried I/O throughout the change. A complete acceptance record demonstrates identity correctness, logical-fabric membership, authorized target reachability and workload integrity after movement.

## Worked cases

### The right database is not yet active

Synthetic: show dpvm database maps the test pWWN to 95; show dpvm database active maps it to 96; login occurs in 96.

The device followed active state. Review pending/conflicting changes, commit and activate through the selected release workflow, then coordinate the login event and verify fabric membership. Do not alter array masking to compensate for wrong VSAN membership.

### A narrow exception defeats a broad policy

Synthetic: nWWN maps the test server node to 95 but its old pWWN exception maps one HBA to 96.

The specific pWWN entry wins. Confirm which HBA path is affected, retire or correct the approved exception, and validate the A/B path design. A node-level edit alone cannot override this specific mapping.

## Guided build and fault isolation

Build two-switch DPVM membership for one test host, capture configured/active state, then move the supported F-port attachment.

Hint: Carry the raw WWPN through every record; do not rely only on aliases.

Instructor reasoning: The post-move identity must map to the approved VSAN, with zoning and masking still correct. Separately demonstrate an inactive database change and explain why it does not affect login.

## Independent assignment

Create an approved identity ledger for three synthetic hosts, including a node mapping and one port exception. Reconcile it against active DPVM and zoning fixtures, propose a safe migration order, and execute the order only in a supported isolated lab with a disposable volume.

## Verified primary references

- [MDS 9.x: Dynamic VSANs and DPVM](https://www.cisco.com/c/en/us/td/docs/dcn/mds9000/sw/9x/configuration/fabric/cisco-mds-9000-nx-os-fabric-configuration-guide-9x/creating_dynamic_vsans.html)
- [MDS 9.x: CFS infrastructure](https://www.cisco.com/c/en/us/td/docs/dcn/mds9000/sw/9x/configuration/system-management/cisco-mds-9000-nx-os-system-management-configuration-guide-9x/using_the_cfs_infrastructure.html)
