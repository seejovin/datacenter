# Linux namespace, VLAN, bond and bridge packet-walk lab

Use a disposable Linux VM or authorized isolated lab. The commands below alter local network state and require appropriate capabilities. They were not executed here. Do not run them in the namespace of a workstation or server that carries important services without an isolated plan and cleanup. The code package's offline exercises do not require these privileges.

**Minimal namespace/bridge construction.** This demonstrates a local Layer-2 path without Internet routing or NAT:

```bash
ip netns add dc_app
ip link add dc_veth type veth peer name dc_eth
ip link set dc_eth netns dc_app
ip link add dc_br type bridge
ip link set dc_veth master dc_br
ip link set dc_br up
ip link set dc_veth up
ip -n dc_app link set lo up
ip -n dc_app link set dc_eth up
ip addr add 10.200.0.1/24 dev dc_br
ip -n dc_app addr add 10.200.0.2/24 dev dc_eth
```

Inspect the host and namespace separately using supported `ip link`, `ip -n dc_app addr`, `ip -n dc_app route`, `bridge link` and neighbor commands. Test only the local10.200.0.1↔10.200.0.2 path. No default route is needed for this same-subnet experiment. Explain where ARP crosses the veth pair and bridge. Remove the host veth's bridge membership in a controlled test and compare captures on the namespace end, host end and bridge.

Cleanup in this disposable lab:

```bash
ip netns del dc_app
ip link del dc_br
```

Deleting the namespace removes the moved veth endpoint and its peer under the normal veth lifecycle; verify cleanup explicitly and remove any remaining lab-only interface if the experiment changed that relationship. Never substitute a real bridge/interface name into cleanup without verifying ownership.

**VLAN-aware extension.** Choose one coherent design: VLAN subinterfaces on a parent/bond feeding separate bridges, or a VLAN-filtering bridge over an uplink. Record where a tag is added, retained or removed. On the peer switch, record allowed VLAN and native/tagged behavior. Intentionally omit one VLAN from one side and use captures to distinguish no tag, wrong tag and correct tag rejected later.

**Bond extension.** Use actual disposable NICs or an appropriate provider lab to compare active-backup and802.3ad. For802.3ad, configure a matching supported upstream LACP group; do not attach independent access ports and assume the host bond creates the switch configuration. Inspect `/proc/net/bonding/<lab-bond>` and the upstream LACP state. Test one member loss under workload, then test the shared-switch failure assumption analytically or physically as authorized. Two members on one switch do not prove switch independence.

**Acceptance.** Deliver a packet walk from application namespace through veth, bridge/VLAN, bond/member and upstream switch, with route and firewall/NAT stages only where actually configured. Include one missing bridge member, one VLAN mismatch and one aggregation mismatch. A local VM demonstrates Linux logical behavior; it does not prove physical NIC offloads, line-rate performance or production CNI behavior.
