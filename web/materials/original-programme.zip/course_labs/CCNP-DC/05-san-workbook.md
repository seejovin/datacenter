# MDS SAN construction, identity and active zoning

Use a supported MDS lab with an initiator and disposable target volume, or an authorized provider lab. This workbook's WWPNs and outputs are synthetic and its commands were not executed on equipment here. Pin NX-OS, switch model, optic and array/HBA compatibility. Keep A/B fabrics independent unless a separately approved design requires otherwise.

**Requirement.** Initiator LAB-HOST may access only LAB-TARGET in VSAN20 and only the intended disposable LUN through array masking. A second unrelated initiator must remain denied. A single-fabric outage must preserve required application I/O through the separately commissioned other fabric.

Illustrative logical construction:

```text
vsan database
  vsan 20 name LAB_A
  vsan 20 interface fc1/1
  vsan 20 interface fc1/2
interface fc1/1
  switchport mode F
  no shutdown
interface fc1/2
  switchport mode F
  no shutdown
device-alias database
  device-alias name LAB-HOST pwwn 20:00:00:25:b5:00:00:11
  device-alias name LAB-TARGET pwwn 50:00:00:25:b5:00:00:21
  exit
device-alias commit
zone name LAB-HOST-TO-TARGET vsan 20
  member pwwn 20:00:00:25:b5:00:00:11
  member pwwn 50:00:00:25:b5:00:00:21
zoneset name LAB-ACTIVE vsan 20
  member LAB-HOST-TO-TARGET
```

Before activation, compare the proposed full database with the actual active zoneset. The example intentionally uses explicit WWPN members while creating aliases for readable identity records, avoiding an assumption about device-alias mode. In a real existing fabric, do not activate a tiny lab zoneset that omits production zones. Use the selected release's supported transaction and CFS procedure, coordinate existing session ownership and activate only the reviewed complete intended policy for the isolated VSAN.

Illustrative activation command for this isolated lab is `zoneset activate name LAB-ACTIVE vsan 20`. Confirm the exact syntax and mode for the selected platform. Record the active policy before and after. Read the supported forms of `show flogi database`, `show fcns database`, `show zoneset active vsan 20`, `show device-alias database`, VSAN/port state and interface error/credit counters.

**Interpretation ladder.** FLOGI shows initiator attachment and FCID assignment. FCNS shows registered fabric identity. Active zoning permits the communication pair. Array masking exposes a volume. Host discovery/multipathing presents the intended device. Only an application read/write with integrity checks demonstrates useful storage service. A management ping to the array is not a substitute for this chain.

**Faults.** Replace the initiator WWPN in a proposed zone with a retired identity; leave a correct zone unactivated; remove the required VSAN from an ISL; disable or constrain required upstream NPIV in a supported NPV exercise; and analyze supplied credit/CRC time series. Introduce one fault at a time. Do not intentionally corrupt valuable data; use disposable volumes and known test patterns.

For credit diagnosis, compare deltas over the incident interval. Persistent transmit-credit-zero time with clean CRC and a slow receiver suggests a different mechanism from rising CRC/link resets. For distance, estimate the in-flight byte budget and check supported credit allocation. A simplified calculation is not a physical measurement, and buffer settings must follow actual platform accounting.

**Recovery.** Restore the approved active policy, verify both fabrics and correct LUN identity, perform workload I/O, then test supported one-path/fabric loss and return. Record interruption against application timeout. If only one path remains after repair, report degraded service rather than closing the dual-path requirement.
