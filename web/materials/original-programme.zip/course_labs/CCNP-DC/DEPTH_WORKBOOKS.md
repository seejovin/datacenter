# Protocol and controller depth workbooks

These are original teaching cases and unexecuted vendor implementation sequences. The Python models run offline; they do not emulate Cisco devices or award practical competence.

Run from the project root:

```bash
python course_labs/CCNP-DC/depth_checks.py --self-test
python course_labs/CCNP-DC/depth_checks.py --demo
```

The demonstration checks timestamp arithmetic, external-route cost, DPVM precedence, role-based logical pairs, controller version conflicts, bounded template inputs, telemetry rate and snapshot timing. CFS region, TRM gate, prefix-range, tracked-priority, conceptual membership-filter and structured merge/replacement exercises are intentionally narrow models. Read their assumptions before changing inputs.

- [OSPF link-state databases, areas, flooding and route calculation](depth-092.md)
- [PTP, NTP and defensible time-quality measurements](depth-093.md)
- [Tenant routed multicast: MVPN signaling, transport trees and receiver delivery](depth-094.md)
- [DPVM identity selection, distributed state and storage mobility](depth-095.md)
- [Enhanced zoning transactions, smart zoning roles and safe fabric merges](depth-096.md)
- [CFS transport, application scope, regions, locks and merge semantics](depth-097.md)
- [NDO 4.2: build two ACI sites, deploy schemas and reconcile versions](depth-098.md)
- [NDFC 12.1.2e: fabric construction, attachments, templates and reconciliation](depth-099.md)
- [NDI 6.3.1: onboarding, telemetry, flow analysis and evidence quality](depth-100.md)
- [BGP best-path selection, prefix policy and advertisement control](depth-101.md)
- [HSRP, VRRPv3 and IPv6 first-hop failure behavior](depth-102.md)
- [IGMP, MLD and snooping: receiver state, source filters and aging](depth-103.md)
- [NX-OS checkpoint, configuration replace and verified recovery](depth-104.md)

For each workbook, write predictions before reading the worked solution. Change a fixture or function call to create a failing case, record the narrow cause, then correct only that cause. The independent vendor task requires exact supported hardware/software, authorized access, before/after output, workload tests and a reviewer. No result in depth_demo_synthetic.json is observed vendor output.

The NDO/NDFC/NDI versions are separate teaching baselines. Do not assume that sharing a Nexus Dashboard name proves joint version compatibility. The APIC 5.x bridge in chapter 098 does not relabel older APIC 6.x examples.
