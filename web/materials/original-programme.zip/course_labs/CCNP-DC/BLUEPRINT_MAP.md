# CCNP Data Center: current public blueprint crosswalk

Checked 19 September 2026. This programme teaches all five curriculum courses. Provider leaf IDs, original chapter outcomes and question IDs are separate namespaces. A shared question is counted once even where it supports related outcomes. The linkage identifies supporting chapter banks; it does not imply that every item in a chapter independently assesses every linked subtopic.

All supplied cases are original and synthetic. Public outline alignment is distinct from observed platform competence and independently reviewed exam readiness.

## DCCOR — v1.2

[Official public outline](https://learningcontent.cisco.com/documents/marketing/exam-topics/350-601-DCCOR-v1.2.pdf)

| Provider leaf | Authored scope | Chapters | Supporting question IDs |
|---|---|---|---|
| 1.1.a | OSPF adjacency and forwarding | L004, L052 | Q0025–Q0032, Q0409–Q0416, Q0913–Q0920 |
| 1.1.b | Multiprotocol BGP implementation | L005, L008, L052 | Q0033–Q0040, Q0057–Q0064, Q0409–Q0416, Q0913–Q0920 |
| 1.1.c | Multicast tree construction | L006, L053 | Q0041–Q0048, Q0417–Q0424, Q0921–Q0944 |
| 1.1.d | Gateway redundancy behaviour | L006, L042 | Q0041–Q0048, Q0329–Q0336, Q0809–Q0832 |
| 1.2 | Loop avoidance and aggregation | L002, L003 | Q0009–Q0024 |
| 1.3 | EVPN overlay implementation | L007, L008, L009 | Q0049–Q0072 |
| 1.4.a | ACI initial construction | L027, L028 | Q0209–Q0224, Q0705–Q0720 |
| 1.4.b | ACI attachment policy | L029 | Q0225–Q0232, Q0721–Q0728 |
| 1.4.c | Virtualization integration | L036 | Q0281–Q0288, Q0777–Q0784 |
| 1.5 | Packet forwarding classes | L001, L002, L006, L008, L033 | Q0001–Q0016, Q0041–Q0048, Q0057–Q0064, Q0257–Q0264, Q0753–Q0760 |
| 1.6 | Cloud operating models | L089 | Q1001–Q1008 |
| 1.7.a | Software upgrade continuity | L010 | Q0073–Q0080 |
| 1.7.b | Programmable logic maintenance | L010, L022 | Q0073–Q0080, Q0169–Q0176 |
| 1.7.c | Software patch lifecycle | L010 | Q0073–Q0080 |
| 1.8 | Configuration persistence and recovery | L001, L010 | Q0001–Q0008, Q0073–Q0080 |
| 1.9 | Network observation methods | L010, L038, L080 | Q0073–Q0080, Q0297–Q0304, Q0633–Q0640 |
| 1.10 | Streaming assurance interpretation | L080, L081, L083 | Q0633–Q0648, Q0657–Q0664 |
| 1.11 | Dashboard management capabilities | L010, L076, L083 | Q0073–Q0080, Q0601–Q0608, Q0657–Q0664 |
| 2.1 | Rack server implementation | L011, L015 | Q0081–Q0088, Q0113–Q0120 |
| 2.2.a | Blade infrastructure enrollment | L012, L013, L056 | Q0089–Q0104, Q0441–Q0448, Q0953–Q0960 |
| 2.2.b | Compute infrastructure administration | L012, L016, L017 | Q0089–Q0096, Q0121–Q0136 |
| 2.2.c | Ethernet server attachment | L013, L014 | Q0097–Q0112 |
| 2.2.d | SAN server attachment | L013, L014, L015, L020 | Q0097–Q0120, Q0153–Q0160 |
| 2.2.e | Server identity and boot | L013, L015 | Q0097–Q0104, Q0113–Q0120 |
| 2.3 | UCS-X managed policies | L016 | Q0121–Q0128 |
| 2.4 | Compute upgrade compatibility | L017, L057 | Q0129–Q0136, Q0449–Q0456 |
| 2.5 | Compute backup and restore | L017 | Q0129–Q0136 |
| 2.6 | Compute traffic observation | L014, L017, L057 | Q0105–Q0112, Q0129–Q0136, Q0449–Q0456 |
| 3.1.a | FC fabric initialization | L019 | Q0145–Q0152 |
| 3.1.b | FC link aggregation | L022, L048 | Q0169–Q0176, Q0377–Q0384, Q0881–Q0896 |
| 3.1.c | FC address assignment | L019 | Q0145–Q0152 |
| 3.1.d | Fabric configuration coordination | L020 | Q0153–Q0160 |
| 3.1.e | Zoning implementation | L020 | Q0153–Q0160 |
| 3.1.f | Fabric name registration | L019 | Q0145–Q0152 |
| 3.1.g | Persistent device naming | L020 | Q0153–Q0160 |
| 3.1.h | Virtualized fabric attachment | L021 | Q0161–Q0168 |
| 3.1.i | Virtual SAN separation | L019, L021 | Q0145–Q0152, Q0161–Q0168 |
| 3.2 | IP storage implementation | L018, L023 | Q0137–Q0144, Q0177–Q0184 |
| 3.3 | Storage software maintenance | L022 | Q0169–Q0176 |
| 3.4 | Storage traffic observation | L022, L059 | Q0169–Q0176, Q0465–Q0472 |
| 4.1.a | Event-triggered automation | L075, L061 | Q0481–Q0488, Q0593–Q0600, Q0985–Q0992 |
| 4.1.b | Scheduled automation | L075, L061 | Q0481–Q0488, Q0593–Q0600, Q0985–Q0992 |
| 4.1.c | On-device shell environments | L075 | Q0593–Q0600 |
| 4.1.d | Structured management interfaces | L060, L077 | Q0473–Q0480, Q0609–Q0616, Q0977–Q0984 |
| 4.1.e | On-device Python execution | L075 | Q0593–Q0600 |
| 4.2.a | Ansible application | L070, L071 | Q0553–Q0568 |
| 4.2.b | Python integration | L073, L077, L083 | Q0577–Q0584, Q0609–Q0616, Q0657–Q0664 |
| 4.2.c | Automated bootstrap | L074 | Q0585–Q0592 |
| 4.2.d | Dashboard workflows | L076 | Q0601–Q0608 |
| 4.2.e | PowerShell application | L090 | Q1009–Q1016 |
| 4.2.f | Terraform application | L072 | Q0569–Q0576 |
| 4.2.g | Intersight orchestration | L016, L049 | Q0121–Q0128, Q0385–Q0392, Q0897–Q0904 |
| 4.3 | AI fabric requirements | L041, L044, L045, L047, L067 | Q0321–Q0328, Q0345–Q0360, Q0369–Q0376, Q0529–Q0536, Q0793–Q0808, Q0841–Q0872 |
| 5.1.a | Network administrative authority | L024 | Q0185–Q0192 |
| 5.1.b | ACI access segmentation | L031, L032 | Q0241–Q0256, Q0737–Q0752 |
| 5.1.c | Edge identity safeguards | L025 | Q0193–Q0200 |
| 5.1.d | Routing key lifecycle | L025, L062 | Q0193–Q0200, Q0489–Q0496, Q0993–Q1000 |
| 5.1.e | Protected Ethernet links | L025, L062 | Q0193–Q0200, Q0489–Q0496, Q0993–Q1000 |
| 5.2.a | Compute administrative authority | L024, L016 | Q0121–Q0128, Q0185–Q0192 |
| 5.3.a | SAN administrative authority | L024, L026 | Q0185–Q0192, Q0201–Q0208 |
| 5.3.b | FC attachment authorization | L026 | Q0201–Q0208 |
| 5.3.c | Switch fabric admission | L026 | Q0201–Q0208 |

## DCACI — v1.2

[Official public outline](https://learningcontent.cisco.com/documents/marketing/exam-topics/300-620-DCACI-v1.2.pdf)

| Provider leaf | Authored scope | Chapters | Supporting question IDs |
|---|---|---|---|
| 1.1.a | Fabric roles and hardware | L027 | Q0209–Q0216, Q0705–Q0712 |
| 1.1.b | Virtual controller dependencies | L027 | Q0209–Q0216, Q0705–Q0712 |
| 1.2 | Managed-object relationships | L028 | Q0217–Q0224, Q0713–Q0720 |
| 1.3 | Operational record interpretation | L027, L038 | Q0209–Q0216, Q0297–Q0304, Q0705–Q0712 |
| 1.4 | Fabric discovery workflow | L027, L054 | Q0209–Q0216, Q0425–Q0432, Q0705–Q0712, Q0945–Q0952 |
| 1.5.a | Access-policy construction | L029 | Q0225–Q0232, Q0721–Q0728 |
| 1.5.b | Fabric policy dependencies | L027, L029 | Q0209–Q0216, Q0225–Q0232, Q0705–Q0712, Q0721–Q0728 |
| 1.6.a | Tenant administrative scope | L030 | Q0233–Q0240, Q0729–Q0736 |
| 1.6.b | Application organization | L028, L030 | Q0217–Q0224, Q0233–Q0240, Q0713–Q0720, Q0729–Q0736 |
| 1.6.c | Routing-context separation | L030 | Q0233–Q0240, Q0729–Q0736 |
| 1.6.d | Bridge-domain behaviour | L030, L033 | Q0233–Q0240, Q0257–Q0264, Q0729–Q0736, Q0753–Q0760 |
| 1.6.e | Endpoint attachment groups | L030, L033 | Q0233–Q0240, Q0257–Q0264, Q0729–Q0736, Q0753–Q0760 |
| 1.6.f | Contract-based authorization | L031 | Q0241–Q0248, Q0737–Q0744 |
| 1.6.g | Security-group classification | L032 | Q0249–Q0256, Q0745–Q0752 |
| 2.1 | Endpoint location learning | L033 | Q0257–Q0264, Q0753–Q0760 |
| 2.2 | Bridge-domain forwarding controls | L033 | Q0257–Q0264, Q0753–Q0760 |
| 3.1 | External Layer-2 boundaries | L034 | Q0265–Q0272, Q0761–Q0768 |
| 3.2 | External routed attachment | L035 | Q0273–Q0280, Q0769–Q0776 |
| 4.1.a | VMware integration workflow | L036 | Q0281–Q0288, Q0777–Q0784 |
| 4.1.b | Nutanix integration constraints | L036 | Q0281–Q0288, Q0777–Q0784 |
| 4.2 | Policy programming timing | L036 | Q0281–Q0288, Q0777–Q0784 |
| 4.3 | Service-chain forwarding | L037 | Q0289–Q0296 |
| 5.1 | Management path construction | L038 | Q0297–Q0304 |
| 5.2.a | External event collection | L038 | Q0297–Q0304 |
| 5.2.b | Fabric assurance interpretation | L038, L080 | Q0297–Q0304, Q0633–Q0640 |
| 5.3 | Configuration recovery workflow | L039 | Q0305–Q0312, Q0785–Q0792 |
| 5.4 | Administrative role scope | L038 | Q0297–Q0304 |
| 5.5 | Fabric upgrade sequencing | L039 | Q0305–Q0312, Q0785–Q0792 |
| 6.1 | Multi-Pod tradeoffs | L040 | Q0313–Q0320 |
| 6.2 | Multi-Site tradeoffs | L040 | Q0313–Q0320 |
| 6.3 | Remote Leaf dependencies | L040 | Q0313–Q0320 |

## DCID — v1.2

[Official public outline](https://learningcontent.cisco.com/documents/marketing/exam-topics/300-610-DCID-v1.2.pdf)

| Provider leaf | Authored scope | Chapters | Supporting question IDs |
|---|---|---|---|
| 1.1.a | AI application requirements | L041, L047 | Q0321–Q0328, Q0369–Q0376, Q0793–Q0808, Q0865–Q0872 |
| 1.1.b | Training versus inference | L041, L044, L047 | Q0321–Q0328, Q0345–Q0352, Q0369–Q0376, Q0793–Q0808, Q0841–Q0848, Q0857–Q0872 |
| 1.1.c | Accelerator and offload placement | L047, L067 | Q0369–Q0376, Q0529–Q0536, Q0865–Q0872 |
| 1.1.d | AI traffic constraints | L041, L044, L045 | Q0321–Q0328, Q0345–Q0360, Q0793–Q0808, Q0841–Q0864 |
| 1.1.e | Operational energy tradeoffs | L041, L047 | Q0321–Q0328, Q0369–Q0376, Q0793–Q0808, Q0865–Q0872 |
| 1.2.a | RoCE fabric selection | L044, L045 | Q0345–Q0360, Q0841–Q0864 |
| 1.2.b | Ethernet fabric selection | L042, L044 | Q0329–Q0336, Q0345–Q0352, Q0809–Q0832, Q0841–Q0848, Q0857–Q0864 |
| 1.2.c | InfiniBand fabric selection | L044 | Q0345–Q0352, Q0841–Q0848, Q0857–Q0864 |
| 1.2.d | Remote memory access | L044 | Q0345–Q0352, Q0841–Q0848, Q0857–Q0864 |
| 1.3.a | Layer-2 mobility scope | L042, L043 | Q0329–Q0344, Q0809–Q0840 |
| 1.3.b | Layer-2 failure independence | L003, L042 | Q0017–Q0024, Q0329–Q0336, Q0809–Q0832 |
| 1.3.c | Layer-2 convergence design | L002, L003, L042 | Q0009–Q0024, Q0329–Q0336, Q0809–Q0832 |
| 1.3.d | Layer-2 service insertion | L037, L042 | Q0289–Q0296, Q0329–Q0336, Q0809–Q0832 |
| 1.3.e | Aggregation topology selection | L003, L042 | Q0017–Q0024, Q0329–Q0336, Q0809–Q0832 |
| 1.4.a | Routed workload mobility | L009, L042, L043 | Q0065–Q0072, Q0329–Q0344, Q0809–Q0840 |
| 1.4.b | Restart and forwarding continuity | L005, L042 | Q0033–Q0040, Q0329–Q0336, Q0809–Q0832 |
| 1.4.c | Routing convergence bounds | L004, L005, L042 | Q0025–Q0040, Q0329–Q0336, Q0809–Q0832 |
| 1.4.d | Routed service insertion | L009, L037, L042 | Q0065–Q0072, Q0289–Q0296, Q0329–Q0336, Q0809–Q0832 |
| 1.4.e | VRF-Lite segmentation | L009, L042 | Q0065–Q0072, Q0329–Q0336, Q0809–Q0832 |
| 1.5 | Lossless traffic engineering | L045 | Q0353–Q0360, Q0849–Q0856 |
| 1.6 | EVPN inter-site design | L043 | Q0337–Q0344, Q0833–Q0840 |
| 1.7.a | Management failure independence | L038, L043 | Q0297–Q0304, Q0337–Q0344, Q0833–Q0840 |
| 1.7.b | Site recovery and authority | L043 | Q0337–Q0344, Q0833–Q0840 |
| 1.7.c | Central controller placement | L043, L049 | Q0337–Q0344, Q0385–Q0392, Q0833–Q0840, Q0897–Q0904 |
| 1.8 | Overlay segmentation choice | L009, L030, L042 | Q0065–Q0072, Q0233–Q0240, Q0329–Q0336, Q0729–Q0736, Q0809–Q0832 |
| 2.1.a | Ethernet compute resilience | L046 | Q0361–Q0368, Q0873–Q0880 |
| 2.1.b | Ethernet failure-state capacity | L046 | Q0361–Q0368, Q0873–Q0880 |
| 2.1.c | Ethernet FI operating modes | L012, L046 | Q0089–Q0096, Q0361–Q0368, Q0873–Q0880 |
| 2.2.a | Storage attachment capacity | L046, L048 | Q0361–Q0368, Q0377–Q0384, Q0873–Q0896 |
| 2.2.b | SAN FI operating modes | L021, L046 | Q0161–Q0168, Q0361–Q0368, Q0873–Q0880 |
| 2.2.c | Direct storage attachment | L046, L091 | Q0361–Q0368, Q0873–Q0880, Q1017–Q1024 |
| 2.3.a | Server profile design | L013, L047, L050 | Q0097–Q0104, Q0369–Q0376, Q0393–Q0400, Q0865–Q0872, Q0905–Q0912 |
| 2.3.b | Ethernet adapter policies | L014, L047 | Q0105–Q0112, Q0369–Q0376, Q0865–Q0872 |
| 2.3.c | FC adapter policies | L014, L047 | Q0105–Q0112, Q0369–Q0376, Q0865–Q0872 |
| 2.4 | UCS-X placement tradeoffs | L016, L047 | Q0121–Q0128, Q0369–Q0376, Q0865–Q0872 |
| 2.5 | AI compute architecture | L041, L047 | Q0321–Q0328, Q0369–Q0376, Q0793–Q0808, Q0865–Q0872 |
| 3.1 | IP storage path independence | L023, L048 | Q0177–Q0184, Q0377–Q0384, Q0881–Q0896 |
| 3.2.a | FC congestion priorities | L022, L048 | Q0169–Q0176, Q0377–Q0384, Q0881–Q0896 |
| 3.2.b | IP storage service classes | L023, L045, L048 | Q0177–Q0184, Q0353–Q0360, Q0377–Q0384, Q0849–Q0856, Q0881–Q0896 |
| 3.3.a | FC attachment role selection | L021, L048 | Q0161–Q0168, Q0377–Q0384, Q0881–Q0896 |
| 3.3.b | Fabric interconnect capacity | L022, L048 | Q0169–Q0176, Q0377–Q0384, Q0881–Q0896 |
| 3.3.c | SAN oversubscription analysis | L048 | Q0377–Q0384, Q0881–Q0896 |
| 3.4 | Workload storage selection | L018, L023, L047, L048 | Q0137–Q0144, Q0177–Q0184, Q0369–Q0384, Q0865–Q0872, Q0881–Q0896 |
| 4.1.a | Intersight architecture | L016, L049 | Q0121–Q0128, Q0385–Q0392, Q0897–Q0904 |
| 4.1.b | API architecture selection | L049, L060, L077 | Q0385–Q0392, Q0473–Q0480, Q0609–Q0616, Q0897–Q0904, Q0977–Q0984 |
| 4.1.c | Model-driven architecture | L049, L063, L065 | Q0385–Q0392, Q0497–Q0504, Q0513–Q0520, Q0897–Q0904 |
| 4.1.d | Ansible architecture | L049, L070, L071 | Q0385–Q0392, Q0553–Q0568, Q0897–Q0904 |
| 4.1.e | Python architecture | L049, L073, L083 | Q0385–Q0392, Q0577–Q0584, Q0657–Q0664, Q0897–Q0904 |
| 4.1.f | Terraform architecture | L049, L072 | Q0385–Q0392, Q0569–Q0576, Q0897–Q0904 |
| 4.2.a | Server template scope | L013, L050 | Q0097–Q0104, Q0393–Q0400, Q0905–Q0912 |
| 4.2.b | vNIC template inheritance | L014, L050 | Q0105–Q0112, Q0393–Q0400, Q0905–Q0912 |
| 4.2.c | vHBA template inheritance | L014, L050 | Q0105–Q0112, Q0393–Q0400, Q0905–Q0912 |
| 4.2.d | Global versus local ownership | L050 | Q0393–Q0400, Q0905–Q0912 |
| 4.3 | Cross-system orchestration | L016, L049 | Q0121–Q0128, Q0385–Q0392, Q0897–Q0904 |
| 4.4 | Controller-led deployment | L049, L076 | Q0385–Q0392, Q0601–Q0608, Q0897–Q0904 |

## DCIT — v1.2

[Official public outline](https://learningcontent.cisco.com/documents/marketing/exam-topics/300-615-DCIT-v1.2.pdf)

| Provider leaf | Authored scope | Chapters | Supporting question IDs |
|---|---|---|---|
| 1.1.a | OSPF differential diagnosis | L051, L052 | Q0401–Q0416, Q0913–Q0920 |
| 1.1.b | BGP differential diagnosis | L052 | Q0409–Q0416, Q0913–Q0920 |
| 1.1.c | Multicast failure isolation | L006, L053 | Q0041–Q0048, Q0417–Q0424, Q0921–Q0944 |
| 1.1.d | Gateway continuity diagnosis | L006, L053 | Q0041–Q0048, Q0417–Q0424, Q0921–Q0944 |
| 1.2 | Layer-2 fault isolation | L002, L003, L053 | Q0009–Q0024, Q0417–Q0424, Q0921–Q0944 |
| 1.3 | Overlay fault isolation | L007, L008, L053 | Q0049–Q0064, Q0417–Q0424, Q0921–Q0944 |
| 1.4.a | Fabric enrollment diagnosis | L027, L054 | Q0209–Q0216, Q0425–Q0432, Q0705–Q0712, Q0945–Q0952 |
| 1.4.b | Attachment policy diagnosis | L029, L054 | Q0225–Q0232, Q0425–Q0432, Q0721–Q0728, Q0945–Q0952 |
| 1.4.c | Virtual attachment diagnosis | L036, L054 | Q0281–Q0288, Q0425–Q0432, Q0777–Q0784, Q0945–Q0952 |
| 1.4.d | Tenant relationship diagnosis | L030, L031, L054 | Q0233–Q0248, Q0425–Q0432, Q0729–Q0744, Q0945–Q0952 |
| 1.4.e | ACI forwarding diagnosis | L033, L054 | Q0257–Q0264, Q0425–Q0432, Q0753–Q0760, Q0945–Q0952 |
| 1.4.f | External policy diagnosis | L035, L055 | Q0273–Q0280, Q0433–Q0440, Q0769–Q0776 |
| 2.1 | Rack-server failure isolation | L015, L056 | Q0113–Q0120, Q0441–Q0448, Q0953–Q0960 |
| 2.2.a | Chassis and IOM diagnosis | L012, L056 | Q0089–Q0096, Q0441–Q0448, Q0953–Q0960 |
| 2.2.b | Ethernet policy diagnosis | L014, L056, L057 | Q0105–Q0112, Q0441–Q0456, Q0953–Q0960 |
| 2.2.c | SAN policy diagnosis | L014, L015, L056, L058 | Q0105–Q0120, Q0441–Q0448, Q0457–Q0464, Q0953–Q0976 |
| 2.2.d | Identity and boot diagnosis | L013, L015, L056 | Q0097–Q0104, Q0113–Q0120, Q0441–Q0448, Q0953–Q0960 |
| 2.3 | Server packet-path diagnosis | L014, L057 | Q0105–Q0112, Q0449–Q0456 |
| 2.4.a | VIC fault isolation | L014, L057 | Q0105–Q0112, Q0449–Q0456 |
| 2.4.b | Firmware fault isolation | L017, L057 | Q0129–Q0136, Q0449–Q0456 |
| 2.4.c | IOM fault isolation | L012, L056 | Q0089–Q0096, Q0441–Q0448, Q0953–Q0960 |
| 2.4.d | FI fault isolation | L012, L056, L057 | Q0089–Q0096, Q0441–Q0456, Q0953–Q0960 |
| 2.5 | Compute compatibility diagnosis | L017, L057 | Q0129–Q0136, Q0449–Q0456 |
| 3.1.a | Fabric startup diagnosis | L019, L058 | Q0145–Q0152, Q0457–Q0464, Q0961–Q0976 |
| 3.1.b | Credit starvation diagnosis | L022, L059 | Q0169–Q0176, Q0465–Q0472 |
| 3.1.c | NPV admission diagnosis | L021, L058 | Q0161–Q0168, Q0457–Q0464, Q0961–Q0976 |
| 3.1.d | VSAN separation diagnosis | L019, L021, L058 | Q0145–Q0152, Q0161–Q0168, Q0457–Q0464, Q0961–Q0976 |
| 3.2.a | Fabric identity diagnosis | L019, L058 | Q0145–Q0152, Q0457–Q0464, Q0961–Q0976 |
| 3.2.b | Zoning authorization diagnosis | L020, L058 | Q0153–Q0160, Q0457–Q0464, Q0961–Q0976 |
| 3.2.c | Alias-resolution diagnosis | L020, L058 | Q0153–Q0160, Q0457–Q0464, Q0961–Q0976 |
| 3.2.d | Fabric transaction diagnosis | L020, L058 | Q0153–Q0160, Q0457–Q0464, Q0961–Q0976 |
| 4.1.a | Event policy diagnosis | L061, L075 | Q0481–Q0488, Q0593–Q0600, Q0985–Q0992 |
| 4.1.b | Scheduled execution diagnosis | L061, L075 | Q0481–Q0488, Q0593–Q0600, Q0985–Q0992 |
| 4.2.a | Shell execution diagnosis | L061, L075 | Q0481–Q0488, Q0593–Q0600, Q0985–Q0992 |
| 4.2.b | REST workflow diagnosis | L060, L077 | Q0473–Q0480, Q0609–Q0616, Q0977–Q0984 |
| 4.2.c | Serialization fault isolation | L060, L077 | Q0473–Q0480, Q0609–Q0616, Q0977–Q0984 |
| 4.2.d | Python workflow diagnosis | L060, L073, L083 | Q0473–Q0480, Q0577–Q0584, Q0657–Q0664, Q0977–Q0984 |
| 4.2.e | Ansible failure isolation | L061, L071 | Q0481–Q0488, Q0561–Q0568, Q0985–Q0992 |
| 4.2.f | Terraform failure isolation | L061, L072 | Q0481–Q0488, Q0569–Q0576, Q0985–Q0992 |
| 4.2.g | Intersight workflow diagnosis | L016, L060 | Q0121–Q0128, Q0473–Q0480, Q0977–Q0984 |
| 5.1 | Cross-platform release diagnosis | L017, L057 | Q0129–Q0136, Q0449–Q0456 |
| 5.2 | Controller integration recovery | L062, L083 | Q0489–Q0496, Q0657–Q0664, Q0993–Q1000 |
| 5.3.a | Fabric admission safeguards | L026, L062 | Q0201–Q0208, Q0489–Q0496, Q0993–Q1000 |
| 5.3.b | Network privilege diagnosis | L024, L062 | Q0185–Q0192, Q0489–Q0496, Q0993–Q1000 |
| 5.3.c | Edge protection diagnosis | L025 | Q0193–Q0200 |
| 5.3.d | MACsec association diagnosis | L025, L062 | Q0193–Q0200, Q0489–Q0496, Q0993–Q1000 |
| 5.4 | ACI authority diagnosis | L038, L062 | Q0297–Q0304, Q0489–Q0496, Q0993–Q1000 |
| 5.5.a | Compute privilege diagnosis | L024, L062 | Q0185–Q0192, Q0489–Q0496, Q0993–Q1000 |
| 5.5.b | Compute key lifecycle | L016, L024, L062 | Q0121–Q0128, Q0185–Q0192, Q0489–Q0496, Q0993–Q1000 |
| 5.6.a | SAN privilege diagnosis | L024, L026, L062 | Q0185–Q0192, Q0201–Q0208, Q0489–Q0496, Q0993–Q1000 |
| 5.6.b | FC port admission diagnosis | L026, L058 | Q0201–Q0208, Q0457–Q0464, Q0961–Q0976 |
| 5.6.c | Switch membership diagnosis | L026, L062 | Q0201–Q0208, Q0489–Q0496, Q0993–Q1000 |

## DCNAUTO — v2.0

[Official public outline](https://learningcontent.cisco.com/documents/marketing/exam-topics/300-635-DCNAUTO-v2.0-7-9-2025.pdf)

| Provider leaf | Authored scope | Chapters | Supporting question IDs |
|---|---|---|---|
| 1.1 | YANG model selection | L063 | Q0497–Q0504 |
| 1.2 | ACI automation object model | L028, L067 | Q0217–Q0224, Q0529–Q0536, Q0713–Q0720 |
| 1.3 | DPU automation boundaries | L067 | Q0529–Q0536 |
| 1.4 | RPC service selection | L064, L065 | Q0505–Q0520 |
| 1.5 | Schema-to-RPC payload construction | L066 | Q0521–Q0528 |
| 2.1 | Reviewed declarative delivery | L068 | Q0537–Q0544 |
| 2.2 | Jinja control and rendering | L069 | Q0545–Q0552 |
| 2.3 | Ansible device/controller workflows | L070, L071 | Q0553–Q0568 |
| 2.4 | Terraform device/controller workflows | L072 | Q0569–Q0576 |
| 2.5 | Declarative-tool failure isolation | L061, L071, L072 | Q0481–Q0488, Q0561–Q0576, Q0985–Q0992 |
| 3.1 | ncclient operation construction | L073 | Q0577–Q0584 |
| 3.2 | Trusted bootstrap construction | L074 | Q0585–Q0592 |
| 3.3.a | On-device Bash workflow | L075 | Q0593–Q0600 |
| 3.3.b | On-device Python workflow | L075 | Q0593–Q0600 |
| 3.4 | Dashboard policy capabilities | L076 | Q0601–Q0608 |
| 3.5 | Dashboard template construction | L076 | Q0601–Q0608 |
| 3.6 | NX-API request construction | L077 | Q0609–Q0616 |
| 4.1 | Topology simulation design | L078 | Q0617–Q0624 |
| 4.2 | pyATS command workflow | L079 | Q0625–Q0632 |
| 4.3 | Telemetry pipeline architecture | L080 | Q0633–Q0640 |
| 4.4 | gNMI subscription construction | L081 | Q0641–Q0648 |
| 4.5 | Authoritative inventory integration | L082 | Q0649–Q0656 |
| 4.6 | Python health-state collection | L083 | Q0657–Q0664 |
| 4.7 | Linux virtual networking | L084, L085 | Q0665–Q0680 |
| 5.1 | AI-assisted code validation | L086 | Q0681–Q0688 |
| 5.2 | AI security boundaries | L087 | Q0689–Q0696 |
| 5.3 | Agent integration control | L088 | Q0697–Q0704 |

