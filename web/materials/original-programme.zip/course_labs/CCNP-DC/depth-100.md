# NDI 6.3.1: onboarding, telemetry, flow analysis and evidence quality

### Build an observation service with an explicit coverage boundary

Use Nexus Dashboard Insights 6.3.1 and its NDFC-specific documentation for this exercise. Record the Nexus Dashboard host, NDFC and NX-OS maintenance releases and check their joint support. An NDI 6.x label does not guarantee every feature across all 6.x releases. This chapter supplies a versioned workflow within the retrieved CCIE equipment family, not a claim that the newest product behaves identically.

NDI collects state, constructs analytical models and presents findings. Its result is only as current and complete as its inputs. Separate collection health, analysis completion and service correctness. A completed analysis of a stale snapshot may be internally consistent while saying nothing about a change that happened afterward. A missing flow record may mean no traffic, an unsupported collection point, a sampling miss, failed export or an incorrect query.

Define the observation requirement first. For the BLUE application, the operator must distinguish a missing network attachment, a policy denial, a forwarding-programming inconsistency and congestion. The needed evidence includes topology and configuration, the exact flow tuple and VRF, collection timestamps, device compatibility, relevant counters and an independent application test. A general green site score is not a replacement for that requirement-specific record.

### Onboard and verify collection

Start with the accepted NDFC laboratory fabric from chapter 099. Add or select its site through the documented NDI site workflow. A site registered in Nexus Dashboard is not automatically enabled in each hosted service. For an already registered site, use the Ready to Add path and verify its fabric type, address family, collection loopback and associated VRF. The loopback must actually reach the Nexus Dashboard in-band collector path in the supported context.

Choose Managed or Monitored mode deliberately. Managed mode can deploy telemetry configuration to switches; it is a change-capable integration, not merely a read-only dashboard. Monitored mode does not automatically install that configuration, so the owner must provide the required collection setup. Apply the documented credentials and authority for the selected mode rather than claiming every onboarding step works with a read-only account. Store secrets through the approved platform mechanism and keep them out of exported exercise evidence.

Check release-specific limitations before modifying a production control. For example, the 6.3.1 NDFC site guide documents an incompatibility with NDFC Change Control enabled and a restriction on manually adding remotely authenticated NDFC sites. Use the supported onboarding route and a compatible isolated lab configuration. Do not silently disable an operational approval control to make an unsupported combination appear to work; select a supported version/design or record the limitation.

Inspect System Status and expected telemetry configuration for every switch. Compare the intended loopback/VRF and collector address with actual device configuration and reachability. Verify that data timestamps advance, not merely that a controller connection is established. Create a harmless bounded event, such as an authorized interface-state change in the lab, and confirm that it appears at the expected device and time. Restore the interface and retain both observations.

### Configure flow visibility for a specific question

Select the collection method supported by the switch and interface: flow telemetry, NetFlow or sFlow have different information and fidelity. Do not assume they all contain full packet payloads or identical path detail. A sampled mechanism can miss a short low-rate flow. A high-rate aggregate can reveal trends while still concealing the precise packet responsible for one application failure.

Configure a narrow test flow from 10.99.0.10 to 10.99.1.20, TCP destination 443, in BLUE. Record the source port when reproducing a specific hashed path. Choose the supported host-facing observation points and inspect the installed collection rules. On the pinned release, interface-based flow telemetry has restrictions on VXLAN spine-leaf links, so do not invent visibility by selecting an unsupported transit point. Time synchronization from chapter 093 is part of this measurement service.

Generate a controlled stream with sequence numbers or repeatable application requests. Compare source transmission, receiver results and the collected record. Then stop the flow and verify how the display ages. Calculate rates from actual intervals: a counter increase of 300,000 bytes over two seconds is 150,000 bytes per second, or 1.2 megabits per second before any separately accounted overhead. Detect counter resets instead of reporting a negative rate as real traffic.

### Run connectivity analysis and interpret its limits

In Analysis Hub, create a Connectivity Analysis for the correct site and routed or switched flow. Enter source, destination, VRF and relevant Layer-4 fields. Check the node compatibility/status information before interpreting gaps. Quick mode traces the supported forwarding path evidence; Full mode adds deeper consistency checks between software and hardware state. Neither mode guarantees that an unobserved application dependency is healthy.

Active-path analysis can use ELAM-related evidence where supported and needs an actual suitable flow. Keep the test traffic active for the observation window. If the job reports no active flow, that is a measurement prerequisite failure, not automatic proof of a forwarding outage. If the destination is absent from the specified VRF, verify the query and endpoint state before diagnosing a hardware fault. Run the reverse-flow analysis where return routing or policy could differ.

A synthetic finding might show a correct route in software but a hardware programming inconsistency on Leaf B. Treat that as a focused hypothesis. Preserve raw results, compare relevant device state and application loss, and use an approved corrective procedure with rollback. An AI-generated correlation or suggested command has no independent authority to reset the switch. After correction, rerun the same query and application test with fresh timestamps and verify the previously denied flow remains denied.

### Snapshots, exports and recovery

A snapshot site supports analysis of collected data at a particular time. It is valuable for a change window or an offline review, but it has no live connection supplying the next state. Retain collection time, upload time, analysis time and source inventory separately. Reanalyzing the same snapshot with a newer rule set can yield a different finding without any device change. Do not label that as newly observed production behavior.

Export anomalies and relevant records to the operational evidence system using the supported integration, and test the receiver outage behavior. The pinned guide does not promise replay of every syslog anomaly generated while the external server is unavailable. If continuity is required, design and test an appropriate retained path rather than assuming a reconnected destination receives historical gaps automatically.

Acceptance requires healthy collection, a deliberately visible test event, a scoped flow record, a correctly parameterized connectivity analysis, a diagnosed missing-data condition and a demonstrated recovery. Include a snapshot comparison whose time boundary is explicit. A successful NDI job proves that the job completed within its supported evidence scope; engineering acceptance comes from relating that evidence to the actual service requirement.

## Worked cases

### Collection failure masquerades as no traffic

Synthetic: receiver logs show successful requests; sampled telemetry has no record; collector timestamps have stopped advancing.

Treat collection freshness as a failed dependency. Check supported observation points, source loopback/VRF and exporter status before interpreting the missing flow. Preserve receiver evidence and rerun a bounded stream after collection recovery.

### Analysis after a change uses old data

Synthetic: a 09:00 snapshot is analyzed at 11:10 after a 10:30 change. The report shows no relevant inconsistency.

The report validates only its collected snapshot scope. Obtain fresh evidence for the changed state, retain both snapshots and compare their collection times. A later analysis timestamp is not a later device observation.

## Guided build and fault isolation

Onboard the accepted lab fabric in a deliberately chosen mode, prove telemetry freshness, configure one supported flow and run forward/reverse connectivity analysis.

Hint: Capture collection, upload and analysis times separately; keep the exact flow tuple and VRF.

Instructor reasoning: The accepted record must show one visible event, a supported collection point, a fresh flow and a measurement failure that is correctly distinguished from a service failure. Full analysis evidence must be related to actual application tests.

## Independent assignment

Create a before/after change evidence package using one live-site observation and one labeled snapshot. Inject collector reachability loss and an inactive active-path test. Recover without widening tenant policy, and document the external export outage behavior and any retained evidence gap.

## Verified primary references

- [NDI 6.3.1 NDFC: Getting Started](https://www.cisco.com/c/dam/en/us/td/docs/dcn/ndi/6x/articles/cisco-ndi-getting-started-release-631-ndfc.pdf)
- [NDI 6.3.1 NDFC: Sites](https://www.cisco.com/c/dam/en/us/td/docs/dcn/ndi/6x/articles/cisco-ndi-sites-release-631-ndfc.pdf)
- [NDI 6.3.1 NDFC: Analysis Hub](https://www.cisco.com/c/dam/en/us/td/docs/dcn/ndi/6x/articles/cisco-ndi-analysis-hub-release-631-ndfc.pdf)
- [NDI 6.3.1 NDFC: Flows](https://www.cisco.com/c/dam/en/us/td/docs/dcn/ndi/6x/articles/cisco-ndi-flows-release-631-ndfc.pdf)
- [NDI 6.3.1 NDFC: Anomalies and advisories](https://www.cisco.com/c/dam/en/us/td/docs/dcn/ndi/6x/articles/cisco-ndi-anomalies-advisories-release-631-ndfc.pdf)
