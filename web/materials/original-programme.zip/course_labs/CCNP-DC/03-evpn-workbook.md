# VXLAN EVPN construction: L2 service, routed tenant and evidence

This workbook adds tenant services to the routed underlay in Workbook 01. It is an original illustrative configuration, not a captured or executed device build. The classic VLAN/SVI L3-VNI form below is deliberately a teaching baseline; newer NX-OS releases also have a newer L3-VNI mode with different support and migration guidance. Select one documented mode for the actual lab rather than mixing them. Check ASIC, TCAM, license, MTU and exact release requirements.

**Stage 1: bridge one segment.** Both leaves map VLAN120 to L2 VNI10120. Their dedicated VTEP loopback1 addresses remain reachable through the underlay. BGP uses loopback0 separately. Ingress replication supplies BUM transport for this bounded two-leaf lab.

```text
feature nv overlay
feature vn-segment-vlan-based
feature interface-vlan
nv overlay evpn
vlan 120
  vn-segment 10120
interface Ethernet1/10
  switchport
  switchport mode access
  switchport access vlan 120
  no shutdown
interface nve1
  no shutdown
  host-reachability protocol bgp
  source-interface loopback1
  member vni 10120
    ingress-replication protocol bgp
evpn
  vni 10120 l2
    rd auto
    route-target import 65000:10120
    route-target export 65000:10120
```

Use distinct lab endpoint IPs in the same subnet on the two leaves. Generate controlled endpoint traffic. Inspect local MAC learning, EVPN type-2 routes, type-3 participation, NVE peers/VNIs and remote MAC installation using the selected release's supported commands. A remote route in the global EVPN table is not enough: show the imported tenant forwarding entry and an actual allowed flow.

The explicit route target is shared for membership; automatically derived RDs remain unique per originating route context. Do not make all RDs identical to make the display look consistent. Do not assume the VNI number alone authorizes route import. The underlay transports outer VTEP packets and should not require every inner tenant MAC.

**Stage 2: add a routed tenant.** Use VRF BLUE, L3 VNI50001, L2 VNIs10120/10130 and an approved distributed gateway MAC. This classic form illustrates the dependency graph:

```text
fabric forwarding anycast-gateway-mac 0001.0001.0001
vlan 500
  vn-segment 50001
vrf context BLUE
  vni 50001
  rd auto
  address-family ipv4 unicast
    route-target both 65000:50001
    route-target both 65000:50001 evpn
interface Vlan500
  no shutdown
  vrf member BLUE
  ip forward
interface Vlan120
  no shutdown
  vrf member BLUE
  ip address 10.120.0.1/24
  fabric forwarding mode anycast-gateway
interface nve1
  member vni 50001 associate-vrf
```

Add VLAN130/VNI10130 and its gateway in the same deliberate manner, plus the appropriate EVPN L2 stanza and supported BGP VRF address-family configuration for the intended host/prefix advertisements. The exact `advertise l2vpn evpn` and redistribution policy belongs under the chosen BGP VRF design; advertise only the approved connected or external prefixes. This is a staged construction exercise, not a paste-and-go whole-fabric configuration. The learner must supply the missing symmetric Leaf B and VLAN130 sections and explain each relationship before execution.

**Packet walk.** A source on VLAN120 sends to the gateway MAC. The ingress leaf routes in BLUE, selects the remote VTEP/tenant route and encapsulates through the routed overlay context. The egress leaf decapsulates into the intended tenant routing context and forwards onto VLAN130. Verify both directions, not only one ICMP echo request.

**Fault campaign.** Independently introduce a wrong import RT, missing L3-VNI association, absent underlay VTEP route and insufficient alternate-path MTU. For each, predict which table first diverges and which traffic classes still work. Add a duplicate-IP endpoint fault and distinguish it from legitimate mobility. Preserve control-plane and packet evidence before clearing anything.

**Acceptance.** Deliver supported platform/mode selection, complete per-node configs, route/MAC/NVE evidence, MTU byte budget, allowed and denied tenant flows, endpoint mobility and restoration. The virtual lab can demonstrate supported control behavior; it does not measure physical buffer headroom, optic limits or line-rate performance.
