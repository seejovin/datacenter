# Offline automation laboratory and vendor execution bridge

The packaged `academy_lab.py` is a standard-library-only executable laboratory. It never opens a socket, launches a subprocess or writes to a device. Its fixtures and results are synthetic. This makes the exercises reproducible without Cisco credentials while keeping vendor execution as a separate assessed gate.

From the project root:

```bash
python course_labs/CCNP-DC/academy_lab.py demo
python course_labs/CCNP-DC/academy_lab.py selftest
```

**Exercise A — NX-API parsing.** Inspect `parse_nxapi`. It checks the teaching envelope, each embedded device result and single-row/list cardinality. Add a fixture with two operations where one fails. Predict whether a healthy interface from the first operation is enough for overall success. The correct result is a visible operation failure, not a green report based on partial data. The parser supports the supplied fixture schema only; a real collector must validate the selected command's actual response format.

**Exercise B — intent validation.** `validate_vlan_intent` rejects duplicate/out-of-range IDs, missing required VLANs and names that escape the lab's constrained grammar. Change management VLAN99 to absent and observe rejection. Add a newline-bearing name and observe rejection before rendering. Explain why valid syntax alone cannot prove that an intended deletion is authorized. The grammar is deliberately narrower than every possible vendor naming rule; expand it only with a documented output-context design.

**Exercise C — target identity.** `validate_inventory` compares approved stable identity, lifecycle and observed serial/role. Make the management IP point to a different serial and show that the workflow stops. Do not auto-overwrite approved role from an observed hostname. The required decision is reconciliation through the asset/change process.

**Exercise D — modeled payload.** `gnmi_teaching_payload` builds an intermediate path and JSON-IETF value representation for a keyed interface boolean. It rejects the string `false`; Python would otherwise treat a nonempty string as truthy in many contexts. This function does not serialize the actual gNMI protobuf. Use the official gNMI service/client definitions for a real target, discover supported models/encodings and preserve exact list keys. `seconds_to_ns(10)` returns10,000,000,000 and enforces a bounded teaching sampling policy.

**Exercise E — telemetry quality.** `counter_rate` calculates a delta only when identity, boot context and time are coherent. A reset establishes a new baseline rather than negative utilization. `health_report` treats stale/future or failed observations as unknown and distinguishes admin-up/oper-down from an intentionally shut interface. It does not claim that all applications are healthy merely because the checked interfaces are up.

**Exercise F — asynchronous reconciliation.** `reconcile_job` checks the exact target set and reports missing, failed and pending outcomes. Even full execution success leaves `service_verified` false. Explain which postconditions must set an acceptance decision outside this fixture: configuration readback, required flow, prohibited flow, redundancy and recovery where applicable.

**Exercise G — agent authority.** `validate_agent_plan` permits only bounded read/proposal operations in this offline lab and rejects unauthorized assets or payload/plan target mismatch. Feed a log containing instructions to export a secret or delete ACLs. The content is data to analyze, not authority. The program has no mutation implementation, so validation cannot accidentally execute a generated proposal.

**Bridge to a vendor lab.** Pin actual platform/tool versions. Replace only the transport adapter with a supported read-only client first. Verify SSH/TLS identity, use scoped secrets outside source, capture capabilities and schema, and rerun the parser/negative tests against sanitized real observations. Add mutation only through an approved reviewed plan with bounded scope, transaction semantics, timeout reconciliation and independent service verification. Passing the offline tests is evidence about this code's supplied cases, not a Cisco commissioning result.

**Tool-specific implementation assignments.**

- NETCONF/ncclient: use the server's advertised datastores, a context-managed session, explicit namespace filters, structured RPC error handling and lock cleanup. Demonstrate an unconfirmed timed commit only on a server that advertises the capability.
- Jinja2: use `StrictUndefined`, validate input before rendering, sort deterministic resource lists and compare the resulting diff. Test missing data and injection-like names.
- Ansible: pin the collection, validate inventory/environment, choose documented merge versus replacement semantics and retain per-target results. `check` mode fidelity depends on the module; it is not workload acceptance.
- Terraform: protect/lock state, establish one owner per resource, review every replacement and refuse unintended destruction of management dependencies. Import is a state association, not authorization or automatic correct intent.
- pyATS: pin parser support, retain raw plus structured before/after state and assert semantic invariants. Missing parser output must fail or mark validation unknown, not pass as empty healthy state.
- PowerShell: keep objects through filtering/selection, format only at the display boundary, validate nested JSON depth and inspect asynchronous job outcomes. A successful web request is not a completed deployment.

**Independent assessment.** Add at least four new failure fixtures chosen by an assessor, explain why the existing logic should accept or reject each, implement the needed correction and rerun the full local suite. Then complete the separate supported-device workflow with a harmless configuration change and an observed recovery. Retain the distinction between code tests, simulation, vendor-lab observations and production evidence.
