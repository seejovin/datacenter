# UCS provisioning and replacement: a dependency-driven implementation

This is an original vendor-lab workflow, not a claim that UCS hardware was configured in this package. Use a supported UCS Manager or Intersight-managed environment and follow the selected product's actual object names, firmware matrix and maintenance procedure. The two management models share principles but are not interchangeable APIs.

**Prepare.** Inventory FI, IOM, chassis, server, VIC, optics, firmware and host-driver versions. Record power, cooling and rack interfaces without claiming specialist electrical or mechanical commissioning authority. Verify management/OOB access, DNS/time/certificates and named administrative roles. Draw Fabric A and B independently, including upstream VLAN/VSAN and array dependencies.

**Construct policies in dependency order.**

1. Define approved VLANs and VSANs and their upstream availability. Do not create unused broad ranges merely to avoid later policy review.
2. Create nonoverlapping MAC, WWNN/WWPN and UUID pools as required by the chosen management model. Record ownership and exhaustion thresholds.
3. Define vNIC policies/templates with intended fabric, VLAN list/native behavior, QoS and supported adapter policy.
4. Define vHBA policies/templates with fabric, VSAN, unique identity pools and supported FC adapter policy.
5. Create boot policy for the intended local or SAN device, with explicit firmware mode and approved alternatives. Record target WWPN and LUN identity for SAN boot.
6. Define the compatible firmware policy/bundle, BIOS settings, maintenance acknowledgement and server-selection criteria.
7. Compose the server/service profile and, if used, its template relationship. Document whether later template changes propagate.
8. Review the complete resulting identity and policy graph before association/deployment. A single profile can request disruptive hardware actions.
9. Deploy to one representative compatible server and follow asynchronous or association status to a terminal outcome.
10. Verify active, not merely downloaded, firmware and inspect any pending reboot/acknowledgement.
11. Verify host Ethernet from guest/OS through virtual switch, VIC, IOM/FI and uplink. Confirm actual tagging and intended fabric path.
12. Verify storage from vHBA identity through FLOGI/FCNS, active zoning, masking, host multipath and application I/O.
13. Cold-boot through the supported alternate path and compare the result with running-OS failover; they are different tests.
14. Confirm required monitoring, audit, backup and recovery access before accepting the server into service.
15. Expand only after the canary passes the relevant hardware, hypervisor, boot and workload combinations.

**Worked replacement.** Server S-old uses a logical service identity that must move to S-new. First quiesce the workload and establish that the old identity cannot remain active. Check S-new's compatibility and receive/inspect it through the hardware process. Associate the approved identity/policies, verify actual WWPN/MAC allocation and boot volume, then restore service. Keeping both owners active is not a valid generic availability strategy. A new physical serial and reused logical service identity should both appear in the evidence record.

**Failure distinctions.** Pool exhaustion blocks identity allocation; unsupported IOM/FI firmware blocks infrastructure; wrong VLAN/VSAN blocks I/O attachment; a wrong LUN blocks intended boot-device selection; wrong UEFI/legacy mode can make a visible correct disk unbootable; an updating template can affect many hosts at once. Diagnose the first divergent stage rather than deleting profiles indiscriminately.

**Independent task.** Provision a disposable workload and perform one approved replacement, one-fabric I/O loss and one controlled firmware-policy change in a supported lab. Deliver a dependency graph, before/after identities, exact platform versions, active-policy evidence, workload results and a recovery record. If physical equipment is unavailable, mark the analytical/simulator work complete only at that fidelity and leave physical commissioning open.
