# NX-OS checkpoint, configuration replace and verified recovery

### Recovery begins with an explicit state model

Use the Nexus 9000 NX-OS 10.3(x) checkpoint/rollback and configuration-replace procedures for this chapter. The examples are original, unexecuted device commands. The offline workbook compares small structured configuration models; it does not parse arbitrary NX-OS CLI or simulate a device transaction engine. Preserve independent management access and use an authorized disposable topology for failure experiments.

There are several states to distinguish. Running configuration expresses the currently accepted configuration. Startup configuration is a persisted boot input. A checkpoint records an earlier configuration for a supported rollback workflow. Operational state includes learned routes, neighbor sessions, forwarding entries, counters and application behavior. An external controller may maintain another intended state that it can deploy after a local change. These states can disagree without a syntax error appearing on the console.

Suppose a route-map change is present in running configuration and passes a test but was not saved. A later reboot can restore the startup behavior. Conversely, saving a faulty running configuration makes the fault persistent; it does not certify the configuration. Creating a checkpoint is also not the same action as declaring the checkpointed state acceptable. Record the timestamp, software version, feature context and evidence that made a recovery point usable.

### Merge does not mean replace

Consider a simplified structured model. The accepted state contains VLAN 10 and interface description 'server-a'. A later change adds VLAN 20 and changes the description to 'temporary'. Copying a partial file that sets the description back can restore that value while leaving VLAN 20 in place. Omission from a merge input is not an instruction to delete the omitted resource.

Replacement instead aims at a complete intended configuration. A resource present in running state but absent from the replacement can be removed. This is powerful and can also delete legitimate work done after the replacement file was captured. Neither operation understands the business value of a concurrent change. A configuration manager needs explicit ownership, a current baseline and a reviewed difference, rather than relying on the reassuring filename 'stable'.

An important distinction is scope. Restoring one switch's configuration cannot reverse a database transaction, recover a missing storage volume or replace a failed optic. Restoring an old ACL does not necessarily restore an external identity provider's policy. A complete recovery plan identifies the states the selected mechanism can restore and the dependent states that require separate actions and verification.

### Construct a named checkpoint experiment

In an isolated laboratory, first demonstrate healthy reachability and the intended negative access test. Capture the running and startup configurations, release inventory and active configuration writers. Create a uniquely named checkpoint before the experiment. The following command sequence illustrates the relevant workflow; the intervening authorized test change is deliberately separate:

```text
checkpoint before_route_policy
show checkpoint before_route_policy
show checkpoint summary
! Apply the narrowly scoped laboratory change here.
show diff rollback-patch checkpoint before_route_policy running-config
rollback running-config checkpoint before_route_policy atomic
show rollback log exec
show rollback log verify
```

The difference command compares the named selections. Read the patch meaning and direction rather than treating any displayed minus sign as self-explanatory. Verify the named checkpoint's content before applying it. After rollback, compare the relevant running configuration, protocol state and application evidence with the accepted baseline. Save the accepted running configuration to startup only after the acceptance decision.

The documented rollback modes have different error semantics. Atomic is the default mode; best effort can skip errors; stop-at-first-failure stops when an error occurs. These names do not remove the need to inspect the operation logs and resulting configuration. A partial or interrupted operation demands an explicit reconciliation record. Do not turn on best effort merely to turn a red status into a green change ticket.

The release guide also limits checkpoint portability and eligible checkpoint files. Treat a checkpoint as version-bound, not as a universal migration artifact. A text file exported by an arbitrary method is not automatically a valid checkpoint input. The documented bootflash difference limitation means a 'No Changes' response in that specific workflow cannot be interpreted as proof of equality. Use the supported named-checkpoint workflow and an independent content comparison where required.

### Full configuration replace and timed confirmation

Configuration replace is a separate operation. Build its input from a complete, appropriate device configuration and regenerate it after a software-version change. A short VLAN snippet intended for merging is not a suitable full replacement file. Review the generated patch and semantic checks before applying a file that can remove existing commands.

For an authorized laboratory replacement file named `bootflash:accepted_candidate.cfg`, the following illustrates the pinned workflow:

```text
configure replace bootflash:accepted_candidate.cfg show-patch
configure replace bootflash:accepted_candidate.cfg verify-only
configure replace bootflash:accepted_candidate.cfg verbose commit-timeout 300
show config-replace status
show config-replace log exec
show config-replace log verify
! Confirm only after the defined service and access tests pass.
configure replace commit
```

A commit timeout gives the operator a bounded opportunity to confirm the replacement. If it expires, the device initiates restoration of the previous configuration. The confirmation command stops that timer. It is not the command that copies running configuration to startup. An automated workflow must distinguish device operation completion, service verification, timer confirmation and persistence as separate decisions.

For example, the replacement can apply successfully while removing the management path from which the engineer intended to confirm it. An independent console makes the state observable. In a disposable test, allow the timer to expire and verify the actual restored configuration and reachability. A network timeout in the automation client does not prove that the device rejected the request; read operation status before deciding whether to retry.

Semantic verification checks configuration applicability and consistency within its documented scope. It cannot prove a remote application responds, an upstream route has the correct policy, or the retained access boundary matches the requirement. Define those tests before the change. A job that confirms immediately upon CLI success discards the purpose of the service-validation window.

### Concurrent ownership and recovery evidence

Freeze competing writers during the controlled transaction. A second SSH session, NX-API job or controller reconciliation can change the baseline between a patch preview and execution. After the operation, a controller may restore its own desired state and make the local rollback appear unstable. Identify whether the controller or the local device owns each setting and update the correct source of intent.

A useful recovery packet contains the starting state, complete candidate or named checkpoint, patch review, operator identity, operation logs, remaining timer state, relevant protocol tables and positive/negative application tests. Include startup persistence status separately. Retain any failed or skipped commands and their effect rather than only the final success line.

Finally, distinguish configuration recovery from service recovery. An OSPF neighbor can need time to re-establish; an application connection may need to retry; a security control may need to be checked for unintended widening. The change is complete when the agreed service and boundary are restored and the accepted state is persistently recorded, not when an old configuration string reappears in a command output.

## Worked cases

### The old checkpoint contains an unwanted deletion

Synthetic: a 09:00 checkpoint predates an approved 09:30 VLAN addition. The 10:00 rollback patch removes both the faulty change and the legitimate VLAN.

Do not execute the stale whole-device recovery unquestioningly. Reconcile the current accepted intent, coordinate ownership and choose a supported narrow correction or complete candidate that preserves the approved addition. Review a fresh difference and verify both services.

### A successful replace loses the confirmation path

Synthetic: the candidate applies and starts a 300-second timer, but management reachability from the automation host is lost. Independent console status shows the timer still pending.

Use the console to observe the pending state and the defined recovery process. In the isolated experiment, allow expiry and prove restoration. Do not treat the client timeout as rejection or send repeated replacements. Correct and revalidate the management dependency before another attempt.

## Guided build and fault isolation

Build an isolated checkpoint recovery and a separate full-replace experiment with a timed confirmation. Include a partial merge that intentionally leaves an unwanted test resource.

Hint: Keep running, startup, checkpoint, candidate, operational and controller-intended state separate.

Instructor reasoning: The record demonstrates the merge residue, reviews deletion scope, inspects execution/verification logs and validates service before confirming and saving. A timer-expiry exercise proves actual recovery behavior rather than assuming it.

## Independent assignment

Create a configuration recovery casebook with a preserved concurrent change, an invalid candidate, a lost client response and a successful timed replacement. Use an authorized console path and the release-specific procedures. For offline work, model typed configuration resources and compare merge versus replacement; do not claim the model executes NX-OS rollback.

## Verified primary references

- [NX-OS 10.3(x): checkpoint and rollback](https://www.cisco.com/c/en/us/td/docs/dcn/nx-os/nexus9000/103x/configuration/system-management/cisco-nexus-9000-series-nx-os-system-management-configuration-guide-103x/m-configuring-rollback.html)
- [NX-OS 10.3(x): configuration replace and commit timeout](https://www.cisco.com/c/en/us/td/docs/dcn/nx-os/nexus9000/103x/configuration/system-management/cisco-nexus-9000-series-nx-os-system-management-configuration-guide-103x/m-performing-configuration-replace.html)
