# Tenant routed multicast: MVPN signaling, transport trees and receiver delivery

### Separate the tenant tree from its transport

Use a supported Nexus 9000 NX-OS 10.3(x) TRM lab. Reuse the working EVPN unicast topology from chapters 007–009 and the PIM reasoning from chapter 006. Record the exact switch family: multicast replication and mixed-mode features have hardware restrictions. This chapter teaches the Layer-3 TRM model with multicast transport in the underlay. It does not silently substitute a later release, a different L3VNI mode or a non-TRM leaf.

A tenant source sends an ordinary IP multicast packet to a group. Its receiver may be on another subnet and another leaf. Bridging a multicast frame inside one L2 VNI cannot by itself provide that routed tenant service. TRM combines tenant multicast routing, BGP MVPN signaling and a transport tree through the fabric. The inner tenant source/group and outer multicast transport group are different namespaces with different forwarding state.

Build a four-layer worksheet. The endpoint layer records the receiver's IGMP membership and application socket. The tenant layer records VRF, source reachability, RP or SSM assumptions, multicast incoming interface and outgoing interfaces. The overlay signaling layer records MVPN family negotiation and the routes that describe participation and joins. The underlay records VTEP reachability, PIM state and the multicast group carrying encapsulated traffic. The same word 'multicast' on four screens does not make the screens interchangeable.

### Why unicast EVPN is insufficient

An established BGP session may negotiate EVPN but omit the IPv4 MVPN address family. Type-2 MAC/IP and type-5 IP-prefix reachability can work while the multicast service lacks its own signaling. MVPN routes describe multicast VPN participation and source/receiver relationships. Route types have specific purposes; recognizing an EVPN type number is not enough to decode an MVPN NLRI. Route-target policy controls which tenant receives signaling, while an outer group supplies transport replication. Neither replaces the other.

A default multicast distribution tree is associated with the tenant's L3 VNI/VRF in this implementation. The underlay distributes encapsulated packets among participating VTEPs; edge routing and receiver state determine useful delivery. Data MDT functions can optimize selected traffic where the platform supports them, but they introduce further thresholds and tree state. Begin with the default tree and prove the basic path before adding that optimization.

Separate underlay groups for L2 BUM replication, default MDT and any data MDT pools. Reusing an arbitrary group everywhere makes troubleshooting and support assumptions harder and conflicts with the cited baseline guidance. A group value is a transport resource assignment, not a security label. Tenant isolation still depends on VRF/VNI and import policy plus the complete implementation. Conversely, a correct isolated VRF can still lose multicast because its outer tree is missing.

### RPF and the routed packet walk

For a synthetic source 10.94.10.10 in BLUE and group 239.94.1.1, trace the packet from the source-facing leaf. The ingress leaf identifies BLUE, checks the multicast forwarding state and encapsulates according to the VRF transport. Intermediate switches forward the outer multicast packet using underlay state. A receiver leaf decapsulates, applies tenant multicast forwarding and sends only onto eligible receiver-facing interfaces. The external source path, if present, must satisfy the tenant's RPF expectation; underlay RPF independently constrains the outer transport.

RPF is based on the relevant source or RP lookup and selected multicast behavior, not on a general feeling that both paths are reachable. A policy change can move a unicast next hop while multicast still arrives through the old path. That creates a precise reason for rejection. Blindly disabling RPF or widening all route imports trades a diagnosable inconsistency for loops or isolation risk. Identify which layer's RPF failed and restore consistent routing.

TRM uses a routed forwarding approach. An application that sends with TTL 1 can fail across this service even where the source and receiver operator thinks of the fabric as one large LAN. Examine TTL at the endpoint and routed boundaries. Increasing application TTL must remain within the authorized multicast scope; do not use it as a substitute for confirming where traffic is allowed to travel.

### Construct from a known unicast baseline

Use two leaves, one spine route reflector, a source host and a receiver host. BLUE uses L3 VNI 50940; its source and receiver networks use different L2 VNIs. Keep RED as a negative-test tenant. Validate unicast reachability and route-target isolation first. Then build underlay PIM for the allocated transport groups, configure the chosen tenant RP model consistently, and enable the MVPN signaling family on every relevant peer including the route reflector.

The following original, unexecuted fragments identify additions to the already working baseline. They intentionally retain the conventional NVE L3VNI attachment style. Do not combine them blindly with the new L3VNI mode; use one internally consistent release-supported model and complete its documented prerequisites.

```text
feature ngmvpn
ip igmp snooping vxlan
interface nve1
  member vni 50940 associate-vrf
    mcast-group 239.194.0.10
router bgp 65000
  neighbor 192.0.2.254
    address-family ipv4 mvpn
      send-community extended
vrf context BLUE
  ip multicast multipath s-g-hash next-hop-based
```

This is not the entire leaf configuration: existing NVE source, EVPN, VLAN/SVI, tenant route targets, PIM and RP settings remain required. On the spine, reflect the MVPN family using the release-supported neighbor configuration. On each leaf, confirm family negotiation and imported multicast signaling. Use `show bgp ipv4 mvpn`, tenant `show ip mroute` and IGMP group inspection with locally confirmed VRF syntax. Capture the relevant underlay multicast route separately. Preserve raw outputs before producing a normalized summary.

Start the receiver before sending a bounded, identifiable multicast stream. Record source packets, outer-tree replication, decapsulation and delivered application sequence numbers. Stop one receiver and observe membership aging; do not assume an instantaneous leave when the selected protocol uses timers. Add RED with the same inner group number and demonstrate that BLUE data is not delivered there. Test a missing MVPN family, a missing underlay group path and a tenant RPF mismatch as separate faults before combining them. A passing unicast ping is a control experiment, not the multicast acceptance test.

## Worked cases

### Three green screens, one missing tree

Synthetic: receiver IGMP membership exists, MVPN routes are imported, unicast EVPN works; outer group 239.194.0.10 has no receiver-leaf outgoing interface at the spine.

Follow the packet to the outer tree. Correct underlay PIM/RPF and membership for that transport path, then test tenant delivery. Do not broaden route-target imports because the supplied evidence already reaches the right tenant signaling state.

### Routed service versus LAN assumptions

Synthetic: application emits TTL 1. Source and receiver addresses are in different tenant subnets. No receiver data appears despite valid trees.

The routed path can exhaust TTL. Confirm with a capture and controlled application TTL change within the authorized scope. Preserve negative tests for RED and local-scope groups; do not globally alter multicast boundaries.

## Guided build and fault isolation

Extend the existing two-leaf EVPN workbook with BLUE multicast between different subnets, recording all four evidence layers.

Hint: Prove the underlay outer-group path separately from tenant RPF and MVPN joins.

Instructor reasoning: A successful record joins endpoint membership, tenant routing, MVPN family/import and outer-tree delivery to observed application packets. Break each dependency individually and predict the affected layer.

## Independent assignment

Build the approved TRM mode on supported equipment, then diagnose an unknown combination of missing MVPN signaling and underlay tree failure. Include a RED isolation test, receiver leave/expiry observation and source TTL explanation.

## Verified primary references

- [NX-OS 10.3(x): Tenant Routed Multicast](https://www.cisco.com/c/en/us/td/docs/dcn/nx-os/nexus9000/103x/configuration/vxlan/cisco-nexus-9000-series-nx-os-vxlan-configuration-guide-release-103x/m-configuring-trm.html)
- [Multicast VPN architecture, RFC 6513](https://www.rfc-editor.org/rfc/rfc6513.html)
- [BGP encodings for multicast VPNs, RFC 6514](https://www.rfc-editor.org/rfc/rfc6514.html)
