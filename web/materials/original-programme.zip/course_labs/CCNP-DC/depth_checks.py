#!/usr/bin/env python3
"""Offline teaching models for chapters 092–104; no network access or device emulation.

Every input/output is synthetic. These narrow models expose assumptions rather
than implementing complete OSPF, PTP, MVPN, MDS, APIC or Nexus Dashboard systems.
"""
import argparse,copy,ipaddress,json,math,re,unittest
from pathlib import Path


def finite(value):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):
        raise ValueError('finite numeric input required')
    return value


def ptp_estimate(forward_interval_us,reverse_interval_us):
    a,b=finite(forward_interval_us),finite(reverse_interval_us)
    delay=(a+b)/2
    if delay<0: raise ValueError('negative mean delay is outside this model')
    return {'mean_delay_us':delay,'receiver_offset_us':(a-b)/2,'assumption':'equal forward and reverse propagation delay'}


def holdover(initial_bound_us,drift_us_per_second,seconds):
    values=[finite(x) for x in (initial_bound_us,drift_us_per_second,seconds)]
    if any(x<0 for x in values):raise ValueError('bounds and elapsed time must be nonnegative')
    return values[0]+values[1]*values[2]


def ospf_e1_cost(internal,external):
    a,b=finite(internal),finite(external)
    if min(a,b)<0:raise ValueError('cost must be nonnegative')
    return a+b


def dpvm_lookup(pwwn,nwwn,active_p,active_n,static_vsan,valid_vsans):
    """Teaching precedence at a new supported F-port login; no live-session model."""
    target=active_p.get(pwwn,active_n.get(nwwn,static_vsan))
    if static_vsan not in valid_vsans:raise ValueError('static port VSAN must be valid')
    if target not in valid_vsans:raise ValueError('selected dynamic VSAN is not operational')
    return target


def smart_pairs(roles):
    """Logical unordered exchanges, NOT hardware entry sizing or MDS emulation."""
    valid={'initiator','target','both'}
    if any(v not in valid for v in roles.values()):raise ValueError('verify unknown device role first')
    names=sorted(roles);result=[]
    for i,a in enumerate(names):
        for b in names[i+1:]:
            ar,br=roles[a],roles[b]
            if (ar in {'initiator','both'} and br in {'target','both'}) or (br in {'initiator','both'} and ar in {'target','both'}):result.append([a,b])
    return result


def cfs_participants(origin,application,switches):
    """Synthetic supported physical-scope application with configured regions.
    Transport reachability is a supplied Boolean, not a discovered fact.
    """
    src=switches[origin]
    if not src['cfs'] or not src['applications'].get(application,False):return []
    region=src['regions'].get(application,0)
    return sorted(name for name,s in switches.items() if s['cfs'] and s['reachable'] and s['applications'].get(application,False) and s['regions'].get(application,0)==region)


def schema_label_update(schema,expected_version,new_label):
    """Narrow optimistic-concurrency exercise; not an APIC/NDO API server."""
    if type(expected_version) is not int:raise ValueError('integer expected version required')
    if schema['_updateVersion']!=expected_version:raise ValueError('stale object version: reread and reconcile')
    if not isinstance(new_label,str) or not new_label.strip():raise ValueError('nonempty label required')
    out=copy.deepcopy(schema);out['displayName']=new_label;out['_updateVersion']+=1;return out


def render_vlan(vlan_id,vlan_name,reserved=(1,99)):
    """Original two-line CLI generator with a deliberately narrow input contract."""
    if type(vlan_id) is not int or not 2<=vlan_id<=4094 or vlan_id in reserved:raise ValueError('VLAN outside permitted lab range or reserved')
    if not isinstance(vlan_name,str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,31}',vlan_name):raise ValueError('name must be a single bounded label')
    return f'vlan {vlan_id}\n  name {vlan_name}\n'


def counter_rate(before,after,seconds):
    a,b,t=(finite(x) for x in (before,after,seconds))
    if a<0 or b<0 or t<=0:raise ValueError('nonnegative counters and positive interval required')
    if b<a:raise ValueError('counter reset or wrap: resolve before computing rate')
    return (b-a)*8/t


def observation_scope(collected,analysis,change_time):
    a,b,c=(finite(x) for x in (collected,analysis,change_time))
    if b<a:raise ValueError('analysis cannot precede collection in this normalized model')
    return 'predates_change' if a<c else 'includes_time_after_change'


def trm_missing_layers(state):
    required=['receiver_membership','tenant_rpf','mvpn_signaling','underlay_tree','tenant_isolation']
    if any(type(state.get(k)) is not bool for k in required):raise ValueError('all modeled gates require explicit true/false observations')
    return [k for k in required if not state[k]]


def prefix_permitted(candidate, base, minimum, maximum):
    """One positive prefix-list entry, not full route-map evaluation."""
    network=ipaddress.ip_network(candidate,strict=True);parent=ipaddress.ip_network(base,strict=True)
    if network.version!=parent.version:raise ValueError('address families differ')
    if not parent.prefixlen<=minimum<=maximum<=parent.max_prefixlen:raise ValueError('invalid prefix-length range')
    return network.subnet_of(parent) and minimum<=network.prefixlen<=maximum


def effective_priority(base,decrements):
    """Arithmetic only; no election, address-owner or timer simulation."""
    values=[base]+list(decrements)
    if any(type(v) is not int or v<0 or v>255 for v in values):raise ValueError('integer priorities/decrements from 0 to 255 required')
    return max(0,base-sum(decrements))


def source_requested(mode,sources,candidate):
    """Conceptual host filter only; NOT NX-OS EXCLUDE implementation support."""
    if mode not in {'INCLUDE','EXCLUDE'}:raise ValueError('explicit filter mode required')
    selected=ipaddress.ip_address(candidate);pool={ipaddress.ip_address(x) for x in sources}
    if any(x.version!=selected.version for x in pool):raise ValueError('mixed address-family filter')
    return selected in pool if mode=='INCLUDE' else selected not in pool


def resource_change(current,target,mode):
    """Flat typed resource model. Omission deletes only for replacement.
    No CLI parser, dependency ordering, rollback engine or live execution.
    """
    if mode not in {'merge','replace'}:raise ValueError('choose merge or replace')
    if not isinstance(current,dict) or not isinstance(target,dict):raise ValueError('resource dictionaries required')
    result=copy.deepcopy(target if mode=='replace' else current)
    if mode=='merge':result.update(copy.deepcopy(target))
    return {'result':result,'removed':sorted(set(current)-set(result)),'changed':sorted(k for k in result if k not in current or result[k]!=current[k])}


class DepthTests(unittest.TestCase):
    def test_prefix_exact(self):self.assertTrue(prefix_permitted('10.101.0.0/24','10.101.0.0/16',16,24))
    def test_prefix_too_specific(self):self.assertFalse(prefix_permitted('10.101.0.0/25','10.101.0.0/16',16,24))
    def test_prefix_outside(self):self.assertFalse(prefix_permitted('10.102.0.0/24','10.101.0.0/16',16,24))
    def test_prefix_invalid_range(self):
        with self.assertRaises(ValueError):prefix_permitted('10.101.0.0/24','10.101.0.0/16',24,20)
    def test_track_sufficient(self):self.assertLess(effective_priority(120,[30]),100)
    def test_track_insufficient(self):self.assertGreater(effective_priority(120,[10]),100)
    def test_track_multiple(self):self.assertEqual(effective_priority(120,[10,30]),80)
    def test_track_boolean(self):
        with self.assertRaises(ValueError):effective_priority(True,[10])
    def test_include_specific(self):self.assertTrue(source_requested('INCLUDE',['192.0.2.11'],'192.0.2.11'))
    def test_include_other(self):self.assertFalse(source_requested('INCLUDE',['192.0.2.11'],'192.0.2.12'))
    def test_empty_include(self):self.assertFalse(source_requested('INCLUDE',[],'192.0.2.11'))
    def test_empty_exclude_model(self):self.assertTrue(source_requested('EXCLUDE',[],'192.0.2.11'))
    def test_exclude_member_model(self):self.assertFalse(source_requested('EXCLUDE',['192.0.2.11'],'192.0.2.11'))
    def test_filter_mixed_family(self):
        with self.assertRaises(ValueError):source_requested('INCLUDE',['2001:db8::1'],'192.0.2.11')
    def test_merge_keeps_omitted(self):self.assertEqual(resource_change({'vlan10':{},'vlan20':{}},{'vlan10':{}},'merge')['removed'],[])
    def test_replace_removes_omitted(self):self.assertEqual(resource_change({'vlan10':{},'vlan20':{}},{'vlan10':{}},'replace')['removed'],['vlan20'])
    def test_replace_concurrent_loss(self):self.assertIn('approved_vlan30',resource_change({'vlan10':{},'approved_vlan30':{}},{'vlan10':{}},'replace')['removed'])
    def test_resource_copy(self):
        current={'interface':{'description':'old'}};new=resource_change(current,{'interface':{'description':'new'}},'merge');self.assertEqual(current['interface']['description'],'old');self.assertEqual(new['result']['interface']['description'],'new')

    def test_ptp_offset(self):self.assertEqual(ptp_estimate(14,6)['receiver_offset_us'],4)
    def test_ptp_delay(self):self.assertEqual(ptp_estimate(14,6)['mean_delay_us'],10)
    def test_ptp_asymmetry(self):self.assertEqual(ptp_estimate(12,8)['receiver_offset_us'],2)
    def test_ptp_negative_offset(self):self.assertEqual(ptp_estimate(6,14)['receiver_offset_us'],-4)
    def test_ptp_nan(self):
        with self.assertRaises(ValueError):ptp_estimate(float('nan'),2)
    def test_holdover(self):self.assertEqual(holdover(3,0.8,60),51)
    def test_holdover_negative(self):
        with self.assertRaises(ValueError):holdover(1,1,-1)
    def test_e1(self):self.assertLess(ospf_e1_cost(25,10),ospf_e1_cost(12,30))
    def test_dpvm_specific(self):self.assertEqual(dpvm_lookup('p','n',{'p':95},{'n':96},96,{95,96}),95)
    def test_dpvm_node(self):self.assertEqual(dpvm_lookup('p','n',{}, {'n':95},96,{95,96}),95)
    def test_dpvm_fallback(self):self.assertEqual(dpvm_lookup('p','n',{}, {},96,{95,96}),96)
    def test_dpvm_invalid_target(self):
        with self.assertRaises(ValueError):dpvm_lookup('p','n',{'p':95},{},96,{96})
    def test_dpvm_invalid_static(self):
        with self.assertRaises(ValueError):dpvm_lookup('p','n',{'p':95},{},96,{95})
    def test_smart_pairs(self):self.assertEqual(len(smart_pairs({'I1':'initiator','I2':'initiator','T1':'target','T2':'target'})),4)
    def test_smart_no_target_pair(self):self.assertEqual(smart_pairs({'T1':'target','T2':'target'}),[])
    def test_smart_both(self):self.assertEqual(smart_pairs({'A':'both','B':'target'}),[['A','B']])
    def test_smart_unknown(self):
        with self.assertRaises(ValueError):smart_pairs({'I':'unknown','T':'target'})
    def peers(self):return {n:{'cfs':True,'reachable':True,'applications':{'ntp':True},'regions':{'ntp':r}} for n,r in [('A',7),('B',7),('C',0)]}
    def test_cfs_region(self):self.assertEqual(cfs_participants('A','ntp',self.peers()),['A','B'])
    def test_cfs_default_expansion(self):
        p=self.peers();p['A']['regions']={};p['B']['regions']={};self.assertEqual(cfs_participants('A','ntp',p),['A','B','C'])
    def test_cfs_app_disabled(self):
        p=self.peers();p['B']['applications']['ntp']=False;self.assertEqual(cfs_participants('A','ntp',p),['A'])
    def test_cfs_global_disabled(self):
        p=self.peers();p['A']['cfs']=False;self.assertEqual(cfs_participants('A','ntp',p),[])
    def test_schema_copy(self):
        old={'_updateVersion':7,'displayName':'old','other':{'preserve':1}};new=schema_label_update(old,7,'reviewed');self.assertEqual(new['_updateVersion'],8);self.assertEqual(old['displayName'],'old');self.assertEqual(new['other'],old['other'])
    def test_schema_stale(self):
        with self.assertRaises(ValueError):schema_label_update({'_updateVersion':8},7,'new')
    def test_vlan(self):self.assertEqual(render_vlan(990,'ACADEMY_BLUE'),'vlan 990\n  name ACADEMY_BLUE\n')
    def test_vlan_injection(self):
        with self.assertRaises(ValueError):render_vlan(990,'BLUE\nshutdown')
    def test_vlan_reserved(self):
        with self.assertRaises(ValueError):render_vlan(99,'BLUE')
    def test_vlan_boolean(self):
        with self.assertRaises(ValueError):render_vlan(True,'BLUE')
    def test_vlan_range(self):
        with self.assertRaises(ValueError):render_vlan(4095,'BLUE')
    def test_rate(self):self.assertEqual(counter_rate(100000,400000,2),1200000)
    def test_rate_reset(self):
        with self.assertRaises(ValueError):counter_rate(400000,100000,2)
    def test_rate_zero_interval(self):
        with self.assertRaises(ValueError):counter_rate(1,2,0)
    def test_snapshot(self):self.assertEqual(observation_scope(9,11.1,10.5),'predates_change')
    def test_fresh_collection(self):self.assertEqual(observation_scope(11,11.1,10.5),'includes_time_after_change')
    def test_trm_layer(self):self.assertEqual(trm_missing_layers(dict(receiver_membership=True,tenant_rpf=True,mvpn_signaling=True,underlay_tree=False,tenant_isolation=True)),['underlay_tree'])
    def test_trm_unknown(self):
        with self.assertRaises(ValueError):trm_missing_layers({})


def demo():
    return {'label':'SYNTHETIC OFFLINE MODEL; no Cisco execution', 'prefix_allow_24':prefix_permitted('10.101.0.0/24','10.101.0.0/16',16,24),'tracked_priority':effective_priority(120,[30]),'include_other_source':source_requested('INCLUDE',['192.0.2.11'],'192.0.2.12'),'replacement_diff':resource_change({'vlan10':{},'approved_vlan30':{}},{'vlan10':{}},'replace'),'ptp':ptp_estimate(14,6),'holdover_bound_us':holdover(3,.8,60),'e1_costs':[ospf_e1_cost(12,30),ospf_e1_cost(25,10)],'dpvm_selected_vsan':dpvm_lookup('p','n',{'p':95},{'n':96},96,{95,96}),'smart_logical_pairs':smart_pairs({'I1':'initiator','I2':'initiator','T1':'target','T2':'target'}),'schema_updated':schema_label_update({'_updateVersion':7,'displayName':'old'},7,'reviewed'),'rendered_cli':render_vlan(990,'ACADEMY_BLUE'),'rate_bps':counter_rate(100000,400000,2),'snapshot_scope':observation_scope(9,11.1,10.5),'trm_missing':trm_missing_layers(dict(receiver_membership=True,tenant_rpf=True,mvpn_signaling=True,underlay_tree=False,tenant_isolation=True))}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--self-test',action='store_true');parser.add_argument('--demo',action='store_true');args=parser.parse_args()
    if args.self_test:unittest.main(argv=['depth_checks'],verbosity=2)
    else:print(json.dumps(demo(),indent=2))
