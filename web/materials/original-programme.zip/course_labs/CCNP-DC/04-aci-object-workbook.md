# ACI tenant construction and access-policy dependency worksheet

Use an authorized APIC sandbox or isolated fabric with a pinned supported 6.x release. The JSON below is an original teaching payload for the APIC managed-object model; it was not submitted to a controller here. Query the target model and API documentation before execution. The payload creates a small logical tenant but deliberately does not claim to commission physical access or external routing by itself.

**Logical construction.** The intended graph is LAB → VRF BLUE → BD WEB → EPG web under application profile APP. The BD gateway is10.120.0.1/24. An EPG-to-BD relationship and BD-to-VRF relationship are explicit objects.

```json
{
  "fvTenant": {
    "attributes": {"name": "LAB"},
    "children": [
      {"fvCtx": {"attributes": {"name": "BLUE"}}},
      {"fvBD": {
        "attributes": {"name": "WEB", "unicastRoute": "yes"},
        "children": [
          {"fvRsCtx": {"attributes": {"tnFvCtxName": "BLUE"}}},
          {"fvSubnet": {"attributes": {"ip": "10.120.0.1/24", "scope": "private"}}}
        ]
      }},
      {"fvAp": {
        "attributes": {"name": "APP"},
        "children": [
          {"fvAEPg": {
            "attributes": {"name": "web"},
            "children": [
              {"fvRsBd": {"attributes": {"tnFvBDName": "WEB"}}}
            ]
          }}
        ]
      }}
    ]
  }
}
```

A supported REST workflow targets the relevant managed-object endpoint, uses a scoped authenticated session and inspects both response and subsequent fault/deployment state. Read back the tenant subtree and inspect the actual relationship target names. Do not infer that an HTTP success means a physical host can now communicate.

**Access chain.** Complete this table with actual object DNs and observed relationships before adding the EPG's physical path. The EPG needs a compatible domain; the selected leaf interface must resolve through its selector/policy group/AEP to that domain and an eligible VLAN pool.

| Requirement | Object/relationship to record | Proof |
|---|---|---|
| VLAN120 available | VLAN pool and allocation mode |120 lies in approved range |
| Physical domain eligible | Domain→pool and AEP→domain |Both references resolve |
| Leaf/port selected | Switch profile, interface profile/selector |Correct node and port |
| Port behavior | Interface policy group |Speed/LACP/trunk/access settings appropriate |
| EPG membership | EPG→domain and static path/encap |Effective deployment and endpoint learning |

For a vPC path, configure the supported leaf-pair/bundle model first. A static EPG path referencing a vPC does not create the underlying vPC pair. For a VMM domain, replace the physical-static assumptions with the actual controller, dynamic allocation and resolution/deployment model.

**Contract construction.** Define a filter for the approved protocol/service, a subject referencing it, a contract containing the subject and provider/consumer relationships on the intended EPGs. Record scope and reverse-direction handling from the chosen release. First test the intended service, then an adjacent forbidden port and an unauthorized source EPG. Do not use preferred-group or vzAny expansion merely to hide a wrong filter or classification.

**L3Out construction.** Record the VRF relationship, logical border-node profile, logical interface profile/path, address and routing protocol, external EPG classification, contracts, internal BD subnet advertisement scope and return route. Build one approved external prefix first. Confirm actual received/advertised routes; a0.0.0.0/0 external classification object is not automatically a default route. This DCACI sequence excludes transit routing and VRF leaking from its exam-specific L3Out claim; advanced programme work can address them separately.

**Guided break/fix.** Change only `tnFvBDName` to an absent BD and observe the unresolved relation. Restore it, then remove VLAN120 from the eligible pool and compare the fault stage. Finally introduce a contract port mismatch. Explain why these three failures require different repairs even when the application symptom is simply timeout.

**Independent gate.** Supply the completed object graph, API request/response records with secrets removed, effective access/route/policy state, packet walks and positive/negative flow matrix. APIC simulator success does not establish actual switch hardware forwarding or VMM compatibility; label the environment precisely.
