#!/usr/bin/env python3
"""Offline Cisco automation reasoning labs. No sockets, subprocesses or device writes.

Fixtures are synthetic. Passing these checks validates this local logic only.
Run: python academy_lab.py demo | python academy_lab.py selftest
"""
from __future__ import annotations
import argparse
import copy
import json
import math
import re
import unittest
from datetime import datetime, timezone

class ValidationError(ValueError):
    pass


def rows(value):
    if isinstance(value, dict):
        return [value]
    if isinstance(value, list) and all(isinstance(x, dict) for x in value):
        return value
    raise ValidationError('Expected one row object or a list of row objects')


def parse_nxapi(payload):
    """Strict parser for the supplied teaching envelope, not all NX-API commands."""
    try:
        outputs = rows(payload['ins_api']['outputs']['output'])
    except (KeyError, TypeError) as exc:
        raise ValidationError('Missing NX-API teaching envelope') from exc
    result = []
    for operation in outputs:
        if str(operation.get('code')) != '200':
            raise ValidationError('Device operation failed: '+str(operation.get('msg', 'unknown')))
        try:
            interfaces = rows(operation['body']['TABLE_interface']['ROW_interface'])
        except (KeyError, TypeError) as exc:
            raise ValidationError('Missing interface table') from exc
        for interface in interfaces:
            if not isinstance(interface.get('interface'), str):
                raise ValidationError('Interface identity missing')
            if interface.get('admin_state') not in {'up', 'down'}:
                raise ValidationError('Unknown administrative state')
            if interface.get('oper_state') not in {'up', 'down'}:
                raise ValidationError('Unknown operational state')
            result.append(dict(interface))
    if not result:
        raise ValidationError('No required interface observations returned')
    return result


def validate_vlan_intent(intent):
    if not isinstance(intent, dict) or set(intent) != {'asset_id', 'vlans', 'required_vlans'}:
        raise ValidationError('Intent keys must match the declared contract')
    if not isinstance(intent['asset_id'], str) or not intent['asset_id']:
        raise ValidationError('Stable asset identity required')
    if not isinstance(intent['vlans'], list) or not isinstance(intent['required_vlans'], list):
        raise ValidationError('VLAN sets must be lists')
    seen = set()
    for vlan in intent['vlans']:
        if not isinstance(vlan, dict) or set(vlan) != {'id', 'name'}:
            raise ValidationError('Each VLAN needs exactly id and name')
        vid = vlan['id']
        if type(vid) is not int or not 1 <= vid <= 4094:
            raise ValidationError('VLAN ID must be an integer in the teaching range 1..4094')
        if vid in seen:
            raise ValidationError('Duplicate VLAN ID')
        if not isinstance(vlan['name'], str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,32}', vlan['name']):
            raise ValidationError('VLAN name violates the constrained lab grammar')
        seen.add(vid)
    if any(type(x) is not int for x in intent['required_vlans']):
        raise ValidationError('Required VLAN IDs must be integers')
    if not set(intent['required_vlans']) <= seen:
        raise ValidationError('Required service VLAN would be removed')
    return sorted(intent['vlans'], key=lambda x: x['id'])


def validate_inventory(record, observed, authorized_assets):
    required = {'asset_id', 'serial', 'role', 'lifecycle'}
    if not required <= record.keys():
        raise ValidationError('Incomplete inventory record')
    if record['asset_id'] not in authorized_assets:
        raise ValidationError('Asset outside authorized target set')
    if record['lifecycle'] != 'active':
        raise ValidationError('Asset is not active')
    if record['serial'] != observed.get('serial'):
        raise ValidationError('Observed hardware identity differs from approved inventory')
    if record['role'] != observed.get('role'):
        raise ValidationError('Observed role differs; reconcile rather than overwrite intent')
    return record['asset_id']


def gnmi_teaching_payload(interface, enabled):
    """Intermediate model fixture, NOT a serialized protobuf/wire request."""
    if not isinstance(interface, str) or not re.fullmatch(r'Ethernet[1-9][0-9]*/[1-9][0-9]*', interface):
        raise ValidationError('Constrained lab interface name required')
    if type(enabled) is not bool:
        raise ValidationError('enabled must be a boolean, not a truthy string')
    return {'update': [{'path': {'elem': [
        {'name': 'interfaces'},
        {'name': 'interface', 'key': {'name': interface}},
        {'name': 'config'}, {'name': 'enabled'}]},
        'value': {'json_ietf_val_text': json.dumps(enabled)}}],
        'limitations': 'Intermediate teaching structure. Use actual supported gNMI protobuf/client encoding for a real target.'}


def seconds_to_ns(seconds):
    if type(seconds) not in {int, float} or not math.isfinite(seconds) or not 0.1 <= seconds <= 86400:
        raise ValidationError('Sample interval outside bounded teaching policy')
    return int(seconds * 1_000_000_000)


def counter_rate(before, after):
    """Return unknown for resets, identity changes and invalid time; never false health."""
    for item in (before, after):
        if not {'asset_id', 'boot_id', 'seconds', 'bytes'} <= item.keys():
            raise ValidationError('Counter sample incomplete')
        if type(item['bytes']) is not int or item['bytes'] < 0:
            raise ValidationError('Counter must be a nonnegative integer')
        if type(item['seconds']) not in {int,float} or not math.isfinite(item['seconds']):
            raise ValidationError('Sample time invalid')
    if before['asset_id'] != after['asset_id']:
        return {'status': 'unknown', 'reason': 'asset identity changed'}
    if before['boot_id'] != after['boot_id'] or after['bytes'] < before['bytes']:
        return {'status': 'unknown', 'reason': 'counter discontinuity; establish new baseline'}
    elapsed = after['seconds'] - before['seconds']
    if elapsed <= 0:
        return {'status': 'unknown', 'reason': 'nonpositive elapsed time'}
    return {'status': 'observed', 'bytes_per_second': (after['bytes']-before['bytes'])/elapsed}


def health_report(observation, now_seconds, max_age=60):
    if observation.get('collection_status') != 'ok':
        return {'health': 'unknown', 'reason': 'collection failed', 'source': observation.get('source')}
    stamp = observation.get('observed_seconds')
    if type(stamp) not in {int, float} or not math.isfinite(stamp):
        return {'health': 'unknown', 'reason': 'invalid observation time'}
    age = now_seconds-stamp
    if age < 0 or age > max_age:
        return {'health': 'unknown', 'reason': 'future or stale observation', 'age_seconds': age}
    interfaces = parse_nxapi(observation['payload'])
    faults = [x['interface'] for x in interfaces if x['admin_state']=='up' and x['oper_state']!='up']
    return {'health': 'fault' if faults else 'observed_healthy_for_checked_interfaces',
            'fault_interfaces': faults, 'age_seconds': age,
            'limitations': 'This checks only supplied interface observations, not complete application health.'}


def reconcile_job(expected_assets, results):
    if len(set(expected_assets)) != len(expected_assets):
        raise ValidationError('Duplicate target identity')
    by_asset = {}
    for result in results:
        asset = result.get('asset_id')
        if asset not in expected_assets or asset in by_asset:
            raise ValidationError('Unexpected or duplicate result target')
        if result.get('status') not in {'succeeded', 'failed', 'pending'}:
            raise ValidationError('Unknown execution result')
        by_asset[asset] = result['status']
    missing = [x for x in expected_assets if x not in by_asset]
    failed = [x for x,s in by_asset.items() if s=='failed']
    pending = [x for x,s in by_asset.items() if s=='pending']
    return {'execution_complete': not (missing or failed or pending),
            'missing': missing, 'failed': failed, 'pending': pending,
            'service_verified': False,
            'next_step': 'Verify effective service separately' if not (missing or failed or pending) else 'Reconcile actual state before retry or compensation'}


def validate_agent_plan(plan, authorized_assets):
    if set(plan) != {'operation', 'asset_ids', 'approved_change_id', 'payload'}:
        raise ValidationError('Unexpected plan fields')
    if plan['operation'] not in {'read_interfaces', 'propose_vlan_intent'}:
        raise ValidationError('Operation outside this offline read/proposal boundary')
    if not isinstance(plan['asset_ids'],list) or not plan['asset_ids']:
        raise ValidationError('Explicit target list required')
    if not set(plan['asset_ids']) <= set(authorized_assets):
        raise ValidationError('Unauthorized target')
    if plan['operation']=='propose_vlan_intent':
        if not isinstance(plan['approved_change_id'],str) or not plan['approved_change_id'].startswith('LAB-'):
            raise ValidationError('Lab change identity required')
        validate_vlan_intent(plan['payload'])
        if plan['payload']['asset_id'] not in plan['asset_ids']:
            raise ValidationError('Payload target differs from plan scope')
    return {'validated_proposal': True, 'executed': False,
            'note': 'This program has no mutation or network capability.'}


SINGLE={'ins_api':{'outputs':{'output':{'code':'200','body':{'TABLE_interface':{'ROW_interface':{'interface':'Ethernet1/1','admin_state':'up','oper_state':'down'}}}}}}}
INTENT={'asset_id':'leaf-a','vlans':[{'id':120,'name':'application'},{'id':99,'name':'management'}],'required_vlans':[99]}

class LabTests(unittest.TestCase):
    def test_single_row(self):self.assertEqual(len(parse_nxapi(SINGLE)),1)
    def test_multiple_rows(self):
        x=copy.deepcopy(SINGLE);row=x['ins_api']['outputs']['output']['body']['TABLE_interface'];row['ROW_interface']=[row['ROW_interface'],{'interface':'Ethernet1/2','admin_state':'up','oper_state':'up'}]
        self.assertEqual(len(parse_nxapi(x)),2)
    def test_device_error_inside_http_success(self):
        x=copy.deepcopy(SINGLE);x['ins_api']['outputs']['output']['code']='400'
        with self.assertRaises(ValidationError):parse_nxapi(x)
    def test_unknown_schema(self):
        with self.assertRaises(ValidationError):parse_nxapi({'result':[]})
    def test_duplicate_vlan(self):
        x=copy.deepcopy(INTENT);x['vlans'].append(x['vlans'][0])
        with self.assertRaises(ValidationError):validate_vlan_intent(x)
    def test_injection_like_name(self):
        x=copy.deepcopy(INTENT);x['vlans'][0]['name']='prod\nshutdown'
        with self.assertRaises(ValidationError):validate_vlan_intent(x)
    def test_required_vlan_preserved(self):
        x=copy.deepcopy(INTENT);x['vlans']=x['vlans'][:1]
        with self.assertRaises(ValidationError):validate_vlan_intent(x)
    def test_boolean_not_vlan_integer(self):
        x=copy.deepcopy(INTENT);x['vlans'][0]['id']=True
        with self.assertRaises(ValidationError):validate_vlan_intent(x)
    def test_deterministic_vlan_order(self):self.assertEqual([x['id'] for x in validate_vlan_intent(INTENT)],[99,120])
    def test_wrong_serial(self):
        with self.assertRaises(ValidationError):validate_inventory({'asset_id':'a','serial':'OLD','role':'leaf','lifecycle':'active'},{'serial':'NEW','role':'leaf'},{'a'})
    def test_retired_target(self):
        with self.assertRaises(ValidationError):validate_inventory({'asset_id':'a','serial':'S','role':'leaf','lifecycle':'retired'},{'serial':'S','role':'leaf'},{'a'})
    def test_gnmi_boolean(self):self.assertEqual(gnmi_teaching_payload('Ethernet1/12',False)['update'][0]['value']['json_ietf_val_text'],'false')
    def test_gnmi_string_rejected(self):
        with self.assertRaises(ValidationError):gnmi_teaching_payload('Ethernet1/12','false')
    def test_subscription_units(self):self.assertEqual(seconds_to_ns(10),10_000_000_000)
    def test_subscription_too_fast(self):
        with self.assertRaises(ValidationError):seconds_to_ns(0.000001)
    def test_counter_rate(self):
        a={'asset_id':'a','boot_id':'b','seconds':10,'bytes':1_000_000};b={**a,'seconds':20,'bytes':1_500_000}
        self.assertEqual(counter_rate(a,b)['bytes_per_second'],50_000)
    def test_counter_reset(self):
        a={'asset_id':'a','boot_id':'b','seconds':10,'bytes':1_000_000};b={**a,'boot_id':'new','seconds':20,'bytes':20_000}
        self.assertEqual(counter_rate(a,b)['status'],'unknown')
    def test_stale_not_healthy(self):self.assertEqual(health_report({'collection_status':'ok','observed_seconds':0,'payload':SINGLE},1500)['health'],'unknown')
    def test_fresh_fault(self):self.assertEqual(health_report({'collection_status':'ok','observed_seconds':99,'payload':SINGLE},100)['health'],'fault')
    def test_timeout_not_healthy(self):self.assertEqual(health_report({'collection_status':'timeout'},100)['health'],'unknown')
    def test_partial_job(self):self.assertFalse(reconcile_job(['a','b'],[{'asset_id':'a','status':'succeeded'}])['execution_complete'])
    def test_execution_not_service_acceptance(self):self.assertFalse(reconcile_job(['a'],[{'asset_id':'a','status':'succeeded'}])['service_verified'])
    def test_agent_forbidden_action(self):
        with self.assertRaises(ValidationError):validate_agent_plan({'operation':'delete_all_acls','asset_ids':['a'],'approved_change_id':'LAB-1','payload':{}},{'a'})
    def test_agent_target_mismatch(self):
        with self.assertRaises(ValidationError):validate_agent_plan({'operation':'propose_vlan_intent','asset_ids':['other'],'approved_change_id':'LAB-1','payload':INTENT},{'other'})


def demo():
    report={'environment':'Offline synthetic fixtures; no device was contacted',
            'normalized_interfaces':parse_nxapi(SINGLE),
            'validated_vlan_intent':validate_vlan_intent(INTENT),
            'gnmi_intermediate':gnmi_teaching_payload('Ethernet1/12',False),
            'ten_second_interval_ns':seconds_to_ns(10),
            'health':health_report({'collection_status':'ok','observed_seconds':99,'payload':SINGLE},100),
            'partial_job':reconcile_job(['leaf-a','leaf-b'],[{'asset_id':'leaf-a','status':'succeeded'},{'asset_id':'leaf-b','status':'failed'}])}
    print(json.dumps(report,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=['demo','selftest'])
    args=parser.parse_args()
    if args.mode=='demo':demo()
    else:
        result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(LabTests))
        raise SystemExit(not result.wasSuccessful())
