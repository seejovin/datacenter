# CCNP Data Center engineering workbooks

These original workbooks accompany all five assigned courses: DCCOR, DCACI, DCID, DCIT and DCNAUTO. Study the mechanism and worked example first, complete guided practice, attempt the linked question bank, then perform the independent task. Return incorrect answers to the relevant mechanism; memorizing a letter does not establish understanding.

The programme preserves the curriculum's requirement to study all five courses. Cisco's qualification route and concentration choices do not reduce that educational scope. The public scope versions used here are DCCOR/DCACI/DCID/DCIT v1.2 and DCNAUTO v2.0, checked on 19 September 2026. See `BLUEPRINT_MAP.md` and `blueprint_map.json` for the explicit provider-leaf crosswalk. An item linked to several leaves is counted once in the bank.

## Environments and evidence

There are three different kinds of work in this folder:

| Work | What it can demonstrate | Required environment |
|---|---|---|
| Analytical cases and synthetic exhibits | Mechanism reasoning, calculations, justified design and diagnosis | The course and an evidence worksheet |
| `academy_lab.py` | Tested parsing, validation, reconciliation and health logic against supplied fixtures | Python 3.10 or later; standard library only |
| Cisco and Linux implementation workbooks | A construction and failure-testing procedure for the selected supported environment | Authorized compatible equipment, vendor lab or disposable VM as specified |

Only the Python offline component was executed while this package was authored. Device configurations, API examples and fault outputs are original illustrative or synthetic material. Do not label an analytical worksheet as a physical test. Cisco virtual platforms do not necessarily reproduce ASIC buffering, optics, storage interoperability, line-rate forwarding, timing, PFC behavior or every licensed feature.

Choose the exact switch/server/controller model, image, license, hypervisor, adapter, storage and driver combination before a vendor exercise. Review the selected release's compatibility and command documentation. NX-OS examples assume a supported Nexus 9000 10.x laboratory; the source list includes 10.6 guidance. APIC examples assume a supported 6.x laboratory. MDS, UCS, Intersight and Linux exercises require their explicitly selected supported release. The VXLAN workbook deliberately identifies its classic L3-VNI construction and requires choosing one supported mode.

## Workbooks

| Workbook | Construct and observe | Distinguishing faults |
|---|---|---|
| `01-routing-workbook.md` | Routed underlay, loopback reachability, OSPF and EVPN BGP sessions | Adjacency, prefix, next-hop and address-family failures |
| `02-vpc-workbook.md` | vPC domain, peer-link, keepalive and downstream aggregation | Member inconsistency, peer-link loss and orphan exposure |
| `03-evpn-workbook.md` | L2 VNI, route targets, routed tenant and anycast gateway | Wrong import, missing L3 association and alternate-path MTU |
| `04-aci-object-workbook.md` | Tenant, VRF, BD, EPG and the attachment/policy dependency chain | Missing relations, classification errors and L3Out scope |
| `05-san-workbook.md` | VSAN, login, aliases, active zoning, masking and workload I/O | Stale identity, inactive policy, missing VSAN and credit/CRC differences |
| `06-ucs-workbook.md` | Pools, policies, templates, boot, firmware and server association | Unresolved dependencies, compatibility and replacement behavior |
| `07-automation-workbook.md` | Offline implementation plus a bridge to actual supported clients | Bad types, wrong targets, stale health, partial jobs and unsafe agent authority |
| `08-linux-workbook.md` | Namespace/veth/bridge path with VLAN and bond extensions | Bridge membership, tag admission and LACP mismatch |

Related chapters share these workbooks. Full text appears once in the course; related chapters link the same artifact. This sharing is not counted as additional authored chapters or questions.

## Run the offline work

From the project root:

```bash
python course_labs/CCNP-DC/academy_lab.py demo
python course_labs/CCNP-DC/academy_lab.py selftest
```

The module makes no network connections and writes no device configuration. Its demonstration fixtures are synthetic. The tests exercise valid and invalid NX-API envelopes; strict intent and inventory validation; required-resource protection; typed gNMI teaching data; subscription intervals; stale or failed collection; counter resets; partial orchestration; and restricted agent proposals. Read the test names and implementation instead of treating a green result as an unexplained badge.

The gNMI helper returns a clearly labeled intermediate representation. It is not a wire-ready protobuf request. A real client must construct the supported PathElem/TypedValue messages, encode the selected model correctly, authenticate to the authorized target and reconcile operation results. The workbook explains that boundary.

For independent assessment, add four new failure fixtures that are meaningfully different from the existing tests. Explain the expected result before execution, implement any necessary correction, and retain the complete observed test report. Separately complete a harmless supported-device read/change/readback/recovery workflow. This second step is an external practical gate.

## End-to-end capstone

Build an evidence portfolio for two deliberately separate network implementations: a standalone NX-OS EVPN fabric and an ACI fabric. Do not paste standalone NX-OS control-plane configuration onto APIC-managed leaves. Both may serve the same written workload and recovery requirements, enabling a justified comparison of their management and policy models.

1. Define tenants, application flows, forbidden flows, rack/server/storage interfaces, management dependencies and normal/failure-state capacity. Include an AI workload's communication, checkpoint, power and cooling interface requirements within your assigned engineering scope.
2. Produce the addressed topology, platform/compatibility matrix, prefix/VLAN/VNI/VSAN allocation, identity/policy model and alternative analysis. Calculate oversubscription, single-flow limits, MTU and recovery timing with units and assumptions.
3. Construct the standalone underlay/overlay and its management path. Prove route import, actual endpoint forwarding, segmentation and a controlled path loss. Explain every difference between control-plane state and observed service.
4. Construct the equivalent bounded ACI application. Prove discovery, physical or virtual attachment, endpoint classification, contract direction and the intended external route/service path. Test one allowed and one denied flow before and after a controlled failure.
5. Commission a compatible server profile and dual storage paths to disposable data. Verify identity, boot target, LUN identity, multipath behavior and workload integrity through one authorized failure and recovery.
6. Deliver an automation workflow with a stable authorized target set, typed intent, preview, bounded execution, per-step result reconciliation and recovery. Integrate independent observation; a controller's accepted job does not close the application acceptance criterion.
7. Investigate assessor-supplied faults without first clearing useful state. Retain competing hypotheses and the observation that separated them. Include a forwarding failure, a policy failure, a server/storage dependency failure, and a stale or misleading automation observation.
8. Hand over the as-built records, tested recovery procedure, monitoring requirements, trust/credential ownership, known limitations and change evidence. Present measured results separately from simulations and untested predictions.

An assessor should accept a practical outcome only when the required service works, forbidden behavior remains denied, the learner explains the mechanism, the specified failure has been tested, recovery is repeatable and the evidence identifies the actual environment. Do not substitute a fixed quiz percentage for those conditions. Provider examinations, experience requirements and certification awards remain separate external processes.

## Build and inspect the authored package

The authoring sources are retained in `review/academy/ccnp_build.py`, `ccnp_quality.py`, `ccnp_deepen.py` and `ccnp_crosswalk.py`. Run them in that order when deliberately rebuilding this course. Running only the first script overwrites later refinement and mapping work. The final `ccnp_audit.py` checks course references, artifacts, question structure, distinct signatures, blueprint links and the actual offline test result. It does not certify the scientific validity or psychometric quality of every question.
