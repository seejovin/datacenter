# PTP, NTP and defensible time-quality measurements

### Time is a measured service

This exercise uses the Cisco Nexus 9000 NX-OS 10.3(x) PTP and NTP guides. Select supported physical interfaces and timestamp hardware before building a lab. A virtual switch can teach message interpretation but cannot demonstrate the precision of a physical timestamp engine. Keep the configured PTP profile, domain, transport, delay mechanism and software image in the evidence manifest. The fact that a product supports some PTP functions does not establish support for every IEEE 1588 option or profile.

Frequency, phase and time of day are different requirements. Two clocks can tick at almost the same rate while disagreeing by a fixed number of seconds. They can agree now yet drift apart rapidly. A workload specification must state the tolerated error, observation interval and behavior after reference loss. A claim such as 'synchronized' without an error bound is inadequate for ordering close security events or comparing one-way packet timestamps.

A clock tree starts from an approved reference and distributes timing through a hierarchy. An ordinary clock has one PTP port; a boundary clock participates on multiple ports and supplies time onward after synchronizing upstream. A transparent clock accounts for packet residence time rather than terminating the timing hierarchy in the same way. These are protocol concepts, not a guarantee that the selected Nexus supports all roles. On this NX-OS baseline, the implementation example uses a boundary-clock role and end-to-end delay measurement. Do not substitute a peer-delay design or native Layer-2 encapsulation without verifying support.

### Four timestamps and the symmetry assumption

Let the reference transmit a Sync message at t1 and the receiver timestamp arrival at t2. Let the receiver send a Delay_Req at t3 and the reference record its arrival at t4. A Delay_Resp conveys the reference's measurement. A two-step exchange supplies precise Sync transmission information in a Follow_Up; a one-step implementation conveys the necessary correction in its supported message processing. Hardware timestamps reduce uncertainty introduced by software scheduling and queues before the timestamp point.

Define receiver offset theta as receiver time minus reference time. With equal forward and reverse delay d, t2 minus t1 equals d plus theta, and t4 minus t3 equals d minus theta. Therefore the estimated path delay is half the sum of the two measured intervals, while the estimated offset is half their difference. These equations require compatible units and appropriately related timestamps. They are not permission to subtract unrelated log clocks.

For an original synthetic exchange, let t2 minus t1 be 14 microseconds and t4 minus t3 be 6 microseconds. The estimated delay is 10 microseconds and the receiver is 4 microseconds ahead. The receiver should correct its time estimate toward the reference rather than adding another 4 microseconds. If the real forward path is 12 microseconds and reverse is 8 while both clocks are actually aligned, the same method reports a false positive offset of 2 microseconds. The asymmetry error is half the directional delay difference. A stable small reported offset can still coexist with systematic path asymmetry.

### Selection, domains and failure behavior

The best-master selection process compares clock datasets according to the chosen profile. Administrative priority can influence selection before some quality fields. Lowering a priority number may make a poor oscillator win; it does not improve that oscillator. A secure design limits who can advertise timing, controls management changes and monitors unexpected changes of reference identity. A PTP domain separates protocol participation but is not cryptographic authentication or a tenant VRF.

The physical forwarding path matters. Variable queueing, asymmetric routing, timestamp placement, unsupported optics or port modes, and a missing message class can degrade synchronization. UDP-based PTP distinguishes event and general messages; a policy that permits only one required class can leave partial evidence visible without completing the measurement. Interpret Sync, Follow_Up, Announce and delay exchanges according to the selected profile. A passive port is not automatically broken: it can represent the topology chosen to avoid competing timing paths.

After upstream loss, the downstream clock may enter holdover or become an unqualified local source according to its implementation and configuration. Holdover error grows with oscillator drift and environmental conditions. At a hypothetical worst-case drift of 0.8 microseconds per second, 60 seconds without correction adds as much as 48 microseconds to the previous bound. An application requiring a 20-microsecond bound cannot treat that interval as healthy just because packets still forward. Define the alarm and application response before inducing reference loss.

### Build and observe the clock chain

Use one approved laboratory reference, a supported Nexus boundary clock and a timestamp-capable endpoint. Preserve the separate management path. First record an unsynchronized baseline. Configure matching profile/domain/transport and verify unicast reachability or the required multicast forwarding independently. The following unexecuted fragment illustrates ordinary PTP enablement and physical-port participation; the source address must belong to the designed clock transport, and the final profile settings come from the release guide:

```text
feature ptp
ptp source 192.0.2.93
interface Ethernet1/10
  ptp
  no shutdown
show ptp brief
show ptp clock
show ptp port interface ethernet 1/10
show ptp detail
```

Do not paste a priority of 1 on every switch. Decide which device should win and inspect the actual selected reference, clock class, port role, offset, delay and observation time. Collect a series through normal load, congestion and reference failover. A single favorable offset does not characterize tails or transient error. Compare with an independent measurement where the application demands precision; an instrument cannot validate itself solely by reporting its own estimate.

NTP serves a related operational need for system timestamps. Check the management VRF, configured servers, reachability, selection status and reported offset. A low stratum identifies distance in a synchronization hierarchy, not guaranteed accuracy or trust. Do not assume PTP synchronization automatically proves that syslog wall-clock time is correct; verify the platform's clock relationships and collect both observations. Keep original timestamps and any analytical corrections separate in an incident timeline.

Rollback must preserve a known reference hierarchy. Restore the prior clock configuration, confirm selected source and convergence, then check downstream application error bounds. Record a time-quality gap explicitly rather than silently rewriting historical logs. Recovery is accepted when the intended reference, error bound and failure alarms work under the required load, not merely when the PTP feature is enabled.

## Worked cases

### Clock arithmetic with hidden asymmetry

Synthetic exchange: forward interval 14 us, reverse interval 6 us. Independent instrument later measures 4 us directional asymmetry.

Under symmetry the estimate is delay 10 us, offset +4 us. Directional asymmetry can account for part of that estimate, so report the independent path observation and uncertainty instead of claiming the clock is exactly 4 us wrong.

### Healthy forwarding, unacceptable holdover

Synthetic: telemetry remains reachable after reference loss. Oscillator bound is 0.8 us/s; application budget is 20 us; outage lasts 60 s.

The additional bound reaches 48 us before including initial error. Mark the timing service out of tolerance even while Ethernet works. Validate the designed alternate reference or application degraded mode rather than suppressing the alarm.

## Guided build and fault isolation

Build one reference-boundary-endpoint chain. Capture selected reference, roles, delay and offset for idle, load, reference loss and recovery.

Hint: Treat the timestamp engine and path symmetry as explicit assumptions.

Instructor reasoning: Produce time series with an independent comparator where available; distinguish advertised clock quality from observed application error. A role transition is expected evidence, not itself success.

## Independent assignment

Construct two reference candidates with deliberate election priorities, then inject a domain mismatch and a general-message filter separately. Recover each without changing unrelated routing. Submit a timing budget and a documented interval where historical log ordering remains uncertain.

## Verified primary references

- [NX-OS 10.3(x): PTP](https://www.cisco.com/c/en/us/td/docs/dcn/nx-os/nexus9000/103x/configuration/system-management/cisco-nexus-9000-series-nx-os-system-management-configuration-guide-103x/m-configuring-ptp.html)
- [NTPv4 protocol, RFC 5905](https://www.rfc-editor.org/rfc/rfc5905.html)
