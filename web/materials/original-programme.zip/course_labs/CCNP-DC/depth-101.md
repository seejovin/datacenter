# BGP best-path selection, prefix policy and advertisement control

### Eligibility comes before preference

Use the Nexus 9000 NX-OS 10.3(x) BGP and route-policy guides. This chapter extends the established-session and next-hop workbook with actual selection and filtering decisions. Assume ordinary unicast BGP unless an EVPN or MVPN family is explicitly named. Optional best-path knobs, additional attributes and platform-specific tie rules must be recorded; a memorized simplified list cannot explain a configuration that deliberately changes the algorithm.

First identify the exact prefix and address family. Longest-prefix forwarding compares installed prefixes; BGP best-path selection compares candidate paths for the same prefix in the same family. A /24 can direct traffic more specifically than a /16 even if the /16 has an attractive BGP attribute. Then determine whether each candidate is eligible: policy must accept it, AS-loop checks must permit it and the next hop must be usable. An unreachable path does not become usable merely by assigning a high local preference.

Keep received, accepted, best, installed and advertised states separate. A received route can be rejected. An accepted route can lose best-path selection. The BGP best path can lose installation to another route source in the unicast RIB. An installed route can fail adjacency or hardware programming. An outbound policy can suppress advertisement even while local forwarding works. This chain explains why a route count from one table cannot answer every routing question.

### Explain the winning comparison

On the pinned baseline, local weight is an early Cisco-specific preference and is not distributed as an ordinary BGP path attribute. Local preference normally guides exit choice inside an AS and is shared through iBGP. Higher values are preferred for these comparisons. Locally originated paths, AS-path length, origin code and MED participate in later decisions according to the configured rules. A shorter AS path is not the first comparison in every case.

Origin code identifies the BGP origin category, not the trustworthiness of the sender. In the applicable comparison, IGP origin is preferred to EGP and then incomplete. It does not mean that an 'IGP' route is necessarily being carried by OSPF on the current link. MED is a lower-is-preferred hint with comparison conditions; by default, it is not a universally comparable cost across unrelated neighboring ASes. A command that changes MED comparison can change the result, so inspect it before calculating.

When earlier attributes tie, eBGP versus iBGP and the internal cost to reach the next hop can affect the selected route. Remaining tie behavior, route-reflection information and best-path change suppression depend on the implementation. Multipath installation has its own eligibility and configuration requirements; two accepted paths do not automatically become two forwarding paths. Record both the best route and the set actually installed for ECMP.

For a synthetic comparison, path A has weight 0, local preference 200 and AS-path length 4; path B has weight 0, local preference 100 and AS-path length 1. With equal eligibility and no intervening special policy, A wins at local preference before AS length matters. If A's next hop becomes unreachable, B may win among remaining eligible paths. This is a change in candidate usability, not a contradiction of local preference.

### Policy direction and route-map evaluation

An inbound policy controls what a neighbor's update becomes in the local routing process. Raising inbound local preference for a selected route normally influences local-AS outbound traffic toward that destination. An outbound policy controls advertisements sent to a neighbor. Prepending the local AS on an outbound announcement can influence how remote networks choose an inbound path toward the advertised service, but remote policy can override that hint. Neither operation is a packet ACL.

Prefix-list entries combine an address prefix with allowed prefix lengths. An exact /16 match is different from allowing more-specific /17 through /24 routes. A broader permitted length range can accidentally admit a route the site does not own. Evaluate both containment and prefix length. Route maps evaluate ordered sequences and their match conditions; an unmatched route can reach a later sequence, and an implicit deny can reject routes with no permitted match.

A deny inside a referenced prefix list means that entry does not satisfy the route-map match condition. It is not automatically equivalent to a matching deny route-map sequence. This distinction matters when a later permit sequence exists. Work through the control flow with one concrete prefix before changing a production route map. Give deny and permit policy objects names that express their actual use rather than assuming the word 'BLOCK' changes semantics.

### Construct a bounded route-policy experiment

Use two upstream laboratory routers and one border leaf. Announce only owned synthetic ranges and retain an out-of-band recovery path. Define the allowed service aggregate 10.101.0.0/16 and any specifically approved more-specifics. The following original unexecuted fragment prefers accepted routes in that range from one neighbor while rejecting other routes in this deliberately narrow lab feed:

```text
ip prefix-list APP101 seq 5 permit 10.101.0.0/16 le 24
route-map PREFER_APP101 permit 10
  match ip address prefix-list APP101
  set local-preference 200
router bgp 65000
  neighbor 192.0.2.101
    remote-as 65101
    address-family ipv4 unicast
      route-map PREFER_APP101 in
```

There is no final permit-all sequence in this example. That is intentional for the isolated feed and would be inappropriate if the real neighbor also supplies other required routes. Before applying it, enumerate the expected accepted and denied prefixes. Do not reuse a narrow example on a full production table without deriving the actual policy.

Capture the relevant BGP table, accepted routes, next-hop reachability, RIB and advertisements using release-confirmed show commands. If policy changes need re-evaluation, prefer the supported route-refresh or appropriately scoped soft procedure when available, rather than resetting every BGP session. Verify negotiated capability and retained inbound information; a soft operation is not magic reconstruction of data the device never retained or cannot request.

Test three failures separately: a prefix length outside the allowlist, a correct route whose next hop is unresolved and a preferred BGP route displaced in the RIB by another source. Then test a route-map control-flow error using a denied prefix-list match followed by a permissive route-map sequence. Predict the result first, observe it and repair the policy narrowly. Acceptance includes a negative advertisement test: unowned or unauthorized prefixes must remain absent from the neighbor's accepted state.

## Worked cases

### Longer AS path wins for a reason

Synthetic: equal eligible weights, local preference 200 versus 100, AS lengths 4 versus 1.

The first differing applicable comparison is local preference, so the longer path can win. Then deliberately remove its next-hop reachability and explain why eligibility changes the winner.

### Deny list does not create the expected deny

Synthetic: route-map deny sequence references a prefix list that denies the target prefix, followed by permit-all.

The referenced list does not match that route at the deny sequence, allowing evaluation to continue. Correct the matching logic and verify both the intended rejection and required accepted routes before deployment.

## Guided build and fault isolation

Build a two-upstream route-policy lab and track one prefix through received, accepted, best, installed and advertised states.

Hint: Identify the first differing applicable comparison rather than reciting the whole algorithm.

Instructor reasoning: The record must distinguish an attribute preference, an eligibility failure and a RIB-source conflict. Include exact prefix-length tests and a route-map control-flow case.

## Independent assignment

Author a prefix ownership allowlist for two services, implement inbound preference and outbound advertisement bounds, then diagnose one hidden route-map fall-through. Prove unauthorized prefixes stay absent at the peer after a scoped policy refresh.

## Verified primary references

- [NX-OS 10.3(x): Basic BGP selection](https://www.cisco.com/c/en/us/td/docs/dcn/nx-os/nexus9000/103x/unicast-routing-configuration/cisco-nexus-9000-series-nx-os-unicast-routing-configuration-guide-release-103x/m-n9k-configuring-basic-bgp-101x.html)
- [BGP-4 protocol, RFC 4271](https://www.rfc-editor.org/rfc/rfc4271.html)
- [BGP operational security, RFC 7454](https://www.rfc-editor.org/rfc/rfc7454.html)
- [NX-OS 10.3(x): route policy manager](https://www.cisco.com/c/en/us/td/docs/dcn/nx-os/nexus9000/103x/unicast-routing-configuration/cisco-nexus-9000-series-nx-os-unicast-routing-configuration-guide-release-103x/m_configuring_route_policy_manager.html)
