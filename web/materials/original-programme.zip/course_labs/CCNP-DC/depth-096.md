# Enhanced zoning transactions, smart zoning roles and safe fabric merges

### Separate policy, transaction mode and hardware realization

This chapter uses Cisco MDS NX-OS 9.x. Check the exact image, fabric interoperability and hardware limits before converting an existing fabric. The words 'enhanced' and 'smart' address different problems. Enhanced zoning coordinates changes through an explicit session and commit model. Smart zoning uses device roles to reduce unnecessary communication combinations in hardware. Neither is a synonym for array LUN masking, and neither removes the need for an approved initiator-to-target access policy.

Start with a communication matrix. Rows identify initiators; columns identify targets; each permitted pair has an owner and a storage purpose. Keep unrelated initiators and targets out of the same policy merely to reduce administrative work. If an array needs a special target-to-target exchange, represent that requirement explicitly. The correct policy comes before the choice of how to encode it.

A zone definition is part of the editable database. A zoneset groups zone definitions. The active zoneset is the selected policy enforced for a VSAN. The full database can contain inactive historical or proposed objects. A saved full database therefore is not evidence of the active policy, and the active policy alone is not a complete backup of all authored definitions. A troubleshooting transcript should show zone mode, pending session, full database, active zoneset and actual endpoint registration.

### Enhanced zoning as a controlled transaction

In enhanced mode, the first modifying operation opens a session and takes the relevant lock. Edits remain pending until committed or discarded. A zoneset activation request can itself be pending inside that session. An operator who sees the new zone in a pending difference must not tell the host team that access is already live. Commit applies the accepted change and closes the session; discard abandons the pending changes. Inspect the active database afterward because intent, commit outcome and device service still differ.

Locks prevent conflicting concurrent writers. They are not nuisance alarms to clear reflexively. If another operator owns a live session, coordinate with that operator. If a session is genuinely abandoned, retain its pending changes and ownership evidence, determine whether to discard or complete them, then use the documented recovery workflow. A forced commit can activate someone else's unfinished proposal. A forced discard can destroy legitimate work. Neither should be the default response to a busy fabric.

Fabric merges add another conflict surface. Two fabrics can contain objects with the same name but different membership. A union of names is not necessarily a valid union of policy. Compare active and full databases, alias definitions, modes and merge policy before joining an ISL. Restricted merge policy can intentionally reject nonidentical databases; permissive merge still has conflict rules. Never solve an unexplained isolated ISL by permitting every default-zone exchange.

### Smart zoning and role correctness

A traditional large zone can imply communication between every pair of its members. For an original four-member example with two initiators and two targets, there are six unordered pairs. Only four are initiator-target pairs; initiator-initiator and target-target communication may be unnecessary. Smart zoning can use roles to avoid programming those unnecessary combinations. This simple pair count illustrates policy reduction; it is not a vendor TCAM sizing formula. Actual entry consumption depends on implementation and membership details.

Role information can be learned from name-server registration or specified through supported configuration. An offline device or incomplete FC4 registration can leave its role unknown during conversion. Do not silently assume an unknown member is an initiator. Verify HBA/array documentation, registration and the approved matrix. A device acting as both initiator and target needs deliberate handling. Smart zoning's defaults can be overridden for a justified exception, but the exception should remain narrow and testable.

Conversion is a lifecycle operation. Capture the existing active policy and resource use, inspect device roles, generate the conversion, review errors and activate/commit according to the selected mode. Then test both permitted and prohibited pairs. A lower hardware resource count does not prove that every required pair still works. An apparently successful host scan does not prove target-to-target replication remains allowed.

### Construct an isolated enhanced-zoning change

Use VSAN 96 with one test initiator and one disposable target. Confirm default-zone policy, FLOGI and name-server registration. Choose a basic or already-enhanced starting mode explicitly. If enabling enhanced mode, review the whole fabric first; do not paste a mode conversion into an unrelated maintenance window. The following original unexecuted sequence assumes enhanced mode is already accepted and operational:

```text
zone name Z_LAB96 vsan 96
  member pwwn 20:00:00:00:00:00:00:96
  member pwwn 50:00:00:00:00:00:00:96
exit
zoneset name ZS_LAB96 vsan 96
  member Z_LAB96
exit
zoneset activate name ZS_LAB96 vsan 96
show zone pending-diff vsan 96
zone commit vsan 96
show zone status vsan 96
show zoneset active vsan 96
```

Review the pending difference before committing. Use exact release help for optional command qualifiers. Persist the full configuration and retain an external backup through the approved workflow. The published guide distinguishes active-zone persistence from saving the complete authored database, so record both recovery needs.

Next add a second initiator and target to a separate experimental zone. Build the desired pair matrix before enabling smart zoning. Use the supported conversion workflow, such as `zone convert smart-zoning zoneset name ZS_LAB96 vsan 96`, only after checking device roles and the intended policy; inspect conversion status and reactivate/commit as required. This command is an illustration of the conversion operation, not permission to convert a live fabric wholesale.

### Evidence that survives a failure

Inject an uncommitted activation, an incorrect WWPN and an unknown role as separate faults. The first is a transaction-state problem, the second an identity problem, and the third a policy-realization problem. They can all produce missing I/O but require different corrections. Include array masking and host multipath in final acceptance: zoning permits a fabric exchange but does not decide which logical unit the array exposes.

Rollback restores a known approved active zoneset with its referenced identities and required attributes. Reverting only a zone name while retaining altered members does not restore policy. Restore the corresponding array mapping only if it was part of the change; do not widen unrelated access. Verify path failover and data integrity on the disposable workload, then confirm the unrelated initiator remains denied. Record exactly which transaction was committed and which tests were actually observed.

## Worked cases

### Pending activation mistaken for service

Synthetic: pending-diff adds the test zone, while show zoneset active still shows the previous set. The host cannot see the target.

Inspect session ownership and approve the intended difference, commit through enhanced zoning, then verify active membership and the host path. Do not modify default-zone policy to bypass the uncommitted transaction.

### Resource optimization removes a required exchange

Synthetic: two targets support an approved replication path. Smart conversion removes their target-to-target combination.

The resource optimization must respect the explicit application matrix. Configure and test the narrow supported exception, preserving denial for unrelated members. Verify replication and failure recovery independently from an ordinary host LUN scan.

## Guided build and fault isolation

Build a pending enhanced-zoning change and prove the difference between full, pending and active databases. Then compare a four-member traditional policy with reviewed smart roles.

Hint: Write the required pair matrix before inspecting resource savings.

Instructor reasoning: The first test must show no new access before commit; the second must prove every authorized pair and at least one denied pair after conversion. Record role provenance and transaction ownership.

## Independent assignment

Merge two synthetic zoning inventories containing one same-name membership conflict. Produce a reconciled policy and rollback plan. In the vendor lab, use disposable VSANs and demonstrate successful commit, deliberate discard and a correctly preserved target replication exception.

## Verified primary references

- [MDS 9.x: Zones and enhanced/smart zoning](https://www.cisco.com/c/en/us/td/docs/dcn/mds9000/sw/9x/configuration/fabric/cisco-mds-9000-nx-os-fabric-configuration-guide-9x/configuring_and_managing_zones.html)
