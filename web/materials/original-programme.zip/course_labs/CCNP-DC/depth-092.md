# OSPF link-state databases, areas, flooding and route calculation

### An adjacency is only the first gate

Use Nexus 9000 NX-OS 10.3(x) for this implementation exercise. Verify the chosen image and interface capabilities before entering the illustrative commands. The earlier adjacency chapter established Hellos, MTU and neighbor states. This chapter follows the information that an established adjacency carries. OSPF distributes descriptions of topology and reachability, not a copy of each router's installed forwarding table. Routers in the same area synchronize their area-scoped link-state database and independently calculate routes. An area border router maintains separate area databases; it does not make every router in every area share one identical database.

A useful evidence record has five columns: received advertisement, advertisement age and origin, result of the OSPF calculation, selected route in the unicast RIB, and usable forwarding adjacency. A failure in any column can leave a neighbor Full while a workload remains unreachable. A static route with a preferred administrative distance can win the RIB even when the OSPF calculation is correct. Conversely, a selected OSPF route may recurse to an unresolved next hop. Never clear all neighbors merely because one destination fails.

### Reading the topology database

For OSPFv2, a type 1 router LSA describes the originating router's links inside one area. On a broadcast transit network, the designated router originates a type 2 network LSA representing the shared segment and attached routers. A point-to-point link does not need that pseudonode. The DR role reduces adjacency and flooding work; it does not require every ordinary data packet to pass through the DR. A router ID identifies an originator and must be unique. It need not be an address assigned to the interface carrying a particular workload.

A type 3 summary LSA advertises inter-area reachability from an ABR. Despite its name, it can describe a specific prefix; aggregation is a separate configuration choice. A type 4 LSA supplies inter-area reachability to an ASBR when needed for external-route calculation. A type 5 LSA advertises external reachability across the eligible OSPF domain. An NSSA uses type 7 advertisements internally and a suitable ABR translates eligible routes for the rest of the domain. These roles are OSPFv2 terminology; OSPFv3 changes LSA structure and encoding, so do not identify an OSPFv3 packet by memorizing only this v2 table.

An LSA instance is identified by its type, link-state ID and advertising router. Sequence, checksum and age help determine which instance is newer. Aging and refresh are necessary even without a user configuration change. A MaxAge flush withdraws an advertisement; it is not a request to prefer the oldest copy. During database exchange, summary headers identify missing or outdated entries, requests obtain the needed contents, and acknowledgments plus retransmissions support reliable flooding. Repeated retransmissions point toward loss, inconsistent state or overload; a stable Hello exchange does not establish that larger database packets survive.

### Areas, external paths and containment

Area design bounds database size and calculation work, but it also constrains information flow. A regular stub area excludes external type 5 advertisements and relies on an ABR-provided default for external destinations. It cannot contain an ordinary ASBR redistributing external routes. An NSSA permits local external injection through type 7 advertisements while keeping the external scope controlled. The NSSA translator, forwarding address and filtering policy matter when a route exists inside the NSSA but disappears beyond its ABR. An area-type mismatch can prevent adjacency before any of these route calculations occur.

Intra-area, inter-area and external paths have different selection rules. A low external metric is not permission to bypass the preferred path category. For external type 1, internal cost to the external path is added to the external metric. For external type 2, the external metric is normally the main comparison, with internal cost relevant to applicable tie decisions. Apply the exact RFC and implementation rules when multiple ASBRs or forwarding addresses are present. A calculation worksheet should identify route category before comparing numbers.

Summarization belongs at an information boundary. An ABR can announce a combined range toward another area while retaining details locally. That reduces remote state but may hide a failed component prefix while another component keeps the aggregate alive. Sending traffic for an unused part of the range toward the summary origin does not create a destination there. Validate discard behavior and prevent forwarding loops. A summary is neither an access-control list nor evidence that every address within its range is reachable.

### Construct a three-area evidence chain

Use four logical routers: CORE in area 0, BORDER joining areas 0 and 20, EDGE inside area 20, and EXIT joining area 0 to area 30. Initially make all areas normal. Give EDGE loopback 10.20.4.1/32 and EXIT loopback 10.30.9.1/32. Build one routed point-to-point link at a time, preserve console access, and record the source router ID for each advertisement. The following fragment is an original unexecuted NX-OS teaching example for BORDER; it is not a complete production configuration:

```text
feature ospf
router ospf CAMPUS
  router-id 192.0.2.20
interface Ethernet1/1
  no switchport
  ip address 192.0.2.0/31
  ip router ospf CAMPUS area 0.0.0.0
  ip ospf network point-to-point
  no shutdown
interface Ethernet1/2
  no switchport
  ip address 192.0.2.2/31
  ip router ospf CAMPUS area 0.0.0.20
  ip ospf network point-to-point
  no shutdown
```

Inspect `show ip ospf neighbors`, `show ip ospf database`, `show ip ospf route` and the destination in `show ip route`; confirm release-specific command options with local help. In CORE, predict an inter-area advertisement for EDGE's loopback rather than EDGE's area-20 router LSA. In BORDER, inspect both area databases. Then make area 20 stub consistently and compare the external database before and after. Use an approved static test prefix at EXIT and an explicit redistribution route map if adding external reachability; do not redistribute every connected interface casually.

For failure testing, remove only the loopback advertisement while keeping adjacencies intact, apply an ABR summary that conceals one component withdrawal, and introduce a preferred conflicting static route in a disposable VRF. For each experiment, predict which of the five evidence columns changes first. Restore the previous configuration and confirm route withdrawal and reinstallation as well as packet forwarding. The learning outcome is a causal explanation of a missing or misleading route, not a screenshot of Full neighbors.

## Worked cases

### Full neighbors, missing route

Synthetic: CORE has a Full neighbor to BORDER. BORDER sees EDGE type 1 in area 20; CORE lacks any type 3 for EDGE loopback.

Trace the loopback on EDGE, then BORDER area-20 database, then ABR range/filter policy and area-0 advertisement. The shared adjacency is not the failed dependency. Repair the narrow advertisement policy and verify the resulting RIB and packet path.

### Aggregate survives a component failure

Synthetic: a /16 aggregate covers two active /24s. One /24 fails and the /16 remains. Traffic to the failed /24 reaches the ABR and drops.

This is a visibility consequence of aggregation, not necessarily a protocol defect. Determine the required failure visibility, inspect discard behavior and decide whether more-specific advertisement or application routing is needed. Do not remove safe discard handling just to make a packet take another loop.

## Guided build and fault isolation

Build the four-router topology and produce a database-to-forwarding table for one internal and one external prefix. Then compare normal, stub and NSSA area 20.

Hint: Record the LSA originator and scope before explaining the route code.

Instructor reasoning: A normal area can carry eligible externals; a stub uses a default for those destinations; an NSSA permits local type 7 injection. Changes must be consistent, and each mode needs route and application tests.

## Independent assignment

Rebuild from an empty authorized lab, inject one area-type mismatch and one summary visibility fault separately, then combine a correct OSPF calculation with an incorrect preferred static route. Submit the command transcript and a five-column causal explanation for each fault.

## Verified primary references

- [NX-OS 10.3(x): OSPFv2](https://www.cisco.com/c/en/us/td/docs/dcn/nx-os/nexus9000/103x/unicast-routing-configuration/cisco-nexus-9000-series-nx-os-unicast-routing-configuration-guide-release-103x/m_configuring_ospfv2.html)
- [OSPFv2 protocol, RFC 2328](https://www.rfc-editor.org/rfc/rfc2328.html)
- [OSPF NSSA, RFC 3101](https://www.rfc-editor.org/rfc/rfc3101.html)
