# IGMP, MLD and snooping: receiver state, source filters and aging

### Membership is a dependency of multicast forwarding

Use the Nexus 9000 NX-OS 10.3(x) IGMP, MLD and snooping chapters for the stated laboratory baseline. Verify the exact switch family, ASIC resource requirements and feature interactions before implementation. The protocol reasoning below distinguishes a host's request, a bridge's replication list and a router's multicast forwarding state. They answer different questions. All configurations and observations supplied here are original teaching examples and have not been executed on Cisco equipment.

A receiver subscribes to a multicast application channel; a sender normally does not join the group merely to transmit to it. For IPv4, IGMP communicates local receiver interest. For IPv6, MLD performs the corresponding listener-discovery role using ICMPv6. Neither protocol independently creates a routed tree across the data center. PIM, a supported overlay multicast mechanism and the unicast information used for reverse-path checks provide other parts of that service.

Consider a receiver behind a virtual switch. Its application may request a group successfully at the socket layer, but the report can be blocked before the physical leaf. The leaf may learn membership but lack an upstream multicast route. Alternatively, the routed tree can be healthy while the bridge's receiver port has aged out. Trace these state boundaries separately, starting with the application source, destination group, address family, tenant and interface.

### Group-only and source-specific requests

IGMPv2 identifies a group without carrying the same source-filter expressiveness as IGMPv3. MLDv1 and MLDv2 have a similar generational distinction. A source-specific application identifies both a source S and a group G. Two streams to the same group from different sources are different channels. A receiver asking for one source should not be assumed to request every source using that destination address.

At the protocol model level, an INCLUDE list means interest in the listed sources; an EXCLUDE list means interest in sources other than those listed. For a host-level thought experiment, INCLUDE {A, B} accepts A and B, while EXCLUDE {B} accepts A but rejects B. INCLUDE with an empty list represents no requested source. EXCLUDE with an empty list represents interest from any source. These are filter semantics, not evidence that every platform implements every mode.

That distinction matters for the pinned NX-OS implementation: the cited IGMP guide explicitly lists exclusion or blocking of a source list as unsupported. Use a supported inclusion-based SSM design when that meets the requirement. Do not submit an EXCLUDE report and claim the switch enforces source denial just because IGMPv3 appears in a feature list. Where a security requirement prohibits a source, enforce and test an appropriate supported control at the relevant boundary; multicast membership is not authentication of the sender.

An older group-only receiver can require an explicitly designed SSM translation or proxy mechanism if it must consume an SSM service. Translation needs a trustworthy mapping from group to source. It cannot discover the intended publisher from the destination group alone when several publishers are possible. A stale static mapping can build a perfectly valid tree toward the wrong source.

### Snooping, the querier and the multicast router port

A Layer-2 switch ordinarily replicates multicast within a broadcast domain according to its forwarding policy. Snooping observes membership control traffic to constrain receiver-port replication. A multicast-router port has a different role from a receiver port: it leads toward a device participating in the routed multicast service. Losing that classification can interrupt report or data handling even while endpoint-facing membership entries appear correct.

Membership is soft state. Queries solicit reports, reports refresh state, and expiration removes interest that has not been refreshed. An initial unsolicited report can make a stream work temporarily in a VLAN with no active querier. When the membership expires, the result depends on the platform's unknown-multicast policy: loss or unwanted flooding are both possible service problems. Increasing an aging timer hides the missing refresh mechanism and makes stale membership persist longer.

For an isolated Layer-2 VLAN with sources and receivers but no multicast routing, configure a supported snooping querier. Give it a unique, valid address in the VLAN and verify actual queries on the wire. A snooping querier maintains membership discovery; it does not supply inter-VLAN routing, an RP or a tenant MVPN control plane. For a PIM-enabled SVI, use the routed interface's membership workflow and follow the documented guidance about avoiding a redundant VLAN-mode querier configuration.

### Leave processing and host aggregation

A Leave indicates that a host has stopped requesting a group, not necessarily that every host behind the port has left. Normal last-member processing checks for remaining listeners before pruning. Fast leave makes a stronger topology assumption and can immediately remove the port. A physical port connected to a hypervisor, access switch or wireless bridge can represent many receivers even if it has only one visible uplink cable.

For example, VMs A and B share Ethernet1/12 and both consume a group. A leaves. If the switch treats the port as a single receiver and prunes immediately, B loses traffic despite its continuing interest. Reducing the last-member query interval will not repair a mode that skips the query. Correct the mode and topology assumption, then verify B's stream while A repeatedly joins and leaves. Explicit host tracking and version-specific report behavior also matter; do not transfer the assumptions of one version to another without checking the implementation.

### Construct and observe two address-family experiments

First create an authorized, isolated IPv4 Layer-2 VLAN 103 with one sender and two receivers on separate ports. Supply the VLAN and access-port configuration from the preceding Layer-2 lessons. The following fragment adds a snooping querier, not a routed multicast service:

```text
vlan configuration 103
  ip igmp snooping querier 10.103.0.254
```

Verify `show ip igmp snooping groups` and `show ip igmp snooping querier`, together with packet captures of Queries and Reports. Run a known-rate stream, leave one receiver subscribed and unsubscribe the other. Record the receiver-port replication state and application sequence gaps. Then remove the querier in the isolated experiment and observe state aging rather than assuming immediate loss.

For a separate routed experiment, establish the PIM and RPF prerequisites from the multicast-routing chapter. On the receiver-facing SVI, `ip igmp version 3` selects the membership version used by the source-specific exercise. Compare the interface's membership state with `show ip mroute` for the exact source and group. Do not use `ip igmp join-group` as a casual high-rate traffic sink: the pinned guide describes CPU consumption. A documented `ip igmp static-oif` has a different hardware-forwarding purpose and still requires careful scope and verification.

For IPv6, use documentation-prefix source addressing and a valid multicast destination with the intended scope. Configure `ipv6 mld version 2` on the supported receiver-facing interface. Capture MLD reports and inspect `show ipv6 mld groups` and the IPv6 multicast route. MLD snooping is a separate feature with platform and resource prerequisites; validate those requirements before enabling it, including any required resource change or reload. An IPv4 snooping table cannot establish IPv6 listener state.

The final acceptance record includes the precise S/G request, membership refresh, receiver-port list, router-port state, routed outgoing-interface list where applicable, RPF result and application delivery. Negative tests should show that an unsubscribed port is not receiving ordinary application multicast and that a required source remains available after another receiver leaves. Preserve necessary link-local control traffic according to its special forwarding rules; a blanket rule for all multicast destinations can damage unrelated network control functions.

## Worked cases

### A join works until the state expires

Synthetic: one unsolicited IGMP report installs the receiver port at 10:00. No queries or later reports occur. The group entry disappears later and the application loses data.

Trace the missing refresh mechanism. Add a supported unique-address snooping querier for the isolated Layer-2 VLAN and verify queries, reports and continued state beyond the former expiry interval. Do not interpret a larger timer as a repaired control plane.

### A leave prunes another virtual machine

Synthetic: two VMs share one physical uplink. Both request G; only A leaves. Fast leave immediately removes the uplink and B loses sequence numbers.

The port is not a single receiver. Restore appropriate last-member processing or a supported explicitly tracked design. Repeat the transition while capturing B and an unsubscribed port. Verify the fix preserves selectivity rather than merely flooding the VLAN.

## Guided build and fault isolation

Build the isolated IPv4 querier experiment and a separate supported IPv6 listener experiment. Introduce a missing querier and a shared-port leave fault one at a time.

Hint: Follow application request, on-wire report, snooping receiver list and routed state as separate observations.

Instructor reasoning: A complete record identifies exactly which state stopped refreshing or which port was wrongly removed. It restores that mechanism and demonstrates receiver continuity and negative replication tests.

## Independent assignment

Produce a dual-stack multicast membership casebook with a two-host shared uplink, the exact S/G requests, timer observations and a source-support matrix. Include a conceptual EXCLUDE example explicitly distinguished from the pinned NX-OS limitation. Implement only supported mechanisms and document any resource/reload prerequisite before a device change.

## Verified primary references

- [NX-OS 10.3(x): IGMP](https://www.cisco.com/c/en/us/td/docs/dcn/nx-os/nexus9000/103x/configuration/multicast/cisco-nexus-9000-series-nx-os-multicast-routing-configuration-guide-release-103x/m_configuring_igmp.html)
- [NX-OS 10.3(x): MLD](https://www.cisco.com/c/en/us/td/docs/dcn/nx-os/nexus9000/103x/configuration/multicast/cisco-nexus-9000-series-nx-os-multicast-routing-configuration-guide-release-103x/m-configuring-mld.html)
- [NX-OS 10.3(x): IGMP snooping](https://www.cisco.com/c/en/us/td/docs/dcn/nx-os/nexus9000/103x/configuration/multicast/cisco-nexus-9000-series-nx-os-multicast-routing-configuration-guide-release-103x/m-configuring-igmp-snooping.html)
- [IETF RFC 3376: IGMPv3 protocol model](https://www.rfc-editor.org/rfc/rfc3376)
- [IETF RFC 3810: MLDv2 protocol model](https://www.rfc-editor.org/rfc/rfc3810)
