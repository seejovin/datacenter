# IC32: independent assessment record

## Scope and authorization
Product/version; isolated environment; permitted actions; safety owner; abort conditions.

## Requirement
Function, operating modes, limits, authority and recovery objectives.

## Model and implementation
Dependencies, boundary crossings, identities, configuration/logic baseline and proposed change.

## Test matrix
| Test | Preconditions | Stimulus | Expected observable result | Actual result | Evidence |
|---|---|---|---|---|---|
| Normal | | | | Not performed | |
| Denied action | | | | Not performed | |
| Degraded state | | | | Not performed | |
| Restart/recovery | | | | Not performed | |

## Trust and functional restoration
Recovery source provenance, removed authority, physical feedback, timing and alarm continuity.

## Acceptance and limitations
Independent reviewer; unresolved assumptions; measured versus simulated results; residual risk owner.
