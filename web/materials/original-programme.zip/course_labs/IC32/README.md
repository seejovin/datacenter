# IC32 — local engineering evidence laboratory

These standard-library Python models use supplied **synthetic data**. They do not
contact or configure equipment. Their outputs are analytical model results, not
physical measurements or vendor-platform acceptance.

## Teaching before execution

Study modules 1, 4, 5, 6 and 9. Explain first-match policy, linear scaling,
measurement quality/freshness and current-versus-historical authority before
running the tools. The code deliberately exposes the mechanism; memorizing CLI
syntax is not the assessment.

Run from this directory with Python 3.12 or another supported Python 3 version:

```bash
python lab.py policy
python lab.py points
python lab.py recovery
python lab.py self-test
```

## Demonstration and guided work

1. **Policy:** predict the matching rule for each flow. The broad first rule
   shadows the intended write denial. Copy `starter.json` to `candidate.json` and
   implement a narrow read permission. Preserve the required jump-host flow.
   Run `python lab.py policy --input candidate.json` and compare every required
   and observed action. A policy that denies everything does not satisfy the task.
2. **Measurement:** pressure_A yields 8 bar from its configured range, but the
   stated transmitter and independent reference imply 5 bar. The model marks it
   usable because all implemented checks pass; this is an intentional demonstration
   that a software good-quality flag does not establish physical correctness.
   Correct the mapping and document the missing metrology check. Pressure_B is
   stale; pressure_C has bad source quality. Do not clear quality flags merely to
   obtain green results.
3. **Recovery:** the backup revives `former_vendor` and omits the required recovery
   custodian. Reconcile to the current approved register, then rerun. Explain why
   a matching backup checksum cannot substitute for this authority review.

## Independent assessment

Submit your candidate fixture, predicted results, actual local outputs, a
requirement-to-test table and an explanation of each original failure. Add a
new flow that challenges rule order, a future timestamp that challenges clock
assumptions, and a restore that keeps ordinary operation working while reviving
an unwanted local identity. The cases must test different mechanisms.

Acceptance: all declared required flows work; prohibited flows fail; point
meaning, quality and age are correctly distinguished; current authority is
preserved; all model limitations are named. Do not edit the expected requirement
to match an incorrect result.

## Remaining practical gates

The simplified policy lacks CIDR, NAT, sessions, application parsing, failover and
vendor syntax. The point model lacks real sensor uncertainty, wiring and dynamics.
The recovery model does not inspect firmware, malware or an actual directory.
Keep vendor firewall commissioning, safe physical loop calibration, controller
restoration and supervised field authority as separate evidence requirements.
