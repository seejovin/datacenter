"""Safe local teaching models. Uses synthetic records; never opens a network socket."""
from __future__ import annotations
import argparse
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent

def first_match(rules, source, destination, service):
    for n, rule in enumerate(rules,1):
        if all(rule[field] in ('any', actual) for field,actual in [('source',source),('destination',destination),('service',service)]):
            return {'action':rule['action'],'rule':n}
    return {'action':'deny','rule':None}

def point_state(record):
    """Deliberately explicit units and quality. Not a device-driver implementation."""
    faults=[]
    span=record['current_max_mA']-record['current_min_mA']
    if span<=0: raise ValueError('Current span must be positive')
    age=record['received_at_s']-record['source_at_s']
    if age<0: faults.append('future_timestamp_or_clock_error')
    if age>record['max_age_s']: faults.append('stale')
    if record['source_quality']!='good': faults.append('source_quality_bad')
    if not record['current_min_mA']<=record['current_mA']<=record['current_max_mA']:
        faults.append('outside_declared_measurement_range')
    value=record['engineering_min']+(record['current_mA']-record['current_min_mA'])/span*(record['engineering_max']-record['engineering_min'])
    return {'id':record['id'],'value':value,'unit':record['unit'],'age_s':age,'usable':not faults,'faults':faults}

def recovered_authority(current, restored):
    # Current register, not the old backup, defines intended remaining authority.
    unexpected=sorted(set(restored['active_accounts'])-set(current['approved_accounts']))
    missing=sorted(set(current['required_accounts'])-set(restored['active_accounts']))
    revived=sorted(set(restored['active_accounts'])&set(current['revoked_accounts']))
    return {'unexpected':unexpected,'missing_required':missing,'revived_revoked':revived,'authority_gate_passes':not(unexpected or missing or revived)}

def self_test():
    assert first_match([{'source':'any','destination':'any','service':'any','action':'permit'},{'source':'collector','destination':'controller','service':'write','action':'deny'}],'collector','controller','write')=={'action':'permit','rule':1}
    assert first_match([],'collector','controller','write')['action']=='deny'
    case={'id':'P1','current_mA':10,'current_min_mA':4,'current_max_mA':20,'engineering_min':0,'engineering_max':80,'unit':'kPa','received_at_s':10,'source_at_s':8,'max_age_s':5,'source_quality':'good'}
    assert point_state(case)['value']==30
    assert point_state(case)['usable']
    assert not point_state(dict(case,source_at_s=2))['usable']
    assert 'future_timestamp_or_clock_error' in point_state(dict(case,source_at_s=11))['faults']
    assert not point_state(dict(case,source_quality='bad'))['usable']
    state=recovered_authority({'approved_accounts':['operator'],'required_accounts':['operator'],'revoked_accounts':['old_vendor']},{'active_accounts':['operator','old_vendor']})
    assert state['revived_revoked']==['old_vendor'] and not state['authority_gate_passes']
    return {'self_tests':'8 passed','environment':'synthetic local model; not measured device behaviour'}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('exercise',choices=['policy','points','recovery','self-test'])
    parser.add_argument('--input',type=Path,default=HERE/'starter.json')
    args=parser.parse_args()
    if args.exercise=='self-test': result=self_test()
    else:
        data=json.loads(args.input.read_text())
        if args.exercise=='policy':
            result=[dict(flow,observed=first_match(data['rules'],flow['source'],flow['destination'],flow['service'])) for flow in data['flow_tests']]
        elif args.exercise=='points':result=[point_state(point) for point in data['points']]
        else:result=recovered_authority(data['current_authority'],data['restored_authority'])
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
