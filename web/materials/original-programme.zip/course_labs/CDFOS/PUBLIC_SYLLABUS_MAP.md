# CDFOS public-syllabus teaching map

Checked against [EPI's public CDFOS outline](https://www.epi-ap.com/services/1/3/136) on 2026-09-19. The original course teaches and assesses all nine public process areas. It does not reproduce protected provider courseware or actual examination questions, and public-topic coverage does not guarantee an exam pass.

| Public process area | Chapter | Original mechanisms and case evidence |
|---|---|---|
| Service level management | 1 | Needs/catalogue/capability, service boundary, outage union, availability, reporting quality, complaints and measured improvement |
| Safety and crisis management | 2 | Hazard controls, competence, calibration, energy-state literacy, group/shift work, permits and crisis coordination |
| Physical security | 3 | Zones/access, receiving/custody, visitors/escorts, keys/credentials, CCTV provenance and patrol exceptions |
| Maintenance | 4 | Strategy, MOPs and restoration deadlines, service reports, spares, tools, housekeeping and CMMS event quality |
| Operations | 5 | Handover/overrides, operating checks, incident/problem/change distinctions, release recovery, baselines, rack admission and retirement |
| Monitoring | 6 | Point contracts, alarm delay/hysteresis, escalation clocks, measurement scaling, buffering/replay and analytics quality |
| Projects | 7 | Mandate, dependencies/critical path, risks/issues/changes, accepted progress, handover and benefit verification |
| Environmental sustainability | 8 | Energy/PUE aggregation, controlled trials, water balance, energy attributes, lifecycle and disposal evidence |
| Governance | 9 | Document authority/effective status/distribution/retention/recovery, stable asset identity and audit scope |

The public outline mentions six document-management subprocesses but does not publish their individual names. The chapter clearly labels its create/review/approve/issue/maintain/retire-retain model as original teaching terminology, not a reproduction of EPI's unpublished terms.

There are 50 objective/case IDs and 500 independently written decisions, with 12,006 words of explanatory teaching before worked examples and practice. Every objective is linked to a chapter and assessed. Length and quiz completion do not establish field competence. The bundled analytical calculator was executed on synthetic fixtures; actual vendor tools, permits, physical maintenance, commissioning and recovery remain separate evidence gates.
