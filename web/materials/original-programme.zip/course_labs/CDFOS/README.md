# CDFOS analytical operations practical

These supplied values are synthetic. This exercise uses Python's standard library and never connects to equipment. It checks arithmetic and evidence interpretation; it does not prove physical operation, switching competence or provider certification.

Read `fixture.json` before opening the calculator. Submit a JSON file using the keys shown by `lab.py` and explain every equation in your own calculation sheet. Calculate the union of overlapping service outages, include the contractually included planned interval, and distinguish the separate telemetry gap supported by independent service evidence. Compute weighted PUE, buffer backlog and net replay time, the dependency finish and the unexplained water balance.

Run `python course_labs/CDFOS/lab.py --submission path/to/your_results.json` from the application directory. Use `--self-check` to verify the provided calculator. Without arguments it shows the reference calculations; use that only after attempting the exercise.

Complete `assessment_template.md`. The numerical check cannot grade causal claims, work authority, procedure quality, environmental accounting boundaries or whether a field action was executed. A reviewer must assess those decisions against the supplied cases and the lesson criteria.

Then alter one input deliberately: make the replay write rate equal to arrivals. Explain why the backlog cannot drain and why a division error must not be reported as successful recovery. Restore the fixture afterward. Independently add an outage wholly inside an existing interval and demonstrate that service loss does not increase. These mutations test the model's boundary conditions rather than create extra practice-bank items.

For the remaining chapters, build the requested evidence packs using their cases: a safety/permit review, access/custody register, maintenance MOP and spares record, controlled release/retirement plan, monitoring point contract, project handover and document/asset register. Retain Siemens/Schneider controls and EPMS, Sunbird DCIM and the selected CMMS as external platform practice where the curriculum assigns them. Record platform/version, actual access, authorized environment and observed evidence; a synthetic worksheet is not a completed vendor or field practical.
