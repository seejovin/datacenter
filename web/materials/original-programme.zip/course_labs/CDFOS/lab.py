"""Read-only analytical check. Standard library; no network or plant access."""
import argparse,json,math
from pathlib import Path

def union_minutes(intervals):
    merged=[]
    for start,end in sorted(intervals):
        if end<start: raise ValueError('Interval end precedes start')
        if merged and start<=merged[-1][1]: merged[-1][1]=max(end,merged[-1][1])
        else: merged.append([start,end])
    return sum(b-a for a,b in merged)

def analyze(d):
    s=d['service'];lost=union_minutes(s['unplanned_intervals']+s['included_planned_intervals'])
    e=d['energy'];pue=sum(x['facility_mwh'] for x in e)/sum(x['it_mwh'] for x in e)
    b=d['buffer'];backlog=b['arrivals_per_second']*60*b['outage_minutes'];net=b['recovery_write_rate']-b['arrivals_per_second']
    if net<=0: raise ValueError('Replay never drains while new records arrive at this rate')
    finishes={}
    for t in d['project']:
        if any(p not in finishes for p in t['after']): raise ValueError('Project must be topologically ordered')
        finishes[t['id']]=max([finishes[p] for p in t['after']] or [0])+t['duration']
    w=d['water']
    return {'service_lost_minutes':lost,'availability_percent':100*(1-lost/s['period_minutes']),'two_month_pue':pue,'backlog_records':backlog,'buffer_spare_records':b['capacity_records']-backlog,'net_drain_records_per_second':net,'replay_minutes':backlog/net/60,'project_finish_days':max(finishes.values()),'water_unexplained_liters':w['inlet_liters']-w['documented_uses_liters']-w['storage_increase_liters']}

def check(actual,expected):
    for k,v in expected.items():
        if k not in actual or not isinstance(actual[k],(int,float)) or not math.isclose(actual[k],v,rel_tol=1e-6,abs_tol=1e-6):
            raise ValueError(f'{k}: expected {v}; received {actual.get(k)!r}')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--submission',type=Path);p.add_argument('--self-check',action='store_true');a=p.parse_args()
    result=analyze(json.loads(Path(__file__).with_name('fixture.json').read_text()))
    if a.self_check:
        check(result,{'service_lost_minutes':70,'availability_percent':99.83796296296296,'two_month_pue':5/3,'backlog_records':9600,'buffer_spare_records':400,'net_drain_records_per_second':2,'replay_minutes':80,'project_finish_days':11,'water_unexplained_liters':1000})
        assert union_minutes([[1,4],[2,3],[4,6],[8,9]])==6
        print('Synthetic numerical checks passed; no physical capability was tested.')
    elif a.submission:
        check(json.loads(a.submission.read_text()),result);print('Numerical submission passed. A reviewer must still assess interpretation and operational decisions.')
    else: print(json.dumps(result,indent=2))
