# Original learner submission

## Calculations
For each result: source fields, units, equation, result, rounding and interpretation.

## Decisions
1. Explain why the monitoring gap does not automatically add downtime here, and what evidence would change the conclusion.
2. State exactly what the two-month PUE proves and cannot prove.
3. Explain why replay speed must exceed new arrivals and why historical recovery does not establish fresh live values.
4. Identify the project critical path and the assumptions omitted from a live cutover promise.
5. List alternative explanations for the water balance; do not invent a leak location.
6. Identify the role authorized to accept each decision and the escalation when evidence is missing.

## Operations evidence packs
Attach the chapter-specific independent-task deliverables. Name every synthetic record and every genuinely executed activity separately. Map each acceptance criterion to evidence, gap, owner and next action.

## Practical fidelity
State what was calculated, simulated, executed in a vendor tool or observed physically. Record reviewer feedback and unresolved external gates.
