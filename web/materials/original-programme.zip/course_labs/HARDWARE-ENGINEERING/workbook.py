"""Offline analytical checker. No network, system inventory, device writes or hardware control."""
import argparse,json,math,pathlib,sys
HERE=pathlib.Path(__file__).resolve().parent

def expected(d):
    a=d['architecture'];m=a['memory'];p=a['pcie'];r=d['installation'];s=d['storage'];h=d['supporting_service'];t=d['commissioning'];o=d['operations'];x=d['recovery']
    bound=p['gt_s']*p['lanes']*p['encoding_payload_bits']/p['encoding_total_bits']/8
    rates=[(b['count']-a['count'])*60/(b['minute']-a['minute']) for a,b in zip(o['ecc_samples'],o['ecc_samples'][1:])]
    lat=sorted(t['latency_ms']);p95=lat[math.ceil(.95*len(lat))-1]
    def mirror_survives(failed):return all(any(member not in failed for member in group) for group in s['mirror_groups'])
    return {
      'memory_a_installed_gib':m['sockets']*m['a_dimms_per_socket']*m['a_dimm_gib'],
      'memory_b_installed_gib':m['sockets']*m['b_dimms_per_socket']*m['b_dimm_gib'],
      'memory_a_transfer_s':m['transfer_gb']/m['a_measured_gb_s'],
      'memory_b_transfer_s':m['transfer_gb']/m['b_measured_gb_s'],
      'pcie_pre_protocol_bound_gb_s':bound,'pcie_transfer_lower_bound_s':p['transfer_gb']/bound,
      'adapter_failure_requirement_met':len({v['adapter'] for v in a['adapter_proposal']['paths']})>1,
      'rack_surviving_demand_kw':r['nodes']*r['node_input_kw'],
      'rack_surviving_capacity_met':r['nodes']*r['node_input_kw']<=r['surviving_feed_limit_kw'],
      'firmware_decision':'hold','redfish_operation_complete':False,'management_identity_reconciled':False,
      'raid6_capacity_tb':(s['active_drives']-2)*s['drive_tb'],
      'raid6_additional_member_tolerance':2-s['failed_active_members'],
      'raid10_set1_survives':mirror_survives(s['failure_set_1']),'raid10_set2_survives':mirror_survives(s['failure_set_2']),
      'filesystem_primary_constraint':'inodes','path_timing_requirement_met':s['path_failure_interruption_s']<=s['allowed_interruption_s'],
      'host_memory_shortfall_gib':max(0,h['guests']*h['guest_memory_gib']+h['host_services_gib']-h['host_usable_gib']),
      'service_primary_fault':'stale_dns','required_database_recovery_point_evidenced':False,
      'latency_mean_ms':sum(lat)/len(lat),'latency_p95_ms':p95,'latency_requirement_met':p95<=t['required_p95_ms'],
      'mean_inflight_requests':t['stable_interval']['completion_rate_s']*t['stable_interval']['mean_time_s'],
      'thermal_leading_hypothesis':'airflow_thermal_limit','ecc_first_rate_h':rates[0],'ecc_second_rate_h':rates[1],
      'reset_interval_rate_valid':False,'spare_route_hours':o['spare_access_h']+o['spare_install_validate_h'],
      'spare_target_met':o['spare_access_h']+o['spare_install_validate_h']<=o['restoration_target_h'],
      'drive_removal_decision':'hold_wrong_target','nic_post_repair_missing':'authorized_wwn_mapping','memory_repair_accepted':False,
      'service_recovery_minutes':x['required_function_and_access_min'],'rto_met':x['required_function_and_access_min']<=x['rto_min'],
      'independent_key_recovery_ready':False,'rollback_without_reconciliation_accepted':False,
      'migration_overlap_kw':x['migration']['old_kw']+x['migration']['new_kw'],
      'migration_overlap_met':x['migration']['old_kw']+x['migration']['new_kw']<=x['migration']['temporary_limit_kw'],
      'sanitization_release_decision':'hold','custody_state_accurate':False,'physical_requirement_closed_by_fixture':False
    }

def check(submission,reference):
    issues=[]
    if not isinstance(submission,dict):return ['Submission must be a JSON object.']
    missing=reference.keys()-submission.keys();extra=submission.keys()-reference.keys()
    issues.extend('Missing: '+k for k in sorted(missing));issues.extend('Unknown: '+k for k in sorted(extra))
    for k,want in reference.items():
      if k not in submission:continue
      got=submission[k]
      if isinstance(want,bool):ok=type(got) is bool and got==want
      elif isinstance(want,(int,float)):ok=type(got) in (int,float) and math.isfinite(got) and math.isclose(got,want,rel_tol=.005,abs_tol=1e-8)
      else:ok=isinstance(got,str) and got==want
      if not ok:issues.append(k+': incorrect value or type')
    return issues

def main():
    ap=argparse.ArgumentParser(description=__doc__);g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--template',action='store_true');g.add_argument('--solution',action='store_true');g.add_argument('--check',type=pathlib.Path)
    args=ap.parse_args();ref=expected(json.loads((HERE/'cases.json').read_text()))
    if args.template:print(json.dumps({k:None for k in ref},indent=2));return 0
    if args.solution:print(json.dumps(ref,indent=2));return 0
    try:issues=check(json.loads(args.check.read_text()),ref)
    except (OSError,ValueError) as e:print('Cannot read valid submission:',e);return 2
    print(json.dumps({'passed':not issues,'checks':len(ref),'issues':issues,'scope':'Synthetic analytical answers only; no physical competence claim'},indent=2));return int(bool(issues))
if __name__=='__main__':sys.exit(main())
