# Hardware engineering practical work

These are original synthetic training cases mapped to the ten mandatory HW outcomes in Curriculum Rev14 §09.2. The workbook reads supplied data only. The recovery exercise executes actual file and SQLite operations exclusively in a new temporary directory. Neither script discovers, connects to, resets or sanitizes equipment.

Run from the repository root with Python 3.10 or later; only the standard library is required:

```bash
python course_labs/HARDWARE-ENGINEERING/workbook.py --template
python course_labs/HARDWARE-ENGINEERING/workbook.py --check my-hardware-answers.json
python course_labs/HARDWARE-ENGINEERING/workbook.py --solution
python course_labs/HARDWARE-ENGINEERING/recovery_lab.py
```

Copy `answers-template.json` to a separate answer file. Read `cases.json`, calculate each numeric answer and supply the decision keys described below. Do the work before viewing `--solution`. The checker enforces every key, actual JSON booleans, finite numbers and a 0.5% numeric tolerance. Passing it demonstrates the supplied analytical decisions; it does not validate the physical system or close an external practical gate.

Decision strings are deliberately explicit: firmware `hold`; filesystem `inodes`; service `stale_dns`; thermal `airflow_thermal_limit`; drive removal `hold_wrong_target`; NIC repair `authorized_wwn_mapping`; sanitization `hold`. Explain each decision in the evidence sheet with its supporting observation and a discriminating next test. Exact-string marking is an arithmetic/decision aid; it does not independently grade the quality of your engineering explanation.

## Work through the lifecycle

| Outcome | Lessons | Supplied analytical work | Required independent/physical evidence |
|---|---|---|---|
| HW-01 | L01–L03 | Compare equal-capacity DIMM populations; calculate transfer times and a qualified PCIe ceiling; reject shared-adapter resilience claim | Conventional and accelerated BOMs, supported compatibility matrix, installed inventory reconciliation, accepted/rejected alternatives |
| HW-02 | L04–L05 | Receiving/rail/damage holds, surviving-feed calculation, destination and liquid-interface readiness | Actual approved server/storage installation, handling/rail review, serial-linked rack/cable/power records, photos and handover tests |
| HW-03 | L06–L07 | Unsupported firmware/driver pairing and rollback; Redfish accepted vs completed state; stale status and serial mismatch | Baseline versions/settings, restricted OOB, approved media boot, supported update and applicable recovery-path test; unsupported rollback recorded |
| HW-04 | L08–L10 | RAID6 usable capacity/remaining tolerance, RAID10 failure placement, inode exhaustion and failed timing target | Supported storage configuration with synthetic data, integrity/performance, safe drive/path failure, replacement/rebuild and independent restoration |
| HW-05 | L11–L12 | Failover memory shortfall, stale DNS and missing recovery logs | Reproducible supporting host/service baseline, effective permissions, functional recovery after host loss and evidence rejecting an incorrect hardware diagnosis |
| HW-06 | L13–L14 | Mean vs nearest-rank p95, Little's Law boundary, correlated thermal diagnosis | Bounded supported diagnostic/load test with predeclared limits, safe introduced fault, raw observations and retest |
| HW-07 | L15–L16 | ECC rate change/reset discontinuity and spare route exceeding restoration target | Dated operating record, normal checks, deterioration/diagnosis, reviewed change, post-change verification, physical/management reconciliation and recurrence plan |
| HW-08 | L17–L18 | Wrong member removal, new WWN authorization and insufficient memory after repair | Actual authorized FRU replacement, restored health/function/protection, old/new identities and records; inaccessible component classes remain open |
| HW-09 | L19–L20 | Functional RTO vs OS boot, inaccessible decryption key, stale rollback and migration overlap demand | Node/service rebuild from approved sources, unavailable-dependency test, revised recovery plan, restored data/function and administrative authority |
| HW-10 | L21–L22 | Incomplete quick-format certificate, active BMC account and false disposed status | Supported sanitization on sacrificial media with synthetic data, prescribed checks, identity/configuration removal and custody/disposition evidence |

The abbreviated lesson numbers belong to `HARDWARE-ENGINEERING-Lxx`. The full textbook chapters supply mechanisms, worked examples, guided practice and individual assessment briefs. A shared case file lets you compare the same system across lifecycle stages; it is not a substitute for those lessons.

## Local recovery demonstration

`recovery_lab.py` creates its own temporary directory and synthetic text/configuration files, preserves a SHA-256 reference manifest, creates backup copies, deliberately corrupts one newly created file, detects the mismatch and restores it. It then creates a three-record SQLite database, uses SQLite's backup API, removes only its own disposable primary database, restores the backup, runs `PRAGMA integrity_check` and queries the expected application records. It prints results and removes the temporary workspace when it ends.

Inspect the source first. Run it and explain why each observation is needed:

1. A mismatch against an independent manifest detects the deliberately altered file. Two hashes of the same damaged copy would not establish correctness.
2. A matching restored hash proves the exercised file bytes match that retained reference.
3. SQLite structural integrity and expected record queries test different claims.
4. This uses a local file copy in one temporary storage environment. It is not independent-site backup, physical-drive failure, database crash testing, PostgreSQL point-in-time recovery, Hyper-V/AD recovery or device sanitization.

For the independent variation, make a reviewed copy of this script in a disposable work area, change the synthetic dataset and preserve an independent expected record set. Add a second safe fault such as an omitted synthetic record in the restored application query. Show that the content check detects it even if structural integrity passes. Do not modify the exercise to accept arbitrary device paths or required data.

## Construct the equipment-specific method

For the real work, first select the actual available model and obtain its current installation, firmware, storage, diagnostic and FRU procedures. A reference to an illustrative Dell manual is not a procedure for another model. Capture the exact document revision and relevant section in `evidence-template.json`. Confirm authorization, supervisor/observer where needed, service ownership, maintenance state, supported parts and safe stop/hold conditions.

Use a test record containing:

- Required function and precise pass/fail criterion before execution.
- Physical serial/slot/bay and the matching BMC/OS identity.
- Supported hardware, firmware/driver and configuration baseline.
- Workload, duration, sample interval, environment and measurement units.
- Remaining redundancy and recovery route during the operation.
- Raw before/fault/corrected/retest evidence with timestamps and collection context.
- Alternative diagnosis and the observation that distinguishes it.
- Final accepted/held requirement, temporary-access removal and recurrence owner.

On a suitable authorized Linux lab, read-only observations may include `lscpu`, `numactl --hardware`, `lspci -tv`, `lspci -vv`, `lsblk`, `ip address` and `ip route`. Tool availability, permissions and meanings vary; follow the selected distribution/OEM guidance. Windows and hypervisor environments require their equivalent supported procedures. Do not paste credentials or confidential identifiers into a shared evidence pack. Redfish practice begins with supplied responses and authorized read-only discovery; the workbook sends no HTTP requests.

The physical assessment must retain an observed installation and FRU replacement, appropriate firmware/recovery work, supported storage fault/rebuild/restoration, bounded diagnostics and sacrificial-media sanitization. Planning, passing the questions or running these offline scripts does not close those requirements. A rejected unsafe or incompatible proposal should be explained on paper; do not execute the rejected action to demonstrate that it is wrong.
