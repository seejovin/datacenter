"""Executed local synthetic data recovery in a new temporary directory.
Touches only files it creates. No hardware access, network, credentials or sanitization.
"""
import hashlib,json,pathlib,shutil,sqlite3,tempfile

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def run():
    with tempfile.TemporaryDirectory(prefix='dc_hw_recovery_') as tmp:
        root=pathlib.Path(tmp);primary=root/'primary';backup=root/'backup';primary.mkdir();backup.mkdir()
        payloads={'inventory.txt':'SYNTHETIC S101: approved host\n','config.json':json.dumps({'service':'synthetic-monitor','expected_records':3},sort_keys=True)}
        for name,data in payloads.items():(primary/name).write_text(data)
        manifest={name:digest(primary/name) for name in payloads}
        for name in payloads:shutil.copy2(primary/name,backup/name)
        (primary/'inventory.txt').write_text('SYNTHETIC CORRUPTED CONTENT\n')
        corruption_detected=digest(primary/'inventory.txt')!=manifest['inventory.txt']
        shutil.copy2(backup/'inventory.txt',primary/'inventory.txt')
        files_restored=all(digest(primary/name)==value for name,value in manifest.items())
        db=primary/'metrics.sqlite';db_backup=backup/'metrics.sqlite'
        with sqlite3.connect(db) as con:
            con.execute('CREATE TABLE readings (id INTEGER PRIMARY KEY, sensor TEXT NOT NULL, value REAL NOT NULL)')
            con.executemany('INSERT INTO readings VALUES (?,?,?)',[(1,'SYNTHETIC-INLET',24.0),(2,'SYNTHETIC-POWER',1200.0),(3,'SYNTHETIC-LATENCY',8.0)])
            con.commit()
            with sqlite3.connect(db_backup) as dst:con.backup(dst)
        db.unlink()  # Deliberate loss of only this newly-created disposable database.
        shutil.copy2(db_backup,db)
        with sqlite3.connect(db) as con:
            integrity=con.execute('PRAGMA integrity_check').fetchone()[0]
            readings=con.execute('SELECT id,sensor,value FROM readings ORDER BY id').fetchall()
        expected=[(1,'SYNTHETIC-INLET',24.0),(2,'SYNTHETIC-POWER',1200.0),(3,'SYNTHETIC-LATENCY',8.0)]
        result={'synthetic_file_corruption_detected':corruption_detected,'file_hashes_restored':files_restored,'sqlite_integrity_check':integrity,'application_records_restored':readings==expected,'record_count':len(readings),'scope':'Actual local file/SQLite operations on new synthetic temporary data. Not a physical-media, PostgreSQL/AD/Hyper-V, crash-consistency or sanitization test.'}
        if not(corruption_detected and files_restored and integrity=='ok' and readings==expected):raise RuntimeError(result)
        return result
if __name__=='__main__':print(json.dumps(run(),indent=2))
