# CDCP integrated facility review

This is a synthetic analytical proposal, deliberately containing multiple independent defects. No values are field measurements.

Work from `proposal.json` and complete `answers-template.json` under a new name. In a separate decision memo:

1. Merge overlapping service outages before calculating availability. Compare the specific recovery event with RTO; an aggregate availability figure does not waive RTO.
2. Calculate rack current after one feed is lost. Identify the exact supplied limit that passes or fails. Do not infer conductor or protection selection from the calculation.
3. Evaluate the one-unit-unavailable cooling state using sensible capacity. Explain what delivery and shared-control evidence remains outside the arithmetic.
4. Compute the microgrid duration while preserving the stated reserve. Discuss losses and source firmness omitted from the simplified model.
5. Complete the optical budget including required margin. Keep receiver overload and polarity as separate acceptance items.
6. Calculate simple payback and explain at least three limitations of using it as the sole financial decision.
7. Check source-data freshness, not display refresh. Describe the operational consequence of a stale normal-looking value.
8. Find shared dependencies in both nominally separate paths. Explain why different suppliers or UPS labels do not establish independence.
9. Review the three evidence claims. Identify the claim that promotes a simulation into production evidence and rewrite it accurately.
10. Decide `accept`, `hold`, or `reject_as_stated`. Explain why known mandatory failures differ from missing evidence, and propose a revised requirement or design only through explicit accountable review.

Run `python review.py --check your-answers.json`. Numerical answers permit 0.5% relative tolerance; booleans and evidence classifications must be exact. Run `python review.py --demo` only after the independent attempt.

Submit calculations, a dependency diagram and a decision memo. The checker evaluates analytical outputs only. A passing file does not approve a real facility or establish hands-on competence. Physical installation, electrical protection, fire systems, structural interfaces and real operations require the applicable qualified work and separate evidence.
