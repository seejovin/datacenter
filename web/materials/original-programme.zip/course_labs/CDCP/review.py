"""Compute a synthetic facility proposal review. No equipment interaction."""
import argparse,json,math,pathlib
HERE=pathlib.Path(__file__).resolve().parent

def union_minutes(intervals):
    merged=[]
    for start,end in sorted(intervals):
        if start<0 or end<start:raise ValueError('Invalid outage interval')
        if merged and start<=merged[-1][1]:merged[-1][1]=max(end,merged[-1][1])
        else:merged.append([start,end])
    return sum(b-a for a,b in merged)

def solve(d):
    s=d['service'];r=d['rack'];k=d['cooling'];m=d['microgrid'];o=d['optical'];e=d['economics'];t=d['telemetry'];p=d['paths']
    down=union_minutes(s['outages']);current=r['server_count']*r['watts_per_server']/(r['single_phase_voltage']*r['power_factor'])
    margin=(k['units']-k['unavailable'])*k['unit_sensible_kw']-k['required_kw']
    return {'service_downtime_minutes':down,'availability_percent':100*(s['scheduled_minutes']-down)/s['scheduled_minutes'],
    'rto_pass':s['observed_recovery_minutes']<=s['rto_minutes'],'surviving_feed_current_a':current,'surviving_feed_pass':current<=r['surviving_feed_limit_a'],
    'cooling_failure_margin_kw':margin,'cooling_failure_state_pass':margin>=0,
    'microgrid_reserve_limited_hours':(m['usable_storage_kwh']-m['reserved_storage_kwh'])/(m['critical_kw']-m['firm_generation_kw']),
    'optical_margin_after_reserve_db':o['tx_min_dbm']-o['rx_sensitivity_dbm']-o['path_loss_db']-o['required_margin_db'],
    'simple_payback_years':e['incremental_cost']/e['annual_net_saving'],
    'telemetry_fresh':t['display_time_s']-t['source_time_s']<=t['maximum_age_s'],
    'shared_power_dependencies':sorted(set(p['power_A'])&set(p['power_B'])),
    'shared_network_dependencies':sorted(set(p['network_A'])&set(p['network_B'])),
    'overclaimed_evidence_ids':['EV-01'],'proposal_decision':'reject_as_stated'}

def check(expected,actual):
    errors=[]
    if not isinstance(actual,dict):return ['Submission must be a JSON object']
    if set(actual)!=set(expected):errors.append('Keys must match answers-template.json exactly')
    for key,target in expected.items():
        value=actual.get(key)
        if isinstance(target,bool):ok=type(value) is bool and value is target
        elif isinstance(target,(str,list)):ok=value==target and type(value) is type(target)
        else:ok=type(value) in (int,float) and math.isfinite(value) and math.isclose(value,target,rel_tol=.005,abs_tol=.001)
        if not ok:errors.append(key+': revise calculation or evidence classification')
    return errors

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--demo',action='store_true');parser.add_argument('--check',type=pathlib.Path);args=parser.parse_args()
    expected=solve(json.loads((HERE/'proposal.json').read_text()))
    if args.demo:print(json.dumps({'evidence_type':'computed synthetic reference','answers':expected},indent=2));return
    if args.check:
        errors=check(expected,json.loads(args.check.read_text()));print(json.dumps({'analytical_check_pass':not errors,'errors':errors,'claim_limit':'No physical performance, field authorization or provider certification is established.'},indent=2));raise SystemExit(bool(errors))
    print('Read README.md and proposal.json; independently complete answers-template.json and a decision memo. Use --check FILE, then --demo if needed.')
if __name__=='__main__':main()
