# CDCP authored coverage and evidence limits

Public scope checked: EPI CDCP course page, 19 September 2026. This is original instruction organized against the public course subjects, not a reproduction of paid provider material or actual exam questions.

| Published subject group | Authored chapters |
|---|---|
| Mission-critical service and business context | 1 |
| Standards and applicability | 2 |
| Site, building and supporting spaces | 3 |
| Raised floors and ceilings | 4 |
| Normal and emergency lighting | 5 |
| Power, microgrids, transfer, UPS and storage | 6–10 |
| Electromagnetic fields | 11 |
| Racks and high-density interfaces | 12 |
| Cooling, humidity, air delivery and liquid systems | 13–16 |
| Water and seasonal thermal storage | 17 |
| Scalable cabling and verification | 18–19 |
| Fire prevention, detection and suppression | 20 |
| Physical security and safety | 21 |
| Monitoring, leak detection and notification | 22 |
| Efficiency and lifecycle integration | 23–25 |

Targeted outline review added enclosure ingress-rating interpretation, thermographic limitations, EMF quantities and units, and jurisdiction-aware fire classification. Exact national requirements, current copyrighted standards tables, OEM selection curves and installation authority remain requirements to obtain from the applicable primary source and qualified discipline. The course does not invent universal electrical derating, fire-agent concentration, environmental limits or structural approval.

The course contains 25 chapters and 500 individually authored questions with option-specific reasoning, worked examples, guided exercises, independent analytical tasks and recall cards. The integrated offline proposal includes deliberately failing current, cooling, optical and recovery constraints, shared dependencies and an overclaimed evidence category. The standard-library checker was executed against known calculations and interval-union cases.

All lab fixtures are synthetic and all computed outputs are analytical. Physical commissioning, operating authority and provider certification require their own evidence and process. The bank has not been psychometrically calibrated or certified by EPI/EXIN as examination-equivalent. Current provider teaching and examination requirements remain part of the overall study programme.

D1 material is interface and examination literacy only, consistent with the charter's exclusion of owned civil/structural/architectural engineering. Detailed power and cooling engineering remains the later D2/D3 development horizon; near-term responsibility is informed integration with qualified specialist interfaces.
