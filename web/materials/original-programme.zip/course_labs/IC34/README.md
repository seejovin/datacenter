# IC34 integrated secure-design laboratory

Build and verify a constrained engineering policy for a synthetic cooling-control cell. The exercise connects requirements, segmentation, protocol authorization, remote identity, certificate trust, retained session state, telemetry freshness and independent approval. Complete the lessons first, then produce the design evidence before consulting `solution.json`.

This laboratory runs with Python 3.10 or later and the standard library. It opens no network sockets and contacts no devices. Supplied identities, certificate facts, time, source quality and approval records are trusted input facts in this model. A passing result establishes that the selected model satisfies the authored fixtures; it does not establish actual device capability, cryptographic validity, process safety or ISA/IEC 62443 conformance.

## System and requirements

The supervisory historian **H** and engineering service **E** communicate through gateway **G**. G maps Modbus unit identifier 1 to cooling controller A and identifier 2 to controller B. The application policy below concerns A only. These register offsets and temperatures are invented for the exercise; they are not a vendor register map or a safe operating recommendation.

| Requirement | Exact decision required |
|---|---|
| Reader H | Permit function 3 reads whose entire zero-based offset range lies within 100–101, to G/unit 1. Deny writes and all other offsets or units. |
| Engineer E | Permit function 6, offset 110, G/unit 1, raw unsigned 16-bit value 180–350 inclusive. The supplied scale is 0.1°C per raw unit. Function 16 remains unauthorized even if its values appear acceptable. |
| Command context | E must have an enabled, unexpired identity, an open maintenance window, trusted time and a command age from 0 to 5 seconds inclusive. Future-dated and stale commands are denied. Identity expiry is exclusive: `now == expires` is denied. |
| Replay | Require increasing command-envelope sequence numbers for the same authenticated identity and session. An exact repetition is denied. |
| Existing transport state | Revocation must take effect before the model's established-flow permit. An existing flow does not preserve revoked authority. New H→G TCP/502 is allowed; reverse initiation is denied. |
| Supplied peer evidence | Require a valid chain and matching private-key evidence, root `SiteRootA`, SAN `g.ot.example`, `serverAuth`, current validity, no revocation and available status evidence. An unverified status is denied for this particular maintenance service. |
| Telemetry | Retain source quality and source timestamp. Non-good quality or a future timestamp is invalid. A good sample is current through age 2 seconds inclusive; older data is stale. Arrival at the broker must not refresh source age. |
| Artifact approval | Bind approval to actor, target, artifact identifier and the half-open interval `[starts, expires)`. Requester and approver must be different people, not merely different account names. |

`starter.json` contains deliberate design weaknesses. `solution.json` implements the requirements for this model. The checker's cases include legitimate operations as well as narrowly targeted violations; a blanket deny policy does not satisfy the required positive cases.

## Run and retain your evidence

Run these commands from the repository root. Use `python3` or your environment's Python executable.

```bash
cp course_labs/IC34/starter.json course_labs/IC34/my_policy.json
python3 course_labs/IC34/check.py course_labs/IC34/my_policy.json --report course_labs/IC34/my_initial_report.json
```

The starter intentionally returns a nonzero exit code. Read each failed requirement and locate the enforcing branch in `design_engine.py`. Before changing a setting, write the requirement identifier, observed incorrect behavior, proposed correction and adjacent positive case that must continue working. Edit only your policy copy. Then run:

```bash
python3 course_labs/IC34/check.py course_labs/IC34/my_policy.json --report course_labs/IC34/my_final_report.json
python3 course_labs/IC34/check.py --self-test
```

Compare with the reference only after recording your decisions:

```bash
python3 course_labs/IC34/check.py course_labs/IC34/solution.json --report course_labs/IC34/reference_report.json
```

The report stores actual and expected decisions. Preserve the initial report, corrected policy, final report and explanation of each change. Do not present a report generated against `solution.json` as evidence that you independently designed the solution.

## Understand the mechanisms

**Framing and full operation checks.** `decode_requests` accepts hexadecimal chunks from an already ordered byte stream. It validates the Modbus application header, protocol identifier, length, function-specific fields, read counts, multi-write byte counts and complete register spans. It reconstructs one request split across chunks and separates multiple requests in a chunk. It bounds the exercise to 64 chunks, 4,096 bytes and 32 requests. It does not implement packet capture, TCP sequence reconstruction, retransmission handling or a production industrial parser. The checker exercises a permitted read followed by a forbidden write in one stream and a permitted write split across chunks.

For a read beginning at offset 101 with count 2, the final address is `101 + 2 - 1 = 102`; it exceeds H's authority even though its first address is allowed. A value of 351 means 35.1°C under this case's map and exceeds E's upper bound. These are different conditions and deserve separate negative tests. A function-16 operation is rejected by the operation allowlist before one attempts to treat it as an equivalent function-6 write.

**Identity and replay.** The sequence number in the exercise is supplied by a hypothetical authenticated command envelope maintained by a trusted intermediary. It is not a native Modbus transaction identifier and is not proof that ordinary Modbus provides cryptographic anti-replay. A deployable design must establish authentication, sequence persistence, restart behavior, trust protection and receiver enforcement. In particular, recreating an in-memory session must not silently allow an old command to acquire new authority. Describe this persistence gap in your design review rather than claiming that this small in-memory model resolves it.

**Transport versus application state.** `firewall_decision` is a deliberately small first-match model, not Linux connection tracking. It represents why a broad established-flow decision can precede and mask a revocation decision. Real firewall identity-to-flow binding, supported session termination, cluster state synchronization and failover require platform-specific verification. The transport permit to G does not prove that a write is authorized by the application model.

**Peer and time evidence.** `peer_evidence_decision` consumes supplied Boolean chain and key facts; it does not parse ASN.1, validate signatures, perform a TLS handshake, consult CRLs/OCSP or protect private keys. Those mechanisms are taught in lesson 10 and require supported independent implementation exercises. Denial when status is unavailable is a case-specific choice for maintenance admission; a different operational dependency needs its own reviewed failure requirement. All laboratory timestamps are numerical seconds on one declared synthetic timeline. There is no implicit real-world clock synchronization.

**Broker recovery.** The auxiliary `queue_result` function uses message rates and a fixed service rate. During a 60-second burst with arrival 150 messages/s and service 100 messages/s, backlog grows to 3,000 messages. With normal arrival 50 messages/s, only 50 messages/s of spare service remains and drain takes 60 seconds. If arrival equals service after the burst, backlog cannot drain. This simplified calculation does not model variable sizes, disk limits or service jitter; include those in a real capacity specification.

## Independent engineering package

Use `design_record.md` as your working record and submit these linked artifacts as the laboratory's practical result:

1. A zone and conduit drawing with every routed, bridged, maintenance, management and out-of-band path. State which component enforces each decision and which inputs it must trust.
2. A requirements table mapping each row above to a policy field, positive fixture, negative fixture and retained result. Distinguish modeled decisions from actual implementation evidence still required.
3. An authorization table for H, E and G, including unit, function, full offset range, representation, time boundary and failure response. Explain why address-only or TCP-port-only rules are insufficient.
4. A revocation and recovery sequence that covers new sessions, existing sessions, a restarted intermediary and an unavailable identity or time service. Identify the maintained state required outside this exercise.
5. A certificate lifecycle plan covering enrollment, server name, trust distribution, expiry, replacement, root overlap, revocation status and tested restoration of embedded clients.
6. Paired factory/site acceptance procedures. Record artifact versions, exact allowed and denied behavior, observation points, uncertainty, stop conditions, local recovery and the evidence that must be repeated after a site configuration change.
7. A cutover plan with a measured rollback decision deadline, approved local operating arrangements and restoration verification. A simulated permit/deny result is not evidence that the physical process remained within its operating envelope.

For each artifact, include facts, assumptions, unknowns and the responsible decision owner. A complete answer must preserve required service and deny nearby prohibited operations, explain the causal mechanism, and identify what cannot be established by this offline model.

## Extension tasks

Work in a copy of the laboratory for these exercises so the reference remains reproducible.

- Add a test for a valid command followed by the same command after session-state loss. Explain why replay protection needs persistent or otherwise securely re-established state; propose a design and a negative test without claiming native Modbus authenticity.
- Add a read that ends exactly at 101 and one ending at 102. Keep source, role, unit and other conditions identical so only range enforcement changes.
- Add a certificate evidence case with an unknown root and a correct DNS name. Explain why name matching cannot establish trust, and identify what an actual chain validator must do.
- Add one site acceptance test where an old authentic sample is republished at a new receipt time. Require the client to display stale source data even though the broker connection is healthy.
- Calculate and document a recovery timeline with a backlog, ongoing arrival, identity restoration and an approval expiring during recovery. State which steps are serial and which may overlap before adding durations.

The repository includes the executed reference report and the source of the 12 self-tests. No vendor command or network action is executed by this lab. Platform-specific labs elsewhere in the course are explicit supported-environment tasks; their synthetic command examples are not claimed as executed evidence.

## Primary references

The synthetic register map and authorization policy are original exercise requirements. Protocol field interpretation was checked against the Modbus Organization's [application protocol V1.1b3](https://www.modbus.org/file/secure/modbusprotocolspecification.pdf) and [TCP/IP messaging implementation guide V1.0b](https://www.modbus.org/file/secure/messagingimplementationguide.pdf). Engineering context comes from [NIST SP 800-82 Revision 3](https://csrc.nist.gov/pubs/sp/800/82/r3/final) and [NIST SP 800-160 Volume 1 Revision 1](https://csrc.nist.gov/pubs/sp/800/160/v1/r1/final). This laboratory is original supplementary preparation aligned to the [public IC34 course scope](https://www.isa.org/training/course-description/ic34).
