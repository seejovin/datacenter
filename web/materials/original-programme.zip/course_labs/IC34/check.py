#!/usr/bin/env python3
"""Exercise synthetic IC34 policy against authored positive/negative requirements."""
import argparse
import copy
import json
from pathlib import Path
import unittest
from design_engine import (FrameError, SessionState, decode_requests, encode_request,
    authorize_request, firewall_decision, peer_evidence_decision, telemetry_quality,
    approve_download, queue_result)
ROOT=Path(__file__).resolve().parent


def context(role='Engineer',**overrides):
    value={'identity':{'id':'E' if role=='Engineer' else 'H','role':role,'enabled':True,'expires':200},
           'revoked':False,'now':100,'issued_at':98,'window_open':True,'time_trusted':True,
           'target':'G','session_id':'s1','command_sequence':1}
    value.update(overrides)
    return value


def evaluate(policy):
    results=[]
    def record(name,actual,expected):
        results.append({'test':name,'passed':actual==expected,'actual':actual,'expected':expected})
    def operation(name,request,ctx,wanted):
        op=decode_requests([request])[0]
        got,_=authorize_request(policy,op,ctx,SessionState())
        record(name,got,wanted)
    operation('H required two-register read',encode_request(3),context('Reader'),True)
    operation('H forbidden single-register write',encode_request(6,100,2),context('Reader'),False)
    operation('H read below first allowed register',encode_request(3,99,1),context('Reader'),False)
    operation('H forbidden multiwrite within allowed read span',encode_request(16,100,values=[300,301]),context('Reader'),False)
    operation('H read crossing final allowed register',encode_request(3,101,2),context('Reader'),False)
    operation('E required in-range write',encode_request(6,110,300),context(),True)
    operation('E inclusive lower boundary',encode_request(6,110,180),context(),True)
    operation('E inclusive upper boundary',encode_request(6,110,350),context(),True)
    operation('E value below approved bound',encode_request(6,110,179),context(),False)
    operation('E value above approved bound',encode_request(6,110,351),context(),False)
    operation('E wrong downstream unit',encode_request(6,110,300,unit=2),context(),False)
    operation('E register below approved offset',encode_request(6,109,300),context(),False)
    operation('E adjacent forbidden register',encode_request(6,111,300),context(),False)
    operation('E unapproved function with otherwise valid offset and value',encode_request(16,110,values=[300]),context(),False)
    operation('E unapproved composite write',encode_request(16,110,values=[300,301]),context(),False)
    operation('E exact five-second age',encode_request(6,110,300),context(issued_at=95),True)
    operation('E stale command',encode_request(6,110,300),context(issued_at=94),False)
    operation('E future-dated command',encode_request(6,110,300),context(issued_at=101),False)
    operation('E untrusted time',encode_request(6,110,300),context(time_trusted=False),False)
    operation('E closed maintenance window',encode_request(6,110,300),context(window_open=False),False)
    operation('E revoked application session',encode_request(6,110,300),context(revoked=True),False)
    expired=context();expired['identity']['expires']=100
    operation('E identity expiry exact boundary',encode_request(6,110,300),expired,False)
    operation('Unsupported write-capable function',encode_request(22,110,300),context(),False)
    state=SessionState();op=decode_requests([encode_request(6,110,300)])[0]
    first=authorize_request(policy,op,context(),state)[0]
    second=authorize_request(policy,op,context(),state)[0]
    record('Trusted command-envelope replay rejected',[first,second],[True,False])
    joined=encode_request(3)+encode_request(6,100,2,transaction=2)
    decisions=[authorize_request(policy,op,context('Reader'),SessionState())[0] for op in decode_requests([joined])]
    record('Coalesced read plus forbidden write',[*decisions],[True,False])
    one=encode_request(6,110,300)
    split=decode_requests([one[:10],one[10:]])
    record('Segmented permitted request reassembled',authorize_request(policy,split[0],context(),SessionState())[0],True)
    for name,packet,wanted in [
      ('Existing revoked transport flow',{'source':'H','destination':'G','port':502,'state':'established','revoked_identity':True},'deny'),
      ('New approved transport flow',{'source':'H','destination':'G','port':502,'state':'new','revoked_identity':False},'allow'),
      ('Unapproved reverse initiation',{'source':'G','destination':'H','port':502,'state':'new','revoked_identity':False},'deny')]:
        record(name,firewall_decision(policy,packet),wanted)
    peer={'chain_valid':True,'key_matches':True,'root':'SiteRootA','sans':['g.ot.example'],
          'purpose':'serverAuth','not_before':0,'not_after':200,'now':100,'revoked':False,'status_available':True}
    record('Supplied trusted peer facts',peer_evidence_decision(policy,peer),True)
    variants=[('Wrong peer name',{'sans':['g-backup.ot.example']}),('Wrong peer root',{'root':'CorpRootB'}),
      ('Wrong certificate purpose',{'purpose':'clientAuth'}),('Mismatched private key evidence',{'key_matches':False}),
      ('Expired certificate evidence',{'not_after':99}),('Revoked certificate evidence',{'revoked':True}),
      ('Unknown revocation evidence',{'status_available':False})]
    for name,change in variants:
        record(name,peer_evidence_decision(policy,{**peer,**change}),False)
    sample={'source_quality':'good','source_time':99,'received_at':100}
    record('Current good telemetry',telemetry_quality(policy,sample,100),'good')
    record('Telemetry inclusive two-second age boundary',telemetry_quality(policy,{**sample,'source_time':98},100),'good')
    record('Old authentic telemetry',telemetry_quality(policy,{**sample,'source_time':97},100),'stale')
    record('Bad quality fresh telemetry',telemetry_quality(policy,{**sample,'source_quality':'bad'},100),'invalid')
    record('Future source timestamp',telemetry_quality(policy,{**sample,'source_time':102},100),'invalid')
    approval={'actor':'V','target':'G','artifact':'h7','starts':80,'expires':120,'requester_person':'P1','approver_person':'P2'}
    request={'actor':'V','target':'G','artifact':'h7','now':100}
    record('Scoped independent approval',approve_download(policy,approval,request),True)
    record('Same person through two accounts',approve_download(policy,{**approval,'approver_person':'P1'},request),False)
    record('Wrong artifact approval',approve_download(policy,approval,{**request,'artifact':'h8'}),False)
    record('Approval exact expiry',approve_download(policy,approval,{**request,'now':120}),False)
    return results


def selftest():
    class EngineTests(unittest.TestCase):
        def test_solution_meets_requirements(self):
            results=evaluate(json.loads((ROOT/'solution.json').read_text()))
            self.assertEqual([r['test'] for r in results if not r['passed']],[])
        def test_starter_reveals_multiple_gaps(self):
            results=evaluate(json.loads((ROOT/'starter.json').read_text()))
            self.assertGreaterEqual(sum(not r['passed'] for r in results),12)
        def test_multiple_requests(self): self.assertEqual(len(decode_requests([encode_request(3)+encode_request(6,110,300)])),2)
        def test_split_request(self):
            h=encode_request(3)
            self.assertEqual(decode_requests([h[:8],h[8:]])[0]['count'],2)
        def test_incomplete_request(self):
            with self.assertRaises(FrameError): decode_requests([encode_request(3)[:-2]])
        def test_invalid_protocol(self):
            h=bytearray.fromhex(encode_request(3));h[3]=1
            with self.assertRaises(FrameError): decode_requests([h.hex()])
        def test_inconsistent_multiwrite_count(self):
            h=bytearray.fromhex(encode_request(16,110,values=[300,301]));h[12]=2
            with self.assertRaises(FrameError): decode_requests([h.hex()])
        def test_address_overflow(self):
            with self.assertRaises(FrameError): decode_requests([encode_request(3,65535,2)])
        def test_bounded_stream(self):
            with self.assertRaises(FrameError): decode_requests(['00'*4097])
        def test_queue_net_drain(self): self.assertEqual(queue_result(150,100,60,50),{'backlog_messages':3000,'drain_seconds':60.0})
        def test_queue_cannot_drain(self): self.assertIsNone(queue_result(150,100,60,100)['drain_seconds'])
        def test_negative_queue_rate(self):
            with self.assertRaises(ValueError): queue_result(-1,100,60,50)
    run=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(EngineTests))
    return 0 if run.wasSuccessful() else 1


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('policy',nargs='?')
    parser.add_argument('--self-test',action='store_true')
    parser.add_argument('--report',help='Optional local JSON result artifact')
    args=parser.parse_args()
    if args.self_test: return selftest()
    if not args.policy: parser.error('Provide a policy JSON or --self-test')
    policy=json.loads(Path(args.policy).read_text())
    results=evaluate(policy)
    print('SYNTHETIC OFFLINE DESIGN VERIFICATION — no network, TLS handshake or device was used.')
    for r in results:
        print(('PASS' if r['passed'] else 'FAIL')+': '+r['test'])
    report={'fidelity':'synthetic analytical model','tests':results,'passed':sum(r['passed'] for r in results),'total':len(results)}
    if args.report: Path(args.report).write_text(json.dumps(report,indent=2)+'\n')
    print(f"{report['passed']}/{report['total']} requirements fixtures passed.")
    print('This is not a production parser, cryptographic validator, safety test or conformance certification.')
    return 0 if all(r['passed'] for r in results) else 1

if __name__=='__main__': raise SystemExit(main())
