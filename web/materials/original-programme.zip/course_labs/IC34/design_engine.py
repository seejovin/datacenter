"""Original offline IC34 design model; never opens a network connection.

Inputs are synthetic decoded identities, peer evidence and ordered TCP-stream
bytes. This is NOT a production firewall, TLS validator, TCP stack or safety gate.
"""
from dataclasses import dataclass, field
from datetime import datetime
import struct

class FrameError(ValueError):
    pass


def decode_requests(chunks):
    """Decode bounded, already ordered Modbus-TCP request bytes, not raw packets."""
    if not isinstance(chunks, list) or len(chunks) > 64:
        raise FrameError('Expected at most 64 ordered stream chunks')
    try:
        stream = b''.join(bytes.fromhex(x) for x in chunks)
    except (ValueError, TypeError) as exc:
        raise FrameError('Chunks must be hexadecimal byte strings') from exc
    if len(stream) > 4096:
        raise FrameError('Synthetic stream exceeds the 4096-byte exercise bound')
    out, pos = [], 0
    while pos < len(stream):
        if len(stream) - pos < 7:
            raise FrameError('Incomplete MBAP header')
        transaction, protocol, length = struct.unpack('!HHH', stream[pos:pos+6])
        if protocol != 0 or not 2 <= length <= 254:
            raise FrameError('Unsupported protocol ID or invalid MBAP length')
        end = pos + 6 + length
        if end > len(stream):
            raise FrameError('Incomplete application request')
        unit, pdu = stream[pos+6], stream[pos+7:end]
        function = pdu[0]
        op = {'transaction':transaction, 'unit':unit, 'function':function}
        if function in (3, 6):
            if len(pdu) != 5:
                raise FrameError('Function 3/6 requires the exact request length')
            address, value = struct.unpack('!HH', pdu[1:])
            op['start'] = address
            if function == 3:
                if not 1 <= value <= 125 or address + value - 1 > 65535:
                    raise FrameError('Invalid read count or register span')
                op.update(count=value, values=[])
            else:
                op.update(count=1, values=[value])
        elif function == 16:
            if len(pdu) < 6:
                raise FrameError('Incomplete multiple-register write')
            address, count = struct.unpack('!HH', pdu[1:5])
            byte_count = pdu[5]
            if not 1 <= count <= 123 or byte_count != 2*count or len(pdu) != 6+byte_count:
                raise FrameError('Write count, byte count and payload length disagree')
            if address + count - 1 > 65535:
                raise FrameError('Register span exceeds address range')
            values = list(struct.unpack('!' + 'H'*count, pdu[6:]))
            op.update(start=address, count=count, values=values)
        else:
            # Unknown functions are never made valid by pretending they are reads.
            op.update(start=None, count=None, values=[])
        out.append(op)
        if len(out) > 32:
            raise FrameError('Too many requests for the exercise bound')
        pos = end
    return out


def encode_request(function, start=100, value=2, unit=1, transaction=1, values=None):
    """Build synthetic fixture bytes, not send a request."""
    if function in (3,6):
        pdu=bytes([function])+struct.pack('!HH',start,value)
    elif function==16:
        values=values if values is not None else [300,999]
        pdu=bytes([16])+struct.pack('!HHB',start,len(values),len(values)*2)+struct.pack('!'+'H'*len(values),*values)
    elif function==22:
        # Syntactically complete mask write: AND=0, OR=value. Still unauthorized.
        pdu=bytes([22])+struct.pack('!HHH',start,0,value)
    else:
        pdu=bytes([function])+b'\x00\x00\x00\x00'
    return (struct.pack('!HHHB',transaction,0,len(pdu)+1,unit)+pdu).hex()


@dataclass
class SessionState:
    last_command_sequence: dict = field(default_factory=dict)


def authorize_request(policy, op, context, state):
    """Evaluate the declared synthetic requirements, returning a reason code."""
    identity=context['identity']
    if not identity['enabled'] or context['revoked']:
        return False,'identity_disabled_or_revoked'
    if context['now'] >= identity['expires']:
        return False,'identity_expired'
    if context['target'] != policy['target'] or op['unit'] not in policy['allowed_units']:
        return False,'wrong_target_or_unit'
    if op['start'] is None:
        return False,'unsupported_function'
    if identity['role']=='Reader':
        if op['function'] not in policy['reader_functions']:
            return False,'reader_function'
        end=op['start']+op['count']-1
        if op['start'] < policy['reader_start'] or end > policy['reader_end']:
            return False,'reader_register_range'
    elif identity['role']=='Engineer':
        if not context['window_open']:
            return False,'maintenance_window_closed'
        if op['function'] not in policy['engineer_functions']:
            return False,'engineer_function'
        end=op['start']+op['count']-1
        if op['start'] < policy['engineer_start'] or end > policy['engineer_end']:
            return False,'engineer_register_range'
        if any(v < policy['minimum_raw'] or v > policy['maximum_raw'] for v in op['values']):
            return False,'engineering_value_range'
        if not context['time_trusted'] and policy['reject_untrusted_command_time']:
            return False,'untrusted_command_time'
        age=context['now']-context['issued_at']
        if age < -policy['future_tolerance_seconds'] or age > policy['max_command_age_seconds']:
            return False,'command_freshness'
        if policy['require_sequence_progress']:
            key=(identity['id'],context['session_id'])
            if context['command_sequence'] <= state.last_command_sequence.get(key,0):
                return False,'replayed_command_envelope'
            state.last_command_sequence[key]=context['command_sequence']
    else:
        return False,'unlisted_role'
    return True,'allowed'


def firewall_decision(policy, packet):
    """Tiny first-match state model; does not implement Linux conntrack."""
    if policy['revocation_before_established'] and packet['revoked_identity']:
        return 'deny'
    if packet['state']=='established':
        return 'allow'
    if packet['revoked_identity']:
        return 'deny'
    permitted=(packet['source']=='H' and packet['destination']=='G' and packet['port']==502)
    return 'allow' if permitted else 'deny'


def peer_evidence_decision(policy, evidence):
    """Evaluate supplied facts only; no ASN.1, signatures or TLS are processed."""
    if not evidence['chain_valid'] or not evidence['key_matches']:
        return False
    if evidence['root'] not in policy['trusted_roots']:
        return False
    if policy['check_peer_name'] and policy['expected_peer_name'] not in evidence['sans']:
        return False
    if policy['check_peer_purpose'] and evidence['purpose']!='serverAuth':
        return False
    if not evidence['not_before'] <= evidence['now'] <= evidence['not_after']:
        return False
    if evidence['revoked']:
        return False
    if not evidence['status_available'] and policy['reject_unknown_peer_status']:
        return False
    return True


def telemetry_quality(policy, sample, now):
    if sample['source_quality']!='good':
        return 'invalid'
    source_time=sample['received_at'] if policy['replace_source_time'] else sample['source_time']
    age=now-source_time
    if age < 0:
        return 'invalid'
    return 'good' if age <= policy['max_telemetry_age_seconds'] else 'stale'


def approve_download(policy, approval, request):
    if request['actor'] != approval['actor'] or request['target'] != approval['target'] or request['artifact'] != approval['artifact']:
        return False
    if not approval['starts'] <= request['now'] < approval['expires']:
        return False
    if policy['require_independent_approver'] and approval['requester_person']==approval['approver_person']:
        return False
    return True


def queue_result(arrival, service, burst_seconds, normal_arrival):
    if min(arrival,service,burst_seconds,normal_arrival)<0:
        raise ValueError('Rates and duration must be nonnegative')
    backlog=max(0,(arrival-service)*burst_seconds)
    spare=service-normal_arrival
    drain=0 if backlog==0 else None if spare<=0 else backlog/spare
    return {'backlog_messages':backlog,'drain_seconds':drain}
