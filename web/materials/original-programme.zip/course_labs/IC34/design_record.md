# IC34 learner design record

Author: 

Case version: 

Policy file and digest: 

Initial report: 

Final report: 

Use this record with `README.md`. Retain the initial decisions before consulting the reference policy. All observations here concern the synthetic offline model unless an independently authorized external exercise is explicitly identified.

## Requirement and mechanism trace

| ID | Required property | Enforcing model function/field | Initial defect and evidence | Corrected policy | Positive fixture | Isolated negative fixture | Remaining implementation gap |
|---|---|---|---|---|---|---|---|
| R1 | H read scope: G/unit 1/function 3/offsets 100–101 | | | | | | |
| R2 | E command: G/unit 1/function 6/offset 110/raw 180–350 | | | | | | |
| R3 | Current authority, approved window, trusted age 0–5 seconds | | | | | | |
| R4 | Repeated authenticated command envelope denied | | | | | | |
| R5 | Existing transport authority does not survive required revocation | | | | | | |
| R6 | Peer trust, name, purpose, key, time and status | | | | | | |
| R7 | Source quality and source age preserved through republishing | | | | | | |
| R8 | Approval binds person, actor, target, artifact and interval | | | | | | |

## One targeted negative-test design

- Requirement and expected failure:
- Fully authorized baseline:
- Exactly one input condition changed:
- Why the chosen observation proves the relevant condition was enforced:
- Other possible rejection causes that must remain valid:
- Recovery/positive test after rejection:
- Evidence file and result:

## One interacting-state test design

- Initial identity, application session, transport state and time evidence:
- First event:
- State that should change:
- State that may remain cached:
- Second event or fault:
- Required operation decision and deadline:
- Observation points and timestamp uncertainty:
- Recovery behavior and retained authority checks:

## Trust and dependency review

| Supplied trusted fact | Real producer or authority needed | How integrity/freshness would be established | Failure response | Independent evidence still required |
|---|---|---|---|---|
| Authenticated identity and role | | | | |
| Command issue time | | | | |
| Command-envelope sequence and restart state | | | | |
| Certificate chain/key facts | | | | |
| Revocation status | | | | |
| Source telemetry quality/time | | | | |
| Approval-person identity | | | | |

## Factory-to-site evidence transfer

- Tested software/configuration and immutable identifiers:
- Which laboratory assumptions differ at the site:
- Path and identity mappings requiring site verification:
- Factory tests that can be reused, with justification:
- Tests that must be repeated after site changes:
- Safe stop condition and responsible person:
- Supported restoration sequence:
- Acceptance authority and unresolved exception disposition:

## Cutover timing

- Operating window:
- Recovery duration and basis:
- Verification duration and basis:
- Contingency allowance:
- Latest rollback decision time:
- Planned tasks, serial dependencies and permissible overlaps:
- Observation that requires rollback or a separately approved alternate disposition:
- Evidence proving old authority was removed after successful transfer:

## Evidence boundary

State precisely what your final report proves. Then list the platform, cryptographic, safety and licensed-standard questions it cannot answer. A passing reference policy, a vendor product name and a course score must not be substituted for those missing results.
