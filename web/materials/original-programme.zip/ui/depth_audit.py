"""Current authored inventory, source traceability and practical limits."""
from pathlib import Path
import streamlit as st
from core.academy import CREDENTIAL_IDS, course_rows, provider_rows, rows_csv
from ui.academy import open_course

ROOT = Path(__file__).resolve().parents[1]


def render_depth_audit(courses):
    st.subheader("Course depth and scope")
    st.write("Inspect the actual modules, chapters, assessments and source mappings. Counts describe the material supplied; they do not establish exam readiness or practical competence.")
    rows = course_rows(courses)
    st.dataframe(rows, hide_index=True, width="stretch")
    st.download_button("Download course inventory", rows_csv(rows), "course-inventory.csv", "text/csv")
    by_id = {c["id"]: c for c in courses}
    if not by_id:
        return
    cid = st.selectbox("Inspect a course", list(by_id), key="depth_course")
    course = by_id[cid]
    a, b, c = st.columns(3)
    a.metric("Teaching chapters", len(course["lessons"]))
    b.metric("Original questions", len(course["questions"]))
    c.metric("Bank requirement", "1,000" if cid == "CCNP-DC" else "500" if cid in CREDENTIAL_IDS else "Engineering extension")
    bp = course["blueprint"]
    st.markdown(f"[{bp['title']}]({bp['url']}) · {bp['version']} · checked {bp['checked_on']}")
    st.write(bp["scope_note"])
    for item in bp["limitations"]:
        st.info(item)
    st.button("Open course teaching and practice", on_click=open_course, args=(cid,), type="primary")
    published = provider_rows(course)
    if published:
        with st.expander("Published scope records"):
            st.dataframe(published, hide_index=True, width="stretch")
    st.markdown("**Authored module structure**")
    st.dataframe([{"Module": m["id"], "Title": m["title"], "Chapters": len(m["lesson_ids"]),
                   "Questions": sum(q["module_id"] == m["id"] for q in course["questions"])}
                  for m in course["modules"]], hide_index=True, width="stretch")
    st.markdown("**External completion requirements**")
    for item in course["external_requirements"]:
        st.markdown("- " + item)
    st.caption("The previous overview prototype is retained under Learn for orientation and progress compatibility. Its completion records remain separate from course checkpoints.")
