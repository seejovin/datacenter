"""Full-course reading, practice, diagnostics and portable recall."""
from __future__ import annotations

import uuid
from pathlib import Path
import streamlit as st

from core.academy import (assessment_rows, chapter_status, course_rows,
                          learning_units, provider_rows, question_index, rows_csv, select_questions)
from core.engine import anki_package, flashcard_export, mark_complete

ROOT = Path(__file__).resolve().parents[1]


def open_course(course_id, chapter_id=None):
    st.session_state["page"] = "Courses"
    st.session_state["academy_course"] = course_id
    st.session_state["academy_view"] = "Study"
    if chapter_id:
        st.session_state["academy_chapter_target"] = chapter_id


def open_flashcards(course_id, chapter_id=None):
    st.session_state.update(page="Flashcards", card_collection="Courses",
                            card_cert=course_id, card_domain="All subjects",
                            card_depth="All levels", card_completed=False,
                            review_early=False, card_revealed=False,
                            card_chapter_target=chapter_id or "All chapters")
    st.session_state.pop("card_filter", None)


def _start_practice(course_id, ids, key, label):
    st.session_state["academy_practice_" + course_id] = {"ids": ids, "key": key, "label": label}


def _end_practice(course_id):
    active = st.session_state.pop("academy_practice_" + course_id, None)
    if active:
        st.session_state.pop(active["key"] + "_result", None)
        st.session_state.pop(active["key"] + "_attempt", None)


def _chapter(course, lesson, progress, update, render_assessment, questions):
    lid = lesson["id"]
    objectives = {o["id"]: o for o in course["objectives"]}
    st.subheader(lesson["title"])
    st.caption(f"{lid} · {lesson['minutes']} estimated study minutes before independent work")
    with st.expander("Learning objectives and prerequisites"):
        for oid in lesson["objective_ids"]:
            st.markdown(f"- **{oid}:** {objectives[oid]['text']}")
        missing = [p for p in lesson["prerequisites"] if p not in progress["completed"]]
        if missing:
            st.write("Recommended first: " + ", ".join(missing))
        st.caption("You can read any chapter. A chapter checkpoint also requires its prerequisite checkpoints.")
    tabs = st.tabs(["Learn", "Worked demonstrations", "Guided practice", "Chapter questions", "Independent task", "Sources & recall"])
    with tabs[0]:
        st.markdown(lesson["body"])
    with tabs[1]:
        for example in lesson["worked_examples"]:
            st.markdown("### " + example["title"])
            st.markdown(example["scenario"])
            st.markdown("**Reason through the evidence**")
            st.markdown(example["solution"])
    with tabs[2]:
        practice = lesson["guided_practice"]
        st.markdown(practice["prompt"])
        st.text_area("Work your answer before opening the solution", key=f"academy_notes_{lid}", height=180,
                     help="Session scratchpad. Save important reasoning in your own notes or the evidence notebook.")
        with st.expander("Hint"):
            st.markdown(practice["hint"])
        with st.expander("Worked solution"):
            st.markdown(practice["solution"])
    with tabs[3]:
        pool = [questions[q["id"]] for q in course["questions"] if lid in q["lesson_ids"]]
        status = chapter_status(course, lid, progress)
        st.caption(f"{status['answered']} / {status['questions']} distinct questions attempted · "
                   f"{status['accuracy']:.0f}% correct on latest answers")
        if pool:
            batches = (len(pool) + 19) // 20
            batch = st.selectbox("Question set", range(1, batches + 1),
                                 format_func=lambda n: f"Set {n} of {batches}", key=f"academy_batch_{lid}")
            render_assessment(pool[(batch-1)*20:batch*20], f"academy_chapter_{lid}_{batch}", "course_chapter")
        reviewed = st.checkbox("I studied the chapter and worked the demonstrations and guided practice.", key=f"academy_read_{lid}")
        missing = set(lesson["prerequisites"]) - set(progress["completed"])
        if lid in progress["completed"]:
            st.success("Chapter study checkpoint recorded.")
        elif st.button("Complete chapter checkpoint", key=f"academy_complete_{lid}", type="primary",
                       disabled=not (reviewed and status["checkpoint_eligible"] and not missing)):
            update(mark_complete(progress, lid))
            st.rerun()
        st.caption("Checkpoint: every chapter question attempted, at least 80% latest accuracy, study acknowledged, and prerequisite checkpoints completed. This is a study threshold, not an exam pass or practical acceptance.")
    with tabs[4]:
        task = lesson["independent_task"]
        st.caption("Environment: " + task["environment"])
        st.markdown(task["brief"])
        if task["starter_artifacts"]:
            st.markdown("**Starter material**")
            for artifact in task["starter_artifacts"]:
                st.markdown("- " + str(artifact))
                # Only packaged files within the project can be downloaded.
                if isinstance(artifact, str):
                    path = (ROOT / artifact).resolve()
                    if path.is_relative_to(ROOT) and path.is_file() and path.stat().st_size < 10_000_000:
                        st.download_button("Download " + path.name, path.read_bytes(), file_name=path.name,
                                           key=f"asset_{lid}_{artifact}")
        for field, title in (("deliverables", "Evidence to produce"), ("acceptance_criteria", "Acceptance criteria")):
            st.markdown("**" + title + "**")
            for item in task[field]:
                st.markdown("- " + item)
        st.info(task["limitations"])
        st.caption("Use Progress → Practical evidence to record work actually performed, its environment and its remaining limits.")
    with tabs[5]:
        st.button("Review this chapter's flashcards", key="academy_flashcards_"+lid,
                  type="primary", on_click=open_flashcards, args=(course["id"], lid))
        st.caption("Reveal each answer, rate your recall, and save its next review date in the app.")
        for source in lesson["sources"]:
            st.markdown(f"- [{source['title']}]({source['url']})")
        unit = next(l for l in learning_units([course]) if l["id"] == lid)
        with st.expander("Optional Anki export"):
            st.download_button("Download chapter Anki cards", flashcard_export([unit]),
                               file_name=lid+"-Anki.tsv", mime="text/tab-separated-values", key="academy_anki_"+lid)
        for card in lesson["cards"]:
            with st.expander(card["front"]):
                st.markdown(card["back"])


def render_courses(courses, progress, update, render_assessment):
    st.title("Your courses")
    st.write("Learn the mechanisms, follow worked demonstrations, practise with guidance, then answer questions and produce independent evidence.")
    if not courses:
        st.info("Course files are being authored. The existing subject overviews remain available under Learn.")
        return
    by_id = {c["id"]: c for c in courses}
    if st.session_state.get("academy_course") not in by_id:
        st.session_state["academy_course"] = courses[0]["id"]
    cid = st.selectbox("Course", list(by_id), format_func=lambda c: f"{c} · {by_id[c]['title']}", key="academy_course")
    course = by_id[cid]
    questions = question_index([course])
    view = st.radio("Course workspace", ["Study", "Practice", "Diagnostics", "Scope & resources"], horizontal=True, key="academy_view")
    done = sum(l["id"] in progress["completed"] for l in course["lessons"])
    st.progress(done / len(course["lessons"]), text=f"{done} / {len(course['lessons'])} chapter checkpoints · {len(course['questions']):,} questions in this bank")
    if course["kind"] == "milestone_integration":
        st.info("ISA Expert integration review. ISA awards this milestone after the four constituent specialist certificates; this bank is not an additional ISA examination.")
    if view == "Study":
        modules = {m["id"]: m for m in course["modules"]}
        target = st.session_state.pop("academy_chapter_target", None)
        if target:
            lesson = next((l for l in course["lessons"] if l["id"] == target), None)
            if lesson:
                st.session_state[f"academy_module_{cid}"] = lesson["module_id"]
                st.session_state[f"academy_lesson_{cid}_{lesson['module_id']}"] = target
        mid = st.selectbox("Module", list(modules), format_func=lambda m: modules[m]["title"], key=f"academy_module_{cid}")
        lessons = {l["id"]: l for l in course["lessons"] if l["id"] in modules[mid]["lesson_ids"]}
        lid = st.selectbox("Chapter", list(lessons), format_func=lambda l: ("✓ " if l in progress["completed"] else "")+lessons[l]["title"], key=f"academy_lesson_{cid}_{mid}")
        _chapter(course, lessons[lid], progress, update, render_assessment, questions)
    elif view == "Practice":
        session_key = "academy_practice_" + cid
        active = st.session_state.get(session_key)
        if active:
            pool = [questions[qid] for qid in active["ids"] if qid in questions]
            st.caption(active["label"])
            render_assessment(pool, active["key"], "course_practice")
            st.button("Choose another practice set", key="end_"+cid, on_click=_end_practice, args=(cid,))
        else:
            a, b = st.columns(2)
            modules = {m["id"]: m for m in course["modules"]}
            mid = a.selectbox("Practice module", ["All modules"]+list(modules), format_func=lambda m: modules[m]["title"] if m in modules else m, key="pm_"+cid)
            scope = b.selectbox("Question pool", ["Unanswered", "Previously incorrect", "Completed chapter checkpoints", "All questions"], key="ps_"+cid)
            difficulty = a.selectbox("Difficulty", ["All", "foundation", "applied", "advanced"], key="pd_"+cid)
            size = b.select_slider("Questions per set", options=[5, 10, 20, 30, 50, 100], value=20, key="pn_"+cid)
            pool = [q for q in questions.values() if (mid == "All modules" or q["module_id"] == mid)
                    and (difficulty == "All" or q["difficulty"] == difficulty)]
            seed = uuid.uuid4().hex
            chosen = select_questions(pool, progress, size, scope, seed)
            st.caption(f"This selection supplies {len(chosen)} questions for the next set. Selection rotates across objectives; it does not reproduce a provider's exam weighting.")
            st.button("Start course practice", type="primary", disabled=not chosen, key="start_"+cid,
                      on_click=_start_practice,
                      args=(cid, [q["id"] for q in chosen], session_key+seed,
                            f"{cid} · {scope} · {len(chosen)} questions"))
    elif view == "Diagnostics":
        rows = assessment_rows(course, progress)
        attempted = sum(r["Attempted"] for r in rows)
        correct = sum(r["Latest correct"] for r in rows)
        a, b, c = st.columns(3)
        a.metric("Distinct questions attempted", f"{attempted:,} / {len(course['questions']):,}")
        b.metric("Latest-answer accuracy", f"{100*correct/attempted:.0f}%" if attempted else "—")
        c.metric("Objectives with attempts", f"{sum(r['Attempted']>0 for r in rows)} / {len(rows)}")
        st.dataframe(rows, hide_index=True, width="stretch")
        st.download_button("Export objective diagnostics", rows_csv(rows), file_name=cid+"-objectives.csv", mime="text/csv")
        st.caption("Coverage counts distinct questions attempted. Accuracy uses the latest answer for each attempted question. Neither establishes coverage of unpublished provider objectives or practical competence.")
    else:
        bp = course["blueprint"]
        st.subheader("Scope and source version")
        st.markdown(f"[{bp['title']}]({bp['url']}) · {bp['version']} · checked {bp['checked_on']}")
        st.write(bp["scope_note"])
        for limitation in bp["limitations"]:
            st.warning(limitation)
        st.subheader("Preparation and external requirements")
        for prior in course["prerequisites"]["course_ids"]:
            if prior in by_id:
                st.button("Open prerequisite: "+prior, on_click=open_course, args=(prior,), key="prior_"+cid+prior)
        for text in course["prerequisites"]["external"] + course["external_requirements"]:
            st.markdown("- " + text)
        st.subheader("Objective register")
        st.dataframe([{"ID": o["id"], "Objective": o["text"], "Source": o["source_ref"],
                       "Chapters": ", ".join(o["lesson_ids"]), "Curriculum outcomes": ", ".join(o["capability_ids"])}
                      for o in course["objectives"]], hide_index=True, width="stretch")
        published = provider_rows(course)
        if published:
            with st.expander("Published scope crosswalk"):
                st.caption("These links identify supporting teaching and question banks. A shared question can support related topics; it is counted once in the bank. Read each record's remaining requirements.")
                st.dataframe(published, hide_index=True, width="stretch")
                st.download_button("Download published scope crosswalk", rows_csv(published),
                                   file_name=cid+"-scope-crosswalk.csv", mime="text/csv")
        units = learning_units([course])
        st.button("Review this course's flashcards", on_click=open_flashcards, args=(cid,), key="course_flashcards_"+cid)
        with st.expander("Optional Anki export"):
            st.download_button("Download course Anki deck", anki_package(units), file_name=cid+"-Anki.apkg", mime="application/octet-stream")
        guide = ROOT / "docs" / "academy" / (cid+".md")
        if guide.is_file():
            st.download_button("Download offline course book", guide.read_text(encoding="utf-8"), file_name=guide.name, mime="text/markdown")
        for source in course["sources"]:
            st.markdown(f"- [{source['title']}]({source['url']})")
        with st.expander("All course banks"):
            st.dataframe(course_rows(courses), hide_index=True, width="stretch")
