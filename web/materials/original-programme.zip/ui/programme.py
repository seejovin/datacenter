"""Programme navigation and honest requirement/evidence traceability."""
from __future__ import annotations

import json
from pathlib import Path

import streamlit as st

from core.engine import add_evidence
from core.academy import capability_course_rows
from ui.academy import open_course
from core.programme import evidence_packet, rows_csv, study_sequence
from ui.depth_audit import render_depth_audit

ROOT = Path(__file__).resolve().parents[1]


def render_programme(programme, lessons, progress, go, update, courses):
    by_id = {lesson["id"]: lesson for lesson in lessons}
    st.caption("CHARTER → CURRICULUM → STUDY → PRACTICE → REVIEWED EVIDENCE")
    st.title("Your engineering study programme")
    st.write("Study by credential and subject, then connect what you learn to your charter outcomes. Each course contains teaching, demonstrations, guided practice, assessments and independent work. Practical evidence determines what you can responsibly claim.")
    section = st.radio("Programme view", ["Teaching depth", "Study route", "Outcome coverage", "Required teaching", "Practical workbench", "Alignment & limits"], horizontal=True, key="programme_view")
    if section == "Teaching depth":
        render_depth_audit(courses)
    elif section == "Study route":
        st.subheader("A shared foundation, then specialist and integrated work")
        st.caption("Use the course prerequisites to enter at the right point. Course order is a suggested route; platform access and actual prior evidence can change your sequence.")
        for level in programme["levels"]:
            with st.container(border=True):
                st.markdown("**" + level["title"] + "**")
                st.write(level["purpose"])
                st.caption("Practical exit gate: " + level["exit_gate"])
        st.info("Design, implementation, commissioning, operations, maintenance, optimisation, troubleshooting, incident response and recovery recur throughout the programme. Advanced work increases independence, complexity and evidence quality.")
        for course in courses:
            with st.expander(course["id"] + " · " + course["title"]):
                done = sum(l["id"] in progress["completed"] for l in course["lessons"])
                st.write(f"{len(course['modules'])} modules · {len(course['lessons'])} chapters · {len(course['questions']):,} questions · {done} chapter checkpoints")
                st.caption("Prior courses: " + (", ".join(course["prerequisites"]["course_ids"]) or "Read this course's knowledge prerequisites."))
                for text in course["prerequisites"]["external"]:
                    st.markdown("- " + text)
                st.button("Study " + course["id"], key="route_course_"+course["id"], on_click=open_course, args=(course["id"],))
        st.caption("The network, hardware and controls extensions preserve curriculum requirements that extend beyond the planned examinations. Run them alongside related credential courses. Study estimates exclude repeated practice, equipment work and review.")
        with st.expander("Original orientation sequence"):
            sequence = study_sequence(lessons)
            rows = [{"Order": n, "ID": l["id"], "Overview": l["title"], "Topic stage": l["level"], "Prerequisites": ", ".join(l["prerequisites"])} for n,l in enumerate(sequence,1)]
            st.dataframe(rows, hide_index=True, width="stretch")
            st.download_button("Download orientation sequence", rows_csv(rows), "orientation-sequence.csv", "text/csv")
    elif section == "Outcome coverage":
        st.subheader("Forty engineering outcomes + eight controls-network outcomes")
        rows = capability_course_rows(programme, courses)
        c1, c2, c3 = st.columns(3)
        c1.metric("Outcomes with course support", f"{sum(r['Supporting chapters']>0 for r in rows)} / 48")
        c2.metric("Authored course chapters", sum(len(c["lessons"]) for c in courses))
        c3.metric("Independent acceptance", "External")
        domain = st.selectbox("Requirement family", ["All", "NET", "HW", "OT", "SEC", "CN"])
        visible = [row for row in rows if domain == "All" or row["Outcome"].startswith(domain + "-")]
        st.dataframe(visible, hide_index=True, width="stretch")
        st.caption("A supporting chapter or question contributes to the named outcome. The count does not claim that every aspect has been independently assessed. Work packages retain the full curriculum requirement and practical acceptance criteria.")
        st.download_button("Download course-to-outcome crosswalk", rows_csv(rows), "curriculum-course-crosswalk.csv", "text/csv")
        choices = [outcome for outcome in programme["outcomes"] if domain == "All" or outcome["id"].startswith(domain + "-")]
        oid = st.selectbox("Inspect a requirement", [outcome["id"] for outcome in choices],
                           format_func=lambda oid:next(f"{oid} · {item['title']}" for item in choices if item['id']==oid))
        outcome = next(item for item in choices if item["id"] == oid)
        render_outcome(outcome, by_id, go, "coverage_", courses)
    elif section == "Required teaching":
        st.subheader("Keep the curriculum's teaching commitments")
        st.write("This is the required-teaching register, not a list of authored app courses. It retains vendor instruction and model-specific demonstrations. Linking a course does not supply its teaching, demonstrations, exercises or assessment.")
        query = st.text_input("Find a course or provider", placeholder="Siemens, Sunbird, NVIDIA, ENCOR…")
        courses = [item for item in programme["course_register"] if not query or query.casefold() in json.dumps(item, ensure_ascii=False).casefold()]
        st.caption(f"{len(courses)} of {len(programme['course_register'])} curriculum register entries")
        for course in courses:
            with st.expander(f"{course['id']} · {course['title']}"):
                st.write(course["provider"])
                st.markdown(course["assignment"])
                st.caption(course["status"])
                st.caption(course["source_ref"])
                for source in course.get("source_links", []):
                    st.markdown(f"- [{source['title']}]({source['url']})")
                for lid in course.get("lesson_ids", []):
                    st.button(by_id[lid]["title"], key="course_"+str(course["id"])+lid, on_click=go, args=("Learn", lid))
        if programme.get("teaching_routes"):
            st.subheader("Targeted teaching additions")
            for route in programme["teaching_routes"]:
                with st.expander(f"{route['id']} · {route['title']}"):
                    for key, value in route.items():
                        if key not in ("id", "title"):
                            display_value(key, value)
        if programme.get("additional_certificate_routes"):
            st.subheader("Additional credential assignments in the curriculum")
            for route in programme["additional_certificate_routes"]:
                with st.container(border=True):
                    for key, value in route.items():
                        display_value(key, value)
        st.subheader("Instructor and equipment access gates")
        for gate in programme["access_gates"]:
            with st.expander(gate["id"] + " · " + gate["title"]):
                st.write(gate["requirement"])
                st.caption("Required for: " + ", ".join(gate["required_for"]))
    elif section == "Practical workbench":
        st.subheader("Build evidence you can defend")
        choices = programme["outcomes"]
        oid = st.selectbox("Work package", [item["id"] for item in choices],
                           format_func=lambda oid:next(f"WP-{oid} · {item['title']}" for item in choices if item['id']==oid), key="workbench_outcome")
        outcome = next(item for item in choices if item["id"] == oid)
        render_outcome(outcome, by_id, go, "workbench_", courses)
        st.download_button("Download this work-package template", evidence_packet(outcome),
                           outcome["work_package"]+".md", "text/markdown")
        if st.session_state.pop("work_package_saved", False):
            st.success("Work-package note added. Its claims and any linked review are self-reported in this app.")
        with st.form("workpackage_record", clear_on_submit=True):
            st.markdown("**Record an execution or review note**")
            title = st.text_input("Event or test title", max_chars=150)
            environment = st.selectbox("Actual evidence environment", ["analytical", "simulation", "emulation", "vendor_simulation", "physical_lab", "supervised_field", "production"])
            notes = st.text_area("Evidence IDs, measured results, acceptance decision and remaining gaps", max_chars=5500, height=180)
            url = st.text_input("Evidence or independent review link (optional)", max_chars=2000)
            submit = st.form_submit_button("Save work-package note", type="primary")
        if submit:
            if not title.strip() or not notes.strip():
                st.warning("Add an event title and the results or gaps you observed.")
            else:
                try:
                    record = {"title":outcome["work_package"] + " · " + title,
                              "lesson_id":outcome["lesson_ids"][0], "environment":environment,
                              "review_status":"self_reported", "notes":f"Requirement: {oid}\n" + notes, "url":url}
                    update(add_evidence(progress, record))
                    st.session_state["work_package_saved"] = True
                    st.rerun()
                except ValueError as error:
                    st.error(str(error))
        st.caption("Use the supplied registers for the full evidence chain. Nothing in this notebook authorises equipment operation or automatically accepts a work package.")
        related = [entry for entry in progress["evidence"] if entry.get("lesson_id") in outcome["lesson_ids"]]
        if related:
            st.markdown("**Related evidence notes**")
            for entry in reversed(related):
                with st.expander(entry["title"]):
                    st.caption(entry["environment"].replace("_", " ") + " · Self-reported")
                    st.write(entry.get("notes", ""))
                    if entry.get("url"):
                        st.link_button("Open linked evidence or review", entry["url"])
        st.subheader("Cumulative portfolio releases")
        for release in programme["releases"]:
            with st.expander(f"Release {release['id']} · {release['title']}"):
                st.markdown(release["gate"])
        with st.expander("Sustained operations campaign — every D4–D7 domain"):
            for key, value in programme.get("operating_campaign", {}).items():
                display_value(key, value)
        with st.expander("Evidence rules and claim boundaries"):
            for key, value in programme.get("evidence", {}).items():
                display_value(key, value)
        cases = programme.get("practical_cases", [])
        if cases:
            st.subheader("Portfolio case assignments")
            st.caption("These assignments require your own evidence. The app's interactive synthetic cases rehearse decisions separately.")
            for case in cases:
                with st.expander(f"{case['id']} · {case['title']}"):
                    for key,value in case.items():
                        if key not in ("id", "title"):
                            display_value(key,value)
        lab_readme = ROOT / "labs/README.md"
        if lab_readme.exists():
            with st.expander("Four included synthetic data labs"):
                st.markdown(lab_readme.read_text(encoding="utf-8"))
    else:
        report = ROOT / "docs/CURRICULUM_ALIGNMENT.md"
        if report.exists():
            st.markdown(report.read_text(encoding="utf-8"))
            st.download_button("Download alignment explanation", report.read_text(encoding="utf-8"), report.name, "text/markdown")
        else:
            for key,value in programme["baseline"].items():
                display_value(key,value)
            for key,value in programme["sufficiency"].items():
                display_value(key,value)


def display_value(key, value):
    st.markdown("**" + key.replace("_", " ").capitalize() + "**")
    if isinstance(value, str):
        st.markdown(value)
    elif isinstance(value, list) and all(isinstance(item, (str, int)) for item in value):
        for item in value:
            st.markdown("- " + str(item))
    else:
        st.write(value)


def render_outcome(outcome, by_id, go, key_prefix, courses):
    st.markdown("**" + outcome["id"] + " · " + outcome["title"] + "**")
    st.markdown(outcome["scope"])
    st.markdown("**Required teaching**")
    st.markdown(outcome["teaching_requirements"])
    st.markdown("**Supporting course chapters**")
    for course in courses:
        linked = {lid for objective in course["objectives"] if outcome["id"] in objective.get("capability_ids", []) for lid in objective["lesson_ids"]}
        if linked:
            with st.expander(course["id"] + f" · {len(linked)} chapters"):
                for chapter in course["lessons"]:
                    if chapter["id"] in linked:
                        st.button(chapter["title"], key=key_prefix+outcome["id"]+chapter["id"],
                                  on_click=open_course, args=(course["id"], chapter["id"]), width="stretch")
    st.markdown("**Orientation material**")
    for lid in outcome["lesson_ids"]:
        lesson = by_id[lid]
        st.button("Overview · " + lesson["level"] + " target topic · " + lesson["title"], key=key_prefix+outcome["id"]+lid,
                  on_click=go, args=("Learn", lid), width="stretch")
    st.markdown("**Independent practical requirement**")
    st.markdown(outcome["practical_requirement"])
    st.markdown("**Acceptance criteria**")
    for item in outcome["acceptance_criteria"]:
        st.markdown("- " + item)
    st.caption(outcome["source_ref"] + " · " + outcome["work_package"])
