# Test/event: [TEST-ID] — [Title]

| Field | Record |
|---|---|
| Requirement, WP, lesson, case and release | |
| Author, executor, reviewer and timestamp | |
| Environment/evidence level and authority | |
| Hardware/software/firmware and approved configuration hash | |
| Test procedure version and prerequisites | |
| Hazards, isolation and permitted scope | |
| Expected result and numerical limits set before execution | |
| Method, instruments, calibration and uncertainty | |
| Fault or change introduced within approved boundary | |
| Abort criteria and rollback/restoration | |

## Actual observations

| Timestamp | Observation | Raw evidence ID/location/hash | Requirement | Pass/fail/untested |
|---|---|---|---|---|
| | | | | |

Keep design intent, configured state, digital observation and physical result separate. Record permitted and denied paths where relevant; successful ping or a green dashboard does not prove application or process acceptance.

## Defect, correction and retest

Record defect ID, competing hypotheses, diagnosis, correction/change ID, repeated test and resulting state. Include failed results. Verify the function, retained data/alarms, configuration and administrative trust after restoration.

## Review

Accepted criteria: 

Open criteria, fidelity/physical limitations and residual risks: 

Independent reviewer/reproduction record and date: 
