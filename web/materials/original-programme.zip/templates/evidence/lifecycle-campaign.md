# Operating campaign — [Domain D4/D5/D6/D7] / [network branch if applicable]

Environment and evidence level: 

System scope, owner, authority, operating modes and campaign period: 

Normal operating cycles observed and justification of representativeness: 

| Required event | Requirement and predetermined criterion | Date / actual event | Test and raw evidence | Result and reviewer | Remaining gap |
|---|---|---|---|---|---|
| Repeated normal checks and applicable modes | | | | | |
| Abnormal condition/alarm and escalation | | | | | |
| Preventive/condition-based/corrective maintenance | | | | | |
| Reviewed planned change | | | | | |
| Failed or rolled-back change | | | | | |
| Diagnosed fault with competing hypotheses | | | | | |
| Security validation and applicable incident | | | | | |
| Trusted restoration and service retest | | | | | |
| Measured improvement and revised design/runbook | | | | | |

Cross-domain events may be reused only through explicit links to each domain's own criteria and evidence. Apply this record to every declared network branch. Calendar duration and repetition count alone do not establish acceptance.

Before/after measurement and remaining trade-offs: 

Independent review/reproduction: 

Claim that this campaign supports, including evidence level: 
