# Work package: [WP-ID] — [Title]

Status: Planned / Teaching complete / Practically applied / Awaiting review / Accepted / Open defect / Superseded

| Field | Record |
|---|---|
| Owner and reviewer | |
| Date, version and repository commit | |
| Outcome, lesson, course/instructor assignment | |
| Portfolio release(s) and domain | |
| Required service and intended claim | |
| Environment and evidence level | |
| Personal contribution, supervision and authority | |
| Systems/interfaces in scope; external owners | |
| Exclusions and physical/fidelity limitations | |
| Product, firmware/software version and lab rights | |

## Requirements and acceptance fixed before execution

| Requirement ID and source/version | Required function/limit | Assumption or constraint | Test/event ID | Pass criterion | Evidence ID |
|---|---|---|---|---|---|
| | | | | | |

## Teaching and prerequisites

Record the actual lesson/session and assessment completed, guided exercise, missing instruction, demonstrated equivalence and continuing access. App knowledge progress is supporting evidence only.

## Design and implementation

Record alternatives and rejected options, dependencies and failure paths, capacity/timing/security requirements, diagrams, configuration or wiring, versions, identities, baseline, deviations and as-built state.

## Lifecycle event links

| Design | Implementation | Commissioning | Daily operation | Maintenance | Optimisation | Troubleshooting | Incident response | Recovery |
|---|---|---|---|---|---|---|---|---|
| | | | | | | | | |

## Evidence and decision

Link raw data and provenance, test versions, defects/corrections/retests, measured outcomes, residual uncertainty and open access/physical gaps. Specify accepted criteria individually and name the independent reviewer. Unmet requirements remain open.
