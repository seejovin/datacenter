# Release / claim review — [REL-ID] / [CLAIM-ID]

| Field | Record |
|---|---|
| Intended release and claimed horizon/domain | |
| Evidence level and actual personal contribution | |
| Requirement/outcome/work-package scope | |
| Accepted tests/events and raw evidence index | |
| Physical tasks demonstrated and remaining gaps | |
| Domain operating-campaign acceptance | |
| Incident, trusted recovery and measured improvement | |
| Independent review or reproduction and findings | |
| Open defects, access, uncertainty and residual risk | |
| Field/production experience and delegated authority boundary | |
| Publication permission, redaction and secrets review | |
| Decision, reviewer and date | |

Proposed claim:

> Demonstrated [capability] in [environment/evidence level] by [personal implemented work and accepted test/event], with [principal limitation or production-experience boundary].

Name the horizon: near-term D4–D7 or separately accepted long-term D2–D7. D1 is excluded from both. Neither a certificate nor app knowledge completion closes missing physical or operating evidence. An unresolved required criterion prevents programme completion.
