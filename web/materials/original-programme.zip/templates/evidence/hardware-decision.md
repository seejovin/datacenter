# Engineering decision — [ID] / [WP-HW-ID]

| Field | Record |
|---|---|
| Proposal or observed work being reviewed | |
| Required service and constraints | |
| Requirement, OEM method/source and exact version | |
| Approved design/BOM/compatibility and installed state | |
| Observations, tests and raw evidence | |
| Competing explanation and how distinguished | |
| Operational consequence of proceeding | |
| Disposition: accept / conditional acceptance where allowed / hold / reject / escalate | |
| Reason tied to the requirement | |
| Correction, responsible owner and retest | |
| Final outcome and remaining limitations | |
| Competent reviewer and date | |
| Delegated authority or recommendation-only status | |
| Laboratory / supervised field / production boundary | |

Across the D5 case set, show both justified rejection of plausible incorrect work and justified acceptance of correct work. Retain real execution and physical observations: review alone does not establish hands-on capability. Never execute an unsafe proposal merely to demonstrate that it is wrong.
