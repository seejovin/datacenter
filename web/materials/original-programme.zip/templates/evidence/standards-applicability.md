# Standards applicability — [Record ID]

| Field | Record |
|---|---|
| Domain and system/interface | |
| Publisher, publication, edition, amendments and adoption | |
| Actual clause/requirement after full-text review | |
| Applicability rationale and boundary | |
| Non-applicability or exception with justification | |
| Curriculum outcome, lesson and work package | |
| Implemented control/design decision | |
| Test/event, raw evidence and acceptance | |
| Reviewer, date and unresolved gap | |

Public catalogue descriptions and training summaries are not normative text or conformance evidence. Record D1 only as an excluded external interface. D2/D3 foundation mappings do not establish their later specialist engineering or authority.
