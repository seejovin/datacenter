# Evidence templates

Copy a template for an actual work package or event. Blank fields are unresolved; this folder contains no completed learner evidence. Retain raw records and link them instead of treating a screenshot or quiz result as proof of a whole capability.

Use stable IDs: requirement `PR-`, system `SYS-`, interface `IF-`, work package `WP-`, test `TEST-`, evidence `EV-`, defect `DEF-`, change `CHG-`, incident `INC-`, release `REL-`, claim `CLAIM-`. Preserve the original `WP-NET/HW/OT/SEC/CN` IDs when linking curriculum work packages.

| Template | Purpose |
|---|---|
| `work-package.md` | Boundary, requirements, teaching, implementation, tests and review. |
| `test-record.md` | Predetermined acceptance, actual observations, raw evidence, defect and retest. |
| `lifecycle-campaign.md` | Required repeated operating events for each domain and network branch. |
| `hardware-decision.md` | Evidence-based acceptance, hold, rejection or escalation. |
| `teaching-access.md` | Named instruction, prerequisites, provider/product/version and continuing lab rights. |
| `standards-applicability.md` | Actual requirement/edition, applicability, test, evidence and review. |
| `change-and-recovery.md` | Controlled change, rollback, incident response and trusted restoration. |
| `release-and-claim-review.md` | Independent review, remaining gaps and bounded public claim. |

Evidence levels remain distinct: analytical design; simulation/computational model; network emulation; vendor simulation; physical laboratory; supervised field; production. Record actual personal work, authority and limits. A claimed real physical task requires physical evidence.

Before applicable physical/site/destructive work, apply the controls already required by your curriculum: approved scope and authority, competent supervision, OEM method, hazards/isolation/PPE, backup and rollback, emergency response and publication boundary. Leave the record open if necessary access or authority is missing.

Source: Portfolio v2.5 §§14–16, Appendix A, §21; Curriculum Rev14 §§10–11.
