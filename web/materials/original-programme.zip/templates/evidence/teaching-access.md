# Teaching and access — [Assignment/outcome ID]

| Required field | Record |
|---|---|
| Required outcome and practical assessment | |
| Actual provider, course, lesson titles or named instructor/session | |
| Product/version and prerequisite evidence | |
| Assignment scope; what remains outside scope | |
| Structured explanation and demonstration | |
| Guided practice and independent assessment | |
| Language, delivery format and accessibility | |
| Equipment, software licence, lab rights and retention period | |
| Physical work and supervision required | |
| Cost/funding, owner, planned period and review date | |
| Assessed equivalence for reused teaching | |
| Separate enrolment/exam attendance conditions | |
| Portfolio work package and intended evidence location | |
| Status and remaining gap | |

A provider/access gap remains compulsory and open. Record the agreed teaching before claiming that a general course outline covers a product-specific task. Reuse equivalent teaching without waiving the outcome or assuming an external provider grants an attendance exemption.
