# Change / incident / recovery — [CHG-ID or INC-ID]

| Field | Record |
|---|---|
| Trigger, reason, scope and required service | |
| Systems and dependencies, reduced redundancy and common causes | |
| Owner, operational approver, supervision and permitted authority | |
| Baseline versions/configurations/identities and trusted backup | |
| Acceptance, abort and return-to-service criteria | |
| Planned actions, test boundary and evidence preservation | |
| Rollback or recovery method and unavailable-dependency alternative | |

## Timeline and evidence

| Time | Observation/action | Actor and authority | Evidence | Known / uncertain | Service consequence |
|---|---|---|---|---|---|
| | | | | | |

## Incident response, where applicable

Record scope, preservation, containment/continuity trade-offs, escalation, eradication, removed credentials/keys/sessions and untested boundaries. Distinguish a tabletop decision exercise from technical restoration.

## Restoration and acceptance

Record trusted source selection; restore network/time/identity/storage/application dependencies in justified order. Verify intended function, data/point bindings, alarms/history, configuration/firmware and revoked authority. A reboot or successful login does not establish trusted recovery.

Final state, measurements and residual risk: 

Reviewer and return-to-service authority: 

Required runbook/design/acceptance improvement and owner: 
