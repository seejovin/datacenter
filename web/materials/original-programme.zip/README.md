# Data Center Academy

An independent Streamlit study programme for data-center facilities, networks,
hardware, OT controls, cybersecurity and lifecycle engineering. It combines
credential courses with the wider engineering outcomes in your charter,
curriculum and portfolio plan.

## What is included

- Fourteen credential-related banks for planned items #2–#15, each with at least
  500 original questions. CCNP Data Center has over 1,000 across DCCOR, DCACI,
  DCID, DCIT and DCNAUTO. ISA Expert has an integration bank; it is a milestone
  earned through its four constituent provider certificates, not another exam.
- Courses organised into modules and chapters, with mechanism teaching, worked
  demonstrations, guided exercises, explained assessments, independent tasks
  and primary-source references.
- Network, hardware and controls engineering extensions for curriculum outcomes
  beyond the examinations. Existing CCNA study is an external prerequisite.
- Single-answer, multiple-answer and sequence questions, evidence exhibits,
  objective diagnostics, unanswered-question practice and targeted remediation.
- Runnable local exercises, platform workbooks, sixteen portfolio case
  assignments, forty-eight outcome work packages and six cumulative releases.
- Offline course books, individual and combined Anki decks, curriculum and
  source crosswalks, question registers and a machine-readable inventory.
- Device-local progress, manual JSON backup/restore and an evidence notebook.
  The original 88 orientation lessons and their progress identities are retained.
- Built-in flashcard review for every course and orientation card: reveal the
  answer, rate recall and save the next review date. Anki is optional.

The exact released counts are generated from the course files in
[the content manifest](exports/content-manifest.json) and
[course inventory](exports/course-inventory.csv). Per-course source baselines,
coverage limits and external requirements are in
[the course manifest](exports/course-manifest.json).

Read [the programme guide](docs/PROGRAMME_GUIDE.md) for the course inventory and how it fits your intended identity.

Start at **Programme → Study route**, then open **Courses**. Learn the chapter,
work its demonstrations and guided exercise, attempt the questions, and complete
its independent task. Course practice can filter unanswered or previously incorrect
questions, or questions from completed chapter checkpoints. Diagnostics count distinct questions and use the latest
answer for each; repeated attempts do not inflate coverage.

A chapter checkpoint requires study acknowledgement, every linked question
attempted, at least 80% latest accuracy and its prerequisite checkpoints. This
is a study threshold. Provider examinations, supervised equipment work and
independently accepted portfolio evidence remain separate requirements. A bank
size, map or quiz score cannot guarantee a certificate or professional competence.
The material is original independent preparation, not provider-authorised courseware
or a collection of actual examination questions.

## Run locally

Use Python 3.12 from the directory containing `app.py`:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

On Windows, activate with `.venv\Scripts\activate` instead. No API keys or
secrets are required. Follow the printed local URL.

## Deploy with GitHub and Streamlit

1. Extract the ZIP and upload its **contents** to `seejovin/datacenter` on GitHub.
   Keep `app.py`, `requirements.txt`, `core`, `content`, `ui`, `components`,
   `course_labs`, `docs`, `exports` and `.streamlit` at the repository root.
2. In [Streamlit Community Cloud](https://share.streamlit.io/), select **Create app**
   and choose your existing GitHub app.
3. Set repository `seejovin/datacenter`, branch `main` and entrypoint `app.py`.
4. Select Python **3.12** in Advanced settings, choose an available URL and deploy.

These settings follow the [official deployment guide](https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/deploy), checked 19 September 2026.
If you retain a nested `datacenter` directory, the entrypoint is
`datacenter/app.py`. This delivery supplies files; it does not claim that the
repository was pushed or a public deployment was performed.

## Curriculum and charter alignment

The controlled baseline is **Charter Revision 3.5**, **Curriculum Revision 14**
and **Portfolio Version 2.5**. Read
[the alignment explanation](docs/CURRICULUM_ALIGNMENT.md) or open
**Programme → Alignment & limits**.

The programme retains all NET/HW/OT/SEC-01–10 and CN-01–08 outcomes, 69 core
teaching-register entries, vendor access gates, operating campaigns and Releases
0–5. Its course-to-outcome crosswalk identifies authored support. The work
packages preserve the full practical requirement and acceptance criteria.

D4 networks, D6 controls and D7 security are principal specialisations. All
D5 hardware outcomes remain mandatory. D2/D3 power and cooling provide foundations
and integration; specialist ownership requires a later supervised route. D1
building engineering ownership is excluded. The referenced Track 1/MUDT document
was not supplied for this implementation; its completion is not assumed.

**Programme → Required teaching** preserves the curriculum's external vendor
assignments. Study here does not waive attendance, examination, equipment access,
experience or endorsement rules. Course-specific source limitations identify
where a complete provider blueprint was not publicly retrievable. Those limits
must be resolved against the provider before claiming verified exam completeness.

## Progress and privacy

Progress is saved in the browser's local storage for this app's origin and loaded
into the active Streamlit session. There is no account or automatic cross-device
sync. Clearing site data, changing the app URL or changing browsers can remove
access to that copy. Export a backup regularly and before moving devices.

The app validates backups, protects existing state while loading, and detects
conflicting writes from another tab. Resolve a conflict after exporting any
unsaved work. Modern browsers compress large progress records for local storage;
if saving is blocked or capacity is exceeded, use the manual backup. The
uncompressed backup limit is **16 MiB**, with up to **20,000 assessment attempts**.

Use **Progress → Backup & restore**. Import replaces the device's active progress
after validation. Old schema-1 backups and stable orientation IDs remain
compatible. An orientation checkpoint is never promoted to a course checkpoint.

The hosted server processes progress and entered notes during the session;
the durable copy remains in the browser. Personal progress is not written into
the project files. Evidence notes are self-reported: keep raw artefacts and
independent reviews in your own controlled storage.

## Built-in flashcards

Open **Flashcards**, choose your course and chapter, recall the answer, then
select **Reveal answer**. Rate it **Again**, **Hard**, **Good** or **Easy**.
You can also select **Review this chapter's flashcards** from a course chapter's
**Sources & recall** tab. Every supplied card is available inside the app;
no Anki installation or external account is required.

Due cards appear before new cards. The page shows due, new, scheduled and previously
reviewed card counts for your selection. Ratings use fixed review intervals:
**Again = 10 minutes, Hard = 1 day, Good = 3 days, Easy = 7 days**, measured from
the rating time. Use **Refresh due cards** after waiting, or enable early review.
These intervals do not grow automatically after repeated successful recall.

Ratings, review counts and due dates are saved with device-local progress and
included in the JSON backup. Use **Progress → Backup & restore** to move that
history between browsers. Flashcard ratings do not grant chapter checkpoints or
quiz credit.

Optional Anki downloads are inside **Review intervals and optional export**.
Ready-made decks remain in `exports/course-decks`. Anki history is separate and
does not sync with this app. For TSV import, use fields **NoteID, Front, Back,
Source**, map the fifth column to **Tags**, enable HTML and update matching notes.

## Content and development

`content/academy/*.json` is the canonical course material.
`content/programme.json` contains the curriculum and evidence requirements.
The original subject JSON files remain as orientation material, and
`content/certificates.json` retains their credential relevance map.
`docs/academy` contains the generated offline course books; `course_labs` contains
local exercises and platform workbooks. Historical prototype audits remain in
`docs/audits` and are labelled by their original scope and date.

Keep existing IDs for wording corrections. Use a new question ID when the
assessed objective changes so recorded answers retain their meaning.

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
node tests/device_store_test.mjs
python scripts/build_release.py --output ../Data-Center-Academy-Streamlit.zip
```

The release builder validates structure, links, assets and bank minimums before
regenerating books, Anki decks, registers and manifests. These checks detect
broken content; they do not establish pedagogical or psychometric validation.
See `TEST_REPORT.md` for the actual checks performed and their limits.

After deployment, check a course quiz and checkpoint, reload to verify saved
progress, export/import a backup in another browser, and import an Anki deck.
The local test results do not replace these checks in your hosted environment.
