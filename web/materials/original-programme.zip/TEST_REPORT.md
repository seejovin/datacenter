# Version 3.1.0 — built-in flashcard review

Checked 20 September 2026. **13 focused tests passed** for built-in recall and
course integration. Anki is an optional export; the complete supplied card
collection can be studied inside the app.

- Direct chapter and course review links; course/chapter filters reset incompatible selections.
- New, due, scheduled and reviewed counts, deduplicated by card identity.
- Due cards ordered by actual timestamp before new cards, including imported timezone offsets.
- Answers reset when the active card or selection changes, including early-review toggles and restored progress.
- Rating, count and due-date roundtrip through the existing JSON backup schema.
- Existing chapter checkpoints, question-bank minimums, curriculum links, remediation and ISA milestone distinctions remain verified.

Review intervals are fixed: Again 10 minutes, Hard 1 day, Good 3 days and Easy
7 days. Each interval starts when rated; repeated success does not automatically
lengthen it. The storage protocol and progress schema are unchanged. Progress is
saved in the browser for this app; manual backups support moving between browsers.

The test record is `docs/quality/flashcards-pytest.xml`. No public deployment or
real-browser acceptance test was performed for this update. The prior programme
verification record follows and retains its original date and test scope.

---

# Version 3.0.0 — release verification

Checked 19 September 2026 with Python 3.12, Streamlit 1.55.0 and genanki 0.13.1.

## Delivered material

The canonical inventory contains **17 courses, 555 chapters,
8,452 original course questions and 1,860 course recall cards**.
All fourteen credential-related banks meet the 500-question minimum. CCNP Data
Center contains 1,180 questions across all five assigned courses and their
technical extensions; CISSP contains 590. ISA Expert has an additional
integration bank and remains a provider milestone, not another examination.

The original 88 orientation lessons, 492 questions and 492 cards retain their
identities. They are separate from the course counts above. The generated
inventory records 320,780 teaching-body words,
95,857 worked-example words and
41,246 guided-practice words. These quantities describe supplied
material and are not measures of teaching quality or learner competence.

## Software and artifact checks

- **71 pytest tests passed** in the full application suite. This covers grading,
  ordered answers, progress validation/import, prerequisite checks, course
  diagnostics, remediation, actual chapter navigation, curriculum pages, cases,
  recall exports and credential/evidence separation. The final content and the
  clarified completed-checkpoint filter also passed their targeted integration checks.
- **13 JavaScript storage protocol checks passed**, including loading protection,
  explicit restoration, cross-tab conflicts, compressed records, capacity limits
  and preservation of existing state on rejected writes. These use a simulated
  browser environment; they do not constitute a deployed-browser test.
- A local headless Streamlit process started and returned **HTTP 200 / `ok`** from
  its health endpoint. Streamlit AppTest exercised the application widgets.
- Release validation passed for identifiers, prerequisite cycles, module/objective/
  question relationships, answer-key structure, duplicate stems within banks,
  packaged starter files and all bank minimums. Every authored chapter and objective
  has assessment links. All 48 curriculum outcomes have supporting chapters and questions.
- All **17 offline course books** contain every primary chapter and question once.
  The question register contains 8,452 distinct entries.
  Every published answer and option rationale was checked after book display-order
  shuffling, including the exact sequence for ordered-answer questions.
  All 18 Anki packages passed ZIP and SQLite integrity checks, with exact note sets
  and stable note identities across individual and combined exports. The combined
  deck contains **2,352 notes**, including the orientation cards.

The machine-readable content and source inventories are in `exports`. Selected
check records are in `docs/quality`. The release ZIP builder checks archive CRCs
and writes the completed archive atomically before delivery.

## Executable exercises

The packaged exercises were executed locally with synthetic input. Checks covered
facilities calculations; network policy and routing mechanisms; protocol bytes
and framing; evidence parsing and detection; controlled authority decisions;
configuration preconditions; telemetry quality; control dynamics; and trusted
recovery dependencies. Actual temporary file and SQLite restoration was performed
where the hardware, controls and CISSP exercises explicitly describe it.

| Exercise family | Executed verification |
|---|---|
| DCCA / CDCP | Reference workbook calculations and deliberate failed acceptance cases |
| CDFOS / CDCS | Numerical self-checks with independently reviewed calculation examples |
| CCNP Data Center | 24 original and 53 additional mechanism/input-contract tests |
| CCIE / network extension | 9 and 11 narrow offline policy/model checks |
| GICSP | Signal/policy checks and generated synthetic PCAP field/checksum/length checks |
| GRID | Offline PCAP reconstruction, bounded PE parsing and detection regression checks |
| IC32 / IC33 / IC37 | 8, 13 and 17 local model/calculation checks |
| IC34 | 12 parser/model self-tests and 46/46 reference-policy requirement fixtures |
| ISA Expert | 17 integration model checks |
| CISSP | 12 application-casebook and 29 assessment/operations tests |
| Hardware / controls extensions | Actual temporary file/database recovery; 15 controls checks |

Each exercise declares its assumptions and execution environment. No Cisco,
Siemens, power, cooling, safety or production equipment was operated. Static
platform commands and workbooks remain learner assignments in the stated supported
environment. Supplied certificate or identity facts in an offline model are not
cryptographic validation results.

## Instructional review and source boundaries

The original material received AI-assisted author review and targeted independent
review. A separately recorded sample examined 433 complete questions plus 126
additional calculation items across five banks, producing **138 applied question
corrections/refinements**. GIAC's later bank-wide distractor pass refined 527
alternatives across GICSP and GRID. Additional CISSP, IC33, IC34 and engineering
reviews corrected concrete ambiguity, arithmetic, wording and rationale issues.
The exact scope of the independent sample is in
[QUESTION_REVIEW.md](docs/quality/QUESTION_REVIEW.md).

The Cisco scope review retrieved all five current CCNP outlines and linked 227
published leaves. It also identified missing mechanism/build instruction beyond
simple mapping; chapters 092–104 supply those additions. Read
[CCNP_SOURCE_REVIEW.md](docs/quality/CCNP_SOURCE_REVIEW.md).

The complete official CCIE v3.1 leaf list could not be retrieved from its loading/
CSS-error topic page; a final source-only cloud-browser attempt also timed out.
Its programme and equipment baselines were verified. DCCA
and several other providers expose public subject groups rather than a complete
private examination specification. Their course manifests preserve that distinction.
Source links, versions and individual limitations remain visible in the app and
course books; a topic link is not proof of exhaustive semantic coverage.

No provider endorsement, full independent technical review of every item,
learner item analysis, psychometric calibration or exam-pass guarantee is claimed.
The programme tracks the supplied charter/curriculum/portfolio requirements;
vendor learning, hands-on implementation, operating campaigns, supervised work,
provider examinations and accepted portfolio releases remain part of the route.

## Delivery and reproduction

This delivery supplies the project for the user to upload. No GitHub push or
public Streamlit deployment was performed. A local Chromium executable was unavailable;
no real-browser visual or hosted persistence acceptance test of the app is claimed.
Perform the post-deployment checks in README.md at the final hosted origin.

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
node tests/device_store_test.mjs
python scripts/build_release.py --output ../Data-Center-Academy-v3-Streamlit.zip
```

The version 2.0.1 reports under `docs/audits` are retained as labelled historical
prototype audits. Current inventory and limits are in the generated manifests,
programme guide and this report.
