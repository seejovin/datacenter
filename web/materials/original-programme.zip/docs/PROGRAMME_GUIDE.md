# Data Center Academy — programme guide

The programme combines credential preparation with the broader engineering identity in your charter. Study is organised into courses, modules and chapters; the curriculum view connects that material to the work and evidence you must demonstrate.

## Your target identity

Your Charter Revision 3.5 makes networks (D4), OT/controls (D6) and cybersecurity (D7) the principal specialisations. All ten hardware outcomes (D5) remain mandatory. Power and cooling (D2/D3) provide required foundations and integration now; full specialist ownership is a later supervised pathway. Building engineering ownership (D1) is excluded.

Curriculum Revision 14 supplies the teaching assignments; Portfolio Version 2.5 supplies the acceptance structure. The app retains all 48 NET/HW/OT/SEC/CN outcomes, 69 core teaching-register entries, 16 practical case assignments and Releases 0–5. The referenced Track 1/MUDT document was not supplied, so its completion is not assumed.

## Delivered course inventory

The first table contains the fourteen planned items after CCNA. ISA Expert is the integration milestone earned through its four constituent provider certificates; its bank is additional study, not an invented examination.

| Pathway | Modules | Chapters | Original questions | Recall cards |
|---|---:|---:|---:|---:|
| DCCA | 25 | 25 | 500 | 125 |
| IC32 | 10 | 30 | 500 | 50 |
| CDCP | 25 | 25 | 500 | 125 |
| CDFOS | 9 | 9 | 500 | 52 |
| CCNP-DC | 22 | 104 | 1,180 | 416 |
| GICSP | 10 | 50 | 500 | 103 |
| GRID | 7 | 50 | 500 | 100 |
| CISSP | 8 | 38 | 590 | 166 |
| CDCS | 12 | 12 | 500 | 50 |
| IC33 | 25 | 25 | 500 | 75 |
| IC34 | 25 | 25 | 500 | 88 |
| IC37 | 10 | 30 | 500 | 50 |
| ISA-EXPERT | 10 | 30 | 500 | 60 |
| CCIE-DC | 25 | 25 | 500 | 125 |

The additional engineering courses preserve requirements beyond the examination list.

| Engineering extension | Chapters | Questions | Recall cards |
|---|---:|---:|---:|
| Independent network engineering: campus, edge, wireless, hybrid, AI and controls | 33 | 330 | 99 |
| Hardware Engineering: Architecture, Integration, Operations and Recovery | 22 | 176 | 110 |
| Controls engineering: instruments, PLC/DDC, dynamics and complete operational ownership | 22 | 176 | 66 |

The original 88 orientation lessons remain available with their original progress identities. They are separate from the expanded courses. The inventory counts supplied material; it does not measure a learner's proficiency or prove psychometric validity.

## How to study

1. Open Programme → Study route and check course prerequisites. Reuse demonstrated CCNA foundations through your existing app.
2. Open a course chapter and study its explanation before attempting the worked demonstration yourself.
3. Complete the guided exercise before revealing its solution.
4. Answer the chapter questions, read every relevant rationale and revisit the mechanism behind errors. Use Practice for unanswered questions or targeted remediation.
5. Select Review this chapter's flashcards, or open Flashcards and choose a course/chapter. Recall the answer, reveal it, then rate Again, Hard, Good or Easy. The app saves ratings and due dates; Anki is optional.
6. Execute the independent task in its declared environment, retain actual results and complete the corresponding curriculum work package.
7. Review cumulative release evidence and provider requirements separately from study checkpoints.

Built-in flashcards show due cards before new cards, with counts for new, due, scheduled and reviewed cards. Review intervals are fixed: Again 10 minutes, Hard 1 day, Good 3 days and Easy 7 days. Use Refresh due cards after waiting. Review history is saved on this browser and included in Progress → Backup & restore. No external flashcard application or account is needed.

Foundation, Applied and Advanced describe increasing difficulty and independence within subjects. You do not need to finish every subject at one level before starting the next level in another. The course prerequisites and practical release gates provide the dependencies. Cross-domain work joins these strands as your evidence grows.

All nine lifecycle responsibilities recur: design, implementation, commissioning, day-to-day operations, maintenance, optimisation, troubleshooting, incident response and recovery. Advanced work increases ambiguity, scale and integration; it does not postpone operations or recovery until the end.

## Why this fits the curriculum and charter

A certificate-only route would leave parts of the intended identity untracked. Data-center networking alone does not establish campus/WAN/wireless engineering; an OT-security qualification does not establish PLC application behaviour; a facilities course does not demonstrate server diagnosis and restoration. The three engineering extensions, 48 work packages and retained vendor assignments keep those requirements visible.

Shared work can support several outcomes when each claim has its own criteria and evidence links. The course-to-outcome crosswalk identifies supporting chapters and questions; the work package preserves the complete requirement. A large number of links is not a claim that every aspect has been independently assessed.

## What establishes the intended identity

This package supplies original instruction, explained assessments, executable local exercises and a structured route through the specified work. Achieving the identity requires completing that route: retained platform instruction, physical and supervised practice, repeated operating campaigns, trusted recovery, measured improvement and accepted portfolio releases. Software progress alone cannot establish professional competence or authority.

The local labs distinguish actual file/database operations from synthetic network, process and authority models. They do not claim that Cisco, Siemens, electrical, cooling or safety equipment was operated. Vendor commands and platform workbooks require their stated supported lab and acceptance evidence.

## Scope verification and external requirements

### DCCA

[Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/) — Public scope checked 2026-09-19; author-defined chapter identifiers; checked 2026-09-19.

Original instruction mapped to public subject areas. Public information is not an item-level examination specification; no claim of provider endorsement or actual examination replication.

- Detailed examination weighting and proprietary learning materials are not publicly verified.

- National requirements and equipment-specific limits must be supplied for actual installation.

- This author-reviewed bank has not been psychometrically calibrated or independently certified as equivalent to the provider examination.

### IC32

[Public ISA course topics with original engineering instruction](https://www.isa.org/training/course-description/ic32) — Public programme checked 2026-09-19; checked 2026-09-19.

Modules and objective IDs below are authored instructional subdivisions, not official exam weightings. Public course themes are mapped; proprietary examination blueprints and licensed normative clauses are not reproduced.

- No provider endorsement or predicted examination pass score.

- Applicable licensed ISA/IEC 62443 editions and clause-level conformance require separate review.

- NIST SP 800-82 Rev. 3 is final; Rev. 4 was a pre-draft call for comments at source review.

### CDCP

[EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4) — Public scope checked 2026-09-19; author-defined chapter identifiers; checked 2026-09-19.

Original instruction mapped to public subject areas. Public information is not an item-level examination specification; no claim of provider endorsement or actual examination replication.

- Detailed examination weighting and proprietary learning materials are not publicly verified.

- National requirements and equipment-specific limits must be supplied for actual installation.

- This author-reviewed bank has not been psychometrically calibrated or independently certified as equivalent to the provider examination.

### CDFOS

[EPI public course syllabus; original independent study programme](https://www.epi-ap.com/services/1/3/136) — Public outline checked 2026-09-19; checked 2026-09-19.

Maps the public syllabus into original instruction and assessment. Provider examination weighting and protected training materials are not reproduced. These are original practice questions, not actual examination questions.

- Public outline does not disclose the full protected provider curriculum or item bank.

- App study does not award a credential or replace provider eligibility, required examinations, equipment access or field authority.

### CCNP-DC

[Five mandatory curriculum courses mapped to official DCCOR/DCACI/DCID/DCIT v1.2 and DCNAUTO v2.0 public objectives](https://www.cisco.com/site/us/en/learn/training-certifications/certifications/datacenter/ccnp-data-center/index.html) — DCCOR/DCACI/DCID/DCIT v1.2; DCNAUTO v2.0; checked 2026-09-19.

All five official public examination outlines were readable on the checked date. The curriculum requires all five full courses, not merely the core plus one concentration. Original authored instruction and assessment are mapped to source sections; completion still requires supported practical implementation and independent content/evidence review.

- Synthetic configurations and outputs are teaching exhibits, not results captured from executed Cisco equipment. Exact feature support, syntax, licensing and interoperability require the selected platform release documentation.

- Authored instruction and questions require external Cisco platform practice and independent review; bank size alone does not demonstrate exam readiness or engineering competence.

- Chapters 092–104 add release-pinned protocol and platform depth. NDO 4.2(x), NDFC 12.1.2e and NDI 6.3.1 are documented teaching baselines; exact host/controller/device interoperability must be checked. Chapter 098 explicitly uses APIC 5.2(x) feature assumptions while earlier APIC 6.x examples retain their original labels.

### GICSP

[GIAC public certification objectives](https://www.giac.org/certifications/global-industrial-cyber-security-professional-gicsp/) — Public objective groups checked 2026-09-19; provider supplies no numbered objective version on the page; checked 2026-09-19.

Original instruction mapped to every public objective group. Authored atomic objective IDs are not GIAC IDs. Public groups do not expose a complete item-level examination blueprint or weighting; no official equivalence or readiness guarantee is asserted.

- No paid SANS teaching or actual GIAC questions are reproduced.

- Synthetic evidence exercises and offline programs do not replace the practical fluency required for the current registered examination.

- The provider determines examination format and award; consult the rules for the registered attempt.

- The course covers every public objective group through original teaching and assessment; public groups do not establish exhaustive private exam coverage or replace vendor-specific hands-on competence. The current public Modbus specification links were verified during final source review. FieldComm technology-page retrieval was denied during source checking, so product details require current authorised documentation.

### GRID

[GIAC public certification objectives](https://www.giac.org/certifications/response-industrial-defense-grid/) — Public objective groups checked 2026-09-19; provider supplies no numbered objective version on the page; checked 2026-09-19.

Original instruction mapped to all seven public objective groups, including Visibility and Asset Awareness. Authored atomic objective IDs are not GIAC IDs. Public groups do not expose complete item-level examination weighting; no official equivalence or readiness guarantee is asserted.

- No paid SANS teaching or actual GIAC questions are reproduced.

- Synthetic evidence exercises and offline programs do not replace the practical fluency required for the current registered examination.

- The provider determines examination format and award; consult the rules for the registered attempt.

### CISSP

[ISC2 CISSP public exam outline (effective 15 April 2024)](https://www.isc2.org/certifications/cissp/cissp-certification-exam-outline) — Public outline effective 2024-04-15; checked 2026-09-19; checked 2026-09-19.

Original instruction across all eight CISSP domains, with a crosswalk to all 62 numbered sections of the public outline effective 2024-04-15. Chapters teach their supporting subtopics and connect them to data-center and OT cases. This independent bank does not reproduce the adaptive examination, official item weighting or provider courseware.

- Published-section mapping identifies supporting teaching and bank questions; it is not psychometric validation or proof that every provider item format or unpublished detail is covered.

- The study sequence and question distribution are instructional choices, not a reproduction of ISC2 computerized adaptive testing or its pass scale.

- Local exercises use fictional data. Real legal decisions, equipment operation and certification eligibility require the responsible authority and current provider rules.

### CDCS

[EPI public course syllabus; original independent study programme](https://www.epi-ap.com/services/1/3/5) — Public outline checked 2026-09-19; checked 2026-09-19.

Maps the public syllabus into original instruction and assessment. Provider examination weighting and protected training materials are not reproduced. These are original practice questions, not actual examination questions.

- Public outline does not disclose the full protected provider curriculum or item bank.

- App study does not award a credential or replace provider eligibility, required examinations, equipment access or field authority.

- Rating schemes, normative limits and installation duties require their actual applicable editions and competent authorities. Examples below are supplied educational models, not certified designs or permission for physical work.

### IC33

[Public ISA course objectives mapped to independently authored engineering instruction](https://www.isa.org/training/course-description/ic33) — Public outline checked 2026-09-19; checked 2026-09-19.

Public course topics, not a reproduced proprietary examination blueprint. Authored objective identifiers are local subdivisions. Original cases use public NIST engineering guidance; licensed ISA/IEC 62443 requirements and paid ISA teaching are not reproduced.

- No ISA endorsement, actual examination items, credential award, or pass guarantee.

- A licensed applicable edition of the standards and qualified assessment are required for clause-level conformance and security-level claims.

- NIST SP 800-82 Revision 3 is the final OT baseline used; Revision 4 predraft activity is not a replacement final standard.

- The CISA CSET service page returned HTTP 403 during review; the official cisagov/cset repository was retrieved. No CSET software was executed, and no proprietary standards content was copied.

### IC34

[Public ISA course objectives mapped to independently authored engineering instruction](https://www.isa.org/training/course-description/ic34) — Public outline checked 2026-09-19; checked 2026-09-19.

Public course topics, not a reproduced proprietary examination blueprint. Authored objective identifiers are local subdivisions. Original cases use public NIST engineering guidance; licensed ISA/IEC 62443 requirements and paid ISA teaching are not reproduced. Thirteen local crosswalk rows map the ten public learning objectives and additional public exercise scopes. These rows are instructional mappings, not a proprietary examination-content denominator. The course extends the public outline with independent technical cases and an executable offline model.

- No ISA endorsement, actual examination items, credential award, or pass guarantee.

- A licensed applicable edition of the standards and qualified assessment are required for clause-level conformance and security-level claims.

- NIST SP 800-82 Revision 3 is the final OT baseline used; Revision 4 predraft activity is not a replacement final standard.

- The public ISA page uses inconsistent lifecycle and acceptance-test acronym expansions across sections. This course uses explicit security-engineering, factory-acceptance and site-acceptance terminology; it does not infer a separate proprietary syllabus from those inconsistencies.

- Security-level validation against ISA/IEC 62443-3-3 remains an external licensed-standard and competent-assessment exercise. Passing these authored cases is not a security-level determination.

- The offline Python lab was executed against synthetic inputs. Its 46 reference requirement fixtures and 12 self-tests passed. It does not implement production TCP reconstruction, cryptographic certificate validation, native Modbus authentication, real firewall session control or process-safety validation.

- Vendor configuration and API examples have declared platform assumptions and are synthetic or proposed exercises. Their presence is not a claim that vendor systems were executed or certified in this build.

### IC37

[Public ISA course topics with original engineering instruction](https://www.isa.org/training/course-description/ic37) — Public programme checked 2026-09-19; checked 2026-09-19.

Modules and objective IDs below are authored instructional subdivisions, not official exam weightings. Public course themes are mapped; proprietary examination blueprints and licensed normative clauses are not reproduced.

- No provider endorsement or predicted examination pass score.

- Applicable licensed ISA/IEC 62443 editions and clause-level conformance require separate review.

- NIST SP 800-82 Rev. 3 is final; Rev. 4 was a pre-draft call for comments at source review.

### ISA-EXPERT

[Original integration review across IC32, IC33, IC34 and IC37](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program) — Provider programme checked 2026-09-19; authored integration syllabus 1.0; checked 2026-09-19.

ISA awards Expert automatically after its four specialist certificates. These modules, objectives and 500 questions are original integration teaching and review, not a fifth official exam or provider exam blueprint.

- No official exam weighting, provider endorsement or pass guarantee is claimed.

- Licensed standards and applicable edition-specific clause review remain external.

- Synthetic laboratories do not establish vendor-device or physical commissioning competence.

### CCIE-DC

[CCIE Data Center v3.1 programme and equipment baseline](https://www.cisco.com/site/us/en/learn/training-certifications/certifications/datacenter/ccie-data-center/index.html) — v3.1 programme; equipment publication retrieved 2026-09-19; checked 2026-09-19.

Expert preparation builds on all five CCNP course modules. The programme page and official equipment list were retrieved; the interactive leaf-objective page returned CSS errors. Authored objective IDs below are not represented as official blueprint numbering.

- Complete official leaf-objective reconciliation remains unresolved because the topic page was inaccessible.

- Original analytical exhibits and independent vendor workbooks do not reproduce the Cisco examination or replace licensed platform practice.

- Current production features beyond the published baseline are identified as extension topics.

### NETWORK-ENGINEERING

[Curriculum Data Center Rev 14 NET-01–10 and CN-01–08 independent engineering scope](https://www.rfc-editor.org/) — Authored curriculum capability course; not a separate certification; checked 2026-09-19.

This course extends the data-center vendor courses into independently assessed campus, WAN/Po P, wireless/NAC, hybrid, AI and industrial networking. Authored objectives map capability outcomes rather than an invented exam blueprint.

- Real RF surveys, fiber measurements, vendor controller integration and physical maintenance require actual equipment.

- Full Cisco SISE and the specified NVIDIA and vendor courses remain assigned teaching; this authored course does not claim to reproduce their paid materials.

- Full profession-level readiness also requires the separately assigned vendor courses and independently accepted practical/operating evidence; a mapped capability or question count is not proof of mastery.

### HARDWARE-ENGINEERING

[Curriculum Rev14 §09.2: mandatory HW-01 through HW-10](https://www.dmtf.org/standards/redfish) — Curriculum Rev14 / Portfolio v2.5; authored 2026-09-19; checked 2026-09-19.

Original instruction for the ten mandatory hardware outcomes in the retained curriculum. The URL is a technical reference, not a public copy of the private curriculum. This is an engineering extension, not an additional certification or an assertion of practical competence.

- Exact component compatibility, installation, fault thresholds, hot-swap support and firmware recovery are model-specific and require the applicable OEM documentation.

- Synthetic exercises establish analytical performance only. Real installation, authorized component replacement, supported firmware work and sacrificial-media sanitization require separate observed evidence.

### CONTROLS-ENGINEERING

[Curriculum Rev14 OT-01–10 and CN-01–08; Charter Rev3.5; Portfolio Rev2.5](https://www.sitrain-learning.siemens.com/en/rw1105/Online-Training-SIMATIC-Programming-1-in-TIA-Portal) — Original teaching extension, 2026-09-19; checked 2026-09-19.

The governing scope is the supplied curriculum and charter, not a vendor examination blueprint. Original teaching, worked examples, guided practice and assessment connect directly to its OT and controls-networking outcomes. Public technical references support implementation details; they do not replace the assigned full teaching routes.

- The local Python lab is an illustrative bounded model, not an IEC 61131 runtime, Siemens PLCSIM, an electrical protection test or a physical commissioning record.

- D1 civil/structural/architectural engineering remains excluded; D2/D3 power and mechanical work is near-term interface integration, with specialist design and switching authority separate.

- Vendor licenses, required external courses, selected equipment, supervised physical work and review remain explicit access/evidence gates.

## Files and deployment

The project contains offline books in docs/academy, Anki decks in exports/course-decks, executable exercises and workbooks in course_labs, source/objective/question registers in exports, and evidence templates in templates/evidence. README.md explains local use and GitHub/Streamlit deployment.

Upload the extracted project contents to seejovin/datacenter, then choose app.py and Python 3.12 in Streamlit Community Cloud. No API keys are required. This delivery provides the project files; it does not claim a GitHub push or public deployment.
