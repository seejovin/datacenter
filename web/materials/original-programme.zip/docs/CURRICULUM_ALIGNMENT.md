# Programme alignment, course coverage and evidence gates

This programme uses **proficiency and engineering outcomes as its main structure**, with certificate routes as another view of the same material. That matches your charter: the goal is to engineer and sustain networks, hardware, controls and cybersecurity throughout their lifecycle. The certificates support that goal, but their boundaries overlap and do not collectively replace the required practical evidence.

The controlled requirements are your **Charter Revision 3.5**, **Curriculum Data Center Revision 14**, and **Portfolio Architecture and Evidence Plan Version 2.5**. The companion Track 1/MUDT Revision 8 is referenced by those documents but was not supplied for this implementation. Its completion is not assumed. Your existing CCNA study remains an external foundation that can be reused after assessment.

## What the expanded programme supplies

The earlier overview prototype was insufficient for the requested programme. Its 88 orientation lessons are preserved as optional preparation. The new courses provide their own modules, chapters, worked demonstrations, guided exercises, objective-linked question banks and independent tasks. Old overview checkpoints remain separate from course checkpoints.

Fourteen credential-related banks cover the planned items #2–#15 at a minimum of 500 original questions per bank. CCNP has over 1,000 questions across all five retained courses: DCCOR, DCACI, DCID, DCIT and DCNAUTO. CCIE adds integrated design, implementation, diagnosis and recovery preparation after those foundations. ISA Expert is an integration pathway over its four specialist certificates, with its own study bank rather than an invented additional provider exam.

Three engineering extensions retain networking beyond the data center, all ten mandatory hardware outcomes, and controls engineering. Their purpose is to supply teaching for identity requirements that the certificate list alone cannot close. Exact chapter, question and flashcard counts are in `exports/course-inventory.csv` and `exports/content-manifest.json`.

| Dimension | Supplied material | Completion evidence still required |
|---|---|---|
| Requirements | All forty NET/HW/OT/SEC outcomes and eight CN assignments, with work packages and acceptance criteria. | Demonstrate each outcome at the required environment and independence. |
| Instruction | Separate course teaching, mechanisms, examples, guided work and referenced platform workbooks. | Complete retained provider instruction, model-specific demonstrations and access-dependent practice where required. |
| Assessment | Original questions, evidence interpretation, calculations, diagnosis, sequencing and objective diagnostics. | Unfamiliar practical performance, external examinations and independent review. |
| Practical work | Local executable exercises, platform assignments, evidence templates and operating campaigns. | Execute equipment and field work and retain measured results, defects, retests and accepted decisions. |
| Source traceability | Dated course baselines, authored objective registers and detailed source crosswalks where retrievable. | Revalidate current provider scope and resolve course-specific unpublished or inaccessible blueprint limits. |
| Learning records | Separate course checkpoints, orientation history, recall and self-reported evidence. | Provider-awarded credentials and controlled, independently reviewed portfolio records. |

The app is a substantial independent teaching and practice programme. **It is not evidence that all proprietary course content has been reproduced, every examination leaf has been independently verified, or a learner is already competent.** Course-specific scope records make those distinctions visible. The complete public CCNP leaf list has a crosswalk; broader public outlines are used where providers do not expose comparable detail. Counts describe the supplied inventory, not a guarantee of examination success.

Use **Programme → course → module → chapter → guided practice → assessment → independent task**. Return to the curriculum outcome and work package to judge the evidence needed. A high quiz score does not waive a physical, platform, experience or review requirement.

## Why the hybrid structure fits your documents

Your charter defines a capability target, while the curriculum supplies teaching routes and the portfolio defines acceptance. Consequently, the app follows **Charter → learning outcome → lesson and practice → work package → test/event → evidence → review → claim**.

A certificate-only structure would repeat shared subjects such as network boundaries, risk, maintenance and recovery. It would also make independently required campus, PoP/edge, wireless, storage, controls and hardware outcomes harder to track. For example, a DC-networking credential is not evidence of real RF survey work, a PLC course is not a server-repair assessment, and an OT-security certificate is not proof that a restored control application has correct physical behaviour.

The programme reuses foundations and adds separate implementation, diagnostic and assessment sequences where systems and objectives differ. Courses contains the authored credential material; Certificates provides an additional planning and relevance view. No certificate is automatically treated as proof of an outcome unless its underlying evidence meets that outcome's criteria.

| Proficiency progression | Required learning emphasis | Practical expectation |
|---|---|---|
| Foundation | Explain systems, units, dependencies, failure paths, measurements, controls and baseline security. | Start bounded physical work, verification and simple restoration early. |
| Applied | Implement supported platforms, commission functions, diagnose faults and control changes. | Independently demonstrate the named outcome with raw results, defects/retests, rollback and restoration. |
| Advanced | Resolve ambiguity across domains, quantify uncertainty, justify acceptance and validate automation. | Accept cumulative releases, repeat lifecycle events, prove trusted recovery and measured improvement, and obtain independent review. |

All nine lifecycle responsibilities apply at every stage: **design, implementation, commissioning, day-to-day operations, maintenance, optimisation, troubleshooting, incident response and recovery**. Advanced study increases difficulty and independence; it does not defer operations or recovery until the end.

## Scope remains faithful to the charter

| Domain | Treatment |
|---|---|
| D4 — networks | Principal specialisation. Independently assess physical media, enterprise/campus, DC/ACI/EVPN, PoP/WAN/edge, hybrid connectivity, wireless/NAC, storage, AI fabrics and controls communications. |
| D5 — hardware | Mandatory and integral. Real installation and repair remain compulsory; advanced effort concentrates on compatibility, integration, diagnosis, validation and accept/hold/reject decisions. |
| D6 — OT and controls | Principal specialisation. Cover requirements, instrumentation, PLC/DDC applications, dynamics, power/cooling interfaces, supervisory systems, DCIM/CMMS, protocols and sustaining work. |
| D7 — cybersecurity | Principal specialisation. Protect, observe, assess, defend and recover OT, networks and infrastructure IT, including identities, firmware and hardware management. |
| D2/D3 — power/cooling | Required foundations and integration now. Full specialist engineering is a separate long-term acceptance gate. |
| D1 — building engineering | Excluded from both horizons. Retain only external building/site constraints and interface owners. |

Equal outcome counts do not assign equal study time. D4, D6 and D7 require sustained specialist study, implementation and operating experience. D5 foundations should be learned efficiently and then used in decision-rich shared cases; task repetition is not the professional differentiator. A supported hardware management tool, CMMS or BMS is reused rather than rebuilt. Supporting hosts and services remain in scope without creating a separate cloud/workload-platform or AI-model specialisation.

## Teaching assignments are preserved

The machine-readable register in `content/programme.json` retains the actual assignment scope and source links from the supplied curriculum. These inherited references are dated curriculum selections; their current delivery conditions are not newly verified by reproducing a link.

| Curriculum assignment | Retained purpose |
|---|---|
| Items 1–12 | Shared CCNA, facility, PLC/BAS, industrial communications, Windows/Hyper-V and Ignition foundations. |
| Items 13–26 | Network/OT security, reliable MQTT, SQL, historian/database and host lifecycle work, CDCP and CDFOS. |
| Items 27–38 | Sequences, vendor controls engineering, field equipment, EPMS, industrial resilience, protocols and timing. |
| 03A | Siemens PRO/SCL/service progression with assessed entry and explicit PLCSIM Advanced instruction/access still to arrange. |
| 03B | Sunbird end-user and administrator learning, including agreed lifecycle outcomes and continuing application access. |
| 03C | Selected CMMS work management plus separately assigned administration, integrations and recovery. |
| CN-01–08 | Controls-network requirements, resilience, protocols/time, management, virtualised services, day-two work, automation and bounded AI/MCP diagnostics. |
| Items 39–45 | OT incident decisions, recovery dependencies, compromised identity, technical restoration, authorised assessment and exercise improvement. |
| Items 46–51 | All retained DCCOR, DCACI, DCID, DCIT, DCNAUTO and SISE learning, beyond one concentration examination. |
| Items 52–58 | Advanced OT security, ISA lifecycle learning, GRID/GICSP/CISSP support, AI infrastructure and the independent CCIE preparation target. |
| Items 59–65 | Validated models, workload/power/heat, capacity and dependencies, cooling, telemetry/uncertainty, constrained optimisation and continuous assurance. |
| 07A and NCP-AIN | Bounded AI hardware/rack/infrastructure work and independently assessed Ethernet/RoCE and InfiniBand networking. |

T-NET, T-HW and T-SEC routes retain the additional enterprise, wireless, hardware and security teaching specifications. T-LAB-01–06 are explicit instructor/equipment assignments, not invented public course titles. Product-specific Modbus, BACnet MS/TP, MMS/GOOSE, physical timing, selected management/security tools, Redfish video titles and AI/MCP instruction must be pinned where the curriculum leaves them unresolved.

No app lesson completion silently waives a paid provider's attendance or exam prerequisite. Document equivalent knowledge to avoid duplicate teaching purchases, while checking credential eligibility independently.

CDCS, IC33 and IC34 remain required credential targets even though they do not have separate numbers among Items 1–65. Their additional routes are preserved from Curriculum §06A; the source explicitly requires provider-route revalidation. The certificate pages carry the separate exam-planning view.

## Evidence and release gates

The six portfolio releases are cumulative engineering releases, not the three proficiency levels:

| Release | Acceptance focus |
|---|---|
| 0 — Governance | Controlled requirements, traceability, test plans, evidence identity, versioning, review and publication boundaries. |
| 1 — OT, hardware and facility integration | Correct physical/control behaviour, verified instrumentation, actual managed hardware, commissioning and restoration. |
| 2 — Networks | Each independent network branch passes its own service, security, failure and recovery tests. |
| 3 — Cybersecurity | Protection, detection, incident handling and restored function with malicious authority removed. |
| 4 — Operations | Repeated normal checks, maintenance, controlled and failed changes, fault/incident response, restoration and measured improvement. |
| 5 — Automation and assurance | Repeatable automation, tested authority boundaries, validated models, uncertainty, rejected invalid actions and operational benefit. |

The register also retains all **16 cumulative practical case assignments** from Portfolio Sections 13 and 21.6. Interactive cases in the app rehearse decisions; the practical assignments require executed work and evidence. Shared work can support several outcomes only when each has its own criteria and explicit evidence links.

For **each D4–D7 domain**, maintain an operating campaign that contains repeated normal checks, an abnormal condition, actual maintenance, a planned change, a failed or rolled-back change, a diagnosed fault, security validation and an applicable incident, restoration, and a measured improvement. The network campaign must cover each declared branch. The documents prescribe events and evidence, not an invented number of weeks or a universal performance threshold. Define numerical limits from the service requirement and supported equipment before testing.

Required physical evidence includes real managed server/storage installation and authorised FRU replacement, supported storage and independent restoration with synthetic data, real cabling/optical and RF measurements for corresponding claims, and a safe physical sensing/actuation/control loop. Advanced accelerator/fabric/timing access remains an open dependency until obtained. A virtual rack or emulator cannot demonstrate a physical task.

Every HW work package also records its engineering decision: applicable requirement and OEM version, proposed/installed state, evidence, competing explanation, consequence, accept/hold/reject/escalate disposition, correction/retest and authority. Demonstrate both rejection of plausible incorrect work and acceptance of correct work. Do not execute an unsafe proposal to prove it is wrong.

Use the templates in `templates/evidence/` to maintain that record. The app's personal notes are self-reported study records; they do not establish independent acceptance. Keep raw results and reviewer decisions under controlled storage outside a transient web session.

## What establishes completion

The course inventory, source mappings and work packages make the programme inspectable. Study the material, complete the exercises, resolve source and platform access limits, and assess performance against each work package. A mapped chapter supplies support; accepted evidence determines whether the requirement is met.

Before claiming near-term programme completion, verify complete teaching and assessment coverage, then review all 48 outcomes, Releases 0–5, physical work, the domain operating campaigns, incident/trusted recovery, validated automation and measured improvement. Obtain independent review or reproduction for major releases. Identify remaining field/production experience and professional-authority gaps explicitly. Recheck each certification's current full blueprint and eligibility separately.

The long-term D2/D3 hand-off requires a new, independently reviewed specialist teaching and supervised-practice plan across the same nine lifecycle responsibilities. Operating EPMS, BMS or a model is valuable integration evidence; it is not specialist ownership of the electrical or cooling installation. D1 remains excluded. Company delivery capability and contracted authority are separate from personal study.

**Controlled references:** Charter Rev 3.5 §§2, 4–6; Curriculum Rev 14 §§00A–00C, 03A–03D, 06A, 08–12; Portfolio v2.5 §§7–16, 21–22. The detailed per-outcome crosswalk is in `content/programme.json` and the app's Programme view.
