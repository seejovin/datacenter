> Historical Version 2.0.1 audit of the orientation prototype. The expanded course programme is documented in `../CURRICULUM_ALIGNMENT.md` and `../../exports/course-manifest.json`; this archived audit is not the current course inventory.

# Teaching depth audit

Audit date: 19 September 2026. Baseline: the existing 88-lesson app, Curriculum — Data Center Revision 14, and its retained full-course assignments. This audit concerns what the app actually teaches and tests, separately from equipment access or production experience.

## Verdict

The app is an introductory engineering companion and requirements navigator. It is **not a complete foundation-to-advanced course covering the retained certification and vendor-course scope**. The previous description of it as a sufficient advanced study programme was too strong. Keeping links to full courses does not supply their teaching; giving every broad outcome a linked lesson does not establish that its constituent knowledge and skills have been taught.

This is not just a need for more physical practice after otherwise complete theory. The theory, mechanisms, demonstrations, procedures, diagnostic examples and independent assessment are themselves incomplete. Existing useful material should be retained as orientation or synthesis lessons while the actual courses are decomposed and built beneath it.

## Measured inventory

Counts below are computed from the checked-in JSON, not inferred from a provider's teaching hours. Body words use whitespace splitting and exclude questions, sources and assignments. They measure the scale of the artifact, not competence or a percentage of blueprint completion.

| Track | Lessons | Main-body words | Median body length | Questions |
|---|---:|---:|---:|---:|
| Facility | 10 | 4,185 | 415 | 40 |
| Engineering foundations | 8 | 3,336 | 418.5 | 32 |
| Networking | 20 | 11,773 | 589.5 | 120 |
| Controls and controls networks | 18 | 10,270 | 569 | 108 |
| Hardware | 10 | 7,492 | 733 | 60 |
| Security | 14 | 11,286 | 807 | 84 |
| Integration | 8 | 4,952 | 624.5 | 48 |
| **Total** | **88** | **53,294** | — | **492** |

Additional observations:

- Main bodies, worked examples and guided-practice fields together contain approximately 69,517 whitespace-separated words; this is not 69,517 words of distinct technical instruction.
- The catalogue allocates 4,295 lesson minutes: 71 hours 35 minutes. Full external-course assignments are additional and are not delivered by those estimates.
- The CCNP Data Center route reuses 23 app lessons containing 15,043 main-body words. The CCIE Data Center route reuses 20 containing 13,708. These totals overlap with other routes and must not be added into a claimed volume of independent teaching.
- All 492 lesson questions are multiple choice: 428 single-answer and 64 multiple-answer. There are 192 three-option questions and 300 four-option questions.
- No lesson question prompt contains a multiline exhibit, configuration block or tabular exhibit. None of the 88 main bodies, worked examples or guided-practice fields contains a fenced code/configuration block. No lesson has a populated diagram field.
- There are eight branching decision cases comprising 36 decision steps, and four separate synthetic JSON-data exercises. These supply some evidence-based reasoning but do not constitute course-wide practical teaching.

## Findings

### 1. A requirements map has been mistaken for a taught syllabus

`programme.json` maps 40 broad NET/HW/OT/SEC outcomes and eight CN outcomes to app lessons. Each outcome is a substantial capability bundle, not one lesson-sized objective. Linking it to a body and a work-package assignment establishes a destination, not adequate instructional coverage.

For example, Curriculum Revision 14 Items 46–50 explicitly retain **full DCCOR, DCACI, DCID, DCIT and DCNAUTO teaching**. One certificate card collects all four concentration-course names in one topic group. That group is a navigation heading, not four implemented courses. The same issue affects the full SANS, ISA, CISSP and vendor-platform commitments.

Required correction: decompose each retained course and independent engineering requirement into teachable objectives, with separate states for absent, orientation only, taught, demonstrated and independently assessed. Do not award complete coverage because a keyword or broad outcome ID appears.

### 2. Lesson granularity collapses entire subjects into short summaries

`L-OT-03` covers PLC scan/task behaviour, function/function-block/data-block distinctions, state machines, timers, retained state, typed interfaces, tool/firmware versioning, online change, simulation, commissioning and recovery in **585 body words**. Its teaching links then assign TIA-PRO1, PRO2, SCL1 where required, PRO3, SERV2 and SERV3. The app has not delivered that sequence.

`L-CN-03` uses **568 body words** to discuss BACnet/IP, MS/TP, Modbus TCP/RTU, OPC UA, MQTT, IEC 61850 MMS/GOOSE, SNMP, syslog, NTP/PTP and IRIG-B. These need separate conceptual and implementation sequences, not one combined protocol survey.

Required correction: promote these broad units to chapters or overview pages. Build separate lessons on mechanisms, normal transactions, configuration, verification and faults before cross-protocol comparison and integration.

### 3. The learner is told what to do without being shown how

The PLC assignment says “Build typed blocks and independent instances.” No complete block, state-transition implementation, timer trace, input/output mapping or reproducible vendor project is supplied. The networking and security lessons similarly request versioned configurations, detections and restoration evidence without supplying a course-wide progression of worked implementation artifacts.

A student cannot reliably progress from an explanation of the importance of independent instances to independently implementing, debugging and restoring a controller application. Prerequisite provider courses may supply that missing instruction, but the app must say they supply it and track the actual teaching sequence.

Required correction: every implementation objective needs a versioned, reproducible demonstration, a guided exercise with intermediate checks and a genuinely different independent task. Include expected observations and explanations of failed states, not only a final answer paragraph.

### 4. Advanced labels are not supported by advanced technical treatment

`L-OT-04` explains P/I/D, windup, sampling and process delay but gives no controller implementation, discrete-time update, complete output trace, tuning comparison or reproducible response dataset within the lesson. Its first advanced question asks the learner to subtract an eight-second delay from 38 seconds.

`L-INT-03` asks an advanced question consisting of `2 × 4.18 × 5`. The calculation is useful foundation material; its level label does not create advanced mastery. The lesson's more meaningful uncertainty calculation deserves retention, but it does not replace the missing cooling/control prerequisite sequence.

Required correction: establish prerequisite conceptual depth, then assess advanced difficulty through multi-stage reasoning, unfamiliar evidence, competing explanations, measured constraints and justified design decisions. Difficulty must be established by the task, not inherited from the lesson label.

### 5. Security content is disproportionately assurance advice rather than full technical instruction

`L-SEC-03` provides useful identity-lifecycle and recovery principles, but its approximately 800-word treatment cannot teach PKI design, enrollment, chain building, name/usage validation, trust-store operation, status handling, certificate renewal, service authentication and implementation-specific diagnosis. Its worked example reports a revocation delay; it does not show how to inspect or fix the underlying validation path.

`L-SEC-06` explains detection design and precision/recall, but supplies no implemented detection, parser, event-query sequence or packet-decoding exercise within the lesson. `L-SEC-13` combines architecture, isolation, secure development, testing and supply-chain principles in 850 words. A CISSP domain mapping to these summaries is relevance, not delivered domain breadth.

Required correction: build separate technical sequences for identity/PKI, protocol visibility, host/controller evidence, detection development, investigation and trusted recovery. Preserve full non-OT security breadth where required by the certification route instead of treating a DC example as coverage of its entire domain.

### 6. Many questions are easily solved by rejecting implausible distractors

The security questions repeatedly contrast one sensible answer with obviously invalid claims. In `L-SEC-03`, a valid TLS session is followed by options including “Whether encryption automatically calibrated the sensor.” In `L-SEC-06`, a stale dashboard question offers “Every constant value proves a cyberattack” and “Encryption automatically proves freshness.” In `L-INT-06`, the model-purpose question offers “Use the most expensive simulation tool” and “Produce a smooth dashboard.”

These can check orientation, but a learner can answer them without performing the underlying technical work. High scores therefore say little about depth. Several distractors test rejection of absolute wording rather than discrimination among plausible diagnoses or designs.

Required correction: retain simple diagnostic questions only at the appropriate stage. Use plausible alternatives based on specific misconceptions, configuration semantics, calculations and observations; explain precisely why each fails under the stated conditions.

### 7. Assessment lacks variety, independent transfer and adequate objective sampling

Every non-foundation lesson has six questions regardless of how many mechanisms it compresses. The protocol survey and PLC lifecycle lesson each receive six MCQs despite encompassing numerous independent technical objectives. Worked examples are sometimes directly reused: the PID time-constant numbers and precision/recall example reappear in questions with essentially the same task.

The 80% learning checkpoint is an app policy, not evidence that an outcome with many untested subskills has been mastered. Repeating a small fixed bank can improve the score without revealing unseen weaknesses. The four JSON exercises add useful variation but are too few to change the overall assessment architecture.

Required correction: map questions and tasks to atomic objectives and cognitive demands; include fresh values and unseen exhibits; use calculations, packet/configuration interpretation, ordering, fault isolation, design critique and practical validation. Separate practice items from independent checkpoints and use coverage-qualified results rather than broad outcome mastery labels.

### 8. Practical work packages are mostly assignment briefs, not runnable learning units

The hardware content gives comparatively useful compatibility and acceptance examples. However, assignments such as physical BMC commissioning, supported firmware update and restoration still need model-specific baselines, observed command/API outputs, guided interpretation and controlled fault examples before the independent work begins.

The four bundled data exercises are narrow static cases. They do not provide the numerous startup configurations, network topologies, controller projects, protocol captures, telemetry sets, host records and restored-state comparisons required by the retained courses. A checklist asking for these artifacts is not the artifact or the teaching.

Required correction: package reproducible analytical/emulated work where feasible and supply complete observation sets where a vendor lab cannot be bundled. State lab entitlements and equipment needs precisely. Keep practical access limits separate from omissions in the app's own instruction.

### 9. External teaching is acknowledged but incompletely operationalised

The course register correctly preserves full provider courses and often marks teaching edition, actual lessons and access as unverified. Some teaching resources explicitly say to pin actual video titles before study or arrange an instructor demonstration. Those are unresolved teaching-design tasks, not a finished video-led learning pathway.

Curriculum Revision 14 contains exact assignments in places: RealPars PLC lesson ranges; CODESYS sections 1–9; MQTT sections 1–8; named Ignition modules; and complete Cisco and specialist-security courses. These should become navigable, prerequisite-aware study units with the app's supplementary teaching and checks attached at the right point. Merely displaying their names in a sources tab leaves the learner to assemble the course.

Required correction: distinguish app-authored instruction from external required instruction. For each required segment, record the verified provider title/module, prerequisites, access, demonstration, guided exercise, independent assessment and remaining unassigned gaps. Do not invent unavailable provider lesson numbers.

### 10. Repeated general principles crowd out missing subject-specific mechanisms

Across domains, the same valid principles recur: preserve evidence, distinguish transport from application, respect authority, verify restoration, state uncertainty and avoid unsupported claims. These are important synthesis themes. Their recurrence does not compensate for missing subject-specific teaching and should not be counted as independent coverage each time a lesson is mapped to another credential.

Required correction: retain shared principles once as reusable prerequisites, revisit them through progressively harder technical cases, and spend course space on the mechanisms and operations unique to each subject. Certificate routes should assemble required common and specialised units without either needless duplication or false equivalence.

## Rebuild acceptance criteria

A replacement should not be accepted merely because it has more lessons or words. Before calling a course complete, require:

1. A dated, source-grounded objective inventory with no unexamined course-sized headings standing in for detailed coverage.
2. Foundational explanations that support the promised implementation work without silently assuming untaught concepts.
3. Mechanism-level treatment and worked demonstrations for every implementation/diagnosis objective.
4. Guided exercises with intermediate observations and a distinct independent assessment.
5. Supplied artifacts or a precise external lab route with all access and prerequisite requirements visible.
6. Questions that distinguish plausible alternatives and sample the actual objective breadth.
7. Traceability from requirement and course objective to instruction, exercise, assessment and evidence; absent items remain absent.
8. Independent technical review of representative difficult units and an audit of all coverage claims.

This audit establishes a substantial gap. It does not quantify the missing material as a multiple of the current app or claim a completion percentage; that requires an atomic objective inventory against the applicable provider editions.
