> Historical Version 2.0.1 audit of the orientation prototype. The expanded course programme is documented in `../CURRICULUM_ALIGNMENT.md` and `../../exports/course-manifest.json`; this archived audit is not the current course inventory.

# Cisco teaching-depth audit

Audit date: 19 September 2026. Scope: the delivered 88-lesson app, Curriculum Data Center Revision 14, and current public Cisco sources. This is a substantive gap audit, not a complete leaf-objective certification audit.

## Conclusion

The app does not contain the full Cisco study programme required by the curriculum. It contains short conceptual introductions, useful engineering acceptance principles, recall questions, and assignments directing the learner to obtain most of the necessary teaching elsewhere. The earlier description of this as a sufficient advanced study programme was not supported by its instructional content.

Mapping a lesson to NET-03 or to DCCOR/DCACI/DCID/DCIT/DCNAUTO does not show that those courses have been taught. The current mapping conflates a broad requirement reference with instructional coverage.

## What was inspected

The audit read the fabric, storage and automation lesson bodies, worked examples, guided solutions, questions and practical assignments in `content/network_advanced.json`; the Cisco certificate routes; relevant supporting hardware lessons; and Curriculum Items 46–51 and 58. It compared these with Cisco's published course outlines, public labs, exam documents and programme pages. Gaps below mean the inspected app lacks the necessary teaching or demonstrated assessment, not that a term never occurs anywhere in the repository.

The network file contains 20 units and 120 questions. Its teaching bodies total approximately 11,773 whitespace-delimited words; including worked examples and guided-practice fields gives approximately 15,714. This excludes questions, flashcards, source links and external assignment instructions. Word count is a scale check, not a measure of instructional quality.

| App area | Delivered teaching scale | Assessment limitation |
|---|---|---|
| EVPN/VXLAN and ACI, L-NET-03 / 03X | Two bodies totalling 1,173 words; 1,549 with worked/guided fields | Twelve questions across two broad technologies; no executable NX-OS/APIC build or actual command-output interpretation exercise in these units |
| FC and IP storage, L-NET-07 / 07X | Two bodies totalling 1,192 words; 1,578 with worked/guided fields | Twelve questions; largely path, identity, latency and recovery reasoning, without full MDS/UCS storage implementation instruction |
| Automation and assurance, L-NET-10 / 10X | Two bodies totalling 1,252 words; 1,661 with worked/guided fields | Twelve questions; policy and workflow principles, without the required Cisco API/IaC implementation sequence |

The generic hardware content teaches useful compatibility, integrity, recovery and diagnostic reasoning. For example, L-HW-04 distinguishes RAID, multipathing, replication and backup. That is not equivalent to teaching UCS Manager, fabric interconnect configuration, identity pools, service-profile deployment or Intersight operations.

Some distractors make questions easier than their labels suggest. An EVPN question asks which attribute controls import/export; alternatives include an interface description, optic serial number and route age. An oversubscription question asks for 1,200/600. These can check initial understanding, but they do not assess professional fabric implementation or fault isolation. More variants of such questions would not close the gap.

## The curriculum requires more than the minimum credential route

Curriculum Items 46–50 assign **full DCCOR, DCACI, DCID, DCIT and DCNAUTO teaching**. Item 46 explicitly includes designated self-study sections and prerequisite server, virtualisation, SAN and Fibre Channel foundations. Item 51 independently requires full SISE. Item 57 requires both DCAIE and DCAIAOT; Item 58 requires the complete applicable CCIE Data Center blueprint and practical preparation. NET-01–10 additionally retain independent campus, edge, wireless, hybrid, storage, AI and controls-network capability.

Cisco's credential rule remains a core exam plus one concentration, while CCIE adds a practical lab to its qualifying core requirement. That minimum credential rule cannot reduce the user's full-course learning commitments. [CCNP programme](https://www.cisco.com/site/us/en/learn/training-certifications/certifications/datacenter/ccnp-data-center/index.html), [CCIE programme](https://www.cisco.com/site/us/en/learn/training-certifications/certifications/datacenter/ccie-data-center/index.html).

## Concrete instructional gaps

**DCCOR:** Cisco's public training overview lists 27 course-outline blocks and 19 labs. The app has no comparable sequence taking a learner through Nexus switching/routing, fabric configuration, MDS SAN services and UCS provisioning. Required examples include constructing a working vPC, explaining its failure states from evidence, provisioning a fabric interconnect, creating identities and service profiles, and checking resulting host connectivity. These require mechanism teaching, configuration demonstrations, output interpretation and repeatable practice. A paragraph saying that a supported implementation must be tested does not supply that instruction. [DCCOR training overview](https://www.cisco.com/c/dam/en_us/training-events/training/courses/dccor.pdf).

The DCCOR v1.2 blueprint also distinguishes compute implementation, FC fabric services, infrastructure monitoring, automation and security. Missing professional instruction includes UCS-X/Intersight relationships; FCID, FCNS, CFS, VSAN and NPV/NPIV operation; platform-specific security controls; and configuration/restore procedures. Merely adding these nouns to a lesson or a coverage row is insufficient. [DCCOR v1.2 objectives](https://learningcontent.cisco.com/documents/marketing/exam-topics/350-601-DCCOR-v1.2.pdf).

**DCACI:** The app explains tenants, VRFs, bridge domains, EPGs and contracts at an introductory level. It does not teach a fabric build from discovery and access-policy dependencies through endpoint attachment, packet forwarding, external connectivity and VMM integration. Cisco's public course labs separately exercise discovery, access policies/vPC, inter-EPG connectivity, bridge-domain forwarding, L2/L3 external connection and vCenter integration. Those are distinct learning sequences. [DCACI course](https://www.cisco.com/site/us/en/learn/training-certifications/training/courses/dcaci.html).

The current blueprint adds concrete breadth beyond the app's general policy narrative: contract variants, endpoint security groups, bridge-domain forwarding settings, service graphs, management recovery, upgrades and ACI deployment options. A complete course needs separate worked configurations and fault cases for these mechanisms rather than one migration discussion. [DCACI v1.2 objectives](https://learningcontent.cisco.com/documents/marketing/exam-topics/300-620-DCACI-v1.2.pdf).

**DCID:** App capacity calculations and acceptance decisions are useful, but do not provide the required Cisco design course. Missing instruction includes comparing fabric-interconnect modes, VIC and adapter policies, UCS deployment alternatives, interconnect choices, orchestration architecture and service-profile/template consequences. The learner needs multiple constrained design studies with defensible alternatives, calculations, failure analysis and reviews. [DCID course](https://www.cisco.com/site/us/en/learn/training-certifications/training/courses/dcid.html), [DCID v1.2 objectives](https://learningcontent.cisco.com/documents/marketing/exam-topics/300-610-DCID-v1.2.pdf).

**DCIT:** The app commonly states the suspected fault in its worked example and asks for a sensible next action. That differs from diagnosing an unfamiliar system using imperfect evidence. Required teaching must develop tool selection, command/API-output interpretation, competing hypotheses and safe corrective action across NX-OS, ACI, UCS and SAN. Cisco's course publishes a substantial troubleshooting-lab sequence covering switching, routing, storage, compute and ACI interconnections. [DCIT course](https://www.cisco.com/site/us/en/learn/training-certifications/training/courses/dcit.html).

The v1.2 blueprint requires specific investigations such as FC credit starvation, hardware/firmware interoperability, server-to-fabric packet flow, orchestration failures and security policy faults. The current twelve storage questions cannot establish those abilities. [DCIT v1.2 objectives](https://learningcontent.cisco.com/documents/marketing/exam-topics/300-615-DCIT-v1.2.pdf).

**DCNAUTO:** The app teaches good principles about idempotence, least privilege, partial deployment and rollback. It does not teach how to implement the corresponding Cisco workflows. Required instructional sequences include day-zero provisioning, on-box execution, NX-API, model-driven interfaces, NDFC, Ansible/Terraform, validation frameworks and telemetry. Students need real request/response examples, data models, working code, output, deliberately broken inputs and verification. The current official course publishes 30 lab activities; the app has no comparable executable Cisco automation workbooks. [DCNAUTO course](https://www.cisco.com/site/us/en/learn/training-certifications/training/courses/dcnauto.html).

**CCIE:** A relabelled advanced conceptual unit cannot substitute for a separate expert preparation track. Cisco lists an eight-hour v3.1 practical examination and publishes a specific equipment/software baseline. Preparation therefore needs platform access, component technology labs, integrated multi-domain builds, unfamiliar faults, design decisions, recovery and timed independent work. The app contains no complete CCIE lab environment or assessed task sequence. [CCIE programme](https://www.cisco.com/site/us/en/learn/training-certifications/certifications/datacenter/ccie-data-center/index.html), [CCIE v3.1 equipment/software](https://learningcontent.cisco.com/documents/marketing/exam-topics/CCIE-DC-3.1-equipment_and_SW_reviewed.pdf).

## Version and source findings

The public DCCOR/DCID/DCIT/DCACI exam PDFs inspected are version 1.2. Cisco's update note says these changes became effective on 21 May 2025; it also states that the separate 300-630 advanced-ACI exam would end that day. Some Cisco course and exam landing pages still say v1.1. A recent retrieval date alone cannot resolve this discrepancy. Pin the examination document, course version and lab software separately. [Cisco v1.2 update notice](https://learningcontent.cisco.com/documents/marketing/exam-topics/New_CCNP_DC_v1.2_Minor_Update_Notes.pdf).

The current DCNAUTO exam page explicitly names version 2.0. Its current course page has broader modern automation activities. Do not silently reuse an older DCAUTO outline. [DCNAUTO exam](https://www.cisco.com/site/us/en/learn/training-certifications/exams/dcnauto.html).

Course teaching scope and current examination scope are not identical. Preserve the curriculum's full assigned teaching while recording changes to examination requirements separately. Do not delete useful operating knowledge because an exam removed a technology; equally, do not market old teaching as the complete current blueprint.

**Audit limit:** Cisco Learning Network's interactive topic pages returned loading/CSS errors. Direct official v1.2 PDFs were readable for the four subjects above, but the complete CCIE leaf-objective list and DCNAUTO v2.0 PDF were not retrieved in this pass. Consequently this audit does not assert a fully verified leaf-by-leaf blueprint inventory for those two routes. It establishes substantial inadequacy without requiring that unsupported claim.

## Required course architecture

The architecture should preserve subject-based reuse while exposing substantial independent courses: prerequisites; DCCOR; DCACI; DCID; DCIT; DCNAUTO; SISE; the assigned AI courses; and CCIE preparation. Course → module → lesson → demonstration → guided exercise → independent task should be real content layers, not repeated labels over the same summaries.

For each objective, record the required action and depth, prerequisite knowledge, mechanism lesson, versioned demonstration, guided exercise, independent assessment and evidence requirement. Mark **mentioned**, **explained**, **demonstrated**, **practised**, and **independently assessed** separately. A mapping reference must never advance these states automatically.

An illustrative fabric sequence would separate encapsulation and MTU, underlay routing, BGP EVPN control state, route import/export, endpoint learning and mobility, BUM handling, tenant routing, external connectivity, redundancy and convergence, telemetry, upgrades and troubleshooting. ACI requires its own implementation sequence. This sequence is a proposed authoring structure, not a claim that all these modules have now been written.

Lesson acceptance should require enough explanation to predict behaviour, at least one complete worked implementation or evidence analysis appropriate to the objective, a guided practice with meaningful feedback, and an unfamiliar independent task. Question banks should assess discrimination between plausible faults, application of constraints, configuration/output interpretation and corrective choices. Flashcards reinforce retained concepts; they do not replace this teaching or practical assessment.

Do not declare a course complete based on a target lesson count, a quantity of generated questions, complete cross-reference coverage, or software tests passing. Instructional completeness requires objective-level content review and appropriate assessment evidence. The current app is a reusable platform and introductory supplement; its substantive professional and expert course authoring remains unfinished.
