# CCNP and CCIE source-scope review

Checked 19 September 2026. This is a source and instructional-scope review of the authored package. It does not claim that reading, question counts, crosswalk links or offline models establish practical competence.

## Verified CCNP denominator

All five assigned Cisco public outlines were retrieved in full. The inventory uses the lowest published numbered item in each branch, preserving unsplit items where the provider does not publish children. Broad outline items are not interpreted as exhaustive lists of implementation details. The canonical file contains 227 distinct provider references with valid module, lesson and question links; shared questions remain counted once.

| Assigned course | Retrieved public outline | Inventory leaves | Main authored coverage |
|---|---|---:|---|
| DCCOR | [350-601 v1.2](https://learningcontent.cisco.com/documents/marketing/exam-topics/350-601-DCCOR-v1.2.pdf) | 62 | Network, compute, storage, automation/AI and security; chapters 001–026 and shared mechanism/workbook extensions |
| DCACI | [300-620 v1.2](https://learningcontent.cisco.com/documents/marketing/exam-topics/300-620-DCACI-v1.2.pdf) | 31 | Fabric/object/access model, tenant policy, packet forwarding, external attachment, VMM, services, management and deployment choices; chapters 027–040 with shared implementation material |
| DCID | [300-610 v1.2](https://learningcontent.cisco.com/documents/marketing/exam-topics/300-610-DCID-v1.2.pdf) | 55 | Requirements and failure capacity, traditional/AI networks, compute placement/connectivity, storage and automation design; chapters 041–050 plus prerequisites |
| DCIT | [300-615 v1.2](https://learningcontent.cisco.com/documents/marketing/exam-topics/300-615-DCIT-v1.2.pdf) | 52 | Causal diagnosis across network, ACI, compute, SAN, management and automation; chapters 051–062 and protocol-specific extensions |
| DCNAUTO | [300-635 v2.0](https://learningcontent.cisco.com/documents/marketing/exam-topics/300-635-DCNAUTO-v2.0-7-9-2025.pdf) | 27 | Models/protocols, IaC, device/controller programmability, operations and AI integration; chapters 063–088 plus shared material |

DCNAUTO uses the retrieved v2.0 PDF rather than a stale landing-page version label. Its modern scope is represented explicitly: DPU and network-centric ACI/Hyperfabric context; YANG-to-payload construction; gNMI/gRPC/gNOI; ncclient; Ansible/Terraform failure analysis; POAP and on-box code; Dashboard templates; pyATS; telemetry; source-of-truth reconciliation; Linux VLAN/veth/bond/subinterface/bridge paths; and AI-agent authority, integration and security.

The DCACI source expressly excludes transit routing and VRF route leaking from its L3Out implementation item. Such broader engineering material should be identified as extension/prerequisite material, not silently represented as an explicit DCACI requirement. The scope map follows the published items rather than copying an older course outline.

## Instructional gap review and corrections

The scope review went beyond checking whether each source item had a link. The [Cisco Press DCCOR second-edition public contents](https://www.ciscopress.com/store/ccnp-and-ccie-data-center-core-dccor-350-601-official-9780138228088) were used as a primary publisher depth comparison, not as the CCIE lab blueprint or a substitute for the five current outlines. This comparison and the relevant platform manuals exposed concrete mechanism/build gaps in the initial 91 chapters. They were authored into chapters 092–104 rather than left as a reading list.

| Confirmed instructional gap | Added authored instruction | Primary implementation reference and explicit boundary |
|---|---|---|
| OSPF database scope, area boundaries, flooding and route calculation | 092 | NX-OS 10.3 OSPF chapter and IETF OSPF/NSSA specifications; four-router experiment, LSA type reasoning and external-route cost cases |
| Time mechanisms and defensible measurements | 093 | NX-OS 10.3 PTP guide and NTP specification; timestamp arithmetic, asymmetry and holdover assumptions; broader observation depth rather than a fabricated named exam leaf |
| Routed tenant multicast | 094 | NX-OS 10.3 TRM guide and MVPN specifications; receiver, tenant/RPF, MVPN and underlay gates distinguished; not represented as a verified CCIE numbered leaf |
| Dynamic identity-to-VSAN behavior | 095 | MDS 9.x DPVM guide; pWWN/nWWN precedence, login timing, pending/committed/active state and mobility evidence |
| Enhanced and smart zoning | 096 | MDS 9.x zoning guide; session ownership, active authorization, role-based exchanges and exceptions; logical-pair model explicitly not TCAM sizing |
| CFS distribution internals | 097 | MDS 9.x CFS guide; transport, application eligibility, scope, regions, session locks and merge semantics |
| NDO build and deployment sequence | 098 | NDO 4.2 ACI configuration chapters; onboarding, infrastructure, schemas/templates, common/site-local policy, per-site deployment and optimistic version checks |
| NDFC build and template sequence | 099 | NDFC 12.1.2e greenfield/fabric/template/brownfield chapters; resource plans, roles, attachments, preview/deployment, drift and bounded template inputs |
| NDI onboarding and assurance evidence | 100 | NDI 6.3.1 NDFC guides; collection, managed/monitored mode, supported onboarding, flow/snapshot analysis and evidence limitations |
| BGP decision and policy internals | 101 | NX-OS 10.3 basic BGP and route-policy guides; eligibility, same-prefix selection, next-hop resolution, weight/local preference, conditional attributes and policy fall-through |
| First-hop redundancy and IPv6 | 102 | NX-OS 10.3 HSRP/VRRP guides; tracking arithmetic, preemption, failure observation, virtual identity and ND/RA evidence |
| Membership and selective replication | 103 | NX-OS 10.3 IGMP/MLD/snooping guides and membership specifications; source/group requests, query refresh, shared-port leave failure, family-specific state |
| Configuration recovery semantics | 104 | NX-OS 10.3 rollback/configuration-replace guides; merge residue, checkpoint/replace scope, concurrent-change loss, timer confirmation and service acceptance |

Every added chapter has mechanism teaching, two original worked cases, guided practice, an independent assignment, four recall cards and twelve original questions with four same-context alternatives and individual rationales. Exact source URLs are in each chapter and its standalone workbook. The additions supply 13,913 body words, 26 worked cases and 156 questions. These are measurements of authored additions, not a threshold that proves completeness.

Three release-specific findings affected the authored instructions. The IGMP lesson distinguishes conceptual EXCLUDE semantics from the pinned NX-OS source-list exclusion limitation. The NDI lesson preserves the 6.3.1 NDFC Change Control compatibility restriction instead of recommending an unsupported combination. The configuration recovery lesson distinguishes the documented bootflash comparison limitation from actual configuration equality. These are examples of why a generic feature name is insufficient evidence for an implementation claim.

The combined course now represents all five published course families in teaching and assessment. The final review found no additional **unmapped published CCNP leaf**. That narrower conclusion must not be expanded into a claim that every possible variant, hardware behavior or related exam question is covered. Implementation verbs still require construction and diagnosis on supported systems, and broad outline wording permits related topics beyond the enumerated list.

## CCIE v3.1 verification boundary

The [live Cisco CCIE Data Center programme page](https://www.cisco.com/site/us/en/learn/training-certifications/certifications/datacenter/ccie-data-center/index.html) identifies the v3.1 lab and the DCCOR core requirement. The [official equipment and software PDF](https://learningcontent.cisco.com/documents/marketing/exam-topics/CCIE-DC-3.1-equipment_and_SW_reviewed.pdf) was retrieved and read. Its content identifies the CCIE Data Center v3.1 baseline even though one retrieval title was incorrectly labelled with another examination identifier.

The [official CCIE lab-topic page](https://learningnetwork.cisco.com/s/ccie-data-center-exam-topics) repeatedly returned a loading/CSS-error shell, including the final retrieval check. No complete authoritative v3.1 leaf list was obtained. This is a retrieval limitation, not evidence that the page is nonexistent or that its contents were verified. The programme page's linked [at-a-glance PDF](https://www.cisco.com/c/dam/en_us/training-events/certifications/expert/ccie-data-center-at-a-glance.pdf) is an older v3.0 document and was not promoted to a current leaf denominator.

The verified equipment publication places Nexus 9000 on NX-OS 10.x, APIC on 5.x, UCS/CIMC on 4.x, and Dashboard/NDO/NDFC/NDI in the 3.x/4.x/12.x/6.x families. It also includes older Nexus 7000/5000 software families. The new controller chapters provide explicit teaching baselines within the published families, and chapter 098 provides an APIC 5.2 bridge. Earlier APIC 6.x examples retain their labels and must not be silently treated as proof of 5.x support. Joint interoperability still requires the actual compatibility matrix for the chosen combination.

The equipment list does not prove that every feature available on each listed platform is an examination requirement. No unverified OTV/VDC or other feature requirement was invented from a hardware name. The 25 authored CCIE chapters and their 500 questions provide integrated expert cases building on the CCNP course; their local objective IDs are correctly distinct from official numbering. A claim of complete official CCIE leaf reconciliation remains unsupported. That unresolved source boundary must remain visible in the application, reports and any completion claim.

No canonical CCIE content was edited during this audit. The final editorial pass labels RFC 8365 as the EVPN overlay specification and RFC 7432 as foundational BGP MPLS-based EVPN. This is a citation precision issue, not a new examination-scope claim.

## Reproducible package verification

Canonical CCNP freeze: 104 chapters, 22 modules, 1,180 distinct question signatures, 416 recall cards and 227 provider leaf references. Overall body text is 62,157 words; worked examples add 18,709 and guided practice adds 5,391 under the audit script's documented counting method. Shared workbook material is counted once. All 38 independent question replacements were compared with the supplied replacement objects and remain exactly preserved.

From the project root:

```bash
python course_labs/CCNP-DC/academy_lab.py selftest
python course_labs/CCNP-DC/academy_lab.py demo
python course_labs/CCNP-DC/depth_checks.py --self-test
python course_labs/CCNP-DC/depth_checks.py --demo
python scripts/build_release.py
```

The original lab has 24 passing tests and the depth lab has 53. Tests cover narrow executable reasoning and input contracts, including stale-version rejection, injection-resistant template input, counter resets, membership filter semantics and merge-versus-replacement behavior. They do not emulate Cisco equipment. Schema/reference, linked-artifact, unique-question-signature and source-link checks passed. Reports and synthetic demonstration outputs are retained in the package.

Vendor device execution, complete independent technical review of every item, learner item analysis and psychometric validation were not performed. Those limitations remain explicit. The authored programme is concrete and reviewable; practical achievement requires the independent implementation evidence specified in the workbooks.
