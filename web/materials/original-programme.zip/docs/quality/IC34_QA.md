# IC34 course review and execution record

The course contains original supplementary teaching and assessment aligned to the public ISA IC34 scope. The source crosswalk is an instructional mapping; it is not a reproduced proprietary exam blueprint or a licensed-standard conformance assessment.

## Authored coverage

Twenty-five focused lessons connect assessed risk and measurable requirements to conceptual architecture, switching/routing, stateful filtering, industrial operation authorization, DMZ services, remote maintenance, role design, PKI, host hardening, application control, legacy interfaces, development integrity, monitoring, IDS operation, logging/time, failover, trusted recovery, automation, factory/site tests, cutover and maintained acceptance.

Each lesson has mechanism teaching, a supplied synthetic technical case, worked reasoning, guided practice, an independent evidence task and memory-recall cards. The bank contains 500 distinct authored stems, with 20 different decisions per shared case. Shared case use is explicit. Questions were not multiplied by changing host names, numbers or option order.

The public crosswalk maps ten learning objectives and three additional exercise scopes to lessons and questions. Course-wide references include every lesson-specific source. Platform examples state assumptions, including IOS XE 17.9, OpenSSH 9.6+, OpenSSL 3.0 and Suricata 8.0.2. The Modbus Organization's relocated application and TCP/IP specification links were retrieved successfully during source review.

## Editorial checks

The final review replaced implausible alternatives with adjacent technical errors and adjusted difficulty where a direct lookup did not justify an advanced label. Chapters 1–4 had 47 questions and 16 labels refined. All 20 PKI questions in chapter 10 were reworked. The independent 5–9 pass reviewed all 100 items, refined 118 alternatives across 59 questions, changed 50 inflated labels and rewrote two ambiguous negative stems. The 11–15 review is recorded in its separate editorial report. Chapters 16–18 and 21–25 have independent technical-review records; chapters 19–20 include explicit recovery timing and API/capability checks.

These are editorial and technical reviews. No empirical item-discrimination study, actual examination-equivalence analysis or learner outcome validation is claimed.

## Executed local laboratory

The standard-library laboratory performs no network operations. Twelve self-tests passed, covering complete/split/coalesced frames, malformed lengths and protocol identifiers, bounded parsing, address spans, positive/negative policy behavior and queue recovery. The reference policy passes 46 of 46 authored requirement fixtures. The deliberately weak starter passes 25 of 46 and returns a nonzero exit status as expected.

A targeted semantic review added isolated forbidden-function and lower-bound cases so an out-of-range register could not mask a missing function restriction. The unsupported mask-write fixture has complete function-specific bytes rather than relying on a malformed request to produce denial.

Reproduce from the repository root:

```bash
.venv/bin/python course_labs/IC34/check.py --self-test
.venv/bin/python course_labs/IC34/check.py course_labs/IC34/solution.json --report course_labs/IC34/reference_report.json
python scripts/build_release.py
```

The course content validator checks schema, unique stems and options, lesson/question/provider mappings, source union and artifact existence. `IC34_QA.json` contains current counts and the canonical file digest after the final build. The learner laboratory includes a requirement trace, trust/dependency review, factory/site transfer record and cutover worksheet in `course_labs/IC34/design_record.md`.

## Evidence limits

All network/device outputs in the teaching are synthetic or proposed commands; those vendor environments were not executed. The local model consumes already ordered stream chunks and trusted context facts. It is not a production TCP stack, industrial parser, firewall, cryptographic validator or process protection system. Its sequence is a hypothetical authenticated upstream command envelope, not a claim that native Modbus transaction identifiers provide anti-replay.

Actual ISA course/examination prerequisites remain external. Licensed applicable standards and competent implementation/assessment are required for normative security-level or conformance claims. App completion, a passing local checker and a quiz score do not award a certificate or establish field authority.
