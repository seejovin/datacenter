# Independent question review — 19 September 2026

The patch packet contains **138 reviewed question replacements**, including 20 definite ambiguity, missing-input, evidence-overclaim or case-context corrections. The remaining edits replace weak distractors with plausible same-context misconceptions and explain why each is wrong. Three-option items remain three-option items. The isolated review initially produced a patch packet. All 138 replacements were subsequently applied to the canonical courses and verified during integration.

| Course | Original bank screened | Full prompt/options/key sample | Additional calculation prompt/exhibit/key review | Patched questions |
|---|---:|---:|---:|---:|
| CDFOS | 500 | 57 | 23 | 25 |
| CDCS | 500 | 72 | 103 | 15 |
| CCNP-DC | 1024 | 143 | 0 | 38 |
| IC32 | 500 | 65 | 0 | 20 |
| IC37 | 500 | 96 | 0 | 40 |

Machine screening covered 3,024 questions. Independent AI-assisted review covered **433 complete question items**, plus **126 additional calculation items** whose prompt, exhibit and keyed result were checked without reading every distractor in that pass. The union is **559 questions**. Samples are risk-targeted, not random. All lexical and negative-stem candidates were read, together with calculation candidates, initial schema examples, and the missing-context item pairs. Exact IDs are recorded in `independent_question_QA.json`. The IC37 exhibit sweep also inspected every distinct nonempty case exhibit for obvious contamination or missing antecedents. This is not a claim that all 3,024 questions received a full substantive review.

## Definite corrections

- **CDFOS-Q0331:** the original “which entry is insufficient” wording made all four alternatives defensible. The revision asks which actual supplied unit entry is ambiguous.
- **CDCS-Q0346:** reducing the modeled heat load would normally move the prediction away from the higher observed temperature. The revision tests unjustified calibration without prescribing the contradictory direction.
- **IC32-Q0011:** 3.5 s is a calculated worst-case age under supplied assumptions, not an independently specified maximum acceptable process age. The stem and rationale now distinguish these.
- **IC32-Q0228:** an appliance reporting allowance of encrypted traffic does not by itself prove correct network-policy enforcement. The key now limits the claim to the supplied observation and visibility limits.
- **IC37-Q0045, Q0112:** negative stems made multiple unproven statements valid choices. The replacements separate established intermediate facts from the missing deployment or notification outcome.
- **IC37-Q0103:** elapsed heartbeat age is 130 s, while overdue time is 100 s. The original “collection gap” did not specify which quantity. The revised stem asks elapsed age.
- **IC37-Q0131, Q0486:** distractors could legitimately describe the same review consideration or staffing weakness as the key. They now represent incomplete approaches or distinct corrective actions.
- **IC37-Q0273:** removed an unrelated restored-secret question from the exhibit.
- **IC37-Q0152, Q0172, Q0202, Q0238, Q0302, Q0309, Q0404, Q0418, Q0490:** restored the prior case facts as standalone exhibits. These questions can now appear independently in a random quiz.
- **CCNP-DC-Q0643:** supplied the previously omitted 20 paths per device, confirming 200 × 20 / 10 = 400 path updates/s without requiring the learner to remember another lesson screen.

## Technical observations and limits

The calculation sweep found no incorrect keyed arithmetic under the supplied assumptions. It checked availability interval unions, non-additive medians, outage and recovery deadlines, historian queues, critical paths, energy and PUE, three-phase power and voltage-drop models, fuel/UPS/stored-energy calculations, air/liquid thermal flow, illustrative suppression models, optical budgets, cooling efficiency, payback, telemetry rates, throughput/oversubscription and recovery bandwidth. Synthetic simplifying assumptions remain necessary; these are not signed physical designs.

The CCNP sample covered routing, vPC/EVPN, storage authorization and credits, ACI dependencies, UCS identity/firmware, telemetry, automation schemas/typing, asynchronous work, recovery and failure-domain reasoning. All 93 negative-stem candidates were read with their exhibits/options. This question-focused sample is not a complete chapter-by-chapter blueprint audit, and it does not close the additional teaching gaps that the root source audit has already assigned to the CCNP author.

The gNMI timing/synchronization claims were cross-checked against the [OpenConfig protocol definition](https://raw.githubusercontent.com/openconfig/gnmi/master/proto/gnmi/gnmi.proto). `sample_interval` is in nanoseconds and the synchronization flag denotes completion of the initial subscribed-value delivery. L066 explicitly labels its dictionary as an intermediate teaching representation. A future executable payload exercise must preserve the distinction between a protobuf boolean (`bool_val`) and encoded JSON bytes (`json_ietf_val`), rather than passing that dictionary directly as a protobuf object. No question-key correction was required for that explicitly bounded representation.

Residual limitation: many unreviewed bank items remain outside this independent sample. This packet improves concrete defects; it is not evidence of provider equivalence, psychometric validation, exam readiness or completeness of all teaching.

## Integration result

All 138 replacements are included in this release. Question identities, answer-key index sequences and mapping relationships were retained. Further CCNP teaching additions are documented in [the source review](CCNP_SOURCE_REVIEW.md). This report describes the dated sample, not the total current bank size.
