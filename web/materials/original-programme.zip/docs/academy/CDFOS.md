# CDFOS — Certified Data Centre Facilities Operations Specialist — complete original study course

Original independent instruction and practice. Read the teaching, work the demonstrations and guided exercise, then attempt questions before reading their explanations. Independent tasks require your own evidence.

Source baseline: [EPI public course syllabus; original independent study programme](https://www.epi-ap.com/services/1/3/136) · Public outline checked 2026-09-19 · checked 2026-09-19

Maps the public syllabus into original instruction and assessment. Provider examination weighting and protected training materials are not reproduced. These are original practice questions, not actual examination questions.

## Scope and external requirements

- Public outline does not disclose the full protected provider curriculum or item bank.

- App study does not award a credential or replace provider eligibility, required examinations, equipment access or field authority.

- Retain the curriculum-assigned EPI course and official examination as separate requirements.

- Use approved vendor tools and procedures; physical, electrical, fire and mechanical work requires competent personnel and appropriate authority.

- D1 content is examination and interface literacy only. D2/D3 specialist engineering remains the later charter horizon; integration and operational coordination do not confer specialist authority.

## Preparation

Prior courses: See the knowledge prerequisites below.

- Provider enrollment and examination eligibility must be checked directly.

- EPI recommends DCFC/CDCP beforehand and advises operations experience; these are recommendations, not a claimed mandatory CDCP certificate prerequisite for CDFOS.

## CDFOS-M01 — Service commitments, measurement and improvement

### CDFOS-L01 — Service commitments, measurement and improvement

Estimated study time: 120 minutes before independent work. Prerequisite chapters: Use the course prerequisites.

## From customer need to an operable promise

Service level management connects a customer's required outcome with a service the operator can actually deliver and measure. Begin with the consuming activity and consequence of interruption. A customer's request for “a resilient rack” leaves several questions unanswered: which outlets and network interfaces are included, how much usable capacity is committed, under what normal and maintenance conditions, during which support hours, and what constitutes loss of service? Needs analysis gathers these facts before promising a percentage. Record business windows, expected growth, dependencies the customer owns, relevant constraints and the person authorized to accept the service definition.

A service portfolio includes proposed, active and retired services and their governing decisions. A service catalogue presents available services and their defined scope to the appropriate audience. They are related but serve different purposes. A proposal under evaluation should not appear as an orderable commitment until capability and commercial authority are established. Catalogue entries need a service owner, eligibility, included interfaces, capacity units, request method, support boundaries, dependencies and the applicable service-level terms. Version the entry so an order can be linked to the promise actually made at the time.

Describe service boundaries through observable outcomes. “Power available” could mean voltage at a specified outlet within an agreed envelope, upstream equipment running, or an application still operating. These are different measurements and responsibility boundaries. A UPS running normally does not prove every customer outlet is energized. Conversely, a customer's failed internal power supply may not represent a failed facility service. Map customer requirements to the physical interface, operational process and measurement point that can substantiate them. Define treatment of customer-owned equipment and shared dependencies before an incident creates a dispute.

## Assess capability before signing

Capability assessment examines the complete delivery chain: infrastructure, installed configuration, people, tools, spares, suppliers, information, procedures and recovery access. A nominal equipment rating is only one input. Consider actual current load, committed reservations, required maintenance state, a credible fault, environmental conditions and the method used to verify capacity. Two feeds sharing an upstream component cannot support an independence claim merely because the rack has two cables. A backup contract without a tested callout and usable spare may not support the promised restoration window.

Operational capability also changes with time. A service that was deliverable before one cooling unit failed may be restricted while the facility is degraded. Communicate the operational constraint through the approved process; do not silently rewrite the customer agreement or assume the original design capacity still applies. A controlled admission or placement hold can protect existing commitments while corrective work is planned. Capacity and capability reports should distinguish installed nameplate, demonstrated usable capacity, allocated commitments, measured demand and remaining margin. Avoid double-counting reservations as both actual load and an additional forecast.

A service level agreement records the agreed scope and measurable targets, responsibilities, reporting, review and dispute arrangements. Supporting internal operational agreements and supplier commitments should align with it. A two-hour customer restoration target cannot be supported by a supplier response commitment that merely promises to answer the phone within two hours. Trace the chain from detection through escalation, mobilization, diagnosis, repair, verification and customer communication. Define who has authority at each stage, including outside ordinary working hours. A contractual remedy or service credit is not a technical recovery procedure.

## Make the measurement rule unambiguous

An availability ratio is meaningful only after its denominator and outage rule are defined. For a simple time-based service, availability equals eligible service time minus qualifying unavailable time, divided by eligible service time. Report the numerator, denominator, period, unit and exclusions with the percentage. Thirty days contain 43,200 minutes, but the denominator may differ when the agreement defines a restricted service window. Do not subtract planned work from the denominator unless the agreed rule permits it. A maintenance ticket being approved internally does not automatically make its customer impact contractually excluded.

Overlapping incidents require interval logic. If one service is unavailable from 10:00 to 10:30 and another incident affecting that same service runs from 10:20 to 10:50, the union is fifty minutes, not sixty. Different customer services may have different affected intervals. A facility-wide aggregate can conceal a poor result for one rack or tenant. Define whether the metric is per service, customer-weighted, capacity-weighted or another explicit measure; never switch the aggregation rule to make a result look better. Preserve the event timeline and measurement source used to calculate each result.

Targets for response, restoration and resolution also need separate clocks. Response may mean acknowledgment by the assigned person; restoration means the defined service has returned; resolution may mean the underlying problem and records are closed. An automatic ticket creation timestamp is not necessarily human response. Define the starting event, pauses if any, ending event, time source and evidence for each clock. Requiring correct service verification prevents a ticket status change from becoming an unsupported restoration claim. Record uncertainty when clocks disagree rather than assigning false precision.

## Reporting is a controlled interpretation of evidence

A useful report explains service delivered, target attainment, incidents, capacity, risks, actions and limitations. Identify the source system, collection coverage, timestamp handling and calculation version. Missing measurements are not automatically healthy time. A monitoring outage may leave service status unknown; use independent evidence where available and report the uncertainty. Do not equate a missing alarm with proof that nothing failed. Reconcile customer observations, facility telemetry and event records before resolving contradictions.

Averages can hide experience. An average response time of five minutes could combine many immediate acknowledgments with one very late critical response. Use a distribution or relevant percentiles alongside counts and severity where the decision requires it. Percentile calculation methods and sample size affect the result; document them. Separate the customer's service metric from internal equipment-health indicators. Both are useful, but the former assesses the delivered outcome and the latter helps explain or predict it. A report should not substitute an easier equipment metric for a difficult customer measurement without an agreed change.

Correct reporting errors openly. Retain the original report, corrected version, reason, affected periods and reviewer approval. Silent replacement weakens the evidence trail and can undermine later trend analysis. Reporting frequency should match both contractual commitments and operational needs. A monthly summary does not replace immediate notification of a material service impact. The notification route, escalation threshold and responsible person belong in the service definition and incident procedures.

## Complaints and satisfaction reveal different information

A complaint process records the concern, acknowledges it through the agreed route, preserves relevant evidence, assigns an owner, investigates fairly and communicates a reasoned outcome. A customer may be dissatisfied even when a narrow availability target passed, for example because communication was poor or repeated short interruptions disrupted work. Conversely, a satisfied customer does not erase a missed contractual target. Treat satisfaction feedback and objective service measures as complementary inputs. Avoid treating a complaint as proof of operator fault before the evidence is examined, or dismissing it merely because a dashboard was green.

Use interviews and surveys with clear questions, relevant respondents and an explicit sampling method. A response rate of ten percent can carry selection bias; show counts and limitations rather than presenting the score as every customer's view. Categorize complaints consistently enough to detect recurrence, while retaining the original context. Protect customer and operational information in shared reports. Where the service agreement defines a dispute or escalation route, follow it and retain the decision authority.

## Improve a demonstrated weakness

A service improvement plan begins with a measurable problem, baseline, hypothesized cause, intended outcome and owner. Select an intervention that addresses the cause and fits operational constraints. If late restoration comes mainly from an unavailable spare, changing the dashboard theme will not repair the dependency. Compare improvement options using expected effect, cost, risk, implementation effort and reversibility. A lower-cost intervention can be preferable if it addresses the limiting stage without introducing disproportionate failure exposure.

Define a trial with comparable workload, coverage and operating conditions. Record adverse effects as well as benefits. A reduction in incident count during a period with half the service exposure does not establish improved reliability; normalize the comparison appropriately and acknowledge small samples. Confirm that a faster process did not omit required verification or safety steps. Review the result with the service owner, update controlled procedures and training, and schedule a follow-up check. Close the improvement item only when its acceptance evidence supports the claimed outcome, or record why the trial was rejected and what remains open.

For the independent exercise, act as the operations counterpart reviewing a synthetic service package. Produce the boundary statement, capability evidence, measurement specification, reporting calculation, complaint decision and improvement plan. These are analytical results. Physical capability, executed operations and supplier performance still require the curriculum's vendor, laboratory or supervised evidence. The app provides complete original reasoning practice for this module without representing itself as the EPI provider or awarding the credential.

#### Worked demonstrations

**Rack service definition before sale**

Synthetic training case — not a field record.

A customer requests a 10 kW rack with two independent power feeds, 24-hour monitoring and a 30-minute response. The draft catalogue says “dual power, resilient service.” Rack outlets share an upstream switchboard. The operations desk is staffed continuously, but supplier callout is weekdays only. No response-clock definition exists.

**Reasoning:** Separate required outcomes from shorthand labels. The shared switchboard prevents an unsupported independence claim. Continuous monitoring does not establish supplier availability. Define the outlet/service boundary and response clock; hold the unverified catalogue promise pending capability and authority review.

**Availability calculation with overlapping incidents**

Synthetic training case — not a field record.

Synthetic 30-day month: eligible service window is all 43,200 minutes. Service A is unavailable 10:00–10:30 and 10:20–10:50 on one day. A separate 20-minute planned outage is contractually included. Telemetry is missing for another 15 minutes; an independent outlet recorder demonstrates service remained available then. The agreement has no planned-maintenance exclusion.

**Reasoning:** The overlapping service intervals have a 50-minute union. Add the separate 20-minute included outage for 70 unavailable minutes. Availability is (43,200−70)/43,200 = 99.83796%, approximately 99.838%. The independent recorder supports the telemetry-gap classification; record that evidence and do not invent a contractual exclusion.

**Capacity promise in a degraded maintenance state**

Synthetic training case — not a field record.

A synthetic cooling group has four units, each demonstrated at 100 kW for the stated conditions. Current load is 210 kW and an accepted reservation is 40 kW. One unit is unavailable. The service policy requires capacity after one additional unit is isolated for maintenance. A sales request adds 30 kW. All four units also depend on one common control-power source.

**Reasoning:** With one unit unavailable and another removed, two units remain: 200 kW. Existing measured load plus the separate accepted reservation is 250 kW under the stated planning rule, so the required maintenance state is already unsupported. Hold additional commitment and escalate the existing exposure. The control-power source is a separate common dependency; adding nameplate capacity does not resolve it.

**Reporting integrity and contradictory observations**

Synthetic training case — not a field record.

A report claims “100% monitored availability.” Collector C was offline for 40 minutes, customer tickets describe a 12-minute service interruption, and the only surviving equipment log uses a clock known to be 8 minutes fast. The response-time sample is 1, 1, 2, 2, 4 and 20 minutes. The report shows only its 5-minute mean.

**Reasoning:** Distinguish monitoring coverage from service availability. Preserve the customer account and clock offset, correlate independent evidence and report unresolved intervals. The sample mean is five minutes but one response took twenty; display the distribution and the agreed target rather than treating the mean as universal experience. Keep original and corrected report versions.

**Complaint, satisfaction and fair review**

Synthetic training case — not a field record.

Tenant T reports repeated short disruptions and poor updates. The monthly availability target passed, but three incident notifications were sent to an obsolete contact. A satisfaction survey received 8 replies from 80 tenants; 7 were positive. The complaint procedure requires an assigned owner, acknowledgment and a reasoned response.

**Reasoning:** Passing one target does not resolve communication failures or the tenant’s experience. Assign the complaint, preserve its facts, correct the contact governance and assess the notification requirement. Report seven positive responses among eight respondents and a ten-percent response rate; do not claim that 87.5% of all tenants are satisfied.

**Service improvement trial and acceptance**

Synthetic training case — not a field record.

Twelve comparable restoration events show median detection 2 min, escalation 3 min, spare retrieval 35 min and repair/verification 20 min. A proposal places a controlled spare near the service area. Trial retrieval median is 8 min, but one spare was used without identity verification and caused a wrong-part delay. Trial workload and event definitions otherwise match the baseline.

**Reasoning:** The observed limiting stage is spare retrieval. The median stage reduction is 27 minutes, but medians cannot automatically be added to prove the same end-to-end improvement. The identity-check failure is an adverse effect needing correction. Approve wider use only after supported compatibility, custody, replenishment and full restoration measurements meet the trial criteria.

#### Guided practice

Review a proposed rack service with an ambiguous boundary, overlapping outage records and a disputed notification. Produce one coherent recommendation.

**Hint:** Keep capability, contractual measurement, evidence quality and customer experience as separate questions.

**Worked solution:** Define the service interface and failure conditions; reconcile supporting capability before commitment; union same-service outage intervals under the agreed denominator; preserve clock/coverage limits; investigate the notification independently of availability; create an owner-led improvement trial with adverse-effect criteria.

#### Independent task

Environment: analytical

Independently review a synthetic service package and defend acceptance or hold.

**Packaged starter material**

- course_labs/CDFOS/README.md
- course_labs/CDFOS/fixture.json
- course_labs/CDFOS/assessment_template.md
- course_labs/CDFOS/lab.py
- course_labs/CDFOS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- Service boundary and capability matrix
- Reproducible availability/response report
- Complaint disposition and improvement trial plan

**Acceptance criteria**

- Measurement rules reproduce the result.
- Unverified promises and unknown intervals remain explicit.
- Improvement acceptance includes service quality and adverse effects.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer. The bundled calculator was executed against supplied synthetic fixtures; its numerical checks do not grade physical work or professional authorization.

#### Chapter practice

**CDFOS-Q0001 · single · operations**

Which statement needs clarification before acceptance?

Synthetic training case — not a field record.

A customer requests a 10 kW rack with two independent power feeds, 24-hour monitoring and a 30-minute response. The draft catalogue says “dual power, resilient service.” Rack outlets share an upstream switchboard. The operations desk is staffed continuously, but supplier callout is weekdays only. No response-clock definition exists.

1. The already-stated request for two power feeds
2. The already-stated ten-kilowatt rack demand
3. The precise failure and maintenance conditions covered by “independent” feeds
4. The already-confirmed continuous operations-desk staffing

**Correct option(s):** 3

- Option 1: Feed count is known but does not define independent failure coverage.
- Option 2: The requested amount is supplied; the resilience condition remains undefined.
- Option 3: Two outlet labels do not define the tolerated upstream failure.
- Option 4: The case supplies that fact; supplier capability still needs separate review.

**CDFOS-Q0002 · single · operations**

Which observed fact directly challenges the independence claim?

Synthetic training case — not a field record.

A customer requests a 10 kW rack with two independent power feeds, 24-hour monitoring and a 30-minute response. The draft catalogue says “dual power, resilient service.” Rack outlets share an upstream switchboard. The operations desk is staffed continuously, but supplier callout is weekdays only. No response-clock definition exists.

1. The service includes continuous monitoring
2. The customer requests a response target
3. The rack demand is stated in kilowatts
4. Both feeds share the upstream switchboard

**Correct option(s):** 4

- Option 1: Monitoring is a supporting service, not evidence of independence.
- Option 2: Response time is a separate operational commitment.
- Option 3: A demand unit does not describe shared failure domains.
- Option 4: One common component can affect both paths.

**CDFOS-Q0003 · single · mechanism**

What distinguishes a portfolio entry from a catalogue commitment?

Synthetic training case — not a field record.

A customer requests a 10 kW rack with two independent power feeds, 24-hour monitoring and a 30-minute response. The draft catalogue says “dual power, resilient service.” Rack outlets share an upstream switchboard. The operations desk is staffed continuously, but supplier callout is weekdays only. No response-clock definition exists.

1. A catalogue should include every untested engineering idea
2. A portfolio can include a proposed service not yet approved for ordering
3. Every portfolio entry must already be in production
4. A portfolio replaces the service owner’s approval

**Correct option(s):** 2

- Option 1: Orderable commitments require reviewed capability and authority.
- Option 2: Portfolio governance includes lifecycle decisions before availability.
- Option 3: Proposals and retired offerings may remain in the portfolio.
- Option 4: A register does not itself authorize a commitment.

**CDFOS-Q0004 · single · operations**

What should the 30-minute response clock specify?

Synthetic training case — not a field record.

A customer requests a 10 kW rack with two independent power feeds, 24-hour monitoring and a 30-minute response. The draft catalogue says “dual power, resilient service.” Rack outlets share an upstream switchboard. The operations desk is staffed continuously, but supplier callout is weekdays only. No response-clock definition exists.

1. Only the interval between two automated emails
2. Only when the ticket closes
3. Start event, responding role, qualifying action and evidence
4. Only the supplier’s office opening time

**Correct option(s):** 3

- Option 1: Automation may not establish the promised human response.
- Option 2: Closure can occur much later and represents a different outcome.
- Option 3: These define what is measured and when the clock ends.
- Option 4: That does not define the customer-facing response event.

**CDFOS-Q0005 · single · operations**

What is the appropriate treatment of weekday-only supplier callout?

Synthetic training case — not a field record.

A customer requests a 10 kW rack with two independent power feeds, 24-hour monitoring and a 30-minute response. The draft catalogue says “dual power, resilient service.” Rack outlets share an upstream switchboard. The operations desk is staffed continuously, but supplier callout is weekdays only. No response-clock definition exists.

1. Assess its effect on the promised round-the-clock service capability
2. Assume continuous monitoring makes the supplier continuously available
3. Remove the supplier from the dependency list
4. Treat the supplier’s response and restoration as identical

**Correct option(s):** 1

- Option 1: Supporting commitments must fit the offered service.
- Option 2: Observation cannot create staffing or contract availability.
- Option 3: Omitting a dependency does not eliminate its effect.
- Option 4: Arrival or acknowledgment does not establish restored service.

**CDFOS-Q0006 · single · operations**

Which measurement best supports a power service defined at the rack outlet?

Synthetic training case — not a field record.

A customer requests a 10 kW rack with two independent power feeds, 24-hour monitoring and a 30-minute response. The draft catalogue says “dual power, resilient service.” Rack outlets share an upstream switchboard. The operations desk is staffed continuously, but supplier callout is weekdays only. No response-clock definition exists.

1. Evidence at the agreed outlet interface and operating envelope
2. The switchboard’s installation date
3. UPS normal-mode status alone
4. The customer’s application login success alone

**Correct option(s):** 1

- Option 1: The observation matches the committed delivery boundary.
- Option 2: Asset age does not measure present outlet availability.
- Option 3: Upstream status cannot prove every downstream outlet is usable.
- Option 4: Application state may include dependencies outside the power service.

**CDFOS-Q0007 · single · operations**

Who should resolve the unsupported promise before publication?

Synthetic training case — not a field record.

A customer requests a 10 kW rack with two independent power feeds, 24-hour monitoring and a 30-minute response. The draft catalogue says “dual power, resilient service.” Rack outlets share an upstream switchboard. The operations desk is staffed continuously, but supplier callout is weekdays only. No response-clock definition exists.

1. The supplier by silently changing the catalogue
2. The customer without disclosure of the shared dependency
3. Any operator who can edit the website
4. The accountable service owner through technical and commercial review

**Correct option(s):** 4

- Option 1: Supplier input does not replace the operator’s controlled approval.
- Option 2: The decision requires accurate capability information.
- Option 3: Editing access does not confer commitment authority.
- Option 4: Commitment requires both capability and authorized acceptance.

**CDFOS-Q0008 · single · operations**

Which is a defensible interim catalogue state?

Synthetic training case — not a field record.

A customer requests a 10 kW rack with two independent power feeds, 24-hour monitoring and a 30-minute response. The draft catalogue says “dual power, resilient service.” Rack outlets share an upstream switchboard. The operations desk is staffed continuously, but supplier callout is weekdays only. No response-clock definition exists.

1. Withdraw every existing rack service
2. Proposed or restricted pending verified capability and approval
3. Fully available because two feeds are installed
4. Publish first and clarify after an outage

**Correct option(s):** 2

- Option 1: The finding concerns a defined proposed commitment.
- Option 2: This prevents unverified scope becoming an orderable promise.
- Option 3: Feed count does not close the identified capability gap.
- Option 4: That transfers unresolved risk into an active promise.

**CDFOS-Q0009 · single · operations**

Which information belongs in the service entry?

Synthetic training case — not a field record.

A customer requests a 10 kW rack with two independent power feeds, 24-hour monitoring and a 30-minute response. The draft catalogue says “dual power, resilient service.” Rack outlets share an upstream switchboard. The operations desk is staffed continuously, but supplier callout is weekdays only. No response-clock definition exists.

1. Only a resilience adjective and price
2. Every staff member’s private contact details
3. Only the procurement contract number
4. Scope, owner, interfaces, limits, request path and supporting terms

**Correct option(s):** 4

- Option 1: That leaves the delivery and responsibility boundaries undefined.
- Option 2: Personal information is not a substitute for an approved support route.
- Option 3: Procurement records do not define the complete customer service.
- Option 4: These allow customers and operators to interpret the offering.

**CDFOS-Q0010 · single · operations**

What would close the capability review?

Synthetic training case — not a field record.

A customer requests a 10 kW rack with two independent power feeds, 24-hour monitoring and a 30-minute response. The draft catalogue says “dual power, resilient service.” Rack outlets share an upstream switchboard. The operations desk is staffed continuously, but supplier callout is weekdays only. No response-clock definition exists.

1. A second copy of the same topology drawing
2. Reviewed evidence for the stated boundary and approved resolution of gaps
3. A supplier’s verbal assurance without defined scope
4. A revised description that omits the switchboard

**Correct option(s):** 2

- Option 1: Duplication does not add independent verification.
- Option 2: Acceptance depends on demonstrated capability or an agreed revised promise.
- Option 3: Unrecorded reassurance cannot substantiate the stated commitment.
- Option 4: Removing a fact conceals rather than resolves the dependency.

**CDFOS-Q0011 · single · calculation**

How much unavailable time results from the two overlapping incidents?

Synthetic training case — not a field record.

Synthetic 30-day month: eligible service window is all 43,200 minutes. Service A is unavailable 10:00–10:30 and 10:20–10:50 on one day. A separate 20-minute planned outage is contractually included. Telemetry is missing for another 15 minutes; an independent outlet recorder demonstrates service remained available then. The agreement has no planned-maintenance exclusion.

1. 30 minutes
2. 20 minutes
3. 50 minutes
4. 60 minutes

**Correct option(s):** 3

- Option 1: Using only the longer individual interval misses additional impact.
- Option 2: The overlap alone is not the full unavailable interval.
- Option 3: The service is continuously unavailable from 10:00 to 10:50.
- Option 4: Adding incident durations double-counts the ten-minute overlap.

**CDFOS-Q0012 · single · operations**

How should the planned outage be treated?

Synthetic training case — not a field record.

Synthetic 30-day month: eligible service window is all 43,200 minutes. Service A is unavailable 10:00–10:30 and 10:20–10:50 on one day. A separate 20-minute planned outage is contractually included. Telemetry is missing for another 15 minutes; an independent outlet recorder demonstrates service remained available then. The agreement has no planned-maintenance exclusion.

1. Subtract it from both numerator and denominator without disclosure
2. Exclude it automatically because it was scheduled
3. Include its 20 minutes under the stated agreement
4. Count it only if a customer complained

**Correct option(s):** 3

- Option 1: That changes the agreed measurement rule.
- Option 2: The contract expressly provides no such exclusion.
- Option 3: Internal approval does not create an exclusion absent from the agreement.
- Option 4: Qualifying unavailability does not depend on complaint submission.

**CDFOS-Q0013 · single · operations**

What is the total qualifying unavailable time?

Synthetic training case — not a field record.

Synthetic 30-day month: eligible service window is all 43,200 minutes. Service A is unavailable 10:00–10:30 and 10:20–10:50 on one day. A separate 20-minute planned outage is contractually included. Telemetry is missing for another 15 minutes; an independent outlet recorder demonstrates service remained available then. The agreement has no planned-maintenance exclusion.

1. 85 minutes
2. 50 minutes
3. 70 minutes
4. 80 minutes

**Correct option(s):** 3

- Option 1: The independent recorder supports availability during the telemetry gap.
- Option 2: This omits the contractually included planned outage.
- Option 3: Fifty minutes of unioned incidents plus twenty planned minutes apply.
- Option 4: This double-counts the overlapping incident period.

**CDFOS-Q0014 · single · operations**

Which approximate availability is correct?

Synthetic training case — not a field record.

Synthetic 30-day month: eligible service window is all 43,200 minutes. Service A is unavailable 10:00–10:30 and 10:20–10:50 on one day. A separate 20-minute planned outage is contractually included. Telemetry is missing for another 15 minutes; an independent outlet recorder demonstrates service remained available then. The agreement has no planned-maintenance exclusion.

1. 99.815%
2. 99.838%
3. 99.884%
4. 98.380%

**Correct option(s):** 2

- Option 1: That result uses eighty minutes and double-counts overlap.
- Option 2: Divide 43,130 available minutes by 43,200 eligible minutes.
- Option 3: That result excludes the required planned outage.
- Option 4: The percentage scaling is inconsistent with seventy minutes in a month.

**CDFOS-Q0015 · single · mechanism**

Why may the telemetry gap be classified as available here?

Synthetic training case — not a field record.

Synthetic 30-day month: eligible service window is all 43,200 minutes. Service A is unavailable 10:00–10:30 and 10:20–10:50 on one day. A separate 20-minute planned outage is contractually included. Telemetry is missing for another 15 minutes; an independent outlet recorder demonstrates service remained available then. The agreement has no planned-maintenance exclusion.

1. The customer did not open a ticket
2. The monitoring server had no alarm record
3. Every missing sample is assumed healthy
4. Independent evidence demonstrates the agreed service during that interval

**Correct option(s):** 4

- Option 1: Silence is weaker than the supplied direct evidence.
- Option 2: A failed collector can miss alarms.
- Option 3: Missing data alone does not establish service state.
- Option 4: The classification follows an actual corroborating observation.

**CDFOS-Q0016 · single · operations**

What must accompany the reported percentage?

Synthetic training case — not a field record.

Synthetic 30-day month: eligible service window is all 43,200 minutes. Service A is unavailable 10:00–10:30 and 10:20–10:50 on one day. A separate 20-minute planned outage is contractually included. Telemetry is missing for another 15 minutes; an independent outlet recorder demonstrates service remained available then. The agreement has no planned-maintenance exclusion.

1. Only the rounded number
2. Period, eligible minutes, outage rule, exclusions and evidence
3. Only the longest outage
4. Only the number of incident tickets

**Correct option(s):** 2

- Option 1: Readers cannot reconstruct its meaning without the measurement basis.
- Option 2: These make the result reproducible and interpretable.
- Option 3: The monthly result includes all qualifying intervals.
- Option 4: Tickets do not directly equal unique service-impact time.

**CDFOS-Q0017 · single · operations**

Which data operation prevents overlap inflation?

Synthetic training case — not a field record.

Synthetic 30-day month: eligible service window is all 43,200 minutes. Service A is unavailable 10:00–10:30 and 10:20–10:50 on one day. A separate 20-minute planned outage is contractually included. Telemetry is missing for another 15 minutes; an independent outlet recorder demonstrates service remained available then. The agreement has no planned-maintenance exclusion.

1. Average the incident durations
2. Count every ticket independently
3. Remove all incidents that overlap
4. Compute the union of qualifying intervals for the same service

**Correct option(s):** 4

- Option 1: An average does not measure total affected time.
- Option 2: Several tickets can describe the same service interruption.
- Option 3: That would discard real affected minutes.
- Option 4: Union counts each unavailable minute once.

**CDFOS-Q0018 · single · operations**

Could a facility-wide average replace Service A’s result without agreement?

Synthetic training case — not a field record.

Synthetic 30-day month: eligible service window is all 43,200 minutes. Service A is unavailable 10:00–10:30 and 10:20–10:50 on one day. A separate 20-minute planned outage is contractually included. Telemetry is missing for another 15 minutes; an independent outlet recorder demonstrates service remained available then. The agreement has no planned-maintenance exclusion.

1. Yes, if both numbers are percentages
2. Yes, if the facility average is higher
3. No; aggregation must match the defined service metric
4. Yes, because every rack shares the building

**Correct option(s):** 3

- Option 1: Common units do not imply equivalent definitions.
- Option 2: Favorable appearance does not authorize a changed metric.
- Option 3: A broader average can conceal one service’s failure.
- Option 4: Shared location does not make service impact identical.

**CDFOS-Q0019 · single · operations**

What would change if the independent recorder were unavailable?

Synthetic training case — not a field record.

Synthetic 30-day month: eligible service window is all 43,200 minutes. Service A is unavailable 10:00–10:30 and 10:20–10:50 on one day. A separate 20-minute planned outage is contractually included. Telemetry is missing for another 15 minutes; an independent outlet recorder demonstrates service remained available then. The agreement has no planned-maintenance exclusion.

1. The gap would certainly be available
2. The fifteen-minute gap would need investigation and explicit uncertainty
3. The gap would certainly be a physical outage
4. The contractual denominator would automatically shrink

**Correct option(s):** 2

- Option 1: There would be no stated evidence supporting that conclusion.
- Option 2: Unknown telemetry cannot automatically be classified as healthy.
- Option 3: Missing observation does not uniquely establish service loss.
- Option 4: A monitoring defect does not silently alter the agreement.

**CDFOS-Q0020 · single · operations**

How should a later correction to an outage interval be handled?

Synthetic training case — not a field record.

Synthetic 30-day month: eligible service window is all 43,200 minutes. Service A is unavailable 10:00–10:30 and 10:20–10:50 on one day. A separate 20-minute planned outage is contractually included. Telemetry is missing for another 15 minutes; an independent outlet recorder demonstrates service remained available then. The agreement has no planned-maintenance exclusion.

1. Overwrite the old report without a record
2. Ignore the correction once the month closes
3. Correct the summary percentage but retain inconsistent source intervals
4. Issue a traceable corrected report with reason and affected result

**Correct option(s):** 4

- Option 1: Silent changes prevent reconstruction of the original decision.
- Option 2: Known measurement errors can materially affect reporting.
- Option 3: The corrected result must remain traceable to a coherent evidence set.
- Option 4: Versioned correction preserves accountability and trend integrity.

**CDFOS-Q0021 · single · operations**

What capacity remains in the stated unavailable-plus-maintenance condition?

Synthetic training case — not a field record.

A synthetic cooling group has four units, each demonstrated at 100 kW for the stated conditions. Current load is 210 kW and an accepted reservation is 40 kW. One unit is unavailable. The service policy requires capacity after one additional unit is isolated for maintenance. A sales request adds 30 kW. All four units also depend on one common control-power source.

1. 200 kW
2. 400 kW
3. 250 kW
4. 300 kW

**Correct option(s):** 1

- Option 1: Two demonstrated one-hundred-kilowatt units remain.
- Option 2: This assumes every installed unit is available.
- Option 3: That is the stated load-plus-reservation commitment, not remaining capacity.
- Option 4: This ignores the additional maintenance isolation.

**CDFOS-Q0022 · single · operations**

What planned demand must be considered before the new request?

Synthetic training case — not a field record.

A synthetic cooling group has four units, each demonstrated at 100 kW for the stated conditions. Current load is 210 kW and an accepted reservation is 40 kW. One unit is unavailable. The service policy requires capacity after one additional unit is isolated for maintenance. A sales request adds 30 kW. All four units also depend on one common control-power source.

1. 210 kW
2. 290 kW
3. 280 kW
4. 250 kW

**Correct option(s):** 4

- Option 1: This omits the accepted reservation.
- Option 2: This double-counts the forty-kilowatt reservation.
- Option 3: This adds the new request before assessing existing commitments.
- Option 4: The stated rule adds 210 measured and 40 separately reserved kilowatts.

**CDFOS-Q0023 · single · operations**

What is the immediate disposition of the 30 kW request?

Synthetic training case — not a field record.

A synthetic cooling group has four units, each demonstrated at 100 kW for the stated conditions. Current load is 210 kW and an accepted reservation is 40 kW. One unit is unavailable. The service policy requires capacity after one additional unit is isolated for maintenance. A sales request adds 30 kW. All four units also depend on one common control-power source.

1. Accept because installed nameplate is 400 kW
2. Accept because the failed unit may return eventually
3. Accept after changing only the catalogue wording
4. Hold pending capability resolution and authorized review

**Correct option(s):** 4

- Option 1: Installed capacity ignores the specified degraded state.
- Option 2: Unverified future repair does not establish current capability.
- Option 3: A description change does not create physical margin.
- Option 4: The required state does not support even current commitments.

**CDFOS-Q0024 · single · operations**

What existing issue requires escalation?

Synthetic training case — not a field record.

A synthetic cooling group has four units, each demonstrated at 100 kW for the stated conditions. Current load is 210 kW and an accepted reservation is 40 kW. One unit is unavailable. The service policy requires capacity after one additional unit is isolated for maintenance. A sales request adds 30 kW. All four units also depend on one common control-power source.

1. The reservation is necessarily fraudulent
2. The cooling load must be measured in kilovolt-amperes
3. The facility has too many reserve units
4. The defined maintenance state cannot support existing planned demand

**Correct option(s):** 4

- Option 1: The case states it is accepted; no fraud evidence exists.
- Option 2: Thermal load in kilowatts is an appropriate quantity here.
- Option 3: The available capacity is insufficient under the stated condition.
- Option 4: The problem precedes the additional sales request.

**CDFOS-Q0025 · single · mechanism**

What does the common control-power source affect?

Synthetic training case — not a field record.

A synthetic cooling group has four units, each demonstrated at 100 kW for the stated conditions. Current load is 210 kW and an accepted reservation is 40 kW. One unit is unavailable. The service policy requires capacity after one additional unit is isolated for maintenance. A sales request adds 30 kW. All four units also depend on one common control-power source.

1. Only the number of spare fan assemblies required
2. Only the steady-state thermal rating while every unit remains energized
3. The claimed independence of all cooling units
4. Only the operator acknowledgment-time target

**Correct option(s):** 3

- Option 1: Spare quantity does not describe the shared control-power failure.
- Option 2: The common source also creates a multi-unit availability dependency.
- Option 3: One support failure could affect multiple nominally separate units.
- Option 4: A response metric does not remove the shared physical dependency.

**CDFOS-Q0026 · single · operations**

Which evidence is stronger for the capacity decision?

Synthetic training case — not a field record.

A synthetic cooling group has four units, each demonstrated at 100 kW for the stated conditions. Current load is 210 kW and an accepted reservation is 40 kW. One unit is unavailable. The service policy requires capacity after one additional unit is isolated for maintenance. A sales request adds 30 kW. All four units also depend on one common control-power source.

1. The number of installed cabinets
2. Demonstrated capacity under matching conditions and the required state
3. The largest rating in a generic brochure
4. A historic peak load from a different hall

**Correct option(s):** 2

- Option 1: Cabinet count does not establish cooling output.
- Option 2: It reflects the operating envelope and tested assumptions.
- Option 3: A brochure may describe different conditions or models.
- Option 4: Different topology and conditions limit relevance.

**CDFOS-Q0027 · single · operations**

What should be checked before adding reservation and measured load?

Synthetic training case — not a field record.

A synthetic cooling group has four units, each demonstrated at 100 kW for the stated conditions. Current load is 210 kW and an accepted reservation is 40 kW. One unit is unavailable. The service policy requires capacity after one additional unit is isolated for maintenance. A sales request adds 30 kW. All four units also depend on one common control-power source.

1. That nameplate demand replaces every measured load value
2. That every reservation has already consumed physical power
3. That sales has removed all historical records
4. That the reservation is not already included in the measured demand

**Correct option(s):** 4

- Option 1: The stated planning rule requires semantic reconciliation, not an unexplained substitution.
- Option 2: Reservations commonly represent committed future demand.
- Option 3: History supports reconciliation rather than requiring deletion.
- Option 4: Avoid counting the same commitment twice.

**CDFOS-Q0028 · single · operations**

Which correction addresses the common control-power dependency?

Synthetic training case — not a field record.

A synthetic cooling group has four units, each demonstrated at 100 kW for the stated conditions. Current load is 210 kW and an accepted reservation is 40 kW. One unit is unavailable. The service policy requires capacity after one additional unit is isolated for maintenance. A sales request adds 30 kW. All four units also depend on one common control-power source.

1. Increasing the monitoring frequency without changing the power dependency
2. A reviewed supported architecture change and its own failure test
3. Document two logical control-power feeds while both remain connected to the same unsupported source
4. Adding another unit to the same unsupported source only

**Correct option(s):** 2

- Option 1: Better observation alone does not provide an independent control-power path.
- Option 2: Dependency removal must be implemented and verified.
- Option 3: Logical feed records do not remove the shared physical source or demonstrate failure tolerance.
- Option 4: Unit count alone can retain the common failure.

**CDFOS-Q0029 · single · mechanism**

What should an interim operations report distinguish?

Synthetic training case — not a field record.

A synthetic cooling group has four units, each demonstrated at 100 kW for the stated conditions. Current load is 210 kW and an accepted reservation is 40 kW. One unit is unavailable. The service policy requires capacity after one additional unit is isolated for maintenance. A sales request adds 30 kW. All four units also depend on one common control-power source.

1. Available capacity, committed demand, required state and unresolved risk
2. Only the estimated repair date
3. Only total installed rating
4. Only the new customer’s requested load

**Correct option(s):** 1

- Option 1: Readers need the constraint and its consequence.
- Option 2: A forecast does not describe current service capability.
- Option 3: That conceals unavailable equipment and maintenance exposure.
- Option 4: Existing commitments and dependencies are material.

**CDFOS-Q0030 · single · operations**

What closes the hold on additional commitment?

Synthetic training case — not a field record.

A synthetic cooling group has four units, each demonstrated at 100 kW for the stated conditions. Current load is 210 kW and an accepted reservation is 40 kW. One unit is unavailable. The service policy requires capacity after one additional unit is isolated for maintenance. A sales request adds 30 kW. All four units also depend on one common control-power source.

1. A separate sales approval without technical revalidation
2. A lower monthly average despite the unchanged maintenance constraint
3. Verified capability or an explicitly agreed revised service condition
4. A verbal assumption that no second event will occur

**Correct option(s):** 3

- Option 1: Commercial approval does not establish the required physical capability.
- Option 2: Average utilization cannot prove capacity in the required limiting state.
- Option 3: The authorized promise must match supportable delivery.
- Option 4: That does not satisfy the required maintenance state.

**CDFOS-Q0031 · single · mechanism**

What is wrong with the 100% claim?

Synthetic training case — not a field record.

A report claims “100% monitored availability.” Collector C was offline for 40 minutes, customer tickets describe a 12-minute service interruption, and the only surviving equipment log uses a clock known to be 8 minutes fast. The response-time sample is 1, 1, 2, 2, 4 and 20 minutes. The report shows only its 5-minute mean.

1. Customer tickets always override every technical observation
2. The available evidence does not establish continuous service
3. A collector outage proves all customers were unavailable
4. Clock offset invalidates every retained record permanently

**Correct option(s):** 2

- Option 1: Each source needs context and corroboration.
- Option 2: Collection failure and contrary observations require reconciliation.
- Option 3: Monitoring failure does not uniquely establish service loss.
- Option 4: Known timing error can be analyzed with appropriate limits.

**CDFOS-Q0032 · single · operations**

How should the equipment log’s known offset be handled?

Synthetic training case — not a field record.

A report claims “100% monitored availability.” Collector C was offline for 40 minutes, customer tickets describe a 12-minute service interruption, and the only surviving equipment log uses a clock known to be 8 minutes fast. The response-time sample is 1, 1, 2, 2, 4 and 20 minutes. The report shows only its 5-minute mean.

1. Ignore all events in that log
2. Assume the ticket and equipment clocks share the offset
3. Preserve raw time and document the offset in the correlated timeline
4. Rewrite the source log and discard the original

**Correct option(s):** 3

- Option 1: A known offset may still permit useful correlation.
- Option 2: Different sources require separate time-quality assessment.
- Option 3: This supports reconstruction without altering original evidence.
- Option 4: That removes the evidence needed to audit interpretation.

**CDFOS-Q0033 · single · mechanism**

What does the five-minute mean conceal?

Synthetic training case — not a field record.

A report claims “100% monitored availability.” Collector C was offline for 40 minutes, customer tickets describe a 12-minute service interruption, and the only surviving equipment log uses a clock known to be 8 minutes fast. The response-time sample is 1, 1, 2, 2, 4 and 20 minutes. The report shows only its 5-minute mean.

1. A twenty-minute response within the sample
2. That all six responses took five minutes
3. That response time equals restoration time
4. That the sample contains forty observations

**Correct option(s):** 1

- Option 1: An average does not describe every customer event.
- Option 2: The individual values expressly differ.
- Option 3: The sample concerns response, not verified service recovery.
- Option 4: There are six stated observations.

**CDFOS-Q0034 · single · operations**

What is the median response time?

Synthetic training case — not a field record.

A report claims “100% monitored availability.” Collector C was offline for 40 minutes, customer tickets describe a 12-minute service interruption, and the only surviving equipment log uses a clock known to be 8 minutes fast. The response-time sample is 1, 1, 2, 2, 4 and 20 minutes. The report shows only its 5-minute mean.

1. 10 minutes
2. 4 minutes
3. 2 minutes
4. 5 minutes

**Correct option(s):** 3

- Option 1: That is half the maximum, not the median.
- Option 2: Four is an observed value, not the middle pair.
- Option 3: The middle pair in the ordered six-value sample is two and two.
- Option 4: That is the arithmetic mean.

**CDFOS-Q0035 · single · operations**

Which report treatment is defensible while evidence remains incomplete?

Synthetic training case — not a field record.

A report claims “100% monitored availability.” Collector C was offline for 40 minutes, customer tickets describe a 12-minute service interruption, and the only surviving equipment log uses a clock known to be 8 minutes fast. The response-time sample is 1, 1, 2, 2, 4 and 20 minutes. The report shows only its 5-minute mean.

1. Report only equipment uptime and label it service availability
2. Delete the disputed interval from the service window
3. Separate established results, unknown intervals and investigation actions
4. Classify every unknown minute as healthy

**Correct option(s):** 3

- Option 1: The substituted metric has a different boundary.
- Option 2: That changes the agreed denominator without authority.
- Option 3: This preserves uncertainty and an accountable path to resolution.
- Option 4: Missing observations cannot justify that assumption.

**CDFOS-Q0036 · single · operations**

What is the first purpose of reporting collection coverage?

Synthetic training case — not a field record.

A report claims “100% monitored availability.” Collector C was offline for 40 minutes, customer tickets describe a 12-minute service interruption, and the only surviving equipment log uses a clock known to be 8 minutes fast. The response-time sample is 1, 1, 2, 2, 4 and 20 minutes. The report shows only its 5-minute mean.

1. Replace unavailable observation intervals with the preceding healthy sample
2. Demonstrate that no customer impact occurred
3. Show which periods the monitoring evidence actually represents
4. Replace the incident investigation

**Correct option(s):** 3

- Option 1: Coverage reporting should expose gaps, not silently carry forward health.
- Option 2: Coverage alone does not measure customer service.
- Option 3: Coverage limits the strength of conclusions from that source.
- Option 4: Reports do not eliminate the need to resolve contradictions.

**CDFOS-Q0037 · single · operations**

Which response distribution statement is accurate?

Synthetic training case — not a field record.

A report claims “100% monitored availability.” Collector C was offline for 40 minutes, customer tickets describe a 12-minute service interruption, and the only surviving equipment log uses a clock known to be 8 minutes fast. The response-time sample is 1, 1, 2, 2, 4 and 20 minutes. The report shows only its 5-minute mean.

1. The largest observation should always be excluded
2. The mean proves no outlier exists
3. Five responses were at most four minutes and one was twenty
4. Every response met a five-minute target

**Correct option(s):** 3

- Option 1: Exclusion needs a justified measurement rule, not inconvenience.
- Option 2: The listed twenty-minute observation contradicts that inference.
- Option 3: This follows directly from the disclosed sample.
- Option 4: The twenty-minute response would fail that target.

**CDFOS-Q0038 · single · operations**

What must precede comparing a percentile with another month?

Synthetic training case — not a field record.

A report claims “100% monitored availability.” Collector C was offline for 40 minutes, customer tickets describe a 12-minute service interruption, and the only surviving equipment log uses a clock known to be 8 minutes fast. The response-time sample is 1, 1, 2, 2, 4 and 20 minutes. The report shows only its 5-minute mean.

1. Confirm method, population, sample size and measurement boundaries
2. Use whichever calculation produces the better target result
3. Round both means to whole minutes
4. Remove all slow responses from both samples

**Correct option(s):** 1

- Option 1: Different definitions or populations can distort comparison.
- Option 2: The method must be consistent and agreed.
- Option 3: Rounding means does not align percentile definitions.
- Option 4: That biases the service result.

**CDFOS-Q0039 · single · operations**

Who should receive a corrected material service result?

Synthetic training case — not a field record.

A report claims “100% monitored availability.” Collector C was offline for 40 minutes, customer tickets describe a 12-minute service interruption, and the only surviving equipment log uses a clock known to be 8 minutes fast. The response-time sample is 1, 1, 2, 2, 4 and 20 minutes. The report shows only its 5-minute mean.

1. No one once a report has been issued
2. Every external contact regardless of information scope
3. The defined report recipients through the controlled correction process
4. Only the analyst who noticed the error

**Correct option(s):** 3

- Option 1: Publication does not make an error immutable.
- Option 2: Distribution should respect the approved audience and sensitivity.
- Option 3: The affected audience needs a traceable revised interpretation.
- Option 4: Other recipients would retain the incorrect result.

**CDFOS-Q0040 · single · mechanism**

What distinguishes a customer metric from an equipment indicator?

Synthetic training case — not a field record.

A report claims “100% monitored availability.” Collector C was offline for 40 minutes, customer tickets describe a 12-minute service interruption, and the only surviving equipment log uses a clock known to be 8 minutes fast. The response-time sample is 1, 1, 2, 2, 4 and 20 minutes. The report shows only its 5-minute mean.

1. Both are interchangeable when expressed as percentages
2. Customer metrics cannot use technical telemetry
3. Equipment indicators are never useful
4. The customer metric measures the agreed delivered outcome

**Correct option(s):** 4

- Option 1: Equal units do not imply equal definitions.
- Option 2: Telemetry can measure the agreed service interface.
- Option 3: They can support diagnosis and early warning.
- Option 4: Equipment health helps explain service but may not equal it.

**CDFOS-Q0041 · single · operations**

Does passing monthly availability justify closing the complaint without investigation?

Synthetic training case — not a field record.

Tenant T reports repeated short disruptions and poor updates. The monthly availability target passed, but three incident notifications were sent to an obsolete contact. A satisfaction survey received 8 replies from 80 tenants; 7 were positive. The complaint procedure requires an assigned owner, acknowledgment and a reasoned response.

1. No; communication and repeated disruption may concern separate requirements
2. Yes; a percentage supersedes all customer observations
3. Yes; complaints apply only to complete facility outages
4. No; every complaint proves the operator breached the contract

**Correct option(s):** 1

- Option 1: One successful metric does not resolve every service concern.
- Option 2: The agreement and experience include more than one metric.
- Option 3: Short or partial disruption can still be material.
- Option 4: The concern still requires a fair evidence-based assessment.

**CDFOS-Q0042 · single · operations**

What is the immediate complaint-management action?

Synthetic training case — not a field record.

Tenant T reports repeated short disruptions and poor updates. The monthly availability target passed, but three incident notifications were sent to an obsolete contact. A satisfaction survey received 8 replies from 80 tenants; 7 were positive. The complaint procedure requires an assigned owner, acknowledgment and a reasoned response.

1. Remove the customer’s old tickets
2. Assign ownership, acknowledge and preserve the reported facts
3. Offer a technical root cause before reviewing evidence
4. Wait for the next annual satisfaction survey

**Correct option(s):** 2

- Option 1: Those records may explain recurrence and impact.
- Option 2: This starts the defined accountable review process.
- Option 3: Premature attribution can mislead the investigation.
- Option 4: That delays the stated complaint procedure.

**CDFOS-Q0043 · single · operations**

What directly explains the missed notifications?

Synthetic training case — not a field record.

Tenant T reports repeated short disruptions and poor updates. The monthly availability target passed, but three incident notifications were sent to an obsolete contact. A satisfaction survey received 8 replies from 80 tenants; 7 were positive. The complaint procedure requires an assigned owner, acknowledgment and a reasoned response.

1. Every monitoring sensor had failed
2. The availability formula was necessarily wrong
3. The approved distribution process retained an obsolete contact
4. The customer’s servers were necessarily misconfigured

**Correct option(s):** 3

- Option 1: The evidence concerns notification addressing, not all sensing.
- Option 2: No such calculation error is stated.
- Option 3: The case supplies a concrete communication-path defect.
- Option 4: Server configuration does not explain the wrong recipient.

**CDFOS-Q0044 · single · operations**

What is the survey response rate?

Synthetic training case — not a field record.

Tenant T reports repeated short disruptions and poor updates. The monthly availability target passed, but three incident notifications were sent to an obsolete contact. A satisfaction survey received 8 replies from 80 tenants; 7 were positive. The complaint procedure requires an assigned owner, acknowledgment and a reasoned response.

1. 10%
2. 8%
3. 87.5%
4. 70%

**Correct option(s):** 1

- Option 1: Eight of eighty invited tenants responded.
- Option 2: Eight responses are not eight percent of eighty.
- Option 3: That is the positive share among respondents.
- Option 4: Seven positive responses do not equal seventy percent of invitations.

**CDFOS-Q0045 · single · operations**

What may be reported about positive sentiment?

Synthetic training case — not a field record.

Tenant T reports repeated short disruptions and poor updates. The monthly availability target passed, but three incident notifications were sent to an obsolete contact. A satisfaction survey received 8 replies from 80 tenants; 7 were positive. The complaint procedure requires an assigned owner, acknowledgment and a reasoned response.

1. Seven of eight respondents were positive, with limited coverage
2. Only one tenant in the building is dissatisfied
3. The complaint is invalid because most respondents were positive
4. 87.5% of all tenants are proven satisfied

**Correct option(s):** 1

- Option 1: The statement preserves both observed result and sample limitation.
- Option 2: The survey does not establish every tenant’s view.
- Option 3: Aggregate sentiment does not adjudicate a specific concern.
- Option 4: Nonrespondents were not measured by this survey.

**CDFOS-Q0046 · single · mechanism**

What should a reasoned complaint response distinguish?

Synthetic training case — not a field record.

Tenant T reports repeated short disruptions and poor updates. The monthly availability target passed, but three incident notifications were sent to an obsolete contact. A satisfaction survey received 8 replies from 80 tenants; 7 were positive. The complaint procedure requires an assigned owner, acknowledgment and a reasoned response.

1. Established facts, unmet requirements, uncertainty and corrective actions
2. Only the service-credit amount
3. Only the internal ticket status
4. Only whether the operations team feels blamed

**Correct option(s):** 1

- Option 1: The customer can understand both conclusion and remaining work.
- Option 2: A remedy does not explain the failure or improvement.
- Option 3: Status alone does not communicate the investigation outcome.
- Option 4: Feelings do not resolve the service evidence.

**CDFOS-Q0047 · single · operations**

Which corrective action addresses notification recurrence?

Synthetic training case — not a field record.

Tenant T reports repeated short disruptions and poor updates. The monthly availability target passed, but three incident notifications were sent to an obsolete contact. A satisfaction survey received 8 replies from 80 tenants; 7 were positive. The complaint procedure requires an assigned owner, acknowledgment and a reasoned response.

1. Increase every environmental alarm threshold
2. Send unrestricted details to all tenant addresses
3. Stop sending notifications to reduce failures
4. Assign contact ownership and periodically test the notification route

**Correct option(s):** 4

- Option 1: Thresholds do not correct the recipient list.
- Option 2: Broad distribution creates unnecessary disclosure and confusion.
- Option 3: That abandons the communication requirement.
- Option 4: This repairs the process that allowed stale recipients.

**CDFOS-Q0048 · single · operations**

What should govern a disputed contractual remedy?

Synthetic training case — not a field record.

Tenant T reports repeated short disruptions and poor updates. The monthly availability target passed, but three incident notifications were sent to an obsolete contact. A satisfaction survey received 8 replies from 80 tenants; 7 were positive. The complaint procedure requires an assigned owner, acknowledgment and a reasoned response.

1. The first operator’s personal preference
2. Automatic acceptance of either party’s first claim
3. The survey’s average score
4. The agreed dispute route and authorized decision process

**Correct option(s):** 4

- Option 1: Individual preference is not the agreed decision mechanism.
- Option 2: Fair review requires the defined evidence and authority.
- Option 3: Sentiment does not determine contractual interpretation.
- Option 4: Technical findings inform but do not replace contractual authority.

**CDFOS-Q0049 · single · mechanism**

Why retain the original complaint wording alongside categories?

Synthetic training case — not a field record.

Tenant T reports repeated short disruptions and poor updates. The monthly availability target passed, but three incident notifications were sent to an obsolete contact. A satisfaction survey received 8 replies from 80 tenants; 7 were positive. The complaint procedure requires an assigned owner, acknowledgment and a reasoned response.

1. It proves the customer’s hypothesis is correct
2. It preserves context that standardized labels can lose
3. It requires publishing identifiable details to every tenant
4. It eliminates the need to classify recurrence

**Correct option(s):** 2

- Option 1: Original wording is an account, not automatic causal proof.
- Option 2: Trend coding is useful but may simplify the reported experience.
- Option 3: Retention does not imply unrestricted disclosure.
- Option 4: Consistent categories still support pattern analysis.

**CDFOS-Q0050 · single · operations**

What closes the complaint responsibly?

Synthetic training case — not a field record.

Tenant T reports repeated short disruptions and poor updates. The monthly availability target passed, but three incident notifications were sent to an obsolete contact. A satisfaction survey received 8 replies from 80 tenants; 7 were positive. The complaint procedure requires an assigned owner, acknowledgment and a reasoned response.

1. Communicated findings and agreed actions with any remaining escalation recorded
2. A promise of perfect service without supporting changes
3. A passed availability chart alone
4. Deleting the complaint after acknowledgment

**Correct option(s):** 1

- Option 1: Closure follows the defined process and preserves unresolved matters.
- Option 2: An unsupported assurance is not an evidence-based resolution.
- Option 3: That does not address the identified notification defect.
- Option 4: Acknowledgment starts rather than completes the investigation.

**CDFOS-Q0051 · single · operations**

Which stage is the first improvement candidate from the supplied medians?

Synthetic training case — not a field record.

Twelve comparable restoration events show median detection 2 min, escalation 3 min, spare retrieval 35 min and repair/verification 20 min. A proposal places a controlled spare near the service area. Trial retrieval median is 8 min, but one spare was used without identity verification and caused a wrong-part delay. Trial workload and event definitions otherwise match the baseline.

1. Spare retrieval
2. Escalation only
3. Detection only
4. Report publication

**Correct option(s):** 1

- Option 1: Its thirty-five-minute median is the largest listed stage.
- Option 2: The three-minute stage is not the observed main delay.
- Option 3: Detection is much shorter in the supplied baseline.
- Option 4: No reporting delay is part of the supplied restoration breakdown.

**CDFOS-Q0052 · single · operations**

What is the observed reduction in median retrieval time?

Synthetic training case — not a field record.

Twelve comparable restoration events show median detection 2 min, escalation 3 min, spare retrieval 35 min and repair/verification 20 min. A proposal places a controlled spare near the service area. Trial retrieval median is 8 min, but one spare was used without identity verification and caused a wrong-part delay. Trial workload and event definitions otherwise match the baseline.

1. 35 minutes
2. 8 minutes
3. 27 minutes
4. 43 minutes

**Correct option(s):** 3

- Option 1: That is the baseline value and ignores remaining retrieval time.
- Option 2: That is the trial median rather than the reduction.
- Option 3: Thirty-five minus eight equals twenty-seven.
- Option 4: That adds the before and after medians.

**CDFOS-Q0053 · single · recovery**

Can stage medians simply be summed to prove end-to-end median restoration?

Synthetic training case — not a field record.

Twelve comparable restoration events show median detection 2 min, escalation 3 min, spare retrieval 35 min and repair/verification 20 min. A proposal places a controlled spare near the service area. Trial retrieval median is 8 min, but one spare was used without identity verification and caused a wrong-part delay. Trial workload and event definitions otherwise match the baseline.

1. Yes; all statistics are additive across stages
2. Yes; a smaller retrieval median proves every event improved
3. No; medians are never useful operational metrics
4. No; calculate end-to-end results from matched event timelines

**Correct option(s):** 4

- Option 1: The relationship does not hold generally for medians.
- Option 2: Individual outcomes can differ, as the wrong-part event shows.
- Option 3: They are useful when their scope is understood.
- Option 4: Medians of components do not generally sum to the median total.

**CDFOS-Q0054 · single · operations**

What adverse effect must the trial address?

Synthetic training case — not a field record.

Twelve comparable restoration events show median detection 2 min, escalation 3 min, spare retrieval 35 min and repair/verification 20 min. A proposal places a controlled spare near the service area. Trial retrieval median is 8 min, but one spare was used without identity verification and caused a wrong-part delay. Trial workload and event definitions otherwise match the baseline.

1. A spare was issued without identity verification
2. The baseline had twelve events
3. The detection median stayed at two minutes
4. The spare was physically closer to the work area

**Correct option(s):** 1

- Option 1: The faster process introduced a concrete compatibility-control failure.
- Option 2: Sample size limits inference but is not the stated adverse event.
- Option 3: An unchanged unrelated stage does not by itself negate the trial.
- Option 4: Proximity is the intended intervention, not inherently a defect.

**CDFOS-Q0055 · single · operations**

Which control belongs in the improved spare process?

Synthetic training case — not a field record.

Twelve comparable restoration events show median detection 2 min, escalation 3 min, spare retrieval 35 min and repair/verification 20 min. A proposal places a controlled spare near the service area. Trial retrieval median is 8 min, but one spare was used without identity verification and caused a wrong-part delay. Trial workload and event definitions otherwise match the baseline.

1. Verified identity, compatibility, custody and replenishment
2. Remove all issue records to save time
3. Permit unrecorded personal storage of parts
4. Accept any visually similar spare

**Correct option(s):** 1

- Option 1: These keep faster access from bypassing required suitability and stock control.
- Option 2: That sacrifices traceability and inventory accuracy.
- Option 3: Uncontrolled custody can create loss and readiness problems.
- Option 4: Appearance does not establish supported compatibility.

**CDFOS-Q0056 · single · operations**

What comparison supports attributing an improvement to the trial?

Synthetic training case — not a field record.

Twelve comparable restoration events show median detection 2 min, escalation 3 min, spare retrieval 35 min and repair/verification 20 min. A proposal places a controlled spare near the service area. Trial retrieval median is 8 min, but one spare was used without identity verification and caused a wrong-part delay. Trial workload and event definitions otherwise match the baseline.

1. Only the fastest trial event
2. Comparable event definitions, workload and observation coverage
3. A quiet trial week compared with an unrelated major incident
4. A vendor’s benchmark from another facility

**Correct option(s):** 2

- Option 1: Selecting a best case biases the conclusion.
- Option 2: These reduce alternative explanations for the measured change.
- Option 3: Different conditions confound the effect.
- Option 4: That does not measure this process change.

**CDFOS-Q0057 · single · operations**

What should the improvement owner do with the wrong-part result?

Synthetic training case — not a field record.

Twelve comparable restoration events show median detection 2 min, escalation 3 min, spare retrieval 35 min and repair/verification 20 min. A proposal places a controlled spare near the service area. Trial retrieval median is 8 min, but one spare was used without identity verification and caused a wrong-part delay. Trial workload and event definitions otherwise match the baseline.

1. Retain it, investigate and revise acceptance before expansion
2. Exclude it because it reduces the apparent benefit
3. Rename it as a training event after the fact
4. Stop collecting all further results

**Correct option(s):** 1

- Option 1: Rejected or adverse outcomes are essential trial evidence.
- Option 2: Convenient omission would bias the assessment.
- Option 3: Relabeling does not remove its relevance to the trial.
- Option 4: The design needs a reasoned next step, not loss of evidence.

**CDFOS-Q0058 · single · recovery**

Which measure verifies that speed did not weaken restoration quality?

Synthetic training case — not a field record.

Twelve comparable restoration events show median detection 2 min, escalation 3 min, spare retrieval 35 min and repair/verification 20 min. A proposal places a controlled spare near the service area. Trial retrieval median is 8 min, but one spare was used without identity verification and caused a wrong-part delay. Trial workload and event definitions otherwise match the baseline.

1. Full functional verification and rework/recurrence outcomes
2. Only distance walked to the spare shelf
3. Only the trial sponsor’s satisfaction
4. Only number of parts issued

**Correct option(s):** 1

- Option 1: A faster intermediate step can still worsen final service.
- Option 2: Distance does not prove correct repaired function.
- Option 3: Opinion complements but cannot replace functional evidence.
- Option 4: Issue volume does not demonstrate repair quality.

**CDFOS-Q0059 · single · operations**

What is a defensible expansion decision?

Synthetic training case — not a field record.

Twelve comparable restoration events show median detection 2 min, escalation 3 min, spare retrieval 35 min and repair/verification 20 min. A proposal places a controlled spare near the service area. Trial retrieval median is 8 min, but one spare was used without identity verification and caused a wrong-part delay. Trial workload and event definitions otherwise match the baseline.

1. Expand immediately because one median improved
2. Reject permanently without examining a correctable process defect
3. Let each shift invent its own undocumented issue method
4. Proceed only after the defined performance and control criteria pass

**Correct option(s):** 4

- Option 1: The observed wrong-part issue remains unresolved.
- Option 2: A bounded revision and retest may resolve the problem.
- Option 3: That undermines repeatability and controlled operation.
- Option 4: The improvement must satisfy both benefit and operational safeguards.

**CDFOS-Q0060 · single · implementation**

What should happen after an accepted improvement is implemented?

Synthetic training case — not a field record.

Twelve comparable restoration events show median detection 2 min, escalation 3 min, spare retrieval 35 min and repair/verification 20 min. A proposal places a controlled spare near the service area. Trial retrieval median is 8 min, but one spare was used without identity verification and caused a wrong-part delay. Trial workload and event definitions otherwise match the baseline.

1. Archive all monitoring because the project passed
2. Keep the old procedure as the only approved version
3. Claim the same improvement for every unrelated service
4. Update procedures/training and schedule a sustained-result review

**Correct option(s):** 4

- Option 1: Performance can drift after initial acceptance.
- Option 2: That would conflict with the implemented process.
- Option 3: The evidence applies to the tested process and conditions.
- Option 4: Adoption and follow-up make the gain operationally durable.

#### Recall

**What makes a service promise measurable?**

A defined outcome and boundary, operating conditions, metric clock, evidence source and accountable owner.

**Does a service catalogue include every proposed service?**

An orderable entry requires reviewed capability and authority; proposals can remain in the portfolio without becoming commitments.

**How are overlapping outages counted for one service?**

Use the union of qualifying intervals so each unavailable minute is counted once.

**Does planned work automatically disappear from SLA availability?**

No. Apply the agreed service window and explicit exclusions; scheduling alone does not create an exclusion.

**Capacity promise in a degraded maintenance state — Synthetic training case — not a field record.

A synthetic cooling group has four units, each demonstrated at 100 kW for the stated conditions. Current load is 210 kW and an accepted reservation is 40 kW. One unit is unavailable. The service policy requires capacity after one additional unit is isolated for maintenance. A sales request adds 30 kW. All four units also depend on one common control-power source.**

With one unit unavailable and another removed, two units remain: 200 kW. Existing measured load plus the separate accepted reservation is 250 kW under the stated planning rule, so the required maintenance state is already unsupported. Hold additional commitment and escalate the existing exposure. The control-power source is a separate common dependency; adding nameplate capacity does not resolve it.

**Reporting integrity and contradictory observations — Synthetic training case — not a field record.

A report claims “100% monitored availability.” Collector C was offline for 40 minutes, customer tickets describe a 12-minute service interruption, and the only surviving equipment log uses a clock known to be 8 minutes fast. The response-time sample is 1, 1, 2, 2, 4 and 20 minutes. The report shows only its 5-minute mean.**

Distinguish monitoring coverage from service availability. Preserve the customer account and clock offset, correlate independent evidence and report unresolved intervals. The sample mean is five minutes but one response took twenty; display the distribution and the agreed target rather than treating the mean as universal experience. Keep original and corrected report versions.

**Complaint, satisfaction and fair review — Synthetic training case — not a field record.

Tenant T reports repeated short disruptions and poor updates. The monthly availability target passed, but three incident notifications were sent to an obsolete contact. A satisfaction survey received 8 replies from 80 tenants; 7 were positive. The complaint procedure requires an assigned owner, acknowledgment and a reasoned response.**

Passing one target does not resolve communication failures or the tenant’s experience. Assign the complaint, preserve its facts, correct the contact governance and assess the notification requirement. Report seven positive responses among eight respondents and a ten-percent response rate; do not claim that 87.5% of all tenants are satisfied.

**Service improvement trial and acceptance — Synthetic training case — not a field record.

Twelve comparable restoration events show median detection 2 min, escalation 3 min, spare retrieval 35 min and repair/verification 20 min. A proposal places a controlled spare near the service area. Trial retrieval median is 8 min, but one spare was used without identity verification and caused a wrong-part delay. Trial workload and event definitions otherwise match the baseline.**

The observed limiting stage is spare retrieval. The median stage reduction is 27 minutes, but medians cannot automatically be added to prove the same end-to-end improvement. The identity-check failure is an adverse effect needing correction. Approve wider use only after supported compatibility, custody, replenishment and full restoration measurements meet the trial criteria.

#### References

- [EPI CDFOS public syllabus](https://www.epi-ap.com/services/1/3/136)

## CDFOS-M02 — Safety decisions, energy control and crisis coordination

### CDFOS-L02 — Safety decisions, energy control and crisis coordination

Estimated study time: 120 minutes before independent work. Prerequisite chapters: CDFOS-L01

## Safety is a condition of the work

Facilities operations combines routine observation with activities that can expose people to stored energy, moving equipment, elevated work, heavy objects, chemicals, noise, heat and impaired escape routes. A familiar task can become hazardous when the equipment state, nearby work or workforce changes. Begin with the actual task and location rather than a generic form. Identify who could be affected, including contractors, visitors and people passing through the area. Define the conditions that make the work acceptable and the triggers that require stopping and reassessment.

An incident usually has more than one contributing condition. A person may trip over a temporary cable because the route was poorly planned, the area was congested, lighting was inadequate and shift handover omitted the obstruction. Recording only “operator carelessness” misses controls that could prevent recurrence. Investigate the work design, information, supervision, equipment and organizational pressures as well as the immediate action. Near misses are useful because the same uncontrolled condition may later cause harm. Preserve factual observations and distinguish them from an investigator’s hypothesis.

Select controls by how they reduce exposure. Removing an unnecessary hazardous task or relocating it to a safer environment can be stronger than relying on a warning. Engineering measures, barriers, access design, task organization, procedures and protective equipment have different roles. Personal protective equipment does not make an unsuitable method inherently acceptable. Check whether a proposed control introduces another hazard, such as a barrier that blocks the only usable exit. A control must work under the actual operating conditions and remain in place for the period of exposure.

## Roles, competence and the safety manual

The site’s occupational health and safety manual establishes the management arrangements applicable to that site and jurisdiction. It should connect policy to practical responsibilities, training, risk assessment, reporting, emergency arrangements, permits and review. A manual is useful only if workers can find the current relevant instruction and understand how it applies. An outdated local printout can contradict an approved procedure. Maintain controlled access, version identity, distribution and withdrawal of obsolete instructions.

Appointed safety staff coordinate and advise within defined authority; they do not absorb every other person’s responsibility. The work supervisor must ensure the task is planned and the team understands its boundaries. The permit issuer and recipient have distinct functions under the selected system. Specialists perform work requiring their competence and authorization. A contractor’s general qualification does not prove familiarity with the site’s equipment, isolation arrangement or emergency route. Record the task-specific briefing and verify understanding through demonstration or questioning appropriate to the risk.

Do not equate attendance with competence. Competence combines relevant knowledge, practical ability, experience and awareness of limits for the assigned activity. A person can be competent to inspect a dashboard but not to switch electrical equipment. The charter retains D4–D7 practical ownership while requiring appropriate specialists for power, mechanical and protective-system work. The app’s exercises are analytical or controlled laboratory learning; they do not grant live-work authority. Where a person recognizes an unsafe or unplanned condition, the procedure should provide a clear stop and escalation route without pressure to continue for schedule convenience.

## Measurement tools must be fit for the decision

A calibration label is a pointer to evidence, not the entire assurance argument. Check instrument identity, the quantity and range calibrated, method, uncertainty, relevant environmental conditions, due status and evidence of damage or misuse. A current certificate for one range does not automatically cover another range. Fine display resolution does not establish accuracy. The measurement method and uncertainty must be suitable for the acceptance limit being assessed.

Preserve as-found results before adjustment and as-left results afterward. If an instrument is found outside its allowed performance, identify which earlier decisions relied on it and whether the possible error could change acceptance. Do not automatically discard every prior result, or assume none are affected. Bound the review using last known good status, usage records, failure behavior, measurement margins and independent evidence. Quarantine or otherwise prevent unintended use according to the tool-control procedure while the issue is resolved.

For a simple conservative assessment, a measured deviation plus the declared uncertainty bound can be compared with a limit when that decision rule is appropriate. A reading 0.4 units from nominal with a 0.2-unit bound cannot demonstrate a ±0.5-unit requirement by worst-case reasoning. The result may require adjustment, a better measurement method or a reviewed decision rule; rounding the reading to a favorable value is not a remedy. Record the rule before testing so it cannot be selected opportunistically after seeing the result.

## Hazardous-energy control is a verified state

A stop command changes operation; isolation controls hazardous energy. Equipment may retain energy after its normal supply is removed through batteries, capacitors, pressurized fluid, gravity, springs, thermal storage or another feed. An HMI showing Stopped does not establish that work is safe. Identify the actual energy sources and possible reaccumulation, use the equipment-specific approved isolation method through authorized personnel, and verify the required safe state with suitable means. This is conceptual teaching, not a switching instruction for a live installation.

Lockout and tagging arrangements support control of reconnection and communication of the protected work state. Their detailed legal and site requirements vary. A tag warning is not automatically equivalent to a physical isolation device. The selected procedure must address personal protection, identity, multiple workers, contractors, work suspension, shift changes, testing and return to service. No learner should remove another person’s protection merely because a shift ended or the schedule is late. Exceptional situations require the formal authorized process and verification that affected people are protected.

Group work needs a clear relationship between the isolated equipment, the controlling arrangement and every person exposed. Shift transfer must preserve continuous protection and communicate the actual work and equipment state. A signature alone is insufficient if the incoming team cannot identify the remaining hazards or confirm the applicable controls. Before authorized return to service, account for personnel, tools, guards, temporary connections and the required approvals; then verify restored function under the approved method. Completion of the repair and permission to reenergize are separate decisions.

## Permits coordinate work; they do not remove hazards

A permit to work records a defined task, location, validity, responsible people, hazards, precautions and authorization within a site system. It should connect to the risk assessment and method, not substitute for them. A signed permit does not make an unrecognized energy source harmless or prove that conditions remain unchanged. Confirm prerequisites and interactions before starting. If scope, location, personnel, equipment state or surrounding work changes materially, stop and obtain the required reassessment and revalidation.

Simultaneous work can create hazards that neither job has in isolation. Hot work near a temporary fire-detection impairment, overhead work above an occupied access route, or maintenance on two supporting paths can invalidate assumptions. Use a coordinated work view and responsible authority to identify conflicts. Retain required fire-system specialist controls and any approved compensatory measures; an operations learner does not invent them. Permit suspension, handback and closure must communicate what remains isolated, impaired or unfinished.

## Crisis response prioritizes people and coordinated decisions

An emergency plan describes credible scenarios, alarms, evacuation or shelter arrangements, assembly/accountability, communication, responder access and command. It should address people needing assistance and visitors who may not know the site. A facility incident can also create a wider service crisis, but restoring IT service must not override life-safety decisions. Follow the site plan and emergency-service direction; do not send untrained people into a hazardous area to collect equipment or investigate an unexplained atmosphere.

Define who initiates notifications, who coordinates the incident, who communicates with customers and who authorizes re-entry or restoration. Maintain alternatives if normal phones, identity systems or network services fail. A drill tests these arrangements against an observable objective: whether people receive the alarm, reach the correct place, are accounted for and communicate useful information. Record gaps and corrective actions without treating a tabletop discussion as a physical evacuation exercise.

Recovery begins only when the responsible authority releases the relevant area or function and the technical prerequisites are met. Preserve incident evidence when compatible with immediate safety needs. Reconcile temporary overrides, impairments, access permissions and configuration changes before normal operation. A post-event review should identify improvements to prevention, detection, response and handover, with owners and due dates. Generic guidance in this course does not establish compliance with every local law; use the current site and jurisdiction requirements and qualified safety advice for actual work.

#### Worked demonstrations

**Near miss at a temporary work route**

Synthetic training case — not a field record.

A technician trips over a temporary cable crossing a normal aisle beside an open floor work area. No injury occurs. The cable route was changed after the morning briefing. A warning sign is partly hidden by packaging. A proposed barrier would close the only marked escape route. The supervisor suggests recording “inattention” and continuing unchanged.

**Reasoning:** Treat the near miss as evidence of uncontrolled exposure. Make the area safe through the approved site process, reassess the changed route and preserve the escape path. Investigate the route change, visibility, housekeeping and communication instead of closing on a personal-blame label. Verify any replacement control in the real work arrangement.

**Safety roles and task-specific competence**

Synthetic training case — not a field record.

A contractor holds a general electrical qualification but has not been briefed on the facility’s dual-source equipment. An operations analyst completed the app and can view the EPMS. The current safety manual is revision 8; the job pack contains revision 5. The appointed safety adviser is offsite, and the work supervisor proposes starting because the permit form has been signed.

**Reasoning:** Resolve the outdated instructions and task-specific competence gap before work. General qualification, dashboard access and course completion establish different things. The supervisor and permit roles retain their responsibilities; absence of an adviser does not make an unsafe task acceptable or transfer specialist authority to an analyst.

**Calibration scope and an out-of-tolerance finding**

Synthetic training case — not a field record.

Temperature instrument T has a current certificate covering 0–50 °C. A proposed task needs 80 °C measurement with ±0.5 °C total allowed error. At a later check, a 40 °C reference produces 40.4 °C; the conservative reference bound is ±0.2 °C. The tool was used on five acceptance records since its last known-good check. Usage records identify those tasks.

**Reasoning:** The current certificate does not demonstrate performance at 80 °C. At 40 °C, worst-case deviation plus reference bound reaches 0.6 °C, so that rule cannot demonstrate ±0.5 °C compliance. Prevent unapproved use, retain as-found evidence and review the five prior decisions against their margins and conditions rather than assuming every result is either valid or invalid.

**Multiple energy sources in a paper isolation review**

Synthetic training case — not a field record.

Paper exercise only: a training unit has a normal AC feed, a battery-backed control supply, a pressurized actuator and a raised component held by a powered mechanism. The HMI shows Stopped. The draft work plan identifies only the normal AC feed and assumes no restart is possible. No physical switching is performed in this exercise.

**Reasoning:** The draft does not identify all energy sources or stored-energy effects. Stopped status is an operational command state, not verified isolation. An authorized specialist must develop and execute the equipment-specific method, including stored energy, reaccumulation and verification. The learner’s acceptable output is a documented hold and corrected hazard/interface review, not an improvised live switching sequence.

**Group protection and shift transfer**

Synthetic training case — not a field record.

A paper group-maintenance case has three authorized workers under the site’s approved group-protection system. Two workers leave at shift end; one remains inside the work boundary. The incoming supervisor receives a handover saying only “repair nearly complete.” A departing worker’s protection is still recorded. The schedule coordinator asks for immediate restart.

**Reasoning:** Work completion, worker accountability and restoration authority remain separate. Maintain the approved protection across the transfer, establish who remains exposed and reconcile every relevant control through the site procedure. A vague handover and schedule request do not authorize removal of another person’s protection or restart.

**Permit conflict and simultaneous work**

Synthetic training case — not a field record.

A contractor holds a permit for localized hot work. A different team schedules a fire-detection impairment in the same area during the same hour. The hot-work assessment assumed active detection and a clear service corridor. Delivery pallets now narrow that corridor. The permit issuer has not reviewed the combined work. No live work is performed in this case.

**Reasoning:** The combined condition differs from the assessed basis. Suspend the affected work through the site process and have the responsible authority coordinate the conflict with the fire-system specialist. Revalidate access, protective arrangements and any authorized compensatory measures before work; do not invent a workaround or assume two individually signed permits are compatible.

**Crisis command, accountability and recovery release**

Synthetic training case — not a field record.

A synthetic drill reports smoke near a service room and loss of normal internal phones. Two visitors are signed in, but only one is recorded at the assembly point. A customer asks an operator to re-enter for a storage device. Emergency responders have not released the area. The backup communications radio is available but its contact list is outdated.

**Reasoning:** Follow the site emergency plan, account for the missing visitor through the designated incident authority and use the approved alternative communication route. Do not send an untrained operator into an unreleased area for equipment. Preserve the communication and accountability gaps for corrective action. Technical recovery follows safety release and verified service prerequisites.

#### Guided practice

Review a synthetic work package containing an outdated instruction, an unlisted energy source, an uncertain instrument and a conflicting permit. State which work can proceed and what must be held.

**Hint:** A signature, a stopped display and a current sticker each prove only a narrow fact.

**Worked solution:** Hold the affected task until current instructions, task-specific competence, all energy sources, suitable measurement evidence and simultaneous-work controls are resolved through the authorized site process. Record distinct reasons and responsible roles. Keep the exercise analytical and do not invent a live switching method.

#### Independent task

Environment: analytical

Defend a safety and emergency-readiness review using the supplied synthetic cases.

**Packaged starter material**

- course_labs/CDFOS/README.md
- course_labs/CDFOS/fixture.json
- course_labs/CDFOS/assessment_template.md
- course_labs/CDFOS/lab.py
- course_labs/CDFOS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- Hazard/source and role matrix
- Instrument-suitability and prior-result review
- Permit conflict and shift-transfer decision
- Emergency accountability and communication improvement plan

**Acceptance criteria**

- No evidence class or authority is overstated.
- Unresolved hazards trigger the defined hold/escalation.
- Recovery separates safety release from technical acceptance.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer. The bundled calculator was executed against supplied synthetic fixtures; its numerical checks do not grade physical work or professional authorization.

#### Chapter practice

**CDFOS-Q0061 · single · operations**

Which fact most directly invalidates the morning briefing’s assumptions?

Synthetic training case — not a field record.

A technician trips over a temporary cable crossing a normal aisle beside an open floor work area. No injury occurs. The cable route was changed after the morning briefing. A warning sign is partly hidden by packaging. A proposed barrier would close the only marked escape route. The supervisor suggests recording “inattention” and continuing unchanged.

1. The work had a supervisor
2. The cable route changed after the briefing
3. A warning sign existed somewhere nearby
4. No injury was reported

**Correct option(s):** 2

- Option 1: Appointment alone does not ensure current conditions are controlled.
- Option 2: The team’s shared picture no longer matches the work area.
- Option 3: A hidden sign may not provide effective warning.
- Option 4: Absence of injury does not validate the hazard controls.

**CDFOS-Q0062 · single · operations**

How should the event be classified for learning?

Synthetic training case — not a field record.

A technician trips over a temporary cable crossing a normal aisle beside an open floor work area. No injury occurs. The cable route was changed after the morning briefing. A warning sign is partly hidden by packaging. A proposed barrier would close the only marked escape route. The supervisor suggests recording “inattention” and continuing unchanged.

1. A completed control test with a passing result
2. Proof that the worker alone caused the hazard
3. A harmless event because no treatment was needed
4. A near miss requiring factual review and corrective action

**Correct option(s):** 4

- Option 1: The trip demonstrates that the existing controls were ineffective.
- Option 2: The case contains several work-system contributors.
- Option 3: The same condition can cause future harm.
- Option 4: An uncontrolled exposure occurred without the eventual injury.

**CDFOS-Q0063 · single · mechanism**

Why is the proposed barrier unacceptable as described?

Synthetic training case — not a field record.

A technician trips over a temporary cable crossing a normal aisle beside an open floor work area. No injury occurs. The cable route was changed after the morning briefing. A warning sign is partly hidden by packaging. A proposed barrier would close the only marked escape route. The supervisor suggests recording “inattention” and continuing unchanged.

1. Barriers are never useful around floor work
2. Every temporary control needs to be permanent
3. It blocks the only marked escape route
4. The sign already makes every other measure unnecessary

**Correct option(s):** 3

- Option 1: Suitable barriers can be an effective control.
- Option 2: Temporary controls can be appropriate when governed and effective.
- Option 3: A control must not create an unresolved emergency-access hazard.
- Option 4: A partly hidden sign does not resolve the exposure.

**CDFOS-Q0064 · single · operations**

Which investigation question addresses a system cause?

Synthetic training case — not a field record.

A technician trips over a temporary cable crossing a normal aisle beside an open floor work area. No injury occurs. The cable route was changed after the morning briefing. A warning sign is partly hidden by packaging. A proposed barrier would close the only marked escape route. The supervisor suggests recording “inattention” and continuing unchanged.

1. Can the event be removed from the monthly count?
2. Who authorized and communicated the route change?
3. Which worker should automatically lose access?
4. Was the cable expensive enough to justify keeping it there?

**Correct option(s):** 2

- Option 1: Reporting appearance is not a prevention analysis.
- Option 2: The changed task arrangement may explain loss of control.
- Option 3: Predetermined punishment does not establish causes.
- Option 4: Purchase cost does not determine safe routing.

**CDFOS-Q0065 · single · operations**

Which measure is stronger than leaving the same crossing with another reminder?

Synthetic training case — not a field record.

A technician trips over a temporary cable crossing a normal aisle beside an open floor work area. No injury occurs. The cable route was changed after the morning briefing. A warning sign is partly hidden by packaging. A proposed barrier would close the only marked escape route. The supervisor suggests recording “inattention” and continuing unchanged.

1. Ask workers to remember the hidden sign
2. Require faster walking through the area
3. Move the incident record to a lower-priority queue
4. Eliminate the unnecessary crossing through an approved route

**Correct option(s):** 4

- Option 1: That retains the poorly controlled hazard.
- Option 2: Speed does not improve the physical route and can worsen risk.
- Option 3: Administrative classification does not reduce exposure.
- Option 4: Removing exposure is more reliable than relying solely on attention.

**CDFOS-Q0066 · single · operations**

What should be checked after revising the work layout?

Synthetic training case — not a field record.

A technician trips over a temporary cable crossing a normal aisle beside an open floor work area. No injury occurs. The cable route was changed after the morning briefing. A warning sign is partly hidden by packaging. A proposed barrier would close the only marked escape route. The supervisor suggests recording “inattention” and continuing unchanged.

1. Access, escape, visibility and effects on nearby people
2. Only the length of the new cable
3. Only that the contractor accepted the schedule
4. Only that the drawing now includes an exit symbol

**Correct option(s):** 1

- Option 1: The control must function in the actual shared environment.
- Option 2: Length alone does not establish a safe route.
- Option 3: Schedule agreement does not verify safety.
- Option 4: A drawing symbol does not verify the actual route is unobstructed.

**CDFOS-Q0067 · single · mechanism**

What should the factual record distinguish?

Synthetic training case — not a field record.

A technician trips over a temporary cable crossing a normal aisle beside an open floor work area. No injury occurs. The cable route was changed after the morning briefing. A warning sign is partly hidden by packaging. A proposed barrier would close the only marked escape route. The supervisor suggests recording “inattention” and continuing unchanged.

1. Only events that caused measurable injury
2. Only the final blame assignment
3. Only whether insurance was notified
4. Observed conditions from hypotheses about contributing causes

**Correct option(s):** 4

- Option 1: Near misses also reveal uncontrolled conditions.
- Option 2: That would omit the observations supporting the conclusion.
- Option 3: Notification is not the complete causal record.
- Option 4: This preserves evidence while allowing reasoned investigation.

**CDFOS-Q0068 · single · operations**

Who may be affected besides the technician?

Synthetic training case — not a field record.

A technician trips over a temporary cable crossing a normal aisle beside an open floor work area. No injury occurs. The cable route was changed after the morning briefing. A warning sign is partly hidden by packaging. A proposed barrier would close the only marked escape route. The supervisor suggests recording “inattention” and continuing unchanged.

1. Only staff named on the cable work order
2. Other workers, visitors and emergency users of the route
3. Only the person who moved the cable
4. Only people who read the sign

**Correct option(s):** 2

- Option 1: Passers-by may be exposed without participating in the task.
- Option 2: The hazard exists in a shared circulation area.
- Option 3: Responsibility and exposure are different concepts.
- Option 4: Those who do not see it may be especially exposed.

**CDFOS-Q0069 · single · operations**

What would show that a corrective action worked?

Synthetic training case — not a field record.

A technician trips over a temporary cable crossing a normal aisle beside an open floor work area. No injury occurs. The cable route was changed after the morning briefing. A warning sign is partly hidden by packaging. A proposed barrier would close the only marked escape route. The supervisor suggests recording “inattention” and continuing unchanged.

1. A verified safe arrangement and follow-up observation under use
2. Closing the corrective-action ticket alone
3. Issuing a reminder without inspecting the route
4. A promise that workers will be more careful

**Correct option(s):** 1

- Option 1: Implementation and effectiveness both need evidence.
- Option 2: Closure can occur without checking the actual area.
- Option 3: Communication alone does not prove exposure was removed.
- Option 4: An assurance is weaker than a functioning control.

**CDFOS-Q0070 · single · operations**

When should work resume?

Synthetic training case — not a field record.

A technician trips over a temporary cable crossing a normal aisle beside an open floor work area. No injury occurs. The cable route was changed after the morning briefing. A warning sign is partly hidden by packaging. A proposed barrier would close the only marked escape route. The supervisor suggests recording “inattention” and continuing unchanged.

1. After the authorized reassessment establishes acceptable current conditions
2. Immediately because the original permit still has time remaining
3. Whenever the customer requests completion
4. Only after every future facility hazard is eliminated

**Correct option(s):** 1

- Option 1: The changed environment requires a valid work basis.
- Option 2: Validity time does not cover material unassessed changes.
- Option 3: Customer urgency does not replace safety authorization.
- Option 4: The task needs appropriate scoped controls, not an impossible universal condition.

**CDFOS-Q0071 · single · mechanism**

What does the contractor’s general qualification establish by itself?

Synthetic training case — not a field record.

A contractor holds a general electrical qualification but has not been briefed on the facility’s dual-source equipment. An operations analyst completed the app and can view the EPMS. The current safety manual is revision 8; the job pack contains revision 5. The appointed safety adviser is offsite, and the work supervisor proposes starting because the permit form has been signed.

1. That no briefing is needed when a permit exists
2. Authorization for every task at any data center
3. That revision 5 is necessarily suitable
4. Relevant background, but not complete site-specific competence

**Correct option(s):** 4

- Option 1: A permit does not replace task understanding.
- Option 2: Qualification scope and site authority are bounded.
- Option 3: Document currency is a separate question.
- Option 4: The particular dual-source arrangement and procedures remain unverified.

**CDFOS-Q0072 · single · operations**

What may the analyst’s app completion support?

Synthetic training case — not a field record.

A contractor holds a general electrical qualification but has not been briefed on the facility’s dual-source equipment. An operations analyst completed the app and can view the EPMS. The current safety manual is revision 8; the job pack contains revision 5. The appointed safety adviser is offsite, and the work supervisor proposes starting because the permit form has been signed.

1. Proof of production incident experience
2. Permission to replace the contractor’s isolation procedure
3. Automatic electrical switching authority
4. Evidence of studied knowledge within the assessed scope

**Correct option(s):** 4

- Option 1: Study activity is a different evidence class.
- Option 2: The analyst has no stated specialist authority.
- Option 3: Operational authority requires separate competence and authorization.
- Option 4: It does not demonstrate authorized physical electrical work.

**CDFOS-Q0073 · single · operations**

What is the correct treatment of revision 5 in the job pack?

Synthetic training case — not a field record.

A contractor holds a general electrical qualification but has not been briefed on the facility’s dual-source equipment. An operations analyst completed the app and can view the EPMS. The current safety manual is revision 8; the job pack contains revision 5. The appointed safety adviser is offsite, and the work supervisor proposes starting because the permit form has been signed.

1. Assume every older revision is identical
2. Use it because printed copies are always authoritative
3. Edit its revision number without reviewing content
4. Reconcile it against the approved current instruction before use

**Correct option(s):** 4

- Option 1: The change history must be checked.
- Option 2: Medium does not determine approval or currency.
- Option 3: Relabeling cannot make obsolete instructions current.
- Option 4: An obsolete document may contain superseded controls.

**CDFOS-Q0074 · single · operations**

Does the signed permit prove the task is ready?

Synthetic training case — not a field record.

A contractor holds a general electrical qualification but has not been briefed on the facility’s dual-source equipment. An operations analyst completed the app and can view the EPMS. The current safety manual is revision 8; the job pack contains revision 5. The appointed safety adviser is offsite, and the work supervisor proposes starting because the permit form has been signed.

1. Yes; signature overrides equipment differences
2. Yes; the adviser’s absence transfers all authority to the form
3. No; permits can never support safe work
4. No; required conditions and competence still need verification

**Correct option(s):** 4

- Option 1: Unassessed hazards are not removed by signing.
- Option 2: Documents do not acquire independent decision-making authority.
- Option 3: Permits are useful when integrated with verified controls.
- Option 4: A form records authorization within a valid work system.

**CDFOS-Q0075 · single · operations**

What should the supervisor verify in the briefing?

Synthetic training case — not a field record.

A contractor holds a general electrical qualification but has not been briefed on the facility’s dual-source equipment. An operations analyst completed the app and can view the EPMS. The current safety manual is revision 8; the job pack contains revision 5. The appointed safety adviser is offsite, and the work supervisor proposes starting because the permit form has been signed.

1. Only that the job can finish before lunch
2. Only that everyone signed an attendance sheet
3. Only the contractor’s company registration
4. The team can explain task boundaries, hazards, controls and stop triggers

**Correct option(s):** 4

- Option 1: Schedule does not establish preparedness.
- Option 2: Attendance alone does not demonstrate usable understanding.
- Option 3: Corporate identity is not task-specific competence.
- Option 4: Understanding must connect the procedure to the actual work.

**CDFOS-Q0076 · single · operations**

What remains true while the safety adviser is offsite?

Synthetic training case — not a field record.

A contractor holds a general electrical qualification but has not been briefed on the facility’s dual-source equipment. An operations analyst completed the app and can view the EPMS. The current safety manual is revision 8; the job pack contains revision 5. The appointed safety adviser is offsite, and the work supervisor proposes starting because the permit form has been signed.

1. The customer becomes the permit issuer automatically
2. Any observer becomes the authorized electrical specialist
3. All safety requirements are suspended
4. Defined supervisory and worker responsibilities remain in force

**Correct option(s):** 4

- Option 1: Roles follow the site system, not an improvised substitution.
- Option 2: Authority does not transfer through proximity.
- Option 3: Staff location does not remove hazards or duties.
- Option 4: An adviser supports rather than absorbs all safety responsibility.

**CDFOS-Q0077 · single · operations**

Which competence evidence is most relevant to the dual-source task?

Synthetic training case — not a field record.

A contractor holds a general electrical qualification but has not been briefed on the facility’s dual-source equipment. An operations analyst completed the app and can view the EPMS. The current safety manual is revision 8; the job pack contains revision 5. The appointed safety adviser is offsite, and the work supervisor proposes starting because the permit form has been signed.

1. Read access to the monitoring application
2. A course certificate on an unrelated system
3. Assessed ability using the applicable equipment and approved procedure
4. Long employment without recorded relevant work

**Correct option(s):** 3

- Option 1: Information access does not imply physical-work competence.
- Option 2: Unrelated attendance does not demonstrate this task.
- Option 3: It addresses the actual hazards and actions involved.
- Option 4: Duration alone does not establish the required skill.

**CDFOS-Q0078 · single · operations**

What should an operator do on discovering an unplanned source?

Synthetic training case — not a field record.

A contractor holds a general electrical qualification but has not been briefed on the facility’s dual-source equipment. An operations analyst completed the app and can view the EPMS. The current safety manual is revision 8; the job pack contains revision 5. The appointed safety adviser is offsite, and the work supervisor proposes starting because the permit form has been signed.

1. Continue because the job is already authorized
2. Use the stop/escalation process and preserve a safe work state
3. Update the diagram after completing the work
4. Ask the analyst to improvise a switching sequence

**Correct option(s):** 2

- Option 1: Authorization depends on the assessed conditions.
- Option 2: A new energy source invalidates the assumed boundary.
- Option 3: Documentation cannot retroactively control the unassessed exposure.
- Option 4: The analyst’s stated role lacks that authority.

**CDFOS-Q0079 · single · operations**

What makes the safety manual operationally useful?

Synthetic training case — not a field record.

A contractor holds a general electrical qualification but has not been briefed on the facility’s dual-source equipment. An operations analyst completed the app and can view the EPMS. The current safety manual is revision 8; the job pack contains revision 5. The appointed safety adviser is offsite, and the work supervisor proposes starting because the permit form has been signed.

1. Storage only in an inaccessible corporate archive
2. Current controlled instructions linked to roles and actual tasks
3. Maximum length regardless of relevance
4. Unrestricted local editing by every contractor

**Correct option(s):** 2

- Option 1: Workers need the relevant current instructions when preparing work.
- Option 2: The manual must be available, applicable and understood.
- Option 3: Volume alone does not improve task guidance.
- Option 4: Uncontrolled versions can conflict.

**CDFOS-Q0080 · single · mechanism**

Revision 8 adds a second-source check absent from revision 5. What does this imply for the job pack?

Synthetic training case — not a field record.

A contractor holds a general electrical qualification but has not been briefed on the facility’s dual-source equipment. An operations analyst completed the app and can view the EPMS. The current safety manual is revision 8; the job pack contains revision 5. The appointed safety adviser is offsite, and the work supervisor proposes starting because the permit form has been signed.

1. Only the cover-page revision number needs changing
2. The second source may be ignored if the contractor is experienced
3. The method must be reviewed against the added source before work
4. The old method remains sufficient because its first source is correct

**Correct option(s):** 3

- Option 1: Relabeling leaves the missing technical control unresolved.
- Option 2: Experience does not remove an actual energy dependency.
- Option 3: The revision changes a material energy-control assumption.
- Option 4: Correct treatment of one source does not cover the added source.

**CDFOS-Q0081 · single · operations**

Does the current certificate demonstrate fitness for the 80 °C task?

Synthetic training case — not a field record.

Temperature instrument T has a current certificate covering 0–50 °C. A proposed task needs 80 °C measurement with ±0.5 °C total allowed error. At a later check, a 40 °C reference produces 40.4 °C; the conservative reference bound is ±0.2 °C. The tool was used on five acceptance records since its last known-good check. Usage records identify those tasks.

1. No; calibrated instruments can never be used for acceptance
2. No; its stated calibrated range ends at 50 °C
3. Yes; eighty degrees is merely another temperature
4. Yes; any current certificate covers every displayed value

**Correct option(s):** 2

- Option 1: Suitable calibrated instruments can support valid decisions.
- Option 2: Date validity does not extend the documented measurement range.
- Option 3: Performance can vary outside the assessed range.
- Option 4: Calibration scope is quantity- and range-specific.

**CDFOS-Q0082 · single · operations**

What is the observed error at the 40 °C check?

Synthetic training case — not a field record.

Temperature instrument T has a current certificate covering 0–50 °C. A proposed task needs 80 °C measurement with ±0.5 °C total allowed error. At a later check, a 40 °C reference produces 40.4 °C; the conservative reference bound is ±0.2 °C. The tool was used on five acceptance records since its last known-good check. Usage records identify those tasks.

1. +0.4 °C
2. 40.4 °C
3. −0.4 °C
4. +0.2 °C

**Correct option(s):** 1

- Option 1: The indication exceeds the reference value by four tenths.
- Option 2: That is the indication, not its error relative to forty.
- Option 3: The sign is reversed for the stated indication-minus-reference convention.
- Option 4: That is the reference uncertainty bound, not observed deviation.

**CDFOS-Q0083 · single · operations**

What conservative combined bound applies under the stated rule?

Synthetic training case — not a field record.

Temperature instrument T has a current certificate covering 0–50 °C. A proposed task needs 80 °C measurement with ±0.5 °C total allowed error. At a later check, a 40 °C reference produces 40.4 °C; the conservative reference bound is ±0.2 °C. The tool was used on five acceptance records since its last known-good check. Usage records identify those tasks.

1. 0.2 °C
2. 0.08 °C
3. 0.6 °C
4. 0.4 °C

**Correct option(s):** 3

- Option 1: Subtracting uncertainty would create unjustified favorable margin.
- Option 2: Multiplying the two values is not the stated combination rule.
- Option 3: Add the absolute 0.4 deviation and 0.2 reference bound.
- Option 4: This ignores the stated reference contribution.

**CDFOS-Q0084 · single · design**

Can the ±0.5 °C requirement be demonstrated by that result and rule?

Synthetic training case — not a field record.

Temperature instrument T has a current certificate covering 0–50 °C. A proposed task needs 80 °C measurement with ±0.5 °C total allowed error. At a later check, a 40 °C reference produces 40.4 °C; the conservative reference bound is ±0.2 °C. The tool was used on five acceptance records since its last known-good check. Usage records identify those tasks.

1. Yes; rounding 0.6 to one significant figure gives a pass
2. No; the conservative bound exceeds the allowed error
3. No; the actual temperature is necessarily outside safe operation
4. Yes; the displayed deviation alone is below the limit

**Correct option(s):** 2

- Option 1: Rounding cannot justify a favorable limit change.
- Option 2: The evidence lacks sufficient acceptance margin.
- Option 3: Measurement noncompliance does not by itself prove the process state.
- Option 4: The stated decision rule includes reference uncertainty.

**CDFOS-Q0085 · single · operations**

What should happen to as-found readings before adjustment?

Synthetic training case — not a field record.

Temperature instrument T has a current certificate covering 0–50 °C. A proposed task needs 80 °C measurement with ±0.5 °C total allowed error. At a later check, a 40 °C reference produces 40.4 °C; the conservative reference bound is ±0.2 °C. The tool was used on five acceptance records since its last known-good check. Usage records identify those tasks.

1. Replace them with corrected readings
2. Treat them as irrelevant once adjustment succeeds
3. Record only the new calibration due date
4. Retain them with method, identity and conditions

**Correct option(s):** 4

- Option 1: That erases evidence of the original instrument behavior.
- Option 2: Historical acceptance may depend on the prior error.
- Option 3: A date cannot reconstruct the observed error.
- Option 4: They support fault analysis and review of earlier decisions.

**CDFOS-Q0086 · single · operations**

What is the appropriate initial scope of retrospective review?

Synthetic training case — not a field record.

Temperature instrument T has a current certificate covering 0–50 °C. A proposed task needs 80 °C measurement with ±0.5 °C total allowed error. At a later check, a 40 °C reference produces 40.4 °C; the conservative reference bound is ±0.2 °C. The tool was used on five acceptance records since its last known-good check. Usage records identify those tasks.

1. Only the last use regardless of evidence
2. Every measurement ever made at the facility
3. The five identified uses since the last known-good check
4. No prior use because the certificate was in date

**Correct option(s):** 3

- Option 1: Earlier uses may also be affected.
- Option 2: That is not supported by the identified instrument exposure.
- Option 3: Usage history bounds the known potentially affected decisions.
- Option 4: Calendar status does not negate an observed performance issue.

**CDFOS-Q0087 · single · operations**

How should a prior result with a large acceptance margin be handled?

Synthetic training case — not a field record.

Temperature instrument T has a current certificate covering 0–50 °C. A proposed task needs 80 °C measurement with ±0.5 °C total allowed error. At a later check, a 40 °C reference produces 40.4 °C; the conservative reference bound is ±0.2 °C. The tool was used on five acceptance records since its last known-good check. Usage records identify those tasks.

1. Delete the original record and retest silently
2. Reject it automatically without analysis
3. Assess whether the plausible instrument error could change its disposition
4. Accept it automatically because the margin looked large

**Correct option(s):** 3

- Option 1: Corrections need traceability to the original acceptance.
- Option 2: Not every bounded error changes a decision.
- Option 3: Impact depends on error bounds, conditions and decision margin.
- Option 4: The margin must be compared with a justified error assessment.

**CDFOS-Q0088 · single · mechanism**

What does metrological traceability alone fail to guarantee?

Synthetic training case — not a field record.

Temperature instrument T has a current certificate covering 0–50 °C. A proposed task needs 80 °C measurement with ±0.5 °C total allowed error. At a later check, a 40 °C reference produces 40.4 °C; the conservative reference bound is ±0.2 °C. The tool was used on five acceptance records since its last known-good check. Usage records identify those tasks.

1. That any reference chain can exist
2. That measurements can be compared at all
3. That the instrument has an identity
4. Fitness of uncertainty and method for this particular decision

**Correct option(s):** 4

- Option 1: A documented chain is central to traceability.
- Option 2: Appropriate traceable methods support comparison.
- Option 3: Identity can be documented independently.
- Option 4: Traceability and suitability are related but distinct.

**CDFOS-Q0089 · single · operations**

Which replacement tool is preferable for the 80 °C task?

Synthetic training case — not a field record.

Temperature instrument T has a current certificate covering 0–50 °C. A proposed task needs 80 °C measurement with ±0.5 °C total allowed error. At a later check, a 40 °C reference produces 40.4 °C; the conservative reference bound is ±0.2 °C. The tool was used on five acceptance records since its last known-good check. Usage records identify those tasks.

1. The tool with the most decimal places only
2. The tool used most often by the team
3. A suitable instrument with applicable range, uncertainty and method evidence
4. Any tool displaying a current-date sticker

**Correct option(s):** 3

- Option 1: Resolution does not establish accuracy or suitability.
- Option 2: Familiarity cannot substitute for measurement capability.
- Option 3: Selection must match the actual acceptance requirement.
- Option 4: The underlying scope and performance still matter.

**CDFOS-Q0090 · single · operations**

What should release the affected instrument back to approved use?

Synthetic training case — not a field record.

Temperature instrument T has a current certificate covering 0–50 °C. A proposed task needs 80 °C measurement with ±0.5 °C total allowed error. At a later check, a 40 °C reference produces 40.4 °C; the conservative reference bound is ±0.2 °C. The tool was used on five acceptance records since its last known-good check. Usage records identify those tasks.

1. Moving it to a different toolbox
2. The supervisor’s need to finish the work
3. Verified acceptable performance and updated controlled status
4. A new sticker without supporting results

**Correct option(s):** 3

- Option 1: Location does not change its measurement behavior.
- Option 2: Urgency does not improve instrument capability.
- Option 3: Return to use requires evidence that the relevant issue is resolved.
- Option 4: Label replacement is not performance verification.

**CDFOS-Q0091 · single · mechanism**

What does the HMI Stopped indication establish?

Synthetic training case — not a field record.

Paper exercise only: a training unit has a normal AC feed, a battery-backed control supply, a pressurized actuator and a raised component held by a powered mechanism. The HMI shows Stopped. The draft work plan identifies only the normal AC feed and assumes no restart is possible. No physical switching is performed in this exercise.

1. The displayed operational state only
2. Absence of battery energy
3. Absence of actuator pressure
4. That the raised component cannot move

**Correct option(s):** 1

- Option 1: It does not verify isolation of every energy source.
- Option 2: The control supply can remain energized independently.
- Option 3: Mechanical energy needs separate assessment.
- Option 4: Powered holding arrangements require their own hazard controls.

**CDFOS-Q0092 · single · operations**

Which omitted source can preserve electrical control capability?

Synthetic training case — not a field record.

Paper exercise only: a training unit has a normal AC feed, a battery-backed control supply, a pressurized actuator and a raised component held by a powered mechanism. The HMI shows Stopped. The draft work plan identifies only the normal AC feed and assumes no restart is possible. No physical switching is performed in this exercise.

1. The battery-backed control supply
2. The pressurized actuator by itself
3. Gravity acting on the raised component
4. The HMI stop request as an energy source

**Correct option(s):** 1

- Option 1: It remains a potential source beyond the normal AC feed.
- Option 2: Stored fluid energy can cause motion but is not the stated electrical supply.
- Option 3: That is a mechanical hazard, not the stated control-power source.
- Option 4: A command is not the battery-backed source supplying the controls.

**CDFOS-Q0093 · single · mechanism**

Why must the pressurized actuator be assessed?

Synthetic training case — not a field record.

Paper exercise only: a training unit has a normal AC feed, a battery-backed control supply, a pressurized actuator and a raised component held by a powered mechanism. The HMI shows Stopped. The draft work plan identifies only the normal AC feed and assumes no restart is possible. No physical switching is performed in this exercise.

1. Pressure is always harmless below a dashboard alarm
2. Stored fluid energy can cause motion after electrical shutdown
3. Electrical isolation automatically vents every actuator
4. A stopped HMI proves the actuator is depressurized

**Correct option(s):** 2

- Option 1: Alarm state does not define safe maintenance conditions.
- Option 2: Removing one supply does not remove every hazardous energy form.
- Option 3: That behavior cannot be assumed without design evidence.
- Option 4: The display does not establish the physical pressure state.

**CDFOS-Q0094 · single · operations**

What concern does the raised component introduce?

Synthetic training case — not a field record.

Paper exercise only: a training unit has a normal AC feed, a battery-backed control supply, a pressurized actuator and a raised component held by a powered mechanism. The HMI shows Stopped. The draft work plan identifies only the normal AC feed and assumes no restart is possible. No physical switching is performed in this exercise.

1. A guarantee that pressure release also supports the raised load
2. Only a concern while the normal motor is commanded to run
3. A guarantee that electrical shutdown is unnecessary
4. Gravity-related movement if its support or holding force is lost

**Correct option(s):** 4

- Option 1: Releasing one energy form does not establish safe mechanical support.
- Option 2: Loss of holding force can cause movement despite a stop command.
- Option 3: The additional hazard does not remove electrical requirements.
- Option 4: Mechanical support must be addressed by the approved method.

**CDFOS-Q0095 · single · operations**

What is the correct disposition of the draft plan?

Synthetic training case — not a field record.

Paper exercise only: a training unit has a normal AC feed, a battery-backed control supply, a pressurized actuator and a raised component held by a powered mechanism. The HMI shows Stopped. The draft work plan identifies only the normal AC feed and assumes no restart is possible. No physical switching is performed in this exercise.

1. Hold for complete source identification and authorized method review
2. Accept because one energy source is listed
3. Accept if the HMI screenshot is attached
4. Ask the learner to improvise a live test

**Correct option(s):** 1

- Option 1: The work boundary is incomplete.
- Option 2: Partial identification is insufficient for the stated equipment.
- Option 3: A screenshot cannot verify the omitted sources.
- Option 4: The exercise grants no specialist switching authority.

**CDFOS-Q0096 · single · operations**

Which question addresses reaccumulation?

Synthetic training case — not a field record.

Paper exercise only: a training unit has a normal AC feed, a battery-backed control supply, a pressurized actuator and a raised component held by a powered mechanism. The HMI shows Stopped. The draft work plan identifies only the normal AC feed and assumes no restart is possible. No physical switching is performed in this exercise.

1. Does the equipment’s rated capacity match its purchase specification?
2. Was the original supply rating copied accurately to the drawing?
3. Was the last repair completed within its scheduled duration?
4. Can pressure or another energy state return during the work?

**Correct option(s):** 4

- Option 1: Rating compliance does not establish whether hazardous energy can return during the task.
- Option 2: A rating record does not establish whether energy can return during work.
- Option 3: Past schedule performance does not assess returning energy in this task.
- Option 4: A safe initial state may not remain safe without controls.

**CDFOS-Q0097 · single · operations**

What must verification be based on?

Synthetic training case — not a field record.

Paper exercise only: a training unit has a normal AC feed, a battery-backed control supply, a pressurized actuator and a raised component held by a powered mechanism. The HMI shows Stopped. The draft work plan identifies only the normal AC feed and assumes no restart is possible. No physical switching is performed in this exercise.

1. Only a successful ping to the controller
2. The equipment-specific approved method and suitable means
3. Only a disabled software button
4. Only the absence of an audible motor sound

**Correct option(s):** 2

- Option 1: Network response does not prove physical isolation.
- Option 2: Verification must address the actual energy and task conditions.
- Option 3: Software inhibition is not automatically energy isolation.
- Option 4: Quiet equipment can retain hazardous energy.

**CDFOS-Q0098 · single · operations**

What role does a warning tag have in this review?

Synthetic training case — not a field record.

Paper exercise only: a training unit has a normal AC feed, a battery-backed control supply, a pressurized actuator and a raised component held by a powered mechanism. The HMI shows Stopped. The draft work plan identifies only the normal AC feed and assumes no restart is possible. No physical switching is performed in this exercise.

1. Communication within the approved energy-control system
2. Automatic equivalence to every locking arrangement
3. Permission to omit verification
4. Authorization for any observer to restore power

**Correct option(s):** 1

- Option 1: A tag does not automatically provide physical isolation.
- Option 2: Legal and physical adequacy depends on the selected system.
- Option 3: Communication does not establish the safe state.
- Option 4: Restoration authority remains controlled.

**CDFOS-Q0099 · single · operations**

A gauge reads zero upstream, but the approved method identifies a separately trapped actuator segment. What follows?

Synthetic training case — not a field record.

Paper exercise only: a training unit has a normal AC feed, a battery-backed control supply, a pressurized actuator and a raised component held by a powered mechanism. The HMI shows Stopped. The draft work plan identifies only the normal AC feed and assumes no restart is possible. No physical switching is performed in this exercise.

1. The zero reading proves every connected segment is pressure-free
2. The actuator hazard becomes an electrical issue only
3. The upstream reading does not verify the trapped segment’s state
4. The gauge should be relabeled as an actuator gauge

**Correct option(s):** 3

- Option 1: An isolated trapped section can retain a different state.
- Option 2: Stored fluid energy remains a distinct physical concern.
- Option 3: Measurement location must represent the energy boundary being assessed.
- Option 4: A label cannot change the measured physical location.

**CDFOS-Q0100 · single · operations**

Which record supports later authorized planning?

Synthetic training case — not a field record.

Paper exercise only: a training unit has a normal AC feed, a battery-backed control supply, a pressurized actuator and a raised component held by a powered mechanism. The HMI shows Stopped. The draft work plan identifies only the normal AC feed and assumes no restart is possible. No physical switching is performed in this exercise.

1. A source/dependency list with unresolved hazards and specialist actions
2. A statement that the HMI was green
3. A copied procedure for a different unit without review
4. A generic one-line “power off” instruction

**Correct option(s):** 1

- Option 1: It gives the qualified planner a traceable basis for completion.
- Option 2: That omits the important energy distinctions.
- Option 3: Different architecture can invalidate the assumed controls.
- Option 4: The equipment has several sources and stored-energy concerns.

**CDFOS-Q0101 · single · recovery**

What is the critical fact before any restoration decision?

Synthetic training case — not a field record.

A paper group-maintenance case has three authorized workers under the site’s approved group-protection system. Two workers leave at shift end; one remains inside the work boundary. The incoming supervisor receives a handover saying only “repair nearly complete.” A departing worker’s protection is still recorded. The schedule coordinator asks for immediate restart.

1. The scheduled window is ending
2. The repair is described as nearly complete
3. Two workers have left the shift
4. One worker remains within the protected work boundary

**Correct option(s):** 4

- Option 1: Schedule cannot override the required protection.
- Option 2: Progress language does not establish that people are clear.
- Option 3: Their departure does not establish the remaining worker’s safety.
- Option 4: Personnel exposure must be accounted for before restoration.

**CDFOS-Q0102 · single · operations**

What is missing from “repair nearly complete”?

Synthetic training case — not a field record.

A paper group-maintenance case has three authorized workers under the site’s approved group-protection system. Two workers leave at shift end; one remains inside the work boundary. The incoming supervisor receives a handover saying only “repair nearly complete.” A departing worker’s protection is still recorded. The schedule coordinator asks for immediate restart.

1. Only the estimated remaining repair duration
2. Only the original planned isolation list
3. Actual equipment state, remaining work, personnel and protection status
4. Only the replacement part’s installation status

**Correct option(s):** 3

- Option 1: Duration does not identify personnel, hazards and protection state.
- Option 2: The incoming team also needs current changes and actual participant status.
- Option 3: The incoming team needs a concrete handover basis.
- Option 4: Mechanical progress alone does not describe the protected boundary.

**CDFOS-Q0103 · single · operations**

What should happen to group protection during shift transfer?

Synthetic training case — not a field record.

A paper group-maintenance case has three authorized workers under the site’s approved group-protection system. Two workers leave at shift end; one remains inside the work boundary. The incoming supervisor receives a handover saying only “repair nearly complete.” A departing worker’s protection is still recorded. The schedule coordinator asks for immediate restart.

1. Rely solely on the schedule coordinator’s message
2. Remove all controls until the new team signs
3. Assume outgoing controls automatically protect unnamed incoming workers
4. Preserve continuous protection under the approved transfer procedure

**Correct option(s):** 4

- Option 1: Schedule coordination does not verify personal protection.
- Option 2: That could expose a worker still within the boundary.
- Option 3: The site system must explicitly account for participants.
- Option 4: The handover must not create an unprotected interval.

**CDFOS-Q0104 · single · operations**

Who may decide how to handle a departing worker’s recorded protection?

Synthetic training case — not a field record.

A paper group-maintenance case has three authorized workers under the site’s approved group-protection system. Two workers leave at shift end; one remains inside the work boundary. The incoming supervisor receives a handover saying only “repair nearly complete.” A departing worker’s protection is still recorded. The schedule coordinator asks for immediate restart.

1. The first incoming worker without checking records
2. The authorized process defined for that situation
3. Any person with a matching tool
4. The customer requesting service restoration

**Correct option(s):** 2

- Option 1: Unverified removal can endanger someone still exposed.
- Option 2: Exceptional handling requires formal checks and appropriate authority.
- Option 3: Physical ability is not authorization.
- Option 4: Customer urgency does not replace the protection procedure.

**CDFOS-Q0105 · single · operations**

What should the incoming supervisor verify?

Synthetic training case — not a field record.

A paper group-maintenance case has three authorized workers under the site’s approved group-protection system. Two workers leave at shift end; one remains inside the work boundary. The incoming supervisor receives a handover saying only “repair nearly complete.” A departing worker’s protection is still recorded. The schedule coordinator asks for immediate restart.

1. Only the percentage of repair completed
2. Personnel, scope, isolation/protection state and remaining hazards
3. Only that the old permit has a signature
4. Only that the equipment appears quiet

**Correct option(s):** 2

- Option 1: Completion percentage does not capture hazardous conditions.
- Option 2: Acceptance requires understanding the actual ongoing work.
- Option 3: A prior signature does not establish current transfer conditions.
- Option 4: Quiet equipment can retain hazards and exposed personnel.

**CDFOS-Q0106 · single · operations**

When is a physical repair complete enough for restart?

Synthetic training case — not a field record.

A paper group-maintenance case has three authorized workers under the site’s approved group-protection system. Two workers leave at shift end; one remains inside the work boundary. The incoming supervisor receives a handover saying only “repair nearly complete.” A departing worker’s protection is still recorded. The schedule coordinator asks for immediate restart.

1. Whenever the last replacement part is installed
2. Only after the separate authorized return-to-service conditions are met
3. Whenever one team member says the work looks finished
4. Whenever the customer’s outage allowance is exhausted

**Correct option(s):** 2

- Option 1: Guards, people, controls and verification may remain unresolved.
- Option 2: Repair completion alone is not restoration permission.
- Option 3: Individual impression is not the required acceptance process.
- Option 4: An elapsed allowance does not remove safety requirements.

**CDFOS-Q0107 · single · operations**

What record should identify who remains protected?

Synthetic training case — not a field record.

A paper group-maintenance case has three authorized workers under the site’s approved group-protection system. Two workers leave at shift end; one remains inside the work boundary. The incoming supervisor receives a handover saying only “repair nearly complete.” A departing worker’s protection is still recorded. The schedule coordinator asks for immediate restart.

1. Only the equipment warranty list
2. The current participant/protection register linked to the work
3. Only the weekly staffing forecast
4. Only the original procurement roster

**Correct option(s):** 2

- Option 1: Warranty status does not provide personnel accountability.
- Option 2: It connects the arrangement to actual exposed people.
- Option 3: Forecasts do not establish who remains in the boundary now.
- Option 4: Purchasing records do not show current work participation.

**CDFOS-Q0108 · single · operations**

Which transfer observation should trigger a hold?

Synthetic training case — not a field record.

A paper group-maintenance case has three authorized workers under the site’s approved group-protection system. Two workers leave at shift end; one remains inside the work boundary. The incoming supervisor receives a handover saying only “repair nearly complete.” A departing worker’s protection is still recorded. The schedule coordinator asks for immediate restart.

1. The replacement component has the approved identity
2. The incoming team cannot reconcile a recorded worker’s status
3. The receiving team asks for clarification before acceptance
4. The handover includes the current isolation reference

**Correct option(s):** 2

- Option 1: That supports the repair rather than creating this hold.
- Option 2: An unresolved exposure/protection state prevents confident restoration.
- Option 3: Clarification is an appropriate control, not a reason to bypass transfer.
- Option 4: That is useful evidence, though not sufficient alone.

**CDFOS-Q0109 · single · operations**

What is the correct response to the immediate-restart request?

Synthetic training case — not a field record.

A paper group-maintenance case has three authorized workers under the site’s approved group-protection system. Two workers leave at shift end; one remains inside the work boundary. The incoming supervisor receives a handover saying only “repair nearly complete.” A departing worker’s protection is still recorded. The schedule coordinator asks for immediate restart.

1. Explain the unresolved conditions and escalate through the defined authority
2. Restart and reconcile the register afterward
3. Transfer restart authority to the calendar system
4. Delete the remaining-worker entry to close the work

**Correct option(s):** 1

- Option 1: The service pressure must be managed without bypassing protection.
- Option 2: That could expose an unaccounted worker.
- Option 3: A schedule cannot verify safe conditions.
- Option 4: Falsifying the record does not remove exposure.

**CDFOS-Q0110 · single · operations**

The incoming roster lists a worker who has not arrived. How should the transfer record treat that person?

Synthetic training case — not a field record.

A paper group-maintenance case has three authorized workers under the site’s approved group-protection system. Two workers leave at shift end; one remains inside the work boundary. The incoming supervisor receives a handover saying only “repair nearly complete.” A departing worker’s protection is still recorded. The schedule coordinator asks for immediate restart.

1. Reconcile actual participation before assigning or releasing protection
2. Assume the forecast roster is the actual participant list
3. Remove an outgoing worker’s protection to balance the headcount
4. Let the absent worker’s name authorize restart

**Correct option(s):** 1

- Option 1: The register must reflect real exposure and the approved system.
- Option 2: A planned assignment does not establish presence or protected work.
- Option 3: Numerical balance is not a safe transfer of personal protection.
- Option 4: An unverified identity cannot establish that exposed people are clear.

**CDFOS-Q0111 · single · operations**

Which assumption has changed most directly?

Synthetic training case — not a field record.

A contractor holds a permit for localized hot work. A different team schedules a fire-detection impairment in the same area during the same hour. The hot-work assessment assumed active detection and a clear service corridor. Delivery pallets now narrow that corridor. The permit issuer has not reviewed the combined work. No live work is performed in this case.

1. The contractor has a named supervisor
2. The hot-work assessment assumed active detection in the affected area
3. The work is localized
4. The permit has an expiry time

**Correct option(s):** 2

- Option 1: That role does not resolve the concurrent impairment.
- Option 2: The planned impairment contradicts that premise.
- Option 3: A small work area can still depend on fire detection and access.
- Option 4: Time validity does not validate changed hazards.

**CDFOS-Q0112 · single · diagnosis**

What should be done before the conflicting activities proceed?

Synthetic training case — not a field record.

A contractor holds a permit for localized hot work. A different team schedules a fire-detection impairment in the same area during the same hour. The hot-work assessment assumed active detection and a clear service corridor. Delivery pallets now narrow that corridor. The permit issuer has not reviewed the combined work. No live work is performed in this case.

1. Coordinate and reassess the combined work through the permit authority
2. Treat both permits as automatically compatible
3. Ask the delivery driver to decide the impairment scope
4. Allow the earlier-issued permit to override every later hazard

**Correct option(s):** 1

- Option 1: Separate approvals do not establish compatibility.
- Option 2: Their assumptions conflict in the same area and time.
- Option 3: That person has no stated protective-system authority.
- Option 4: Issue order is not a complete risk-control rule.

**CDFOS-Q0113 · single · mechanism**

What does the narrowed corridor affect?

Synthetic training case — not a field record.

A contractor holds a permit for localized hot work. A different team schedules a fire-detection impairment in the same area during the same hour. The hot-work assessment assumed active detection and a clear service corridor. Delivery pallets now narrow that corridor. The permit issuer has not reviewed the combined work. No live work is performed in this case.

1. Only the permitted hot-work duration
2. Access and emergency movement assumptions for the work area
3. Only the delivery team’s unloading sequence
4. Only the storage capacity of the holding area

**Correct option(s):** 2

- Option 1: The route condition affects the work’s physical response assumptions, not just duration.
- Option 2: Work logistics can change exposure and response capability.
- Option 3: The obstruction also changes access and emergency movement for others.
- Option 4: The immediate issue is the narrowed route used by people.

**CDFOS-Q0114 · single · design**

Who should define protective-system impairment controls?

Synthetic training case — not a field record.

A contractor holds a permit for localized hot work. A different team schedules a fire-detection impairment in the same area during the same hour. The hot-work assessment assumed active detection and a clear service corridor. Delivery pallets now narrow that corridor. The permit issuer has not reviewed the combined work. No live work is performed in this case.

1. The designated authority with the relevant fire-system specialist
2. The app learner using a generic internet checklist
3. Any operator who can silence a panel
4. The contractor alone without facility coordination

**Correct option(s):** 1

- Option 1: The arrangement requires competent, authorized evaluation.
- Option 2: Generic study is not a site-specific protective-system procedure.
- Option 3: Interface access does not confer design or impairment authority.
- Option 4: Other people and systems share the affected area.

**CDFOS-Q0115 · single · mechanism**

Why does a signed permit not settle the issue?

Synthetic training case — not a field record.

A contractor holds a permit for localized hot work. A different team schedules a fire-detection impairment in the same area during the same hour. The hot-work assessment assumed active detection and a clear service corridor. Delivery pallets now narrow that corridor. The permit issuer has not reviewed the combined work. No live work is performed in this case.

1. Permits apply only to financial approval
2. It was based on conditions that are no longer the complete work state
3. Signatures are never meaningful
4. A permit necessarily guarantees zero residual risk

**Correct option(s):** 2

- Option 1: The permit concerns controlled hazardous work.
- Option 2: Authorization depends on its assessed scope and prerequisites.
- Option 3: They can record valid authority within a functioning system.
- Option 4: No form eliminates hazards by itself.

**CDFOS-Q0116 · single · operations**

Which change needs formal reassessment here?

Synthetic training case — not a field record.

A contractor holds a permit for localized hot work. A different team schedules a fire-detection impairment in the same area during the same hour. The hot-work assessment assumed active detection and a clear service corridor. Delivery pallets now narrow that corridor. The permit issuer has not reviewed the combined work. No live work is performed in this case.

1. Detection availability and corridor condition during the task
2. A typographical correction to an unrelated report title
3. An updated cost estimate with no change to task or conditions
4. A correction to an unrelated completed work-order reference

**Correct option(s):** 1

- Option 1: Both alter important assumptions of the approved method.
- Option 2: That does not change the work’s hazard basis.
- Option 3: Financial revision alone does not alter the stated hazard controls.
- Option 4: That does not change this task’s physical assumptions.

**CDFOS-Q0117 · single · operations**

What should a suspended permit communicate?

Synthetic training case — not a field record.

A contractor holds a permit for localized hot work. A different team schedules a fire-detection impairment in the same area during the same hour. The hot-work assessment assumed active detection and a clear service corridor. Delivery pallets now narrow that corridor. The permit issuer has not reviewed the combined work. No live work is performed in this case.

1. That any team may now use the area freely
2. Only that the job is behind schedule
3. That all equipment is automatically restored
4. Work status, remaining controls, restrictions and revalidation requirements

**Correct option(s):** 4

- Option 1: Restrictions may remain during suspension.
- Option 2: Schedule status omits the operational boundary.
- Option 3: Suspension does not necessarily reverse isolations or impairments.
- Option 4: Others need to know what is still impaired or protected.

**CDFOS-Q0118 · single · operations**

What is the strongest evidence of acceptable restart of the task?

Synthetic training case — not a field record.

A contractor holds a permit for localized hot work. A different team schedules a fire-detection impairment in the same area during the same hour. The hot-work assessment assumed active detection and a clear service corridor. Delivery pallets now narrow that corridor. The permit issuer has not reviewed the combined work. No live work is performed in this case.

1. The original permit copied with a new time
2. An email saying the customer prefers no delay
3. The absence of a fire during the delay
4. Verified corrected conditions and authorized permit revalidation

**Correct option(s):** 4

- Option 1: Changing a time without review does not resolve the conflict.
- Option 2: Preference does not verify controls.
- Option 3: No event is not proof that the proposed controls are adequate.
- Option 4: The work basis must again match actual conditions.

**CDFOS-Q0119 · single · operations**

What should permit handback record?

Synthetic training case — not a field record.

A contractor holds a permit for localized hot work. A different team schedules a fire-detection impairment in the same area during the same hour. The hot-work assessment assumed active detection and a clear service corridor. Delivery pallets now narrow that corridor. The permit issuer has not reviewed the combined work. No live work is performed in this case.

1. Only contractor hours worked
2. Only the original task description
3. Completed and unfinished work, remaining impairments and acceptance
4. Only a statement that tools were purchased

**Correct option(s):** 3

- Option 1: Labor data do not describe plant or protection status.
- Option 2: The final state may differ from the initial plan.
- Option 3: The receiving operator needs the actual returned state.
- Option 4: Procurement does not establish handback conditions.

**CDFOS-Q0120 · single · diagnosis**

What wider process improvement follows from this conflict?

Synthetic training case — not a field record.

A contractor holds a permit for localized hot work. A different team schedules a fire-detection impairment in the same area during the same hour. The hot-work assessment assumed active detection and a clear service corridor. Delivery pallets now narrow that corridor. The permit issuer has not reviewed the combined work. No live work is performed in this case.

1. Stop recording impairments to avoid apparent conflicts
2. Ban every future maintenance activity
3. Let each contractor keep an isolated permit register
4. A coordinated view of simultaneous work and shared assumptions

**Correct option(s):** 4

- Option 1: Concealment increases uncertainty and risk.
- Option 2: That is disproportionate and does not build a usable control process.
- Option 3: That preserves the coordination failure.
- Option 4: The conflict was missed because separate work streams were not integrated.

**CDFOS-Q0121 · single · operations**

What takes priority over retrieving the customer’s device?

Synthetic training case — not a field record.

A synthetic drill reports smoke near a service room and loss of normal internal phones. Two visitors are signed in, but only one is recorded at the assembly point. A customer asks an operator to re-enter for a storage device. Emergency responders have not released the area. The backup communications radio is available but its contact list is outdated.

1. The customer’s contractual availability target
2. The emergency plan and protection of people
3. The operator’s familiarity with the room
4. The device’s replacement cost

**Correct option(s):** 2

- Option 1: A target does not replace emergency authority.
- Option 2: Service property recovery cannot override the unresolved safety state.
- Option 3: Familiarity does not establish safe conditions.
- Option 4: Value does not authorize hazardous re-entry.

**CDFOS-Q0122 · single · operations**

How should the unaccounted visitor be handled?

Synthetic training case — not a field record.

A synthetic drill reports smoke near a service room and loss of normal internal phones. Two visitors are signed in, but only one is recorded at the assembly point. A customer asks an operator to re-enter for a storage device. Emergency responders have not released the area. The backup communications radio is available but its contact list is outdated.

1. Assume the visitor left without recording it
2. Report the discrepancy through the designated accountability/incident route
3. Send any available technician to search alone
4. Delete the visitor entry to align the count

**Correct option(s):** 2

- Option 1: That would conceal an unresolved accountability gap.
- Option 2: The responsible responders need accurate missing-person information.
- Option 3: Untrained entry can create another casualty.
- Option 4: Records must reflect uncertainty, not manufacture agreement.

**CDFOS-Q0123 · single · mechanism**

What does loss of normal phones demonstrate?

Synthetic training case — not a field record.

A synthetic drill reports smoke near a service room and loss of normal internal phones. Two visitors are signed in, but only one is recorded at the assembly point. A customer asks an operator to re-enter for a storage device. Emergency responders have not released the area. The backup communications radio is available but its contact list is outdated.

1. That the customer automatically becomes incident commander
2. That every monitoring alarm is false
3. That all emergency response must stop
4. The plan needs a usable alternative communication dependency

**Correct option(s):** 4

- Option 1: Command follows the defined plan.
- Option 2: Phone failure does not determine alarm validity.
- Option 3: Alternative routes and responders may remain available.
- Option 4: Emergency coordination cannot assume one channel always survives.

**CDFOS-Q0124 · single · operations**

What limits the available backup radio’s usefulness?

Synthetic training case — not a field record.

A synthetic drill reports smoke near a service room and loss of normal internal phones. Two visitors are signed in, but only one is recorded at the assembly point. A customer asks an operator to re-enter for a storage device. Emergency responders have not released the area. The backup communications radio is available but its contact list is outdated.

1. The outdated contact list may prevent reaching the correct role
2. Radio hardware can never support emergency communication
3. The absence of a monthly availability chart
4. Only the radio’s purchase date

**Correct option(s):** 1

- Option 1: A working device is not a complete communication capability.
- Option 2: Suitable radios can be part of an approved plan.
- Option 3: That chart is not the immediate communication route.
- Option 4: Age alone does not identify the stated routing defect.

**CDFOS-Q0125 · single · operations**

Who authorizes re-entry into the affected area?

Synthetic training case — not a field record.

A synthetic drill reports smoke near a service room and loss of normal internal phones. Two visitors are signed in, but only one is recorded at the assembly point. A customer asks an operator to re-enter for a storage device. Emergency responders have not released the area. The backup communications radio is available but its contact list is outdated.

1. The responsible authority under the emergency plan
2. The change calendar when the outage window ends
3. The first operator to observe that smoke has reduced
4. Any customer whose equipment is inside

**Correct option(s):** 1

- Option 1: The area has not yet been released.
- Option 2: A schedule cannot assess the hazardous area.
- Option 3: Appearance alone does not establish safe conditions.
- Option 4: Ownership does not confer emergency safety authority.

**CDFOS-Q0126 · single · operations**

What should the drill record measure?

Synthetic training case — not a field record.

A synthetic drill reports smoke near a service room and loss of normal internal phones. Two visitors are signed in, but only one is recorded at the assembly point. A customer asks an operator to re-enter for a storage device. Emergency responders have not released the area. The backup communications radio is available but its contact list is outdated.

1. Only attendance at the pre-drill briefing
2. Only the number of incident tickets created
3. Only whether no actual fire occurred
4. Alarm receipt, accountability, communication and decision effectiveness

**Correct option(s):** 4

- Option 1: Attendance does not establish response performance.
- Option 2: Ticket count does not measure coordinated response.
- Option 3: The exercise is synthetic and tests preparedness.
- Option 4: These observations test the stated response objectives.

**CDFOS-Q0127 · single · operations**

What claim follows from a tabletop smoke scenario?

Synthetic training case — not a field record.

A synthetic drill reports smoke near a service room and loss of normal internal phones. Two visitors are signed in, but only one is recorded at the assembly point. A customer asks an operator to re-enter for a storage device. Emergency responders have not released the area. The backup communications radio is available but its contact list is outdated.

1. The facility has production fire-response experience
2. The fire detection installation is certified
3. A real evacuation route was physically validated
4. The participants exercised decisions within a simulated scenario

**Correct option(s):** 4

- Option 1: Simulation is a distinct evidence class.
- Option 2: That requires separate authorized system acceptance.
- Option 3: A discussion does not measure actual movement.
- Option 4: Physical evacuation and live responder performance were not demonstrated.

**CDFOS-Q0128 · single · recovery**

What must precede technical service restoration after release?

Synthetic training case — not a field record.

A synthetic drill reports smoke near a service room and loss of normal internal phones. Two visitors are signed in, but only one is recorded at the assembly point. A customer asks an operator to re-enter for a storage device. Emergency responders have not released the area. The backup communications radio is available but its contact list is outdated.

1. Verified equipment, protection and operational prerequisites
2. Only restarting the monitoring server
3. Only clearing every visible alarm
4. Only a customer request to reconnect

**Correct option(s):** 1

- Option 1: Safety release permits assessment; it does not prove every system ready.
- Option 2: Other physical and logical dependencies remain.
- Option 3: Alarm acknowledgment may not resolve initiating conditions.
- Option 4: Demand does not establish technical readiness.

**CDFOS-Q0129 · single · recovery**

Which temporary measures need reconciliation during recovery?

Synthetic training case — not a field record.

A synthetic drill reports smoke near a service room and loss of normal internal phones. Two visitors are signed in, but only one is recorded at the assembly point. A customer asks an operator to re-enter for a storage device. Emergency responders have not released the area. The backup communications radio is available but its contact list is outdated.

1. Only the original construction drawings
2. Only the final alarm acknowledgment count
3. Only the emergency team’s attendance record
4. Overrides, impairments, access grants and emergency configuration changes

**Correct option(s):** 4

- Option 1: Current emergency deviations also require review.
- Option 2: Acknowledgment counts do not reconcile temporary operational changes.
- Option 3: Attendance does not establish that temporary technical measures were removed.
- Option 4: Emergency actions can leave an unintended operating state.

**CDFOS-Q0130 · single · operations**

What makes the post-drill review actionable?

Synthetic training case — not a field record.

A synthetic drill reports smoke near a service room and loss of normal internal phones. Two visitors are signed in, but only one is recorded at the assembly point. A customer asks an operator to re-enter for a storage device. Emergency responders have not released the area. The backup communications radio is available but its contact list is outdated.

1. A summary that omits the missing visitor to avoid concern
2. Specific gaps with owners, due dates and verification methods
3. A statement that communication should improve
4. A claim that no further drills are needed

**Correct option(s):** 2

- Option 1: Omission hides a material response weakness.
- Option 2: Actions need accountable closure and evidence of effectiveness.
- Option 3: A vague aspiration lacks ownership and acceptance.
- Option 4: One exercise cannot establish permanent readiness.

#### Recall

**Near miss at a temporary work route — Synthetic training case — not a field record.

A technician trips over a temporary cable crossing a normal aisle beside an open floor work area. No injury occurs. The cable route was changed after the morning briefing. A warning sign is partly hidden by packaging. A proposed barrier would close the only marked escape route. The supervisor suggests recording “inattention” and continuing unchanged.**

Treat the near miss as evidence of uncontrolled exposure. Make the area safe through the approved site process, reassess the changed route and preserve the escape path. Investigate the route change, visibility, housekeeping and communication instead of closing on a personal-blame label. Verify any replacement control in the real work arrangement.

**Safety roles and task-specific competence — Synthetic training case — not a field record.

A contractor holds a general electrical qualification but has not been briefed on the facility’s dual-source equipment. An operations analyst completed the app and can view the EPMS. The current safety manual is revision 8; the job pack contains revision 5. The appointed safety adviser is offsite, and the work supervisor proposes starting because the permit form has been signed.**

Resolve the outdated instructions and task-specific competence gap before work. General qualification, dashboard access and course completion establish different things. The supervisor and permit roles retain their responsibilities; absence of an adviser does not make an unsafe task acceptable or transfer specialist authority to an analyst.

**Calibration scope and an out-of-tolerance finding — Synthetic training case — not a field record.

Temperature instrument T has a current certificate covering 0–50 °C. A proposed task needs 80 °C measurement with ±0.5 °C total allowed error. At a later check, a 40 °C reference produces 40.4 °C; the conservative reference bound is ±0.2 °C. The tool was used on five acceptance records since its last known-good check. Usage records identify those tasks.**

The current certificate does not demonstrate performance at 80 °C. At 40 °C, worst-case deviation plus reference bound reaches 0.6 °C, so that rule cannot demonstrate ±0.5 °C compliance. Prevent unapproved use, retain as-found evidence and review the five prior decisions against their margins and conditions rather than assuming every result is either valid or invalid.

**Multiple energy sources in a paper isolation review — Synthetic training case — not a field record.

Paper exercise only: a training unit has a normal AC feed, a battery-backed control supply, a pressurized actuator and a raised component held by a powered mechanism. The HMI shows Stopped. The draft work plan identifies only the normal AC feed and assumes no restart is possible. No physical switching is performed in this exercise.**

The draft does not identify all energy sources or stored-energy effects. Stopped status is an operational command state, not verified isolation. An authorized specialist must develop and execute the equipment-specific method, including stored energy, reaccumulation and verification. The learner’s acceptable output is a documented hold and corrected hazard/interface review, not an improvised live switching sequence.

**Group protection and shift transfer — Synthetic training case — not a field record.

A paper group-maintenance case has three authorized workers under the site’s approved group-protection system. Two workers leave at shift end; one remains inside the work boundary. The incoming supervisor receives a handover saying only “repair nearly complete.” A departing worker’s protection is still recorded. The schedule coordinator asks for immediate restart.**

Work completion, worker accountability and restoration authority remain separate. Maintain the approved protection across the transfer, establish who remains exposed and reconcile every relevant control through the site procedure. A vague handover and schedule request do not authorize removal of another person’s protection or restart.

**Permit conflict and simultaneous work — Synthetic training case — not a field record.

A contractor holds a permit for localized hot work. A different team schedules a fire-detection impairment in the same area during the same hour. The hot-work assessment assumed active detection and a clear service corridor. Delivery pallets now narrow that corridor. The permit issuer has not reviewed the combined work. No live work is performed in this case.**

The combined condition differs from the assessed basis. Suspend the affected work through the site process and have the responsible authority coordinate the conflict with the fire-system specialist. Revalidate access, protective arrangements and any authorized compensatory measures before work; do not invent a workaround or assume two individually signed permits are compatible.

**Crisis command, accountability and recovery release — Synthetic training case — not a field record.

A synthetic drill reports smoke near a service room and loss of normal internal phones. Two visitors are signed in, but only one is recorded at the assembly point. A customer asks an operator to re-enter for a storage device. Emergency responders have not released the area. The backup communications radio is available but its contact list is outdated.**

Follow the site emergency plan, account for the missing visitor through the designated incident authority and use the approved alternative communication route. Do not send an untrained operator into an unreleased area for equipment. Preserve the communication and accountability gaps for corrective action. Technical recovery follows safety release and verified service prerequisites.

#### References

- [EPI CDFOS public syllabus](https://www.epi-ap.com/services/1/3/136)
- [HSE maintenance guidance — jurisdiction-specific reference](https://www.hse.gov.uk/work-equipment-machinery/maintenance.htm)
- [HSE permit-to-work systems — supporting reference](https://www.hse.gov.uk/comah/sragtech/techmeaspermit.htm)
- [NIST metrological traceability policy](https://www.nist.gov/calibrations/traceability)

## CDFOS-M03 — Physical access, custody and security operations

### CDFOS-L03 — Physical access, custody and security operations

Estimated study time: 120 minutes before independent work. Prerequisite chapters: CDFOS-L02

## Physical security begins with assets and consequences

Physical security protects people, equipment, information and the ability to operate the facility. Start with assets and the consequences of unauthorized access, damage, removal or interference. A security risk assessment considers plausible threats, vulnerabilities, existing controls and residual consequences. Do not rank every area solely by replacement cost: a low-cost control cabinet may affect many critical systems. Record assumptions about visitors, contractors, delivery routes, neighboring spaces and emergency access. An assessment should lead to specific control and operating requirements rather than a generic statement that the building is secure.

Security zones organize different levels of access and observation. A public reception area, delivery holding space, support room and operational equipment area can require different permissions. Define transitions, permitted roles, escort rules and the expected response to exceptions. A zone label on a drawing does not prove the installed boundary: doors, partitions, service penetrations, shared corridors and other routes must be reconciled with the actual arrangement by the responsible specialists. D1 building engineering remains outside the charter’s owned scope; the operator must recognize and report an interface weakness rather than claim structural design authority.

## Authorization, credentials and actual passage

Authorization states who may enter which area, for what purpose and during which period. A badge or key is a mechanism used to enforce that decision. Issuing a credential does not create an unlimited right to enter, and returning a badge does not necessarily revoke a cached digital permission. Maintain a controlled identity lifecycle: request, sponsor or owner, approval, permitted zones and times, issuance, changes, expiry, return or loss, revocation and evidence of effective enforcement. Privileged access requires the corresponding review and accountability.

Access events must be interpreted carefully. A granted badge transaction may show that the system accepted a credential at a reader; it does not necessarily establish who physically passed through or whether another person followed. A denied event does not always mean the door stayed secure if another condition allowed passage. Combine controller events, door status, authorized observation and incident evidence within the approved privacy and retention rules. Avoid treating a single technology as a complete account of a physical event.

Visitors and contractors need a purpose, identity verification appropriate to the site, host responsibility, permitted route, time limit and any escort requirement. A familiar contractor is not automatically authorized for a different zone or work package. Brief visitors on emergency arrangements and record their departure so accountability remains useful during an incident. If the host becomes unavailable, follow the defined escalation or waiting procedure rather than allowing unrestricted movement. An emergency exit and a security access rule have different life-safety implications; changes must preserve the approved protective and egress design.

## Deliveries and holding areas

Receiving separates an expected shipment from an accepted operational asset. Match the delivery to an authorized order and recipient, verify identity and condition, and route it through the designated holding and inspection process. Packaging, transport damage, wrong model, unrecorded components or unexplained seals can require a hold. Do not bring unidentified equipment directly into an operational rack because the driver knows a staff name. Conversely, a discrepancy should be recorded and resolved through the process rather than interpreted automatically as malicious activity.

A holding area needs controlled access, identification, segregation and an owner for disposition. Distinguish received, awaiting inspection, accepted, quarantined and released states. Materials can introduce hazards or contamination as well as security concerns; use the appropriate safety and manufacturer procedures for batteries, liquids or damaged goods. Maintain custody records when an asset changes hands. They should answer what item, which identity, when, from whom, to whom, why and in what condition. A photograph can support condition evidence but does not replace the acceptance decision.

Equipment removal is also an authorization event. A deinstallation work order may permit disconnection but not necessarily disposal, offsite transfer or release of stored data. Reconcile asset identity, owner approval, media treatment, destination, escort or shipment arrangement and the record updates appropriate to the task. A serial number mismatch should cause a hold until the correct item and authority are established. Security and hardware personnel should share the evidence rather than maintain inconsistent versions of the asset state.

## Keys, badges and offline operation

Mechanical keys and electronic credentials have different lifecycle constraints. Disabling a badge does not recover a lost mechanical master key. A lost key may require an assessment of every affected lock and the approved replacement or compensating arrangement. Keep key identifiers, authorized holders, issue/return records, storage and duplication authority under control. An unrecorded copy defeats confidence in the holder list. Do not publish sensitive keying details in a broadly accessible training or operations report.

Electronic access systems may continue making local decisions when disconnected from their server. Understand which permissions, schedules and revocations are cached, how long the design permits offline operation and how events reconcile afterward. A revoked contractor may remain admitted by an offline controller if the supported design has not received the change. Test the selected behavior with controlled identities and authorization. The operational response must follow the approved security and life-safety design; indiscriminately locking every door is not a valid universal remedy.

## Monitoring, patrols and incident evidence

Monitoring should follow defined risks and response needs. A camera view, door alarm or patrol is valuable when it covers the relevant event, produces usable evidence and reaches an accountable responder. Assess blind areas, lighting, occlusion, time quality, health monitoring, storage and retention. A camera recording at the wrong time or an alarm sent to an unattended console can create an appearance of protection without the needed result. Testing should include the complete path from a controlled event through notification, acknowledgment, investigation and recorded disposition.

Patrols are purposeful inspections, not just route completion. A patrol checklist should identify meaningful conditions such as unsecured doors, unexpected people or goods, damaged barriers, blocked routes and signs of tampering, while respecting the worker’s training and authority. Vary or review patterns according to the site risk assessment rather than treating a fixed route as a guarantee. Document what was observed and what could not be inspected. An inaccessible checkpoint must not be recorded as inspected merely to complete the form.

Incident reporting preserves facts, times, sources, immediate actions, affected assets and uncertainty. Follow the defined response and escalation process, prioritizing people and avoiding unauthorized confrontation or interference with evidence. An access-system anomaly can result from configuration, hardware failure, an authorized exception or misuse; investigate before asserting intent. Preserve relevant records using controlled access and retention, and document any gaps caused by clock drift, missing video or controller outage. Personal information and security-sensitive layouts should be shared only with the appropriate audience under applicable site and jurisdiction rules.

After an incident, restore both the physical condition and the operational control: door hardware, approved access, monitoring, records and responder readiness. Verify the effective state with representative permitted and denied actions. Review why the event was possible and whether a process, technology, training or supplier action should change. Closure should include the accepted remaining risk and reviewer decision, not merely a cleared alarm. The independent assignment in this module produces a zone/access matrix, delivery and removal decisions, credential lifecycle tests and an evidence-based incident report using synthetic cases and controlled laboratory identities.

#### Worked demonstrations

**Zone boundary and approved purpose**

Synthetic training case — not a field record.

The site has reception Z1, delivery holding Z2 and equipment room Z3. A cooling contractor is approved for a two-hour task in Z2 with an escort. Their reusable badge currently opens Z3 because an old project role was never removed. A shared service corridor connects Z2 to a cabinet controlling several Z3 systems.

**Reasoning:** The current badge exceeds the approved purpose. Reconcile role inheritance and effective access, not merely the new request form. Include the shared cabinet/corridor dependency in risk review because consequence can extend beyond the zone label. Preserve life-safety arrangements and involve the responsible boundary specialists.

**Delivery custody and release from holding**

Synthetic training case — not a field record.

A shipment expected to contain switch serial S100 arrives with serial S101 and a damaged outer carton. The driver has the correct purchase-order number and asks to deliver directly to the live rack because the recipient is busy. The holding register has no entry yet. A second undamaged package matches its expected serial and order.

**Reasoning:** Correct order knowledge does not resolve an identity mismatch or damage. Receive through the controlled holding/inspection route, document condition and custody, and obtain authorized disposition before installation. The matching package can proceed through the same required acceptance checks; one discrepancy does not justify rejecting unrelated correctly evidenced goods.

**Visitor escort and credential expiry**

Synthetic training case — not a field record.

Visitor V is approved for Z2 from 09:00 to 11:00 with host H. At 10:00 H leaves the site unexpectedly. At 11:10 the badge still opens Z2 because its controller is offline and retains an old permission. The visitor register still shows V onsite. The approved procedure requires host availability and review of extensions.

**Reasoning:** Host absence changes the approved access arrangement. Follow the visitor waiting/escalation procedure, not an informal unescorted continuation. The expiry failure requires effective-access investigation at the offline controller. Reconcile departure and permissions separately; returning a badge does not by itself prove every cached authorization was removed.

**Mechanical key loss and obsolete privileges**

Synthetic training case — not a field record.

A departing technician returns an electronic badge but cannot locate a mechanical key that opens three service rooms. The badge is disabled centrally. The key register shows two issued copies, while a supervisor recalls an unrecorded third copy. One room contains shared control-power equipment. The technician’s old digital administrator role also remains assigned.

**Reasoning:** Badge disablement does not resolve the missing mechanical key or digital administrator role. Establish the affected locks and consequence, reconcile all copies and use the authorized security decision for replacement or compensating controls. Remove or explicitly justify obsolete digital access. Preserve a restricted record of keying and custody without publishing sensitive details broadly.

**Monitoring coverage and evidence preservation**

Synthetic training case — not a field record.

A camera covers the Z3 doorway but not the adjacent corridor. Its clock is 90 seconds fast. A badge event is logged at 14:02:10 on a synchronized controller. Video shows a passage at displayed 14:03:40. Footage is scheduled for routine overwrite tonight. The incident reviewer has authorized preservation for the relevant window.

**Reasoning:** The known offset aligns the displayed video time with 14:02:10, but alignment alone does not establish the person’s identity or events outside the camera view. Preserve the authorized window and its metadata through the evidence process before overwrite. Retain the raw timestamps and correction rationale, access controls and integrity record.

**Patrol finding and controlled security restoration**

Synthetic training case — not a field record.

A patrol finds a service door held open by packaging after an approved delivery window ended. The access log contains valid delivery entries but no current exception. A local alarm has been acknowledged without a field check. The door is part of an approved emergency-egress arrangement. No signs of forced damage are visible.

**Reasoning:** The expired delivery exception and open door require a response under the security procedure. Protect people, preserve observations and involve the responsible role to restore the approved door state without defeating egress. Valid earlier entries do not authorize indefinite openness; acknowledged alarms do not demonstrate physical correction. Do not label the event a break-in without evidence.

#### Guided practice

Review a visitor, an unreconciled delivery and an open-door event using separate authorization, custody and physical-observation records.

**Hint:** Do not treat credential acceptance, physical passage and authorized purpose as the same event.

**Worked solution:** Compare the current purpose with effective permissions; route goods through identity/condition acceptance; correlate physical findings and logs with time/coverage limits; preserve required egress and escalate specialist boundaries; verify actual permitted and denied behavior after correction.

#### Independent task

Environment: analytical

Produce a defensible physical-security operating package from the synthetic cases.

**Packaged starter material**

- course_labs/CDFOS/README.md
- course_labs/CDFOS/fixture.json
- course_labs/CDFOS/assessment_template.md
- course_labs/CDFOS/lab.py
- course_labs/CDFOS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- Zone and effective-access matrix
- Delivery/key custody dispositions
- Credential expiry test plan
- Patrol incident and evidence-preservation report

**Acceptance criteria**

- Scope and physical passage are distinguished.
- Revocation and restoration are tested at the effective control.
- Reports preserve evidence limits and life-safety authority.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer. The bundled calculator was executed against supplied synthetic fixtures; its numerical checks do not grade physical work or professional authorization.

#### Chapter practice

**CDFOS-Q0131 · single · operations**

Which permission is excessive against the stated task?

Synthetic training case — not a field record.

The site has reception Z1, delivery holding Z2 and equipment room Z3. A cooling contractor is approved for a two-hour task in Z2 with an escort. Their reusable badge currently opens Z3 because an old project role was never removed. A shared service corridor connects Z2 to a cabinet controlling several Z3 systems.

1. A record of the contractor’s sponsor
2. Presence at reception for identity verification
3. Unescorted entry to Z3 through the inherited role
4. Escorted access to Z2 during the task window

**Correct option(s):** 3

- Option 1: Sponsorship is an accountability control, not excess access.
- Option 2: Reception processing supports the approved entry route.
- Option 3: The approved purpose is a bounded escorted Z2 task.
- Option 4: That is the stated authorized access.

**CDFOS-Q0132 · single · operations**

What should access review inspect beyond the new request?

Synthetic training case — not a field record.

The site has reception Z1, delivery holding Z2 and equipment room Z3. A cooling contractor is approved for a two-hour task in Z2 with an escort. Their reusable badge currently opens Z3 because an old project role was never removed. A shared service corridor connects Z2 to a cabinet controlling several Z3 systems.

1. Only the text typed into the latest form
2. Only the access group assigned for the present contractor visit
3. Only whether the contractor has visited before
4. All effective roles and inherited permissions on the credential

**Correct option(s):** 4

- Option 1: That may omit retained system roles.
- Option 2: The new group can coexist with inherited or retained groups that grant broader effective access.
- Option 3: Familiarity does not determine the current authorized purpose.
- Option 4: An old assignment can broaden actual access.

**CDFOS-Q0133 · single · mechanism**

Why is the shared control cabinet relevant to zone risk?

Synthetic training case — not a field record.

The site has reception Z1, delivery holding Z2 and equipment room Z3. A cooling contractor is approved for a two-hour task in Z2 with an escort. Their reusable badge currently opens Z3 because an old project role was never removed. A shared service corridor connects Z2 to a cabinet controlling several Z3 systems.

1. Only equipment purchase price determines zone criticality
2. A cabinet in Z2 cannot affect Z3 by definition
3. Risk assessment excludes shared service corridors
4. Its consequence reaches systems beyond its physical zone

**Correct option(s):** 4

- Option 1: Cost alone does not capture service dependencies.
- Option 2: Zone labels do not alter actual control relationships.
- Option 3: Shared routes can be important boundary dependencies.
- Option 4: A modest asset can have a large operational effect.

**CDFOS-Q0134 · single · operations**

What is the proper handling of the unexpected Z3 access?

Synthetic training case — not a field record.

The site has reception Z1, delivery holding Z2 and equipment room Z3. A cooling contractor is approved for a two-hour task in Z2 with an escort. Their reusable badge currently opens Z3 because an old project role was never removed. A shared service corridor connects Z2 to a cabinet controlling several Z3 systems.

1. Ask the contractor to avoid using it without changing permissions
2. Restrict and reconcile it through the authorized access process
3. Delete the contractor’s identity history
4. Leave it active because the new task is short

**Correct option(s):** 2

- Option 1: A promise does not correct the technical overpermission.
- Option 2: The effective permission should match the approved task.
- Option 3: Historical records support investigation and accountability.
- Option 4: Short duration does not justify unrelated access.

**CDFOS-Q0135 · single · operations**

Which negative test is relevant after correction?

Synthetic training case — not a field record.

The site has reception Z1, delivery holding Z2 and equipment room Z3. A cooling contractor is approved for a two-hour task in Z2 with an escort. Their reusable badge currently opens Z3 because an old project role was never removed. A shared service corridor connects Z2 to a cabinet controlling several Z3 systems.

1. A valid escorted Z2 request is always denied
2. The reader’s display is turned off
3. Every employee is prevented from entering any room
4. The task credential cannot enter Z3 under the tested conditions

**Correct option(s):** 4

- Option 1: That would also break the authorized task.
- Option 2: Display state does not establish access enforcement.
- Option 3: That exceeds the defined security objective.
- Option 4: This verifies the removed out-of-scope permission.

**CDFOS-Q0136 · single · design**

What should define the escort’s responsibility?

Synthetic training case — not a field record.

The site has reception Z1, delivery holding Z2 and equipment room Z3. A cooling contractor is approved for a two-hour task in Z2 with an escort. Their reusable badge currently opens Z3 because an old project role was never removed. A shared service corridor connects Z2 to a cabinet controlling several Z3 systems.

1. Only the visitor’s estimated arrival time
2. Only permission to enter the reception area
3. The approved route, presence requirement and response to separation
4. Only the escort’s job title

**Correct option(s):** 3

- Option 1: Arrival does not establish continuing supervision.
- Option 2: The escort needs defined responsibilities throughout the authorized visit.
- Option 3: Escort control needs an operationally clear meaning.
- Option 4: A title does not describe the required behavior.

**CDFOS-Q0137 · single · operations**

How should the corridor boundary concern be resolved?

Synthetic training case — not a field record.

The site has reception Z1, delivery holding Z2 and equipment room Z3. A cooling contractor is approved for a two-hour task in Z2 with an escort. Their reusable badge currently opens Z3 because an old project role was never removed. A shared service corridor connects Z2 to a cabinet controlling several Z3 systems.

1. Declare structural compliance from the access log
2. Relabel the corridor as Z3 without changing controls
3. Review installed routes and dependencies with the responsible specialists
4. Ignore the cabinet because no incident has occurred

**Correct option(s):** 3

- Option 1: Logs cannot prove physical construction or boundary performance.
- Option 2: A drawing label alone does not implement a boundary.
- Option 3: Operational findings require an appropriate design/interface assessment.
- Option 4: Absence of a known incident does not remove the dependency.

**CDFOS-Q0138 · single · operations**

What is the purpose of the two-hour limit?

Synthetic training case — not a field record.

The site has reception Z1, delivery holding Z2 and equipment room Z3. A cooling contractor is approved for a two-hour task in Z2 with an escort. Their reusable badge currently opens Z3 because an old project role was never removed. A shared service corridor connects Z2 to a cabinet controlling several Z3 systems.

1. Bound access to the approved work period and require reviewed extension
2. Replace the need for a sponsor
3. Automatically approve all work requested within two hours
4. Guarantee that the repair cannot take longer

**Correct option(s):** 1

- Option 1: A time constraint limits continued authorization.
- Option 2: Time and ownership are separate controls.
- Option 3: Scope still governs what may be done.
- Option 4: The task may overrun and then require a decision.

**CDFOS-Q0139 · single · operations**

What should happen if the task must enter Z3 unexpectedly?

Synthetic training case — not a field record.

The site has reception Z1, delivery holding Z2 and equipment room Z3. A cooling contractor is approved for a two-hour task in Z2 with an escort. Their reusable badge currently opens Z3 because an old project role was never removed. A shared service corridor connects Z2 to a cabinet controlling several Z3 systems.

1. Record the entry only after the work is complete
2. Ask another contractor to lend a badge
3. Stop the out-of-scope activity and obtain the required new authorization
4. Use the old inherited role as an informal exception

**Correct option(s):** 3

- Option 1: Retrospective logging does not authorize the action.
- Option 2: Credential sharing defeats individual authorization.
- Option 3: The original Z2 approval does not cover the changed task.
- Option 4: That was the excessive access under review.

**CDFOS-Q0140 · single · operations**

Which record best supports an access decision audit?

Synthetic training case — not a field record.

The site has reception Z1, delivery holding Z2 and equipment room Z3. A cooling contractor is approved for a two-hour task in Z2 with an escort. Their reusable badge currently opens Z3 because an old project role was never removed. A shared service corridor connects Z2 to a cabinet controlling several Z3 systems.

1. Only the contractor’s previous access approval
2. Only the credential-issuance record showing that a badge was activated
3. Only the reader model number
4. Purpose, approving role, zones, time, escort condition and effective tests

**Correct option(s):** 4

- Option 1: A previous visit may have different scope and dates.
- Option 2: Activation does not show the approved zones, time restrictions, escort condition or effective enforcement.
- Option 3: Hardware identity alone does not show the authorized decision.
- Option 4: It links intent to actual enforcement.

**CDFOS-Q0141 · single · operations**

What most directly requires a hold on the first switch?

Synthetic training case — not a field record.

A shipment expected to contain switch serial S100 arrives with serial S101 and a damaged outer carton. The driver has the correct purchase-order number and asks to deliver directly to the live rack because the recipient is busy. The holding register has no entry yet. A second undamaged package matches its expected serial and order.

1. The received serial differs from the expected asset
2. A second package is undamaged
3. The driver knows the purchase-order number
4. The recipient is temporarily busy

**Correct option(s):** 1

- Option 1: The item’s identity has not been reconciled to the authorized delivery.
- Option 2: Another item’s condition does not resolve this discrepancy.
- Option 3: That supports association but is not itself a defect.
- Option 4: Staff availability should route the process, not determine identity acceptance.

**CDFOS-Q0142 · single · mechanism**

What does the correct purchase-order number establish?

Synthetic training case — not a field record.

A shipment expected to contain switch serial S100 arrives with serial S101 and a damaged outer carton. The driver has the correct purchase-order number and asks to deliver directly to the live rack because the recipient is busy. The holding register has no entry yet. A second undamaged package matches its expected serial and order.

1. That the serial mismatch can be ignored
2. That the driver is authorized for live-rack access
3. That carton damage is purely cosmetic
4. A claimed link to an expected transaction that still needs verification

**Correct option(s):** 4

- Option 1: Identity remains inconsistent.
- Option 2: Delivery knowledge does not confer operational-area permission.
- Option 3: Condition requires appropriate inspection and disposition.
- Option 4: Knowledge of an order is not complete item acceptance.

**CDFOS-Q0143 · single · operations**

Where should the unreconciled item go under this process?

Synthetic training case — not a field record.

A shipment expected to contain switch serial S100 arrives with serial S101 and a damaged outer carton. The driver has the correct purchase-order number and asks to deliver directly to the live rack because the recipient is busy. The holding register has no entry yet. A second undamaged package matches its expected serial and order.

1. Directly into the live rack to save handling time
2. An unrecorded corridor space until someone remembers it
3. Into accepted stock with the expected serial copied onto the record
4. The controlled holding or quarantine route with recorded status

**Correct option(s):** 4

- Option 1: The item has not passed identity and condition checks.
- Option 2: That loses control and may obstruct access.
- Option 3: That would create a false asset identity.
- Option 4: This preserves custody while preventing premature installation.

**CDFOS-Q0144 · single · operations**

Which condition evidence should be retained?

Synthetic training case — not a field record.

A shipment expected to contain switch serial S100 arrives with serial S101 and a damaged outer carton. The driver has the correct purchase-order number and asks to deliver directly to the live rack because the recipient is busy. The holding register has no entry yet. A second undamaged package matches its expected serial and order.

1. Only the driver’s planned departure time
2. Only a statement that the supplier is usually reliable
3. Only the new asset’s intended hostname
4. Observed packaging/item condition with time and responsible receiver

**Correct option(s):** 4

- Option 1: Schedule does not establish damage or suitability.
- Option 2: Reputation does not record this shipment’s condition.
- Option 3: A logical name cannot document delivery condition.
- Option 4: It supports later assessment without assuming a cause.

**CDFOS-Q0145 · single · operations**

Who should authorize final disposition of the mismatch?

Synthetic training case — not a field record.

A shipment expected to contain switch serial S100 arrives with serial S101 and a damaged outer carton. The driver has the correct purchase-order number and asks to deliver directly to the live rack because the recipient is busy. The holding register has no entry yet. A second undamaged package matches its expected serial and order.

1. Any operator who wants the port capacity
2. The installer by silently changing S100 to S101
3. The driver solely because the order number matches
4. The designated receiving/asset owner with procurement and technical input

**Correct option(s):** 4

- Option 1: Demand does not resolve identity or condition.
- Option 2: Record editing without disposition conceals the discrepancy.
- Option 3: The driver does not own the facility’s acceptance decision.
- Option 4: The decision must reconcile the authorized item and its suitability.

**CDFOS-Q0146 · single · operations**

What should a custody handoff record identify?

Synthetic training case — not a field record.

A shipment expected to contain switch serial S100 arrives with serial S101 and a damaged outer carton. The driver has the correct purchase-order number and asks to deliver directly to the live rack because the recipient is busy. The holding register has no entry yet. A second undamaged package matches its expected serial and order.

1. Only the receiver’s full name and department
2. Only the delivery quantity and destination building
3. Only the purchase order and packing list
4. Item, sender, receiver, time, purpose and condition

**Correct option(s):** 4

- Option 1: This identifies a person but omits the item, transfer time, purpose, condition and sender.
- Option 2: A quantity and location omit the individual asset and accountable transfer parties.
- Option 3: Transaction documents do not establish who accepted custody at this handoff.
- Option 4: These connect responsibility across the transfer.

**CDFOS-Q0147 · single · operations**

Can the matching undamaged package be accepted automatically because the other one failed?

Synthetic training case — not a field record.

A shipment expected to contain switch serial S100 arrives with serial S101 and a damaged outer carton. The driver has the correct purchase-order number and asks to deliver directly to the live rack because the recipient is busy. The holding register has no entry yet. A second undamaged package matches its expected serial and order.

1. It can bypass all checks to compensate for delay
2. It must undergo its own required checks and disposition
3. It must be rejected because all goods from the truck are identical risks
4. It should be assigned the mismatched switch’s serial

**Correct option(s):** 2

- Option 1: Schedule pressure does not waive acceptance.
- Option 2: Each item’s evidence and acceptance are independent.
- Option 3: The case does not establish a common defect requiring that conclusion.
- Option 4: That would corrupt both asset records.

**CDFOS-Q0148 · single · mechanism**

What should the holding register distinguish?

Synthetic training case — not a field record.

A shipment expected to contain switch serial S100 arrives with serial S101 and a damaged outer carton. The driver has the correct purchase-order number and asks to deliver directly to the live rack because the recipient is busy. The holding register has no entry yet. A second undamaged package matches its expected serial and order.

1. Only whether the supplier has confirmed shipment completion
2. Only present or absent
3. Received, awaiting inspection, quarantined, accepted and released states
4. Only whether the received quantity matches the purchase order

**Correct option(s):** 3

- Option 1: Shipment status does not show the receiving team’s acceptance decision or handling restrictions.
- Option 2: That loses the decision and restriction status.
- Option 3: These states prevent possession being mistaken for approval.
- Option 4: Quantity agreement does not establish inspection, quarantine, technical acceptance or release.

**CDFOS-Q0149 · single · implementation**

What should happen before installation after a resolved mismatch?

Synthetic training case — not a field record.

A shipment expected to contain switch serial S100 arrives with serial S101 and a damaged outer carton. The driver has the correct purchase-order number and asks to deliver directly to the live rack because the recipient is busy. The holding register has no entry yet. A second undamaged package matches its expected serial and order.

1. Verify the approved identity, technical suitability and release status
2. Discard the discrepancy record to simplify inventory
3. Skip technical checks because receiving approved custody
4. Install as soon as a new label is printed

**Correct option(s):** 1

- Option 1: Resolution must reach the actual item and work authorization.
- Option 2: The record explains the accepted change and preserves traceability.
- Option 3: Custody and installation suitability are different gates.
- Option 4: A label does not prove a valid disposition.

**CDFOS-Q0150 · single · operations**

What is an unsupported conclusion from the damaged carton alone?

Synthetic training case — not a field record.

A shipment expected to contain switch serial S100 arrives with serial S101 and a damaged outer carton. The driver has the correct purchase-order number and asks to deliver directly to the live rack because the recipient is busy. The holding register has no entry yet. A second undamaged package matches its expected serial and order.

1. That condition should be documented
2. That malicious tampering definitely occurred
3. That the responsible recipient should be informed
4. That installation should await the defined assessment

**Correct option(s):** 2

- Option 1: Recording the observation is appropriate.
- Option 2: Damage has several possible causes requiring investigation.
- Option 3: The owner needs the discrepancy for disposition.
- Option 4: A controlled hold follows the unresolved condition.

**CDFOS-Q0151 · single · operations**

What condition becomes invalid at 10:00?

Synthetic training case — not a field record.

Visitor V is approved for Z2 from 09:00 to 11:00 with host H. At 10:00 H leaves the site unexpectedly. At 11:10 the badge still opens Z2 because its controller is offline and retains an old permission. The visitor register still shows V onsite. The approved procedure requires host availability and review of extensions.

1. The required host/escort arrangement
2. Every other visitor’s approval expires
3. The visitor’s identity necessarily becomes false
4. The controller’s hardware warranty ends

**Correct option(s):** 1

- Option 1: The approved visit depends on H’s availability.
- Option 2: The case concerns V’s particular arrangement.
- Option 3: Host absence does not prove identity fraud.
- Option 4: That is unrelated to the stated change.

**CDFOS-Q0152 · single · operations**

What should V do when the host becomes unavailable?

Synthetic training case — not a field record.

Visitor V is approved for Z2 from 09:00 to 11:00 with host H. At 10:00 H leaves the site unexpectedly. At 11:10 the badge still opens Z2 because its controller is offline and retains an old permission. The visitor register still shows V onsite. The approved procedure requires host availability and review of extensions.

1. Borrow an employee badge to complete the visit
2. Continue through all zones because entry was previously granted
3. Follow the approved waiting or escalation arrangement
4. Choose another employee as host without the required approval

**Correct option(s):** 3

- Option 1: Sharing bypasses identity and scope controls.
- Option 2: Initial entry does not create unlimited continuing permission.
- Option 3: The access condition needs an authorized resolution.
- Option 4: Host substitution must follow the site process.

**CDFOS-Q0153 · single · mechanism**

What does the 11:10 successful entry show?

Synthetic training case — not a field record.

Visitor V is approved for Z2 from 09:00 to 11:00 with host H. At 10:00 H leaves the site unexpectedly. At 11:10 the badge still opens Z2 because its controller is offline and retains an old permission. The visitor register still shows V onsite. The approved procedure requires host availability and review of extensions.

1. The visitor register has automatically recorded departure
2. Expiry was not effectively enforced at that controller
3. The visitor was automatically approved for an extension
4. The server’s expiry record is necessarily absent

**Correct option(s):** 2

- Option 1: Physical-access state and visitor records may be separate.
- Option 2: The actual access contradicts the intended time limit.
- Option 3: A granted event does not create authorization.
- Option 4: The controller may be using stale cached information.

**CDFOS-Q0154 · single · operations**

Which dependency should be examined first for the expiry failure?

Synthetic training case — not a field record.

Visitor V is approved for Z2 from 09:00 to 11:00 with host H. At 10:00 H leaves the site unexpectedly. At 11:10 the badge still opens Z2 because its controller is offline and retains an old permission. The visitor register still shows V onsite. The approved procedure requires host availability and review of extensions.

1. The rack’s cooling setpoint
2. The guest Wi-Fi’s internet speed
3. The host’s email signature
4. Offline permission caching and synchronization behavior

**Correct option(s):** 4

- Option 1: It is outside the stated access-control mechanism.
- Option 2: That does not directly explain the local access decision.
- Option 3: It does not enforce controller schedules.
- Option 4: The case identifies a disconnected controller with old state.

**CDFOS-Q0155 · single · operations**

What must an authorized visit extension include?

Synthetic training case — not a field record.

Visitor V is approved for Z2 from 09:00 to 11:00 with host H. At 10:00 H leaves the site unexpectedly. At 11:10 the badge still opens Z2 because its controller is offline and retains an old permission. The visitor register still shows V onsite. The approved procedure requires host availability and review of extensions.

1. Only a longer entry in the calendar without enforcement
2. Only a verbal request from the visitor
3. Reviewed purpose, duration, host condition and effective permission update
4. Only continued possession of the badge

**Correct option(s):** 3

- Option 1: The actual access system must match the approved extension.
- Option 2: The visitor cannot self-authorize new access.
- Option 3: An extension changes the original bounded authorization.
- Option 4: Possession does not establish a revised right.

**CDFOS-Q0156 · single · mechanism**

Why is the onsite register important during an emergency?

Synthetic training case — not a field record.

Visitor V is approved for Z2 from 09:00 to 11:00 with host H. At 10:00 H leaves the site unexpectedly. At 11:10 the badge still opens Z2 because its controller is offline and retains an old permission. The visitor register still shows V onsite. The approved procedure requires host availability and review of extensions.

1. It replaces the emergency assembly process
2. It proves every listed person is in their approved zone
3. It authorizes re-entry into an unreleased area
4. It supports accountability for people who may still be present

**Correct option(s):** 4

- Option 1: Actual accountability still requires the defined response.
- Option 2: A register does not locate every person precisely.
- Option 3: Presence records do not confer emergency access authority.
- Option 4: Incomplete departure records can create uncertainty during response.

**CDFOS-Q0157 · single · mechanism**

What does badge return establish by itself?

Synthetic training case — not a field record.

Visitor V is approved for Z2 from 09:00 to 11:00 with host H. At 10:00 H leaves the site unexpectedly. At 11:10 the badge still opens Z2 because its controller is offline and retains an old permission. The visitor register still shows V onsite. The approved procedure requires host availability and review of extensions.

1. Physical custody of that credential has returned
2. No copy or other credential can exist
3. The visit’s work was technically accepted
4. Every controller has received revocation

**Correct option(s):** 1

- Option 1: Cached electronic permissions still need their own reconciliation.
- Option 2: The stated observation is narrower.
- Option 3: Credential handling is separate from work acceptance.
- Option 4: Return does not prove network synchronization.

**CDFOS-Q0158 · single · recovery**

Which post-recovery test is appropriate?

Synthetic training case — not a field record.

Visitor V is approved for Z2 from 09:00 to 11:00 with host H. At 10:00 H leaves the site unexpectedly. At 11:10 the badge still opens Z2 because its controller is offline and retains an old permission. The visitor register still shows V onsite. The approved procedure requires host availability and review of extensions.

1. Every credential is permanently denied
2. The expired test identity is denied and a valid identity still works as approved
3. Only the server shows a green synchronization icon
4. Only the badge is physically cut

**Correct option(s):** 2

- Option 1: That could disrupt authorized operation and life-safety arrangements.
- Option 2: Both restriction and intended operation need verification.
- Option 3: Actual enforcement remains untested.
- Option 4: That does not test the controller’s permission state.

**CDFOS-Q0159 · single · operations**

What should a log analysis avoid assuming?

Synthetic training case — not a field record.

Visitor V is approved for Z2 from 09:00 to 11:00 with host H. At 10:00 H leaves the site unexpectedly. At 11:10 the badge still opens Z2 because its controller is offline and retains an old permission. The visitor register still shows V onsite. The approved procedure requires host availability and review of extensions.

1. That an expired permission should be investigated
2. That a granted credential event uniquely identifies the person who passed
3. That the event timestamp has any analytical value
4. That controller state may differ from server state

**Correct option(s):** 2

- Option 1: The observed mismatch warrants investigation.
- Option 2: Physical passage can require additional corroboration.
- Option 3: Time can help when its quality is assessed.
- Option 4: The case makes that a relevant hypothesis.

**CDFOS-Q0160 · single · operations**

What durable improvement addresses this case?

Synthetic training case — not a field record.

Visitor V is approved for Z2 from 09:00 to 11:00 with host H. At 10:00 H leaves the site unexpectedly. At 11:10 the badge still opens Z2 because its controller is offline and retains an old permission. The visitor register still shows V onsite. The approved procedure requires host availability and review of extensions.

1. Require visitors to monitor controller health themselves
2. Stop recording visitors when controllers are offline
3. Test host contingencies, offline expiry behavior and departure reconciliation
4. Extend every visitor badge indefinitely

**Correct option(s):** 3

- Option 1: System administration remains the operator’s responsibility.
- Option 2: That reduces accountability during a degraded state.
- Option 3: The case exposes several distinct lifecycle dependencies.
- Option 4: That removes the intended time boundary.

**CDFOS-Q0161 · single · operations**

Which exposure remains after disabling the badge?

Synthetic training case — not a field record.

A departing technician returns an electronic badge but cannot locate a mechanical key that opens three service rooms. The badge is disabled centrally. The key register shows two issued copies, while a supervisor recalls an unrecorded third copy. One room contains shared control-power equipment. The technician’s old digital administrator role also remains assigned.

1. Every physical access path is automatically closed
2. The missing mechanical key can still affect its compatible locks
3. The digital administrator role is automatically removed
4. The key becomes harmless because the technician left employment

**Correct option(s):** 2

- Option 1: The case identifies a separate mechanical mechanism.
- Option 2: Electronic revocation does not change a mechanical key.
- Option 3: The case states that assignment remains active.
- Option 4: Employment status does not alter the key’s physical capability.

**CDFOS-Q0162 · single · mechanism**

What does the recalled third copy indicate?

Synthetic training case — not a field record.

A departing technician returns an electronic badge but cannot locate a mechanical key that opens three service rooms. The badge is disabled centrally. The key register shows two issued copies, while a supervisor recalls an unrecorded third copy. One room contains shared control-power equipment. The technician’s old digital administrator role also remains assigned.

1. All three locks must already have failed
2. The key inventory may be incomplete and needs reconciliation
3. The two recorded copies were necessarily never issued
4. The missing key is definitely the third copy

**Correct option(s):** 2

- Option 1: Copy control and lock function are different issues.
- Option 2: Unrecorded duplication weakens confidence in custody.
- Option 3: A third copy does not negate the existing records.
- Option 4: The available information does not identify it.

**CDFOS-Q0163 · single · operations**

What should determine the response scope?

Synthetic training case — not a field record.

A departing technician returns an electronic badge but cannot locate a mechanical key that opens three service rooms. The badge is disabled centrally. The key register shows two issued copies, while a supervisor recalls an unrecorded third copy. One room contains shared control-power equipment. The technician’s old digital administrator role also remains assigned.

1. Only the electronic badge permissions listed as disabled
2. Only the employee’s departure date
3. Affected locks, accessible assets, custody uncertainty and consequence
4. Only the replacement price of the key

**Correct option(s):** 3

- Option 1: The mechanical key may still open affected locks; electronic revocation does not establish its scope.
- Option 2: Timing matters but does not establish the affected boundary.
- Option 3: The assessment must reflect actual exposure.
- Option 4: Low key cost can conceal high operational consequence.

**CDFOS-Q0164 · single · mechanism**

Why does the shared control-power room deserve attention?

Synthetic training case — not a field record.

A departing technician returns an electronic badge but cannot locate a mechanical key that opens three service rooms. The badge is disabled centrally. The key register shows two issued copies, while a supervisor recalls an unrecorded third copy. One room contains shared control-power equipment. The technician’s old digital administrator role also remains assigned.

1. Control-power equipment cannot affect availability
2. Mechanical access is irrelevant when systems have passwords
3. Every service room has identical consequences
4. Access there can affect several dependent systems

**Correct option(s):** 4

- Option 1: Its failure can disrupt the functions it supplies.
- Option 2: Physical and logical controls address different paths.
- Option 3: Dependencies differ and require assessment.
- Option 4: Consequence extends beyond the room’s apparent equipment count.

**CDFOS-Q0165 · single · operations**

What should happen to the obsolete digital administrator role?

Synthetic training case — not a field record.

A departing technician returns an electronic badge but cannot locate a mechanical key that opens three service rooms. The badge is disabled centrally. The key register shows two issued copies, while a supervisor recalls an unrecorded third copy. One room contains shared control-power equipment. The technician’s old digital administrator role also remains assigned.

1. Delete all historical administrator logs
2. Revoke or explicitly justify it through the access review
3. Rename it as a contractor role without changing permissions
4. Leave it because the badge was returned

**Correct option(s):** 2

- Option 1: Those records may support accountability and investigation.
- Option 2: A separate retained privilege needs its own disposition.
- Option 3: A label does not resolve excess authority.
- Option 4: Badge custody does not govern application permissions.

**CDFOS-Q0166 · single · operations**

Who should decide whether locks or other controls must change?

Synthetic training case — not a field record.

A departing technician returns an electronic badge but cannot locate a mechanical key that opens three service rooms. The badge is disabled centrally. The key register shows two issued copies, while a supervisor recalls an unrecorded third copy. One room contains shared control-power equipment. The technician’s old digital administrator role also remains assigned.

1. The departing technician alone
2. The authorized security owner using the exposure assessment
3. Any operator who can purchase new cylinders
4. The payroll system automatically

**Correct option(s):** 2

- Option 1: The person reporting loss does not own all facility risk acceptance.
- Option 2: The response needs accountable, context-specific judgment.
- Option 3: Procurement capability is not the full security authority.
- Option 4: Employment processing cannot assess every physical dependency.

**CDFOS-Q0167 · single · implementation**

What belongs in a controlled key register?

Synthetic training case — not a field record.

A departing technician returns an electronic badge but cannot locate a mechanical key that opens three service rooms. The badge is disabled centrally. The key register shows two issued copies, while a supervisor recalls an unrecorded third copy. One room contains shared control-power equipment. The technician’s old digital administrator role also remains assigned.

1. Only the room’s environmental readings
2. Key identity, compatible scope, authorized holders and issue/return status
3. Only the original number of keys ordered
4. Only the total number of employees

**Correct option(s):** 2

- Option 1: Those measurements do not describe key authorization.
- Option 2: These link the credential to custody and exposure.
- Option 3: Initial quantity does not show current holders, copies or returns.
- Option 4: Headcount cannot identify key holders.

**CDFOS-Q0168 · single · mechanism**

Why restrict distribution of detailed keying information?

Synthetic training case — not a field record.

A departing technician returns an electronic badge but cannot locate a mechanical key that opens three service rooms. The badge is disabled centrally. The key register shows two issued copies, while a supervisor recalls an unrecorded third copy. One room contains shared control-power equipment. The technician’s old digital administrator role also remains assigned.

1. Because no key records should exist
2. Because every employee must know every master-key pattern
3. It describes sensitive access relationships
4. Because restricted records cannot be audited

**Correct option(s):** 3

- Option 1: Controlled records are necessary for accountability.
- Option 2: Broad disclosure is not automatically justified.
- Option 3: The record should reach people with an operational need.
- Option 4: Authorized reviewers can inspect controlled information.

**CDFOS-Q0169 · single · operations**

What evidence closes a replacement-control action?

Synthetic training case — not a field record.

A departing technician returns an electronic badge but cannot locate a mechanical key that opens three service rooms. The badge is disabled centrally. The key register shows two issued copies, while a supervisor recalls an unrecorded third copy. One room contains shared control-power equipment. The technician’s old digital administrator role also remains assigned.

1. A statement that the old key is probably lost outside
2. A record confirming only that the electronic badge was disabled
3. A purchase order for new locks only
4. Verified effective access changes and reconciled custody records

**Correct option(s):** 4

- Option 1: Speculation does not resolve exposure.
- Option 2: That does not verify the changed mechanical locks, retained administrator authority or reconciled custody.
- Option 3: Ordering does not prove installation or functioning access.
- Option 4: The intended restriction must exist in the actual installation.

**CDFOS-Q0170 · single · operations**

What preventive process addresses the unrecorded copy?

Synthetic training case — not a field record.

A departing technician returns an electronic badge but cannot locate a mechanical key that opens three service rooms. The badge is disabled centrally. The key register shows two issued copies, while a supervisor recalls an unrecorded third copy. One room contains shared control-power equipment. The technician’s old digital administrator role also remains assigned.

1. Treat mechanical keys as exempt from offboarding
2. Controlled duplication authority and periodic custody reconciliation
3. Stop assigning identifiers to keys
4. Rely on staff memory alone

**Correct option(s):** 2

- Option 1: They remain capable after employment ends.
- Option 2: These target the breakdown in key lifecycle control.
- Option 3: That would reduce traceability.
- Option 4: The case shows memory and records already disagree.

**CDFOS-Q0171 · single · operations**

What corrected time corresponds to displayed video 14:03:40?

Synthetic training case — not a field record.

A camera covers the Z3 doorway but not the adjacent corridor. Its clock is 90 seconds fast. A badge event is logged at 14:02:10 on a synchronized controller. Video shows a passage at displayed 14:03:40. Footage is scheduled for routine overwrite tonight. The incident reviewer has authorized preservation for the relevant window.

1. 14:02:10
2. 14:03:40 without qualification
3. 14:05:10
4. 14:01:40

**Correct option(s):** 1

- Option 1: Subtract the known ninety-second fast offset.
- Option 2: That ignores the stated clock error.
- Option 3: Adding the offset moves the time in the wrong direction.
- Option 4: That subtracts two minutes rather than ninety seconds.

**CDFOS-Q0172 · single · mechanism**

What does time alignment establish by itself?

Synthetic training case — not a field record.

A camera covers the Z3 doorway but not the adjacent corridor. Its clock is 90 seconds fast. A badge event is logged at 14:02:10 on a synchronized controller. Video shows a passage at displayed 14:03:40. Footage is scheduled for routine overwrite tonight. The incident reviewer has authorized preservation for the relevant window.

1. Every corridor movement was recorded
2. The visitor had authorization for every subsequent action
3. The observations may correspond temporally within the known limits
4. The badge holder is definitely the person in the video

**Correct option(s):** 3

- Option 1: The camera does not cover that area.
- Option 2: Timing does not establish scope of permission.
- Option 3: Identity and complete event meaning still need evidence.
- Option 4: A credential event is not unique proof of physical identity.

**CDFOS-Q0173 · single · operations**

What is the immediate evidence-preservation priority?

Synthetic training case — not a field record.

A camera covers the Z3 doorway but not the adjacent corridor. Its clock is 90 seconds fast. A badge event is logged at 14:02:10 on a synchronized controller. Video shows a passage at displayed 14:03:40. Footage is scheduled for routine overwrite tonight. The incident reviewer has authorized preservation for the relevant window.

1. Preserve the authorized relevant footage before routine overwrite
2. Change the camera clock and discard old metadata first
3. Export all cameras for all tenants without scope review
4. Wait until the normal retention cycle deletes it

**Correct option(s):** 1

- Option 1: Otherwise potentially useful evidence may be lost.
- Option 2: That can obscure interpretation of the original record.
- Option 3: Preservation should respect authorized scope and information controls.
- Option 4: That would defeat the approved preservation need.

**CDFOS-Q0174 · single · operations**

What should accompany an exported clip?

Synthetic training case — not a field record.

A camera covers the Z3 doorway but not the adjacent corridor. Its clock is 90 seconds fast. A badge event is logged at 14:02:10 on a synchronized controller. Video shows a passage at displayed 14:03:40. Footage is scheduled for routine overwrite tonight. The incident reviewer has authorized preservation for the relevant window.

1. Only the export tool’s successful-completion status
2. Only the reviewer’s conclusion
3. Only confirmation that the exported video plays in the viewer
4. Source, time basis, scope, handling and integrity information

**Correct option(s):** 4

- Option 1: Tool completion alone does not preserve the provenance and handling information needed to interpret the clip.
- Option 2: The underlying evidence must remain independently assessable.
- Option 3: Playback demonstrates readability, but not the camera identity, time basis, export scope or integrity history.
- Option 4: These support later interpretation and controlled custody.

**CDFOS-Q0175 · single · operations**

Can the footage prove what happened in the corridor?

Synthetic training case — not a field record.

A camera covers the Z3 doorway but not the adjacent corridor. Its clock is 90 seconds fast. A badge event is logged at 14:02:10 on a synchronized controller. Video shows a passage at displayed 14:03:40. Footage is scheduled for routine overwrite tonight. The incident reviewer has authorized preservation for the relevant window.

1. Yes; nearby areas are implicitly covered
2. No; that area lies outside the stated view
3. Yes; the badge event fills every visual gap
4. No camera footage can ever support any conclusion

**Correct option(s):** 2

- Option 1: Proximity does not create a recorded image.
- Option 2: Evidence claims must follow actual coverage.
- Option 3: An access event does not reconstruct unobserved movement.
- Option 4: The covered doorway may still provide useful evidence.

**CDFOS-Q0176 · single · operations**

How should the raw camera timestamps be treated?

Synthetic training case — not a field record.

A camera covers the Z3 doorway but not the adjacent corridor. Its clock is 90 seconds fast. A badge event is logged at 14:02:10 on a synchronized controller. Video shows a passage at displayed 14:03:40. Footage is scheduled for routine overwrite tonight. The incident reviewer has authorized preservation for the relevant window.

1. Treat every timestamp as exact after one correction
2. Replace all times with the report creation time
3. Rewrite them without keeping the original
4. Retain them and document the offset interpretation separately

**Correct option(s):** 4

- Option 1: Offset knowledge still needs scope and uncertainty.
- Option 2: That destroys event chronology.
- Option 3: That removes the basis for auditing the correction.
- Option 4: This preserves the original record and the analysis.

**CDFOS-Q0177 · single · operations**

Which observation tests whether monitoring supports response?

Synthetic training case — not a field record.

A camera covers the Z3 doorway but not the adjacent corridor. Its clock is 90 seconds fast. A badge event is logged at 14:02:10 on a synchronized controller. Video shows a passage at displayed 14:03:40. Footage is scheduled for routine overwrite tonight. The incident reviewer has authorized preservation for the relevant window.

1. The storage disk has unused capacity
2. A vendor brochure lists analytics features
3. A controlled event reaches the responsible role and produces the expected action
4. The camera’s power LED is on

**Correct option(s):** 3

- Option 1: Capacity alone does not verify usable event evidence.
- Option 2: Advertised capability does not demonstrate the installed workflow.
- Option 3: Recording alone is not the complete operational path.
- Option 4: Power does not prove capture, storage, notification or response.

**CDFOS-Q0178 · single · operations**

What should govern access to the preserved footage?

Synthetic training case — not a field record.

A camera covers the Z3 doorway but not the adjacent corridor. Its clock is 90 seconds fast. A badge event is logged at 14:02:10 on a synchronized controller. Video shows a passage at displayed 14:03:40. Footage is scheduled for routine overwrite tonight. The incident reviewer has authorized preservation for the relevant window.

1. The exported file’s small size
2. The approved incident, privacy and evidence-access rules
3. Automatic public posting to identify the person
4. Any employee’s curiosity about the event

**Correct option(s):** 2

- Option 1: File size does not determine information sensitivity.
- Option 2: Sensitive records need controlled use and disclosure.
- Option 3: That exceeds the stated preservation purpose.
- Option 4: Curiosity is not an operational authorization.

**CDFOS-Q0179 · single · operations**

What if the camera health check was green during a recording gap?

Synthetic training case — not a field record.

A camera covers the Z3 doorway but not the adjacent corridor. Its clock is 90 seconds fast. A badge event is logged at 14:02:10 on a synchronized controller. Video shows a passage at displayed 14:03:40. Footage is scheduled for routine overwrite tonight. The incident reviewer has authorized preservation for the relevant window.

1. Investigate which health conditions were actually monitored
2. Assume the gap is impossible
3. Remove recording continuity from the requirement
4. Conclude all video was maliciously removed

**Correct option(s):** 1

- Option 1: A narrow health indicator may omit recording completeness.
- Option 2: A display state cannot override missing evidence.
- Option 3: A failed test does not justify silently deleting the need.
- Option 4: Several operational causes remain possible.

**CDFOS-Q0180 · single · operations**

What is a suitable closing statement if identity remains uncertain?

Synthetic training case — not a field record.

A camera covers the Z3 doorway but not the adjacent corridor. Its clock is 90 seconds fast. A badge event is logged at 14:02:10 on a synchronized controller. Video shows a passage at displayed 14:03:40. Footage is scheduled for routine overwrite tonight. The incident reviewer has authorized preservation for the relevant window.

1. Declare that no event occurred
2. Name the badge owner as the actor without qualification
3. State the established observations and unresolved identity question
4. Discard the useful temporal evidence because one question remains

**Correct option(s):** 3

- Option 1: The case includes recorded passage and an access event.
- Option 2: The evidence may not uniquely identify the person.
- Option 3: The report should not invent certainty.
- Option 4: Partial uncertainty does not make every observation useless.

**CDFOS-Q0181 · single · operations**

What is the primary observed control failure?

Synthetic training case — not a field record.

A patrol finds a service door held open by packaging after an approved delivery window ended. The access log contains valid delivery entries but no current exception. A local alarm has been acknowledged without a field check. The door is part of an approved emergency-egress arrangement. No signs of forced damage are visible.

1. The emergency-egress design is necessarily defective
2. The door remains held open beyond the approved delivery condition
3. Every recorded delivery entry was unauthorized
4. The absence of forced damage proves no exposure

**Correct option(s):** 2

- Option 1: No design defect has been established.
- Option 2: The current physical state is not covered by the stated exception.
- Option 3: The case says those entries were valid.
- Option 4: An open door can create exposure without damage.

**CDFOS-Q0182 · single · mechanism**

What does alarm acknowledgment establish?

Synthetic training case — not a field record.

A patrol finds a service door held open by packaging after an approved delivery window ended. The access log contains valid delivery entries but no current exception. A local alarm has been acknowledged without a field check. The door is part of an approved emergency-egress arrangement. No signs of forced damage are visible.

1. The delivery exception automatically renewed
2. The incident has no remaining security relevance
3. Someone recorded awareness, not necessarily physical correction
4. The door has returned to its approved state

**Correct option(s):** 3

- Option 1: Acknowledgment does not extend access authorization.
- Option 2: The open boundary remains unresolved.
- Option 3: The field condition still needs verification.
- Option 4: The patrol observation contradicts that conclusion.

**CDFOS-Q0183 · single · operations**

Which response preserves both security and life safety?

Synthetic training case — not a field record.

A patrol finds a service door held open by packaging after an approved delivery window ended. The access log contains valid delivery entries but no current exception. A local alarm has been acknowledged without a field check. The door is part of an approved emergency-egress arrangement. No signs of forced damage are visible.

1. Disable all door alarms permanently
2. Add an unapproved lock across the exit immediately
3. Restore the approved door arrangement through the responsible procedure
4. Leave the door open indefinitely because it supports egress

**Correct option(s):** 3

- Option 1: That removes observation without resolving the physical condition.
- Option 2: That can create a separate life-safety failure.
- Option 3: Do not improvise a closure that defeats required egress.
- Option 4: Approved egress need not mean uncontrolled normal access.

**CDFOS-Q0184 · single · operations**

What should the patrol report record first?

Synthetic training case — not a field record.

A patrol finds a service door held open by packaging after an approved delivery window ended. The access log contains valid delivery entries but no current exception. A local alarm has been acknowledged without a field check. The door is part of an approved emergency-egress arrangement. No signs of forced damage are visible.

1. Only the patrol’s total walking time
2. A definitive accusation against the last delivery worker
3. Only that the checkpoint was visited
4. Observed state, location, time, context and immediate authorized actions

**Correct option(s):** 4

- Option 1: Duration does not document the control failure.
- Option 2: The evidence does not establish who left the obstruction.
- Option 3: Route completion omits the actual finding.
- Option 4: A factual record supports investigation and handover.

**CDFOS-Q0185 · single · operations**

How should earlier valid access events be interpreted?

Synthetic training case — not a field record.

A patrol finds a service door held open by packaging after an approved delivery window ended. The access log contains valid delivery entries but no current exception. A local alarm has been acknowledged without a field check. The door is part of an approved emergency-egress arrangement. No signs of forced damage are visible.

1. They make the physical observation irrelevant
2. They show approved transactions during the earlier window
3. They prove no person could have passed without a badge
4. They prove every later passage was approved

**Correct option(s):** 2

- Option 1: Logs and field state answer different questions.
- Option 2: They do not authorize the later open-door condition.
- Option 3: An open door can allow unrecorded passage.
- Option 4: The access scope and time still apply.

**CDFOS-Q0186 · single · operations**

What should happen if the patrol cannot inspect an assigned checkpoint safely?

Synthetic training case — not a field record.

A patrol finds a service door held open by packaging after an approved delivery window ended. The access log contains valid delivery entries but no current exception. A local alarm has been acknowledged without a field check. The door is part of an approved emergency-egress arrangement. No signs of forced damage are visible.

1. Mark it passed to preserve the route completion target
2. Record the limitation and escalate through the defined process
3. Enter regardless of the hazard because patrol is scheduled
4. Delete the checkpoint permanently without review

**Correct option(s):** 2

- Option 1: That creates false assurance.
- Option 2: An unperformed inspection must not be reported as complete.
- Option 3: Schedule does not authorize unsafe exposure.
- Option 4: Coverage changes need a risk-based decision.

**CDFOS-Q0187 · single · operations**

What is an unsupported incident classification from these facts alone?

Synthetic training case — not a field record.

A patrol finds a service door held open by packaging after an approved delivery window ended. The access log contains valid delivery entries but no current exception. A local alarm has been acknowledged without a field check. The door is part of an approved emergency-egress arrangement. No signs of forced damage are visible.

1. An open-door security finding
2. An alarm-response verification gap
3. An expired exception requiring review
4. Confirmed forced-entry break-in

**Correct option(s):** 4

- Option 1: That is the stated physical observation.
- Option 2: Acknowledgment occurred without a field check.
- Option 3: The window ended and no current exception exists.
- Option 4: No forced damage or actor evidence is supplied.

**CDFOS-Q0188 · single · recovery**

What should verify restoration?

Synthetic training case — not a field record.

A patrol finds a service door held open by packaging after an approved delivery window ended. The access log contains valid delivery entries but no current exception. A local alarm has been acknowledged without a field check. The door is part of an approved emergency-egress arrangement. No signs of forced damage are visible.

1. Actual approved door function, monitoring and permitted/denied behavior
2. Only changing the patrol route
3. Only a visual check that the door is now closed
4. Only clearing the alarm history

**Correct option(s):** 1

- Option 1: The entire intended control should work after correction.
- Option 2: A route change does not restore the door.
- Option 3: A closed door may still have defective latching, monitoring, authorized access or required egress behavior.
- Option 4: Clearing records does not repair the boundary.

**CDFOS-Q0189 · single · operations**

Which process weakness should be examined?

Synthetic training case — not a field record.

A patrol finds a service door held open by packaging after an approved delivery window ended. The access log contains valid delivery entries but no current exception. A local alarm has been acknowledged without a field check. The door is part of an approved emergency-egress arrangement. No signs of forced damage are visible.

1. Only the number of cameras on another floor
2. Only the supplier’s packaging brand
3. How delivery exceptions expire and how alarms receive field verification
4. Only the original building opening date

**Correct option(s):** 3

- Option 1: Unrelated coverage does not close this specific workflow gap.
- Option 2: Brand does not explain authorization and response closure.
- Option 3: Both contributed to the unclosed condition.
- Option 4: Age alone does not identify this operating defect.

**CDFOS-Q0190 · single · operations**

What should incident closure retain?

Synthetic training case — not a field record.

A patrol finds a service door held open by packaging after an approved delivery window ended. The access log contains valid delivery entries but no current exception. A local alarm has been acknowledged without a field check. The door is part of an approved emergency-egress arrangement. No signs of forced damage are visible.

1. Only the contractor’s promise to remember next time
2. Only a green status icon
3. Only the statement that no theft was reported
4. Evidence, corrective action, verified state and accepted remaining risk

**Correct option(s):** 4

- Option 1: A promise does not demonstrate corrected operation.
- Option 2: A display state is weaker than the required evidence chain.
- Option 3: No reported loss does not prove controls were restored.
- Option 4: The reviewer needs a defensible result and limitations.

#### Recall

**Zone boundary and approved purpose — Synthetic training case — not a field record.

The site has reception Z1, delivery holding Z2 and equipment room Z3. A cooling contractor is approved for a two-hour task in Z2 with an escort. Their reusable badge currently opens Z3 because an old project role was never removed. A shared service corridor connects Z2 to a cabinet controlling several Z3 systems.**

The current badge exceeds the approved purpose. Reconcile role inheritance and effective access, not merely the new request form. Include the shared cabinet/corridor dependency in risk review because consequence can extend beyond the zone label. Preserve life-safety arrangements and involve the responsible boundary specialists.

**Delivery custody and release from holding — Synthetic training case — not a field record.

A shipment expected to contain switch serial S100 arrives with serial S101 and a damaged outer carton. The driver has the correct purchase-order number and asks to deliver directly to the live rack because the recipient is busy. The holding register has no entry yet. A second undamaged package matches its expected serial and order.**

Correct order knowledge does not resolve an identity mismatch or damage. Receive through the controlled holding/inspection route, document condition and custody, and obtain authorized disposition before installation. The matching package can proceed through the same required acceptance checks; one discrepancy does not justify rejecting unrelated correctly evidenced goods.

**Visitor escort and credential expiry — Synthetic training case — not a field record.

Visitor V is approved for Z2 from 09:00 to 11:00 with host H. At 10:00 H leaves the site unexpectedly. At 11:10 the badge still opens Z2 because its controller is offline and retains an old permission. The visitor register still shows V onsite. The approved procedure requires host availability and review of extensions.**

Host absence changes the approved access arrangement. Follow the visitor waiting/escalation procedure, not an informal unescorted continuation. The expiry failure requires effective-access investigation at the offline controller. Reconcile departure and permissions separately; returning a badge does not by itself prove every cached authorization was removed.

**Mechanical key loss and obsolete privileges — Synthetic training case — not a field record.

A departing technician returns an electronic badge but cannot locate a mechanical key that opens three service rooms. The badge is disabled centrally. The key register shows two issued copies, while a supervisor recalls an unrecorded third copy. One room contains shared control-power equipment. The technician’s old digital administrator role also remains assigned.**

Badge disablement does not resolve the missing mechanical key or digital administrator role. Establish the affected locks and consequence, reconcile all copies and use the authorized security decision for replacement or compensating controls. Remove or explicitly justify obsolete digital access. Preserve a restricted record of keying and custody without publishing sensitive details broadly.

**Monitoring coverage and evidence preservation — Synthetic training case — not a field record.

A camera covers the Z3 doorway but not the adjacent corridor. Its clock is 90 seconds fast. A badge event is logged at 14:02:10 on a synchronized controller. Video shows a passage at displayed 14:03:40. Footage is scheduled for routine overwrite tonight. The incident reviewer has authorized preservation for the relevant window.**

The known offset aligns the displayed video time with 14:02:10, but alignment alone does not establish the person’s identity or events outside the camera view. Preserve the authorized window and its metadata through the evidence process before overwrite. Retain the raw timestamps and correction rationale, access controls and integrity record.

**Patrol finding and controlled security restoration — Synthetic training case — not a field record.

A patrol finds a service door held open by packaging after an approved delivery window ended. The access log contains valid delivery entries but no current exception. A local alarm has been acknowledged without a field check. The door is part of an approved emergency-egress arrangement. No signs of forced damage are visible.**

The expired delivery exception and open door require a response under the security procedure. Protect people, preserve observations and involve the responsible role to restore the approved door state without defeating egress. Valid earlier entries do not authorize indefinite openness; acknowledged alarms do not demonstrate physical correction. Do not label the event a break-in without evidence.

#### References

- [EPI CDFOS public syllabus](https://www.epi-ap.com/services/1/3/136)
- [NIST SP 800-53 Rev. 5 — physical and environmental protection controls](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final)

## CDFOS-M04 — Maintenance strategy, procedures, spares and work evidence

### CDFOS-L04 — Maintenance strategy, procedures, spares and work evidence

Estimated study time: 120 minutes before independent work. Prerequisite chapters: CDFOS-L03

## Maintenance protects a required function

Maintenance is the work used to preserve or restore equipment and system function. Its value depends on the failure being addressed and the consequence of that failure. A calendar task may be appropriate for a component with a manufacturer-defined interval, while condition observations may support another task. Corrective maintenance responds to a detected defect; preventive work acts before a failure under a defined strategy; condition-based work uses a relevant observed condition. Predictive claims require a validated relationship between observations and future behavior, not merely a dashboard with a trend line.

Start with the asset’s required function, operating conditions, failure modes, protective limits and supporting dependencies. An apparently minor sensor can be important if its wrong value causes a harmful operating decision. Conversely, replacing a healthy component too frequently can introduce installation defects, unnecessary exposure and cost. Use manufacturer requirements, applicable obligations, operating history and engineering assessment to choose the strategy. A criticality ranking should consider consequence and recoverability, not only purchase price or how often a fault has been reported.

Distinguish a task from a result. “Inspect pump” is an activity; “verify the specified flow, leakage condition, alarms and automatic availability” describes aspects of acceptance. The maintenance plan should say what observation is required, how it will be obtained safely, what limits apply, what finding requires escalation and which records must change. Never invent a universal electrical, mechanical or protective limit from an example in this course. Actual tasks use the selected equipment’s approved instructions and the relevant competent personnel.

## A method of procedure is a controlled decision sequence

A maintenance operations procedure, or MOP, translates an approved method into a repeatable work sequence for a defined asset and condition. Identify the exact equipment, source documents and versions, purpose, scope, roles, tools, spares, permits, prerequisite state, steps, hold points, observations, abort criteria, rollback or recovery and handback. Instructions should make decision points explicit: what must be true before a step, what result is expected, and what happens if it is not observed. A checklist that tells the operator to continue regardless of failed evidence is not a controlled method.

Prechecks must reflect the current facility, including failed or isolated equipment and concurrent work. An old topology showing two available paths is not valid evidence when one is already out of service. Confirm the actual approved configuration and dependencies. The person executing the work should be able to match the procedure’s asset identity to the installed item. If a label, drawing and local identity disagree, stop and resolve the discrepancy; guessing which asset was intended can enlarge the outage.

Define the work window around the complete task. Include preparation, verification, decision time, rollback and final observation. A rollback trigger must occur early enough to complete the supported recovery within the remaining window. Some actions are not safely reversible by copying an old configuration or reinstalling a part. A firmware change, consumable action or altered physical condition may need a different recovery plan. Record those limits before execution and use the correct authority when the planned path becomes unavailable.

During work, record actual observations and deviations as they occur. A prefilled result can hide an unexpected condition. Peer checks or independent verification should target consequential identification and transition points, not merely add signatures. Temporary overrides and impairments need an owner, reason, scope, expiry and removal test. A completed repair can leave equipment outside automatic operation; handback must verify the required returned mode and function as well as the physical component.

## Service reports preserve engineering meaning

A service report connects the work order to what was actually found and done. Retain asset identity, method/version, personnel, time, conditions, as-found observations, diagnostic reasoning, parts and versions, adjustments, as-left results, remaining defects, restrictions and acceptance. A statement such as “serviced, all okay” is not enough when the required checks involve measurable function. The report should distinguish a performed test from an unperformed or represented one and identify the raw evidence location.

As-found information supports recurrence analysis. If a bearing repeatedly fails after a replacement, the cause may be alignment, lubrication, operating conditions, installation method or another dependency. Replacing the part again without retaining evidence can repeat the symptom while losing the opportunity to identify the mechanism. A maintenance finding can require a design or procedure change through the appropriate review; the CMMS is the record of that decision and work, not a substitute for engineering judgment.

After work, reconcile asset records, spare inventory, calibration status, configuration, drawings and monitoring as applicable. Verify the complete observation chain when a sensor or controller interface changed. A correct local reading may still be associated with the wrong asset in BMS. A returned network link may still use an obsolete management identity. Close the work order only against the defined acceptance and documented residual issues, using the site’s permitted conditional-acceptance process where appropriate.

## Spares are a recovery capability, not just stock

A spare is useful when it is the correct supported item, stored in acceptable conditions, available when needed and accompanied by the tools, knowledge and configuration needed to use it. Track model, revision, firmware or compatibility constraints, quantity, location, condition, shelf life and ownership. Similar appearance does not prove interchangeability. A newer replacement can be unsupported by the existing host or control system. Review substitution through the responsible technical process rather than treating any stocked item as approved.

Inventory policy balances lead time, expected use, variability, consequence and cost. A simple illustrative reorder point can be expected demand during replenishment lead time plus a justified safety stock. Its assumptions must be explicit; intermittent critical failures may not follow a stable daily average. Stock on hand, allocated stock and confirmed incoming stock answer different questions. A part reserved for another approved outage is not necessarily free for a new task. A delivery date without confidence or a supported emergency alternative may not meet the restoration requirement.

Storage and periodic inspection matter. Batteries, seals, filters, lubricants and electronic assemblies can deteriorate or become unsuitable while unused. Follow the selected manufacturer and safety requirements, and record inspection or refresh actions. Quarantine damaged, expired or uncertain stock so it is not silently counted as ready. After issue, trigger replenishment and update custody. A spare consumed during an incident should not leave the recovery plan relying on a quantity that exists only in the old database.

## Tools and housekeeping are part of readiness

Choose tools for the actual method and equipment. Tool condition, appropriate rating, fit, calibration where relevant, protective features and user competence all matter. A tool can have a current calibration certificate and still be unsuitable for a particular range or environment. Inspect for damage and follow the process after a drop, overload or other event that may affect performance. Do not improvise a substitute merely because the correct tool is missing; assess whether the task must be held or a supported alternative approved.

Tool accountability prevents equipment damage and later incidents. Keep an appropriate issue/return and work-area check, especially where loose items can remain inside cabinets or airflow paths. Consumables and temporary test connections also need removal or deliberate retention under approval. A finished MOP should leave a known state, not a collection of unexplained jumpers, caps or tools. When a tool is unaccounted for, assess the affected work boundary before returning equipment to service.

Housekeeping protects access, airflow, cleanliness, fire loading and reliable observation. Packaging can obstruct a return path or escape route; dust and debris can contaminate equipment; misplaced floor tiles can change airflow or expose a fall hazard. Use the approved cleaning method and materials for the area and equipment. Do not assume that moving contamination out of sight removes it; uncontrolled cleaning can redistribute particles. Coordinate intrusive cleaning with equipment owners and protective-system requirements.

A housekeeping inspection should identify the required condition, not simply whether an area looks tidy from the entrance. Check cable routes, storage boundaries, underfloor or overhead areas when authorized, leakage, temporary materials and access to emergency equipment. Preserve the distinction between cleaning, fault repair and specialist contamination assessment. Repeated debris or leakage should lead to investigation of the source rather than endless symptom removal.

The independent maintenance assignment combines a strategy decision, an executable reviewed MOP, a supported spare/tool readiness check, a factual service report and a recurrence review. At least one practical task must be performed in the appropriate safe laboratory or supervised environment to support a hands-on claim. Analytical cases teach the decisions and acceptance logic but do not establish that physical maintenance or live switching has occurred.

#### Worked demonstrations

**Selecting a maintenance strategy from a failure mechanism**

Synthetic training case — not a field record.

Fan group F has a manufacturer-required inspection interval. A vibration trend rose after a mounting change, while run hours are low. A separate room-temperature sensor has shown intermittent mapping errors with no physical drift. A proposal replaces every fan monthly and recalibrates the sensor weekly without investigating either cause.

**Reasoning:** Retain mandatory manufacturer work, but investigate the changed mounting and the digital mapping fault. Frequent replacement or calibration can add effort without addressing the observed mechanisms. Define a task from required function, credible failure mode, relevant evidence and acceptance rather than treating all maintenance as calendar replacement.

**MOP identity, hold points and recovery window**

Synthetic training case — not a field record.

A MOP names pump P-14, but its drawing points to P-41. Step 6 says “continue after valve feedback changes,” with no expected state or timeout. The window ends at 04:00; supported recovery takes 18 minutes and final checks take 12 minutes. A precheck shows the standby pump is unavailable. The required service must remain supported.

**Reasoning:** Hold before execution: identity, step acceptance and current capacity are unresolved. The latest recovery decision without contingency is 03:30. The unavailable standby changes the work basis. A valid MOP needs exact asset identity, expected feedback, timeout/abort logic and a supported recovery route that fits the window.

**Service report with a missing functional test**

Synthetic training case — not a field record.

A contractor report states “sensor replaced; system healthy.” It identifies the new sensor serial but contains no as-found readings, source range, BMS point check or alarm test. A local display reads plausibly; BMS still associates the point with the neighboring unit. The work order is marked ready for closure.

**Reasoning:** The report establishes a replacement identity, not complete service acceptance. Preserve the missing-evidence limitation, verify the actual source/range and correct the approved point association. Test display, alarm and retained data against the required function. Do not invent as-found values; assess whether other retained evidence can support the historical diagnosis.

**Spare readiness and replenishment arithmetic**

Synthetic training case — not a field record.

A synthetic filter stock uses a stable planning estimate of 2 units/day. Confirmed replenishment lead time is 10 days and the approved safety stock is 8 units. There are 25 units physically present, 6 reserved for an approved job, and 4 quarantined for damage. An order for 20 is confirmed but not yet received. The policy uses ready unallocated stock for immediate-task readiness.

**Reasoning:** The illustrative reorder point is 2×10+8 = 28 units under the stated planning assumptions. Ready unallocated stock is 25−6−4 = 15. Confirmed incoming stock affects replenishment planning but is not available for immediate issue. Investigate whether stable average demand remains appropriate before treating the formula as universal for critical intermittent spares.

**Tool suitability and missing-item accountability**

Synthetic training case — not a field record.

A MOP requires a specified calibrated torque tool and an insulated tool appropriate to the selected task. The torque tool’s certificate is current, but its listed range does not include the required setting. A similar unverified tool is available. At handback, one small adapter from the issued kit is unaccounted for near an open equipment cabinet.

**Reasoning:** A current certificate does not establish suitability outside its range, and visual similarity does not approve a substitute. Hold the affected task pending a supported tool decision. The missing adapter requires work-area accountability and an authorized assessment before return to service, because an unexplained object may remain in the equipment.

**Housekeeping as an airflow and access control**

Synthetic training case — not a field record.

After rack installation, packaging remains near a return-air path, a floor opening is temporarily uncovered and debris is visible near an intake. The contractor proposes sweeping everything toward the underfloor space. The work pack has not assigned ownership for temporary materials. No particle measurements have been taken.

**Reasoning:** The findings affect airflow, access and contamination control, not just appearance. Protect the opening and routes through the approved method, use the area’s permitted cleaning process and remove material to the correct destination. Do not redistribute debris into a hidden airflow space or claim a contamination limit was exceeded without measurement. Assign removal and verification ownership.

**Recurring maintenance and causal work history**

Synthetic training case — not a field record.

The CMMS lists six “pump seal leak” tickets in one month. Three are duplicate reports of one event. The remaining events occurred after work by two teams using different installation revisions. Operating hours doubled compared with the previous month. Reports record replacement parts but omit alignment observations. A proposal judges performance only by raw ticket count.

**Reasoning:** Reconcile event identity before calculating failure frequency. Compare actual events with operating exposure and relevant conditions. Preserve procedure revisions and missing alignment evidence as hypotheses to investigate. A corrective plan should test the failure mechanism and verify restored function and recurrence under comparable observation, not simply reduce ticket entry.

#### Guided practice

Independently review a maintenance proposal with an identity discrepancy, unsuitable tool, incomplete service report and depleted spare stock. Build an executable acceptance and recovery plan.

**Hint:** Tie every task to its failure mechanism and verify current readiness before sequence execution.

**Worked solution:** Resolve asset/method versions and failed prechecks; use supported tools and parts; calculate only within declared planning assumptions; set recovery decision time before the window closes; preserve actual as-found/as-left results; verify automatic function and records; review recurrence using distinct events and comparable exposure.

#### Independent task

Environment: analytical

Prepare and defend a maintenance package, then arrange a safe practical task at the appropriate evidence level.

**Packaged starter material**

- course_labs/CDFOS/README.md
- course_labs/CDFOS/fixture.json
- course_labs/CDFOS/assessment_template.md
- course_labs/CDFOS/lab.py
- course_labs/CDFOS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- Strategy and criticality rationale
- Reviewed MOP with hold/rollback decisions
- Spare/tool readiness and housekeeping checks
- Service report and recurrence analysis

**Acceptance criteria**

- The method matches the current asset and conditions.
- No unperformed test is claimed as passed.
- Handback restores required function and reconciles records.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer. The bundled calculator was executed against supplied synthetic fixtures; its numerical checks do not grade physical work or professional authorization.

#### Chapter practice

**CDFOS-Q0191 · single · operations**

Which observation makes a mounting-related fan hypothesis relevant?

Synthetic training case — not a field record.

Fan group F has a manufacturer-required inspection interval. A vibration trend rose after a mounting change, while run hours are low. A separate room-temperature sensor has shown intermittent mapping errors with no physical drift. A proposal replaces every fan monthly and recalibrates the sensor weekly without investigating either cause.

1. The sensor has a mapping issue
2. Run hours are low
3. The proposal uses a monthly interval
4. Vibration increased after the mounting change

**Correct option(s):** 4

- Option 1: That belongs to a different failure chain.
- Option 2: Low age alone does not identify the vibration source.
- Option 3: A chosen calendar interval does not explain the observed change.
- Option 4: The timing supports a hypothesis to test, not yet a proven cause.

**CDFOS-Q0192 · single · operations**

What should happen to the manufacturer-required inspection?

Synthetic training case — not a field record.

Fan group F has a manufacturer-required inspection interval. A vibration trend rose after a mounting change, while run hours are low. A separate room-temperature sensor has shown intermittent mapping errors with no physical drift. A proposal replaces every fan monthly and recalibrates the sensor weekly without investigating either cause.

1. Cancel it because vibration is now monitored
2. Retain it unless an authorized applicable process approves a change
3. Replace it with a dashboard screenshot only
4. Perform it only after a fan fails

**Correct option(s):** 2

- Option 1: Condition data do not automatically replace the stated requirement.
- Option 2: A speculative new strategy does not silently waive required work.
- Option 3: The specified inspection may require different evidence.
- Option 4: That changes preventive work into reactive response without justification.

**CDFOS-Q0193 · single · mechanism**

Why is weekly sensor calibration a weak response to the stated mapping fault?

Synthetic training case — not a field record.

Fan group F has a manufacturer-required inspection interval. A vibration trend rose after a mounting change, while run hours are low. A separate room-temperature sensor has shown intermittent mapping errors with no physical drift. A proposal replaces every fan monthly and recalibrates the sensor weekly without investigating either cause.

1. Mapping errors prove the sensor is physically broken
2. Calibration may not correct the digital association error
3. Calibration can never improve a sensor’s measurement
4. Weekly work is always prohibited

**Correct option(s):** 2

- Option 1: Digital configuration can be wrong while the sensor is accurate.
- Option 2: The proposed task does not address the observed mechanism.
- Option 3: It can be relevant to an actual measurement-performance issue.
- Option 4: Suitability depends on need, method and consequences.

**CDFOS-Q0194 · single · mechanism**

What distinguishes condition-based work here?

Synthetic training case — not a field record.

Fan group F has a manufacturer-required inspection interval. A vibration trend rose after a mounting change, while run hours are low. A separate room-temperature sensor has shown intermittent mapping errors with no physical drift. A proposal replaces every fan monthly and recalibrates the sensor weekly without investigating either cause.

1. Replacing equipment only by calendar date
2. A relevant observed condition informs a defined maintenance decision
3. Waiting for complete failure before every action
4. Any task displayed on a digital dashboard

**Correct option(s):** 2

- Option 1: That is a time-based trigger rather than condition-based reasoning.
- Option 2: The condition must have an interpretable relationship to function.
- Option 3: That is not the stated condition-based approach.
- Option 4: Display format does not define maintenance strategy.

**CDFOS-Q0195 · single · operations**

What risk can unnecessary frequent replacement introduce?

Synthetic training case — not a field record.

Fan group F has a manufacturer-required inspection interval. A vibration trend rose after a mounting change, while run hours are low. A separate room-temperature sensor has shown intermittent mapping errors with no physical drift. A proposal replaces every fan monthly and recalibrates the sensor weekly without investigating either cause.

1. Automatic improvement independent of component suitability
2. Installation defects and additional maintenance exposure
3. Elimination of the need for post-work verification
4. Guaranteed removal of every common cause

**Correct option(s):** 2

- Option 1: Unsupported substitutions can worsen behavior.
- Option 2: More intervention is not automatically more reliability.
- Option 3: Every consequential intervention still needs acceptance.
- Option 4: Replacement may leave the underlying cause unchanged.

**CDFOS-Q0196 · single · operations**

Which task statement is most assessable?

Synthetic training case — not a field record.

Fan group F has a manufacturer-required inspection interval. A vibration trend rose after a mounting change, while run hours are low. A separate room-temperature sensor has shown intermittent mapping errors with no physical drift. A proposal replaces every fan monthly and recalibrates the sensor weekly without investigating either cause.

1. Inspect the defined condition and compare recorded results with approved limits
2. Complete the work order before month end
3. Check the fan and make it good
4. Replace whichever part is easiest to reach

**Correct option(s):** 1

- Option 1: It specifies evidence and a decision basis.
- Option 2: Timing alone does not establish function.
- Option 3: That leaves method and acceptance undefined.
- Option 4: Convenience does not identify the required corrective action.

**CDFOS-Q0197 · single · operations**

What should criticality consider beyond replacement cost?

Synthetic training case — not a field record.

Fan group F has a manufacturer-required inspection interval. A vibration trend rose after a mounting change, while run hours are low. A separate room-temperature sensor has shown intermittent mapping errors with no physical drift. A proposal replaces every fan monthly and recalibrates the sensor weekly without investigating either cause.

1. Only the number of past tickets
2. Only how visually large the asset is
3. Service consequence, dependencies and recovery difficulty
4. Only the supplier’s discount

**Correct option(s):** 3

- Option 1: Frequency alone omits impact and hidden failures.
- Option 2: Size is not a reliable consequence measure.
- Option 3: A low-cost component can affect critical functions.
- Option 4: Price reduction does not measure operational consequence.

**CDFOS-Q0198 · single · operations**

What would support a predictive-maintenance claim?

Synthetic training case — not a field record.

Fan group F has a manufacturer-required inspection interval. A vibration trend rose after a mounting change, while run hours are low. A separate room-temperature sensor has shown intermittent mapping errors with no physical drift. A proposal replaces every fan monthly and recalibrates the sensor weekly without investigating either cause.

1. A monthly replacement schedule called predictive
2. The presence of an AI label on the dashboard
3. A single rising point without context
4. A validated relationship between observations and future behavior within stated limits

**Correct option(s):** 4

- Option 1: Renaming a strategy does not change its mechanism.
- Option 2: A product label does not validate predictive performance.
- Option 3: One observation does not establish a predictive model.
- Option 4: Prediction needs evidence beyond plotting a trend.

**CDFOS-Q0199 · single · operations**

What should the investigation compare for the fan?

Synthetic training case — not a field record.

Fan group F has a manufacturer-required inspection interval. A vibration trend rose after a mounting change, while run hours are low. A separate room-temperature sensor has shown intermittent mapping errors with no physical drift. A proposal replaces every fan monthly and recalibrates the sensor weekly without investigating either cause.

1. Only the fan’s purchase-order approval
2. Mounting, operating condition and vibration evidence before and after the change
3. Only the sensor’s database row name
4. Only the proposed maintenance frequency

**Correct option(s):** 2

- Option 1: Procurement authority is not diagnostic evidence.
- Option 2: A controlled comparison can discriminate the supported hypothesis.
- Option 3: That does not address the fan’s mechanical condition.
- Option 4: A proposed schedule cannot explain the fault.

**CDFOS-Q0200 · single · operations**

What is an appropriate strategy-review outcome?

Synthetic training case — not a field record.

Fan group F has a manufacturer-required inspection interval. A vibration trend rose after a mounting change, while run hours are low. A separate room-temperature sensor has shown intermittent mapping errors with no physical drift. A proposal replaces every fan monthly and recalibrates the sensor weekly without investigating either cause.

1. One universal replacement interval for every asset
2. No maintenance until every causal question is certain
3. Close both findings because the equipment still runs
4. Separate justified preventive, condition and corrective tasks with acceptance

**Correct option(s):** 4

- Option 1: The case contains distinct failure modes and requirements.
- Option 2: Required protective work and bounded investigation can proceed appropriately.
- Option 3: Continued operation does not resolve degraded or misleading function.
- Option 4: Different mechanisms can need different treatments.

**CDFOS-Q0201 · single · operations**

Which issue must be resolved before matching the procedure to equipment?

Synthetic training case — not a field record.

A MOP names pump P-14, but its drawing points to P-41. Step 6 says “continue after valve feedback changes,” with no expected state or timeout. The window ends at 04:00; supported recovery takes 18 minutes and final checks take 12 minutes. A precheck shows the standby pump is unavailable. The required service must remain supported.

1. Whether the maintenance window is long enough for either pump
2. Whether the procedure’s pump model matches both candidate assets
3. The P-14 versus P-41 identity conflict
4. Whether the contractor has previously serviced this pump family

**Correct option(s):** 3

- Option 1: Available time does not reconcile P-14 and P-41 before selecting the work target.
- Option 2: A model match cannot distinguish the two physical assets when their controlled identifiers conflict.
- Option 3: Executing against the wrong asset can enlarge the consequence.
- Option 4: Experience with a family does not establish which identified pump the authorization covers.

**CDFOS-Q0202 · single · operations**

What is missing from step 6?

Synthetic training case — not a field record.

A MOP names pump P-14, but its drawing points to P-41. Step 6 says “continue after valve feedback changes,” with no expected state or timeout. The window ends at 04:00; supported recovery takes 18 minutes and final checks take 12 minutes. A precheck shows the standby pump is unavailable. The required service must remain supported.

1. Only the operator’s signature at the end
2. Only a general instruction to continue if conditions seem normal
3. Expected feedback, allowed time and the failed-result decision
4. Only the commanded pump state without confirmation

**Correct option(s):** 3

- Option 1: A signature cannot supply an unspecified expected result.
- Option 2: The operator still lacks an observable criterion and defined failure branch.
- Option 3: The instruction cannot be assessed or safely branched as written.
- Option 4: A command is not the expected physical feedback or timeout decision.

**CDFOS-Q0203 · single · recovery**

What is the latest recovery decision time without extra margin?

Synthetic training case — not a field record.

A MOP names pump P-14, but its drawing points to P-41. Step 6 says “continue after valve feedback changes,” with no expected state or timeout. The window ends at 04:00; supported recovery takes 18 minutes and final checks take 12 minutes. A precheck shows the standby pump is unavailable. The required service must remain supported.

1. 03:30
2. 03:48
3. 03:42
4. 04:00

**Correct option(s):** 1

- Option 1: Eighteen minutes plus twelve minutes require thirty minutes.
- Option 2: This allows checks but omits recovery.
- Option 3: This allows recovery but omits final checks.
- Option 4: At window end there is no time for the required remaining work.

**CDFOS-Q0204 · single · operations**

What effect does the unavailable standby have?

Synthetic training case — not a field record.

A MOP names pump P-14, but its drawing points to P-41. Step 6 says “continue after valve feedback changes,” with no expected state or timeout. The window ends at 04:00; supported recovery takes 18 minutes and final checks take 12 minutes. A precheck shows the standby pump is unavailable. The required service must remain supported.

1. It can be ignored if the drawing shows two pumps
2. It only changes the work-order priority code
3. It invalidates the assumed supported maintenance state
4. It makes the primary pump safer to remove

**Correct option(s):** 3

- Option 1: A drawing does not override observed current state.
- Option 2: The effect is on service capability, not just classification.
- Option 3: Current dependencies differ from a fully available baseline.
- Option 4: Loss of standby reduces rather than increases support.

**CDFOS-Q0205 · single · operations**

What should a failed precheck do to the sequence?

Synthetic training case — not a field record.

A MOP names pump P-14, but its drawing points to P-41. Step 6 says “continue after valve feedback changes,” with no expected state or timeout. The window ends at 04:00; supported recovery takes 18 minutes and final checks take 12 minutes. A precheck shows the standby pump is unavailable. The required service must remain supported.

1. Automatically choose an unreviewed alternate asset
2. Trigger the defined hold or escalation before affected work
3. Allow continuation if the procedure was approved last month
4. Be marked passed after the work is complete

**Correct option(s):** 2

- Option 1: A different target requires its own valid method.
- Option 2: Prechecks are decision gates, not ceremonial records.
- Option 3: Approval assumed conditions that may have changed.
- Option 4: Retrospective falsification removes the control.

**CDFOS-Q0206 · single · recovery**

Why must rollback feasibility be reviewed before starting?

Synthetic training case — not a field record.

A MOP names pump P-14, but its drawing points to P-41. Step 6 says “continue after valve feedback changes,” with no expected state or timeout. The window ends at 04:00; supported recovery takes 18 minutes and final checks take 12 minutes. A precheck shows the standby pump is unavailable. The required service must remain supported.

1. Rollback matters only when the customer complains
2. Some actions cannot be reversed by simply undoing the last step
3. A backup file guarantees every mechanical state can be restored
4. Every physical change is instantly reversible

**Correct option(s):** 2

- Option 1: It protects the defined service and work boundary.
- Option 2: Recovery may require different artifacts, time or specialist work.
- Option 3: Configuration does not restore all physical conditions.
- Option 4: That is not a valid general assumption.

**CDFOS-Q0207 · single · operations**

What should an independent check target here?

Synthetic training case — not a field record.

A MOP names pump P-14, but its drawing points to P-41. Step 6 says “continue after valve feedback changes,” with no expected state or timeout. The window ends at 04:00; supported recovery takes 18 minutes and final checks take 12 minutes. A precheck shows the standby pump is unavailable. The required service must remain supported.

1. Only whether the form uses the correct letterhead
2. Only the number of tools listed
3. Only the planned lunch break
4. Asset identity and consequential state transitions

**Correct option(s):** 4

- Option 1: Appearance does not verify the work target or transition.
- Option 2: Tool count alone does not establish suitability or identity.
- Option 3: That does not assess the identified engineering risks.
- Option 4: These are specific high-consequence failure points.

**CDFOS-Q0208 · single · operations**

What should be recorded during execution if later authorized?

Synthetic training case — not a field record.

A MOP names pump P-14, but its drawing points to P-41. Step 6 says “continue after valve feedback changes,” with no expected state or timeout. The window ends at 04:00; supported recovery takes 18 minutes and final checks take 12 minutes. A precheck shows the standby pump is unavailable. The required service must remain supported.

1. Only the final pass/fail label
2. Only the original planned start time
3. Actual observations, timing and deviations at the relevant steps
4. Prefilled expected values copied into result fields

**Correct option(s):** 3

- Option 1: That loses the information needed to review deviations.
- Option 2: Actual transitions and outcomes remain necessary.
- Option 3: This preserves what happened against the expected sequence.
- Option 4: Expected behavior is not observed evidence.

**CDFOS-Q0209 · single · recovery**

What is required if the defined recovery route becomes unavailable?

Synthetic training case — not a field record.

A MOP names pump P-14, but its drawing points to P-41. Step 6 says “continue after valve feedback changes,” with no expected state or timeout. The window ends at 04:00; supported recovery takes 18 minutes and final checks take 12 minutes. A precheck shows the standby pump is unavailable. The required service must remain supported.

1. Remove recovery from the MOP after the fact
2. Stop expansion and obtain an authorized revised decision
3. Treat the operator’s optimism as equivalent to recovery evidence
4. Continue because the window has already started

**Correct option(s):** 2

- Option 1: That conceals a changed risk.
- Option 2: The original work basis no longer supports its safety/service assumptions.
- Option 3: Confidence does not restore missing capability.
- Option 4: Elapsed time does not create a viable recovery path.

**CDFOS-Q0210 · single · operations**

What makes handback complete for this pump task?

Synthetic training case — not a field record.

A MOP names pump P-14, but its drawing points to P-41. Step 6 says “continue after valve feedback changes,” with no expected state or timeout. The window ends at 04:00; supported recovery takes 18 minutes and final checks take 12 minutes. A precheck shows the standby pump is unavailable. The required service must remain supported.

1. Verified required mode, function, alarms and reconciled records
2. Only that the MOP file is uploaded
3. Only that the work window has expired
4. Only that the new part is bolted in place

**Correct option(s):** 1

- Option 1: A repaired component must return the intended service.
- Option 2: Document storage is not equipment verification.
- Option 3: Time does not prove successful return to service.
- Option 4: Installation alone does not establish functional acceptance.

**CDFOS-Q0211 · single · operations**

What has the report directly established?

Synthetic training case — not a field record.

A contractor report states “sensor replaced; system healthy.” It identifies the new sensor serial but contains no as-found readings, source range, BMS point check or alarm test. A local display reads plausibly; BMS still associates the point with the neighboring unit. The work order is marked ready for closure.

1. The original sensor’s measured error
2. Correct BMS asset association
3. Successful alarm testing
4. The claimed replacement and its recorded serial identity

**Correct option(s):** 4

- Option 1: As-found readings are absent.
- Option 2: The case states that mapping remains wrong.
- Option 3: No alarm test is recorded.
- Option 4: The wider functional checks are not documented.

**CDFOS-Q0212 · single · operations**

What is the immediate obstacle to closure?

Synthetic training case — not a field record.

A contractor report states “sensor replaced; system healthy.” It identifies the new sensor serial but contains no as-found readings, source range, BMS point check or alarm test. A local display reads plausibly; BMS still associates the point with the neighboring unit. The work order is marked ready for closure.

1. The required observation chain is not correctly verified
2. The new sensor is the approved replacement model
3. The local display remains readable after the replacement
4. The replacement sensor has a different serial number from the removed sensor

**Correct option(s):** 1

- Option 1: A plausible local reading does not close the known BMS mapping defect.
- Option 2: Approved hardware is not itself a closure obstacle; the unverified observation chain is.
- Option 3: Readability is useful but does not resolve the known downstream association with the wrong asset.
- Option 4: A new serial is expected in a replacement; it needs traceability, not rejection solely because it changed.

**CDFOS-Q0213 · single · operations**

How should missing as-found values be handled?

Synthetic training case — not a field record.

A contractor report states “sensor replaced; system healthy.” It identifies the new sensor serial but contains no as-found readings, source range, BMS point check or alarm test. A local display reads plausibly; BMS still associates the point with the neighboring unit. The work order is marked ready for closure.

1. Estimate favorable values without labeling the estimate
2. Record the gap and seek legitimate retained evidence
3. Copy as-left values into the as-found column
4. Delete the need for historical diagnosis from every future task

**Correct option(s):** 2

- Option 1: Unsupported values can distort cause and acceptance.
- Option 2: Do not manufacture historical readings.
- Option 3: That creates a false account of the original condition.
- Option 4: A missing record should improve, not weaken, the process.

**CDFOS-Q0214 · single · mechanism**

What does the neighboring-unit association threaten?

Synthetic training case — not a field record.

A contractor report states “sensor replaced; system healthy.” It identifies the new sensor serial but contains no as-found readings, source range, BMS point check or alarm test. A local display reads plausibly; BMS still associates the point with the neighboring unit. The work order is marked ready for closure.

1. The local display must therefore be electrically dead
2. Operators may attribute the measurement or alarm to the wrong asset
3. Only the order in which points appear in a trend export
4. The sensor’s physical serial number changes

**Correct option(s):** 2

- Option 1: The case says it shows a plausible value.
- Option 2: Correct value and wrong identity can still mislead decisions.
- Option 3: Wrong asset association can alter operational attribution, not merely presentation sequence.
- Option 4: Software mapping does not alter the installed serial.

**CDFOS-Q0215 · single · diagnosis**

Which test directly addresses the mapping defect?

Synthetic training case — not a field record.

A contractor report states “sensor replaced; system healthy.” It identifies the new sensor serial but contains no as-found readings, source range, BMS point check or alarm test. A local display reads plausibly; BMS still associates the point with the neighboring unit. The work order is marked ready for closure.

1. Restart the browser and assume the label refreshed
2. Confirm that the neighboring point displays a plausible value
3. Trace a known source stimulus to the correct asset point and alarm
4. Ping the BMS server only

**Correct option(s):** 3

- Option 1: A display refresh does not establish source correctness.
- Option 2: Plausibility does not establish which physical source drives the required point.
- Option 3: It verifies the actual end-to-end association.
- Option 4: Reachability does not test point identity.

**CDFOS-Q0216 · single · mechanism**

Why should the source range be retained?

Synthetic training case — not a field record.

A contractor report states “sensor replaced; system healthy.” It identifies the new sensor serial but contains no as-found readings, source range, BMS point check or alarm test. A local display reads plausibly; BMS still associates the point with the neighboring unit. The work order is marked ready for closure.

1. Scaling and alarm interpretation depend on the actual configured range
2. Because range replaces calibration evidence
3. Because every sensor uses the same range
4. Only to make the report longer

**Correct option(s):** 1

- Option 1: A different range can produce plausible but wrong engineering values.
- Option 2: Range and measurement performance are separate facts.
- Option 3: Products and applications can differ.
- Option 4: The range has a functional role.

**CDFOS-Q0217 · single · operations**

What should a conditional acceptance identify if the site permits it?

Synthetic training case — not a field record.

A contractor report states “sensor replaced; system healthy.” It identifies the new sensor serial but contains no as-found readings, source range, BMS point check or alarm test. A local display reads plausibly; BMS still associates the point with the neighboring unit. The work order is marked ready for closure.

1. A permanent waiver of every future alarm test
2. An assumed complete pass on all unperformed tests
3. Only the phrase “accepted with comments”
4. The explicit residual defect, restriction, owner and resolution condition

**Correct option(s):** 4

- Option 1: A bounded exception does not justify universal omission.
- Option 2: Unperformed checks cannot be claimed as passed.
- Option 3: That is too vague to control the remaining issue.
- Option 4: Conditional status must not conceal incomplete required work.

**CDFOS-Q0218 · single · operations**

What should happen to the CMMS record after corrected verification?

Synthetic training case — not a field record.

A contractor report states “sensor replaced; system healthy.” It identifies the new sensor serial but contains no as-found readings, source range, BMS point check or alarm test. A local display reads plausibly; BMS still associates the point with the neighboring unit. The work order is marked ready for closure.

1. Store the evidence only on the contractor’s private device
2. Leave the old serial as the installed item
3. Link the performed results, asset changes and final disposition
4. Close it without the new evidence because it was already ready

**Correct option(s):** 3

- Option 1: The operator needs controlled access to required records.
- Option 2: That would preserve an inaccurate asset state.
- Option 3: The record should match the returned equipment and evidence.
- Option 4: Readiness did not establish the missing tests.

**CDFOS-Q0219 · single · operations**

Which report statement is evidence-based?

Synthetic training case — not a field record.

A contractor report states “sensor replaced; system healthy.” It identifies the new sensor serial but contains no as-found readings, source range, BMS point check or alarm test. A local display reads plausibly; BMS still associates the point with the neighboring unit. The work order is marked ready for closure.

1. The entire facility is healthy because one point passed
2. All prior incidents are resolved by this replacement
3. The correct point and alarm passed the named test under recorded conditions
4. No future sensor fault can occur

**Correct option(s):** 3

- Option 1: One bounded test cannot establish every system.
- Option 2: Historical causes may require separate evidence.
- Option 3: It states the scope of actual verification.
- Option 4: Maintenance acceptance is not a guarantee against all future failure.

**CDFOS-Q0220 · single · operations**

What process improvement addresses the original report weakness?

Synthetic training case — not a field record.

A contractor report states “sensor replaced; system healthy.” It identifies the new sensor serial but contains no as-found readings, source range, BMS point check or alarm test. A local display reads plausibly; BMS still associates the point with the neighboring unit. The work order is marked ready for closure.

1. Let the service provider define success after seeing results
2. Require every report to contain more pages regardless of content
3. Remove acceptance review to accelerate closure
4. Require task-specific as-found/as-left and functional acceptance fields

**Correct option(s):** 4

- Option 1: Acceptance criteria should be agreed before the test.
- Option 2: Length does not ensure useful evidence.
- Option 3: That would preserve the underlying assurance gap.
- Option 4: The template should support the evidence needed for this maintenance.

**CDFOS-Q0221 · single · operations**

What is the stated illustrative reorder point?

Synthetic training case — not a field record.

A synthetic filter stock uses a stable planning estimate of 2 units/day. Confirmed replenishment lead time is 10 days and the approved safety stock is 8 units. There are 25 units physically present, 6 reserved for an approved job, and 4 quarantined for damage. An order for 20 is confirmed but not yet received. The policy uses ready unallocated stock for immediate-task readiness.

1. 36 units
2. 20 units
3. 18 units
4. 28 units

**Correct option(s):** 4

- Option 1: This double-counts the safety stock.
- Option 2: This omits the approved safety stock.
- Option 3: This adds lead-time days to stock rather than multiplying demand by time.
- Option 4: Twenty units of lead-time demand plus eight safety units.

**CDFOS-Q0222 · single · calculation**

How many units are ready and unallocated now?

Synthetic training case — not a field record.

A synthetic filter stock uses a stable planning estimate of 2 units/day. Confirmed replenishment lead time is 10 days and the approved safety stock is 8 units. There are 25 units physically present, 6 reserved for an approved job, and 4 quarantined for damage. An order for 20 is confirmed but not yet received. The policy uses ready unallocated stock for immediate-task readiness.

1. 15 units
2. 19 units
3. 35 units
4. 25 units

**Correct option(s):** 1

- Option 1: Subtract six reserved and four quarantined from twenty-five present.
- Option 2: This subtracts reservations but ignores damaged stock.
- Option 3: Incoming stock is not yet available and other deductions still apply.
- Option 4: Physical presence includes unavailable categories.

**CDFOS-Q0223 · single · operations**

Can the confirmed incoming order satisfy a task that starts before delivery?

Synthetic training case — not a field record.

A synthetic filter stock uses a stable planning estimate of 2 units/day. Confirmed replenishment lead time is 10 days and the approved safety stock is 8 units. There are 25 units physically present, 6 reserved for an approved job, and 4 quarantined for damage. An order for 20 is confirmed but not yet received. The policy uses ready unallocated stock for immediate-task readiness.

1. No incoming order can ever inform planning
2. Yes, because confirmation makes the parts physically present
3. Not as presently available stock
4. Yes, if the work order is marked urgent

**Correct option(s):** 3

- Option 1: Confirmed receipts are relevant to future inventory decisions.
- Option 2: An order record does not put items on the shelf.
- Option 3: A future receipt is distinct from current issue readiness.
- Option 4: Urgency does not change delivery state.

**CDFOS-Q0224 · single · mechanism**

Why exclude quarantined items from ready stock?

Synthetic training case — not a field record.

A synthetic filter stock uses a stable planning estimate of 2 units/day. Confirmed replenishment lead time is 10 days and the approved safety stock is 8 units. There are 25 units physically present, 6 reserved for an approved job, and 4 quarantined for damage. An order for 20 is confirmed but not yet received. The policy uses ready unallocated stock for immediate-task readiness.

1. Their suitability has not been accepted
2. Their serial numbers are necessarily invalid
3. They are excluded only to reduce accounting value
4. Quarantine automatically means every item is irreparable

**Correct option(s):** 1

- Option 1: Damaged or uncertain parts cannot silently count as recovery capability.
- Option 2: Damage status does not by itself establish identity fraud.
- Option 3: The operational concern is suitability for use.
- Option 4: Disposition may later allow repair or release.

**CDFOS-Q0225 · single · operations**

What assumption limits the reorder calculation?

Synthetic training case — not a field record.

A synthetic filter stock uses a stable planning estimate of 2 units/day. Confirmed replenishment lead time is 10 days and the approved safety stock is 8 units. There are 25 units physically present, 6 reserved for an approved job, and 4 quarantined for damage. An order for 20 is confirmed but not yet received. The policy uses ready unallocated stock for immediate-task readiness.

1. The same values apply to every asset family
2. Safety stock eliminates all uncertainty
3. The formula proves every possible supply interruption is covered
4. Demand and lead-time estimates must represent the planning situation

**Correct option(s):** 4

- Option 1: Demand, consequence and supply chains differ.
- Option 2: A finite buffer cannot cover every event.
- Option 3: It depends on its assumptions and stock policy.
- Option 4: Critical intermittent failures may need another justified approach.

**CDFOS-Q0226 · single · operations**

What should happen when reserved stock is requested for another incident?

Synthetic training case — not a field record.

A synthetic filter stock uses a stable planning estimate of 2 units/day. Confirmed replenishment lead time is 10 days and the approved safety stock is 8 units. There are 25 units physically present, 6 reserved for an approved job, and 4 quarantined for damage. An order for 20 is confirmed but not yet received. The policy uses ready unallocated stock for immediate-task readiness.

1. Obtain an authorized reprioritization with the affected job’s consequence assessed
2. Delete the reservation to keep the dashboard green
3. Treat reserved stock as damaged
4. Issue it silently because it is physically present

**Correct option(s):** 1

- Option 1: A reservation is an existing commitment.
- Option 2: Record manipulation does not resolve competing needs.
- Option 3: Reservation and condition are different categories.
- Option 4: That can leave the planned job without its required part.

**CDFOS-Q0227 · single · operations**

What should follow a valid spare issue?

Synthetic training case — not a field record.

A synthetic filter stock uses a stable planning estimate of 2 units/day. Confirmed replenishment lead time is 10 days and the approved safety stock is 8 units. There are 25 units physically present, 6 reserved for an approved job, and 4 quarantined for damage. An order for 20 is confirmed but not yet received. The policy uses ready unallocated stock for immediate-task readiness.

1. Update quantity/custody and trigger the defined replenishment action
2. Keep the old count until the invoice is paid
3. Wait until the next annual inventory regardless of criticality
4. Count the installed used part as an unused spare

**Correct option(s):** 1

- Option 1: Recovery readiness changes when stock is consumed.
- Option 2: Financial timing does not determine physical issue state.
- Option 3: The recorded ready quantity would remain wrong.
- Option 4: Installed equipment is not immediately available replacement stock.

**CDFOS-Q0228 · single · operations**

What evidence supports accepting a substitute spare?

Synthetic training case — not a field record.

A synthetic filter stock uses a stable planning estimate of 2 units/day. Confirmed replenishment lead time is 10 days and the approved safety stock is 8 units. There are 25 units physically present, 6 reserved for an approved job, and 4 quarantined for damage. An order for 20 is confirmed but not yet received. The policy uses ready unallocated stock for immediate-task readiness.

1. A higher model number without support evidence
2. The supplier’s statement that it is popular
3. The same connector shape without checking ratings or configuration
4. Approved compatibility and condition for the selected equipment

**Correct option(s):** 4

- Option 1: Newer can still be incompatible.
- Option 2: Popularity does not verify the required interface and version.
- Option 3: Mechanical fit alone does not establish electrical or functional compatibility.
- Option 4: Similarity alone does not establish supported use.

**CDFOS-Q0229 · single · operations**

What should a periodic stock check compare?

Synthetic training case — not a field record.

A synthetic filter stock uses a stable planning estimate of 2 units/day. Confirmed replenishment lead time is 10 days and the approved safety stock is 8 units. There are 25 units physically present, 6 reserved for an approved job, and 4 quarantined for damage. An order for 20 is confirmed but not yet received. The policy uses ready unallocated stock for immediate-task readiness.

1. Only the total shelf capacity
2. Only the purchase price of the most recent batch
3. Actual identity, quantity, condition and restrictions against records
4. Only the supplier’s catalogue availability

**Correct option(s):** 3

- Option 1: Space does not establish what ready parts exist.
- Option 2: Price does not verify present condition or allocation.
- Option 3: Inventory accuracy includes more than counting boxes.
- Option 4: Published availability is not onsite stock.

**CDFOS-Q0230 · single · operations**

What is a sound response to repeated delivery delays?

Synthetic training case — not a field record.

A synthetic filter stock uses a stable planning estimate of 2 units/day. Confirmed replenishment lead time is 10 days and the approved safety stock is 8 units. There are 25 units physically present, 6 reserved for an approved job, and 4 quarantined for damage. An order for 20 is confirmed but not yet received. The policy uses ready unallocated stock for immediate-task readiness.

1. Remove the spare requirement from the recovery plan
2. Reassess lead-time assumptions, stock policy and supported alternatives
3. Count unconfirmed offers as received stock
4. Keep the old lead time because it is in the spreadsheet

**Correct option(s):** 2

- Option 1: The service dependency still exists.
- Option 2: The planning basis should reflect observed supply performance.
- Option 3: Offers do not establish availability.
- Option 4: An obsolete assumption can understate exposure.

**CDFOS-Q0231 · single · mechanism**

Why is the current torque certificate insufficient here?

Synthetic training case — not a field record.

A MOP requires a specified calibrated torque tool and an insulated tool appropriate to the selected task. The torque tool’s certificate is current, but its listed range does not include the required setting. A similar unverified tool is available. At handback, one small adapter from the issued kit is unaccounted for near an open equipment cabinet.

1. Its documented range excludes the required setting
2. Calibration dates are never useful
3. The method’s setting may be ignored if the tool is familiar
4. Every torque tool needs daily replacement

**Correct option(s):** 1

- Option 1: Fitness depends on the actual measurement/application range.
- Option 2: Due status is relevant but not sufficient alone.
- Option 3: Familiarity does not change supported capability.
- Option 4: No such universal requirement is stated.

**CDFOS-Q0232 · single · operations**

What is required before using the similar tool?

Synthetic training case — not a field record.

A MOP requires a specified calibrated torque tool and an insulated tool appropriate to the selected task. The torque tool’s certificate is current, but its listed range does not include the required setting. A similar unverified tool is available. At handback, one small adapter from the issued kit is unaccounted for near an open equipment cabinet.

1. Only a newer purchase date
2. Only confirmation that it fits in the same case
3. Verified suitability and the approved substitution decision
4. Only a verbal claim that it worked elsewhere

**Correct option(s):** 3

- Option 1: Newness is not the same as suitability.
- Option 2: Physical resemblance does not establish performance or rating.
- Option 3: The alternative must meet the method’s relevant requirements.
- Option 4: Another task may have different requirements.

**CDFOS-Q0233 · single · operations**

What should be done about the missing adapter?

Synthetic training case — not a field record.

A MOP requires a specified calibrated torque tool and an insulated tool appropriate to the selected task. The torque tool’s certificate is current, but its listed range does not include the required setting. A similar unverified tool is available. At handback, one small adapter from the issued kit is unaccounted for near an open equipment cabinet.

1. Assume it was left in the workshop
2. Restore service first and search only if a fault occurs
3. Close the kit list using the original issue count
4. Hold the relevant handback and reconcile the item/work area

**Correct option(s):** 4

- Option 1: The case provides no evidence of that location.
- Option 2: The unresolved object may create the later fault.
- Option 3: That would conceal the discrepancy.
- Option 4: An unaccounted object can affect the returned equipment state.

**CDFOS-Q0234 · single · mechanism**

What does the tool’s insulation need to match?

Synthetic training case — not a field record.

A MOP requires a specified calibrated torque tool and an insulated tool appropriate to the selected task. The torque tool’s certificate is current, but its listed range does not include the required setting. A similar unverified tool is available. At handback, one small adapter from the issued kit is unaccounted for near an open equipment cabinet.

1. Only the torque range printed on the tool
2. The selected task’s approved rating and method
3. Only the torque tool’s calibration date
4. Only whether the insulating surface appears undamaged

**Correct option(s):** 2

- Option 1: Mechanical range does not establish electrical insulation suitability.
- Option 2: Generic appearance does not establish appropriate protection.
- Option 3: These tools have different suitability attributes.
- Option 4: Condition inspection matters, but intact appearance does not establish the required rating or approved method.

**CDFOS-Q0235 · single · operations**

Which record supports tool accountability?

Synthetic training case — not a field record.

A MOP requires a specified calibrated torque tool and an insulated tool appropriate to the selected task. The torque tool’s certificate is current, but its listed range does not include the required setting. A similar unverified tool is available. At handback, one small adapter from the issued kit is unaccounted for near an open equipment cabinet.

1. Issued items, responsible holder, task and returned status
2. Only the supplier’s marketing list
3. Only the cabinet’s asset category
4. Only the total annual tool budget

**Correct option(s):** 1

- Option 1: It links the kit to the actual work and discrepancy.
- Option 2: That does not show what was issued or returned.
- Option 3: Asset classification does not identify the kit contents.
- Option 4: Budget does not locate a missing adapter.

**CDFOS-Q0236 · single · operations**

What should happen if a tool is dropped during work?

Synthetic training case — not a field record.

A MOP requires a specified calibrated torque tool and an insulated tool appropriate to the selected task. The torque tool’s certificate is current, but its listed range does not include the required setting. A similar unverified tool is available. At handback, one small adapter from the issued kit is unaccounted for near an open equipment cabinet.

1. Automatically assume it has no effect on any measurement
2. Continue solely because its certificate is still in date
3. Assess it under the tool-control and manufacturer procedure before reliance
4. Automatically discard every tool in the room

**Correct option(s):** 3

- Option 1: That is unsupported without assessment.
- Option 2: The certificate predates the possible damage.
- Option 3: Impact may affect condition or performance.
- Option 4: The response should follow the actual affected items and evidence.

**CDFOS-Q0237 · single · operations**

What is the distinction between fit and suitability?

Synthetic training case — not a field record.

A MOP requires a specified calibrated torque tool and an insulated tool appropriate to the selected task. The torque tool’s certificate is current, but its listed range does not include the required setting. A similar unverified tool is available. At handback, one small adapter from the issued kit is unaccounted for near an open equipment cabinet.

1. Physical fit proves every safety and accuracy requirement
2. Suitability depends only on the operator’s preference
3. A tool may physically fit while lacking required performance or rating
4. A tool that does not fit is always safer

**Correct option(s):** 3

- Option 1: That overstates what fit establishes.
- Option 2: The task and equipment requirements govern selection.
- Option 3: Mechanical fit is only one attribute.
- Option 4: Poor fit can damage the work or create additional hazards.

**CDFOS-Q0238 · single · operations**

Which temporary items should handback consider besides durable tools?

Synthetic training case — not a field record.

A MOP requires a specified calibrated torque tool and an insulated tool appropriate to the selected task. The torque tool’s certificate is current, but its listed range does not include the required setting. A similar unverified tool is available. At handback, one small adapter from the issued kit is unaccounted for near an open equipment cabinet.

1. Only items visible from outside the closed cabinet
2. Test leads, jumpers, caps and other introduced materials
3. Only items purchased that day
4. Only objects larger than a spare module

**Correct option(s):** 2

- Option 1: The relevant work area may include internal locations.
- Option 2: Temporary artifacts can alter the returned state.
- Option 3: Older temporary items can still remain in the work area.
- Option 4: Small objects can also matter.

**CDFOS-Q0239 · single · operations**

What would release the tool-related task hold?

Synthetic training case — not a field record.

A MOP requires a specified calibrated torque tool and an insulated tool appropriate to the selected task. The torque tool’s certificate is current, but its listed range does not include the required setting. A similar unverified tool is available. At handback, one small adapter from the issued kit is unaccounted for near an open equipment cabinet.

1. A promise to apply less force without a basis
2. A decision to omit the specified acceptance step
3. A copied certificate for a different serial number
4. A documented suitable method/tool arrangement with required approval

**Correct option(s):** 4

- Option 1: An improvised setting is not a verified substitute.
- Option 2: That would weaken the approved maintenance method.
- Option 3: The evidence must belong to the actual tool.
- Option 4: The capability gap must be resolved, not merely renamed.

**CDFOS-Q0240 · single · diagnosis**

What would close the missing-item discrepancy?

Synthetic training case — not a field record.

A MOP requires a specified calibrated torque tool and an insulated tool appropriate to the selected task. The torque tool’s certificate is current, but its listed range does not include the required setting. A similar unverified tool is available. At handback, one small adapter from the issued kit is unaccounted for near an open equipment cabinet.

1. A corrected inventory total with no physical explanation
2. The end of the contractor’s shift
3. A verified location or authorized disposition that resolves equipment exposure
4. An assumption that a small adapter cannot cause harm

**Correct option(s):** 3

- Option 1: Accounting alone does not show the object is absent from equipment.
- Option 2: Time does not resolve the object’s location.
- Option 3: The resulting state must be known and accepted.
- Option 4: Size alone does not determine its consequence.

**CDFOS-Q0241 · single · mechanism**

Why is packaging near the return path relevant?

Synthetic training case — not a field record.

After rack installation, packaging remains near a return-air path, a floor opening is temporarily uncovered and debris is visible near an intake. The contractor proposes sweeping everything toward the underfloor space. The work pack has not assigned ownership for temporary materials. No particle measurements have been taken.

1. It matters only after the room temperature alarm activates
2. It can interfere with the intended airflow and add unwanted material
3. Only rack occupancy determines airflow
4. Packaging always increases cooling capacity

**Correct option(s):** 2

- Option 1: A visible hazard can warrant action before an alarm.
- Option 2: Housekeeping can affect system function as well as appearance.
- Option 3: The complete path includes surrounding spaces and obstructions.
- Option 4: Obstruction does not provide a supported cooling benefit.

**CDFOS-Q0242 · single · operations**

What is the appropriate initial treatment of the open floor area?

Synthetic training case — not a field record.

After rack installation, packaging remains near a return-air path, a floor opening is temporarily uncovered and debris is visible near an intake. The contractor proposes sweeping everything toward the underfloor space. The work pack has not assigned ownership for temporary materials. No particle measurements have been taken.

1. Leave it until all unrelated rack work is finished
2. Assume everyone remembers it from the morning briefing
3. Hide it behind loose packaging
4. Establish the approved protection and access control

**Correct option(s):** 4

- Option 1: The present exposure remains while work continues.
- Option 2: Memory is not a reliable physical barrier.
- Option 3: That can conceal rather than control the hazard.
- Option 4: An uncovered opening needs a controlled safe arrangement.

**CDFOS-Q0243 · single · mechanism**

Why is sweeping debris under the floor inadequate?

Synthetic training case — not a field record.

After rack installation, packaging remains near a return-air path, a floor opening is temporarily uncovered and debris is visible near an intake. The contractor proposes sweeping everything toward the underfloor space. The work pack has not assigned ownership for temporary materials. No particle measurements have been taken.

1. Every cleaning action must stop permanently
2. The debris becomes harmless once unobserved
3. It relocates contamination into another operational space
4. Underfloor areas can never affect equipment

**Correct option(s):** 3

- Option 1: A suitable approved cleaning method can address the finding.
- Option 2: Visibility does not determine physical consequence.
- Option 3: Out of sight is not the same as removed or controlled.
- Option 4: They may contain airflow and infrastructure dependencies.

**CDFOS-Q0244 · single · operations**

What should determine the cleaning method?

Synthetic training case — not a field record.

After rack installation, packaging remains near a return-air path, a floor opening is temporarily uncovered and debris is visible near an intake. The contractor proposes sweeping everything toward the underfloor space. The work pack has not assigned ownership for temporary materials. No particle measurements have been taken.

1. Area/equipment requirements and the approved contamination-control procedure
2. Only which method finishes fastest
3. Only whether the debris is visible from the entrance
4. Only the contractor’s usual office-cleaning practice

**Correct option(s):** 1

- Option 1: Materials and methods must suit the installation.
- Option 2: Speed does not establish compatibility or effectiveness.
- Option 3: Hidden areas may still affect function.
- Option 4: An operational equipment area can require different controls.

**CDFOS-Q0245 · single · operations**

Can the operator claim a numerical contamination limit was exceeded?

Synthetic training case — not a field record.

After rack installation, packaging remains near a return-air path, a floor opening is temporarily uncovered and debris is visible near an intake. The contractor proposes sweeping everything toward the underfloor space. The work pack has not assigned ownership for temporary materials. No particle measurements have been taken.

1. Not from the stated visual observation alone
2. Yes; any visible particle proves every standard was exceeded
3. Yes; the number of boxes equals a particle concentration
4. No contamination concern can exist without a number

**Correct option(s):** 1

- Option 1: A numerical claim needs an appropriate measurement basis.
- Option 2: Different limits and methods require specific evidence.
- Option 3: Packaging count does not measure airborne concentration.
- Option 4: Visible debris can justify controlled cleanup and investigation.

**CDFOS-Q0246 · single · operations**

What ownership gap does the work pack reveal?

Synthetic training case — not a field record.

After rack installation, packaging remains near a return-air path, a floor opening is temporarily uncovered and debris is visible near an intake. The contractor proposes sweeping everything toward the underfloor space. The work pack has not assigned ownership for temporary materials. No particle measurements have been taken.

1. The customer alone must remove all site materials
2. The operator may never inspect contractor work
3. The rack installer automatically owns every future facility issue
4. No responsible party is assigned for temporary-material removal and verification

**Correct option(s):** 4

- Option 1: That does not follow from the stated work arrangement.
- Option 2: Acceptance review is part of operational handover.
- Option 3: Responsibility must be defined and scoped.
- Option 4: Unowned cleanup can remain incomplete at handback.

**CDFOS-Q0247 · single · operations**

What should be checked after cleanup?

Synthetic training case — not a field record.

After rack installation, packaging remains near a return-air path, a floor opening is temporarily uncovered and debris is visible near an intake. The contractor proposes sweeping everything toward the underfloor space. The work pack has not assigned ownership for temporary materials. No particle measurements have been taken.

1. Restored routes, airflow arrangement, material removal and affected equipment condition
2. Only that debris moved away from the doorway
3. Only that loose packaging is gone from the visible aisle
4. Only that the work order has a completion date

**Correct option(s):** 1

- Option 1: Acceptance should verify the intended operational state.
- Option 2: It may have been redistributed elsewhere.
- Option 3: Hidden intake debris and disturbed covers also need verification.
- Option 4: Administrative closure is not a physical observation.

**CDFOS-Q0248 · single · operations**

What should recurring debris prompt?

Synthetic training case — not a field record.

After rack installation, packaging remains near a return-air path, a floor opening is temporarily uncovered and debris is visible near an intake. The contractor proposes sweeping everything toward the underfloor space. The work pack has not assigned ownership for temporary materials. No particle measurements have been taken.

1. Investigation of its source and prevention controls
2. A permanently wider alarm deadband
3. Removal of all inspections because findings repeat
4. Automatic attribution to malicious activity

**Correct option(s):** 1

- Option 1: Repeated cleanup may treat a continuing cause only.
- Option 2: Alarm changes do not remove contamination generation.
- Option 3: That would reduce visibility of the unresolved issue.
- Option 4: Recurrence alone does not establish intent.

**CDFOS-Q0249 · single · operations**

How should temporary floor arrangements be handled?

Synthetic training case — not a field record.

After rack installation, packaging remains near a return-air path, a floor opening is temporarily uncovered and debris is visible near an intake. The contractor proposes sweeping everything toward the underfloor space. The work pack has not assigned ownership for temporary materials. No particle measurements have been taken.

1. Through the approved installation and restoration method
2. By fitting any available tile regardless of support or airflow role
3. By leaving all nearby tiles open to equalize pressure
4. By changing only the floor-plan drawing

**Correct option(s):** 1

- Option 1: Floor and airflow interfaces require controlled treatment.
- Option 2: Similar appearance does not prove suitability.
- Option 3: Unreviewed changes can alter safety and airflow.
- Option 4: A drawing edit does not restore the physical arrangement.

**CDFOS-Q0250 · single · operations**

What is a defensible handback statement?

Synthetic training case — not a field record.

After rack installation, packaging remains near a return-air path, a floor opening is temporarily uncovered and debris is visible near an intake. The contractor proposes sweeping everything toward the underfloor space. The work pack has not assigned ownership for temporary materials. No particle measurements have been taken.

1. No further debris can ever appear
2. The entire facility meets every contamination standard
3. The cleaning proves all cooling design capacities
4. The specified area checks passed under the recorded inspection scope

**Correct option(s):** 4

- Option 1: A cleanup cannot guarantee all future conditions.
- Option 2: The case contains no such comprehensive measurement.
- Option 3: Housekeeping verification is narrower than full capacity assessment.
- Option 4: It states the actual observed result and limits.

**CDFOS-Q0251 · single · mechanism**

Why is raw ticket count an unreliable event count here?

Synthetic training case — not a field record.

The CMMS lists six “pump seal leak” tickets in one month. Three are duplicate reports of one event. The remaining events occurred after work by two teams using different installation revisions. Operating hours doubled compared with the previous month. Reports record replacement parts but omit alignment observations. A proposal judges performance only by raw ticket count.

1. Several tickets describe the same underlying event
2. Duplicate reports prove no leak occurred
3. A ticket cannot contain useful maintenance evidence
4. Every CMMS ticket is always a false report

**Correct option(s):** 1

- Option 1: Administrative records need event reconciliation before frequency analysis.
- Option 2: Multiple reports can concern one genuine event.
- Option 3: Proper records support diagnosis and history.
- Option 4: The case includes real events as well as duplicates.

**CDFOS-Q0252 · single · calculation**

If three tickets describe one event and the other three are distinct, how many events are represented?

Synthetic training case — not a field record.

The CMMS lists six “pump seal leak” tickets in one month. Three are duplicate reports of one event. The remaining events occurred after work by two teams using different installation revisions. Operating hours doubled compared with the previous month. Reports record replacement parts but omit alignment observations. A proposal judges performance only by raw ticket count.

1. 6 events
2. 3 events
3. 4 events
4. 1 event

**Correct option(s):** 3

- Option 1: That counts duplicate reports as independent failures.
- Option 2: That discards the grouped event entirely.
- Option 3: One grouped event plus three separate events equals four.
- Option 4: Only three tickets are stated to share one event.

**CDFOS-Q0253 · single · operations**

What must accompany comparison with the previous month?

Synthetic training case — not a field record.

The CMMS lists six “pump seal leak” tickets in one month. Three are duplicate reports of one event. The remaining events occurred after work by two teams using different installation revisions. Operating hours doubled compared with the previous month. Reports record replacement parts but omit alignment observations. A proposal judges performance only by raw ticket count.

1. Only whether the calendar month had a familiar name
2. Only the number of staff on payroll
3. Operating exposure and comparable event definitions
4. Only the total cost of all work orders

**Correct option(s):** 3

- Option 1: Month labels do not normalize operating conditions.
- Option 2: Staff count does not substitute for equipment exposure.
- Option 3: Hours doubled, so raw counts alone can mislead.
- Option 4: Cost and failure frequency are different measures.

**CDFOS-Q0254 · single · mechanism**

Why retain the installation-procedure revision?

Synthetic training case — not a field record.

The CMMS lists six “pump seal leak” tickets in one month. Three are duplicate reports of one event. The remaining events occurred after work by two teams using different installation revisions. Operating hours doubled compared with the previous month. Reports record replacement parts but omit alignment observations. A proposal judges performance only by raw ticket count.

1. All revisions are functionally identical by definition
2. Revision records replace physical acceptance results
3. Different methods may explain a relevant difference in outcomes
4. The newest revision must automatically be the cause

**Correct option(s):** 3

- Option 1: Controlled changes may alter important steps.
- Option 2: Both method and observed result are needed.
- Option 3: Version history supports a testable causal hypothesis.
- Option 4: A version difference requires investigation, not predetermined blame.

**CDFOS-Q0255 · single · mechanism**

What does missing alignment evidence mean?

Synthetic training case — not a field record.

The CMMS lists six “pump seal leak” tickets in one month. Three are duplicate reports of one event. The remaining events occurred after work by two teams using different installation revisions. Operating hours doubled compared with the previous month. Reports record replacement parts but omit alignment observations. A proposal judges performance only by raw ticket count.

1. That alignment can never affect seals
2. That every installation was definitely misaligned
3. That the replacement part identity is irrelevant
4. That a potentially relevant condition was not established in the reports

**Correct option(s):** 4

- Option 1: The relevant mechanism must be assessed by competent personnel.
- Option 2: Absence of evidence does not establish the defect.
- Option 3: Part suitability remains another possible factor.
- Option 4: It is a gap to investigate, not proof of misalignment.

**CDFOS-Q0256 · single · operations**

Which proposal would falsely improve the metric?

Synthetic training case — not a field record.

The CMMS lists six “pump seal leak” tickets in one month. Three are duplicate reports of one event. The remaining events occurred after work by two teams using different installation revisions. Operating hours doubled compared with the previous month. Reports record replacement parts but omit alignment observations. A proposal judges performance only by raw ticket count.

1. Suppress duplicate and genuine reports without preserving event meaning
2. Record the actual work and acceptance results
3. Measure recurrence over comparable operating exposure
4. Reconcile duplicates while retaining their source links

**Correct option(s):** 1

- Option 1: Reducing recorded tickets is not necessarily reducing failures.
- Option 2: That improves the evidence chain.
- Option 3: That supports a more useful comparison.
- Option 4: That improves data quality when transparently performed.

**CDFOS-Q0257 · single · diagnosis**

What is an appropriate diagnostic next step?

Synthetic training case — not a field record.

The CMMS lists six “pump seal leak” tickets in one month. Three are duplicate reports of one event. The remaining events occurred after work by two teams using different installation revisions. Operating hours doubled compared with the previous month. Reports record replacement parts but omit alignment observations. A proposal judges performance only by raw ticket count.

1. Replace every pump without analyzing the shared pattern
2. Declare one team at fault because it has more tickets
3. Compare procedure, installation and operating evidence for the distinct events
4. Change the leak alarm label to a lower priority

**Correct option(s):** 3

- Option 1: Broad replacement may retain the cause and add exposure.
- Option 2: Duplicates and exposure can bias that comparison.
- Option 3: The case offers several plausible mechanisms to discriminate.
- Option 4: Relabeling does not address the physical mechanism.

**CDFOS-Q0258 · single · operations**

What should a revised maintenance method contain?

Synthetic training case — not a field record.

The CMMS lists six “pump seal leak” tickets in one month. Three are duplicate reports of one event. The remaining events occurred after work by two teams using different installation revisions. Operating hours doubled compared with the previous month. Reports record replacement parts but omit alignment observations. A proposal judges performance only by raw ticket count.

1. Only an instruction to work more carefully
2. Only the target of fewer tickets
3. The justified changed steps and measurable acceptance checks
4. Only a new revision number

**Correct option(s):** 3

- Option 1: A vague reminder does not define the required control.
- Option 2: A reporting target does not specify how function will improve.
- Option 3: The intervention should address the supported cause.
- Option 4: Renumbering does not change the method.

**CDFOS-Q0259 · single · operations**

How should improvement be evaluated?

Synthetic training case — not a field record.

The CMMS lists six “pump seal leak” tickets in one month. Three are duplicate reports of one event. The remaining events occurred after work by two teams using different installation revisions. Operating hours doubled compared with the previous month. Reports record replacement parts but omit alignment observations. A proposal judges performance only by raw ticket count.

1. Actual recurrence and functional results under comparable exposure
2. Only a favorable anecdote from one shift
3. Only the first successful restart
4. Only whether the new form is shorter

**Correct option(s):** 1

- Option 1: The measure should reflect service, not just record volume.
- Option 2: Anecdotes alone do not represent the stated campaign.
- Option 3: Recurrence requires observation after initial return.
- Option 4: Form length does not establish reliability.

**CDFOS-Q0260 · single · operations**

What should the final history retain?

Synthetic training case — not a field record.

The CMMS lists six “pump seal leak” tickets in one month. Three are duplicate reports of one event. The remaining events occurred after work by two teams using different installation revisions. Operating hours doubled compared with the previous month. Reports record replacement parts but omit alignment observations. A proposal judges performance only by raw ticket count.

1. Only the final event count
2. Only the latest replacement invoice
3. Only tickets supporting the selected hypothesis
4. Linked source tickets, reconciled events, method versions and dispositions

**Correct option(s):** 4

- Option 1: The count cannot explain grouping or cause analysis.
- Option 2: Procurement is one element, not the complete maintenance history.
- Option 3: Selective retention biases the conclusion.
- Option 4: This preserves both original reports and the engineering interpretation.

#### Recall

**Selecting a maintenance strategy from a failure mechanism — Synthetic training case — not a field record.

Fan group F has a manufacturer-required inspection interval. A vibration trend rose after a mounting change, while run hours are low. A separate room-temperature sensor has shown intermittent mapping errors with no physical drift. A proposal replaces every fan monthly and recalibrates the sensor weekly without investigating either cause.**

Retain mandatory manufacturer work, but investigate the changed mounting and the digital mapping fault. Frequent replacement or calibration can add effort without addressing the observed mechanisms. Define a task from required function, credible failure mode, relevant evidence and acceptance rather than treating all maintenance as calendar replacement.

**MOP identity, hold points and recovery window — Synthetic training case — not a field record.

A MOP names pump P-14, but its drawing points to P-41. Step 6 says “continue after valve feedback changes,” with no expected state or timeout. The window ends at 04:00; supported recovery takes 18 minutes and final checks take 12 minutes. A precheck shows the standby pump is unavailable. The required service must remain supported.**

Hold before execution: identity, step acceptance and current capacity are unresolved. The latest recovery decision without contingency is 03:30. The unavailable standby changes the work basis. A valid MOP needs exact asset identity, expected feedback, timeout/abort logic and a supported recovery route that fits the window.

**Service report with a missing functional test — Synthetic training case — not a field record.

A contractor report states “sensor replaced; system healthy.” It identifies the new sensor serial but contains no as-found readings, source range, BMS point check or alarm test. A local display reads plausibly; BMS still associates the point with the neighboring unit. The work order is marked ready for closure.**

The report establishes a replacement identity, not complete service acceptance. Preserve the missing-evidence limitation, verify the actual source/range and correct the approved point association. Test display, alarm and retained data against the required function. Do not invent as-found values; assess whether other retained evidence can support the historical diagnosis.

**Spare readiness and replenishment arithmetic — Synthetic training case — not a field record.

A synthetic filter stock uses a stable planning estimate of 2 units/day. Confirmed replenishment lead time is 10 days and the approved safety stock is 8 units. There are 25 units physically present, 6 reserved for an approved job, and 4 quarantined for damage. An order for 20 is confirmed but not yet received. The policy uses ready unallocated stock for immediate-task readiness.**

The illustrative reorder point is 2×10+8 = 28 units under the stated planning assumptions. Ready unallocated stock is 25−6−4 = 15. Confirmed incoming stock affects replenishment planning but is not available for immediate issue. Investigate whether stable average demand remains appropriate before treating the formula as universal for critical intermittent spares.

**Tool suitability and missing-item accountability — Synthetic training case — not a field record.

A MOP requires a specified calibrated torque tool and an insulated tool appropriate to the selected task. The torque tool’s certificate is current, but its listed range does not include the required setting. A similar unverified tool is available. At handback, one small adapter from the issued kit is unaccounted for near an open equipment cabinet.**

A current certificate does not establish suitability outside its range, and visual similarity does not approve a substitute. Hold the affected task pending a supported tool decision. The missing adapter requires work-area accountability and an authorized assessment before return to service, because an unexplained object may remain in the equipment.

**Housekeeping as an airflow and access control — Synthetic training case — not a field record.

After rack installation, packaging remains near a return-air path, a floor opening is temporarily uncovered and debris is visible near an intake. The contractor proposes sweeping everything toward the underfloor space. The work pack has not assigned ownership for temporary materials. No particle measurements have been taken.**

The findings affect airflow, access and contamination control, not just appearance. Protect the opening and routes through the approved method, use the area’s permitted cleaning process and remove material to the correct destination. Do not redistribute debris into a hidden airflow space or claim a contamination limit was exceeded without measurement. Assign removal and verification ownership.

**Recurring maintenance and causal work history — Synthetic training case — not a field record.

The CMMS lists six “pump seal leak” tickets in one month. Three are duplicate reports of one event. The remaining events occurred after work by two teams using different installation revisions. Operating hours doubled compared with the previous month. Reports record replacement parts but omit alignment observations. A proposal judges performance only by raw ticket count.**

Reconcile event identity before calculating failure frequency. Compare actual events with operating exposure and relevant conditions. Preserve procedure revisions and missing alignment evidence as hypotheses to investigate. A corrective plan should test the failure mechanism and verify restored function and recurrence under comparable observation, not simply reduce ticket entry.

#### References

- [EPI CDFOS public syllabus](https://www.epi-ap.com/services/1/3/136)
- [HSE maintenance guidance — jurisdiction-specific reference](https://www.hse.gov.uk/work-equipment-machinery/maintenance.htm)
- [HSE permit-to-work systems — supporting reference](https://www.hse.gov.uk/comah/sragtech/techmeaspermit.htm)
- [NIST metrological traceability policy](https://www.nist.gov/calibrations/traceability)

## CDFOS-M05 — Shift operations, service control and equipment lifecycle

### CDFOS-L05 — Shift operations, service control and equipment lifecycle

Estimated study time: 120 minutes before independent work. Prerequisite chapters: CDFOS-L04

## The operating baseline must remain usable between shifts

Data-center operations is the coordinated execution of recurring duties and controlled changes that keep the required service available. The operating baseline includes actual equipment state, approved configuration, current load and commitments, active alarms, work in progress, restrictions, temporary measures and recovery resources. A drawing or database entry is useful only when reconciled with the installation and current work. The next shift must be able to understand the present state without relying on the outgoing operator’s memory.

A shift handover should prioritize consequence and required action. Identify degraded services, unavailable redundancy, active permits and isolations, temporary overrides, unusual trends, pending supplier visits, expected deliveries, open incidents and decisions due during the next shift. For each significant item state what happened, what is known, what remains uncertain, what action is required, who owns it and when escalation or expiry occurs. A long unstructured log can conceal the most urgent item as easily as an empty log can omit it.

Use both a controlled written record and the communication method appropriate to the site. The receiving person should confirm understanding of consequential items and clarify contradictions before accepting responsibility. A read-back can expose an incorrect asset or deadline. A signature records handover participation but does not prove understanding by itself. If a critical fact remains unresolved, preserve it explicitly and use the escalation route rather than allowing the ambiguity to disappear at the shift boundary.

## Walk-around duties are deliberate observations

A walk-around inspection seeks conditions that matter to safe and reliable operation. Examples include unexpected noise or leakage, obstructed airflow or access, incorrect local mode, abnormal indicators, damaged cabling, unsecured doors and changes inconsistent with records. The exact checks follow the site’s approved route, equipment and competence boundaries. An operator should not open hazardous enclosures or manipulate plant merely to complete a generic checklist.

Compare observations with the expected condition and recent history. A stable displayed temperature can coexist with a local leak or a failed sensor. A pump sound may be normal for one mode and abnormal for another. Record the asset, location, time, mode and observation, then route it to the appropriate response. If a checkpoint cannot be inspected, record why and arrange the approved alternative or escalation. A tick copied from the previous shift creates false assurance and weakens later fault reconstruction.

Walk-around and remote monitoring complement each other. Remote systems can provide trends and events across many assets, while physical observation can reveal conditions outside the instrumentation. Neither is universally superior. Reconcile contradictions through a bounded diagnosis and appropriate specialist involvement. Do not calibrate a sensor merely because it disagrees with an unverified handheld reading, or dismiss a physical observation solely because BMS is green.

## Service management coordinates restoration and prevention

An incident concerns an interruption or degradation requiring restoration of the defined service. A service request may ask for a standard authorized action without a fault. A problem investigation seeks the underlying cause or recurring mechanism. A change modifies the controlled environment. These records can be linked, but they have different purposes and acceptance conditions. Closing an incident after service is restored does not necessarily close the associated root-cause work; leaving the problem open does not mean the restored service is still unavailable.

Classify priority using the site’s defined impact and urgency, including safety, affected service, remaining resilience and time sensitivity. The loudest requester is not automatically the highest priority. An apparently small facility defect can be urgent if it removes the last supported path or has a rapidly worsening condition. Conversely, a low-impact request should not bypass controls merely because it is labeled urgent. Preserve the priority rationale and revisit it when evidence changes.

Escalation should reach someone able to make the needed decision or perform the needed work. Functional escalation adds expertise; management escalation addresses authority, coordination or commitment. A ticket can move between teams without progress if each transfer lacks the diagnostic evidence and a clear question. Include the current service impact, observations, actions already taken, constraints and requested decision. Keep the operational owner visible even when a supplier performs the repair.

## Release and change are controlled transitions

A release packages approved changes and supporting artifacts for introduction into operation. Its content can include configuration, software, procedures, training, documentation and recovery material. The package should identify compatible versions, dependencies, test evidence, known limitations, implementation order and rollback or recovery. A change approval is a decision about the proposed work; it does not prove the released artifact matches the approved one. Verify artifact identity and the actual target before execution.

Preproduction testing should represent the relevant mechanism and disclose its fidelity. A successful test on an isolated software instance cannot establish live electrical transfer behavior. Use staged deployment or a canary when appropriate, with criteria for continuation and stop. Coordinate releases with facility work so that two individually acceptable changes do not remove the same remaining capability. When results differ from expectation, preserve state and evidence before selecting the supported recovery action.

After release, verify the intended service, permissions, monitoring, backup and operating documentation. An application can appear functional while its alarms point to an obsolete destination or its backup no longer runs. Handover should include changed procedures and known issues with owners. Emergency changes still require the site’s expedited authority and later reconciliation; emergency status is not permission to leave undocumented permanent drift.

## Configuration management connects intent to installation

A configuration item is something controlled because its identity, state or relationship matters to the service. This may include a physical asset, controller project, network configuration, application version, procedure or dependency relationship. Define the level of detail needed for useful decisions rather than collecting every possible attribute. Stable identifiers and relationship rules make records usable across BMS, DCIM, CMMS, inventories and evidence repositories.

Keep approved state, discovered state and observed field state distinct until reconciled. Automatic discovery can reveal a device, but does not establish that it is authorized or correctly installed. A technician’s emergency change may be justified yet absent from the central baseline. Blindly overwriting every difference can remove a needed correction; blindly accepting every discovered value can legitimize unauthorized drift. Investigate the reason and update the approved baseline through the correct authority.

Relationship accuracy is as important as asset attributes. A server connected to a different PDU or switch than recorded can invalidate a maintenance impact assessment. A point mapped to the wrong unit can direct the wrong response. Reconcile significant relationships using physical or appropriately trusted technical evidence. Record who verified the change, when, by what method and which dependent documents or systems were updated.

## Floor and equipment lifecycle management

Floor management coordinates space, access, support, connectivity and environmental constraints for installation and removal. Free rack units do not prove that a placement is acceptable. Check the approved rack and floor load, service clearances, equipment dimensions, airflow direction, cable routes, power/network connections, thermal support and maintenance access. Structural calculations and building changes require the responsible D1 specialist; the operator must obtain and respect those constraints rather than claim to certify them.

A move/add/change should reserve the relevant capacity and identify the actual execution and acceptance steps. A reservation should have an owner and review/expiry rule so abandoned projects do not indefinitely consume apparent capacity. Verify installed state after work and release only the capacity genuinely freed. Removing one component can leave shared connections, labels, permissions or records that need deliberate treatment.

The equipment lifecycle runs from justified need through specification, procurement, receiving, installation, commissioning, operation, maintenance, change and retirement. Each transition has evidence and authority. Procurement acceptance does not replace commissioning. A device removed from a rack is not automatically ready for resale; ownership, data/media treatment, credential removal, asset status and destination must be resolved. Retain required records without leaving active access or a false operational inventory entry.

The independent operations campaign uses these mechanisms together. Carry a degraded condition across a shift, perform a bounded inspection, classify an incident/request/problem, assess a release, reconcile configuration and accept or hold a placement/retirement task. Produce a record that another operator can use to reach the same justified decisions. Actual physical installation, maintenance and recovery remain separate practical gates, and the evidence must state what was executed, simulated or reviewed analytically.

#### Worked demonstrations

**Handover with an expiring override**

Synthetic training case — not a field record.

At 18:00, cooling unit C2 remains in an approved temporary manual mode that expires at 18:30. Its automatic-sequence retest has not occurred. A supplier is expected at 19:00. The outgoing log says “C2 stable; vendor coming.” The incoming operator assumes normal automatic redundancy is available.

**Reasoning:** The log omits the temporary mode, expiry, missing test and actual resilience state. Correct the handover, obtain the required decision before expiry and distinguish the supplier’s expected arrival from accepted restoration. The receiving operator should confirm the critical state and action rather than infer it from “stable.”

**Walk-around contradicts remote status**

Synthetic training case — not a field record.

BMS shows a cooling unit as available. During an authorized external inspection, the operator sees a local selector in Manual and a small leak beneath the unit. The BMS availability point has not changed for two days, although its screen refreshes. The inspection route does not authorize opening energized panels.

**Reasoning:** Record the local mode, leak and freshness concern. Escalate through the equipment and safety procedures without opening unauthorized enclosures. Trace what “available” actually represents and whether the source is current. A refreshed display is not evidence of newly acquired condition, and the physical findings do not by themselves identify the leak’s cause.

**Incident, request, problem and change records**

Synthetic training case — not a field record.

A customer reports lost monitoring for one rack. Service is restored by an approved temporary collector restart. The same failure occurred twice this month. A proposed permanent driver update has not been tested. Another customer asks for a routine authorized access report. The team wants to close every related record once monitoring returns.

**Reasoning:** The monitoring interruption is an incident; the recurring cause can remain a problem investigation after restoration. The driver update is a proposed change requiring its own evidence and authority. The routine report is a service request. Link records while preserving their different completion conditions.

**Release package differs from approved artifact**

Synthetic training case — not a field record.

Change CR7 approves collector package hash A for platform version 4. The staging test used version 4, but the production host is version 3. The installer presents package hash B. A canary login succeeds, yet alarm forwarding and backup jobs fail. A database migration in the package has no tested reverse path.

**Reasoning:** The proposed execution differs from the approved and tested basis. Hold broader deployment, reconcile package identity and platform support, and assess the database recovery method. A login test does not close alarm or backup requirements. Preserve actual canary state and follow a supported decision rather than assuming a configuration copy reverses the migration.

**Configuration drift after an emergency correction**

Synthetic training case — not a field record.

Discovery finds switch SW9 with a management address absent from the CMDB. A local emergency record authorizes a temporary address change for recovery, but the central baseline was not updated. The temporary permission expires tomorrow. Automation proposes overwriting SW9 immediately with last month’s baseline. A rack-to-PDU relationship in DCIM also conflicts with the inspected connection.

**Reasoning:** Investigate and reconcile both differences. Observed state is not automatically authorized, but the local emergency record may explain this one. Confirm authority, expiry and current service dependencies before rollback or baseline update. Reconcile the physical power relationship independently because configuration items include dependencies, not just device attributes.

**Placement with space, mass and airflow constraints**

Synthetic training case — not a field record.

Rack R has 42 usable rack units: 26 occupied and 8 reserved for an approved project. A proposed device requires 10 units. The responsible structural specialist’s approved additional mass allowance is 250 kg; the proposal adds 280 kg. Its airflow direction also conflicts with the approved row arrangement. Network ports are available.

**Reasoning:** The proposal fails more than one independent placement constraint: only eight unallocated rack units remain, the approved mass allowance is exceeded and airflow compatibility is unresolved. Available network ports do not compensate. Hold placement and obtain a supported revised plan; the operator does not redesign or certify the structure.

**Equipment retirement and release of dependencies**

Synthetic training case — not a field record.

Removal work names server A, but the rack technician identifies serial B at the labeled position. The owner’s disposal authorization covers A only. The server contains storage media, a BMC account and active monitoring/backup records. DCIM proposes releasing 5 kW of reserved capacity immediately, although no physical removal or load verification has occurred.

**Reasoning:** Hold the identity mismatch before disconnecting or releasing the asset. Reconcile ownership and the approved item, then follow supported data/media disposition, access revocation and physical removal. Update monitoring, backup, inventory and capacity only against the actual accepted state; record-retirement is not proof that the physical resource is free.

#### Guided practice

Carry a temporary degraded state across a shift, classify linked service records, review a mismatched release and decide on a constrained placement and retirement.

**Hint:** Use the actual accepted state and distinguish a record transition from physical or functional completion.

**Worked solution:** Preserve modes, expiries and owners in handover; record inspection limits; separate incident restoration from cause/change completion; verify released artifacts and supporting services; reconcile discovered drift through authority; assess all placement constraints; retire equipment only after identity, data, access and capacity obligations are resolved.

#### Independent task

Environment: analytical

Run a synthetic operations campaign with independently reviewed decisions and a usable next-shift handover.

**Packaged starter material**

- course_labs/CDFOS/README.md
- course_labs/CDFOS/fixture.json
- course_labs/CDFOS/assessment_template.md
- course_labs/CDFOS/lab.py
- course_labs/CDFOS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- Exception-focused handover
- Walk-around findings and escalation
- Linked incident/problem/request/change records
- Release/configuration disposition
- Placement and retirement acceptance packs

**Acceptance criteria**

- Current state and unresolved conditions remain explicit.
- No workflow status substitutes for functional evidence.
- The receiving operator can reproduce the required decisions.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer. The bundled calculator was executed against supplied synthetic fixtures; its numerical checks do not grade physical work or professional authorization.

#### Chapter practice

**CDFOS-Q0261 · single · operations**

What is the most consequential misunderstanding?

Synthetic training case — not a field record.

At 18:00, cooling unit C2 remains in an approved temporary manual mode that expires at 18:30. Its automatic-sequence retest has not occurred. A supplier is expected at 19:00. The outgoing log says “C2 stable; vendor coming.” The incoming operator assumes normal automatic redundancy is available.

1. The incoming operator assumes automatic redundancy is available
2. The outgoing shift ends at eighteen hundred
3. The log uses the unit identifier C2
4. The supplier may arrive after ordinary office hours

**Correct option(s):** 1

- Option 1: C2 remains in temporary manual mode without its required retest.
- Option 2: Shift time itself is not the defect.
- Option 3: The identifier is useful when correctly tied to state.
- Option 4: The case’s immediate control deadline is earlier.

**CDFOS-Q0262 · single · operations**

Which deadline requires an action before the supplier arrives?

Synthetic training case — not a field record.

At 18:00, cooling unit C2 remains in an approved temporary manual mode that expires at 18:30. Its automatic-sequence retest has not occurred. A supplier is expected at 19:00. The outgoing log says “C2 stable; vendor coming.” The incoming operator assumes normal automatic redundancy is available.

1. The next monthly report date
2. The supplier arrival at 19:00 only
3. The original installation anniversary
4. The override expiry at 18:30

**Correct option(s):** 4

- Option 1: That cannot resolve the immediate operating condition.
- Option 2: Waiting would pass the temporary-mode expiry.
- Option 3: It has no stated role in the override.
- Option 4: The supplier is not expected until nineteen hundred.

**CDFOS-Q0263 · single · operations**

What should replace the word “stable” in the critical handover item?

Synthetic training case — not a field record.

At 18:00, cooling unit C2 remains in an approved temporary manual mode that expires at 18:30. Its automatic-sequence retest has not occurred. A supplier is expected at 19:00. The outgoing log says “C2 stable; vendor coming.” The incoming operator assumes normal automatic redundancy is available.

1. Actual mode, function, restrictions, missing tests and next decision
2. Only the number of alarms acknowledged
3. Only the supplier’s name
4. A longer general assurance of reliability

**Correct option(s):** 1

- Option 1: These facts support the receiving operator’s action.
- Option 2: Acknowledgment count does not establish automatic readiness.
- Option 3: Contact identity does not define present capability.
- Option 4: Reassurance still omits the consequential state.

**CDFOS-Q0264 · single · operations**

What would demonstrate receiving-shift understanding?

Synthetic training case — not a field record.

At 18:00, cooling unit C2 remains in an approved temporary manual mode that expires at 18:30. Its automatic-sequence retest has not occurred. A supplier is expected at 19:00. The outgoing log says “C2 stable; vendor coming.” The incoming operator assumes normal automatic redundancy is available.

1. Opening the dashboard home page
2. A read-back of the temporary state, expiry and required escalation
3. Copying yesterday’s normal-state entry
4. A signature without discussing the item

**Correct option(s):** 2

- Option 1: Access does not prove interpretation of the exception.
- Option 2: It tests whether the important conditions were understood.
- Option 3: That would preserve an incorrect assumption.
- Option 4: Participation alone does not establish comprehension.

**CDFOS-Q0265 · single · mechanism**

What does the supplier appointment establish?

Synthetic training case — not a field record.

At 18:00, cooling unit C2 remains in an approved temporary manual mode that expires at 18:30. Its automatic-sequence retest has not occurred. A supplier is expected at 19:00. The outgoing log says “C2 stable; vendor coming.” The incoming operator assumes normal automatic redundancy is available.

1. That C2 will be automatically restored at nineteen hundred
2. That the facility can ignore current restrictions
3. That the override may remain indefinitely
4. A planned support action, not completed functional restoration

**Correct option(s):** 4

- Option 1: The work and retest have not occurred.
- Option 2: A future action does not change present state.
- Option 3: The existing expiry still applies.
- Option 4: Arrival and repair acceptance are separate milestones.

**CDFOS-Q0266 · single · operations**

What should happen if the override cannot be removed by expiry?

Synthetic training case — not a field record.

At 18:00, cooling unit C2 remains in an approved temporary manual mode that expires at 18:30. Its automatic-sequence retest has not occurred. A supplier is expected at 19:00. The outgoing log says “C2 stable; vendor coming.” The incoming operator assumes normal automatic redundancy is available.

1. Transfer the unresolved item without an owner
2. Mark the retest passed to close the item
3. Let it expire on paper while leaving it active unnoticed
4. Obtain the defined authorized decision and retain the restricted state explicitly

**Correct option(s):** 4

- Option 1: Ownership is needed for timely action.
- Option 2: No test evidence supports that claim.
- Option 3: Records and actual configuration would diverge.
- Option 4: Extension or another action must follow the site process.

**CDFOS-Q0267 · single · operations**

Which record should be linked to the handover?

Synthetic training case — not a field record.

At 18:00, cooling unit C2 remains in an approved temporary manual mode that expires at 18:30. Its automatic-sequence retest has not occurred. A supplier is expected at 19:00. The outgoing log says “C2 stable; vendor coming.” The incoming operator assumes normal automatic redundancy is available.

1. Only the old normal-sequence screenshot
2. Only the unit’s procurement receipt
3. Only the supplier’s marketing brochure
4. The override/change authorization and its current conditions

**Correct option(s):** 4

- Option 1: The current unit state differs from that baseline.
- Option 2: Purchase history does not authorize the temporary mode.
- Option 3: Advertised capability does not describe this operating exception.
- Option 4: It explains scope, authority and expiry.

**CDFOS-Q0268 · single · operations**

What should verify return to automatic service?

Synthetic training case — not a field record.

At 18:00, cooling unit C2 remains in an approved temporary manual mode that expires at 18:30. Its automatic-sequence retest has not occurred. A supplier is expected at 19:00. The outgoing log says “C2 stable; vendor coming.” The incoming operator assumes normal automatic redundancy is available.

1. Only the passage of the expiry time
2. Only a green communication icon
3. Only the supplier’s arrival signature
4. The required sequence, feedback, alarms and actual mode checks

**Correct option(s):** 4

- Option 1: Time does not execute or verify restoration.
- Option 2: Communication can work while automatic logic remains impaired.
- Option 3: Presence is not a functional test.
- Option 4: Removal of a manual selection alone may not prove function.

**CDFOS-Q0269 · single · operations**

How should unresolved uncertainty cross the shift boundary?

Synthetic training case — not a field record.

At 18:00, cooling unit C2 remains in an approved temporary manual mode that expires at 18:30. Its automatic-sequence retest has not occurred. A supplier is expected at 19:00. The outgoing log says “C2 stable; vendor coming.” The incoming operator assumes normal automatic redundancy is available.

1. Convert it to a normal-state entry for simplicity
2. Explicitly with owner, consequence and next evidence/action
3. Remove it until a complete root cause is known
4. Leave it in an outgoing operator’s private notes

**Correct option(s):** 2

- Option 1: That creates false assurance.
- Option 2: The next shift must not inherit an unstated assumption.
- Option 3: Operational decisions still require the current uncertainty.
- Option 4: The receiving team may not have usable access.

**CDFOS-Q0270 · single · operations**

What durable handover improvement follows?

Synthetic training case — not a field record.

At 18:00, cooling unit C2 remains in an approved temporary manual mode that expires at 18:30. Its automatic-sequence retest has not occurred. A supplier is expected at 19:00. The outgoing log says “C2 stable; vendor coming.” The incoming operator assumes normal automatic redundancy is available.

1. Stop recording supplier actions
2. Delay all handovers until every defect is repaired
3. A structured exception field for mode, expiry, capability and owner
4. Require every entry to use the word stable

**Correct option(s):** 3

- Option 1: Planned actions remain useful when distinguished from completion.
- Option 2: Operations often must transfer a controlled degraded state.
- Option 3: It targets the omissions that caused the misunderstanding.
- Option 4: That repeats the ambiguity.

**CDFOS-Q0271 · single · mechanism**

What does the Manual selector challenge?

Synthetic training case — not a field record.

BMS shows a cooling unit as available. During an authorized external inspection, the operator sees a local selector in Manual and a small leak beneath the unit. The BMS availability point has not changed for two days, although its screen refreshes. The inspection route does not authorize opening energized panels.

1. The operator’s right to record an external observation
2. The unit’s asset identity necessarily being false
3. Every BMS point being maliciously altered
4. The assumption that the unit will participate in automatic operation

**Correct option(s):** 4

- Option 1: The inspection is authorized within its boundary.
- Option 2: Mode and identity are separate facts.
- Option 3: The case supports a narrower inconsistency.
- Option 4: Availability semantics must match the actual operating role.

**CDFOS-Q0272 · single · operations**

What should the operator do about the leak?

Synthetic training case — not a field record.

BMS shows a cooling unit as available. During an authorized external inspection, the operator sees a local selector in Manual and a small leak beneath the unit. The BMS availability point has not changed for two days, although its screen refreshes. The inspection route does not authorize opening energized panels.

1. Open the energized panel to find the source
2. Assume it is harmless because BMS is green
3. Record and escalate it through the approved equipment/safety route
4. Declare the exact failed component without further evidence

**Correct option(s):** 3

- Option 1: The route expressly does not authorize that action.
- Option 2: The remote status does not resolve the physical finding.
- Option 3: The observation may require qualified assessment.
- Option 4: Several causes may produce a visible leak.

**CDFOS-Q0273 · single · mechanism**

Why is the screen refresh insufficient evidence of freshness?

Synthetic training case — not a field record.

BMS shows a cooling unit as available. During an authorized external inspection, the operator sees a local selector in Manual and a small leak beneath the unit. The BMS availability point has not changed for two days, although its screen refreshes. The inspection route does not authorize opening energized panels.

1. All unchanged values are necessarily invalid
2. A timestamp can never help diagnose data quality
3. Rendering can update while the underlying source value remains stale
4. A refreshed screen must always contain new sensor data

**Correct option(s):** 3

- Option 1: A steady physical condition can also remain unchanged.
- Option 2: Source and receipt times are useful when interpreted correctly.
- Option 3: Display activity and acquisition are different stages.
- Option 4: The case gives reason to test that assumption.

**CDFOS-Q0274 · single · operations**

Which investigation best clarifies “available”?

Synthetic training case — not a field record.

BMS shows a cooling unit as available. During an authorized external inspection, the operator sees a local selector in Manual and a small leak beneath the unit. The BMS availability point has not changed for two days, although its screen refreshes. The inspection route does not authorize opening energized panels.

1. Trace the point definition, source, quality and actual mode relationship
2. Refresh the dashboard faster while retaining the existing point definition
3. Reboot all facility controllers immediately
4. Increase every alarm threshold

**Correct option(s):** 1

- Option 1: The displayed label may not represent the required readiness.
- Option 2: A faster refresh repeats the same potentially misleading semantics; trace the source and mode relationship.
- Option 3: A broad restart is not justified by the bounded evidence.
- Option 4: That does not establish the point’s meaning.

**CDFOS-Q0275 · single · operations**

What should the inspection record include?

Synthetic training case — not a field record.

BMS shows a cooling unit as available. During an authorized external inspection, the operator sees a local selector in Manual and a small leak beneath the unit. The BMS availability point has not changed for two days, although its screen refreshes. The inspection route does not authorize opening energized panels.

1. Only the operator’s guess at the repair cost
2. Asset, location, time, mode, observed condition and restrictions
3. Only a pass/fail tick
4. Only the BMS screenshot

**Correct option(s):** 2

- Option 1: Cost speculation does not document the condition.
- Option 2: These support a scoped investigation and handover.
- Option 3: That omits the important conflicting observations.
- Option 4: The physical finding is independent material evidence.

**CDFOS-Q0276 · single · operations**

Which action respects the competence boundary?

Synthetic training case — not a field record.

BMS shows a cooling unit as available. During an authorized external inspection, the operator sees a local selector in Manual and a small leak beneath the unit. The BMS availability point has not changed for two days, although its screen refreshes. The inspection route does not authorize opening energized panels.

1. Proceed because the operator has watched a repair video
2. Request the authorized specialist assessment while preserving a safe area
3. Ask an unbriefed visitor to inspect inside the panel
4. Disable the leak alarm until a specialist arrives

**Correct option(s):** 2

- Option 1: Watching does not establish authorized competence.
- Option 2: Observation does not grant intrusive-work authority.
- Option 3: That expands exposure without the required controls.
- Option 4: No evidence authorizes removing detection.

**CDFOS-Q0277 · single · diagnosis**

What would discriminate stale data from a genuinely steady point?

Synthetic training case — not a field record.

BMS shows a cooling unit as available. During an authorized external inspection, the operator sees a local selector in Manual and a small leak beneath the unit. The BMS availability point has not changed for two days, although its screen refreshes. The inspection route does not authorize opening energized panels.

1. Only observing that the displayed value is unchanged
2. Only counting how many days the value is identical
3. A supported source-quality/time check or controlled known state observation
4. Only repeatedly refreshing the browser

**Correct option(s):** 3

- Option 1: A constant value may reflect either steady process conditions or a frozen data path.
- Option 2: Duration alone does not distinguish steady from stale.
- Option 3: The test should establish whether new source information is acquired.
- Option 4: That repeats the rendering stage.

**CDFOS-Q0278 · single · operations**

What should an inaccessible checkpoint be recorded as?

Synthetic training case — not a field record.

BMS shows a cooling unit as available. During an authorized external inspection, the operator sees a local selector in Manual and a small leak beneath the unit. The BMS availability point has not changed for two days, although its screen refreshes. The inspection route does not authorize opening energized panels.

1. Failed equipment automatically
2. Not inspected, with the reason and required follow-up
3. Removed from all future routes without review
4. Passed if the previous shift found it normal

**Correct option(s):** 2

- Option 1: Access limitation does not uniquely prove equipment failure.
- Option 2: The record must not claim an observation that did not occur.
- Option 3: Coverage changes need an authorized decision.
- Option 4: Earlier evidence does not establish current condition.

**CDFOS-Q0279 · single · operations**

How should remote and physical findings be reconciled?

Synthetic training case — not a field record.

BMS shows a cooling unit as available. During an authorized external inspection, the operator sees a local selector in Manual and a small leak beneath the unit. The BMS availability point has not changed for two days, although its screen refreshes. The inspection route does not authorize opening energized panels.

1. Always calibrate every sensor after any disagreement
2. Always trust the dashboard over the field observation
3. Delete one source to make the report consistent
4. Use each source’s scope and a bounded evidence-based diagnosis

**Correct option(s):** 4

- Option 1: The disagreement may be mode, mapping or observation error.
- Option 2: A dashboard may be stale or semantically wrong.
- Option 3: Apparent consistency is not a substitute for investigation.
- Option 4: Neither source universally overrides the other.

**CDFOS-Q0280 · single · operations**

What closes this walk-around finding?

Synthetic training case — not a field record.

BMS shows a cooling unit as available. During an authorized external inspection, the operator sees a local selector in Manual and a small leak beneath the unit. The BMS availability point has not changed for two days, although its screen refreshes. The inspection route does not authorize opening energized panels.

1. Only restarting the browser
2. Accepted disposition and verification of the affected physical and data functions
3. Only clearing the operator’s note
4. Only a supplier acknowledgment email

**Correct option(s):** 2

- Option 1: That does not establish the source or physical condition.
- Option 2: Both the leak/mode concern and misleading status need resolution.
- Option 3: Record removal does not restore function.
- Option 4: Acknowledgment is not completed corrective work.

**CDFOS-Q0281 · single · recovery**

Which record primarily tracks the monitoring interruption and restoration?

Synthetic training case — not a field record.

A customer reports lost monitoring for one rack. Service is restored by an approved temporary collector restart. The same failure occurred twice this month. A proposed permanent driver update has not been tested. Another customer asks for a routine authorized access report. The team wants to close every related record once monitoring returns.

1. A project closure record only
2. A visitor record
3. A procurement record only
4. An incident record

**Correct option(s):** 4

- Option 1: The case is an operational interruption, not completed project acceptance.
- Option 2: Physical presence is not the stated service failure.
- Option 3: Purchasing does not manage the current interruption.
- Option 4: Its immediate purpose is restoring the defined degraded service.

**CDFOS-Q0282 · single · recovery**

What may remain open after monitoring is restored?

Synthetic training case — not a field record.

A customer reports lost monitoring for one rack. Service is restored by an approved temporary collector restart. The same failure occurred twice this month. A proposed permanent driver update has not been tested. Another customer asks for a routine authorized access report. The team wants to close every related record once monitoring returns.

1. The investigation into the recurring underlying cause
2. Only the temporary restart’s calendar invitation
3. The assertion that service is still unavailable regardless of evidence
4. Every routine request from every customer

**Correct option(s):** 1

- Option 1: Restoration and cause elimination are different outcomes.
- Option 2: That does not represent the recurring technical question.
- Option 3: The restored service should be recorded accurately.
- Option 4: Unrelated records have independent completion conditions.

**CDFOS-Q0283 · single · operations**

How should the proposed driver update be handled?

Synthetic training case — not a field record.

A customer reports lost monitoring for one rack. Service is restored by an approved temporary collector restart. The same failure occurred twice this month. A proposed permanent driver update has not been tested. Another customer asks for a routine authorized access report. The team wants to close every related record once monitoring returns.

1. Apply it automatically because the incident recurred
2. Classify it as a visitor exception
3. Treat it as already completed when the incident closes
4. As a controlled change with compatibility, testing and recovery evidence

**Correct option(s):** 4

- Option 1: Recurrence does not waive change assessment.
- Option 2: That does not govern software modification.
- Option 3: The update has not been executed or tested.
- Option 4: A plausible permanent fix is not yet an accepted deployment.

**CDFOS-Q0284 · single · operations**

What is the routine access-report request?

Synthetic training case — not a field record.

A customer reports lost monitoring for one rack. Service is restored by an approved temporary collector restart. The same failure occurred twice this month. A proposed permanent driver update has not been tested. Another customer asks for a routine authorized access report. The team wants to close every related record once monitoring returns.

1. A confirmed security incident
2. A mandatory emergency change
3. A physical maintenance task
4. A service request under the defined authorized process

**Correct option(s):** 4

- Option 1: No misuse or service failure is stated.
- Option 2: Producing an approved report need not modify the environment.
- Option 3: The request concerns information delivery.
- Option 4: It asks for a standard service rather than reporting a fault.

**CDFOS-Q0285 · single · operations**

What should link the temporary workaround to the permanent investigation?

Synthetic training case — not a field record.

A customer reports lost monitoring for one rack. Service is restored by an approved temporary collector restart. The same failure occurred twice this month. A proposed permanent driver update has not been tested. Another customer asks for a routine authorized access report. The team wants to close every related record once monitoring returns.

1. Only matching incident titles without explicit record relationships
2. Record references, observed effects, limitations and follow-up ownership
3. Only the customer’s billing code
4. Only a shared informal nickname

**Correct option(s):** 2

- Option 1: Similar wording does not establish the controlled workaround/problem dependency.
- Option 2: This preserves why restoration occurred and what remains unresolved.
- Option 3: Billing identity does not describe the technical relationship.
- Option 4: That may not provide durable traceability.

**CDFOS-Q0286 · single · operations**

What should determine incident priority?

Synthetic training case — not a field record.

A customer reports lost monitoring for one rack. Service is restored by an approved temporary collector restart. The same failure occurred twice this month. A proposed permanent driver update has not been tested. Another customer asks for a routine authorized access report. The team wants to close every related record once monitoring returns.

1. Always handle the oldest open ticket first, regardless of current consequence
2. The supplier’s preference for a convenient appointment
3. Defined impact, urgency, remaining resilience and relevant safety consequence
4. The requester who sends the most messages

**Correct option(s):** 3

- Option 1: Queue age alone can give a low-impact issue precedence over loss of resilience or an urgent hazard.
- Option 2: Convenience does not govern operational urgency.
- Option 3: Priority should reflect the actual service situation.
- Option 4: Volume of pressure is not a consistent impact measure.

**CDFOS-Q0287 · single · operations**

What is functional escalation in this case?

Synthetic training case — not a field record.

A customer reports lost monitoring for one rack. Service is restored by an approved temporary collector restart. The same failure occurred twice this month. A proposed permanent driver update has not been tested. Another customer asks for a routine authorized access report. The team wants to close every related record once monitoring returns.

1. Changing the customer’s contract unilaterally
2. Deleting the incident’s diagnostic history
3. Closing the record because the first team lacks expertise
4. Bringing in the expertise needed to diagnose the collector/driver behavior

**Correct option(s):** 4

- Option 1: That is not a technical escalation function.
- Option 2: Experts need the retained evidence.
- Option 3: Lack of expertise should prompt escalation, not unsupported closure.
- Option 4: It adds technical capability to resolve the problem.

**CDFOS-Q0288 · single · operations**

What is management escalation useful for?

Synthetic training case — not a field record.

A customer reports lost monitoring for one rack. Service is restored by an approved temporary collector restart. The same failure occurred twice this month. A proposed permanent driver update has not been tested. Another customer asks for a routine authorized access report. The team wants to close every related record once monitoring returns.

1. Automatically proving the driver is defective
2. Resolving authority, resource or coordination decisions beyond the current role
3. Removing the need to communicate with the customer
4. Replacing every technical test with an executive opinion

**Correct option(s):** 2

- Option 1: Management involvement does not establish causality.
- Option 2: Technical work may depend on an accountable higher-level decision.
- Option 3: Communication remains part of service management.
- Option 4: Authority does not eliminate the need for evidence.

**CDFOS-Q0289 · single · operations**

What should accompany a transfer to a supplier?

Synthetic training case — not a field record.

A customer reports lost monitoring for one rack. Service is restored by an approved temporary collector restart. The same failure occurred twice this month. A proposed permanent driver update has not been tested. Another customer asks for a routine authorized access report. The team wants to close every related record once monitoring returns.

1. Only a demand to replace all equipment
2. Impact, observations, actions tried, constraints and the requested decision
3. Only the phrase “not working”
4. Only the supplier’s contract number

**Correct option(s):** 2

- Option 1: The cause and appropriate scope are not established.
- Option 2: This supports progress instead of uninformative ticket bouncing.
- Option 3: That omits the useful diagnostic context.
- Option 4: The contract does not describe the current failure.

**CDFOS-Q0290 · single · operations**

Which closure pattern is correct?

Synthetic training case — not a field record.

A customer reports lost monitoring for one rack. Service is restored by an approved temporary collector restart. The same failure occurred twice this month. A proposed permanent driver update has not been tested. Another customer asks for a routine authorized access report. The team wants to close every related record once monitoring returns.

1. Keep the incident unavailable forever until root cause is certain
2. Close every linked record whenever any service returns
3. Close restored incident criteria while retaining unresolved problem/change work
4. Merge the routine report request into the outage calculation

**Correct option(s):** 3

- Option 1: That misrepresents actual restored service.
- Option 2: That conceals unperformed permanent work.
- Option 3: Each record follows its own evidence and acceptance.
- Option 4: The request is a different service-management activity.

**CDFOS-Q0291 · single · mechanism**

What does hash B establish relative to approval of hash A?

Synthetic training case — not a field record.

Change CR7 approves collector package hash A for platform version 4. The staging test used version 4, but the production host is version 3. The installer presents package hash B. A canary login succeeds, yet alarm forwarding and backup jobs fail. A database migration in the package has no tested reverse path.

1. The approval of a package name covers every later binary
2. The package is necessarily malicious
3. The presented artifact is not the same identified approved package
4. The package is automatically newer and therefore approved

**Correct option(s):** 3

- Option 1: Artifact identity is part of the controlled release.
- Option 2: A mismatch has several possible causes.
- Option 3: Its contents and authority need reconciliation.
- Option 4: Version novelty does not confer authorization.

**CDFOS-Q0292 · single · mechanism**

Why is production version 3 material?

Synthetic training case — not a field record.

Change CR7 approves collector package hash A for platform version 4. The staging test used version 4, but the production host is version 3. The installer presents package hash B. A canary login succeeds, yet alarm forwarding and backup jobs fail. A database migration in the package has no tested reverse path.

1. Platform version never affects collector behavior
2. The staging result may not represent the production compatibility set
3. A lower version always guarantees compatibility
4. Only the package hash matters for every execution condition

**Correct option(s):** 2

- Option 1: Dependencies can change APIs, libraries and support.
- Option 2: The tested and target platforms differ.
- Option 3: Backward compatibility cannot be assumed.
- Option 4: Identical artifacts can behave differently on different platforms.

**CDFOS-Q0293 · single · operations**

What should successful canary login be counted as?

Synthetic training case — not a field record.

Change CR7 approves collector package hash A for platform version 4. The staging test used version 4, but the production host is version 3. The installer presents package hash B. A canary login succeeds, yet alarm forwarding and backup jobs fail. A database migration in the package has no tested reverse path.

1. One passed interface check within a larger acceptance set
2. Complete operational acceptance
3. Evidence that every untouched host is compatible
4. Proof that the database migration is reversible

**Correct option(s):** 1

- Option 1: Alarm and backup failures remain material.
- Option 2: The case supplies failed required services.
- Option 3: A canary result has a bounded target and environment.
- Option 4: Login does not test reversal.

**CDFOS-Q0294 · single · operations**

What should happen before expanding deployment?

Synthetic training case — not a field record.

Change CR7 approves collector package hash A for platform version 4. The staging test used version 4, but the production host is version 3. The installer presents package hash B. A canary login succeeds, yet alarm forwarding and backup jobs fail. A database migration in the package has no tested reverse path.

1. Continue because the installer returned success
2. Exclude alarm and backup checks after seeing failures
3. Use the canary’s login result as every host’s pass
4. Stop and resolve the failed checks and mismatched basis

**Correct option(s):** 4

- Option 1: Installer status does not override failed service tests.
- Option 2: That changes acceptance opportunistically.
- Option 3: Untested targets and dependencies remain.
- Option 4: Expansion would propagate an unaccepted state.

**CDFOS-Q0295 · single · recovery**

What is needed for the database migration’s recovery plan?

Synthetic training case — not a field record.

Change CR7 approves collector package hash A for platform version 4. The staging test used version 4, but the production host is version 3. The installer presents package hash B. A canary login succeeds, yet alarm forwarding and backup jobs fail. A database migration in the package has no tested reverse path.

1. Only the previous application executable, without a compatible data-state recovery method
2. Only the old schema definition, without the associated data and transaction recovery
3. A supported tested recovery path for the changed data state
4. An assumption that every migration is automatically reversible

**Correct option(s):** 3

- Option 1: Restoring a binary may leave it unable to use the migrated database schema or changed records.
- Option 2: Schema metadata alone may not recover transformed or lost data to an accepted state.
- Option 3: Configuration rollback alone may not reverse schema or data changes.
- Option 4: Some transformations require special recovery procedures.

**CDFOS-Q0296 · single · operations**

Which evidence should be preserved from the canary?

Synthetic training case — not a field record.

Change CR7 approves collector package hash A for platform version 4. The staging test used version 4, but the production host is version 3. The installer presents package hash B. A canary login succeeds, yet alarm forwarding and backup jobs fail. A database migration in the package has no tested reverse path.

1. Only the final success message from installation
2. Only the original planned state
3. Actual versions, artifacts, changed state and failed service observations
4. Only the approved hash A

**Correct option(s):** 3

- Option 1: The operational tests contradict full success.
- Option 2: That omits the partial deployment result.
- Option 3: Recovery needs a truthful account of what occurred.
- Option 4: The actual presented hash B is part of the discrepancy.

**CDFOS-Q0297 · single · operations**

What should the release package include besides software?

Synthetic training case — not a field record.

Change CR7 approves collector package hash A for platform version 4. The staging test used version 4, but the production host is version 3. The installer presents package hash B. A canary login succeeds, yet alarm forwarding and backup jobs fail. A database migration in the package has no tested reverse path.

1. Only marketing release notes
2. Only a statement that changes are routine
3. Applicable procedures, dependencies, tests, training and recovery material
4. Only the supplier’s generic installation guide

**Correct option(s):** 3

- Option 1: They may omit the site’s operational acceptance and recovery.
- Option 2: Classification does not document the controlled transition.
- Option 3: Operations must sustain the introduced state.
- Option 4: The guide may omit site-specific dependencies, operating procedures, acceptance tests and recovery responsibilities.

**CDFOS-Q0298 · single · operations**

What should verify alarm forwarding after correction?

Synthetic training case — not a field record.

Change CR7 approves collector package hash A for platform version 4. The staging test used version 4, but the production host is version 3. The installer presents package hash B. A canary login succeeds, yet alarm forwarding and backup jobs fail. A database migration in the package has no tested reverse path.

1. A controlled event reaching the intended responder through the actual path
2. Only a configured destination string
3. Only the application login
4. Only the absence of current alarms

**Correct option(s):** 1

- Option 1: The complete notification function must work.
- Option 2: Configuration intent is weaker than observed delivery.
- Option 3: Login does not exercise alarm delivery.
- Option 4: No event does not test the notification route.

**CDFOS-Q0299 · single · operations**

What should verify backup readiness after release?

Synthetic training case — not a field record.

Change CR7 approves collector package hash A for platform version 4. The staging test used version 4, but the production host is version 3. The installer presents package hash B. A canary login succeeds, yet alarm forwarding and backup jobs fail. A database migration in the package has no tested reverse path.

1. Successful supported backup and appropriate usability validation
2. Only the existence of an old backup
3. Only spare disk capacity
4. Only an unchanged schedule entry

**Correct option(s):** 1

- Option 1: A new version may change artifacts or dependencies.
- Option 2: That may not recover the new accepted state.
- Option 3: Capacity does not establish a performed usable backup.
- Option 4: A job can remain scheduled while failing.

**CDFOS-Q0300 · single · operations**

What is the appropriate final approval basis?

Synthetic training case — not a field record.

Change CR7 approves collector package hash A for platform version 4. The staging test used version 4, but the production host is version 3. The installer presents package hash B. A canary login succeeds, yet alarm forwarding and backup jobs fail. A database migration in the package has no tested reverse path.

1. The installer’s confidence in the product
2. The number of users who can reach the login page
3. The reconciled supported artifact/environment and complete acceptance evidence
4. The fact that the change window was booked

**Correct option(s):** 3

- Option 1: Confidence does not replace test results.
- Option 2: That remains a narrow subset of the required service.
- Option 3: Approval must match what will actually operate.
- Option 4: Scheduling is not technical acceptance.

**CDFOS-Q0301 · single · operations**

What should happen before automation overwrites SW9?

Synthetic training case — not a field record.

Discovery finds switch SW9 with a management address absent from the CMDB. A local emergency record authorizes a temporary address change for recovery, but the central baseline was not updated. The temporary permission expires tomorrow. Automation proposes overwriting SW9 immediately with last month’s baseline. A rack-to-PDU relationship in DCIM also conflicts with the inspected connection.

1. Accept every discovered value as permanent approval
2. Ignore the difference because service works
3. Delete the emergency record to match the central baseline
4. Review the emergency authority, current dependence and intended expiry

**Correct option(s):** 4

- Option 1: Discovery reports state, not authority.
- Option 2: Temporary permission still needs reconciliation.
- Option 3: That would conceal the actual decision history.
- Option 4: Blind rollback could remove a necessary accepted temporary recovery state.

**CDFOS-Q0302 · single · mechanism**

What does discovery establish about SW9?

Synthetic training case — not a field record.

Discovery finds switch SW9 with a management address absent from the CMDB. A local emergency record authorizes a temporary address change for recovery, but the central baseline was not updated. The temporary permission expires tomorrow. Automation proposes overwriting SW9 immediately with last month’s baseline. A rack-to-PDU relationship in DCIM also conflicts with the inspected connection.

1. An observed address at the collection time
2. The complete physical power topology
3. A confirmed malicious change
4. A formally approved permanent configuration

**Correct option(s):** 1

- Option 1: Authorization and correctness need additional evidence.
- Option 2: Address discovery does not establish rack-PDU connections.
- Option 3: The emergency record offers another explanation.
- Option 4: Observation alone cannot grant approval.

**CDFOS-Q0303 · single · mechanism**

Why is the expiry date operationally important?

Synthetic training case — not a field record.

Discovery finds switch SW9 with a management address absent from the CMDB. A local emergency record authorizes a temporary address change for recovery, but the central baseline was not updated. The temporary permission expires tomorrow. Automation proposes overwriting SW9 immediately with last month’s baseline. A rack-to-PDU relationship in DCIM also conflicts with the inspected connection.

1. It makes the old baseline correct under every condition
2. It invalidates all prior incident evidence
3. It guarantees automatic technical rollback
4. It creates a decision deadline for the temporary state

**Correct option(s):** 4

- Option 1: Current dependencies still require assessment.
- Option 2: Historical records remain relevant.
- Option 3: Enforcement behavior must be verified.
- Option 4: The exception cannot silently become permanent.

**CDFOS-Q0304 · single · operations**

Which source should the approved baseline represent?

Synthetic training case — not a field record.

Discovery finds switch SW9 with a management address absent from the CMDB. A local emergency record authorizes a temporary address change for recovery, but the central baseline was not updated. The temporary permission expires tomorrow. Automation proposes overwriting SW9 immediately with last month’s baseline. A rack-to-PDU relationship in DCIM also conflicts with the inspected connection.

1. Whichever configuration produces fewer differences
2. The oldest surviving file
3. The authorized intended state after reviewed reconciliation
4. Whatever was collected most recently

**Correct option(s):** 3

- Option 1: Diff size is not the acceptance criterion.
- Option 2: Age does not establish current approval.
- Option 3: It is neither arbitrary history nor unreviewed discovery.
- Option 4: Fresh observation can still be unauthorized or incorrect.

**CDFOS-Q0305 · single · mechanism**

Why is the rack-to-PDU relationship a configuration item concern?

Synthetic training case — not a field record.

Discovery finds switch SW9 with a management address absent from the CMDB. A local emergency record authorizes a temporary address change for recovery, but the central baseline was not updated. The temporary permission expires tomorrow. Automation proposes overwriting SW9 immediately with last month’s baseline. A rack-to-PDU relationship in DCIM also conflicts with the inspected connection.

1. Relationships determine maintenance impact and service dependencies
2. PDU mappings matter only during construction
3. Only software versions qualify as controlled configuration
4. DCIM relationships cannot be checked physically

**Correct option(s):** 1

- Option 1: An accurate asset name with a wrong connection can mislead decisions.
- Option 2: They affect later capacity, work and recovery.
- Option 3: Physical relationships can be critical to operations.
- Option 4: Installed connections can be reconciled through authorized methods.

**CDFOS-Q0306 · single · operations**

What should accompany a baseline correction?

Synthetic training case — not a field record.

Discovery finds switch SW9 with a management address absent from the CMDB. A local emergency record authorizes a temporary address change for recovery, but the central baseline was not updated. The temporary permission expires tomorrow. Automation proposes overwriting SW9 immediately with last month’s baseline. A rack-to-PDU relationship in DCIM also conflicts with the inspected connection.

1. Only a statement that the device is reachable
2. Only the new configuration value without the reason or authority
3. Authority, reason, affected items, evidence and version history
4. Only the discovery tool’s default confidence score

**Correct option(s):** 3

- Option 1: Reachability does not establish all configuration requirements.
- Option 2: A value alone cannot explain why the accepted baseline changed.
- Option 3: These make the accepted state traceable.
- Option 4: Approval requires context and accountable review.

**CDFOS-Q0307 · single · operations**

What is the risk of blindly accepting discovered state?

Synthetic training case — not a field record.

Discovery finds switch SW9 with a management address absent from the CMDB. A local emergency record authorizes a temporary address change for recovery, but the central baseline was not updated. The temporary permission expires tomorrow. Automation proposes overwriting SW9 immediately with last month’s baseline. A rack-to-PDU relationship in DCIM also conflicts with the inspected connection.

1. Discovery can never reveal useful information
2. The central baseline becomes immutable forever
3. Unauthorized or erroneous changes can become normalized
4. Every discovery response changes the device physically

**Correct option(s):** 3

- Option 1: It can identify valuable discrepancies.
- Option 2: Controlled updates remain possible and necessary.
- Option 3: Observation should be reviewed before becoming intent.
- Option 4: A read observation need not mutate the device.

**CDFOS-Q0308 · single · operations**

What is the risk of blindly restoring an old baseline?

Synthetic training case — not a field record.

Discovery finds switch SW9 with a management address absent from the CMDB. A local emergency record authorizes a temporary address change for recovery, but the central baseline was not updated. The temporary permission expires tomorrow. Automation proposes overwriting SW9 immediately with last month’s baseline. A rack-to-PDU relationship in DCIM also conflicts with the inspected connection.

1. It can remove legitimate emergency or later approved changes
2. It proves the device was compromised
3. It automatically fixes the physical PDU mapping
4. It always improves service regardless of context

**Correct option(s):** 1

- Option 1: Historical configuration may no longer represent the required state.
- Option 2: Rollback choice does not establish incident cause.
- Option 3: Network configuration cannot move power connections.
- Option 4: Old values can break current dependencies.

**CDFOS-Q0309 · single · operations**

What should be verified after resolving the temporary address?

Synthetic training case — not a field record.

Discovery finds switch SW9 with a management address absent from the CMDB. A local emergency record authorizes a temporary address change for recovery, but the central baseline was not updated. The temporary permission expires tomorrow. Automation proposes overwriting SW9 immediately with last month’s baseline. A rack-to-PDU relationship in DCIM also conflicts with the inspected connection.

1. Only that the old file still exists
2. Only that the CMDB field changed
3. Management access, monitoring, backup and approved reachability
4. Only the switch’s power indicator

**Correct option(s):** 3

- Option 1: Artifact retention does not establish the returned function.
- Option 2: Record correction alone does not test actual service.
- Option 3: Supporting services may depend on the address.
- Option 4: Power does not verify management integration.

**CDFOS-Q0310 · single · diagnosis**

What closes the physical relationship discrepancy?

Synthetic training case — not a field record.

Discovery finds switch SW9 with a management address absent from the CMDB. A local emergency record authorizes a temporary address change for recovery, but the central baseline was not updated. The temporary permission expires tomorrow. Automation proposes overwriting SW9 immediately with last month’s baseline. A rack-to-PDU relationship in DCIM also conflicts with the inspected connection.

1. Editing DCIM to whichever path appears more redundant
2. Using the server hostname as proof of its power feed
3. Verified installed state and controlled updates to affected records
4. Leaving both conflicting values without an owner

**Correct option(s):** 3

- Option 1: A preferred drawing cannot create independence.
- Option 2: Logical identity does not establish physical attachment.
- Option 3: The accepted model must match the actual connection.
- Option 4: Unresolved inconsistency needs a defined disposition.

**CDFOS-Q0311 · single · calculation**

How many unallocated rack units remain?

Synthetic training case — not a field record.

Rack R has 42 usable rack units: 26 occupied and 8 reserved for an approved project. A proposed device requires 10 units. The responsible structural specialist’s approved additional mass allowance is 250 kg; the proposal adds 280 kg. Its airflow direction also conflicts with the approved row arrangement. Network ports are available.

1. 16 units
2. 8 units
3. 10 units
4. 34 units

**Correct option(s):** 2

- Option 1: That ignores the accepted reservation.
- Option 2: Forty-two minus twenty-six occupied minus eight reserved equals eight.
- Option 3: That is the proposed device requirement.
- Option 4: That subtracts reservations but ignores occupied equipment.

**CDFOS-Q0312 · single · operations**

Can the ten-unit device fit without changing accepted allocations?

Synthetic training case — not a field record.

Rack R has 42 usable rack units: 26 occupied and 8 reserved for an approved project. A proposed device requires 10 units. The responsible structural specialist’s approved additional mass allowance is 250 kg; the proposal adds 280 kg. Its airflow direction also conflicts with the approved row arrangement. Network ports are available.

1. No device may ever use reserved capacity
2. No; it needs two more unallocated units than available
3. Yes; reserved space is always free for any new request
4. Yes; network ports can substitute for rack space

**Correct option(s):** 2

- Option 1: An authorized reprioritization could change the allocation.
- Option 2: The stated allocation leaves only eight.
- Option 3: A reservation is an existing commitment requiring review.
- Option 4: The constraints are different physical resources.

**CDFOS-Q0313 · single · operations**

What is the mass-allowance result?

Synthetic training case — not a field record.

Rack R has 42 usable rack units: 26 occupied and 8 reserved for an approved project. A proposed device requires 10 units. The responsible structural specialist’s approved additional mass allowance is 250 kg; the proposal adds 280 kg. Its airflow direction also conflicts with the approved row arrangement. Network ports are available.

1. The proposal has 30 kg spare allowance
2. The operator may ignore the allowance if the rack looks stable
3. The proposal is acceptable because 280 is below 420
4. The proposal exceeds the approved additional allowance by 30 kg

**Correct option(s):** 4

- Option 1: That reverses the comparison.
- Option 2: Appearance is not structural acceptance evidence.
- Option 3: Rack-unit count does not create a mass rating.
- Option 4: Two hundred eighty minus two hundred fifty is thirty.

**CDFOS-Q0314 · single · operations**

Who should resolve a proposed change to the structural allowance?

Synthetic training case — not a field record.

Rack R has 42 usable rack units: 26 occupied and 8 reserved for an approved project. A proposed device requires 10 units. The responsible structural specialist’s approved additional mass allowance is 250 kg; the proposal adds 280 kg. Its airflow direction also conflicts with the approved row arrangement. Network ports are available.

1. The responsible qualified structural authority
2. The app learner after calculating the thirty-kilogram difference
3. The network administrator solely because ports are available
4. The delivery driver based on lifting experience

**Correct option(s):** 1

- Option 1: D1 engineering remains outside the operator’s owned competence.
- Option 2: Arithmetic does not establish structural qualification.
- Option 3: Network capacity does not confer structural authority.
- Option 4: Transport experience does not certify the floor/rack design.

**CDFOS-Q0315 · single · mechanism**

Why is airflow direction a separate acceptance issue?

Synthetic training case — not a field record.

Rack R has 42 usable rack units: 26 occupied and 8 reserved for an approved project. A proposed device requires 10 units. The responsible structural specialist’s approved additional mass allowance is 250 kg; the proposal adds 280 kg. Its airflow direction also conflicts with the approved row arrangement. Network ports are available.

1. The device can disrupt the approved thermal arrangement
2. Available ports guarantee adequate cooling
3. Airflow is determined solely by rack-unit height
4. A mass allowance automatically covers airflow behavior

**Correct option(s):** 1

- Option 1: Physical fit does not guarantee compatible heat removal.
- Option 2: Connectivity does not supply thermal capacity.
- Option 3: Equipment direction and surrounding paths matter.
- Option 4: Structural and thermal constraints are independent.

**CDFOS-Q0316 · single · operations**

What is the correct overall disposition?

Synthetic training case — not a field record.

Rack R has 42 usable rack units: 26 occupied and 8 reserved for an approved project. A proposed device requires 10 units. The responsible structural specialist’s approved additional mass allowance is 250 kg; the proposal adds 280 kg. Its airflow direction also conflicts with the approved row arrangement. Network ports are available.

1. Accept because one constraint, network ports, passes
2. Hold until a reviewed plan satisfies all governing constraints
3. Reject every future device for the rack permanently
4. Accept after deleting the earlier reservation

**Correct option(s):** 2

- Option 1: One success cannot compensate for unrelated failed limits.
- Option 2: Several independent requirements currently fail or remain unresolved.
- Option 3: A different supported proposal may be acceptable.
- Option 4: Allocation changes require authority and consequence review.

**CDFOS-Q0317 · single · operations**

What should a reservation record include?

Synthetic training case — not a field record.

Rack R has 42 usable rack units: 26 occupied and 8 reserved for an approved project. A proposed device requires 10 units. The responsible structural specialist’s approved additional mass allowance is 250 kg; the proposal adds 280 kg. Its airflow direction also conflicts with the approved row arrangement. Network ports are available.

1. Only the supplier’s preferred shipping date
2. Only the project’s informal nickname
3. Owner, purpose, amount and review or expiry conditions
4. Only the requested rack units with no owner or expiry

**Correct option(s):** 3

- Option 1: Shipping does not define the capacity commitment.
- Option 2: Ambiguous naming weakens allocation traceability.
- Option 3: This makes committed capacity accountable and reconcilable.
- Option 4: Capacity can become stranded or disputed without reservation governance.

**CDFOS-Q0318 · single · implementation**

What should verify an eventually approved installation?

Synthetic training case — not a field record.

Rack R has 42 usable rack units: 26 occupied and 8 reserved for an approved project. A proposed device requires 10 units. The responsible structural specialist’s approved additional mass allowance is 250 kg; the proposal adds 280 kg. Its airflow direction also conflicts with the approved row arrangement. Network ports are available.

1. Actual position, connections, airflow and relevant records against the plan
2. Only the fact that it powers on
3. Only the shipping weight label
4. Only the purchase approval

**Correct option(s):** 1

- Option 1: Installed state must match the accepted design and allocations.
- Option 2: Basic startup omits physical and dependency requirements.
- Option 3: The complete installed arrangement needs assessment.
- Option 4: Buying the device does not verify installation.

**CDFOS-Q0319 · single · operations**

Which statement about free space is valid?

Synthetic training case — not a field record.

Rack R has 42 usable rack units: 26 occupied and 8 reserved for an approved project. A proposed device requires 10 units. The responsible structural specialist’s approved additional mass allowance is 250 kg; the proposal adds 280 kg. Its airflow direction also conflicts with the approved row arrangement. Network ports are available.

1. An empty rack proves the floor can support any mass
2. Free space eliminates the need for service clearances
3. Every empty unit is immediately orderable capacity
4. Visible empty space may already be reserved or constrained

**Correct option(s):** 4

- Option 1: Structural limits are independent of occupancy appearance.
- Option 2: Maintenance and access still require their approved space.
- Option 3: Existing commitments and other constraints remain.
- Option 4: Appearance does not represent all allocation and engineering limits.

**CDFOS-Q0320 · single · operations**

What should a revised proposal document?

Synthetic training case — not a field record.

Rack R has 42 usable rack units: 26 occupied and 8 reserved for an approved project. A proposed device requires 10 units. The responsible structural specialist’s approved additional mass allowance is 250 kg; the proposal adds 280 kg. Its airflow direction also conflicts with the approved row arrangement. Network ports are available.

1. Only a statement that installation will be careful
2. Only a revised rack elevation showing free mounting units
3. Changed allocations, approved support limits and thermal/connection evidence
4. Only an updated port-allocation schedule

**Correct option(s):** 3

- Option 1: Care does not remove exceeded design limits.
- Option 2: Rack units do not demonstrate acceptable mass, support, thermal performance or connections.
- Option 3: The reviewer needs the complete corrected placement basis.
- Option 4: Port allocations do not resolve the proposal’s support and thermal constraints.

**CDFOS-Q0321 · single · operations**

What must be resolved before removal?

Synthetic training case — not a field record.

Removal work names server A, but the rack technician identifies serial B at the labeled position. The owner’s disposal authorization covers A only. The server contains storage media, a BMC account and active monitoring/backup records. DCIM proposes releasing 5 kW of reserved capacity immediately, although no physical removal or load verification has occurred.

1. Only whether the hostname matches the removal request
2. Only whether the unit occupies the rack position shown in an older drawing
3. Only whether the unit matches the requested model and form factor
4. The mismatch between authorized asset A and observed serial B

**Correct option(s):** 4

- Option 1: A reused name does not resolve the physical serial mismatch.
- Option 2: An obsolete position record cannot override conflicting current identity evidence.
- Option 3: Identical units can have different authorized identities; the serial mismatch remains unresolved.
- Option 4: The work may otherwise affect the wrong equipment.

**CDFOS-Q0322 · single · operations**

Does authorization to dispose of A permit disposal of B?

Synthetic training case — not a field record.

Removal work names server A, but the rack technician identifies serial B at the labeled position. The owner’s disposal authorization covers A only. The server contains storage media, a BMC account and active monitoring/backup records. DCIM proposes releasing 5 kW of reserved capacity immediately, although no physical removal or load verification has occurred.

1. Yes; the technician’s observation changes the approval automatically
2. No; the actual asset must match the approved disposition
3. Yes; both occupy the same labeled position at different times
4. No disposal can ever occur after an identity correction

**Correct option(s):** 2

- Option 1: Observation does not grant disposal authority.
- Option 2: Different identity requires an authorized resolution.
- Option 3: Location does not make asset ownership interchangeable.
- Option 4: A properly reviewed correction can establish a valid scope.

**CDFOS-Q0323 · single · operations**

What separate issue does storage media introduce?

Synthetic training case — not a field record.

Removal work names server A, but the rack technician identifies serial B at the labeled position. The owner’s disposal authorization covers A only. The server contains storage media, a BMC account and active monitoring/backup records. DCIM proposes releasing 5 kW of reserved capacity immediately, although no physical removal or load verification has occurred.

1. Only the server’s rack-unit height
2. A guarantee that deleting the inventory entry erases data
3. Approved data handling and sanitization/disposition requirements
4. Automatic permission to resell all contents

**Correct option(s):** 3

- Option 1: Height does not determine data treatment.
- Option 2: Record changes do not sanitize media.
- Option 3: Physical removal does not resolve retained information.
- Option 4: Ownership and information requirements remain.

**CDFOS-Q0324 · single · operations**

What should happen to the BMC account and other access?

Synthetic training case — not a field record.

Removal work names server A, but the rack technician identifies serial B at the labeled position. The owner’s disposal authorization covers A only. The server contains storage media, a BMC account and active monitoring/backup records. DCIM proposes releasing 5 kW of reserved capacity immediately, although no physical removal or load verification has occurred.

1. Leave all credentials active for convenience indefinitely
2. Assume unplugging one cable revokes every credential everywhere
3. Publish credentials in the disposal report
4. Revoke, transfer or reissue through the approved lifecycle process

**Correct option(s):** 4

- Option 1: Obsolete access can create exposure.
- Option 2: Stored identities and remote records may persist.
- Option 3: Secrets should not be broadly disclosed.
- Option 4: Retirement changes the legitimate management relationship.

**CDFOS-Q0325 · single · operations**

When may the 5 kW reservation be released?

Synthetic training case — not a field record.

Removal work names server A, but the rack technician identifies serial B at the labeled position. The owner’s disposal authorization covers A only. The server contains storage media, a BMC account and active monitoring/backup records. DCIM proposes releasing 5 kW of reserved capacity immediately, although no physical removal or load verification has occurred.

1. When the authorized capacity process verifies what is genuinely freed
2. Immediately when DCIM proposes the edit
3. Whenever the monitoring record is hidden
4. Only after every other server is retired

**Correct option(s):** 1

- Option 1: The physical and allocation state must support the record change.
- Option 2: A proposal does not establish completed removal.
- Option 3: Display removal does not free physical or committed capacity.
- Option 4: That is unrelated to this asset’s verified resource release.

**CDFOS-Q0326 · single · operations**

What should monitoring reconciliation prevent?

Synthetic training case — not a field record.

Removal work names server A, but the rack technician identifies serial B at the labeled position. The owner’s disposal authorization covers A only. The server contains storage media, a BMC account and active monitoring/backup records. DCIM proposes releasing 5 kW of reserved capacity immediately, although no physical removal or load verification has occurred.

1. A retired asset appearing operational or a live asset being silently unmonitored
2. Any future replacement using the same rack position
3. The use of stable asset identifiers
4. All historical evidence being retained anywhere

**Correct option(s):** 1

- Option 1: Records must match the actual accepted lifecycle state.
- Option 2: A new asset can be installed through its own controlled process.
- Option 3: Stable identity supports reconciliation.
- Option 4: Relevant history can remain under retention policy.

**CDFOS-Q0327 · single · mechanism**

Why review backup records during retirement?

Synthetic training case — not a field record.

Removal work names server A, but the rack technician identifies serial B at the labeled position. The owner’s disposal authorization covers A only. The server contains storage media, a BMC account and active monitoring/backup records. DCIM proposes releasing 5 kW of reserved capacity immediately, although no physical removal or load verification has occurred.

1. To treat backups as spare physical power capacity
2. To apply the approved retention, ownership and recovery disposition
3. To preserve active jobs forever regardless of need
4. To delete every backup immediately without owner review

**Correct option(s):** 2

- Option 1: Data copies do not release facility resources.
- Option 2: Retired hardware does not automatically determine data-retention needs.
- Option 3: Obsolete jobs can fail or expose access unnecessarily.
- Option 4: That can violate recovery or retention requirements.

**CDFOS-Q0328 · single · operations**

What should a custody transfer offsite establish?

Synthetic training case — not a field record.

Removal work names server A, but the rack technician identifies serial B at the labeled position. The owner’s disposal authorization covers A only. The server contains storage media, a BMC account and active monitoring/backup records. DCIM proposes releasing 5 kW of reserved capacity immediately, although no physical removal or load verification has occurred.

1. Only the driver’s knowledge of a staff name
2. Only that a vehicle arrived
3. Only the original purchase price
4. Correct identity, authorized recipient, condition and disposition evidence

**Correct option(s):** 4

- Option 1: Familiarity is not a custody decision.
- Option 2: Arrival does not establish recipient or item authorization.
- Option 3: Value does not define the approved transfer.
- Option 4: The operator must know what left and under what authority.

**CDFOS-Q0329 · single · operations**

What should remain in the asset history after retirement?

Synthetic training case — not a field record.

Removal work names server A, but the rack technician identifies serial B at the labeled position. The owner’s disposal authorization covers A only. The server contains storage media, a BMC account and active monitoring/backup records. DCIM proposes releasing 5 kW of reserved capacity immediately, although no physical removal or load verification has occurred.

1. No record that the asset ever existed
2. An active production status until the next audit
3. Only the hostname that the retired device last used
4. The approved disposition and linked lifecycle evidence under retention rules

**Correct option(s):** 4

- Option 1: That would break maintenance, ownership and incident traceability.
- Option 2: That misrepresents the installation.
- Option 3: A reused hostname does not preserve the controlled physical identity, approved disposition or lifecycle links.
- Option 4: Retirement changes status without erasing accountability.

**CDFOS-Q0330 · single · implementation**

Which acceptance separates deinstallation from complete retirement?

Synthetic training case — not a field record.

Removal work names server A, but the rack technician identifies serial B at the labeled position. The owner’s disposal authorization covers A only. The server contains storage media, a BMC account and active monitoring/backup records. DCIM proposes releasing 5 kW of reserved capacity immediately, although no physical removal or load verification has occurred.

1. Only the disposal supplier’s generic brochure
2. Physical removal plus resolved data, access, ownership and record obligations
3. Only a disconnected network link
4. Only removal from the rack diagram

**Correct option(s):** 2

- Option 1: The actual asset’s disposition requires evidence.
- Option 2: Retirement includes more than disconnecting equipment.
- Option 3: Other dependencies and responsibilities remain.
- Option 4: The physical asset and information may still be present.

#### Recall

**Handover with an expiring override — Synthetic training case — not a field record.

At 18:00, cooling unit C2 remains in an approved temporary manual mode that expires at 18:30. Its automatic-sequence retest has not occurred. A supplier is expected at 19:00. The outgoing log says “C2 stable; vendor coming.” The incoming operator assumes normal automatic redundancy is available.**

The log omits the temporary mode, expiry, missing test and actual resilience state. Correct the handover, obtain the required decision before expiry and distinguish the supplier’s expected arrival from accepted restoration. The receiving operator should confirm the critical state and action rather than infer it from “stable.”

**Walk-around contradicts remote status — Synthetic training case — not a field record.

BMS shows a cooling unit as available. During an authorized external inspection, the operator sees a local selector in Manual and a small leak beneath the unit. The BMS availability point has not changed for two days, although its screen refreshes. The inspection route does not authorize opening energized panels.**

Record the local mode, leak and freshness concern. Escalate through the equipment and safety procedures without opening unauthorized enclosures. Trace what “available” actually represents and whether the source is current. A refreshed display is not evidence of newly acquired condition, and the physical findings do not by themselves identify the leak’s cause.

**Incident, request, problem and change records — Synthetic training case — not a field record.

A customer reports lost monitoring for one rack. Service is restored by an approved temporary collector restart. The same failure occurred twice this month. A proposed permanent driver update has not been tested. Another customer asks for a routine authorized access report. The team wants to close every related record once monitoring returns.**

The monitoring interruption is an incident; the recurring cause can remain a problem investigation after restoration. The driver update is a proposed change requiring its own evidence and authority. The routine report is a service request. Link records while preserving their different completion conditions.

**Release package differs from approved artifact — Synthetic training case — not a field record.

Change CR7 approves collector package hash A for platform version 4. The staging test used version 4, but the production host is version 3. The installer presents package hash B. A canary login succeeds, yet alarm forwarding and backup jobs fail. A database migration in the package has no tested reverse path.**

The proposed execution differs from the approved and tested basis. Hold broader deployment, reconcile package identity and platform support, and assess the database recovery method. A login test does not close alarm or backup requirements. Preserve actual canary state and follow a supported decision rather than assuming a configuration copy reverses the migration.

**Configuration drift after an emergency correction — Synthetic training case — not a field record.

Discovery finds switch SW9 with a management address absent from the CMDB. A local emergency record authorizes a temporary address change for recovery, but the central baseline was not updated. The temporary permission expires tomorrow. Automation proposes overwriting SW9 immediately with last month’s baseline. A rack-to-PDU relationship in DCIM also conflicts with the inspected connection.**

Investigate and reconcile both differences. Observed state is not automatically authorized, but the local emergency record may explain this one. Confirm authority, expiry and current service dependencies before rollback or baseline update. Reconcile the physical power relationship independently because configuration items include dependencies, not just device attributes.

**Placement with space, mass and airflow constraints — Synthetic training case — not a field record.

Rack R has 42 usable rack units: 26 occupied and 8 reserved for an approved project. A proposed device requires 10 units. The responsible structural specialist’s approved additional mass allowance is 250 kg; the proposal adds 280 kg. Its airflow direction also conflicts with the approved row arrangement. Network ports are available.**

The proposal fails more than one independent placement constraint: only eight unallocated rack units remain, the approved mass allowance is exceeded and airflow compatibility is unresolved. Available network ports do not compensate. Hold placement and obtain a supported revised plan; the operator does not redesign or certify the structure.

**Equipment retirement and release of dependencies — Synthetic training case — not a field record.

Removal work names server A, but the rack technician identifies serial B at the labeled position. The owner’s disposal authorization covers A only. The server contains storage media, a BMC account and active monitoring/backup records. DCIM proposes releasing 5 kW of reserved capacity immediately, although no physical removal or load verification has occurred.**

Hold the identity mismatch before disconnecting or releasing the asset. Reconcile ownership and the approved item, then follow supported data/media disposition, access revocation and physical removal. Update monitoring, backup, inventory and capacity only against the actual accepted state; record-retirement is not proof that the physical resource is free.

#### References

- [EPI CDFOS public syllabus](https://www.epi-ap.com/services/1/3/136)
- [NIST SP 800-53 Rev. 5 — physical and environmental protection controls](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final)

## CDFOS-M06 — Monitoring semantics, alarms, escalation and recovery

### CDFOS-L06 — Monitoring semantics, alarms, escalation and recovery

Estimated study time: 120 minutes before independent work. Prerequisite chapters: CDFOS-L05

## Monitoring starts with an operational decision

Monitoring is the acquisition and interpretation of observations needed to operate a service. Start with the decision or response each observation supports. A room temperature used for a daily trend may need a different update rate and uncertainty from a temperature used in a rapid protective sequence. Define the asset, function, measurement or status, source, units, range, expected update behavior, quality, threshold logic, responsible role and response. A facilities monitoring matrix connects these requirements to implemented points and tests.

Coverage is not simply the number of sensors installed. A sensor can be on the wrong asset, have a range unsuitable for the decision, use an incorrect scale, or lose its value before reaching the operator. Trace the complete chain from physical source through input, controller, gateway, network, application, alarm and retained record. Identify shared dependencies such as controller power, time services, databases and notification infrastructure. Redundant dashboards using one failed gateway do not provide independent observation.

Distinguish value, quality and age. A current transport message may contain an old cached observation. A numerical value can remain unchanged because the process is steady or because acquisition stopped. Use the selected protocol and product’s source time, quality, sequence or heartbeat semantics to distinguish those conditions. A browser refresh time is not a source timestamp. When trustworthy freshness cannot be established, present the limitation and follow the designed degraded-data response instead of silently declaring the value current.

## Point testing validates meaning as well as connection

A point-to-point test checks that the intended source appears at the intended consumer with correct identity and interpretation. Use a safe known stimulus or authorized represented value and compare each stage. Verify engineering units, range, polarity where applicable, scaling, asset association, quality and expected direction. A test that only proves a controller responds to ping does not establish that its temperature point represents the correct pipe or room.

For a linear 4–20 mA signal, the fraction of span is (current−4)/16. A transmitter representing 0–100 °C therefore indicates 50 °C at 12 mA. Treating it as 0–20 mA would produce 60 °C, a plausible but wrong value. This calculation teaches scaling, not a universal input-module configuration. Actual fault-current treatment, raw counts, wiring and calibration follow the selected equipment. Use more than one point to distinguish slope and offset errors, and retain as-found and as-left evidence under the measurement-assurance process.

Calibration and point testing overlap but answer different questions. Calibration compares measurement performance with a suitable reference. Mapping tests verify identity and transformation through the system. A perfectly calibrated sensor mapped to the neighboring unit remains an operational defect. After a sensor or software change, verify the alarm and historian as well as the live display. Update point records and record which physical or simulated stimulus was used.

## Alarm logic must support a specific response

An alarm should identify a condition requiring a defined action. Document the initiating rule, priority, delay, deadband or hysteresis, latching, acknowledgment, reset and escalation. Do not use priority merely to make an alarm visually prominent; relate it to consequence and the required response. Excessive duplicate or chattering alarms can obscure the initiating event. Acknowledgment records awareness and may leave the condition active. Clearing the initiating condition may also leave an unacknowledged event in the history, depending on the supported design.

Persistence delays and hysteresis serve different purposes. A persistence delay requires a condition to remain true for a defined duration before triggering. Hysteresis uses different activation and return thresholds to reduce repeated transitions near a boundary. A long delay can suppress brief noise but also postpone a required response; a wide return band can reduce chatter while holding an alarm longer. Select and test these values against the actual process and service requirement rather than copying an unrelated template.

Test boundary behavior. Include just below, at and above the activation condition; a short excursion; a sustained excursion; return to normal; and bad or stale input. Define comparison operators and timer reset behavior explicitly. A simulated trend must state its sampling and timing assumptions. If the requirement is to notify within five seconds, sensing, controller logic, transport, application and notification delays all contribute. A fast network alone cannot prove the complete response time.

## Notification and escalation are separate from detection

A detection event is useful only if the required role receives and acts on it. A notification matrix maps condition, severity or service to recipient role, method, schedule, acknowledgment expectation, escalation deadline and fallback. Use roles with maintained contact ownership rather than relying on one person’s private phone number. Test after contact, shift, identity or communication changes. An application status of “sent” may mean only that it submitted a message to another service; it does not necessarily establish delivery, acknowledgment or response.

Escalation should resolve the needed capability or authority. If the first responder does not acknowledge within the defined interval, the system or operator follows the specified next route. Record which clock starts the escalation and whether retries change it. Repeated retries must not silently postpone escalation forever. During a communication outage, use the approved alternative route and preserve the event history. A supplier’s acknowledgment is not the same as arrival or restored equipment function.

Evaluate the whole path using a controlled test event. Record source time, detection, dispatch, delivery where available, acknowledgment, action and restored condition. Account for clock uncertainty before calculating stage delays. A test that sends a generic email from an administrator’s mailbox does not exercise the actual alarm integration. Include a failed primary recipient or channel so the fallback is demonstrated, while preventing the exercise from being mistaken for an uncontrolled real emergency.

## Retained data and restoration need their own acceptance

Historian storage choices affect what can later be concluded. Sampling intervals, deadbands, aggregation, queue capacity and retention can discard detail. A line drawn between two samples is an interpolation, not proof that every intermediate value was observed. Store source timestamps and quality when supported and required. Distinguish live freshness from eventual historical completeness: backfilled data can restore history without retroactively providing the operator a timely observation during an outage.

Buffers have finite capacity and operating limits. Estimate the records produced during a bounded interruption, include overhead and variable rate as appropriate, and test the selected implementation. A queue that fits the nominal count may still be constrained by storage, record size or a configured age limit. After reconnection, examine backlog drainage, duplicate handling, original timestamps and missing records. Do not erase a gap by assigning receipt time as if it were acquisition time.

Restore monitoring as a functional service. The application, point configuration, identities, certificates, database, time source and notification integrations may all be required. Opening the login page is only an initial observation. Verify current source data, quality, alarms, retained history, permissions, health monitoring and backup after recovery. A restored configuration can reintroduce obsolete destinations or disabled thresholds; compare the recovered state with the accepted current baseline.

## Reports distinguish availability, capacity and capability

Availability reports describe delivered service under the agreed measurement rule. Capacity reports quantify usable resources, demand, allocations and margin. Capability reports ask whether the required function can be delivered under the specified conditions, including maintenance, failure, people and support. These are related but not interchangeable. Low average utilization does not prove a peak, maintenance or common-dependency requirement is met.

Use the appropriate aggregation and units. Do not average percentages from unequal denominators without understanding the intended weighting. Preserve missing-data periods and asset population changes when comparing trends. A dashboard with fewer monitored assets can appear to improve simply because difficult cases disappeared. Identify the data source, calculation version, coverage, period and limitations in reports. Route material deviations to an owner and action rather than leaving them as unexplained red cells.

The independent assignment builds a monitoring matrix, verifies a representative point chain, tests alarm boundaries and notification fallback, and restores a small supported monitoring service. Use synthetic traces for analytical work and separate vendor or physical evidence for actual device behavior. The acceptance report must distinguish demonstrated current information, recovered history and untested fidelity or access requirements.

#### Worked demonstrations

**A monitoring matrix with a missing decision**

Synthetic training case — not a field record.

A matrix lists pump temperature T1, unit “degrees,” poll rate “fast,” alarm recipient “operations,” and no response action. Two dashboards consume the same gateway cache. The pump’s approved operating decision requires a current °C value associated with asset P7, with an agreed maximum age. One dashboard labels it P8.

**Reasoning:** The matrix lacks unambiguous units, timing, recipient role and action, and one consumer has the wrong asset association. Two displays do not remove the shared gateway dependency. Complete the point contract and verify the chain against a known source before using it for the operating decision.

**Persistence and hysteresis on a synthetic trace**

Synthetic training case — not a field record.

Synthetic rule: activate when temperature is strictly above 30 °C continuously for 10 seconds; reset the pending timer whenever temperature is 30 °C or lower. Once active, return to normal only below 28 °C. Trace: 31 °C from t=0 to 6; 30 °C from 6 to 8; 31 °C from 8 to 21; 29 °C from 21 to 30; 27 °C from 30 onward. Assume exact continuous observation for this analytical exercise.

**Reasoning:** The first six-second excursion does not activate. At t=6 the pending timer resets. The second qualifying interval begins at t=8 and reaches ten seconds at t=18. The active alarm remains at 29 °C and returns at t=30 when the value is below 28. Actual sampled implementation needs its own scan, timestamp and boundary tests.

**Notification sent but no accountable response**

Synthetic training case — not a field record.

Alarm A is detected at 02:00. The application submits an email at 02:01 and marks it Sent. The primary on-call address is obsolete, so no acknowledgment arrives. The matrix requires escalation five minutes after detection if unacknowledged. A retry job resubmits every two minutes and incorrectly restarts the escalation timer. A tested voice fallback is available.

**Reasoning:** The escalation deadline is 02:05 from detection, not five minutes after each retry. Sent proves submission only at the stated application stage. Correct the timer semantics and recipient ownership, use the approved fallback and test the complete route with controlled events. Keep delivery, acknowledgment and actual response timestamps distinct.

**Scaling and point identity through a gateway**

Synthetic training case — not a field record.

Synthetic training loop: transmitter T7 represents 0–100 °C over 4–20 mA. A known 12 mA test signal reaches the input. The controller correctly reports 50 °C, but the gateway uses a 0–20 mA interpretation and the display shows 60 °C. The historian also labels T7 as asset P8 instead of P7. No physical live-plant signal is injected.

**Reasoning:** The source fraction is (12−4)/16 = 0.5, so the correct value is 50 °C. The gateway’s different transfer function explains its plausible 60 °C. Correct the approved mapping and independently fix the asset association. Retest several values, alarm behavior and history; software injection does not establish physical calibration or wiring.

**Historian buffering and useful monitoring recovery**

Synthetic training case — not a field record.

Synthetic historian produces exactly 2 records/s. Its tested queue holds 10,000 records under the stated record format. A database outage lasts 80 minutes. After reconnection, the system writes 4 records/s total while new records continue arriving at 2/s. Original source timestamps are preserved. Ignore additional overhead only for this calculation exercise.

**Reasoning:** The outage creates 9,600 records, leaving 400 queue slots at reconnection. Backlog drains at the net rate 4−2 = 2 records/s, taking 4,800 seconds or 80 minutes. Retained history may recover, but operators lacked timely database-backed observations during the outage. Real acceptance must include record size, limits, quality, duplicates and actual implementation behavior.

**Capacity reporting with incomplete and changing observations**

Synthetic training case — not a field record.

A dashboard reports average rack load of 4 kW from 8 of 10 required racks; the two unobserved racks previously carried the highest loads. Samples are 15-minute averages, while the operating requirement concerns a one-minute peak. A cumulative network counter falls after a device restart. The report labels all missing values as zero and claims improved capacity.

**Reasoning:** The population and measurement interval do not support the claimed peak-capacity conclusion. Missing racks must remain unobserved, not zero. Counter discontinuity after restart needs explicit treatment before rates are calculated. Capacity, service availability and capability in a maintenance state require their own defined evidence.

#### Guided practice

Build a monitoring matrix and use the supplied traces to verify scaling, alarm timing, escalation and historical recovery. Explain what the data can and cannot support.

**Hint:** Keep source meaning, freshness, notification and retained history as independent acceptance dimensions.

**Worked solution:** Resolve point identity and units; apply the exact timer/comparison rules; measure the notification path from its stated origin; preserve source timestamps during backfill; calculate buffering with ongoing arrival; report missing populations and intervals explicitly rather than filling them with healthy values.

#### Independent task

Environment: analytical

Commission and restore a small represented monitoring service, then arrange the selected vendor/physical tests.

**Packaged starter material**

- course_labs/CDFOS/README.md
- course_labs/CDFOS/fixture.json
- course_labs/CDFOS/assessment_template.md
- course_labs/CDFOS/lab.py
- course_labs/CDFOS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- Point and notification matrix
- Alarm boundary and negative-input results
- Buffer/recovery calculations and data reconciliation
- Qualified capacity/availability report

**Acceptance criteria**

- Calculations state their assumptions and units.
- Alarm and escalation tests include failure cases.
- Recovered history is not mislabeled as timely live data.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer. The bundled calculator was executed against supplied synthetic fixtures; its numerical checks do not grade physical work or professional authorization.

#### Chapter practice

**CDFOS-Q0331 · single · operations**

Which supplied unit entry is ambiguous and must be completed before an engineering conversion?

Synthetic training case — not a field record.

A matrix lists pump temperature T1, unit “degrees,” poll rate “fast,” alarm recipient “operations,” and no response action. Two dashboards consume the same gateway cache. The pump’s approved operating decision requires a current °C value associated with asset P7, with an agreed maximum age. One dashboard labels it P8.

1. “Degrees” without the intended temperature scale
2. The use of two dashboards
3. The asset identifier P7
4. The existence of a gateway

**Correct option(s):** 1

- Option 1: The required decision explicitly uses degrees Celsius.
- Option 2: Display count does not resolve the unit ambiguity.
- Option 3: That supplies identity rather than temperature scale.
- Option 4: Architecture does not define the unit.

**CDFOS-Q0332 · single · mechanism**

Why is “fast” an inadequate poll requirement?

Synthetic training case — not a field record.

A matrix lists pump temperature T1, unit “degrees,” poll rate “fast,” alarm recipient “operations,” and no response action. Two dashboards consume the same gateway cache. The pump’s approved operating decision requires a current °C value associated with asset P7, with an agreed maximum age. One dashboard labels it P8.

1. It lacks a measurable interval or age criterion
2. Polling intervals can never be specified
3. A short word always indicates a low-priority point
4. Every point must poll at the maximum possible rate

**Correct option(s):** 1

- Option 1: Acceptance needs a defined timing limit.
- Option 2: They can be specified according to function and product behavior.
- Option 3: Word length does not define consequence.
- Option 4: Unbounded polling can overload devices and is not universally needed.

**CDFOS-Q0333 · single · mechanism**

What does the P8 label create?

Synthetic training case — not a field record.

A matrix lists pump temperature T1, unit “degrees,” poll rate “fast,” alarm recipient “operations,” and no response action. Two dashboards consume the same gateway cache. The pump’s approved operating decision requires a current °C value associated with asset P7, with an agreed maximum age. One dashboard labels it P8.

1. Proof that the physical sensor is uncalibrated
2. Proof that P7 does not exist
3. A wrong asset association despite possibly correct numeric data
4. Only a harmless display preference

**Correct option(s):** 3

- Option 1: Mapping and measurement accuracy are different questions.
- Option 2: A display label does not establish the inventory’s reality.
- Option 3: Operators may act on the wrong equipment.
- Option 4: Identity is part of the point’s operational meaning.

**CDFOS-Q0334 · single · operations**

What remains shared across the two dashboards?

Synthetic training case — not a field record.

A matrix lists pump temperature T1, unit “degrees,” poll rate “fast,” alarm recipient “operations,” and no response action. Two dashboards consume the same gateway cache. The pump’s approved operating decision requires a current °C value associated with asset P7, with an agreed maximum age. One dashboard labels it P8.

1. Every display operator’s identity by definition
2. The physical location of every monitored pump
3. The gateway cache supplying both observations
4. The customer’s contractual response target automatically

**Correct option(s):** 3

- Option 1: Separate users may still exist.
- Option 2: Display architecture does not merge equipment locations.
- Option 3: One stale source can mislead both displays.
- Option 4: That depends on the service definition, not display count.

**CDFOS-Q0335 · single · operations**

What should replace the generic recipient “operations”?

Synthetic training case — not a field record.

A matrix lists pump temperature T1, unit “degrees,” poll rate “fast,” alarm recipient “operations,” and no response action. Two dashboards consume the same gateway cache. The pump’s approved operating decision requires a current °C value associated with asset P7, with an agreed maximum age. One dashboard labels it P8.

1. The point’s database table name
2. A maintained accountable role with schedule and response route
3. Every email address ever used by a contractor
4. The gateway’s hostname alone

**Correct option(s):** 2

- Option 1: A storage object is not a responder.
- Option 2: The notification must reach someone able to act.
- Option 3: Uncontrolled distribution does not establish responsibility.
- Option 4: A device name does not define human ownership.

**CDFOS-Q0336 · single · mechanism**

Why record the expected operator action?

Synthetic training case — not a field record.

A matrix lists pump temperature T1, unit “degrees,” poll rate “fast,” alarm recipient “operations,” and no response action. Two dashboards consume the same gateway cache. The pump’s approved operating decision requires a current °C value associated with asset P7, with an agreed maximum age. One dashboard labels it P8.

1. It connects detection to the decision the alarm must support
2. It eliminates the need to test notification
3. It makes measurement quality irrelevant
4. It allows the application to replace every specialist’s authority

**Correct option(s):** 1

- Option 1: An alert without a defined response can become noise.
- Option 2: A written action does not prove delivery.
- Option 3: Wrong or stale data can still trigger an inappropriate action.
- Option 4: Documented action still respects competence and authorization.

**CDFOS-Q0337 · single · operations**

What is the best initial test stimulus?

Synthetic training case — not a field record.

A matrix lists pump temperature T1, unit “degrees,” poll rate “fast,” alarm recipient “operations,” and no response action. Two dashboards consume the same gateway cache. The pump’s approved operating decision requires a current °C value associated with asset P7, with an agreed maximum age. One dashboard labels it P8.

1. Only opening both dashboards simultaneously
2. Only a ping to the gateway address
3. Only changing the display label without source verification
4. A safe known source condition traced to the required consumer

**Correct option(s):** 4

- Option 1: Two rendered screens can share the same defect.
- Option 2: Reachability omits point meaning.
- Option 3: A corrected label may still reference the wrong point.
- Option 4: It tests identity and interpretation across the chain.

**CDFOS-Q0338 · single · design**

Which field supports a freshness decision?

Synthetic training case — not a field record.

A matrix lists pump temperature T1, unit “degrees,” poll rate “fast,” alarm recipient “operations,” and no response action. Two dashboards consume the same gateway cache. The pump’s approved operating decision requires a current °C value associated with asset P7, with an agreed maximum age. One dashboard labels it P8.

1. Source acquisition time or supported quality/sequence semantics
2. Only the time the dashboard page refreshed
3. Only the browser’s page-load time
4. Only the device purchase date

**Correct option(s):** 1

- Option 1: The consumer needs evidence of observation age.
- Option 2: A refreshed interface can still show an old source sample.
- Option 3: Rendering time may be unrelated to source acquisition.
- Option 4: Asset age does not describe current data freshness.

**CDFOS-Q0339 · single · operations**

What should the matrix say about a failed gateway?

Synthetic training case — not a field record.

A matrix lists pump temperature T1, unit “degrees,” poll rate “fast,” alarm recipient “operations,” and no response action. Two dashboards consume the same gateway cache. The pump’s approved operating decision requires a current °C value associated with asset P7, with an agreed maximum age. One dashboard labels it P8.

1. That stale values become current after reconnect
2. That both dashboards remain independently trustworthy
3. The affected points and designed degraded-data response
4. That every pump has physically failed

**Correct option(s):** 3

- Option 1: Reconnection does not automatically refresh cached source data.
- Option 2: They depend on the same source path.
- Option 3: Shared failure impact should be explicit.
- Option 4: Lost observation does not uniquely establish process failure.

**CDFOS-Q0340 · single · operations**

What completes this matrix item’s acceptance?

Synthetic training case — not a field record.

A matrix lists pump temperature T1, unit “degrees,” poll rate “fast,” alarm recipient “operations,” and no response action. Two dashboards consume the same gateway cache. The pump’s approved operating decision requires a current °C value associated with asset P7, with an agreed maximum age. One dashboard labels it P8.

1. A larger number of displayed points
2. Verified identity, units, age, quality, alarm route and required action
3. A signed list with unresolved placeholders
4. A visually consistent pair of dashboards

**Correct option(s):** 2

- Option 1: Quantity does not prove this point’s correctness.
- Option 2: The point must support its defined operational use.
- Option 3: Approval without resolved requirements does not create testable function.
- Option 4: Both can consistently display the same wrong interpretation.

**CDFOS-Q0341 · single · operations**

Does the first excursion activate the alarm?

Synthetic training case — not a field record.

Synthetic rule: activate when temperature is strictly above 30 °C continuously for 10 seconds; reset the pending timer whenever temperature is 30 °C or lower. Once active, return to normal only below 28 °C. Trace: 31 °C from t=0 to 6; 30 °C from 6 to 8; 31 °C from 8 to 21; 29 °C from 21 to 30; 27 °C from 30 onward. Assume exact continuous observation for this analytical exercise.

1. No; thirty-one is below the stated activation threshold
2. No; it lasts only six continuous qualifying seconds
3. Yes; any sample above thirty activates immediately
4. Yes; the later excursion can be added to the first

**Correct option(s):** 2

- Option 1: Thirty-one is above thirty; duration is the limiting factor.
- Option 2: The rule requires ten seconds without reset.
- Option 3: That ignores persistence.
- Option 4: The intervening reset breaks continuity.

**CDFOS-Q0342 · single · operations**

What happens at t=6?

Synthetic training case — not a field record.

Synthetic rule: activate when temperature is strictly above 30 °C continuously for 10 seconds; reset the pending timer whenever temperature is 30 °C or lower. Once active, return to normal only below 28 °C. Trace: 31 °C from t=0 to 6; 30 °C from 6 to 8; 31 °C from 8 to 21; 29 °C from 21 to 30; 27 °C from 30 onward. Assume exact continuous observation for this analytical exercise.

1. The active alarm returns below twenty-eight
2. The alarm must activate because the value equals thirty
3. The pending timer resets because the value is at the threshold
4. The first six seconds are retained indefinitely

**Correct option(s):** 3

- Option 1: No alarm has yet activated and the value is thirty.
- Option 2: Activation requires strictly above thirty for ten seconds.
- Option 3: The rule says thirty or lower resets it.
- Option 4: The stated reset rule removes accumulated pending duration.

**CDFOS-Q0343 · single · operations**

When does the alarm first activate under the stated assumptions?

Synthetic training case — not a field record.

Synthetic rule: activate when temperature is strictly above 30 °C continuously for 10 seconds; reset the pending timer whenever temperature is 30 °C or lower. Once active, return to normal only below 28 °C. Trace: 31 °C from t=0 to 6; 30 °C from 6 to 8; 31 °C from 8 to 21; 29 °C from 21 to 30; 27 °C from 30 onward. Assume exact continuous observation for this analytical exercise.

1. t=21 seconds
2. t=18 seconds
3. t=10 seconds
4. t=8 seconds

**Correct option(s):** 2

- Option 1: The alarm has already met its activation condition at eighteen.
- Option 2: The qualifying interval beginning at eight reaches ten seconds then.
- Option 3: That would incorrectly retain the first interval across the reset.
- Option 4: That is the second excursion’s start, not its persistence completion.

**CDFOS-Q0344 · single · operations**

What happens when the active alarm reaches 29 °C?

Synthetic training case — not a field record.

Synthetic rule: activate when temperature is strictly above 30 °C continuously for 10 seconds; reset the pending timer whenever temperature is 30 °C or lower. Once active, return to normal only below 28 °C. Trace: 31 °C from t=0 to 6; 30 °C from 6 to 8; 31 °C from 8 to 21; 29 °C from 21 to 30; 27 °C from 30 onward. Assume exact continuous observation for this analytical exercise.

1. It becomes invalid solely because the value changed
2. It clears immediately because twenty-nine is below thirty
3. It remains active because the return threshold has not been crossed
4. Its original activation is retrospectively canceled

**Correct option(s):** 3

- Option 1: A normal changing measurement is not automatically bad quality.
- Option 2: Activation and return thresholds are different.
- Option 3: Return requires strictly below twenty-eight.
- Option 4: Later values do not erase the earlier event.

**CDFOS-Q0345 · single · operations**

When does the alarm return to normal?

Synthetic training case — not a field record.

Synthetic rule: activate when temperature is strictly above 30 °C continuously for 10 seconds; reset the pending timer whenever temperature is 30 °C or lower. Once active, return to normal only below 28 °C. Trace: 31 °C from t=0 to 6; 30 °C from 6 to 8; 31 °C from 8 to 21; 29 °C from 21 to 30; 27 °C from 30 onward. Assume exact continuous observation for this analytical exercise.

1. It can never return after persistence activation
2. t=30 seconds
3. t=21 seconds
4. t=28 seconds

**Correct option(s):** 2

- Option 1: The rule explicitly defines a return condition.
- Option 2: The trace becomes twenty-seven, below the stated return threshold.
- Option 3: Twenty-nine does not satisfy the return condition.
- Option 4: The time number does not itself equal a temperature condition.

**CDFOS-Q0346 · single · mechanism**

What does hysteresis accomplish in this rule?

Synthetic training case — not a field record.

Synthetic rule: activate when temperature is strictly above 30 °C continuously for 10 seconds; reset the pending timer whenever temperature is 30 °C or lower. Once active, return to normal only below 28 °C. Trace: 31 °C from t=0 to 6; 30 °C from 6 to 8; 31 °C from 8 to 21; 29 °C from 21 to 30; 27 °C from 30 onward. Assume exact continuous observation for this analytical exercise.

1. Different activation and return thresholds reduce repeated boundary transitions
2. It changes the sensor’s calibration range
3. It guarantees every real process is stable
4. It requires ten seconds continuously above thirty

**Correct option(s):** 1

- Option 1: It separates the direction-dependent state changes.
- Option 2: Alarm logic does not alter the physical measurement range.
- Option 3: Alarm behavior does not control all process dynamics.
- Option 4: That is the persistence timer’s role.

**CDFOS-Q0347 · single · operations**

What additional evidence is required on a sampled controller?

Synthetic training case — not a field record.

Synthetic rule: activate when temperature is strictly above 30 °C continuously for 10 seconds; reset the pending timer whenever temperature is 30 °C or lower. Once active, return to normal only below 28 °C. Trace: 31 °C from t=0 to 6; 30 °C from 6 to 8; 31 °C from 8 to 21; 29 °C from 21 to 30; 27 °C from 30 onward. Assume exact continuous observation for this analytical exercise.

1. Actual sampling, task timing and boundary behavior
2. A claim that all digital timers have zero timing uncertainty
3. Only the controller’s nominal model name
4. Only a copy of the same mathematical trace

**Correct option(s):** 1

- Option 1: Continuous analytical assumptions do not prove implementation timing.
- Option 2: That is not a valid implementation assumption.
- Option 3: Model identity alone does not measure task behavior.
- Option 4: The implementation may observe transitions differently.

**CDFOS-Q0348 · single · operations**

What should a test at exactly 28 °C establish?

Synthetic training case — not a field record.

Synthetic rule: activate when temperature is strictly above 30 °C continuously for 10 seconds; reset the pending timer whenever temperature is 30 °C or lower. Once active, return to normal only below 28 °C. Trace: 31 °C from t=0 to 6; 30 °C from 6 to 8; 31 °C from 8 to 21; 29 °C from 21 to 30; 27 °C from 30 onward. Assume exact continuous observation for this analytical exercise.

1. Reset the alarm to a pending-activation state at exactly 28 °C
2. The alarm remains active under the stated strictly-below return rule
3. Clear after ten seconds at exactly 28 °C
4. It always clears because twenty-eight is the printed threshold

**Correct option(s):** 2

- Option 1: The alarm is already active, and the stated return condition has not been met.
- Option 2: Equality does not meet the return condition.
- Option 3: A delay does not make equality satisfy a strictly-below return condition.
- Option 4: The comparison operator matters.

**CDFOS-Q0349 · single · diagnosis**

What should bad or stale input do?

Synthetic training case — not a field record.

Synthetic rule: activate when temperature is strictly above 30 °C continuously for 10 seconds; reset the pending timer whenever temperature is 30 °C or lower. Once active, return to normal only below 28 °C. Trace: 31 °C from t=0 to 6; 30 °C from 6 to 8; 31 °C from 8 to 21; 29 °C from 21 to 30; 27 °C from 30 onward. Assume exact continuous observation for this analytical exercise.

1. Automatically be treated as zero degrees
2. Be ignored without any indication to the operator
3. Automatically prove a high-temperature event
4. Follow a separately defined data-quality response tested with the alarm

**Correct option(s):** 4

- Option 1: That can hide a real unknown condition.
- Option 2: The consumer needs to know the observation is unreliable.
- Option 3: Invalid data do not establish a particular physical value.
- Option 4: The temperature rule alone does not specify invalid-data behavior.

**CDFOS-Q0350 · single · mechanism**

Why not increase the persistence delay solely to reduce alarm count?

Synthetic training case — not a field record.

Synthetic rule: activate when temperature is strictly above 30 °C continuously for 10 seconds; reset the pending timer whenever temperature is 30 °C or lower. Once active, return to normal only below 28 °C. Trace: 31 °C from t=0 to 6; 30 °C from 6 to 8; 31 °C from 8 to 21; 29 °C from 21 to 30; 27 °C from 30 onward. Assume exact continuous observation for this analytical exercise.

1. Persistence cannot affect detection time
2. It can postpone a required response beyond the process requirement
3. Every alarm must activate with zero delay
4. Longer delays always improve safety

**Correct option(s):** 2

- Option 1: The rule directly introduces a time condition.
- Option 2: Fewer alarms are not automatically better operational behavior.
- Option 3: Some justified filtering or persistence can be appropriate.
- Option 4: Effect depends on consequence and response needs.

**CDFOS-Q0351 · single · operations**

When is escalation due under the stated matrix?

Synthetic training case — not a field record.

Alarm A is detected at 02:00. The application submits an email at 02:01 and marks it Sent. The primary on-call address is obsolete, so no acknowledgment arrives. The matrix requires escalation five minutes after detection if unacknowledged. A retry job resubmits every two minutes and incorrectly restarts the escalation timer. A tested voice fallback is available.

1. 02:05
2. 02:06
3. Only at the next shift change
4. Five minutes after the final retry

**Correct option(s):** 1

- Option 1: The five-minute clock starts at detection at two o’clock.
- Option 2: That would start from the email submission instead.
- Option 3: The matrix specifies a much earlier deadline.
- Option 4: Retries do not redefine the stated origin.

**CDFOS-Q0352 · single · mechanism**

What does the application’s Sent state establish here?

Synthetic training case — not a field record.

Alarm A is detected at 02:00. The application submits an email at 02:01 and marks it Sent. The primary on-call address is obsolete, so no acknowledgment arrives. The matrix requires escalation five minutes after detection if unacknowledged. A retry job resubmits every two minutes and incorrectly restarts the escalation timer. A tested voice fallback is available.

1. The equipment was repaired
2. The escalation condition is satisfied
3. Submission to the next email stage
4. The on-call person read the message

**Correct option(s):** 3

- Option 1: Notification is not restoration.
- Option 2: The matrix still requires action when unacknowledged.
- Option 3: It does not prove recipient delivery or acknowledgment.
- Option 4: No acknowledgment arrived and the address is obsolete.

**CDFOS-Q0353 · single · mechanism**

What is wrong with restarting the timer on every retry?

Synthetic training case — not a field record.

Alarm A is detected at 02:00. The application submits an email at 02:01 and marks it Sent. The primary on-call address is obsolete, so no acknowledgment arrives. The matrix requires escalation five minutes after detection if unacknowledged. A retry job resubmits every two minutes and incorrectly restarts the escalation timer. A tested voice fallback is available.

1. It reduces the need for recipient ownership
2. It proves the email service is unavailable
3. It can postpone escalation indefinitely despite continued nonresponse
4. It necessarily improves the five-minute guarantee

**Correct option(s):** 3

- Option 1: Contacts still need controlled maintenance.
- Option 2: The case identifies a recipient and logic problem.
- Option 3: The retry behavior contradicts the defined detection-based deadline.
- Option 4: Repeated resets can defeat that guarantee.

**CDFOS-Q0354 · single · operations**

What is the correct use of the voice fallback?

Synthetic training case — not a field record.

Alarm A is detected at 02:00. The application submits an email at 02:01 and marks it Sent. The primary on-call address is obsolete, so no acknowledgment arrives. The matrix requires escalation five minutes after detection if unacknowledged. A retry job resubmits every two minutes and incorrectly restarts the escalation timer. A tested voice fallback is available.

1. Wait indefinitely for a successful email first
2. Call unrelated staff until someone happens to answer
3. Follow the approved route while retaining the failed primary-path evidence
4. Treat a dialed call as confirmed equipment restoration

**Correct option(s):** 3

- Option 1: That would miss the escalation requirement.
- Option 2: The matrix defines accountable roles and routes.
- Option 3: Fallback supports response without concealing the defect.
- Option 4: Contact attempt and service recovery are different stages.

**CDFOS-Q0355 · single · operations**

What should maintain the primary recipient information?

Synthetic training case — not a field record.

Alarm A is detected at 02:00. The application submits an email at 02:01 and marks it Sent. The primary on-call address is obsolete, so no acknowledgment arrives. The matrix requires escalation five minutes after detection if unacknowledged. A retry job resubmits every two minutes and incorrectly restarts the escalation timer. A tested voice fallback is available.

1. Only the alarm sensor’s calibration certificate
2. Only a supplier’s general website address
3. The assumption that a mailbox never changes
4. An accountable role/contact lifecycle with periodic validation

**Correct option(s):** 4

- Option 1: Calibration does not govern contact routing.
- Option 2: That may not reach the required on-call role.
- Option 3: The case demonstrates the risk of that assumption.
- Option 4: Addresses can become obsolete after staffing changes.

**CDFOS-Q0356 · single · operations**

Which test exercises the actual notification integration?

Synthetic training case — not a field record.

Alarm A is detected at 02:00. The application submits an email at 02:01 and marks it Sent. The primary on-call address is obsolete, so no acknowledgment arrives. The matrix requires escalation five minutes after detection if unacknowledged. A retry job resubmits every two minutes and incorrectly restarts the escalation timer. A tested voice fallback is available.

1. A test of the login password only
2. A screenshot of the configured address
3. A controlled alarm through detection, dispatch, acknowledgment and escalation
4. A personal email sent directly by the analyst

**Correct option(s):** 3

- Option 1: Authentication does not exercise notification behavior.
- Option 2: Configuration does not prove delivery or response.
- Option 3: It traverses the operational path being accepted.
- Option 4: That bypasses the alarm application and matrix logic.

**CDFOS-Q0357 · single · operations**

What should an acknowledgment timestamp mean?

Synthetic training case — not a field record.

Alarm A is detected at 02:00. The application submits an email at 02:01 and marks it Sent. The primary on-call address is obsolete, so no acknowledgment arrives. The matrix requires escalation five minutes after detection if unacknowledged. A retry job resubmits every two minutes and incorrectly restarts the escalation timer. A tested voice fallback is available.

1. The defined responder action indicating receipt or awareness
2. The time a queue accepted a message
3. The time the sensor first changed
4. The time the work order was permanently closed

**Correct option(s):** 1

- Option 1: Its semantics must be distinct from submission and repair.
- Option 2: That is an intermediate delivery stage.
- Option 3: That is detection/source timing.
- Option 4: Closure is a later process event.

**CDFOS-Q0358 · single · operations**

What should happen when an alarm clears before acknowledgment?

Synthetic training case — not a field record.

Alarm A is detected at 02:00. The application submits an email at 02:01 and marks it Sent. The primary on-call address is obsolete, so no acknowledgment arrives. The matrix requires escalation five minutes after detection if unacknowledged. A retry job resubmits every two minutes and incorrectly restarts the escalation timer. A tested voice fallback is available.

1. Delete all evidence because the physical condition ended
2. Automatically classify the original detection as false
3. Reset every unrelated alarm in the facility
4. Follow the defined event/notification policy and retain the history

**Correct option(s):** 4

- Option 1: That would hide response performance and recurrence.
- Option 2: A real transient can clear before response.
- Option 3: The event has a bounded scope.
- Option 4: Return to normal does not necessarily erase the need to review the event.

**CDFOS-Q0359 · single · operations**

What should be reported about the missed target?

Synthetic training case — not a field record.

Alarm A is detected at 02:00. The application submits an email at 02:01 and marks it Sent. The primary on-call address is obsolete, so no acknowledgment arrives. The matrix requires escalation five minutes after detection if unacknowledged. A retry job resubmits every two minutes and incorrectly restarts the escalation timer. A tested voice fallback is available.

1. A new five-minute target beginning after repair of the mailbox
2. A pass based only on the one-minute submission delay
3. The actual timeline, contact defect, timer defect and corrective actions
4. Only the number of retries

**Correct option(s):** 3

- Option 1: That would hide the original failure.
- Option 2: That measures a narrower stage than the required response.
- Option 3: The result should explain the observed failure without rewriting the rule.
- Option 4: Retry count does not establish timely accountability.

**CDFOS-Q0360 · single · operations**

What verifies the corrected escalation logic?

Synthetic training case — not a field record.

Alarm A is detected at 02:00. The application submits an email at 02:01 and marks it Sent. The primary on-call address is obsolete, so no acknowledgment arrives. The matrix requires escalation five minutes after detection if unacknowledged. A retry job resubmits every two minutes and incorrectly restarts the escalation timer. A tested voice fallback is available.

1. Only the absence of alarms during a quiet hour
2. Only a code-review statement that the timer looks correct
3. Only a successful primary email when someone answers immediately
4. A no-acknowledgment test that escalates at the defined detection-based deadline

**Correct option(s):** 4

- Option 1: No event does not test the logic.
- Option 2: Execution evidence is needed for the actual workflow.
- Option 3: That may never exercise escalation.
- Option 4: The negative case exercises the previously broken behavior.

**CDFOS-Q0361 · single · operations**

What is the correct engineering value for the supplied test signal?

Synthetic training case — not a field record.

Synthetic training loop: transmitter T7 represents 0–100 °C over 4–20 mA. A known 12 mA test signal reaches the input. The controller correctly reports 50 °C, but the gateway uses a 0–20 mA interpretation and the display shows 60 °C. The historian also labels T7 as asset P8 instead of P7. No physical live-plant signal is injected.

1. 50 °C
2. 75 °C
3. 12 °C
4. 60 °C

**Correct option(s):** 1

- Option 1: Twelve milliamperes is halfway through the sixteen-milliampere span.
- Option 2: That would correspond to three-quarters of the stated span.
- Option 3: Current and engineering temperature are different quantities.
- Option 4: That uses the incorrect zero-to-twenty interpretation.

**CDFOS-Q0362 · single · operations**

Which stage is localized by the controller being correct and the gateway wrong?

Synthetic training case — not a field record.

Synthetic training loop: transmitter T7 represents 0–100 °C over 4–20 mA. A known 12 mA test signal reaches the input. The controller correctly reports 50 °C, but the gateway uses a 0–20 mA interpretation and the display shows 60 °C. The historian also labels T7 as asset P8 instead of P7. No physical live-plant signal is injected.

1. The gateway transformation or its input interpretation
2. The physical transmitter is conclusively defective
3. The historian’s asset name causes the current conversion error
4. The controller’s scaling must be changed to sixty

**Correct option(s):** 1

- Option 1: The upstream controller already shows the expected value.
- Option 2: The synthetic signal and correct controller do not support that claim.
- Option 3: Identity mapping and numerical scaling are separate defects.
- Option 4: That would make a correct stage match an incorrect downstream result.

**CDFOS-Q0363 · single · mechanism**

Why can this error be difficult to notice?

Synthetic training case — not a field record.

Synthetic training loop: transmitter T7 represents 0–100 °C over 4–20 mA. A known 12 mA test signal reaches the input. The controller correctly reports 50 °C, but the gateway uses a 0–20 mA interpretation and the display shows 60 °C. The historian also labels T7 as asset P8 instead of P7. No physical live-plant signal is injected.

1. Sixty degrees is numerically plausible even though the mapping is wrong
2. A successful protocol response proves engineering correctness
3. The unit label automatically fixes the transfer function
4. Every scaling error produces a blank screen

**Correct option(s):** 1

- Option 1: Plausibility is weaker than verified transformation.
- Option 2: Transport can carry a wrongly interpreted value.
- Option 3: Displaying Celsius does not establish correct scaling.
- Option 4: Incorrect conversion can still yield ordinary numbers.

**CDFOS-Q0364 · single · mechanism**

What does the P8 history label threaten independently?

Synthetic training case — not a field record.

Synthetic training loop: transmitter T7 represents 0–100 °C over 4–20 mA. A known 12 mA test signal reaches the input. The controller correctly reports 50 °C, but the gateway uses a 0–20 mA interpretation and the display shows 60 °C. The historian also labels T7 as asset P8 instead of P7. No physical live-plant signal is injected.

1. Attribution of observations and alarms to the correct asset
2. The existence of the test signal
3. The mathematical current fraction
4. The controller’s analog input resolution necessarily

**Correct option(s):** 1

- Option 1: Correct numbers can still be assigned to the wrong equipment.
- Option 2: The case states the signal reached the input.
- Option 3: An asset label does not change the arithmetic.
- Option 4: No resolution defect is established.

**CDFOS-Q0365 · single · mechanism**

Why test more than one input value after correction?

Synthetic training case — not a field record.

Synthetic training loop: transmitter T7 represents 0–100 °C over 4–20 mA. A known 12 mA test signal reaches the input. The controller correctly reports 50 °C, but the gateway uses a 0–20 mA interpretation and the display shows 60 °C. The historian also labels T7 as asset P8 instead of P7. No physical live-plant signal is injected.

1. Because all sensors require the same universal test values
2. Because the same midpoint repeated proves the full range
3. To reveal slope, offset or boundary errors not shown by one point
4. To increase the number of screenshots without new evidence

**Correct option(s):** 3

- Option 1: The selected method and operating range govern test points.
- Option 2: Repeating one point does not explore range behavior.
- Option 3: Single-point agreement can conceal a wrong transfer function.
- Option 4: Additional points should test distinct parts of the mapping.

**CDFOS-Q0366 · single · implementation**

What would the stated correct mapping produce at 4 mA?

Synthetic training case — not a field record.

Synthetic training loop: transmitter T7 represents 0–100 °C over 4–20 mA. A known 12 mA test signal reaches the input. The controller correctly reports 50 °C, but the gateway uses a 0–20 mA interpretation and the display shows 60 °C. The historian also labels T7 as asset P8 instead of P7. No physical live-plant signal is injected.

1. 20 °C
2. An automatic physical sensor-failure diagnosis
3. 4 °C
4. 0 °C

**Correct option(s):** 4

- Option 1: That follows the incorrect zero-to-twenty scale.
- Option 2: The case defines four milliamperes as a valid endpoint.
- Option 3: It confuses signal current with temperature.
- Option 4: Four milliamperes is the defined lower engineering endpoint.

**CDFOS-Q0367 · single · implementation**

What should alarm retesting include after the mapping fix?

Synthetic training case — not a field record.

Synthetic training loop: transmitter T7 represents 0–100 °C over 4–20 mA. A known 12 mA test signal reaches the input. The controller correctly reports 50 °C, but the gateway uses a 0–20 mA interpretation and the display shows 60 °C. The historian also labels T7 as asset P8 instead of P7. No physical live-plant signal is injected.

1. Only whether TCP connects to the gateway
2. Only whether the alarm text is longer
3. The intended engineering threshold and associated asset at the consumer
4. Only the controller’s unchanged midpoint value

**Correct option(s):** 3

- Option 1: Connectivity does not test the alarm rule.
- Option 2: Text length does not establish correct triggering.
- Option 3: Both number and identity affect alarm interpretation.
- Option 4: The downstream alarm and mapping changed.

**CDFOS-Q0368 · single · operations**

What should happen to existing misattributed history?

Synthetic training case — not a field record.

Synthetic training loop: transmitter T7 represents 0–100 °C over 4–20 mA. A known 12 mA test signal reaches the input. The controller correctly reports 50 °C, but the gateway uses a 0–20 mA interpretation and the display shows 60 °C. The historian also labels T7 as asset P8 instead of P7. No physical live-plant signal is injected.

1. Assume every previous physical reading was wrong by the same amount
2. Delete all facility history regardless of affected scope
3. Silently rewrite all old records without provenance
4. Assess and document its treatment under the approved data process

**Correct option(s):** 4

- Option 1: The defect and time scope need evidence.
- Option 2: That is disproportionate to the identified point issue.
- Option 3: That destroys the record of what was originally stored.
- Option 4: Historical meaning may need correction or explicit qualification.

**CDFOS-Q0369 · single · operations**

Which claim is supported by this software signal exercise?

Synthetic training case — not a field record.

Synthetic training loop: transmitter T7 represents 0–100 °C over 4–20 mA. A known 12 mA test signal reaches the input. The controller correctly reports 50 °C, but the gateway uses a 0–20 mA interpretation and the display shows 60 °C. The historian also labels T7 as asset P8 instead of P7. No physical live-plant signal is injected.

1. The real installed loop is calibrated and correctly wired
2. The complete cooling process meets its thermal requirement
3. The represented conversion and mapping behavior under the stated conditions
4. The operator is authorized to inject signals into production

**Correct option(s):** 3

- Option 1: No physical live-plant test occurred.
- Option 2: The exercise covers an observation transformation.
- Option 3: It does not demonstrate real sensor placement, wiring or accuracy.
- Option 4: Analytical success does not grant live control authority.

**CDFOS-Q0370 · single · operations**

What should be retained in the point acceptance record?

Synthetic training case — not a field record.

Synthetic training loop: transmitter T7 represents 0–100 °C over 4–20 mA. A known 12 mA test signal reaches the input. The controller correctly reports 50 °C, but the gateway uses a 0–20 mA interpretation and the display shows 60 °C. The historian also labels T7 as asset P8 instead of P7. No physical live-plant signal is injected.

1. Only the date the screenshot was taken
2. Source identity, range, transform, consumer mapping and actual test results
3. Only the gateway’s product name
4. Only the final displayed number

**Correct option(s):** 2

- Option 1: Date is useful but insufficient for point acceptance.
- Option 2: These allow another reviewer to reproduce the interpretation.
- Option 3: Product identity alone does not define the selected map.
- Option 4: A single result cannot explain the configuration and scope.

**CDFOS-Q0371 · single · calculation**

How many records accumulate during the outage?

Synthetic training case — not a field record.

Synthetic historian produces exactly 2 records/s. Its tested queue holds 10,000 records under the stated record format. A database outage lasts 80 minutes. After reconnection, the system writes 4 records/s total while new records continue arriving at 2/s. Original source timestamps are preserved. Ignore additional overhead only for this calculation exercise.

1. 19,200 records
2. 9,600 records
3. 4,800 records
4. 160 records

**Correct option(s):** 2

- Option 1: That incorrectly uses the post-reconnection write rate.
- Option 2: Two per second multiplied by eighty times sixty seconds.
- Option 3: That is elapsed seconds, omitting the two-record rate.
- Option 4: That multiplies by minutes without converting to seconds.

**CDFOS-Q0372 · single · calculation**

How many queue slots remain at reconnection in this model?

Synthetic training case — not a field record.

Synthetic historian produces exactly 2 records/s. Its tested queue holds 10,000 records under the stated record format. A database outage lasts 80 minutes. After reconnection, the system writes 4 records/s total while new records continue arriving at 2/s. Original source timestamps are preserved. Ignore additional overhead only for this calculation exercise.

1. 400 slots
2. 4,000 slots
3. 9,600 slots
4. No finite queue capacity is relevant when timestamps exist

**Correct option(s):** 1

- Option 1: Ten thousand minus nine thousand six hundred.
- Option 2: That does not follow the stated queue and production values.
- Option 3: That is the occupied backlog, not free capacity.
- Option 4: Timestamps do not create storage capacity.

**CDFOS-Q0373 · single · operations**

What is the net backlog drainage rate after reconnection?

Synthetic training case — not a field record.

Synthetic historian produces exactly 2 records/s. Its tested queue holds 10,000 records under the stated record format. A database outage lasts 80 minutes. After reconnection, the system writes 4 records/s total while new records continue arriving at 2/s. Original source timestamps are preserved. Ignore additional overhead only for this calculation exercise.

1. 4 records/s
2. 6 records/s
3. 0 records/s
4. 2 records/s

**Correct option(s):** 4

- Option 1: That ignores ongoing new records.
- Option 2: Adding arrival rate reverses its effect on backlog.
- Option 3: The write rate exceeds ongoing arrival in the stated model.
- Option 4: Four written minus two newly arriving leaves two for backlog reduction.

**CDFOS-Q0374 · single · operations**

How long does the initial backlog take to drain?

Synthetic training case — not a field record.

Synthetic historian produces exactly 2 records/s. Its tested queue holds 10,000 records under the stated record format. A database outage lasts 80 minutes. After reconnection, the system writes 4 records/s total while new records continue arriving at 2/s. Original source timestamps are preserved. Ignore additional overhead only for this calculation exercise.

1. 160 minutes
2. 80 minutes
3. Immediately when the database reconnects
4. 40 minutes

**Correct option(s):** 2

- Option 1: That uses a one-record-per-second net rate not stated here.
- Option 2: Nine thousand six hundred divided by two is forty-eight hundred seconds.
- Option 3: Connection restoration does not eliminate queued work.
- Option 4: That incorrectly assigns all four writes per second to old records.

**CDFOS-Q0375 · single · mechanism**

What does successful backfill prove about live freshness during the outage?

Synthetic training case — not a field record.

Synthetic historian produces exactly 2 records/s. Its tested queue holds 10,000 records under the stated record format. A database outage lasts 80 minutes. After reconnection, the system writes 4 records/s total while new records continue arriving at 2/s. Original source timestamps are preserved. Ignore additional overhead only for this calculation exercise.

1. It does not retroactively satisfy the earlier live observation requirement
2. The database was never unavailable
3. Every operational decision received current data at the time
4. Source timestamps should be discarded to make the display current

**Correct option(s):** 1

- Option 1: Historical completeness and timely availability are separate.
- Option 2: The case explicitly includes an outage.
- Option 3: Later delivery cannot make earlier information timely.
- Option 4: That would hide the observation’s actual age.

**CDFOS-Q0376 · single · mechanism**

Why preserve original source timestamps?

Synthetic training case — not a field record.

Synthetic historian produces exactly 2 records/s. Its tested queue holds 10,000 records under the stated record format. A database outage lasts 80 minutes. After reconnection, the system writes 4 records/s total while new records continue arriving at 2/s. Original source timestamps are preserved. Ignore additional overhead only for this calculation exercise.

1. They prove every source value was physically accurate
2. They retain when observations were acquired rather than merely received
3. They eliminate all duplicate records automatically
4. They increase queue capacity beyond its tested limit

**Correct option(s):** 2

- Option 1: Time metadata do not establish sensor accuracy.
- Option 2: Historical meaning depends on the acquisition context.
- Option 3: Duplicate handling requires its own implementation behavior.
- Option 4: Timestamp fields do not create free storage.

**CDFOS-Q0377 · single · operations**

What assumption needs checking before applying this model to a real product?

Synthetic training case — not a field record.

Synthetic historian produces exactly 2 records/s. Its tested queue holds 10,000 records under the stated record format. A database outage lasts 80 minutes. After reconnection, the system writes 4 records/s total while new records continue arriving at 2/s. Original source timestamps are preserved. Ignore additional overhead only for this calculation exercise.

1. Only the nominal database record count, without stored record size or queue behavior
2. Record size, rate variation, queue limits and supported persistence behavior
3. Only the normal input rate, ignoring queued data delivered after reconnection
4. Only the lowest source rate seen during commissioning

**Correct option(s):** 2

- Option 1: A record count cannot establish actual buffering capacity or supported persistence behavior.
- Option 2: The simple count model intentionally omits additional constraints.
- Option 3: Recovery can impose a backlog drain or burst load beyond steady operation.
- Option 4: Sizing against a low observed rate can miss the intended peak and sustained operating profile.

**CDFOS-Q0378 · single · recovery**

What should identify historical replay at the consumer?

Synthetic training case — not a field record.

Synthetic historian produces exactly 2 records/s. Its tested queue holds 10,000 records under the stated record format. A database outage lasts 80 minutes. After reconnection, the system writes 4 records/s total while new records continue arriving at 2/s. Original source timestamps are preserved. Ignore additional overhead only for this calculation exercise.

1. A permanently green connection icon
2. A new asset identifier for every replayed record
3. The current receipt time alone
4. Source age and appropriate quality/history semantics

**Correct option(s):** 4

- Option 1: Connectivity says little about observation age.
- Option 2: Changing identity would corrupt the history relationship.
- Option 3: That can make old data appear fresh.
- Option 4: Old observations must not appear newly acquired.

**CDFOS-Q0379 · single · recovery**

Which recovery test checks data consistency?

Synthetic training case — not a field record.

Synthetic historian produces exactly 2 records/s. Its tested queue holds 10,000 records under the stated record format. A database outage lasts 80 minutes. After reconnection, the system writes 4 records/s total while new records continue arriving at 2/s. Original source timestamps are preserved. Ignore additional overhead only for this calculation exercise.

1. Compare expected source records with stored records, timestamps and duplicates
2. Only restart the source devices
3. Only inspect free disk space
4. Only open the historian login page

**Correct option(s):** 1

- Option 1: A count alone may conceal wrong or repeated content.
- Option 2: Restarting does not prove the database backlog reconciled.
- Option 3: Capacity does not establish correct persistence.
- Option 4: Login does not verify the recovered dataset.

**CDFOS-Q0380 · single · recovery**

What should the restoration report distinguish?

Synthetic training case — not a field record.

Synthetic historian produces exactly 2 records/s. Its tested queue holds 10,000 records under the stated record format. A database outage lasts 80 minutes. After reconnection, the system writes 4 records/s total while new records continue arriving at 2/s. Original source timestamps are preserved. Ignore additional overhead only for this calculation exercise.

1. Only the final queue count without its time or rate
2. Only the number of dashboard users
3. Current acquisition, backlog state, historical completeness and remaining gaps
4. Only the database process uptime

**Correct option(s):** 3

- Option 1: A snapshot alone may not explain whether recovery is progressing.
- Option 2: User count does not describe recovery completeness.
- Option 3: These describe different aspects of recovered monitoring function.
- Option 4: Uptime is narrower than useful service.

**CDFOS-Q0381 · single · mechanism**

Why is the apparent average-load improvement suspect?

Synthetic training case — not a field record.

A dashboard reports average rack load of 4 kW from 8 of 10 required racks; the two unobserved racks previously carried the highest loads. Samples are 15-minute averages, while the operating requirement concerns a one-minute peak. A cumulative network counter falls after a device restart. The report labels all missing values as zero and claims improved capacity.

1. The number eight is inherently too small for any observation
2. Every lower average is necessarily fabricated
3. An average can never be useful
4. The observed population excludes two previously high-load racks

**Correct option(s):** 4

- Option 1: Scope and purpose, not the number alone, determine usefulness.
- Option 2: The issue is unsupported interpretation, not established intent.
- Option 3: It can be useful for a properly defined population and decision.
- Option 4: Coverage change can bias the aggregate.

**CDFOS-Q0382 · single · operations**

How should the two missing rack values be represented?

Synthetic training case — not a field record.

A dashboard reports average rack load of 4 kW from 8 of 10 required racks; the two unobserved racks previously carried the highest loads. Samples are 15-minute averages, while the operating requirement concerns a one-minute peak. A cumulative network counter falls after a device restart. The report labels all missing values as zero and claims improved capacity.

1. As the smallest observed rack value
2. As permanently retired assets without review
3. As zero to keep the table numeric
4. As missing with the cause and impact on the report stated

**Correct option(s):** 4

- Option 1: An invented substitute needs no basis in the case.
- Option 2: Loss of telemetry does not establish retirement.
- Option 3: That would bias the result downward.
- Option 4: No observation is not a zero-load measurement.

**CDFOS-Q0383 · single · design**

Can fifteen-minute averages establish the one-minute peak requirement?

Synthetic training case — not a field record.

A dashboard reports average rack load of 4 kW from 8 of 10 required racks; the two unobserved racks previously carried the highest loads. Samples are 15-minute averages, while the operating requirement concerns a one-minute peak. A cumulative network counter falls after a device restart. The report labels all missing values as zero and claims improved capacity.

1. No time-series data can ever assess peaks
2. Yes; an average always equals the maximum
3. Not by themselves; shorter excursions can be hidden
4. Yes; the dashboard has a capacity title

**Correct option(s):** 3

- Option 1: Appropriate sampling and aggregation can support the requirement.
- Option 2: That is mathematically false.
- Option 3: The aggregation interval differs from the required event.
- Option 4: A label does not change the underlying data.

**CDFOS-Q0384 · single · mechanism**

What does the counter decrease after restart suggest?

Synthetic training case — not a field record.

A dashboard reports average rack load of 4 kW from 8 of 10 required racks; the two unobserved racks previously carried the highest loads. Samples are 15-minute averages, while the operating requirement concerns a one-minute peak. A cumulative network counter falls after a device restart. The report labels all missing values as zero and claims improved capacity.

1. Every previous counter sample is invalid
2. The restart proves a malicious write
3. A discontinuity or reset requiring rate-calculation handling
4. Negative physical traffic necessarily occurred

**Correct option(s):** 3

- Option 1: Earlier intervals may remain useful with their own context.
- Option 2: Ordinary restart behavior can explain the change.
- Option 3: Naive subtraction could produce a misleading negative rate.
- Option 4: Counters represent accumulated events, not reverse traffic quantities.

**CDFOS-Q0385 · single · operations**

What should accompany a computed counter rate?

Synthetic training case — not a field record.

A dashboard reports average rack load of 4 kW from 8 of 10 required racks; the two unobserved racks previously carried the highest loads. Samples are 15-minute averages, while the operating requirement concerns a one-minute peak. A cumulative network counter falls after a device restart. The report labels all missing values as zero and claims improved capacity.

1. Only the device’s inventory category
2. Only the final decimal number
3. Only a claim that the API returned success
4. Counter definition, interval and reset/wrap treatment

**Correct option(s):** 4

- Option 1: Category alone does not define counter semantics.
- Option 2: That omits the basis needed to interpret the rate.
- Option 3: Transport success does not validate the calculation.
- Option 4: The meaning and continuity of the source determine the result.

**CDFOS-Q0386 · single · operations**

Which observation would better support the peak decision?

Synthetic training case — not a field record.

A dashboard reports average rack load of 4 kW from 8 of 10 required racks; the two unobserved racks previously carried the highest loads. Samples are 15-minute averages, while the operating requirement concerns a one-minute peak. A cumulative network counter falls after a device restart. The report labels all missing values as zero and claims improved capacity.

1. A fifteen-minute average reported to extra decimal places
2. Appropriate time-resolution data covering all required racks
3. A longer averaging window on the same eight racks
4. A report excluding any rack that produces an alarm

**Correct option(s):** 2

- Option 1: Additional precision cannot reconstruct the unmeasured one-minute peak.
- Option 2: The evidence must match both population and interval.
- Option 3: That can hide peaks further and retains the coverage gap.
- Option 4: That would selectively remove important cases.

**CDFOS-Q0387 · single · mechanism**

What distinguishes capacity from capability?

Synthetic training case — not a field record.

A dashboard reports average rack load of 4 kW from 8 of 10 required racks; the two unobserved racks previously carried the highest loads. Samples are 15-minute averages, while the operating requirement concerns a one-minute peak. A cumulative network counter falls after a device restart. The report labels all missing values as zero and claims improved capacity.

1. Capability cannot include staffing or support dependencies
2. Capacity and availability are always identical percentages
3. Capability is merely the highest nameplate number
4. Capability includes whether the required function can be delivered under specified conditions

**Correct option(s):** 4

- Option 1: Those may affect whether the service can actually be delivered.
- Option 2: They describe different quantities and outcomes.
- Option 3: That omits dependencies and operating conditions.
- Option 4: Resources alone do not establish every failure or maintenance state.

**CDFOS-Q0388 · single · diagnosis**

What should a report do with the coverage defect?

Synthetic training case — not a field record.

A dashboard reports average rack load of 4 kW from 8 of 10 required racks; the two unobserved racks previously carried the highest loads. Samples are 15-minute averages, while the operating requirement concerns a one-minute peak. A cumulative network counter falls after a device restart. The report labels all missing values as zero and claims improved capacity.

1. Automatically reject every unaffected historical report
2. Assume it will resolve without tracking
3. Hide the defect to preserve confidence
4. Assign an owner and action while qualifying affected conclusions

**Correct option(s):** 4

- Option 1: Review should be scoped to the actual evidence impact.
- Option 2: Unowned gaps can persist.
- Option 3: Concealment creates false assurance.
- Option 4: The gap should lead to controlled resolution.

**CDFOS-Q0389 · single · operations**

What is needed before comparing this month with the previous one?

Synthetic training case — not a field record.

A dashboard reports average rack load of 4 kW from 8 of 10 required racks; the two unobserved racks previously carried the highest loads. Samples are 15-minute averages, while the operating requirement concerns a one-minute peak. A cumulative network counter falls after a device restart. The report labels all missing values as zero and claims improved capacity.

1. Only equal calendar duration without checking sampling intervals
2. Comparable definitions, population, intervals and data-quality treatment
3. Only a longer reporting narrative
4. Only matching averages without checking which racks were measured

**Correct option(s):** 2

- Option 1: Equal duration does not align measurement resolution or coverage.
- Option 2: Otherwise apparent trends can reflect measurement changes.
- Option 3: Length does not resolve incompatible data.
- Option 4: Different populations can produce misleading comparisons.

**CDFOS-Q0390 · single · operations**

Which conclusion is defensible now?

Synthetic training case — not a field record.

A dashboard reports average rack load of 4 kW from 8 of 10 required racks; the two unobserved racks previously carried the highest loads. Samples are 15-minute averages, while the operating requirement concerns a one-minute peak. A cumulative network counter falls after a device restart. The report labels all missing values as zero and claims improved capacity.

1. All ten racks average 4 kW and all peak limits pass
2. The facility has gained two racks of free capacity
3. The maintenance-state requirement is proven by the average
4. The eight observed racks average 4 kW under the stated sampling, with material limits

**Correct option(s):** 4

- Option 1: Two racks and the required time resolution are missing.
- Option 2: Unobserved assets are not freed resources.
- Option 3: No maintenance-state evidence is supplied.
- Option 4: It states the measured subset without claiming unsupported total capability.

#### Recall

**A monitoring matrix with a missing decision — Synthetic training case — not a field record.

A matrix lists pump temperature T1, unit “degrees,” poll rate “fast,” alarm recipient “operations,” and no response action. Two dashboards consume the same gateway cache. The pump’s approved operating decision requires a current °C value associated with asset P7, with an agreed maximum age. One dashboard labels it P8.**

The matrix lacks unambiguous units, timing, recipient role and action, and one consumer has the wrong asset association. Two displays do not remove the shared gateway dependency. Complete the point contract and verify the chain against a known source before using it for the operating decision.

**Persistence and hysteresis on a synthetic trace — Synthetic training case — not a field record.

Synthetic rule: activate when temperature is strictly above 30 °C continuously for 10 seconds; reset the pending timer whenever temperature is 30 °C or lower. Once active, return to normal only below 28 °C. Trace: 31 °C from t=0 to 6; 30 °C from 6 to 8; 31 °C from 8 to 21; 29 °C from 21 to 30; 27 °C from 30 onward. Assume exact continuous observation for this analytical exercise.**

The first six-second excursion does not activate. At t=6 the pending timer resets. The second qualifying interval begins at t=8 and reaches ten seconds at t=18. The active alarm remains at 29 °C and returns at t=30 when the value is below 28. Actual sampled implementation needs its own scan, timestamp and boundary tests.

**Notification sent but no accountable response — Synthetic training case — not a field record.

Alarm A is detected at 02:00. The application submits an email at 02:01 and marks it Sent. The primary on-call address is obsolete, so no acknowledgment arrives. The matrix requires escalation five minutes after detection if unacknowledged. A retry job resubmits every two minutes and incorrectly restarts the escalation timer. A tested voice fallback is available.**

The escalation deadline is 02:05 from detection, not five minutes after each retry. Sent proves submission only at the stated application stage. Correct the timer semantics and recipient ownership, use the approved fallback and test the complete route with controlled events. Keep delivery, acknowledgment and actual response timestamps distinct.

**Scaling and point identity through a gateway — Synthetic training case — not a field record.

Synthetic training loop: transmitter T7 represents 0–100 °C over 4–20 mA. A known 12 mA test signal reaches the input. The controller correctly reports 50 °C, but the gateway uses a 0–20 mA interpretation and the display shows 60 °C. The historian also labels T7 as asset P8 instead of P7. No physical live-plant signal is injected.**

The source fraction is (12−4)/16 = 0.5, so the correct value is 50 °C. The gateway’s different transfer function explains its plausible 60 °C. Correct the approved mapping and independently fix the asset association. Retest several values, alarm behavior and history; software injection does not establish physical calibration or wiring.

**Historian buffering and useful monitoring recovery — Synthetic training case — not a field record.

Synthetic historian produces exactly 2 records/s. Its tested queue holds 10,000 records under the stated record format. A database outage lasts 80 minutes. After reconnection, the system writes 4 records/s total while new records continue arriving at 2/s. Original source timestamps are preserved. Ignore additional overhead only for this calculation exercise.**

The outage creates 9,600 records, leaving 400 queue slots at reconnection. Backlog drains at the net rate 4−2 = 2 records/s, taking 4,800 seconds or 80 minutes. Retained history may recover, but operators lacked timely database-backed observations during the outage. Real acceptance must include record size, limits, quality, duplicates and actual implementation behavior.

**Capacity reporting with incomplete and changing observations — Synthetic training case — not a field record.

A dashboard reports average rack load of 4 kW from 8 of 10 required racks; the two unobserved racks previously carried the highest loads. Samples are 15-minute averages, while the operating requirement concerns a one-minute peak. A cumulative network counter falls after a device restart. The report labels all missing values as zero and claims improved capacity.**

The population and measurement interval do not support the claimed peak-capacity conclusion. Missing racks must remain unobserved, not zero. Counter discontinuity after restart needs explicit treatment before rates are calculated. Capacity, service availability and capability in a maintenance state require their own defined evidence.

#### References

- [EPI CDFOS public syllabus](https://www.epi-ap.com/services/1/3/136)
- [HSE maintenance guidance — jurisdiction-specific reference](https://www.hse.gov.uk/work-equipment-machinery/maintenance.htm)
- [HSE permit-to-work systems — supporting reference](https://www.hse.gov.uk/comah/sragtech/techmeaspermit.htm)
- [NIST metrological traceability policy](https://www.nist.gov/calibrations/traceability)

## CDFOS-M07 — Facilities projects from mandate to operational handover

### CDFOS-L07 — Facilities projects from mandate to operational handover

Estimated study time: 120 minutes before independent work. Prerequisite chapters: CDFOS-L06

## A facilities project changes an operating system

A project is a temporary organized effort to deliver a defined outcome. In an operating data center, the outcome might be an accepted monitoring extension, a rack installation or a maintenance-system improvement. The project’s technical deliverable and its operational benefit are related but different. Installing sensors is a deliverable; trustworthy actionable monitoring is the intended capability. Define the need, scope, constraints, sponsor, owner, stakeholders, authority and acceptance before treating a list of equipment as the complete project.

Initiation should establish why the work is justified and what success means. Identify the service problem or opportunity, expected benefit, major assumptions, dependencies and boundaries. A project charter gives the manager a defined mandate; it is not unlimited authority to change the live facility. Record who can approve scope, spend, risk and operational cutover. A design or installation task may require specialist authority outside the project manager’s competence. The charter’s D1 exclusion and D2/D3 specialist boundaries still apply even when the work is organized as a project.

Requirements should be testable and traceable. “Improve monitoring” is incomplete until the assets, points, accuracy or quality, freshness, alarm response, retention, roles and recovery behavior are defined. Distinguish mandatory acceptance from desirable enhancements. Record requirement sources and owners so conflicts can be resolved through an accountable decision. An assumption that a vendor provides a required license or protocol driver should be verified before it becomes a hidden schedule dependency.

## Organize work around dependencies and acceptance

Break the outcome into manageable work packages with clear deliverables, responsibility and completion criteria. Include design review, procurement, access and licensing, installation, configuration, tests, training, documentation, recovery preparation and handover. Omitting commissioning from the schedule does not make it unnecessary. A work package is complete when its defined output is accepted, not merely when someone reports hours spent.

Dependencies determine feasible sequencing. A point-mapping test may depend on approved identifiers and a working source interface; operator training should use the accepted configuration or clearly identify pending changes. Distinguish tasks that can proceed in parallel from those that require a predecessor’s output. In a simple deterministic schedule, the longest dependency path governs the earliest finish. Extra resources on a noncritical task may not shorten the overall project. Real schedules also need resource, access-window and uncertainty assessment.

Plan the operating interface deliberately. A technically finished installation may need a specific work window, permits, staffing and customer communication before cutover. Reserve time for prechecks, failed tests, recovery and final observation. Coordinate with other work so that parallel projects do not remove the same remaining path or overload a shared team. The project plan should identify readiness gates and a decision owner for postponement when conditions no longer match the approved basis.

## Risks, issues and changes require different actions

A risk is an uncertain event or condition that could affect the outcome. An issue is a condition that has occurred and needs resolution. Record risk cause, consequence, likelihood/impact assessment appropriate to the method, owner, response and trigger. Do not hide a realized issue in a risk register merely to preserve an optimistic status. A supplier delay that has already missed its date is an issue; uncertainty about a future spare delivery remains a risk until more is known.

A change request evaluates a proposed difference from the agreed scope or baseline. Assess effect on requirements, cost, schedule, interfaces, operating risk, testing, documentation and benefits. A small hardware substitution can create a large integration or support change. Conversely, a legitimate improvement can be accepted when its effect is understood and authorized. Keep the decision and updated baseline traceable; do not allow scope to grow through informal conversations that nobody incorporates into the plan.

Distinguish contingency from an unexamined assumption. A contingency response should state the trigger, action, resources and authority. “The team will work harder” is not a complete recovery plan for an unavailable vendor license or an incompatible interface. Reassess the plan when new evidence changes the assumptions. Communicate the resulting options and tradeoffs to the appropriate decision-maker instead of presenting an unsupported single finish date.

## Execute and control using evidence

Execution coordinates people and suppliers to produce the approved outputs. The project manager maintains the integrated view, while technical owners assess their domain work. Inspect delivered identity and quality before installation. Use controlled design and configuration documents. Record deviations, defects, test results and decisions. A vendor’s completion notice is evidence of its claim, not automatically proof that the facility’s acceptance criteria passed.

Monitor progress against accepted work, not expenditure alone. Spending most of the budget may mean equipment has arrived while integration remains untested. A percentage-complete figure should have a stated basis. Report material blockers, forecast completion, remaining uncertainty and the action needed. Use issue and decision logs to prevent the same unresolved question from being rediscovered by different teams. Preserve the difference between a technical test failure, a scope decision and a resource delay.

Quality control compares outputs with requirements; assurance examines whether the processes used to produce and verify them are suitable. Both matter. A test plan should identify the environment and fidelity, test data, expected result, evidence, reviewer and treatment of failure. An independent acceptance review can reveal that a demonstration used a different firmware or bypassed an important permission. Do not broaden a laboratory result into a field claim without the required evidence.

## Close into operation, then evaluate the benefit

Project closure is a controlled transfer of an accepted capability. Handover should include as-built information, asset and configuration records, operating and emergency procedures, roles, training, spare/tool requirements, backup and recovery material, supplier support, known defects and any agreed restrictions. The receiving operator should demonstrate that the information is usable for a representative task. A folder of documents that nobody can access during an outage is not a complete operational handover.

Open defects need explicit disposition. Some may prevent acceptance; others may be conditionally accepted under the site’s policy with an owner, consequence, due date and compensating condition. “Minor” is not a sufficient description when a defect affects alarm delivery or recovery. Ensure warranty and support responsibilities are clear and that temporary construction or commissioning access is removed or reauthorized for operations.

Lessons learned should connect observed outcomes to future changes. Identify what worked, what failed, why, and what procedure, design template, supplier requirement or training should change. Avoid a list of vague aspirations without ownership. Benefits may require a later operating period to evaluate: a project can deliver its accepted system before enough data exist to prove reduced restoration time or energy use. Assign benefit ownership, baseline, measurement method and review date rather than declaring every forecast realized at the closing meeting.

The independent project exercise produces a charter, requirement/acceptance matrix, dependency schedule, risk/issue/change decisions and operational handover. It uses synthetic evidence and does not authorize construction, electrical switching or live cutover. Practical portfolio acceptance requires the appropriate actual implementation and review evidence alongside this planning competence.

#### Worked demonstrations

**Project charter and an ambiguous monitoring outcome**

Synthetic training case — not a field record.

A sponsor requests “better EPMS visibility” for twelve meters. Procurement proposes buying a dashboard license immediately. Operations requires correct asset mapping, a five-second maximum source age, alarm delivery, ninety-day history and a tested restore. The supplier assumes the existing gateway license includes all drivers, but nobody has checked.

**Reasoning:** Define the accepted operational capability before committing the purchase. The twelve-meter scope and measurable functions form the requirement set. Assign sponsor, project manager, technical owners and operational acceptance authority. Verify the driver entitlement as an assumption/dependency; buying a dashboard alone does not prove the required service.

**Dependency schedule and a controlled scope change**

Synthetic training case — not a field record.

Synthetic schedule: design A takes 3 days. After A, procurement B takes 5 days and procedure drafting C takes 2 days in parallel. Installation D takes 2 days after B and C. Acceptance E takes 1 day after D. A proposed extra interface adds 2 days of design and needs an unconfirmed license. Assume resources are available and no other calendar constraints for the baseline calculation.

**Reasoning:** The baseline critical path is A–B–D–E: 3+5+2+1 = 11 days. C finishes before B and has three days of simple path slack. The extra interface changes scope and a dependency; assess licensing, acceptance and schedule before approval. Real cutover windows and resource constraints must be added before treating the arithmetic as a delivery promise.

**Execution report with cost ahead of acceptance**

Synthetic training case — not a field record.

A project has spent 80% of its budget. Hardware is delivered, but only 4 of 12 point integrations have passed. One supplier’s interface document conflicts with the integrator’s data type. A promised license delivery date passed yesterday. The status report says “80% complete, no issues” based on expenditure.

**Reasoning:** Spending and accepted work are different measures. Report the passed integrations and remaining work, classify the missed license commitment as an issue, and assign the conflicting interface for resolution with source/version evidence. Update the forecast and decision needs rather than retaining a misleading percentage.

**Operational handover and later benefit verification**

Synthetic training case — not a field record.

The new monitoring service passes its defined functional tests. Its backup procedure is stored in a supplier portal unavailable to the night shift. One minor-looking defect routes alarms to an old team mailbox. Temporary installer accounts remain active. The sponsor wants to claim a 30% reduction in restoration time immediately, although no post-launch incidents have occurred.

**Reasoning:** Functional delivery is not complete operational handover when required recovery information and alarm ownership are unusable. Resolve or formally disposition defects and temporary access. Benefit realization needs a baseline, comparable observations and an owner after launch; it cannot be inferred without the relevant operating evidence.

#### Guided practice

Prepare a charter, dependency schedule and acceptance plan for the twelve-meter project, then resolve the release and handover defects before claiming benefits.

**Hint:** Separate purchased output, accepted capability and later measured benefit.

**Worked solution:** Define accountable scope and acceptance; verify licensing assumptions; calculate the controlling dependency path within stated assumptions; handle realized delays as issues; assess scope changes before committing; retain functional and process evidence; hand over usable recovery and support information; assign benefit measurement after launch.

#### Independent task

Environment: analytical

Defend a complete small-project package using synthetic planning and delivery evidence.

**Packaged starter material**

- course_labs/CDFOS/README.md
- course_labs/CDFOS/fixture.json
- course_labs/CDFOS/assessment_template.md
- course_labs/CDFOS/lab.py
- course_labs/CDFOS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- Charter and requirement/acceptance matrix
- Dependency schedule with assumptions
- Risk/issue/change decisions
- Operational handover and benefit-review plan

**Acceptance criteria**

- The schedule includes acceptance and recovery readiness.
- Status reflects accepted work rather than spend alone.
- Closure and claimed benefits match the evidence available.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer. The bundled calculator was executed against supplied synthetic fixtures; its numerical checks do not grade physical work or professional authorization.

#### Chapter practice

**CDFOS-Q0391 · single · operations**

What is the strongest project outcome statement?

Synthetic training case — not a field record.

A sponsor requests “better EPMS visibility” for twelve meters. Procurement proposes buying a dashboard license immediately. Operations requires correct asset mapping, a five-second maximum source age, alarm delivery, ninety-day history and a tested restore. The supplier assumes the existing gateway license includes all drivers, but nobody has checked.

1. Accepted current meter visibility with mapping, alarms, history and restoration
2. Finish before the next report regardless of function
3. Increase the number of screen widgets
4. Purchase one dashboard license

**Correct option(s):** 1

- Option 1: It describes the operational capability required by the customer.
- Option 2: A date alone does not define acceptable delivery.
- Option 3: Display quantity does not establish trustworthy monitoring.
- Option 4: That is a procurement output, not the complete benefit.

**CDFOS-Q0392 · single · operations**

What should happen to the driver-license assumption?

Synthetic training case — not a field record.

A sponsor requests “better EPMS visibility” for twelve meters. Procurement proposes buying a dashboard license immediately. Operations requires correct asset mapping, a five-second maximum source age, alarm delivery, ninety-day history and a tested restore. The supplier assumes the existing gateway license includes all drivers, but nobody has checked.

1. Verify entitlement and compatibility before relying on it in the plan
2. Remove it from the risk register to avoid delay
3. Assume every gateway supports every meter driver
4. Treat it as confirmed because the supplier mentioned it

**Correct option(s):** 1

- Option 1: It can affect cost, schedule and integration.
- Option 2: Omission does not create the missing entitlement.
- Option 3: Product and license support are specific.
- Option 4: An assumption is not verified evidence.

**CDFOS-Q0393 · single · operations**

Who should own the integrated project plan?

Synthetic training case — not a field record.

A sponsor requests “better EPMS visibility” for twelve meters. Procurement proposes buying a dashboard license immediately. Operations requires correct asset mapping, a five-second maximum source age, alarm delivery, ninety-day history and a tested restore. The supplier assumes the existing gateway license includes all drivers, but nobody has checked.

1. The monitoring application itself
2. The appointed project manager within the chartered authority
3. Every supplier independently with no coordinating owner
4. The software installer alone regardless of scope

**Correct option(s):** 2

- Option 1: A tool does not hold organizational authority.
- Option 2: Integration needs a defined responsible role.
- Option 3: Separate plans can leave interface gaps.
- Option 4: Installation is only part of the outcome.

**CDFOS-Q0394 · single · operations**

Who should accept the returned operational capability?

Synthetic training case — not a field record.

A sponsor requests “better EPMS visibility” for twelve meters. Procurement proposes buying a dashboard license immediately. Operations requires correct asset mapping, a five-second maximum source age, alarm delivery, ninety-day history and a tested restore. The supplier assumes the existing gateway license includes all drivers, but nobody has checked.

1. The supplier automatically upon shipment
2. Procurement solely because the invoice is paid
3. The designated operational owner using agreed criteria
4. The project sponsor solely because the agreed delivery date was met

**Correct option(s):** 3

- Option 1: Shipment precedes integration and functional tests.
- Option 2: Financial completion does not establish service acceptance.
- Option 3: The receiving function must be able to use and sustain it.
- Option 4: Schedule completion does not replace operational-owner acceptance against capability criteria.

**CDFOS-Q0395 · single · design**

Which requirement is directly measurable?

Synthetic training case — not a field record.

A sponsor requests “better EPMS visibility” for twelve meters. Procurement proposes buying a dashboard license immediately. Operations requires correct asset mapping, a five-second maximum source age, alarm delivery, ninety-day history and a tested restore. The supplier assumes the existing gateway license includes all drivers, but nobody has checked.

1. The interface should feel modern
2. Source age at the consumer must not exceed five seconds under stated conditions
3. The vendor should be world class
4. The project should have no problems

**Correct option(s):** 2

- Option 1: That is subjective without a defined criterion.
- Option 2: It defines a quantity and a limit needing a test method.
- Option 3: That does not specify an operational result.
- Option 4: An aspiration is not a testable function.

**CDFOS-Q0396 · single · recovery**

Why include restoration in scope at initiation?

Synthetic training case — not a field record.

A sponsor requests “better EPMS visibility” for twelve meters. Procurement proposes buying a dashboard license immediately. Operations requires correct asset mapping, a five-second maximum source age, alarm delivery, ninety-day history and a tested restore. The supplier assumes the existing gateway license includes all drivers, but nobody has checked.

1. It can always be added without cost or schedule effect
2. A license purchase proves backup compatibility
3. Restoration matters only after the first real incident
4. It affects artifacts, dependencies, testing and operational readiness

**Correct option(s):** 4

- Option 1: New requirements can change the plan.
- Option 2: Procurement does not test restoration.
- Option 3: Preparedness requires a defined method beforehand.
- Option 4: Recovery is not automatically supplied by installation.

**CDFOS-Q0397 · single · design**

What should the scope boundary say about meters beyond the twelve?

Synthetic training case — not a field record.

A sponsor requests “better EPMS visibility” for twelve meters. Procurement proposes buying a dashboard license immediately. Operations requires correct asset mapping, a five-second maximum source age, alarm delivery, ninety-day history and a tested restore. The supplier assumes the existing gateway license includes all drivers, but nobody has checked.

1. They are automatically included whenever someone requests them
2. Whether they are excluded, future work or separately approved additions
3. They can never be added through a change
4. Their presence makes the twelve-meter requirement invalid

**Correct option(s):** 2

- Option 1: That creates unmanaged scope growth.
- Option 2: The team needs a controlled boundary.
- Option 3: A reviewed change can legitimately revise scope.
- Option 4: The defined subset can still be a valid project.

**CDFOS-Q0398 · single · design**

What should connect a requirement to project acceptance?

Synthetic training case — not a field record.

A sponsor requests “better EPMS visibility” for twelve meters. Procurement proposes buying a dashboard license immediately. Operations requires correct asset mapping, a five-second maximum source age, alarm delivery, ninety-day history and a tested restore. The supplier assumes the existing gateway license includes all drivers, but nobody has checked.

1. Only its inclusion in the scope statement without verification
2. Its implementation item, test, evidence and approving role
3. Only the supplier quotation line
4. Only a verbal assurance that implementation followed the requirement

**Correct option(s):** 2

- Option 1: Being planned does not demonstrate that it was implemented and passed.
- Option 2: Traceability makes completion assessable.
- Option 3: Commercial description may not prove the function.
- Option 4: Acceptance needs the specified test and retained result.

**CDFOS-Q0399 · single · operations**

What authority does the charter give?

Synthetic training case — not a field record.

A sponsor requests “better EPMS visibility” for twelve meters. Procurement proposes buying a dashboard license immediately. Operations requires correct asset mapping, a five-second maximum source age, alarm delivery, ninety-day history and a tested restore. The supplier assumes the existing gateway license includes all drivers, but nobody has checked.

1. Automatic permission for any electrical work
2. Freedom to omit safety gates when the schedule is tight
3. Ownership of every future facility programme
4. The defined mandate and decision boundaries recorded in it

**Correct option(s):** 4

- Option 1: Specialist competence and site authorization remain.
- Option 2: Project urgency does not remove those requirements.
- Option 3: The mandate is scoped to the authorized project.
- Option 4: It does not grant unlimited live-site authority.

**CDFOS-Q0400 · single · operations**

What is a defensible procurement gate?

Synthetic training case — not a field record.

A sponsor requests “better EPMS visibility” for twelve meters. Procurement proposes buying a dashboard license immediately. Operations requires correct asset mapping, a five-second maximum source age, alarm delivery, ninety-day history and a tested restore. The supplier assumes the existing gateway license includes all drivers, but nobody has checked.

1. A promise to discover all dependencies after installation
2. A low price before any scope definition
3. A reviewed requirement and supported solution/entitlement basis
4. A visually attractive demonstration alone

**Correct option(s):** 3

- Option 1: Hidden dependencies can defeat delivery and operations.
- Option 2: Price cannot establish that the product meets the need.
- Option 3: The purchase should serve the accepted outcome.
- Option 4: A demo may omit interfaces and recovery.

**CDFOS-Q0401 · single · calculation**

What is the baseline earliest finish under the stated assumptions?

Synthetic training case — not a field record.

Synthetic schedule: design A takes 3 days. After A, procurement B takes 5 days and procedure drafting C takes 2 days in parallel. Installation D takes 2 days after B and C. Acceptance E takes 1 day after D. A proposed extra interface adds 2 days of design and needs an unconfirmed license. Assume resources are available and no other calendar constraints for the baseline calculation.

1. 11 days
2. 8 days
3. 13 days
4. 6 days

**Correct option(s):** 1

- Option 1: The longest dependency path is three plus five plus two plus one.
- Option 2: That omits the initial design duration.
- Option 3: That incorrectly adds the parallel two-day task sequentially.
- Option 4: That ignores several required predecessors.

**CDFOS-Q0402 · single · calculation**

Which baseline path controls the finish?

Synthetic training case — not a field record.

Synthetic schedule: design A takes 3 days. After A, procurement B takes 5 days and procedure drafting C takes 2 days in parallel. Installation D takes 2 days after B and C. Acceptance E takes 1 day after D. A proposed extra interface adds 2 days of design and needs an unconfirmed license. Assume resources are available and no other calendar constraints for the baseline calculation.

1. B–C only
2. A–B–D–E
3. A–C–D–E
4. E alone

**Correct option(s):** 2

- Option 1: Those tasks do not represent the full dependency chain.
- Option 2: Procurement is longer than the parallel procedure task.
- Option 3: That path is shorter under the stated durations.
- Option 4: Acceptance depends on completed installation and predecessors.

**CDFOS-Q0403 · single · calculation**

How much simple path slack does C have relative to B?

Synthetic training case — not a field record.

Synthetic schedule: design A takes 3 days. After A, procurement B takes 5 days and procedure drafting C takes 2 days in parallel. Installation D takes 2 days after B and C. Acceptance E takes 1 day after D. A proposed extra interface adds 2 days of design and needs an unconfirmed license. Assume resources are available and no other calendar constraints for the baseline calculation.

1. 2 days
2. 0 days
3. 3 days
4. 5 days

**Correct option(s):** 3

- Option 1: That is C’s duration, not its slack.
- Option 2: C does not govern the join under the stated assumptions.
- Option 3: After A, C takes two days while B takes five.
- Option 4: That is B’s duration without subtracting C.

**CDFOS-Q0404 · single · operations**

Would reducing C by one day shorten the baseline project?

Synthetic training case — not a field record.

Synthetic schedule: design A takes 3 days. After A, procurement B takes 5 days and procedure drafting C takes 2 days in parallel. Installation D takes 2 days after B and C. Acceptance E takes 1 day after D. A proposed extra interface adds 2 days of design and needs an unconfirmed license. Assume resources are available and no other calendar constraints for the baseline calculation.

1. Yes, every task reduction shortens the project equally
2. No task reduction can ever affect a project
3. No, if other assumptions remain unchanged
4. Yes, by two days

**Correct option(s):** 3

- Option 1: Parallel dependencies can absorb the change.
- Option 2: Critical-path reductions can change the finish.
- Option 3: B still controls when installation can start.
- Option 4: The proposed reduction is only one day and off the critical path.

**CDFOS-Q0405 · single · operations**

How should the extra interface request be handled?

Synthetic training case — not a field record.

Synthetic schedule: design A takes 3 days. After A, procurement B takes 5 days and procedure drafting C takes 2 days in parallel. Installation D takes 2 days after B and C. Acceptance E takes 1 day after D. A proposed extra interface adds 2 days of design and needs an unconfirmed license. Assume resources are available and no other calendar constraints for the baseline calculation.

1. Assess and authorize its scope, license, schedule and acceptance effects
2. Reject it automatically because all changes are prohibited
3. Add it informally because only two design days are stated
4. Call it maintenance to avoid change control

**Correct option(s):** 1

- Option 1: The change adds both work and an unresolved dependency.
- Option 2: A justified reviewed change may be acceptable.
- Option 3: Licensing and downstream tests may also change.
- Option 4: Renaming does not remove its project impact.

**CDFOS-Q0406 · single · mechanism**

What does the unconfirmed license represent before it causes a delay?

Synthetic training case — not a field record.

Synthetic schedule: design A takes 3 days. After A, procurement B takes 5 days and procedure drafting C takes 2 days in parallel. Installation D takes 2 days after B and C. Acceptance E takes 1 day after D. A proposed extra interface adds 2 days of design and needs an unconfirmed license. Assume resources are available and no other calendar constraints for the baseline calculation.

1. A dependency uncertainty requiring a risk response and owner
2. A completed issue with a known resolution date
3. A reason to remove acceptance testing
4. A guaranteed zero-cost resource

**Correct option(s):** 1

- Option 1: Its availability can affect delivery.
- Option 2: Neither the delay nor entitlement is established yet.
- Option 3: Testing remains part of the required outcome.
- Option 4: The case says it is unconfirmed.

**CDFOS-Q0407 · single · operations**

What must be added before promising a live cutover date?

Synthetic training case — not a field record.

Synthetic schedule: design A takes 3 days. After A, procurement B takes 5 days and procedure drafting C takes 2 days in parallel. Installation D takes 2 days after B and C. Acceptance E takes 1 day after D. A proposed extra interface adds 2 days of design and needs an unconfirmed license. Assume resources are available and no other calendar constraints for the baseline calculation.

1. Only a more precise decimal day count
2. Actual resource, access-window and operating constraints
3. Only a larger progress chart
4. Only the project manager’s preferred date

**Correct option(s):** 2

- Option 1: Numerical precision cannot supply missing constraints.
- Option 2: The calculation intentionally assumes those away.
- Option 3: Chart size does not alter the plan.
- Option 4: Preference does not determine feasible dependencies.

**CDFOS-Q0408 · single · calculation**

If procurement slips two days with no other change, what is the new earliest finish?

Synthetic training case — not a field record.

Synthetic schedule: design A takes 3 days. After A, procurement B takes 5 days and procedure drafting C takes 2 days in parallel. Installation D takes 2 days after B and C. Acceptance E takes 1 day after D. A proposed extra interface adds 2 days of design and needs an unconfirmed license. Assume resources are available and no other calendar constraints for the baseline calculation.

1. 15 days
2. 9 days
3. 13 days
4. 11 days

**Correct option(s):** 3

- Option 1: That adds four days rather than the stated two.
- Option 2: A delay cannot shorten this unchanged dependency chain.
- Option 3: The critical path grows by the two-day delay.
- Option 4: There is no stated procurement slack on the controlling path.

**CDFOS-Q0409 · single · operations**

What should a contingency for license failure specify?

Synthetic training case — not a field record.

Synthetic schedule: design A takes 3 days. After A, procurement B takes 5 days and procedure drafting C takes 2 days in parallel. Installation D takes 2 days after B and C. Acceptance E takes 1 day after D. A proposed extra interface adds 2 days of design and needs an unconfirmed license. Assume resources are available and no other calendar constraints for the baseline calculation.

1. Only that the team will work harder
2. Only deletion of the risk entry
3. Only a new project name
4. Trigger, supported alternative, resources and decision authority

**Correct option(s):** 4

- Option 1: Effort cannot necessarily create an unavailable entitlement.
- Option 2: Removing the record does not remove uncertainty.
- Option 3: Administrative relabeling does not resolve the dependency.
- Option 4: A usable response needs more than an optimistic statement.

**CDFOS-Q0410 · single · operations**

What should the updated baseline preserve after an approved change?

Synthetic training case — not a field record.

Synthetic schedule: design A takes 3 days. After A, procurement B takes 5 days and procedure drafting C takes 2 days in parallel. Installation D takes 2 days after B and C. Acceptance E takes 1 day after D. A proposed extra interface adds 2 days of design and needs an unconfirmed license. Assume resources are available and no other calendar constraints for the baseline calculation.

1. Only an informal chat message without owner
2. Only the added hardware list
3. Only the original date to avoid stakeholder concern
4. The decision, revised scope/dependencies and affected acceptance criteria

**Correct option(s):** 4

- Option 1: The change must be durable and authorized.
- Option 2: Schedule, interfaces and verification can also change.
- Option 3: An obsolete date can mislead decisions.
- Option 4: The project needs one traceable accepted plan.

**CDFOS-Q0411 · single · mechanism**

Why is 80% expenditure not proof of 80% completion?

Synthetic training case — not a field record.

A project has spent 80% of its budget. Hardware is delivered, but only 4 of 12 point integrations have passed. One supplier’s interface document conflicts with the integrator’s data type. A promised license delivery date passed yesterday. The status report says “80% complete, no issues” based on expenditure.

1. Every project must use identical cost and completion curves
2. Cost can be incurred before integration and acceptance
3. Expenditure is never relevant to project control
4. All hardware delivery equals final service acceptance

**Correct option(s):** 2

- Option 1: Their relationship depends on the work and purchasing pattern.
- Option 2: Delivered equipment may leave substantial unfinished functional work.
- Option 3: Cost remains important but measures a different dimension.
- Option 4: The case includes eight unpassed integrations.

**CDFOS-Q0412 · single · operations**

What is the accepted integration count?

Synthetic training case — not a field record.

A project has spent 80% of its budget. Hardware is delivered, but only 4 of 12 point integrations have passed. One supplier’s interface document conflicts with the integrator’s data type. A promised license delivery date passed yesterday. The status report says “80% complete, no issues” based on expenditure.

1. Zero because one issue exists
2. 4 of 12
3. 80% of 12 automatically
4. 12 of 12

**Correct option(s):** 2

- Option 1: The four accepted results can remain valid within their scope.
- Option 2: Those are the stated passed point integrations.
- Option 3: The budget percentage is not the test result.
- Option 4: Delivery does not prove all integrations passed.

**CDFOS-Q0413 · single · operations**

How should the already-missed license date be classified?

Synthetic training case — not a field record.

A project has spent 80% of its budget. Hardware is delivered, but only 4 of 12 point integrations have passed. One supplier’s interface document conflicts with the integrator’s data type. A promised license delivery date passed yesterday. The status report says “80% complete, no issues” based on expenditure.

1. An automatic cancellation of every project activity
2. A completed deliverable
3. An issue requiring resolution and forecast impact assessment
4. Only a future hypothetical risk

**Correct option(s):** 3

- Option 1: Some independent work may still proceed under review.
- Option 2: The license has not been supplied.
- Option 3: The adverse condition has occurred.
- Option 4: The promised date has already passed.

**CDFOS-Q0414 · single · diagnosis**

What should resolve the data-type conflict?

Synthetic training case — not a field record.

A project has spent 80% of its budget. Hardware is delivered, but only 4 of 12 point integrations have passed. One supplier’s interface document conflicts with the integrator’s data type. A promised license delivery date passed yesterday. The status report says “80% complete, no issues” based on expenditure.

1. The supplier with the larger contract value automatically
2. Independent undocumented fixes by both teams
3. A controlled interface decision based on the authoritative source and test
4. Whichever representation makes the screen look plausible

**Correct option(s):** 3

- Option 1: Commercial size does not determine technical correctness.
- Option 2: That can preserve incompatible assumptions.
- Option 3: The two teams need one verified interpretation.
- Option 4: Plausibility does not establish correct semantics.

**CDFOS-Q0415 · single · operations**

What should the revised status report include?

Synthetic training case — not a field record.

A project has spent 80% of its budget. Hardware is delivered, but only 4 of 12 point integrations have passed. One supplier’s interface document conflicts with the integrator’s data type. A promised license delivery date passed yesterday. The status report says “80% complete, no issues” based on expenditure.

1. Only a green overall icon
2. Only the originally planned finish date
3. Accepted outputs, blockers, forecast, uncertainty and required decisions
4. Only the amount already paid

**Correct option(s):** 3

- Option 1: A summary without material issues misleads.
- Option 2: Current evidence may invalidate the forecast.
- Option 3: Stakeholders need a truthful basis for action.
- Option 4: That conceals the functional state.

**CDFOS-Q0416 · single · operations**

Which activity is quality control?

Synthetic training case — not a field record.

A project has spent 80% of its budget. Hardware is delivered, but only 4 of 12 point integrations have passed. One supplier’s interface document conflicts with the integrator’s data type. A promised license delivery date passed yesterday. The status report says “80% complete, no issues” based on expenditure.

1. Paying a supplier invoice
2. Updating the forecast completion date
3. Approving the annual corporate strategy
4. Comparing implemented point behavior with its agreed acceptance test

**Correct option(s):** 4

- Option 1: Payment does not test integration quality.
- Option 2: Schedule control does not directly verify the implemented point behavior.
- Option 3: That is not this output-level verification.
- Option 4: It evaluates the produced output.

**CDFOS-Q0417 · single · operations**

Which activity is process assurance?

Synthetic training case — not a field record.

A project has spent 80% of its budget. Hardware is delivered, but only 4 of 12 point integrations have passed. One supplier’s interface document conflicts with the integrator’s data type. A promised license delivery date passed yesterday. The status report says “80% complete, no issues” based on expenditure.

1. Substituting a process review for every functional test
2. Assuming supplier certification guarantees this installation
3. Reviewing whether version control and test-review methods are suitable and followed
4. Ignoring interface ownership because tests will find everything

**Correct option(s):** 3

- Option 1: Assurance complements rather than replaces output checks.
- Option 2: A general credential does not prove the actual result.
- Option 3: It examines the process used to produce and verify outputs.
- Option 4: Unowned interfaces can undermine delivery and diagnosis.

**CDFOS-Q0418 · single · operations**

What should a supplier completion notice be treated as?

Synthetic training case — not a field record.

A project has spent 80% of its budget. Hardware is delivered, but only 4 of 12 point integrations have passed. One supplier’s interface document conflicts with the integrator’s data type. A promised license delivery date passed yesterday. The status report says “80% complete, no issues” based on expenditure.

1. Final proof that every operational requirement passed
2. Evidence that no defects can exist
3. A reason to discard the project’s test plan
4. A claim to verify against the facility’s acceptance criteria

**Correct option(s):** 4

- Option 1: The actual test evidence remains necessary.
- Option 2: Completion claims can be incomplete or scoped differently.
- Option 3: The agreed plan still governs acceptance.
- Option 4: Supplier reporting is not automatically independent acceptance.

**CDFOS-Q0419 · single · operations**

What makes an issue log useful?

Synthetic training case — not a field record.

A project has spent 80% of its budget. Hardware is delivered, but only 4 of 12 point integrations have passed. One supplier’s interface document conflicts with the integrator’s data type. A promised license delivery date passed yesterday. The status report says “80% complete, no issues” based on expenditure.

1. Only entries that do not threaten the forecast
2. Only a count of open rows
3. Only informal verbal updates
4. Owner, impact, next action, deadline and decision history

**Correct option(s):** 4

- Option 1: Selective reporting hides material blockers.
- Option 2: Count does not explain consequence or action.
- Option 3: They can be lost across teams and shifts.
- Option 4: These support resolution instead of repeated rediscovery.

**CDFOS-Q0420 · single · operations**

What is a justified continuation decision?

Synthetic training case — not a field record.

A project has spent 80% of its budget. Hardware is delivered, but only 4 of 12 point integrations have passed. One supplier’s interface document conflicts with the integrator’s data type. A promised license delivery date passed yesterday. The status report says “80% complete, no issues” based on expenditure.

1. Stop all unrelated work permanently
2. Proceed with independent ready work while controlling blocked interfaces
3. Continue every integration with guessed data types
4. Declare the remaining eight tests passed based on expenditure

**Correct option(s):** 2

- Option 1: That may be unnecessary if safe independent tasks remain.
- Option 2: The plan should reflect actual dependencies and risk.
- Option 3: That propagates unverified assumptions.
- Option 4: Financial progress cannot create technical evidence.

**CDFOS-Q0421 · single · mechanism**

Why is the inaccessible backup procedure a handover defect?

Synthetic training case — not a field record.

The new monitoring service passes its defined functional tests. Its backup procedure is stored in a supplier portal unavailable to the night shift. One minor-looking defect routes alarms to an old team mailbox. Temporary installer accounts remain active. The sponsor wants to claim a 30% reduction in restoration time immediately, although no post-launch incidents have occurred.

1. Night-shift staff should never perform recovery tasks
2. The receiving shift cannot use required recovery information when needed
3. A passed login test makes recovery documentation unnecessary
4. All supplier portals are inherently unacceptable

**Correct option(s):** 2

- Option 1: Their authorized role and procedures determine that.
- Option 2: Document existence does not establish operational availability.
- Option 3: Different requirements remain.
- Option 4: A supported accessible arrangement may be suitable.

**CDFOS-Q0422 · single · mechanism**

Why might the old-mailbox defect prevent acceptance?

Synthetic training case — not a field record.

The new monitoring service passes its defined functional tests. Its backup procedure is stored in a supplier portal unavailable to the night shift. One minor-looking defect routes alarms to an old team mailbox. Temporary installer accounts remain active. The sponsor wants to claim a 30% reduction in restoration time immediately, although no post-launch incidents have occurred.

1. Mailboxes cannot be part of operational scope
2. It can defeat the required alarm-response function
3. Every cosmetic defect must stop every project
4. The supplier called it minor, so it has no effect

**Correct option(s):** 2

- Option 1: Notification is explicitly part of the service.
- Option 2: A visually small configuration issue can have significant consequence.
- Option 3: Disposition should follow actual impact and criteria.
- Option 4: Labels do not determine operational consequence.

**CDFOS-Q0423 · single · operations**

What should happen to installer accounts?

Synthetic training case — not a field record.

The new monitoring service passes its defined functional tests. Its backup procedure is stored in a supplier portal unavailable to the night shift. One minor-looking defect routes alarms to an old team mailbox. Temporary installer accounts remain active. The sponsor wants to claim a 30% reduction in restoration time immediately, although no post-launch incidents have occurred.

1. Delete audit records of their use
2. Share them with every shift to simplify handover
3. Retain all accounts indefinitely because installation succeeded
4. Remove or reauthorize them for a defined operational purpose

**Correct option(s):** 4

- Option 1: Records may remain relevant under retention policy.
- Option 2: Shared temporary access weakens accountability.
- Option 3: Success does not justify obsolete privilege.
- Option 4: Temporary access must not silently persist beyond its need.

**CDFOS-Q0424 · single · operations**

What demonstrates that handover material is usable?

Synthetic training case — not a field record.

The new monitoring service passes its defined functional tests. Its backup procedure is stored in a supplier portal unavailable to the night shift. One minor-looking defect routes alarms to an old team mailbox. Temporary installer accounts remain active. The sponsor wants to claim a 30% reduction in restoration time immediately, although no post-launch incidents have occurred.

1. The project manager signs without operator involvement
2. The supplier reports a large document count
3. A representative authorized operator performs a task using it
4. The files are compressed into a smaller archive

**Correct option(s):** 3

- Option 1: The receiving function still needs usable capability.
- Option 2: Quantity does not prove usability.
- Option 3: Practical use tests accessibility and clarity.
- Option 4: Packaging does not establish operational effectiveness.

**CDFOS-Q0425 · single · recovery**

Can the sponsor claim a measured 30% restoration improvement now?

Synthetic training case — not a field record.

The new monitoring service passes its defined functional tests. Its backup procedure is stored in a supplier portal unavailable to the night shift. One minor-looking defect routes alarms to an old team mailbox. Temporary installer accounts remain active. The sponsor wants to claim a 30% reduction in restoration time immediately, although no post-launch incidents have occurred.

1. No; no post-launch observations support that measured result
2. Yes; a stated target becomes a result at closure
3. Yes; passing functional tests proves every business benefit
4. No benefit can ever be measured after a project closes

**Correct option(s):** 1

- Option 1: A forecast is not yet a demonstrated benefit.
- Option 2: Targets require evidence before being reported as achieved.
- Option 3: Function and realized performance are different outcomes.
- Option 4: Operational review can assess benefits later.

**CDFOS-Q0426 · single · operations**

What should the benefit plan retain?

Synthetic training case — not a field record.

The new monitoring service passes its defined functional tests. Its backup procedure is stored in a supplier portal unavailable to the night shift. One minor-looking defect routes alarms to an old team mailbox. Temporary installer accounts remain active. The sponsor wants to claim a 30% reduction in restoration time immediately, although no post-launch incidents have occurred.

1. Only the purchase price
2. Only the desired percentage
3. Only the closing-meeting date
4. Baseline, metric, comparable conditions, owner and review period

**Correct option(s):** 4

- Option 1: Cost does not measure restoration performance.
- Option 2: A target alone does not specify measurement.
- Option 3: The observation period may extend beyond closure.
- Option 4: These define how the forecast will be assessed.

**CDFOS-Q0427 · single · operations**

What should conditional acceptance document if permitted?

Synthetic training case — not a field record.

The new monitoring service passes its defined functional tests. Its backup procedure is stored in a supplier portal unavailable to the night shift. One minor-looking defect routes alarms to an old team mailbox. Temporary installer accounts remain active. The sponsor wants to claim a 30% reduction in restoration time immediately, although no post-launch incidents have occurred.

1. Only the phrase “minor snag”
2. A promise that the supplier will remember
3. A silent waiver of all alarm requirements
4. Residual defect, consequence, owner, deadline and operating restriction

**Correct option(s):** 4

- Option 1: That does not define its effect or resolution.
- Option 2: Unowned informal commitments are weak closure evidence.
- Option 3: A bounded disposition does not justify removing the function.
- Option 4: The incomplete item must remain controlled and visible.

**CDFOS-Q0428 · single · operations**

Which lesson learned is actionable?

Synthetic training case — not a field record.

The new monitoring service passes its defined functional tests. Its backup procedure is stored in a supplier portal unavailable to the night shift. One minor-looking defect routes alarms to an old team mailbox. Temporary installer accounts remain active. The sponsor wants to claim a 30% reduction in restoration time immediately, although no post-launch incidents have occurred.

1. Remove recovery from future scope to avoid portal problems
2. Communicate better next time
3. Assign portal-access verification to the handover checklist owner with a retest date
4. Assume future projects will use the same staff

**Correct option(s):** 3

- Option 1: That abandons a required capability.
- Option 2: The aspiration lacks a defined action and acceptance.
- Option 3: It connects a specific cause to an owned process change.
- Option 4: Staff continuity is not a durable control.

**CDFOS-Q0429 · single · operations**

What should the final operational baseline contain?

Synthetic training case — not a field record.

The new monitoring service passes its defined functional tests. Its backup procedure is stored in a supplier portal unavailable to the night shift. One minor-looking defect routes alarms to an old team mailbox. Temporary installer accounts remain active. The sponsor wants to claim a 30% reduction in restoration time immediately, although no post-launch incidents have occurred.

1. Only the supplier’s standard product manual
2. Only the initial design draft
3. Accepted configuration, assets, procedures, support and known restrictions
4. Only the project’s budget spreadsheet

**Correct option(s):** 3

- Option 1: Site interfaces and decisions also matter.
- Option 2: The installed accepted state may differ.
- Option 3: Operations needs the state actually handed over.
- Option 4: Financial records do not define operation.

**CDFOS-Q0430 · single · mechanism**

What distinguishes project closure from benefit review?

Synthetic training case — not a field record.

The new monitoring service passes its defined functional tests. Its backup procedure is stored in a supplier portal unavailable to the night shift. One minor-looking defect routes alarms to an old team mailbox. Temporary installer accounts remain active. The sponsor wants to claim a 30% reduction in restoration time immediately, although no post-launch incidents have occurred.

1. Closure transfers accepted deliverables; benefits may need later operating evidence
2. Closure proves every forecast under all future conditions
3. Benefit review replaces the need for technical acceptance
4. A project can never close with any explicitly governed residual item

**Correct option(s):** 1

- Option 1: Their timing and acceptance can differ.
- Option 2: That overstates the available evidence.
- Option 3: Both have separate purposes.
- Option 4: Site policy may allow bounded conditional acceptance.

#### Recall

**Project charter and an ambiguous monitoring outcome — Synthetic training case — not a field record.

A sponsor requests “better EPMS visibility” for twelve meters. Procurement proposes buying a dashboard license immediately. Operations requires correct asset mapping, a five-second maximum source age, alarm delivery, ninety-day history and a tested restore. The supplier assumes the existing gateway license includes all drivers, but nobody has checked.**

Define the accepted operational capability before committing the purchase. The twelve-meter scope and measurable functions form the requirement set. Assign sponsor, project manager, technical owners and operational acceptance authority. Verify the driver entitlement as an assumption/dependency; buying a dashboard alone does not prove the required service.

**Dependency schedule and a controlled scope change — Synthetic training case — not a field record.

Synthetic schedule: design A takes 3 days. After A, procurement B takes 5 days and procedure drafting C takes 2 days in parallel. Installation D takes 2 days after B and C. Acceptance E takes 1 day after D. A proposed extra interface adds 2 days of design and needs an unconfirmed license. Assume resources are available and no other calendar constraints for the baseline calculation.**

The baseline critical path is A–B–D–E: 3+5+2+1 = 11 days. C finishes before B and has three days of simple path slack. The extra interface changes scope and a dependency; assess licensing, acceptance and schedule before approval. Real cutover windows and resource constraints must be added before treating the arithmetic as a delivery promise.

**Execution report with cost ahead of acceptance — Synthetic training case — not a field record.

A project has spent 80% of its budget. Hardware is delivered, but only 4 of 12 point integrations have passed. One supplier’s interface document conflicts with the integrator’s data type. A promised license delivery date passed yesterday. The status report says “80% complete, no issues” based on expenditure.**

Spending and accepted work are different measures. Report the passed integrations and remaining work, classify the missed license commitment as an issue, and assign the conflicting interface for resolution with source/version evidence. Update the forecast and decision needs rather than retaining a misleading percentage.

**Operational handover and later benefit verification — Synthetic training case — not a field record.

The new monitoring service passes its defined functional tests. Its backup procedure is stored in a supplier portal unavailable to the night shift. One minor-looking defect routes alarms to an old team mailbox. Temporary installer accounts remain active. The sponsor wants to claim a 30% reduction in restoration time immediately, although no post-launch incidents have occurred.**

Functional delivery is not complete operational handover when required recovery information and alarm ownership are unusable. Resolve or formally disposition defects and temporary access. Benefit realization needs a baseline, comparable observations and an owner after launch; it cannot be inferred without the relevant operating evidence.

#### References

- [EPI CDFOS public syllabus](https://www.epi-ap.com/services/1/3/136)

## CDFOS-M08 — Environmental measurement and controlled sustainability improvement

### CDFOS-L08 — Environmental measurement and controlled sustainability improvement

Estimated study time: 120 minutes before independent work. Prerequisite chapters: CDFOS-L07

## Establish a measurable environmental operating boundary

Sustainability management starts with a defined service, physical boundary and reporting period. A facility can reduce purchased electricity while increasing water use, or lower an infrastructure ratio while increasing total energy. These are different outcomes. Create an environmental register covering energy, water, fuel, materials, waste and locally applicable obligations. Assign owners to the source data, calculation method, approval and improvement work. Record the version of the reporting method; do not silently replace an old boundary with a more favorable one. An operating team contributes trustworthy measurements, controlled trials and correctly executed procedures. Specialist design decisions and statutory interpretations retain their assigned competent owners.

Energy is accumulated power over time. One kilowatt sustained for one hour equals one kilowatt-hour; a snapshot in kilowatts is not an energy total. A cumulative meter difference is useful only after handling rollover, replacement, reset, units and missing intervals. Check that meters bracket the same service and period. Facility input can include several supplies and on-site generation; the accounting boundary must prevent omissions and double counting. A shared building's lobby or neighboring tenant cannot simply be included in one month and omitted in the next without a documented allocation rule. Trace each report value back through its meter identity, time interval, scaling and quality flags.

Power usage effectiveness, PUE, compares total facility energy with IT equipment energy within the stated method and boundary. It describes infrastructure overhead relative to the IT energy denominator. It does not measure useful computational work, application efficiency, carbon emissions, water stress or business value. An IT consolidation may reduce total consumption while fixed facility overhead causes PUE to rise. Reporting that as an environmental failure from PUE alone confuses a ratio with the underlying objective. Present numerator, denominator, absolute energy and service context together. Partial metrics and short reporting periods need clear labels; avoid presenting a local room measurement as the whole campus's annual performance.

Aggregation requires energy weighting. If one period uses 150 MWh facility and 100 MWh IT energy, its ratio is 1.5. Another uses 100 MWh facility and 50 MWh IT energy, giving 2.0. Across both periods, 250/150 is approximately 1.667. The arithmetic mean 1.75 gives equal influence to unequal IT-energy denominators and is wrong for the combined boundary. The general calculation is sum of facility energy divided by sum of IT energy. Missing denominator data cannot be replaced with zero; flag the interval and use only a disclosed defensible estimation or correction method. Uncertainty may matter more than an additional decimal place.

## Turn efficiency ideas into controlled improvements

An efficiency opportunity needs a mechanism. Removing an unnecessary airflow obstruction can reduce recirculation; shutting down an apparently idle fan without understanding its standby or pressure-control role can instead remove resilience. Connect the proposed change to the load, control sequence and service constraints. Record the present configuration and a reversible change plan. Identify safety, reliability, humidity, temperature, water, maintenance and monitoring conditions that must remain acceptable. Specify abort and rollback criteria before the trial, and ensure someone has authority to act when those criteria are reached.

A before-and-after comparison needs comparable conditions or a documented model. Lower outdoor temperature, reduced IT load or a different operating schedule can explain a lower energy reading without proving the proposed change caused it. Use sufficient observations for the decision, retain weather and load context, and inspect the whole affected boundary. Moving a cooling load from one meter to another creates apparent savings if the second meter is omitted. Evaluate rebound effects: an efficient system can still consume more total energy if additional demand exceeds the savings. Operations should explain the result's assumptions rather than claiming laboratory precision from a short uncontrolled observation.

Calculate costs with the actual supplied tariff structure. A constant energy charge permits a simple kilowatt-hour difference multiplied by price per kilowatt-hour. Demand charges, time-of-use periods, taxes and contractual constraints require their own terms. In a training example, reducing average power by 8 kW over 100 hours saves 800 kWh. At a stated flat energy charge of 0.12 currency units per kWh, this is 96 currency units of energy charges. It is not automatically the bill reduction if a demand charge remains. A simple payback divides relevant upfront cost by defensible annual net savings; maintenance, reliability impacts and life-cycle costs still need review.

## Water, materials and responsible operating choices

Water usage effectiveness relates a stated water quantity to IT equipment energy, commonly expressed as liters per kilowatt-hour. Define whether the figure includes on-site water only or an expanded source-energy boundary. Mixing the numerator from one method with the name of another makes comparisons misleading. Track supply, consumption, discharge and reuse consistently. Water withdrawal is not necessarily identical to consumption: some withdrawn water returns to the environment, subject to its own quality and temperature implications. Regional scarcity and discharge conditions influence the consequence of a liter used, so a single ratio does not settle the site's environmental impact.

A simple balance can identify a question, not automatically locate a leak. If measured inlet volume exceeds known outlet and stored-volume change, examine meter accuracy, timing, unmetered uses and the process before naming a failed component. Treatment chemistry, microbial control, blowdown and discharge are specialist subjects governed by equipment requirements and applicable local rules. Operators should identify abnormal trends, preserve evidence and follow authorized responses. They should not reduce a protective treatment or disable a leak interlock to improve a dashboard ratio. Liquid-cooling integration adds connections among coolant compatibility, leak detection, IT availability and recovery; retain those interfaces in the change review.

Procurement and end-of-life decisions also affect environmental performance. Compare useful life, repairability, replacement parts, energy performance under actual load and secure disposal requirements. Replacing working equipment may reduce operating energy while adding manufacturing impacts and waste; the decision needs a stated boundary and evidence. Asset retirement still requires data sanitization and custody. A waste-transfer receipt proves a recorded handoff, not necessarily every downstream environmental claim. Confirm the receiving service's authorized scope through the site's procurement process and retain traceable records appropriate to the material and jurisdiction.

## Energy attributes, claims and continuing governance

Separate physical supply behavior from contractual attributes and emissions accounting. An annual renewable-energy instrument does not prove that a site's equipment was powered by a matching local source every hour or that the site can operate during a grid outage. Storage and backup capability require engineering and operational evidence. For emissions reporting, record the accounting method, activity data, factors, instrument eligibility and period. GHG Protocol distinguishes location-based and market-based methods; its public page also identifies an ongoing revision process, so verify the applicable published guidance when making a formal report. Do not invent a factor or call a proposed rule final.

Communicate improvements with bounded claims: what changed, over which period and boundary, compared with what baseline, with which service conditions and uncertainty. Publish unresolved data gaps rather than selecting only favorable sites or months. Assign actions to responsible owners and review whether the new operating state persists after staff, weather or load changes. Sustainability becomes an operational process when meter quality, maintenance, change control, procurement, incident handling and governance reinforce each other. The practical outcome is an auditable improvement with understood trade-offs, not a single favorable metric detached from service delivery.


#### Worked demonstrations

**A two-period efficiency report**

Synthetic training case — not a field record.

Month A: facility 150 MWh, IT 100 MWh. Month B: facility 100 MWh, IT 50 MWh. Both measurements share the same complete boundary. A draft reports PUE 1.75 as the annual value, although only these two months are available. A third month lacks its IT meter data.

**Reasoning:** A and B have PUE 1.5 and 2.0; together 250/150 = 1.6667. Label it a two-month aggregate, not an annual result. Preserve the missing third-month denominator as a data-quality issue. PUE does not establish useful IT work or carbon intensity.

**An airflow trial and a savings claim**

Synthetic training case — not a field record.

A contained-aisle airflow trial changes a control setting. Average facility power falls from 200 to 192 kW over a 100-hour trial; IT load is unchanged, but outside temperature is lower. Flat energy charge is 0.12 currency/kWh; demand charges are separate. A sensor at the hottest rack crosses the predefined rollback threshold. The proposed permanent change costs 1200 currency.

**Reasoning:** The observed energy difference is 8 × 100 = 800 kWh and its stated energy-charge value is 96. Weather is a confounder, so the causal saving is unproven. Execute the approved rollback response when its threshold is reached. Do not annualize a short uncontrolled trial or ignore service limits to achieve a favorable ratio.

**Water accounting and an unresolved balance**

Synthetic training case — not a field record.

For a stated period, on-site water use is 120000 L and IT energy is 60000 kWh. A separate estimate attributes 30000 L to electricity production upstream. An inlet meter records 10000 L during a shorter audit window; documented outlet/use totals are 8500 L and stored volume rises 500 L. Meter timing/accuracy and unmetered uses have not been checked. A proposal would stop treatment checks to save water.

**Reasoning:** The stated on-site ratio is 2 L/kWh; including the separate source quantity would give 2.5 L/kWh under an explicitly expanded method, not the same metric boundary. The audit has an unexplained 1000 L difference, which calls for validation rather than an immediate leak location claim. Protective treatment requirements need competent review and cannot be silently removed for a metric.

**Renewable claims and equipment lifecycle**

Synthetic training case — not a field record.

A site buys annual renewable-energy attributes matching its annual electricity quantity. Its physical grid connection and backup system are unchanged. A draft claim says “renewable power every hour and guaranteed outage independence.” A server-replacement proposal compares operating electricity but omits manufacture, repairability and disposal. Retired drives contain customer data; the recycler has supplied a collection receipt only.

**Reasoning:** Annual attribute matching does not establish hourly physical supply or outage resilience. Report the applicable accounting method and instrument evidence within its limits. Compare replacement options using a declared lifecycle boundary, and retain secure sanitization and downstream service due diligence rather than treating collection as proof of every disposal outcome.

#### Guided practice

Rebuild the two-month energy report, qualify the airflow trial, reconcile the water balance and edit the renewable claim so every statement has a defined evidence boundary.

**Hint:** Keep physical quantities, accounting attributes, service constraints and missing data separate.

**Worked solution:** Aggregate energy before division; disclose the two-month coverage and missing third-month data. Treat the 800 kWh difference as observed rather than causally verified, respect rollback, investigate the 1000 L water discrepancy and limit renewable claims to supported accounting evidence.

#### Independent task

Environment: analytical

Prepare an auditable environmental operations review using the four synthetic cases.

**Packaged starter material**

- course_labs/CDFOS/README.md
- course_labs/CDFOS/fixture.json
- course_labs/CDFOS/assessment_template.md
- course_labs/CDFOS/lab.py
- course_labs/CDFOS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- Energy and water calculation sheet with units
- Trial decision and service constraints
- Environmental claim with source/method scope
- Procurement and disposal evidence checklist

**Acceptance criteria**

- Ratios use consistent boundaries and periods.
- No efficiency gain is claimed by dropping required service protection.
- Physical resilience and contractual energy attributes remain distinguishable.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer. The bundled calculator was executed against supplied synthetic fixtures; its numerical checks do not grade physical work or professional authorization.

#### Chapter practice

**CDFOS-Q0431 · single · calculation**

What is Month A PUE?

Synthetic training case — not a field record.

Month A: facility 150 MWh, IT 100 MWh. Month B: facility 100 MWh, IT 50 MWh. Both measurements share the same complete boundary. A draft reports PUE 1.75 as the annual value, although only these two months are available. A third month lacks its IT meter data.

1. 2.5
2. 1.5
3. 0.667
4. 0.5

**Correct option(s):** 2

- Option 1: Adding one to the already complete facility/IT ratio double counts.
- Option 2: Divide 150 MWh facility energy by 100 MWh IT energy.
- Option 3: That reverses the numerator and denominator.
- Option 4: That describes overhead relative to IT, not the full PUE.

**CDFOS-Q0432 · single · calculation**

What is the combined ratio for the two valid months?

Synthetic training case — not a field record.

Month A: facility 150 MWh, IT 100 MWh. Month B: facility 100 MWh, IT 50 MWh. Both measurements share the same complete boundary. A draft reports PUE 1.75 as the annual value, although only these two months are available. A third month lacks its IT meter data.

1. 1.75
2. 3.5
3. Approximately 1.667
4. 1.0

**Correct option(s):** 3

- Option 1: An unweighted mean gives unequal denominators equal influence.
- Option 2: Adding ratios does not form the aggregate.
- Option 3: Use 250 MWh divided by 150 MWh.
- Option 4: Equal reporting durations do not imply equal facility and IT energy.

**CDFOS-Q0433 · single · calculation**

Why is the arithmetic mean inappropriate here?

Synthetic training case — not a field record.

Month A: facility 150 MWh, IT 100 MWh. Month B: facility 100 MWh, IT 50 MWh. Both measurements share the same complete boundary. A draft reports PUE 1.75 as the annual value, although only these two months are available. A third month lacks its IT meter data.

1. PUE ratios can never be combined
2. The numerator should be weighted by purchase price instead
3. Months must always have identical weather
4. The IT-energy denominators differ

**Correct option(s):** 4

- Option 1: They can be combined through corresponding energy sums.
- Option 2: Price is not the PUE energy denominator.
- Option 3: Weather affects interpretation but does not invalidate this arithmetic.
- Option 4: The aggregate requires weighting by those denominators.

**CDFOS-Q0434 · single · operations**

Which label is justified for the 1.667 result?

Synthetic training case — not a field record.

Month A: facility 150 MWh, IT 100 MWh. Month B: facility 100 MWh, IT 50 MWh. Both measurements share the same complete boundary. A draft reports PUE 1.75 as the annual value, although only these two months are available. A third month lacks its IT meter data.

1. IT application efficiency
2. Verified annual PUE
3. Two-month aggregate for the stated boundary
4. Campus-wide PUE regardless of boundary

**Correct option(s):** 3

- Option 1: The ratio does not measure useful application work.
- Option 2: Ten months of annual evidence are absent.
- Option 3: The evidence covers only those months.
- Option 4: The stated boundary may not encompass other facilities.

**CDFOS-Q0435 · single · operations**

How should the third month be treated before correction?

Synthetic training case — not a field record.

Month A: facility 150 MWh, IT 100 MWh. Month B: facility 100 MWh, IT 50 MWh. Both measurements share the same complete boundary. A draft reports PUE 1.75 as the annual value, although only these two months are available. A third month lacks its IT meter data.

1. Ignore the month while claiming full annual coverage
2. Reuse the lower of the previous denominators without explanation
3. Enter zero IT energy and average the result
4. Flag the missing denominator and disclose the coverage gap

**Correct option(s):** 4

- Option 1: The coverage claim would be false.
- Option 2: That invents favorable data.
- Option 3: Zero is not a valid substitute for missing data.
- Option 4: A valid ratio needs a defensible IT-energy quantity.

**CDFOS-Q0436 · single · operations**

What additional data is needed to estimate electricity emissions?

Synthetic training case — not a field record.

Month A: facility 150 MWh, IT 100 MWh. Month B: facility 100 MWh, IT 50 MWh. Both measurements share the same complete boundary. A draft reports PUE 1.75 as the annual value, although only these two months are available. A third month lacks its IT meter data.

1. Only another decimal place in PUE
2. Only maximum UPS rating
3. Only rack count
4. Applicable emissions factors, method and corresponding energy activity

**Correct option(s):** 4

- Option 1: Precision cannot supply an emissions factor.
- Option 2: Rated capacity is not consumed energy or its emissions factor.
- Option 3: Rack count does not establish energy emissions.
- Option 4: PUE alone contains no carbon-intensity information.

**CDFOS-Q0437 · single · operations**

If IT consolidation reduces total energy but raises PUE, what is defensible?

Synthetic training case — not a field record.

Month A: facility 150 MWh, IT 100 MWh. Month B: facility 100 MWh, IT 50 MWh. Both measurements share the same complete boundary. A draft reports PUE 1.75 as the annual value, although only these two months are available. A third month lacks its IT meter data.

1. The consolidation necessarily increased total energy
2. The IT denominator should be inflated to preserve the old ratio
3. PUE must have been calculated incorrectly
4. Assess both absolute consumption and changed overhead ratio

**Correct option(s):** 4

- Option 1: A rising ratio does not prove a rising numerator.
- Option 2: That corrupts the measurement.
- Option 3: Fixed overhead can change the ratio legitimately.
- Option 4: The two outcomes can coexist.

**CDFOS-Q0438 · single · mechanism**

What distinguishes energy from the instantaneous meter power reading?

Synthetic training case — not a field record.

Month A: facility 150 MWh, IT 100 MWh. Month B: facility 100 MWh, IT 50 MWh. Both measurements share the same complete boundary. A draft reports PUE 1.75 as the annual value, although only these two months are available. A third month lacks its IT meter data.

1. Power requires a billing tariff to exist
2. Energy accumulates power across time
3. Energy and power have interchangeable units
4. An instantaneous kW value always equals the monthly kWh

**Correct option(s):** 2

- Option 1: Tariffs do not define the physical quantity.
- Option 2: A kW snapshot cannot replace an MWh total.
- Option 3: They describe different quantities.
- Option 4: Duration and variability matter.

**CDFOS-Q0439 · single · operations**

What would a silently removed lighting meter do to comparability?

Synthetic training case — not a field record.

Month A: facility 150 MWh, IT 100 MWh. Month B: facility 100 MWh, IT 50 MWh. Both measurements share the same complete boundary. A draft reports PUE 1.75 as the annual value, although only these two months are available. A third month lacks its IT meter data.

1. Prove that lighting was an IT load
2. Improve actual lighting efficiency automatically
3. Change the facility boundary and potentially understate overhead
4. Leave the ratio valid for the original unchanged boundary

**Correct option(s):** 3

- Option 1: Meter removal does not change the load’s function.
- Option 2: Removing measurement does not reduce physical consumption.
- Option 3: The periods would no longer share the stated accounting scope.
- Option 4: The numerator would omit included energy.

**CDFOS-Q0440 · single · operations**

What report evidence makes the calculation auditable?

Synthetic training case — not a field record.

Month A: facility 150 MWh, IT 100 MWh. Month B: facility 100 MWh, IT 50 MWh. Both measurements share the same complete boundary. A draft reports PUE 1.75 as the annual value, although only these two months are available. A third month lacks its IT meter data.

1. Meter identities, intervals, units, quality and calculation lineage
2. Only the rounded final ratio
3. Only the lowest daily ratio
4. Only the equipment nameplate totals

**Correct option(s):** 1

- Option 1: These connect the totals to their physical and reporting boundaries.
- Option 2: Readers cannot trace its source or omissions.
- Option 3: A selected day does not substantiate the aggregate.
- Option 4: Rated power is not metered energy.

**CDFOS-Q0441 · single · calculation**

What is the observed energy difference over the trial duration?

Synthetic training case — not a field record.

A contained-aisle airflow trial changes a control setting. Average facility power falls from 200 to 192 kW over a 100-hour trial; IT load is unchanged, but outside temperature is lower. Flat energy charge is 0.12 currency/kWh; demand charges are separate. A sensor at the hottest rack crosses the predefined rollback threshold. The proposed permanent change costs 1200 currency.

1. 19200 kWh
2. 8 kWh
3. 800 kWh
4. 800 kW

**Correct option(s):** 3

- Option 1: That is trial consumption at 192 kW, not the difference.
- Option 2: That omits the duration.
- Option 3: An 8 kW difference sustained over 100 hours corresponds to 800 kWh.
- Option 4: The calculated quantity is energy, not power.

**CDFOS-Q0442 · single · calculation**

What is its value under the stated energy charge alone?

Synthetic training case — not a field record.

A contained-aisle airflow trial changes a control setting. Average facility power falls from 200 to 192 kW over a 100-hour trial; IT load is unchanged, but outside temperature is lower. Flat energy charge is 0.12 currency/kWh; demand charges are separate. A sensor at the hottest rack crosses the predefined rollback threshold. The proposed permanent change costs 1200 currency.

1. 1200 currency units
2. 96 currency units
3. 9.6 currency units
4. A guaranteed total bill reduction of 96

**Correct option(s):** 2

- Option 1: That is the proposed capital cost.
- Option 2: 800 kWh multiplied by 0.12 gives 96.
- Option 3: That is a factor-of-ten conversion error.
- Option 4: Separate demand and other charges are not evaluated.

**CDFOS-Q0443 · single · mechanism**

Why is the setting’s causal effect still uncertain?

Synthetic training case — not a field record.

A contained-aisle airflow trial changes a control setting. Average facility power falls from 200 to 192 kW over a 100-hour trial; IT load is unchanged, but outside temperature is lower. Flat energy charge is 0.12 currency/kWh; demand charges are separate. A sensor at the hottest rack crosses the predefined rollback threshold. The proposed permanent change costs 1200 currency.

1. A trial can never establish an efficiency effect
2. Outside temperature changed between the comparisons
3. The IT load was unchanged
4. The readings are in kilowatts

**Correct option(s):** 2

- Option 1: A suitable design and evidence can support a bounded conclusion.
- Option 2: Weather can affect cooling energy independently.
- Option 3: That improves one aspect of comparability rather than undermining it.
- Option 4: Power observations can support energy analysis with duration.

**CDFOS-Q0444 · single · operations**

What should happen when the agreed hot-rack threshold is crossed?

Synthetic training case — not a field record.

A contained-aisle airflow trial changes a control setting. Average facility power falls from 200 to 192 kW over a 100-hour trial; IT load is unchanged, but outside temperature is lower. Flat energy charge is 0.12 currency/kWh; demand charges are separate. A sensor at the hottest rack crosses the predefined rollback threshold. The proposed permanent change costs 1200 currency.

1. Delete the threshold because average room temperature is acceptable
2. Continue until the target savings are achieved
3. Follow the approved rollback and escalation criteria
4. Move the sensor to a cooler rack without recording it

**Correct option(s):** 3

- Option 1: Averages do not invalidate a specific agreed limit.
- Option 2: Savings do not override the predefined service boundary.
- Option 3: The service constraint was established before the trial.
- Option 4: That conceals the condition and changes measurement.

**CDFOS-Q0445 · single · operations**

What would strengthen a repeat comparison?

Synthetic training case — not a field record.

A contained-aisle airflow trial changes a control setting. Average facility power falls from 200 to 192 kW over a 100-hour trial; IT load is unchanged, but outside temperature is lower. Flat energy charge is 0.12 currency/kWh; demand charges are separate. A sensor at the hottest rack crosses the predefined rollback threshold. The proposed permanent change costs 1200 currency.

1. Comparing nameplate power with measured trial power
2. Choosing only the coldest successful trial hour
3. Removing all rack-temperature observations
4. Comparable load/weather observations and a declared analysis method

**Correct option(s):** 4

- Option 1: Those are different types of quantities.
- Option 2: Selection can exaggerate benefit.
- Option 3: That loses required service evidence.
- Option 4: These reduce confounding and make the conclusion reviewable.

**CDFOS-Q0446 · single · mechanism**

Why is a simple payback calculation premature?

Synthetic training case — not a field record.

A contained-aisle airflow trial changes a control setting. Average facility power falls from 200 to 192 kW over a 100-hour trial; IT load is unchanged, but outside temperature is lower. Flat energy charge is 0.12 currency/kWh; demand charges are separate. A sensor at the hottest rack crosses the predefined rollback threshold. The proposed permanent change costs 1200 currency.

1. Only electricity price matters in payback
2. Defensible annual net savings are not yet established
3. Capital cost can never be used in payback
4. Payback automatically proves reliability

**Correct option(s):** 2

- Option 1: The savings quantity and relevant costs also matter.
- Option 2: A short confounded observation cannot support a reliable annual denominator.
- Option 3: It is part of the calculation.
- Option 4: Financial arithmetic cannot establish service resilience.

**CDFOS-Q0447 · single · operations**

If fan energy moves to an unmetered supply, what happens to the claim?

Synthetic training case — not a field record.

A contained-aisle airflow trial changes a control setting. Average facility power falls from 200 to 192 kW over a 100-hour trial; IT load is unchanged, but outside temperature is lower. Flat energy charge is 0.12 currency/kWh; demand charges are separate. A sensor at the hottest rack crosses the predefined rollback threshold. The proposed permanent change costs 1200 currency.

1. All moved load becomes zero-carbon
2. The original complete boundary is still measured
3. The apparent reduction may be a boundary artifact
4. The cooling service necessarily improved

**Correct option(s):** 3

- Option 1: A supply change alone does not prove emissions.
- Option 2: A relevant energy path is now omitted.
- Option 3: The load can remain while disappearing from the chosen meter.
- Option 4: Metering changes do not prove thermal performance.

**CDFOS-Q0448 · single · operations**

Which record is needed to reverse the trial reproducibly?

Synthetic training case — not a field record.

A contained-aisle airflow trial changes a control setting. Average facility power falls from 200 to 192 kW over a 100-hour trial; IT load is unchanged, but outside temperature is lower. Flat energy charge is 0.12 currency/kWh; demand charges are separate. A sensor at the hottest rack crosses the predefined rollback threshold. The proposed permanent change costs 1200 currency.

1. Only the trial’s best energy result
2. Only the original procurement invoice
3. Only the installer’s recollection
4. The accepted prior configuration and authorized restoration sequence

**Correct option(s):** 4

- Option 1: That does not identify what to restore.
- Option 2: Commercial records rarely define the operating settings.
- Option 3: Memory is not a durable configuration record.
- Option 4: Rollback needs a known state and method.

**CDFOS-Q0449 · single · operations**

What should a permanent improvement review include besides energy?

Synthetic training case — not a field record.

A contained-aisle airflow trial changes a control setting. Average facility power falls from 200 to 192 kW over a 100-hour trial; IT load is unchanged, but outside temperature is lower. Flat energy charge is 0.12 currency/kWh; demand charges are separate. A sensor at the hottest rack crosses the predefined rollback threshold. The proposed permanent change costs 1200 currency.

1. Only PUE because it captures all environmental effects
2. Only the initial cost, with no ongoing obligations
3. Service margins, resilience, maintenance, water and operating constraints
4. Only the supplier’s promised percentage

**Correct option(s):** 3

- Option 1: PUE does not contain water, reliability or useful work.
- Option 2: Life-cycle costs and support can change the outcome.
- Option 3: The change may affect several coupled outcomes.
- Option 4: The site needs evidence in its conditions.

**CDFOS-Q0450 · single · operations**

How should the initial report describe the trial?

Synthetic training case — not a field record.

A contained-aisle airflow trial changes a control setting. Average facility power falls from 200 to 192 kW over a 100-hour trial; IT load is unchanged, but outside temperature is lower. Flat energy charge is 0.12 currency/kWh; demand charges are separate. A sensor at the hottest rack crosses the predefined rollback threshold. The proposed permanent change costs 1200 currency.

1. Proof that all containment projects are unsuitable
2. An observed reduction with weather confounding and a service-limit event
3. A verified permanent 4% annual saving
4. No useful evidence because the trial was rolled back

**Correct option(s):** 2

- Option 1: One bounded trial cannot support that universal conclusion.
- Option 2: This separates observations from unsupported causal conclusions.
- Option 3: The trial does not establish annual persistence or safe permanent operation.
- Option 4: The observations can inform diagnosis and redesign.

**CDFOS-Q0451 · single · calculation**

What is the stated on-site water-to-IT-energy ratio?

Synthetic training case — not a field record.

For a stated period, on-site water use is 120000 L and IT energy is 60000 kWh. A separate estimate attributes 30000 L to electricity production upstream. An inlet meter records 10000 L during a shorter audit window; documented outlet/use totals are 8500 L and stored volume rises 500 L. Meter timing/accuracy and unmetered uses have not been checked. A proposal would stop treatment checks to save water.

1. 2 L/kWh
2. 2 kWh/L
3. 2.5 L/kWh
4. 0.5 L/kWh

**Correct option(s):** 1

- Option 1: 120000 divided by 60000 gives two.
- Option 2: That attaches the reciprocal units to the result.
- Option 3: That includes the separate upstream quantity beyond the stated on-site boundary.
- Option 4: That reverses the division.

**CDFOS-Q0452 · single · operations**

How should the upstream 30000 L be reported if included?

Synthetic training case — not a field record.

For a stated period, on-site water use is 120000 L and IT energy is 60000 kWh. A separate estimate attributes 30000 L to electricity production upstream. An inlet meter records 10000 L during a shorter audit window; documented outlet/use totals are 8500 L and stored volume rises 500 L. Meter timing/accuracy and unmetered uses have not been checked. A proposal would stop treatment checks to save water.

1. As additional IT electrical energy
2. Under a declared expanded source-water method and boundary
3. As on-site use without changing the label
4. As a measured site leak

**Correct option(s):** 2

- Option 1: Liters cannot be added to kilowatt-hours.
- Option 2: It changes what the numerator represents.
- Option 3: That mixes distinct boundaries.
- Option 4: It is an upstream estimate, not a site loss observation.

**CDFOS-Q0453 · single · calculation**

What is the unexplained audit-window balance?

Synthetic training case — not a field record.

For a stated period, on-site water use is 120000 L and IT energy is 60000 kWh. A separate estimate attributes 30000 L to electricity production upstream. An inlet meter records 10000 L during a shorter audit window; documented outlet/use totals are 8500 L and stored volume rises 500 L. Meter timing/accuracy and unmetered uses have not been checked. A proposal would stop treatment checks to save water.

1. 2000 L
2. 1000 L
3. Zero automatically
4. 1500 L

**Correct option(s):** 2

- Option 1: That subtracts the storage change with the wrong sign.
- Option 2: 10000 minus 8500 minus the 500 L storage increase leaves 1000.
- Option 3: The measured terms do not yet balance.
- Option 4: That ignores water retained in storage.

**CDFOS-Q0454 · single · operations**

What should be checked before declaring a leak?

Synthetic training case — not a field record.

For a stated period, on-site water use is 120000 L and IT energy is 60000 kWh. A separate estimate attributes 30000 L to electricity production upstream. An inlet meter records 10000 L during a shorter audit window; documented outlet/use totals are 8500 L and stored volume rises 500 L. Meter timing/accuracy and unmetered uses have not been checked. A proposal would stop treatment checks to save water.

1. Only the largest pump’s rating
2. Only the monthly PUE
3. Meter timing, accuracy, boundary and unmetered uses
4. Only the inlet pipe’s age

**Correct option(s):** 3

- Option 1: Capacity is not measured lost water.
- Option 2: An energy ratio does not validate the water balance.
- Option 3: These can explain a balance discrepancy.
- Option 4: Age does not locate or prove this discrepancy.

**CDFOS-Q0455 · single · mechanism**

Why does withdrawal differ from consumption?

Synthetic training case — not a field record.

For a stated period, on-site water use is 120000 L and IT energy is 60000 kWh. A separate estimate attributes 30000 L to electricity production upstream. An inlet meter records 10000 L during a shorter audit window; documented outlet/use totals are 8500 L and stored volume rises 500 L. Meter timing/accuracy and unmetered uses have not been checked. A proposal would stop treatment checks to save water.

1. Withdrawal is an energy quantity
2. Some withdrawn water may be returned under defined conditions
3. All withdrawn water is always permanently consumed
4. Consumption counts only drinking water

**Correct option(s):** 2

- Option 1: It is a water-flow accounting concept.
- Option 2: The quantities describe different boundary flows.
- Option 3: Return flows can exist.
- Option 4: Industrial use can consume water.

**CDFOS-Q0456 · single · mechanism**

What is wrong with stopping treatment checks solely to reduce reported use?

Synthetic training case — not a field record.

For a stated period, on-site water use is 120000 L and IT energy is 60000 kWh. A separate estimate attributes 30000 L to electricity production upstream. An inlet meter records 10000 L during a shorter audit window; documented outlet/use totals are 8500 L and stored volume rises 500 L. Meter timing/accuracy and unmetered uses have not been checked. A proposal would stop treatment checks to save water.

1. Checks have no relationship to process condition
2. A lower ratio automatically proves safe water chemistry
3. It can remove a required protective function without competent review
4. Any water-saving idea is prohibited

**Correct option(s):** 3

- Option 1: Their purpose may be to verify required treatment and quality.
- Option 2: The ratio contains no such measurement.
- Option 3: Water chemistry and health/equipment constraints must remain controlled.
- Option 4: Reviewed changes can improve efficiency safely.

**CDFOS-Q0457 · single · operations**

Which context matters when comparing two identical water ratios?

Synthetic training case — not a field record.

For a stated period, on-site water use is 120000 L and IT energy is 60000 kWh. A separate estimate attributes 30000 L to electricity production upstream. An inlet meter records 10000 L during a shorter audit window; documented outlet/use totals are 8500 L and stored volume rises 500 L. Meter timing/accuracy and unmetered uses have not been checked. A proposal would stop treatment checks to save water.

1. Local scarcity, water source, discharge and reporting boundaries
2. Only the number of installed racks
3. Only the operators’ preferred units after conversion
4. Only the lowest daily PUE

**Correct option(s):** 1

- Option 1: Equal ratios can have different environmental consequences.
- Option 2: Rack count does not explain water stress or boundary.
- Option 3: Units alone do not capture local impact.
- Option 4: Energy overhead is not the full water context.

**CDFOS-Q0458 · single · operations**

Who should approve a change to discharge or treatment constraints?

Synthetic training case — not a field record.

For a stated period, on-site water use is 120000 L and IT energy is 60000 kWh. A separate estimate attributes 30000 L to electricity production upstream. An inlet meter records 10000 L during a shorter audit window; documented outlet/use totals are 8500 L and stored volume rises 500 L. Meter timing/accuracy and unmetered uses have not been checked. A proposal would stop treatment checks to save water.

1. The assigned competent specialists using applicable local requirements
2. The metric author without process review
3. The supplier of an unrelated IT switch
4. Any dashboard viewer who sees a high ratio

**Correct option(s):** 1

- Option 1: These are site- and process-dependent obligations.
- Option 2: Reporting responsibility is not treatment-design competence.
- Option 3: That role has no stated authority for the process.
- Option 4: Visibility does not confer authority.

**CDFOS-Q0459 · single · operations**

What should a liquid-cooling water initiative preserve?

Synthetic training case — not a field record.

For a stated period, on-site water use is 120000 L and IT energy is 60000 kWh. A separate estimate attributes 30000 L to electricity production upstream. An inlet meter records 10000 L during a shorter audit window; documented outlet/use totals are 8500 L and stored volume rises 500 L. Meter timing/accuracy and unmetered uses have not been checked. A proposal would stop treatment checks to save water.

1. Only the lowest inlet-water meter total
2. Only the controller returning to its normal mode after the change
3. Coolant compatibility, leak protection, thermal performance and recovery interfaces
4. Only the rack’s IT power rating

**Correct option(s):** 3

- Option 1: A single quantity cannot establish safe service.
- Option 2: Mode alone does not prove compatibility, leak protection or thermal service.
- Option 3: These functions interact with availability and equipment condition.
- Option 4: Thermal and fluid interfaces need separate evidence.

**CDFOS-Q0460 · single · diagnosis**

What is the appropriate status of the 1000 L discrepancy now?

Synthetic training case — not a field record.

For a stated period, on-site water use is 120000 L and IT energy is 60000 kWh. A separate estimate attributes 30000 L to electricity production upstream. An inlet meter records 10000 L during a shorter audit window; documented outlet/use totals are 8500 L and stored volume rises 500 L. Meter timing/accuracy and unmetered uses have not been checked. A proposal would stop treatment checks to save water.

1. An unresolved measurement/process balance requiring investigation
2. A confirmed pipe failure at the cooling unit
3. A verified meter fault
4. A documented environmental violation

**Correct option(s):** 1

- Option 1: The evidence identifies a question but not a proven cause.
- Option 2: No location or failed component is established.
- Option 3: Meter error is only one possible explanation.
- Option 4: Applicable limits and the physical cause are not established by this arithmetic.

**CDFOS-Q0461 · single · operations**

Which claim is unsupported by annual quantity matching alone?

Synthetic training case — not a field record.

A site buys annual renewable-energy attributes matching its annual electricity quantity. Its physical grid connection and backup system are unchanged. A draft claim says “renewable power every hour and guaranteed outage independence.” A server-replacement proposal compares operating electricity but omits manufacture, repairability and disposal. Retired drives contain customer data; the recycler has supplied a collection receipt only.

1. That electricity was consumed during the year
2. That contractual instruments can be relevant to accounting
3. Renewable physical supply in every hour
4. That annual purchased attributes have a recorded quantity

**Correct option(s):** 3

- Option 1: The annual electricity quantity is part of the premise.
- Option 2: They can be, subject to the applicable method and quality requirements.
- Option 3: Annual accounting does not establish hourly matching or physical delivery.
- Option 4: The case states the purchased quantity is recorded.

**CDFOS-Q0462 · single · mechanism**

Why is outage independence unproven?

Synthetic training case — not a field record.

A site buys annual renewable-energy attributes matching its annual electricity quantity. Its physical grid connection and backup system are unchanged. A draft claim says “renewable power every hour and guaranteed outage independence.” A server-replacement proposal compares operating electricity but omits manufacture, repairability and disposal. Retired drives contain customer data; the recycler has supplied a collection receipt only.

1. Grid supply becomes unnecessary whenever a certificate exists
2. The physical supply and backup capability have not changed or been demonstrated
3. Annual energy quantity equals available instantaneous capacity
4. Renewable contracts always disable backup generators

**Correct option(s):** 2

- Option 1: The physical load still needs a functioning supply.
- Option 2: An attribute purchase does not create islanded capacity.
- Option 3: Energy and power capability are different quantities.
- Option 4: No such physical effect follows.

**CDFOS-Q0463 · single · operations**

What should accompany a market-based emissions calculation?

Synthetic training case — not a field record.

A site buys annual renewable-energy attributes matching its annual electricity quantity. Its physical grid connection and backup system are unchanged. A draft claim says “renewable power every hour and guaranteed outage independence.” A server-replacement proposal compares operating electricity but omits manufacture, repairability and disposal. Retired drives contain customer data; the recycler has supplied a collection receipt only.

1. Only the quantity of renewable energy the supplier reports generating elsewhere
2. Applicable method, qualifying instruments, factors, period and activity data
3. Only the supplier’s general statement that the product is renewable
4. Only site PUE

**Correct option(s):** 2

- Option 1: Generation quantity alone does not demonstrate that qualifying instruments apply to this entity, period and electricity use.
- Option 2: The accounting claim needs traceable inputs and eligibility.
- Option 3: A marketing statement does not establish eligible contractual instruments, factors, activity data or method boundaries.
- Option 4: PUE supplies neither the emissions factor nor instrument eligibility.

**CDFOS-Q0464 · single · mechanism**

What does a location-based electricity method principally reflect?

Synthetic training case — not a field record.

A site buys annual renewable-energy attributes matching its annual electricity quantity. Its physical grid connection and backup system are unchanged. A draft claim says “renewable power every hour and guaranteed outage independence.” A server-replacement proposal compares operating electricity but omits manufacture, repairability and disposal. Retired drives contain customer data; the recycler has supplied a collection receipt only.

1. Emissions intensity associated with the relevant grid/location under its rules
2. Only backup fuel consumed on site
3. The number of servers purchased that year
4. The customer’s selected certificate price

**Correct option(s):** 1

- Option 1: It differs from contractual instrument attribution.
- Option 2: Direct fuel emissions are a separate accounting boundary.
- Option 3: Server count is not the electricity emissions calculation.
- Option 4: Price is not the grid emissions factor.

**CDFOS-Q0465 · single · operations**

What must be checked before applying an announced guidance revision?

Synthetic training case — not a field record.

A site buys annual renewable-energy attributes matching its annual electricity quantity. Its physical grid connection and backup system are unchanged. A draft claim says “renewable power every hour and guaranteed outage independence.” A server-replacement proposal compares operating electricity but omits manufacture, repairability and disposal. Retired drives contain customer data; the recycler has supplied a collection receipt only.

1. Whether one supplier already uses its terminology
2. Whether it is published and applicable rather than only a consultation proposal
3. Whether the previous method can be deleted from the audit trail
4. Whether it produces a lower reported value

**Correct option(s):** 2

- Option 1: Supplier usage does not establish adopted requirements.
- Option 2: A draft change is not automatically the reporting rule.
- Option 3: Past reporting methods should remain traceable.
- Option 4: Favorability does not determine applicability.

**CDFOS-Q0466 · single · operations**

What is missing from the replacement comparison?

Synthetic training case — not a field record.

A site buys annual renewable-energy attributes matching its annual electricity quantity. Its physical grid connection and backup system are unchanged. A draft claim says “renewable power every hour and guaranteed outage independence.” A server-replacement proposal compares operating electricity but omits manufacture, repairability and disposal. Retired drives contain customer data; the recycler has supplied a collection receipt only.

1. A stated life-cycle boundary covering relevant embodied impacts, repair and end of life
2. Only the vendor’s unqualified claim of improved sustainability
3. Only the new model’s maximum clock speed
4. Only the new server’s operating electricity at its peak rating

**Correct option(s):** 1

- Option 1: Operating energy is only one dimension.
- Option 2: A claim without a defined lifecycle boundary does not resolve the omitted impacts.
- Option 3: Peak specification alone does not evaluate lifecycle effects.
- Option 4: A single operating point still omits manufacture, repair and disposal.

**CDFOS-Q0467 · single · operations**

What evidence would support keeping equipment longer?

Synthetic training case — not a field record.

A site buys annual renewable-energy attributes matching its annual electricity quantity. Its physical grid connection and backup system are unchanged. A draft claim says “renewable power every hour and guaranteed outage independence.” A server-replacement proposal compares operating electricity but omits manufacture, repairability and disposal. Retired drives contain customer data; the recycler has supplied a collection receipt only.

1. Age alone, regardless of support or workload
2. Measured service adequacy, maintainability and comparative life-cycle effects
3. An assumption that repair always has zero environmental impact
4. The absence of a procurement request

**Correct option(s):** 2

- Option 1: Age is not a complete performance or risk assessment.
- Option 2: Retention should meet the service while assessing impacts.
- Option 3: Repair also consumes resources.
- Option 4: Administrative inactivity does not demonstrate suitability.

**CDFOS-Q0468 · single · operations**

What remains necessary before drives leave custody?

Synthetic training case — not a field record.

A site buys annual renewable-energy attributes matching its annual electricity quantity. Its physical grid connection and backup system are unchanged. A draft claim says “renewable power every hour and guaranteed outage independence.” A server-replacement proposal compares operating electricity but omits manufacture, repairability and disposal. Retired drives contain customer data; the recycler has supplied a collection receipt only.

1. Only an energy-efficiency comparison
2. Authorized data sanitization/disposition and traceable custody
3. Only removal of the asset sticker
4. Only an email saying the recycler is convenient

**Correct option(s):** 2

- Option 1: That does not protect retained information.
- Option 2: Environmental handling does not remove information-protection duties.
- Option 3: A label change does not remove stored data.
- Option 4: Convenience is not the required disposition evidence.

**CDFOS-Q0469 · single · mechanism**

What does the collection receipt establish by itself?

Synthetic training case — not a field record.

A site buys annual renewable-energy attributes matching its annual electricity quantity. Its physical grid connection and backup system are unchanged. A draft claim says “renewable power every hour and guaranteed outage independence.” A server-replacement proposal compares operating electricity but omits manufacture, repairability and disposal. Retired drives contain customer data; the recycler has supplied a collection receipt only.

1. A recorded handoff within its stated scope
2. Certified destruction of all data
3. Zero environmental impact from transport and processing
4. Verified final recycling of every material

**Correct option(s):** 1

- Option 1: It does not prove every downstream processing claim.
- Option 2: The receipt does not state or demonstrate that operation.
- Option 3: No such measurement is provided.
- Option 4: Collection precedes downstream treatment.

**CDFOS-Q0470 · single · operations**

What is a defensible sustainability communication?

Synthetic training case — not a field record.

A site buys annual renewable-energy attributes matching its annual electricity quantity. Its physical grid connection and backup system are unchanged. A draft claim says “renewable power every hour and guaranteed outage independence.” A server-replacement proposal compares operating electricity but omits manufacture, repairability and disposal. Retired drives contain customer data; the recycler has supplied a collection receipt only.

1. Report only the most favorable site without disclosing scope
2. Merge annual attributes and hourly physical supply into one claim
3. Call an operating-energy reduction a complete zero-impact lifecycle
4. State the measured boundary, method, evidence and remaining limits

**Correct option(s):** 4

- Option 1: That can misrepresent a portfolio claim.
- Option 2: Those are different propositions.
- Option 3: Other impacts remain outside that measurement.
- Option 4: Readers can distinguish the result from unsupported extensions.

#### Recall

**A two-period efficiency report — Synthetic training case — not a field record.

Month A: facility 150 MWh, IT 100 MWh. Month B: facility 100 MWh, IT 50 MWh. Both measurements share the same complete boundary. A draft reports PUE 1.75 as the annual value, although only these two months are available. A third month lacks its IT meter data.**

A and B have PUE 1.5 and 2.0; together 250/150 = 1.6667. Label it a two-month aggregate, not an annual result. Preserve the missing third-month denominator as a data-quality issue. PUE does not establish useful IT work or carbon intensity.

**An airflow trial and a savings claim — Synthetic training case — not a field record.

A contained-aisle airflow trial changes a control setting. Average facility power falls from 200 to 192 kW over a 100-hour trial; IT load is unchanged, but outside temperature is lower. Flat energy charge is 0.12 currency/kWh; demand charges are separate. A sensor at the hottest rack crosses the predefined rollback threshold. The proposed permanent change costs 1200 currency.**

The observed energy difference is 8 × 100 = 800 kWh and its stated energy-charge value is 96. Weather is a confounder, so the causal saving is unproven. Execute the approved rollback response when its threshold is reached. Do not annualize a short uncontrolled trial or ignore service limits to achieve a favorable ratio.

**Water accounting and an unresolved balance — Synthetic training case — not a field record.

For a stated period, on-site water use is 120000 L and IT energy is 60000 kWh. A separate estimate attributes 30000 L to electricity production upstream. An inlet meter records 10000 L during a shorter audit window; documented outlet/use totals are 8500 L and stored volume rises 500 L. Meter timing/accuracy and unmetered uses have not been checked. A proposal would stop treatment checks to save water.**

The stated on-site ratio is 2 L/kWh; including the separate source quantity would give 2.5 L/kWh under an explicitly expanded method, not the same metric boundary. The audit has an unexplained 1000 L difference, which calls for validation rather than an immediate leak location claim. Protective treatment requirements need competent review and cannot be silently removed for a metric.

**Renewable claims and equipment lifecycle — Synthetic training case — not a field record.

A site buys annual renewable-energy attributes matching its annual electricity quantity. Its physical grid connection and backup system are unchanged. A draft claim says “renewable power every hour and guaranteed outage independence.” A server-replacement proposal compares operating electricity but omits manufacture, repairability and disposal. Retired drives contain customer data; the recycler has supplied a collection receipt only.**

Annual attribute matching does not establish hourly physical supply or outage resilience. Report the applicable accounting method and instrument evidence within its limits. Compare replacement options using a declared lifecycle boundary, and retain secure sanitization and downstream service due diligence rather than treating collection as proof of every disposal outcome.

#### References

- [EPI CDFOS public syllabus](https://www.epi-ap.com/services/1/3/136)
- [The Green Grid PUE examination, hosted by Lawrence Berkeley National Laboratory](https://datacenters.lbl.gov/sites/default/files/WP49-PUE%20A%20Comprehensive%20Examination%20of%20the%20Metric_v6.pdf)
- [The Green Grid water usage effectiveness](https://www.thegreengrid.org/system/files/store/WUE_v1.pdf)
- [GHG Protocol Scope 2 guidance and revision status](https://ghgprotocol.org/scope-2-guidance)

## CDFOS-M09 — Document authority, asset identity and auditable governance

### CDFOS-L09 — Document authority, asset identity and auditable governance

Estimated study time: 120 minutes before independent work. Prerequisite chapters: CDFOS-L08

## Governance makes authority and evidence usable

Governance defines who can decide, what evidence is required, which obligations apply and how exceptions are reviewed. It is not satisfied by collecting documents after the work. A facilities procedure can be technically accurate yet unusable because the night shift cannot retrieve it, the current approval is unclear or its referenced asset no longer exists. Conversely, a controlled document can still contain a technical error. Document control establishes identity, authority, version and availability; technical review establishes whether the content is suitable. Both are necessary, with clear ownership rather than an assumption that a document-management system guarantees correctness.

Start with a document register. For each controlled item record a stable identifier, title, type, owner, version, status, approvers, applicable systems, effective date, review trigger, storage location, access group and retention/disposition rule. A filename alone is a poor stable identity: people rename files and distribute copies. A cryptographic hash can identify an exact digital artifact, but it cannot establish whether the content is approved, current or safe. The register links the artifact to the decision and operating scope. A draft, an approved future revision and the currently effective revision may all coexist legitimately if their status and use are unambiguous.

The EPI public CDFOS outline references six document-management subprocesses without publishing their individual names. This chapter uses an original six-stage working model for teaching: create, review, approve, issue, maintain, and retire/retain. These are explanatory labels, not a claim to reproduce the provider's protected terminology. The mechanisms matter: generate usable content from requirements and evidence; have the appropriate competence examine it; obtain the required authority; distribute the effective version; reassess it after relevant changes; and withdraw obsolete operational copies while retaining records according to applicable rules.

## Create, review, approve and issue

Creation begins with the actual task and its users. An operating procedure needs prerequisites, affected assets, required competence and authority, current state checks, sequence, decision points, expected observations, abort/rollback conditions, handback and evidence requirements. Avoid phrases such as “check operation” without specifying the observable acceptance. Reference drawings and vendor instructions by controlled identity/version or another maintained relationship. If a prerequisite cannot be verified, the procedure should define the hold and escalation, not encourage improvisation. Accessibility includes language, readability, offline availability where needed and the ability to use the document in the work environment.

Review should follow the consequences of error. A facilities integration document may require controls, network, operations and relevant power/mechanical interface reviewers. Each reviewer addresses their assigned scope rather than approving unrelated specialist design. Resolve conflicting comments through a recorded decision. A review comment marked closed should point to a changed section, a reasoned rejection or another resolution, not merely disappear. A walkthrough can expose missing state checks; an authorized trial or simulation can provide additional evidence at its actual fidelity. A paper review does not prove that a live plant responds as expected.

Approval assigns accountability for release within the site's authority model. Authorship, technical review and operational authorization may be separate roles. A copied signature image or old approval email cannot automatically authorize a changed revision. Record exactly which artifact and scope were approved, by whom and when, with any restrictions. Approved-but-not-effective content needs an activation condition, especially when it depends on an installed change. Activating instructions before the matching configuration exists can be as dangerous as retaining old instructions after the change.

Issue the effective version through controlled distribution. Identify workstations, printed binders, mobile caches and supplier copies that may be used. Notify affected roles, obtain required training or acknowledgement, and withdraw or conspicuously invalidate superseded operating copies. Acknowledgement of receipt is not proof of task competence. Offline copies need a refresh and expiration method appropriate to their use; unavailable network storage during a crisis must not make required emergency guidance inaccessible. Access controls should protect integrity without preventing authorized operators from obtaining necessary instructions at the point of use.

## Maintain, retire and preserve evidence

Maintenance is triggered by more than a calendar date. Configuration changes, incidents, near misses, altered vendor guidance, new duties and failed walkthroughs may require review. A due review can confirm that content remains correct; do not increment a technical revision solely to create the appearance of change without recording what occurred. Conversely, even a small wording change can alter a decision threshold and require renewed technical approval. Keep revision history meaningful: what changed, why, which evidence supports it and what related documents or training are affected.

Emergency changes need a controlled expedited path. Record the temporary instruction's authority, exact scope, effective time, expiration, restrictions and return-to-normal plan. Link it to the permanent baseline and make its precedence clear to every affected shift. Expedited does not mean undocumented. If a temporary instruction expires before the permanent change is ready, the decision must be reassessed by the proper authority; an operator cannot silently extend it because it is convenient. Review actual execution evidence afterward so the permanent update reflects what was learned rather than merely copying a hurried note.

Retirement removes obsolete instructions from operational use while preserving records according to their purpose and retention requirements. “Delete all old versions” can destroy evidence needed to explain a past work order. “Keep every old version available beside the current one” can invite wrong-version execution. Archive with restricted status and traceability; retain the version that governed a historical event. Legal holds, contractual obligations, privacy requirements and approved disposal rules may affect retention. This course provides process literacy, not universal retention durations or legal advice for every jurisdiction.

Restoration of the document repository needs its own acceptance. Recovering readable files is insufficient if permissions, approval records, links, timestamps or effective-status metadata are lost. Test retrieval from a representative operator account and confirm that the active procedure matches the actual configuration. A backup from before an emergency instruction may be internally consistent yet operationally obsolete. Recovery should reconcile post-backup changes and re-establish the approved current state before declaring the service usable. Preserve the recovery evidence and any temporary access changes.

## Govern assets as relationships through time

An asset register becomes useful when stable identity, location, function, relationships and lifecycle status are accurate. A display name or network address is not necessarily identity: a device can move or receive a new address, and an address can be reused by a replacement. Record manufacturer/model/serial where applicable, site asset identifier, owner, installation and support information, configuration baseline, maintenance obligations and dependencies. CMMS, DCIM such as Sunbird, EPMS/BMS inventories and network configuration systems may each hold part of the truth. Define the authoritative fields and reconciliation rules rather than expecting identical databases without a governance model.

Relationships explain operational consequence. A meter measures a specified circuit; a controller serves a group of actuators; a rack depends on particular power and cooling paths. A discovered address confirms an observation, not every physical relationship. Reconcile discrepancies with controlled field evidence and change history. Do not automatically overwrite a reviewed physical asset record with an unverified scan. Record uncertainty and assign resolution when the evidence conflicts. Data-quality measures should assess required field accuracy, relationship completeness and timely updates, not only the number of database rows.

At acquisition, verify accepted identity and intended service. During operation, connect work orders, incidents and changes to the same stable asset identity. During replacement, preserve the old asset's history and establish the new device's identity even if it inherits the same name or address. At retirement, distinguish administrative approval, physical disconnection, data disposition, removal and release of capacity. These milestones can occur at different times. Releasing a rack's power reservation before the physical load is removed can overcommit capacity; deleting the old record can erase maintenance or custody evidence.

An audit follows a decision from obligation to approved method, executed record and resulting state. Sampling can reveal weaknesses, but a sample of five accurate assets does not prove every asset is correct. Record the population, selection method, findings, limitations and corrective actions. Close an action only when the required change and its effectiveness are demonstrated. Governance works when the next authorized person can recover the current state, understand why it is accepted and use the evidence to make a better decision without relying on the memory of the previous shift.


#### Worked demonstrations

**A signed draft and a changed threshold**

Synthetic training case — not a field record.

Procedure OP-17 revision 3 is effective. Revision 4 is approved for use only after control change CH-9, which is not installed. A technician edits revision 4’s abort threshold after approval but retains the original approval page. A printed copy is labeled “latest” without a revision. The review record says “checked” without scope or comments.

**Reasoning:** Use the currently effective revision for its matching configuration, subject to any separately authorized temporary instruction. The post-approval threshold change needs appropriate review and approval; an old signature does not cover it. Identify exact versions and activation conditions, and improve review evidence rather than trusting “latest.”

**Offline copies, temporary instructions and repository recovery**

Synthetic training case — not a field record.

A night shift has an offline copy of OP-17 revision 3. An authorized temporary instruction T-6 changes one response until 06:00. The shift handover omits T-6. At 04:00 the document repository is restored from a backup made before T-6; files open, but role permissions and effective-status metadata are missing. Work order W-88 was executed under revision 2 last month.

**Reasoning:** Reconcile the temporary instruction and repository state, distribute the current authorized operating context and restore access/status metadata before claiming usable recovery. Do not silently extend T-6 beyond its authority. Preserve revision 2 as a historical record linked to W-88 while preventing its accidental operational use.

**Stable asset identity across a controller replacement**

Synthetic training case — not a field record.

Controller asset A-104 serial OLD7 is replaced by serial NEW9 using the same hostname and IP address. CMMS still attaches work orders to OLD7; DCIM lists the rack relationship; BMS discovery overwrites the serial but loses the old maintenance history. A retired rack still draws power, although its 5 kW reservation has already been released. An audit checks five convenient records from a population of 400.

**Reasoning:** Preserve the retired device’s identity/history and establish the replacement identity with inherited service relationships explicitly verified. Reconcile authoritative fields across systems rather than treating an address as immutable identity. Capacity release requires the relevant physical and administrative milestones. The small convenience sample supports only a bounded audit conclusion.

#### Guided practice

Resolve the three document and asset cases into an effective-state register, repository recovery acceptance and controller replacement record.

**Hint:** Distinguish identity, content, approval, effective status, distribution, historical retention and physical lifecycle milestones.

**Worked solution:** Keep revision 3 effective until its replacement’s activation conditions are met; re-review the altered threshold; distribute T-6 with expiry and reconcile it after restore. Preserve revision 2 as history for W-88. Create the new controller identity without destroying OLD7’s history, verify relationships and withhold capacity release until physical evidence supports it.

#### Independent task

Environment: analytical

Build a small governance evidence pack for the synthetic replacement and procedure change.

**Packaged starter material**

- course_labs/CDFOS/README.md
- course_labs/CDFOS/fixture.json
- course_labs/CDFOS/assessment_template.md
- course_labs/CDFOS/lab.py
- course_labs/CDFOS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- Document register and revision/activation decision
- Temporary-instruction handover and restore acceptance
- Old/new asset relationship and lifecycle record
- Audit finding and effectiveness check

**Acceptance criteria**

- No historical evidence is rewritten to match a newer state.
- Current instructions are accessible and unambiguous to the receiving shift.
- Authority and physical completion are supported independently.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer. The bundled calculator was executed against supplied synthetic fixtures; its numerical checks do not grade physical work or professional authorization.

#### Chapter practice

**CDFOS-Q0471 · single · operations**

Which revision is currently effective under the stated record?

Synthetic training case — not a field record.

Procedure OP-17 revision 3 is effective. Revision 4 is approved for use only after control change CH-9, which is not installed. A technician edits revision 4’s abort threshold after approval but retains the original approval page. A printed copy is labeled “latest” without a revision. The review record says “checked” without scope or comments.

1. The unnumbered printed copy
2. Revision 3
3. Revision 4 because it has a larger number
4. The technician’s edited draft automatically

**Correct option(s):** 2

- Option 1: The label latest does not establish controlled identity.
- Option 2: Revision 4 has an unmet activation condition.
- Option 3: Version order does not override effective-status conditions.
- Option 4: Editing does not confer release authority.

**CDFOS-Q0472 · single · mechanism**

Why is retaining the original approval page insufficient after the threshold edit?

Synthetic training case — not a field record.

Procedure OP-17 revision 3 is effective. Revision 4 is approved for use only after control change CH-9, which is not installed. A technician edits revision 4’s abort threshold after approval but retains the original approval page. A printed copy is labeled “latest” without a revision. The review record says “checked” without scope or comments.

1. The technician’s familiarity replaces technical review
2. All threshold edits are purely cosmetic
3. The approved artifact and decision logic have changed
4. Approval pages can never be retained as history

**Correct option(s):** 3

- Option 1: Competence alone does not establish the required authorization.
- Option 2: They can change when work stops or rolls back.
- Option 3: The original approval does not automatically cover new content.
- Option 4: They may be retained for the exact historical revision.

**CDFOS-Q0473 · single · operations**

What should identify the exact approved digital artifact?

Synthetic training case — not a field record.

Procedure OP-17 revision 3 is effective. Revision 4 is approved for use only after control change CH-9, which is not installed. A technician edits revision 4’s abort threshold after approval but retains the original approval page. A printed copy is labeled “latest” without a revision. The review record says “checked” without scope or comments.

1. Only the most recent file modification time
2. Only the author’s username
3. Controlled version and artifact identity linked to its approval record
4. Only a filename containing final

**Correct option(s):** 3

- Option 1: Timestamp recency does not prove approval.
- Option 2: An author can create several different drafts.
- Option 3: This connects the decision to a specific content state.
- Option 4: Names can be reused or changed.

**CDFOS-Q0474 · single · mechanism**

What does a hash by itself establish?

Synthetic training case — not a field record.

Procedure OP-17 revision 3 is effective. Revision 4 is approved for use only after control change CH-9, which is not installed. A technician edits revision 4’s abort threshold after approval but retains the original approval page. A printed copy is labeled “latest” without a revision. The review record says “checked” without scope or comments.

1. That the file is the currently effective revision
2. That every operator has read the procedure
3. That the procedure is operationally safe
4. An exact content identity for comparison, within the algorithm’s use

**Correct option(s):** 4

- Option 1: Status requires controlled records.
- Option 2: Content identity is not distribution evidence.
- Option 3: Correct hashing does not review technical content.
- Option 4: It does not establish suitability or approval.

**CDFOS-Q0475 · single · operations**

How should the unnumbered printed copy be handled?

Synthetic training case — not a field record.

Procedure OP-17 revision 3 is effective. Revision 4 is approved for use only after control change CH-9, which is not installed. A technician edits revision 4’s abort threshold after approval but retains the original approval page. A printed copy is labeled “latest” without a revision. The review record says “checked” without scope or comments.

1. Treat any paper copy as permanently valid
2. Keep it beside all drafts and let the operator choose
3. Reconcile it with the controlled issue and withdraw or replace it as needed
4. Write a new date on it without checking content

**Correct option(s):** 3

- Option 1: Configuration and instructions can change.
- Option 2: That leaves version ambiguity at the point of use.
- Option 3: Its authority cannot be assumed from latest.
- Option 4: A fresh date does not establish an approved revision.

**CDFOS-Q0476 · single · operations**

What is missing from the review entry checked?

Synthetic training case — not a field record.

Procedure OP-17 revision 3 is effective. Revision 4 is approved for use only after control change CH-9, which is not installed. A technician edits revision 4’s abort threshold after approval but retains the original approval page. A printed copy is labeled “latest” without a revision. The review record says “checked” without scope or comments.

1. Only a list of reviewed document titles without findings or scope
2. Review scope, competent reviewer, findings and resolution evidence
3. Only evidence that the reviewer received the file
4. Only a repeated approval date without the reviewed artifact identity

**Correct option(s):** 2

- Option 1: A title list does not show what was assessed or resolved.
- Option 2: The word alone cannot demonstrate what was assessed.
- Option 3: Receipt does not establish technical review.
- Option 4: The record still cannot establish the exact scope or content examined.

**CDFOS-Q0477 · single · implementation**

What should happen if CH-9 installation is delayed?

Synthetic training case — not a field record.

Procedure OP-17 revision 3 is effective. Revision 4 is approved for use only after control change CH-9, which is not installed. A technician edits revision 4’s abort threshold after approval but retains the original approval page. A printed copy is labeled “latest” without a revision. The review record says “checked” without scope or comments.

1. Delete revision 3 immediately because approval of 4 exists
2. Activate revision 4 on its planned date regardless of configuration
3. Remove the condition from 4 without authorization
4. Keep the activation dependency controlled and reassess affected plans

**Correct option(s):** 4

- Option 1: The effective version is still required.
- Option 2: That can mismatch instructions and plant state.
- Option 3: That changes the approved release decision.
- Option 4: The future procedure must not silently become effective.

**CDFOS-Q0478 · single · operations**

What should the procedure’s abort instruction contain?

Synthetic training case — not a field record.

Procedure OP-17 revision 3 is effective. Revision 4 is approved for use only after control change CH-9, which is not installed. A technician edits revision 4’s abort threshold after approval but retains the original approval page. A printed copy is labeled “latest” without a revision. The review record says “checked” without scope or comments.

1. Only a reference to an unavailable draft
2. Observable condition, required response and decision authority
3. Only the phrase use judgment
4. Only a target completion time

**Correct option(s):** 2

- Option 1: The instruction must be usable at the point of work.
- Option 2: Operators need an actionable threshold and path.
- Option 3: That omits the agreed observable condition.
- Option 4: Schedule does not define the safe stop condition.

**CDFOS-Q0479 · single · operations**

How are the six stages taught in this chapter represented?

Synthetic training case — not a field record.

Procedure OP-17 revision 3 is effective. Revision 4 is approved for use only after control change CH-9, which is not installed. A technician edits revision 4’s abort threshold after approval but retains the original approval page. A printed copy is labeled “latest” without a revision. The review record says “checked” without scope or comments.

1. A verbatim reproduction of protected EPI terminology
2. A replacement for all site document-control rules
3. Six mandatory universal legal stages
4. An original working model aligned to the public outline’s process topic

**Correct option(s):** 4

- Option 1: The public outline does not publish those labels.
- Option 2: The site’s applicable controlled process still governs.
- Option 3: No such jurisdiction-independent legal claim is made.
- Option 4: The provider’s unpublished stage names are not claimed.

**CDFOS-Q0480 · single · operations**

What should a cross-discipline reviewer approve?

Synthetic training case — not a field record.

Procedure OP-17 revision 3 is effective. Revision 4 is approved for use only after control change CH-9, which is not installed. A technician edits revision 4’s abort threshold after approval but retains the original approval page. A printed copy is labeled “latest” without a revision. The review record says “checked” without scope or comments.

1. Only spelling even when assigned operational logic
2. All future revisions under one unrestricted approval
3. Every specialist design merely because they joined the meeting
4. Their assigned technical/interface scope with unresolved items visible

**Correct option(s):** 4

- Option 1: That would omit their required technical scope.
- Option 2: Future changes need their own controlled assessment.
- Option 3: Participation does not confer competence in every discipline.
- Option 4: Review authority and competence are bounded.

**CDFOS-Q0481 · single · operations**

What is the immediate problem with the offline copy alone?

Synthetic training case — not a field record.

A night shift has an offline copy of OP-17 revision 3. An authorized temporary instruction T-6 changes one response until 06:00. The shift handover omits T-6. At 04:00 the document repository is restored from a backup made before T-6; files open, but role permissions and effective-status metadata are missing. Work order W-88 was executed under revision 2 last month.

1. Its paper or cached format changes the plant automatically
2. Revision 3 can never be used with a temporary instruction
3. It omits a currently authorized temporary instruction
4. Offline copies are always prohibited

**Correct option(s):** 3

- Option 1: The issue is information control, not a physical configuration change.
- Option 2: A bounded instruction can define valid precedence.
- Option 3: The operator lacks the full effective operating context.
- Option 4: Controlled offline access may be needed during outages.

**CDFOS-Q0482 · single · operations**

What must the shift handover communicate about T-6?

Synthetic training case — not a field record.

A night shift has an offline copy of OP-17 revision 3. An authorized temporary instruction T-6 changes one response until 06:00. The shift handover omits T-6. At 04:00 the document repository is restored from a backup made before T-6; files open, but role permissions and effective-status metadata are missing. Work order W-88 was executed under revision 2 last month.

1. Only that all earlier procedures are cancelled
2. Scope, authority, precedence, expiry and required follow-up
3. Only the author’s first name
4. Only its existence without the affected response

**Correct option(s):** 2

- Option 1: The instruction changes one bounded response, not necessarily every procedure.
- Option 2: The next shift must know how it changes the baseline.
- Option 3: Identity alone does not define instruction or authority.
- Option 4: That does not enable correct use.

**CDFOS-Q0483 · single · operations**

What should happen if T-6 is still needed at 06:00?

Synthetic training case — not a field record.

A night shift has an offline copy of OP-17 revision 3. An authorized temporary instruction T-6 changes one response until 06:00. The shift handover omits T-6. At 04:00 the document repository is restored from a backup made before T-6; files open, but role permissions and effective-status metadata are missing. Work order W-88 was executed under revision 2 last month.

1. Assume repository recovery restarts the expiry clock
2. Seek reassessment and authorization through the defined process
3. Change the expiry in the old record without history
4. Let the operator extend it indefinitely

**Correct option(s):** 2

- Option 1: A technical restore does not renew operational authorization.
- Option 2: An expiry cannot be silently ignored.
- Option 3: That destroys traceability of the decision.
- Option 4: That exceeds the recorded authority.

**CDFOS-Q0484 · single · recovery**

Why is opening restored files insufficient for acceptance?

Synthetic training case — not a field record.

A night shift has an offline copy of OP-17 revision 3. An authorized temporary instruction T-6 changes one response until 06:00. The shift handover omits T-6. At 04:00 the document repository is restored from a backup made before T-6; files open, but role permissions and effective-status metadata are missing. Work order W-88 was executed under revision 2 last month.

1. A restore must always reproduce the original physical server
2. A successful file open proves all historical approvals remain attached
3. Every restored file must have a new document number
4. Permissions and effective-status metadata are also required for usable controlled service

**Correct option(s):** 4

- Option 1: Function can be restored on a supported replacement.
- Option 2: The case explicitly says metadata is missing.
- Option 3: Unnecessary renaming can break identity and links.
- Option 4: Readable content alone does not establish correct access or authority.

**CDFOS-Q0485 · single · recovery**

What must be reconciled after this older backup restore?

Synthetic training case — not a field record.

A night shift has an offline copy of OP-17 revision 3. An authorized temporary instruction T-6 changes one response until 06:00. The shift handover omits T-6. At 04:00 the document repository is restored from a backup made before T-6; files open, but role permissions and effective-status metadata are missing. Work order W-88 was executed under revision 2 last month.

1. Only the number of directories
2. Only the backup media capacity
3. Only the oldest archived procedure
4. Post-backup changes including T-6 and their current status

**Correct option(s):** 4

- Option 1: Directory count does not establish content currency.
- Option 2: Capacity does not identify missing instructions.
- Option 3: Recent changes are the known gap.
- Option 4: The backup predates relevant operating information.

**CDFOS-Q0486 · single · operations**

What access test is most useful before returning the repository?

Synthetic training case — not a field record.

A night shift has an offline copy of OP-17 revision 3. An authorized temporary instruction T-6 changes one response until 06:00. The shift handover omits T-6. At 04:00 the document repository is restored from a backup made before T-6; files open, but role permissions and effective-status metadata are missing. Work order W-88 was executed under revision 2 last month.

1. A representative authorized shift account retrieves the correct effective instruction
2. An unauthenticated public user edits every procedure
3. A storage administrator lists files with unrestricted privileges
4. A supplier confirms their own portal is online

**Correct option(s):** 1

- Option 1: It tests the actual operational access path.
- Option 2: That would violate integrity requirements.
- Option 3: That may bypass missing operator permissions.
- Option 4: That is not the restored operator service.

**CDFOS-Q0487 · single · mechanism**

Why preserve revision 2 for W-88?

Synthetic training case — not a field record.

A night shift has an offline copy of OP-17 revision 3. An authorized temporary instruction T-6 changes one response until 06:00. The shift handover omits T-6. At 04:00 the document repository is restored from a backup made before T-6; files open, but role permissions and effective-status metadata are missing. Work order W-88 was executed under revision 2 last month.

1. Older revisions automatically override newer ones
2. It should remain an equally valid current operating choice
3. It establishes the instruction that governed that historical work
4. The work order must be rewritten to claim revision 3 was used

**Correct option(s):** 3

- Option 1: Effective authority is not based on age alone.
- Option 2: Historical retention does not confer current status.
- Option 3: Audit interpretation depends on the version actually used.
- Option 4: That would falsify execution evidence.

**CDFOS-Q0488 · single · operations**

How should archived instructions differ from current ones?

Synthetic training case — not a field record.

A night shift has an offline copy of OP-17 revision 3. An authorized temporary instruction T-6 changes one response until 06:00. The shift handover omits T-6. At 04:00 the document repository is restored from a backup made before T-6; files open, but role permissions and effective-status metadata are missing. Work order W-88 was executed under revision 2 last month.

1. Unrestricted editing by anyone who views them
2. Immediate deletion regardless of holds or requirements
3. Clear non-operational status and controlled retrieval/retention
4. Identical unlabeled placement in the active binder

**Correct option(s):** 3

- Option 1: Historical integrity matters.
- Option 2: Retention obligations may apply.
- Option 3: History should remain usable without inviting wrong-version execution.
- Option 4: That creates ambiguity.

**CDFOS-Q0489 · single · mechanism**

What does acknowledgement of receipt demonstrate?

Synthetic training case — not a field record.

A night shift has an offline copy of OP-17 revision 3. An authorized temporary instruction T-6 changes one response until 06:00. The shift handover omits T-6. At 04:00 the document repository is restored from a backup made before T-6; files open, but role permissions and effective-status metadata are missing. Work order W-88 was executed under revision 2 last month.

1. That every future execution will be correct
2. That the document’s technical content is error-free
3. That a physical trial has passed
4. That the defined receipt/acknowledgement event occurred

**Correct option(s):** 4

- Option 1: Receipt cannot guarantee behavior.
- Option 2: Distribution evidence is not technical validation.
- Option 3: No trial is described.
- Option 4: It does not alone prove competence to execute the task.

**CDFOS-Q0490 · single · operations**

What should a retention decision consider?

Synthetic training case — not a field record.

A night shift has an offline copy of OP-17 revision 3. An authorized temporary instruction T-6 changes one response until 06:00. The shift handover omits T-6. At 04:00 the document repository is restored from a backup made before T-6; files open, but role permissions and effective-status metadata are missing. Work order W-88 was executed under revision 2 last month.

1. Only available disk space
2. Record purpose and applicable policy, contractual and legal constraints
3. A universal course-defined number of days for every document
4. Only whether the original author still works at the site

**Correct option(s):** 2

- Option 1: Storage pressure does not override required retention.
- Option 2: Durations and holds depend on context.
- Option 3: No such universal period applies here.
- Option 4: Records can remain necessary after staff changes.

**CDFOS-Q0491 · single · mechanism**

Why is the reused IP address insufficient as asset identity?

Synthetic training case — not a field record.

Controller asset A-104 serial OLD7 is replaced by serial NEW9 using the same hostname and IP address. CMMS still attaches work orders to OLD7; DCIM lists the rack relationship; BMS discovery overwrites the serial but loses the old maintenance history. A retired rack still draws power, although its 5 kW reservation has already been released. An audit checks five convenient records from a population of 400.

1. IP addresses can never be recorded in an inventory
2. A serial number can only identify a network subnet
3. An address can move between distinct physical devices
4. Reusing an address means no replacement occurred

**Correct option(s):** 3

- Option 1: They are useful attributes, just not always stable identity.
- Option 2: It identifies equipment within the applicable manufacturer context.
- Option 3: The replacement has a different serial and lifecycle history.
- Option 4: The physical serial change contradicts that assumption.

**CDFOS-Q0492 · single · operations**

What should happen to OLD7’s maintenance history?

Synthetic training case — not a field record.

Controller asset A-104 serial OLD7 is replaced by serial NEW9 using the same hostname and IP address. CMMS still attaches work orders to OLD7; DCIM lists the rack relationship; BMS discovery overwrites the serial but loses the old maintenance history. A retired rack still draws power, although its 5 kW reservation has already been released. An audit checks five convenient records from a population of 400.

1. Retain it linked to the old asset and replacement event
2. Delete it because the address stayed the same
3. Detach all dates so the history appears current
4. Move every old fault to NEW9 as if it occurred there

**Correct option(s):** 1

- Option 1: History should not be overwritten by the new device.
- Option 2: Address continuity does not erase history.
- Option 3: That destroys temporal evidence.
- Option 4: That corrupts the new device’s reliability record.

**CDFOS-Q0493 · single · operations**

What should be verified for NEW9 before inheriting service relationships?

Synthetic training case — not a field record.

Controller asset A-104 serial OLD7 is replaced by serial NEW9 using the same hostname and IP address. CMMS still attaches work orders to OLD7; DCIM lists the rack relationship; BMS discovery overwrites the serial but loses the old maintenance history. A retired rack still draws power, although its 5 kW reservation has already been released. An audit checks five convenient records from a population of 400.

1. Only that its shipping box was opened
2. Only that the old device once passed a test
3. Its actual configuration, connected function and accepted interfaces
4. Only its matching hostname

**Correct option(s):** 3

- Option 1: Receipt is not functional acceptance.
- Option 2: The replacement needs evidence for its own state.
- Option 3: Naming continuity does not prove equivalent service.
- Option 4: A name does not establish physical wiring or behavior.

**CDFOS-Q0494 · single · operations**

How should CMMS, DCIM and BMS fields be governed?

Synthetic training case — not a field record.

Controller asset A-104 serial OLD7 is replaced by serial NEW9 using the same hostname and IP address. CMMS still attaches work orders to OLD7; DCIM lists the rack relationship; BMS discovery overwrites the serial but loses the old maintenance history. A retired rack still draws power, although its 5 kW reservation has already been released. An audit checks five convenient records from a population of 400.

1. Let the latest discovered value overwrite every system automatically
2. Define authoritative fields and controlled reconciliation responsibilities
3. Require identical database structures before any asset can be tracked
4. Keep all discrepancies permanently because systems differ

**Correct option(s):** 2

- Option 1: Discovery can be incomplete or wrong for physical relationships.
- Option 2: Each system may own different parts of the asset record.
- Option 3: Different systems can interoperate through defined mappings.
- Option 4: Material conflicts need an owner and resolution.

**CDFOS-Q0495 · single · mechanism**

What is wrong with releasing the retired rack’s 5 kW now?

Synthetic training case — not a field record.

Controller asset A-104 serial OLD7 is replaced by serial NEW9 using the same hostname and IP address. CMMS still attaches work orders to OLD7; DCIM lists the rack relationship; BMS discovery overwrites the serial but loses the old maintenance history. A retired rack still draws power, although its 5 kW reservation has already been released. An audit checks five convenient records from a population of 400.

1. Five kilowatts is a quantity of floor area
2. A reservation can never be released after retirement
3. A DCIM status change physically disconnects every rack
4. The load remains physically present and can consume the supposedly free capacity

**Correct option(s):** 4

- Option 1: It is a power capacity quantity.
- Option 2: It can be released when the required milestones are verified.
- Option 3: No such control action is established.
- Option 4: Administrative retirement alone does not establish release.

**CDFOS-Q0496 · single · mechanism**

Which retirement milestones should remain distinguishable?

Synthetic training case — not a field record.

Controller asset A-104 serial OLD7 is replaced by serial NEW9 using the same hostname and IP address. CMMS still attaches work orders to OLD7; DCIM lists the rack relationship; BMS discovery overwrites the serial but loses the old maintenance history. A retired rack still draws power, although its 5 kW reservation has already been released. An audit checks five convenient records from a population of 400.

1. All milestones must be marked complete when the request is opened
2. Only the hostname and IP address
3. Authorization, disconnection, data disposition, removal and capacity release
4. Only the purchase and invoice dates

**Correct option(s):** 3

- Option 1: A request starts work rather than proves execution.
- Option 2: These attributes do not prove custody or physical removal.
- Option 3: They can occur at different times and require different evidence.
- Option 4: Those do not describe retirement completion.

**CDFOS-Q0497 · single · operations**

What is a better asset-data quality measure than row count alone?

Synthetic training case — not a field record.

Controller asset A-104 serial OLD7 is replaced by serial NEW9 using the same hostname and IP address. CMMS still attaches work orders to OLD7; DCIM lists the rack relationship; BMS discovery overwrites the serial but loses the old maintenance history. A retired rack still draws power, although its 5 kW reservation has already been released. An audit checks five convenient records from a population of 400.

1. Accuracy/completeness of required identities and relationships with timely updates
2. The number of unreviewed discovery imports
3. The largest possible number of duplicate entries
4. Only the percentage of records containing a display name

**Correct option(s):** 1

- Option 1: Rows can be numerous yet wrong or stale.
- Option 2: Import volume does not prove accepted data quality.
- Option 3: Duplicates can obscure the actual population.
- Option 4: A populated name field does not establish identity or relationship accuracy.

**CDFOS-Q0498 · single · operations**

What can the five-record convenience audit establish?

Synthetic training case — not a field record.

Controller asset A-104 serial OLD7 is replaced by serial NEW9 using the same hostname and IP address. CMMS still attaches work orders to OLD7; DCIM lists the rack relationship; BMS discovery overwrites the serial but loses the old maintenance history. A retired rack still draws power, although its 5 kW reservation has already been released. An audit checks five convenient records from a population of 400.

1. That no further corrective action can be needed
2. A precise population defect rate without assumptions
3. Verified accuracy of all 400 assets
4. Findings for the selected records with stated sampling limits

**Correct option(s):** 4

- Option 1: Observed issues and untested records remain relevant.
- Option 2: Convenience sampling lacks a justified statistical basis here.
- Option 3: The sample and selection do not support that universal claim.
- Option 4: It cannot prove the entire population is correct.

**CDFOS-Q0499 · single · diagnosis**

How should a conflict between discovery and controlled field evidence be handled?

Synthetic training case — not a field record.

Controller asset A-104 serial OLD7 is replaced by serial NEW9 using the same hostname and IP address. CMMS still attaches work orders to OLD7; DCIM lists the rack relationship; BMS discovery overwrites the serial but loses the old maintenance history. A retired rack still draws power, although its 5 kW reservation has already been released. An audit checks five convenient records from a population of 400.

1. Create two active assets with the same identity and no explanation
2. Preserve both observations, assess provenance and resolve through the assigned owner
3. Always discard discovery because automation cannot help
4. Always favor the newest timestamp regardless of source

**Correct option(s):** 2

- Option 1: That preserves ambiguity rather than resolves it.
- Option 2: Automatic overwrite can destroy useful evidence.
- Option 3: Discovery can provide valuable observations within its limits.
- Option 4: Recency alone does not establish correctness.

**CDFOS-Q0500 · single · operations**

What closes an asset-governance corrective action?

Synthetic training case — not a field record.

Controller asset A-104 serial OLD7 is replaced by serial NEW9 using the same hostname and IP address. CMMS still attaches work orders to OLD7; DCIM lists the rack relationship; BMS discovery overwrites the serial but loses the old maintenance history. A retired rack still draws power, although its 5 kW reservation has already been released. An audit checks five convenient records from a population of 400.

1. Only repeating the original audit wording
2. Only changing its status to green
3. Evidence of the required correction and its effectiveness against the finding
4. Only assigning the action to someone

**Correct option(s):** 3

- Option 1: Restating the finding does not correct it.
- Option 2: A label does not demonstrate the result.
- Option 3: An updated record alone may not prove the process weakness is resolved.
- Option 4: Ownership begins the response.

#### Recall

**A signed draft and a changed threshold — Synthetic training case — not a field record.

Procedure OP-17 revision 3 is effective. Revision 4 is approved for use only after control change CH-9, which is not installed. A technician edits revision 4’s abort threshold after approval but retains the original approval page. A printed copy is labeled “latest” without a revision. The review record says “checked” without scope or comments.**

Use the currently effective revision for its matching configuration, subject to any separately authorized temporary instruction. The post-approval threshold change needs appropriate review and approval; an old signature does not cover it. Identify exact versions and activation conditions, and improve review evidence rather than trusting “latest.”

**Offline copies, temporary instructions and repository recovery — Synthetic training case — not a field record.

A night shift has an offline copy of OP-17 revision 3. An authorized temporary instruction T-6 changes one response until 06:00. The shift handover omits T-6. At 04:00 the document repository is restored from a backup made before T-6; files open, but role permissions and effective-status metadata are missing. Work order W-88 was executed under revision 2 last month.**

Reconcile the temporary instruction and repository state, distribute the current authorized operating context and restore access/status metadata before claiming usable recovery. Do not silently extend T-6 beyond its authority. Preserve revision 2 as a historical record linked to W-88 while preventing its accidental operational use.

**Stable asset identity across a controller replacement — Synthetic training case — not a field record.

Controller asset A-104 serial OLD7 is replaced by serial NEW9 using the same hostname and IP address. CMMS still attaches work orders to OLD7; DCIM lists the rack relationship; BMS discovery overwrites the serial but loses the old maintenance history. A retired rack still draws power, although its 5 kW reservation has already been released. An audit checks five convenient records from a population of 400.**

Preserve the retired device’s identity/history and establish the replacement identity with inherited service relationships explicitly verified. Reconcile authoritative fields across systems rather than treating an address as immutable identity. Capacity release requires the relevant physical and administrative milestones. The small convenience sample supports only a bounded audit conclusion.

#### References

- [EPI CDFOS public syllabus](https://www.epi-ap.com/services/1/3/136)
