# NETWORK-ENGINEERING — Independent network engineering: campus, edge, wireless, hybrid, AI and controls

Original independent instruction and practice. Read the teaching, work the demonstrations and guided exercise, then attempt questions before reading their explanations. Independent tasks require your own evidence.

Source baseline: [Curriculum Data Center Rev 14 NET-01–10 and CN-01–08 independent engineering scope](https://www.rfc-editor.org/) · Authored curriculum capability course; not a separate certification · checked 2026-09-19

This course extends the data-center vendor courses into independently assessed campus, WAN/Po P, wireless/NAC, hybrid, AI and industrial networking. Authored objectives map capability outcomes rather than an invented exam blueprint.

## Scope and external requirements

- Real RF surveys, fiber measurements, vendor controller integration and physical maintenance require actual equipment.

- Full Cisco SISE and the specified NVIDIA and vendor courses remain assigned teaching; this authored course does not claim to reproduce their paid materials.

- Full profession-level readiness also requires the separately assigned vendor courses and independently accepted practical/operating evidence; a mapped capability or question count is not proof of mastery.

- Measured fiber/copper installation and fault evidence; real RF survey and controlled WLAN/NAC validation.

- Lawful vendor lab access for ISE, controller-based wireless, InfiniBand, RoCE and industrial gateways.

- Independent operation, maintenance and recovery campaigns for each network branch; a single data-center fabric does not satisfy all branches.

## Preparation

Prior courses: See the knowledge prerequisites below.

- CCNA-equivalent Ethernet, IPv4/IPv6, routing and switching foundations.

- Linux, packet capture and basic Python/JSON literacy.

- For storage and DC fabric depth, complete the CCNP-DC and CCIE-DC component chapters and their independent platform workbooks.

## NETWORK-ENGINEERING-M01 — Optical paths, polarity, loss budgets and safe acceptance

### NETWORK-ENGINEERING-L01 — Optical paths, polarity, loss budgets and safe acceptance

Estimated study time: 150 minutes before independent work. Prerequisite chapters: Use the course prerequisites.

A fiber channel works only when optical type, wavelength, connector, polarity, lane mapping, distance and power budget are compatible. Match the transmitter and receiver specifications for the actual module pair; connector fit alone is not interoperability. Parallel optics add lane and polarity dependencies, while breakout requires support at both the module and port configuration. A nominal speed label does not establish those details.

Calculate received power from minimum transmitter power minus worst-case path loss. Compare it with receiver sensitivity and include the specified engineering margin. Also check receiver overload using maximum transmitter power and minimum loss; a short path can overload some receivers. The loss model includes connectors, splices, fiber attenuation and planned repairs. Digital optical monitoring is useful trend evidence, but a transceiver's estimate is not a substitute for calibrated acceptance measurements.

A clean power budget does not prove clean signaling. Inspect error counters, supported FEC behavior, lane health and actual application load. Dirty connectors, bends or wrong polarity can produce different symptoms. Preserve the as-built route and demarcation, because two fibers in one tray may share the same physical failure. Physical work follows the site's laser, cleaning and access procedures; this workbook supplies analysis, not authorization to handle live optics.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA — not captured from equipment.
Optical model: minimum TX -2 dBm; sensitivity -10 dBm; connector/splice/fiber loss 5 dB; required margin 2 dB. Maximum TX +1 dBm; minimum loss 1 dB; overload limit 0 dBm. Two nominally diverse links share one tray. No field measurement is claimed.

**Reasoning:** Worst-case received power is -7 dBm, giving 3 dB above sensitivity and 1 dB beyond the required 2 dB margin. Best-case received power is 0 dBm, exactly at the stated overload limit with no extra headroom. Shared tray routing is a common cause regardless of logical path count.

#### Guided practice

Add 2 dB repair allowance and decide whether the link still meets the required margin.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Worst-case power becomes -9 dBm, only 1 dB above sensitivity, below the required 2 dB margin. Rework the path or select a compatible supported optical solution; do not silently remove the repair allowance.

#### Independent task

Environment: emulator

Engineer and physically validate a documented optical link, including polarity, budget, counters and independent routing.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Worst-case and best-case power satisfy specified bounds.
- Calibrated measurements and error tests match the model.
- Physical diversity is traced to actual routes.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0001 · single · implementation**

What is worst-case received power?

SYNTHETIC TEACHING DATA — not captured from equipment.
Optical model: minimum TX -2 dBm; sensitivity -10 dBm; connector/splice/fiber loss 5 dB; required margin 2 dB. Maximum TX +1 dBm; minimum loss 1 dB; overload limit 0 dBm. Two nominally diverse links share one tray. No field measurement is claimed.

1. -7 dBm
2. -3 dBm
3. +3 dBm

**Correct option(s):** 1

- Option 1: Correct. -2 minus 5 equals -7.
- Option 2: Incorrect. That subtracts the loss incorrectly.
- Option 3: Incorrect. Loss cannot add received power.

**NETWORK-ENGINEERING-Q0002 · single · implementation**

What margin remains above sensitivity?

SYNTHETIC TEACHING DATA — not captured from equipment.
Optical model: minimum TX -2 dBm; sensitivity -10 dBm; connector/splice/fiber loss 5 dB; required margin 2 dB. Maximum TX +1 dBm; minimum loss 1 dB; overload limit 0 dBm. Two nominally diverse links share one tray. No field measurement is claimed.

1. 8 dB
2. 1 dB
3. 3 dB

**Correct option(s):** 3

- Option 1: Incorrect. That ignores path loss.
- Option 2: Incorrect. That is margin beyond the required reserve.
- Option 3: Correct. -7 is 3 dB above -10.

**NETWORK-ENGINEERING-Q0003 · single · implementation**

What changes after 2 dB repair allowance?

SYNTHETIC TEACHING DATA — not captured from equipment.
Optical model: minimum TX -2 dBm; sensitivity -10 dBm; connector/splice/fiber loss 5 dB; required margin 2 dB. Maximum TX +1 dBm; minimum loss 1 dB; overload limit 0 dBm. Two nominally diverse links share one tray. No field measurement is claimed.

1. The original 3 dB margin remains
2. Receiver overload becomes worse
3. Required margin fails

**Correct option(s):** 3

- Option 1: Incorrect. The extra loss must be included.
- Option 2: Incorrect. More loss reduces received power.
- Option 3: Correct. Only 1 dB remains above sensitivity.

**NETWORK-ENGINEERING-Q0004 · single · diagnosis**

Why check maximum received power?

SYNTHETIC TEACHING DATA — not captured from equipment.
Optical model: minimum TX -2 dBm; sensitivity -10 dBm; connector/splice/fiber loss 5 dB; required margin 2 dB. Maximum TX +1 dBm; minimum loss 1 dB; overload limit 0 dBm. Two nominally diverse links share one tray. No field measurement is claimed.

1. It replaces wavelength compatibility
2. Higher power is always better
3. A receiver can be overloaded

**Correct option(s):** 3

- Option 1: Incorrect. Both checks are needed.
- Option 2: Incorrect. Overload imposes an upper limit.
- Option 3: Correct. Sensitivity is not its only bound.

**NETWORK-ENGINEERING-Q0005 · single · implementation**

What defeats the claimed link diversity?

SYNTHETIC TEACHING DATA — not captured from equipment.
Optical model: minimum TX -2 dBm; sensitivity -10 dBm; connector/splice/fiber loss 5 dB; required margin 2 dB. Maximum TX +1 dBm; minimum loss 1 dB; overload limit 0 dBm. Two nominally diverse links share one tray. No field measurement is claimed.

1. Different interface addresses
2. Different transceiver serials
3. The shared tray

**Correct option(s):** 3

- Option 1: Incorrect. They do not determine route independence.
- Option 2: Incorrect. Unique modules can share a path.
- Option 3: Correct. A physical event can affect both.

**NETWORK-ENGINEERING-Q0006 · single · implementation**

Which observation supplements optical power?

SYNTHETIC TEACHING DATA — not captured from equipment.
Optical model: minimum TX -2 dBm; sensitivity -10 dBm; connector/splice/fiber loss 5 dB; required margin 2 dB. Maximum TX +1 dBm; minimum loss 1 dB; overload limit 0 dBm. Two nominally diverse links share one tray. No field measurement is claimed.

1. Only connector fit
2. Errors, FEC and lane health under load
3. Only nominal speed

**Correct option(s):** 2

- Option 1: Incorrect. Mechanical fit is insufficient.
- Option 2: Correct. Power alone does not prove signaling.
- Option 3: Incorrect. It does not show delivered quality.

**NETWORK-ENGINEERING-Q0007 · single · implementation**

What must breakout validation include?

SYNTHETIC TEACHING DATA — not captured from equipment.
Optical model: minimum TX -2 dBm; sensitivity -10 dBm; connector/splice/fiber loss 5 dB; required margin 2 dB. Maximum TX +1 dBm; minimum loss 1 dB; overload limit 0 dBm. Two nominally diverse links share one tray. No field measurement is claimed.

1. Only the aggregate port speed
2. Module and port lane support
3. Only the cable label

**Correct option(s):** 2

- Option 1: Incorrect. Lane arrangement still matters.
- Option 2: Correct. Both ends must match the intended mapping.
- Option 3: Incorrect. Labels can be wrong or incomplete.

**NETWORK-ENGINEERING-Q0008 · single · implementation**

What does DOM not replace?

SYNTHETIC TEACHING DATA — not captured from equipment.
Optical model: minimum TX -2 dBm; sensitivity -10 dBm; connector/splice/fiber loss 5 dB; required margin 2 dB. Maximum TX +1 dBm; minimum loss 1 dB; overload limit 0 dBm. Two nominally diverse links share one tray. No field measurement is claimed.

1. Trend observation
2. Operational alarms
3. Calibrated acceptance measurement

**Correct option(s):** 3

- Option 1: Incorrect. DOM can support trends.
- Option 2: Incorrect. DOM can contribute to alarms.
- Option 3: Correct. It is useful device telemetry with limitations.

**NETWORK-ENGINEERING-Q0009 · single · implementation**

Which record enables later physical diagnosis?

SYNTHETIC TEACHING DATA — not captured from equipment.
Optical model: minimum TX -2 dBm; sensitivity -10 dBm; connector/splice/fiber loss 5 dB; required margin 2 dB. Maximum TX +1 dBm; minimum loss 1 dB; overload limit 0 dBm. Two nominally diverse links share one tray. No field measurement is claimed.

1. As-built path and demarcation
2. Only a purchase invoice
3. Only IP addressing

**Correct option(s):** 1

- Option 1: Correct. Logical topology omits shared routes.
- Option 2: Incorrect. It does not prove installation route.
- Option 3: Incorrect. It does not locate fibers.

**NETWORK-ENGINEERING-Q0010 · single · calculation**

What is the correct response to an infeasible budget?

SYNTHETIC TEACHING DATA — not captured from equipment.
Optical model: minimum TX -2 dBm; sensitivity -10 dBm; connector/splice/fiber loss 5 dB; required margin 2 dB. Maximum TX +1 dBm; minimum loss 1 dB; overload limit 0 dBm. Two nominally diverse links share one tray. No field measurement is claimed.

1. Change the supported design or constraint explicitly
2. Increase software MTU
3. Ignore the required margin

**Correct option(s):** 1

- Option 1: Correct. Do not hide the deficit.
- Option 2: Incorrect. MTU does not repair optical loss.
- Option 3: Incorrect. That violates the requirement.

#### Recall

**What is worst-case received power?**

-7 dBm -2 minus 5 equals -7.

**What defeats the claimed link diversity?**

The shared tray A physical event can affect both.

**Which record enables later physical diagnosis?**

As-built path and demarcation Logical topology omits shared routes.

#### References

- [Cisco transceiver documentation](https://www.cisco.com/c/en/us/products/interfaces-modules/transceiver-modules/index.html)

## NETWORK-ENGINEERING-M02 — Campus switching, STP boundaries and first-hop resilience

### NETWORK-ENGINEERING-L02 — Campus switching, STP boundaries and first-hop resilience

Estimated study time: 150 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L01

Campus access design balances loop prevention, failure scope, endpoint admission and maintainability. A VLAN is a broadcast domain, not a security policy by itself. Decide where Layer 2 ends and routing begins. A routed-access design can reduce spanning-tree scope, while Layer 2 access may support specific mobility or service requirements. Document the consequence rather than treating one architecture as universally superior.

Spanning tree selects forwarding paths through a bridge topology. Root placement should align with the intended traffic and redundancy design. Edge-port acceleration is suitable for actual endpoint attachments; applying it to uncontrolled switching links can expose loops. BPDU guard, root guard and loop-related protections have different triggers and must match the port's role. A guard event should lead to investigation of the attachment, not automatic permanent disabling of the protection.

First-hop redundancy presents a resilient gateway, but gateway state, uplink routing and actual reachability must agree. A gateway can remain active while its upstream path is broken unless tracking or routing behavior removes that preference. Two access uplinks can also share one distribution dependency. Test an endpoint's DHCP, DNS, gateway and application behavior during failures rather than just checking that a virtual IP answers.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: distribution D 1 is active gateway but its routed uplink fails. D 1 still answers ARP. D 2 has a healthy uplink. Access port Gi 1/10 is an edge port with BPDU guard; an attached unmanaged switch sends BPDUs. DHCP is across the distribution layer.

**Reasoning:** The gateway can answer locally while providing no external service. Validate tracking or routing failover so traffic uses D 2 when the required upstream path is lost. The BPDU event indicates the port no longer behaves as the assumed pure endpoint attachment; inspect the topology before changing guard policy.

#### Guided practice

Create acceptance tests for upstream loss and an unauthorized access switch without disconnecting unrelated users.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Test a controlled endpoint through DHCP, DNS and an external application while withdrawing D 1's uplink. Separately attach the authorized test switch in the isolated lab and confirm guard behavior, alarm and recovery procedure. Do not inject loops into production.

#### Independent task

Environment: emulator

Build and assess a campus access/distribution boundary with loop protection and service-aware gateway failover.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Root and gateway roles match design.
- Endpoint service survives the specified upstream loss.
- Unauthorized switching attachment is contained and recoverable.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0011 · single · diagnosis**

Why can gateway ARP succeed while the application fails?

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: distribution D 1 is active gateway but its routed uplink fails. D 1 still answers ARP. D 2 has a healthy uplink. Access port Gi 1/10 is an edge port with BPDU guard; an attached unmanaged switch sends BPDUs. DHCP is across the distribution layer.

1. D 2 must also be down
2. D 1 is locally alive but upstream-isolated
3. ARP proves every route is valid

**Correct option(s):** 2

- Option 1: Incorrect. The case states its uplink is healthy.
- Option 2: Correct. First-hop response is not end-to-end service.
- Option 3: Incorrect. It resolves only the local next hop.

**NETWORK-ENGINEERING-Q0012 · single · implementation**

Which mechanism should address the broken upstream preference?

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: distribution D 1 is active gateway but its routed uplink fails. D 1 still answers ARP. D 2 has a healthy uplink. Access port Gi 1/10 is an edge port with BPDU guard; an attached unmanaged switch sends BPDUs. DHCP is across the distribution layer.

1. Disable all spanning tree
2. Supported tracking or routing convergence
3. Extend every VLAN to the Internet edge

**Correct option(s):** 2

- Option 1: Incorrect. That does not restore the uplink.
- Option 2: Correct. Gateway selection must reflect usable reachability.
- Option 3: Incorrect. That broadens scope without fixing the fault.

**NETWORK-ENGINEERING-Q0013 · single · implementation**

What does the BPDU event challenge?

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: distribution D 1 is active gateway but its routed uplink fails. D 1 still answers ARP. D 2 has a healthy uplink. Access port Gi 1/10 is an edge port with BPDU guard; an attached unmanaged switch sends BPDUs. DHCP is across the distribution layer.

1. The DHCP lease length
2. The endpoint-only port assumption
3. The virtual gateway address

**Correct option(s):** 2

- Option 1: Incorrect. BPDUs do not define leases.
- Option 2: Correct. A bridge is now attached.
- Option 3: Incorrect. The event is at the access boundary.

**NETWORK-ENGINEERING-Q0014 · single · diagnosis**

Why not simply disable BPDU guard?

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: distribution D 1 is active gateway but its routed uplink fails. D 1 still answers ARP. D 2 has a healthy uplink. Access port Gi 1/10 is an edge port with BPDU guard; an attached unmanaged switch sends BPDUs. DHCP is across the distribution layer.

1. BPDUs are always malicious
2. The unexpected topology may create a loop
3. Guard can never be changed

**Correct option(s):** 2

- Option 1: Incorrect. They can come from legitimate but misplaced equipment.
- Option 2: Correct. Investigate before removing containment.
- Option 3: Incorrect. Policy can be revised through a supported design.

**NETWORK-ENGINEERING-Q0015 · single · implementation**

What should determine the Layer 2 boundary?

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: distribution D 1 is active gateway but its routed uplink fails. D 1 still answers ARP. D 2 has a healthy uplink. Access port Gi 1/10 is an edge port with BPDU guard; an attached unmanaged switch sends BPDUs. DHCP is across the distribution layer.

1. Only the number of VLAN names
2. Service and failure-domain requirements
3. Only the switch vendor

**Correct option(s):** 2

- Option 1: Incorrect. Names do not define operational needs.
- Option 2: Correct. Architecture follows constraints.
- Option 3: Incorrect. Vendor identity does not settle the design.

**NETWORK-ENGINEERING-Q0016 · single · implementation**

Which test adds value beyond virtual-IP ping?

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: distribution D 1 is active gateway but its routed uplink fails. D 1 still answers ARP. D 2 has a healthy uplink. Access port Gi 1/10 is an edge port with BPDU guard; an attached unmanaged switch sends BPDUs. DHCP is across the distribution layer.

1. DHCP, DNS and application transactions during failure
2. Only checking the saved hostname
3. Another identical ping at idle

**Correct option(s):** 1

- Option 1: Correct. It exercises dependent services.
- Option 2: Incorrect. It has no forwarding evidence.
- Option 3: Incorrect. It repeats the narrow check.

**NETWORK-ENGINEERING-Q0017 · single · implementation**

What does a VLAN not establish alone?

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: distribution D 1 is active gateway but its routed uplink fails. D 1 still answers ARP. D 2 has a healthy uplink. Access port Gi 1/10 is an edge port with BPDU guard; an attached unmanaged switch sends BPDUs. DHCP is across the distribution layer.

1. A complete security policy
2. A broadcast-domain boundary
3. A logical segment identifier

**Correct option(s):** 1

- Option 1: Correct. Isolation and admission require additional controls.
- Option 2: Incorrect. That is a core VLAN function.
- Option 3: Incorrect. It supplies one.

**NETWORK-ENGINEERING-Q0018 · single · diagnosis**

Why align root placement with design?

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: distribution D 1 is active gateway but its routed uplink fails. D 1 still answers ARP. D 2 has a healthy uplink. Access port Gi 1/10 is an edge port with BPDU guard; an attached unmanaged switch sends BPDUs. DHCP is across the distribution layer.

1. Any root yields identical paths
2. It affects Layer 2 forwarding paths
3. Root identity sets application passwords

**Correct option(s):** 2

- Option 1: Incorrect. Topology and priorities matter.
- Option 2: Correct. Accidental roots can create poor or unsafe paths.
- Option 3: Incorrect. It does not.

**NETWORK-ENGINEERING-Q0019 · single · design**

What must an edge-port designation reflect?

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: distribution D 1 is active gateway but its routed uplink fails. D 1 still answers ARP. D 2 has a healthy uplink. Access port Gi 1/10 is an edge port with BPDU guard; an attached unmanaged switch sends BPDUs. DHCP is across the distribution layer.

1. Only low traffic volume
2. Only a short cable
3. An actual endpoint attachment

**Correct option(s):** 3

- Option 1: Incorrect. A quiet switch can still loop.
- Option 2: Incorrect. Length does not define port role.
- Option 3: Correct. A bridging link has different risks.

**NETWORK-ENGINEERING-Q0020 · single · implementation**

What closes first-hop resilience testing?

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: distribution D 1 is active gateway but its routed uplink fails. D 1 still answers ARP. D 2 has a healthy uplink. Access port Gi 1/10 is an edge port with BPDU guard; an attached unmanaged switch sends BPDUs. DHCP is across the distribution layer.

1. Only an active/standby label
2. Only two configured uplinks
3. Measured application continuity and controlled recovery

**Correct option(s):** 3

- Option 1: Incorrect. Labels do not prove traffic.
- Option 2: Incorrect. They may share failures.
- Option 3: Correct. A protocol role change alone is insufficient.

#### Recall

**Why can gateway ARP succeed while the application fails?**

D 1 is locally alive but upstream-isolated First-hop response is not end-to-end service.

**What should determine the Layer 2 boundary?**

Service and failure-domain requirements Architecture follows constraints.

**What must an edge-port designation reflect?**

An actual endpoint attachment A bridging link has different risks.

#### References

- [Cisco campus design resources](https://www.cisco.com/c/en/us/solutions/enterprise/design-zone-campus/index.html)

## NETWORK-ENGINEERING-M03 — OSPF adjacency, area scope and dual-stack forwarding

### NETWORK-ENGINEERING-L03 — OSPF adjacency, area scope and dual-stack forwarding

Estimated study time: 150 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L02

An IGP adjacency is a state machine, not a boolean link property. Hello compatibility, neighbor discovery, database description exchange, link-state requests and database synchronization precede full adjacency. Different network types create different expected neighbor relationships; on a broadcast segment, not every pair must form a full adjacency. Diagnose the observed state against the intended topology before treating every non-Full neighbor as broken.

OSPF separates topology distribution from route installation. An LSA can exist in the database without yielding the preferred route in the routing table, and a selected route can still fail hardware installation or next-hop resolution. Area boundaries and external route types affect how information is represented and selected. Summarization reduces detail but can blackhole traffic when a summary remains while a component route disappears.

IPv6 adds separate neighbor discovery and router-advertisement behavior. OSPFv 3 control operation must not be confused with IPv6 host default-router discovery. A working IPv4 application does not prove its IPv6 path works; clients can prefer IPv6 and expose a broken family that IPv4-only probes miss. Test both families through their actual policy and forwarding paths, including IC MPv 6 needed for correct operation.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: R 1/R 2 remain in ExStart after an MTU mismatch. IPv4 service passes. An IPv6 client selects an unauthorized RA sender as default router. An OSPF LSA exists for a destination whose installed route uses a preferred competing source.

**Reasoning:** Investigate the database-exchange mismatch rather than repeatedly changing IP addresses. Separately, the unauthorized RA changes host behavior independently of OSPF. LSA presence does not imply that OSPF wins route selection. Trace the actual IPv6 next hop and installed route.

#### Guided practice

Create a dual-stack acceptance plan that distinguishes adjacency, route selection and host first-hop discovery.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Validate protocol neighbors and databases, compare installed routes/FIBs, inspect IPv6 neighbor/default-router state, then test permitted and denied application traffic in both families. Include unauthorized RA containment and supported IC MPv 6 behavior.

#### Independent task

Environment: emulator

Build and diagnose a dual-stack campus IGP with correct area scope and host first-hop behavior.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Expected adj ace nci es converge.
- Route database, RIB and FIB distinctions are demonstrated.
- IPv4 and IPv6 both meet service and isolation requirements.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0021 · single · implementation**

What does ExStart focus the investigation on?

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: R 1/R 2 remain in ExStart after an MTU mismatch. IPv4 service passes. An IPv6 client selects an unauthorized RA sender as default router. An OSPF LSA exists for a destination whose installed route uses a preferred competing source.

1. Established full synchronization
2. Application DNS only
3. Database-exchange negotiation

**Correct option(s):** 3

- Option 1: Incorrect. The neighbor has not reached Full.
- Option 2: Incorrect. DNS is not OSPF database exchange.
- Option 3: Correct. The supplied MTU mismatch fits that stage.

**NETWORK-ENGINEERING-Q0022 · single · implementation**

Does an LSA guarantee an installed OSPF route?

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: R 1/R 2 remain in ExStart after an MTU mismatch. IPv4 service passes. An IPv6 client selects an unauthorized RA sender as default router. An OSPF LSA exists for a destination whose installed route uses a preferred competing source.

1. No, route selection can prefer another source
2. No route can use that LSA
3. Yes, every LSA becomes the best route

**Correct option(s):** 1

- Option 1: Correct. Database presence is not RIB preference.
- Option 2: Incorrect. It can contribute if eligible and preferred.
- Option 3: Incorrect. Selection rules still apply.

**NETWORK-ENGINEERING-Q0023 · single · implementation**

What sets the client's wrong IPv6 first hop?

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: R 1/R 2 remain in ExStart after an MTU mismatch. IPv4 service passes. An IPv6 client selects an unauthorized RA sender as default router. An OSPF LSA exists for a destination whose installed route uses a preferred competing source.

1. An OSPF router ID alone
2. The successful IPv4 ping
3. The unauthorized RA

**Correct option(s):** 3

- Option 1: Incorrect. Hosts do not learn default routers from router IDs.
- Option 2: Incorrect. That does not set IPv6 routing.
- Option 3: Correct. Host default-router discovery is separate.

**NETWORK-ENGINEERING-Q0024 · single · diagnosis**

Why test IPv6 explicitly?

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: R 1/R 2 remain in ExStart after an MTU mismatch. IPv4 service passes. An IPv6 client selects an unauthorized RA sender as default router. An OSPF LSA exists for a destination whose installed route uses a preferred competing source.

1. Dual-stack means only one protocol runs
2. IPv6 always follows IPv4 policy exactly
3. Applications may prefer its separate path

**Correct option(s):** 3

- Option 1: Incorrect. Both families can operate.
- Option 2: Incorrect. Policies can diverge.
- Option 3: Correct. IPv4 success is insufficient.

**NETWORK-ENGINEERING-Q0025 · single · diagnosis**

What can a surviving summary cause after component loss?

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: R 1/R 2 remain in ExStart after an MTU mismatch. IPv4 service passes. An IPv6 client selects an unauthorized RA sender as default router. An OSPF LSA exists for a destination whose installed route uses a preferred competing source.

1. Guaranteed loop-free application recovery
2. Traffic blackholing within the aggregate
3. Automatic creation of the missing subnet

**Correct option(s):** 2

- Option 1: Incorrect. That requires more evidence.
- Option 2: Correct. The summary can attract unreachable destinations.
- Option 3: Incorrect. Summaries do not create reachability.

**NETWORK-ENGINEERING-Q0026 · single · diagnosis**

Why can a broadcast neighbor remain 2-Way legitimately?

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: R 1/R 2 remain in ExStart after an MTU mismatch. IPv4 service passes. An IPv6 client selects an unauthorized RA sender as default router. An OSPF LSA exists for a destination whose installed route uses a preferred competing source.

1. Not every router pair forms full adjacency
2. All 2-Way states mean bad passwords
3. 2-Way proves application reachability

**Correct option(s):** 1

- Option 1: Correct. DR/BDR relationships affect synchronization.
- Option 2: Incorrect. That is not universal.
- Option 3: Incorrect. It is protocol neighbor state.

**NETWORK-ENGINEERING-Q0027 · single · implementation**

Which check follows RIB selection?

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: R 1/R 2 remain in ExStart after an MTU mismatch. IPv4 service passes. An IPv6 client selects an unauthorized RA sender as default router. An OSPF LSA exists for a destination whose installed route uses a preferred competing source.

1. Only the LSA age
2. FIB and next-hop installation
3. Only the configured hostname

**Correct option(s):** 2

- Option 1: Incorrect. That is earlier control information.
- Option 2: Correct. Control choice must reach forwarding state.
- Option 3: Incorrect. It does not establish forwarding.

**NETWORK-ENGINEERING-Q0028 · single · diagnosis**

Why retain needed IC MPv 6?

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: R 1/R 2 remain in ExStart after an MTU mismatch. IPv4 service passes. An IPv6 client selects an unauthorized RA sender as default router. An OSPF LSA exists for a destination whose installed route uses a preferred competing source.

1. It authorizes every application
2. IPv6 control and path-MTU functions depend on it
3. It is identical to all IPv4 behavior

**Correct option(s):** 2

- Option 1: Incorrect. It does not replace application policy.
- Option 2: Correct. Blanket blocking can break service.
- Option 3: Incorrect. IPv6 has distinct dependencies.

**NETWORK-ENGINEERING-Q0029 · single · implementation**

Which test checks RA containment?

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: R 1/R 2 remain in ExStart after an MTU mismatch. IPv4 service passes. An IPv6 client selects an unauthorized RA sender as default router. An OSPF LSA exists for a destination whose installed route uses a preferred competing source.

1. An unauthorized RA in an isolated access lab
2. Only an OSPF neighbor reset
3. Only a DNS cache flush

**Correct option(s):** 1

- Option 1: Correct. It exercises the first-hop trust boundary.
- Option 2: Incorrect. That does not test host RAs.
- Option 3: Incorrect. That does not remove the source of RAs.

**NETWORK-ENGINEERING-Q0030 · single · implementation**

What closes dual-stack routing acceptance?

SYNTHETIC TEACHING DATA — not captured from equipment.
Campus: R 1/R 2 remain in ExStart after an MTU mismatch. IPv4 service passes. An IPv6 client selects an unauthorized RA sender as default router. An OSPF LSA exists for a destination whose installed route uses a preferred competing source.

1. Only a Full adjacency
2. Only two configured addresses
3. Both families pass positive, negative and failure tests

**Correct option(s):** 3

- Option 1: Incorrect. That omits hosts and policy.
- Option 2: Incorrect. Configuration is not delivery.
- Option 3: Correct. One-family success cannot substitute.

#### Recall

**What does ExStart focus the investigation on?**

Database-exchange negotiation The supplied MTU mismatch fits that stage.

**What can a surviving summary cause after component loss?**

Traffic blackholing within the aggregate The summary can attract unreachable destinations.

**Which test checks RA containment?**

An unauthorized RA in an isolated access lab It exercises the first-hop trust boundary.

#### References

- [OSPFv 2](https://www.rfc-editor.org/rfc/rfc2328.html)
- [OSPFv 3](https://www.rfc-editor.org/rfc/rfc5340.html)
- [RA Guard implementation](https://www.rfc-editor.org/rfc/rfc7113.html)

## NETWORK-ENGINEERING-M04 — BGP policy, recursion and route-leak boundaries

### NETWORK-ENGINEERING-L04 — BGP policy, recursion and route-leak boundaries

Estimated study time: 150 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L03

BGP selects routes according to policy and path attributes, while the forwarding system must resolve the chosen next hop. A preferred BGP path can be unusable if recursion fails or policy installs it into the wrong routing context. Separate received routes, accepted routes, best-path choice and installed forwarding. A route reflector distributes control information; it does not automatically become a valid data-plane next hop.

Build edge policy from the relationship: customer, peer, transit or private interconnect. Define accepted prefix scope, path constraints, default-route behavior, communities, maximum-prefix action and export rules. A route learned from one peer must not become unintended transit to another. Attribute changes such as local preference affect outbound choice within an AS; remote networks control their own choices, so inbound engineering is a policy interaction rather than a unilateral guarantee.

Route-origin validation adds a useful but bounded check. Valid origin does not prove the full path or service trust. Handle invalid and unknown states according to a documented policy and observe the operational consequences. Commission with an isolated route generator, including unauthorized advertisements and upstream withdrawal. Production ownership includes carrier demarcation, escalation evidence, maintenance coordination and restoration of the exact approved export policy.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA — not captured from equipment.
Isolated AS 65000: customer C may advertise 10.60.0.0/16. Peer P advertises 10.70.0.0/16; export policy leaks P routes to peer Q. Exit E 1 has local preference 200 but an unresolved next hop; E 2 has preference 100 and a reachable next hop. A valid-origin route arrives over an unauthorized transit relationship.

**Reasoning:** The P-to-Q export creates unintended transit regardless of origin legitimacy. Fix export scope and test rejection. The E 1 path needs next-hop recursion before it can forward; attribute preference alone is not sufficient. Inspect received/accepted/selected/installed stages independently.

#### Guided practice

Define tests for customer over-advertisement, peer-route leak, unreachable preferred next hop and upstream loss.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Inject each condition only in an isolated multi-AS lab. Verify filters and alarms, inspect route/FIB state, then send bidirectional application traffic over the surviving path. Retain rejected-route evidence and a tested policy rollback.

#### Independent task

Environment: emulator

Operate a constrained multi-AS edge with independently tested import, export, recursion and recovery behavior.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Unauthorized transit is rejected.
- Preferred routes have re solvable next hops.
- Carrier and application recovery evidence is retained.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0031 · single · implementation**

What does exporting P routes to Q create?

SYNTHETIC TEACHING DATA — not captured from equipment.
Isolated AS 65000: customer C may advertise 10.60.0.0/16. Peer P advertises 10.70.0.0/16; export policy leaks P routes to peer Q. Exit E 1 has local preference 200 but an unresolved next hop; E 2 has preference 100 and a reachable next hop. A valid-origin route arrives over an unauthorized transit relationship.

1. A harmless local-only change
2. Automatic origin invalidity
3. Unintended transit

**Correct option(s):** 3

- Option 1: Incorrect. Export affects another neighbor.
- Option 2: Incorrect. The origin can remain legitimate.
- Option 3: Correct. Peer relationships do not authorize arbitrary onward export.

**NETWORK-ENGINEERING-Q0032 · single · diagnosis**

Why is local pref 200 insufficient for E 1 forwarding?

SYNTHETIC TEACHING DATA — not captured from equipment.
Isolated AS 65000: customer C may advertise 10.60.0.0/16. Peer P advertises 10.70.0.0/16; export policy leaks P routes to peer Q. Exit E 1 has local preference 200 but an unresolved next hop; E 2 has preference 100 and a reachable next hop. A valid-origin route arrives over an unauthorized transit relationship.

1. E 2 must be deleted
2. Its next hop is unresolved
3. Local preference must always be 100

**Correct option(s):** 2

- Option 1: Incorrect. A healthy alternative may remain useful.
- Option 2: Correct. Preference does not create recursion.
- Option 3: Incorrect. Values express policy.

**NETWORK-ENGINEERING-Q0033 · single · implementation**

Which stage precedes best-path selection?

SYNTHETIC TEACHING DATA — not captured from equipment.
Isolated AS 65000: customer C may advertise 10.60.0.0/16. Peer P advertises 10.70.0.0/16; export policy leaks P routes to peer Q. Exit E 1 has local preference 200 but an unresolved next hop; E 2 has preference 100 and a reachable next hop. A valid-origin route arrives over an unauthorized transit relationship.

1. Application commit
2. Hardware packet transmission
3. Import acceptance

**Correct option(s):** 3

- Option 1: Incorrect. That is far downstream.
- Option 2: Incorrect. That follows forwarding installation.
- Option 3: Correct. Rejected routes are not eligible in the same way.

**NETWORK-ENGINEERING-Q0034 · single · implementation**

What does origin-valid not prove?

SYNTHETIC TEACHING DATA — not captured from equipment.
Isolated AS 65000: customer C may advertise 10.60.0.0/16. Peer P advertises 10.70.0.0/16; export policy leaks P routes to peer Q. Exit E 1 has local preference 200 but an unresolved next hop; E 2 has preference 100 and a reachable next hop. A valid-origin route arrives over an unauthorized transit relationship.

1. That a validation state was assigned
2. An approved transit relationship
3. A matching authorized origin

**Correct option(s):** 2

- Option 1: Incorrect. The case supplies it.
- Option 2: Correct. Origin authorization has bounded scope.
- Option 3: Incorrect. That is the intended check.

**NETWORK-ENGINEERING-Q0035 · single · implementation**

Which attribute commonly controls outbound preference inside an AS?

SYNTHETIC TEACHING DATA — not captured from equipment.
Isolated AS 65000: customer C may advertise 10.60.0.0/16. Peer P advertises 10.70.0.0/16; export policy leaks P routes to peer Q. Exit E 1 has local preference 200 but an unresolved next hop; E 2 has preference 100 and a reachable next hop. A valid-origin route arrives over an unauthorized transit relationship.

1. A host's TCP window
2. Local preference
3. Remote interface description

**Correct option(s):** 2

- Option 1: Incorrect. It does not select BGP paths.
- Option 2: Correct. It expresses internal exit policy.
- Option 3: Incorrect. It is not a BGP preference attribute.

**NETWORK-ENGINEERING-Q0036 · single · diagnosis**

Why is inbound engineering not guaranteed unilaterally?

SYNTHETIC TEACHING DATA — not captured from equipment.
Isolated AS 65000: customer C may advertise 10.60.0.0/16. Peer P advertises 10.70.0.0/16; export policy leaks P routes to peer Q. Exit E 1 has local preference 200 but an unresolved next hop; E 2 has preference 100 and a reachable next hop. A valid-origin route arrives over an unauthorized transit relationship.

1. Remote networks apply their own policy
2. BGP has no attributes
3. All AS es use identical policies

**Correct option(s):** 1

- Option 1: Correct. Your announcements influence but do not control them.
- Option 2: Incorrect. It has many.
- Option 3: Incorrect. They do not.

**NETWORK-ENGINEERING-Q0037 · single · implementation**

What should customer C be permitted to originate here?

SYNTHETIC TEACHING DATA — not captured from equipment.
Isolated AS 65000: customer C may advertise 10.60.0.0/16. Peer P advertises 10.70.0.0/16; export policy leaks P routes to peer Q. Exit E 1 has local preference 200 but an unresolved next hop; E 2 has preference 100 and a reachable next hop. A valid-origin route arrives over an unauthorized transit relationship.

1. Every route C receives
2. A default automatically
3. Only 10.60.0.0/16 under the contract

**Correct option(s):** 3

- Option 1: Incorrect. That would widen authority.
- Option 2: Incorrect. No default permission is supplied.
- Option 3: Correct. Scope is explicit.

**NETWORK-ENGINEERING-Q0038 · single · implementation**

What should a maximum-prefix policy specify?

SYNTHETIC TEACHING DATA — not captured from equipment.
Isolated AS 65000: customer C may advertise 10.60.0.0/16. Peer P advertises 10.70.0.0/16; export policy leaks P routes to peer Q. Exit E 1 has local preference 200 but an unresolved next hop; E 2 has preference 100 and a reachable next hop. A valid-origin route arrives over an unauthorized transit relationship.

1. Only interface speed
2. Only the peer's display name
3. Threshold, action and recovery

**Correct option(s):** 3

- Option 1: Incorrect. Route quantity is separate.
- Option 2: Incorrect. It does not enforce count.
- Option 3: Correct. An alert and session shutdown differ.

**NETWORK-ENGINEERING-Q0039 · single · diagnosis**

What belongs in carrier escalation evidence?

SYNTHETIC TEACHING DATA — not captured from equipment.
Isolated AS 65000: customer C may advertise 10.60.0.0/16. Peer P advertises 10.70.0.0/16; export policy leaks P routes to peer Q. Exit E 1 has local preference 200 but an unresolved next hop; E 2 has preference 100 and a reachable next hop. A valid-origin route arrives over an unauthorized transit relationship.

1. Demarcation tests, timestamps and affected prefixes
2. Only an assertion that BGP is bad
3. Only the monthly invoice

**Correct option(s):** 1

- Option 1: Correct. It localizes the responsibility boundary.
- Option 2: Incorrect. That is not actionable evidence.
- Option 3: Incorrect. It does not show the incident.

**NETWORK-ENGINEERING-Q0040 · single · implementation**

What closes the edge change?

SYNTHETIC TEACHING DATA — not captured from equipment.
Isolated AS 65000: customer C may advertise 10.60.0.0/16. Peer P advertises 10.70.0.0/16; export policy leaks P routes to peer Q. Exit E 1 has local preference 200 but an unresolved next hop; E 2 has preference 100 and a reachable next hop. A valid-origin route arrives over an unauthorized transit relationship.

1. Only an Established session
2. Only a large route count
3. Approved exports plus tested surviving application paths

**Correct option(s):** 3

- Option 1: Incorrect. That predates many route failures.
- Option 2: Incorrect. Quantity is not correctness.
- Option 3: Correct. Policy and service both matter.

#### Recall

**What does exporting P routes to Q create?**

Unintended transit Peer relationships do not authorize arbitrary onward export.

**Which attribute commonly controls outbound preference inside an AS?**

Local preference It expresses internal exit policy.

**What belongs in carrier escalation evidence?**

Demarcation tests, timestamps and affected prefixes It localizes the responsibility boundary.

#### References

- [BGP operational security](https://www.rfc-editor.org/rfc/rfc7454.html)
- [BGP-4](https://www.rfc-editor.org/rfc/rfc4271.html)
- [Origin validation](https://www.rfc-editor.org/rfc/rfc6811.html)

## NETWORK-ENGINEERING-M05 — WAN encapsulation, IPsec and path-MTU diagnosis

### NETWORK-ENGINEERING-L05 — WAN encapsulation, IPsec and path-MTU diagnosis

Estimated study time: 150 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L04

A WAN service has a physical or provider hand off, an overlay or tunnel, routing policy and application dependencies. The tunnel can be established while data traffic fails because selectors, routes, security policy or MTU differ. Trace a packet before encryption, through encapsulation and after decryption. The outer path and inner tenant path use different addresses and potentially different routing contexts.

IPsec security associations define protected traffic and cryptographic state. IKE negotiation success is not proof that every required traffic selector is included or that both directions use the same intended policy. Rekey and dead-peer behavior must be tested, because a connection can work initially and fail during ordinary lifecycle events. NAT travers al and provider middle boxes add their own dependencies.

Encryption and tunneling add overhead. A small ping can pass while large TCP transfers stall if path-MTU signaling is blocked. MSS adjustment can help particular TCP paths but does not repair every UDP or non-TCP application. Validate both inner size requirements and outer transport limits, and preserve required ICMP handling within the security design.

For SD-WAN or private interconnect, keep the same discipline: control reachability, route installation and application forwarding are separate. A controller's green tunnel status is one observation, not whole-service acceptance.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: IPsec SA established. Selectors permit 10.1.0.0/24 to 10.2.0.0/24; application source 10.1.1.10 is outside that scope. Small tests from 10.1.0.10 pass;1500-byte inner packets stall. Outer path MTU 1500; required PMTU messages blocked. Rekey untested.

**Reasoning:** The application source is outside the allowed selector, while the size-dependent symptom on the allowed subnet is a second problem. Reconcile approved selectors and packet-size handling separately. Do not treat an established SA as proof that either requirement is met.

#### Guided practice

Build a test matrix across source subnet, protocol, packet size and rekey event.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Test approved and denied source ranges, TCP and relevant UDP, minimum and maximum intended sizes, then sustained traffic through rekey. Observe inner/outer counters and application results. Keep unauthorized subnets denied after selector repair.

#### Independent task

Environment: emulator

Diagnose and commission a hybrid tunnel across policy, encapsulation, rekey and application boundaries.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Selectors match the approved flow matrix.
- Required packet sizes pass for each protocol.
- Rekey and peer failure meet recovery limits.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0041 · single · diagnosis**

Why is 10.1.1.10 excluded?

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: IPsec SA established. Selectors permit 10.1.0.0/24 to 10.2.0.0/24; application source 10.1.1.10 is outside that scope. Small tests from 10.1.0.10 pass;1500-byte inner packets stall. Outer path MTU 1500; required PMTU messages blocked. Rekey untested.

1. All private addresses are equivalent
2. It lies outside 10.1.0.0/24
3. The SA must be absent

**Correct option(s):** 2

- Option 1: Incorrect. Selectors are prefix-specific.
- Option 2: Correct. The selector covers a different subnet.
- Option 3: Incorrect. The case says it is established.

**NETWORK-ENGINEERING-Q0042 · single · implementation**

What does an established SA prove?

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: IPsec SA established. Selectors permit 10.1.0.0/24 to 10.2.0.0/24; application source 10.1.1.10 is outside that scope. Small tests from 10.1.0.10 pass;1500-byte inner packets stall. Outer path MTU 1500; required PMTU messages blocked. Rekey untested.

1. Every inner route works
2. Negotiated security state exists
3. All packet sizes pass

**Correct option(s):** 2

- Option 1: Incorrect. Routing remains separate.
- Option 2: Correct. It does not authorize every flow.
- Option 3: Incorrect. Encapsulation can exceed MTU.

**NETWORK-ENGINEERING-Q0043 · single · diagnosis**

Why can small packets pass while large ones stall?

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: IPsec SA established. Selectors permit 10.1.0.0/24 to 10.2.0.0/24; application source 10.1.1.10 is outside that scope. Small tests from 10.1.0.10 pass;1500-byte inner packets stall. Outer path MTU 1500; required PMTU messages blocked. Rekey untested.

1. Encryption only supports small applications
2. DNS always fails for large packets
3. Encapsulation exceeds path limits and PMTU feedback is blocked

**Correct option(s):** 3

- Option 1: Incorrect. That is not the mechanism.
- Option 2: Incorrect. DNS is not the supplied cause.
- Option 3: Correct. The symptom is size-dependent.

**NETWORK-ENGINEERING-Q0044 · single · implementation**

What does MSS adjustment not universally fix?

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: IPsec SA established. Selectors permit 10.1.0.0/24 to 10.2.0.0/24; application source 10.1.1.10 is outside that scope. Small tests from 10.1.0.10 pass;1500-byte inner packets stall. Outer path MTU 1500; required PMTU messages blocked. Rekey untested.

1. UDP and other non-TCP traffic
2. TCP segment sizing
3. A tested TCP path

**Correct option(s):** 1

- Option 1: Correct. MSS is a TCP mechanism.
- Option 2: Incorrect. That is its relevant scope.
- Option 3: Incorrect. It can help that path.

**NETWORK-ENGINEERING-Q0045 · single · implementation**

Which event tests ordinary cryptographic lifecycle?

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: IPsec SA established. Selectors permit 10.1.0.0/24 to 10.2.0.0/24; application source 10.1.1.10 is outside that scope. Small tests from 10.1.0.10 pass;1500-byte inner packets stall. Outer path MTU 1500; required PMTU messages blocked. Rekey untested.

1. Only the first ping
2. Only a GUI refresh
3. Rekey under sustained traffic

**Correct option(s):** 3

- Option 1: Incorrect. That precedes lifecycle turnover.
- Option 2: Incorrect. It does not change SA state.
- Option 3: Correct. Initial setup does not cover renewal.

**NETWORK-ENGINEERING-Q0046 · single · diagnosis**

Why capture before and after tunnel processing?

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: IPsec SA established. Selectors permit 10.1.0.0/24 to 10.2.0.0/24; application source 10.1.1.10 is outside that scope. Small tests from 10.1.0.10 pass;1500-byte inner packets stall. Outer path MTU 1500; required PMTU messages blocked. Rekey untested.

1. Encryption removes routing needs
2. All headers remain identical
3. Inner and outer paths have different state

**Correct option(s):** 3

- Option 1: Incorrect. Outer packets still need routes.
- Option 2: Incorrect. Encapsulation changes them.
- Option 3: Correct. It localizes policy versus transport loss.

**NETWORK-ENGINEERING-Q0047 · single · implementation**

Which selector repair is justified?

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: IPsec SA established. Selectors permit 10.1.0.0/24 to 10.2.0.0/24; application source 10.1.1.10 is outside that scope. Small tests from 10.1.0.10 pass;1500-byte inner packets stall. Outer path MTU 1500; required PMTU messages blocked. Rekey untested.

1. Add only the approved application scope
2. Disable encryption entirely
3. Permit every private prefix

**Correct option(s):** 1

- Option 1: Correct. Preserve denied subnet boundaries.
- Option 2: Incorrect. That removes the protection objective.
- Option 3: Incorrect. That abandons the flow requirement.

**NETWORK-ENGINEERING-Q0048 · single · implementation**

What should peer-failure testing observe?

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: IPsec SA established. Selectors permit 10.1.0.0/24 to 10.2.0.0/24; application source 10.1.1.10 is outside that scope. Small tests from 10.1.0.10 pass;1500-byte inner packets stall. Outer path MTU 1500; required PMTU messages blocked. Rekey untested.

1. Only the configured key length
2. Only controller uptime
3. Detection, rerouting and application recovery

**Correct option(s):** 3

- Option 1: Incorrect. That does not measure recovery.
- Option 2: Incorrect. The peer can fail while controller stays up.
- Option 3: Correct. Tunnel status alone is partial.

**NETWORK-ENGINEERING-Q0049 · single · implementation**

What does a green SD-WAN tunnel omit?

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: IPsec SA established. Selectors permit 10.1.0.0/24 to 10.2.0.0/24; application source 10.1.1.10 is outside that scope. Small tests from 10.1.0.10 pass;1500-byte inner packets stall. Outer path MTU 1500; required PMTU messages blocked. Rekey untested.

1. Any control-plane evidence
2. Effective route and application validation
3. The existence of a tunnel object

**Correct option(s):** 2

- Option 1: Incorrect. It does provide some.
- Option 2: Correct. Control health is not full service.
- Option 3: Incorrect. That is represented bythe status.

**NETWORK-ENGINEERING-Q0050 · single · implementation**

Which final matrix is complete?

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: IPsec SA established. Selectors permit 10.1.0.0/24 to 10.2.0.0/24; application source 10.1.1.10 is outside that scope. Small tests from 10.1.0.10 pass;1500-byte inner packets stall. Outer path MTU 1500; required PMTU messages blocked. Rekey untested.

1. Only configuration diffs
2. Sources, protocols, sizes andrekey/failure events
3. Only one allowed ping

**Correct option(s):** 2

- Option 1: Incorrect. Intent is not behavior.
- Option 2: Correct. It exercises independent dependencies.
- Option 3: Incorrect. That is too narrow.

#### Recall

**Why is 10.1.1.10 excluded?**

It lies outside 10.1.0.0/24 The selector covers a different subnet.

**Which event tests ordinary cryptographic lifecycle?**

Rekey under sustained traffic Initial setup does not cover renewal.

**What does a green SD-WAN tunnel omit?**

Effective route and application validation Control health is not full service.

#### References

- [IPsec architecture](https://www.rfc-editor.org/rfc/rfc4301.html)
- [IKEv 2](https://www.rfc-editor.org/rfc/rfc7296.html)
- [Packet iz ation-layer PMTU discovery](https://www.rfc-editor.org/rfc/rfc8899.html)

## NETWORK-ENGINEERING-M06 — Wireless RF coverage, capacity and survey evidence

### NETWORK-ENGINEERING-L06 — Wireless RF coverage, capacity and survey evidence

Estimated study time: 150 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L05

Wireless coverage and wireless capacity are different constraints. Received signal strength must be evaluated with noise, interference, client capability, channel width and the required modulation/retry behavior. A strong signal can coexist with poor throughput if many transmitters contend for airtime. Wider channels can increase peak rate while reducing channel reuse and increasing interference exposure. Select channel width and cell design for the actual density and application requirement.

An access point and client form a bidirectional link. Increasing AP transmit power can create an asymmetric cell in which the client hears the AP but cannot be heard reliably. Antenna pattern, mounting, obstacles and roaming overlap matter. A predictive survey is a design model; an on-site passive/active survey and application measurements are different evidence types. Record the client type and measurement method because a survey adapter may not represent every device.

Airtime is consumed by data, management traffic, contention, retries and slow clients. The PHY rate shown by a client is not application throughput. Capacity acceptance should use representative concurrent clients and application transactions, including roaming and AP failure. Keep guest, corporate and operational wireless requirements distinct, and avoid assuming that a successful wired NAC design automatically establishes RF performance.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic survey: AP RSSI=-55 dBm, noise=-85 dBm; measured channel utilization 90%, retries 25%. Client transmits at much lower power than AP. Design uses 80 MHz channels in a dense area. One laptop speed test passes when the room is empty. No real RF measurement is claimed.

**Reasoning:** SNR is 30 dB, but high channel occupancy and retries show that signal strength alone does not establish capacity. Review channel reuse, interference and client symmetry; reducing width may improve reuse even if the advertised peak rate falls. The empty-room test does not represent concurrent demand.

#### Guided practice

Define a survey and load test for a room of 80 clients with a real-time application.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Measure coverage and noise using representative clients, observe airtime and retry distribution, then run concurrent application traffic and roaming. Test a failed AP and verify the application latency/loss limits. Record physical locations and client capabilities.

#### Independent task

Environment: emulator

Design and physically validate WLAN coverage and capacity using representative RF and application evidence.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Coverage and capacity are measured separately.
- Bidirectional link quality is acceptable.
- Loaded roaming and AP-loss tests meet service limits.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0051 · single · calculation**

What is the supplied SNR?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic survey: AP RSSI=-55 dBm, noise=-85 dBm; measured channel utilization 90%, retries 25%. Client transmits at much lower power than AP. Design uses 80 MHz channels in a dense area. One laptop speed test passes when the room is empty. No real RF measurement is claimed.

1. 90 dB
2. 30 dB
3. -140 dB

**Correct option(s):** 2

- Option 1: Incorrect. That confuses utilization with signal ratio.
- Option 2: Correct. -55 minus -85 equals 30.
- Option 3: Incorrect. Adding the powers is not SNR.

**NETWORK-ENGINEERING-Q0052 · single · diagnosis**

Why does strong RSSI not prove capacity?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic survey: AP RSSI=-55 dBm, noise=-85 dBm; measured channel utilization 90%, retries 25%. Client transmits at much lower power than AP. Design uses 80 MHz channels in a dense area. One laptop speed test passes when the room is empty. No real RF measurement is claimed.

1. Airtime is heavily occupied
2. RSSI measures application throughput
3. Noise can never affect strong signals

**Correct option(s):** 1

- Option 1: Correct. Contention and retries consume service.
- Option 2: Incorrect. It measures received power.
- Option 3: Incorrect. Interference and SNR still matter.

**NETWORK-ENGINEERING-Q0053 · single · implementation**

What risk follows excessive AP power?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic survey: AP RSSI=-55 dBm, noise=-85 dBm; measured channel utilization 90%, retries 25%. Client transmits at much lower power than AP. Design uses 80 MHz channels in a dense area. One laptop speed test passes when the room is empty. No real RF measurement is claimed.

1. Guaranteed better roaming
2. A bidirectional ly asymmetric cell
3. Automatic extra channels

**Correct option(s):** 2

- Option 1: Incorrect. Large cells can impair roaming.
- Option 2: Correct. The client may not reach back reliably.
- Option 3: Incorrect. Power does not create spectrum.

**NETWORK-ENGINEERING-Q0054 · single · diagnosis**

Why consider narrower channels?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic survey: AP RSSI=-55 dBm, noise=-85 dBm; measured channel utilization 90%, retries 25%. Client transmits at much lower power than AP. Design uses 80 MHz channels in a dense area. One laptop speed test passes when the room is empty. No real RF measurement is claimed.

1. Better reuse may improve dense-area service
2. Narrower always doubles throughput
3. Width has no interference effect

**Correct option(s):** 1

- Option 1: Correct. Peak rate is not the only objective.
- Option 2: Incorrect. The result depends on conditions.
- Option 3: Incorrect. It changes spectrum usage.

**NETWORK-ENGINEERING-Q0055 · single · implementation**

What does the empty-room test omit?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic survey: AP RSSI=-55 dBm, noise=-85 dBm; measured channel utilization 90%, retries 25%. Client transmits at much lower power than AP. Design uses 80 MHz channels in a dense area. One laptop speed test passes when the room is empty. No real RF measurement is claimed.

1. Any evidence of connectivity
2. Concurrent contention and client diversity
3. The laptop's existence

**Correct option(s):** 2

- Option 1: Incorrect. It does show one working case.
- Option 2: Correct. The production load is different.
- Option 3: Incorrect. That is not the gap.

**NETWORK-ENGINEERING-Q0056 · single · diagnosis**

Which evidence is physical RF acceptance?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic survey: AP RSSI=-55 dBm, noise=-85 dBm; measured channel utilization 90%, retries 25%. Client transmits at much lower power than AP. Design uses 80 MHz channels in a dense area. One laptop speed test passes when the room is empty. No real RF measurement is claimed.

1. Only AP count
2. On-site survey and representative application measurements
3. Only a predictive heat map

**Correct option(s):** 2

- Option 1: Incorrect. Count does not prove coverage.
- Option 2: Correct. A model alone is not measurement.
- Option 3: Incorrect. That is simulation.

**NETWORK-ENGINEERING-Q0057 · single · diagnosis**

Why record client capabilities?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic survey: AP RSSI=-55 dBm, noise=-85 dBm; measured channel utilization 90%, retries 25%. Client transmits at much lower power than AP. Design uses 80 MHz channels in a dense area. One laptop speed test passes when the room is empty. No real RF measurement is claimed.

1. All clients are identical
2. Capabilities only affect wired links
3. They affect rate, power and roaming behavior

**Correct option(s):** 3

- Option 1: Incorrect. They vary.
- Option 2: Incorrect. They matter strongly in wireless.
- Option 3: Correct. A survey device may not represent all clients.

**NETWORK-ENGINEERING-Q0058 · single · implementation**

What does PHY rate not equal?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic survey: AP RSSI=-55 dBm, noise=-85 dBm; measured channel utilization 90%, retries 25%. Client transmits at much lower power than AP. Design uses 80 MHz channels in a dense area. One laptop speed test passes when the room is empty. No real RF measurement is claimed.

1. Application good put
2. An observation reported bythe client
3. A link-layer signaling rate

**Correct option(s):** 1

- Option 1: Correct. Overhead, contention and retries reduce useful throughput.
- Option 2: Incorrect. It can be that.
- Option 3: Incorrect. That is its role.

**NETWORK-ENGINEERING-Q0059 · single · implementation**

Which degraded test matters?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic survey: AP RSSI=-55 dBm, noise=-85 dBm; measured channel utilization 90%, retries 25%. Client transmits at much lower power than AP. Design uses 80 MHz channels in a dense area. One laptop speed test passes when the room is empty. No real RF measurement is claimed.

1. One AP unavailable under load
2. Only testing at midnight without clients
3. Only restarting the dashboard

**Correct option(s):** 1

- Option 1: Correct. It exposes remaining coverage and capacity.
- Option 2: Incorrect. That omits demand.
- Option 3: Incorrect. That changes no RF service.

**NETWORK-ENGINEERING-Q0060 · single · design**

What closes the RF design?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic survey: AP RSSI=-55 dBm, noise=-85 dBm; measured channel utilization 90%, retries 25%. Client transmits at much lower power than AP. Design uses 80 MHz channels in a dense area. One laptop speed test passes when the room is empty. No real RF measurement is claimed.

1. Only the widest available channel
2. Measured coverage, capacity and roaming against requirements
3. Only maximum RSSI

**Correct option(s):** 2

- Option 1: Incorrect. Width is not suitability.
- Option 2: Correct. All required conditions need evidence.
- Option 3: Incorrect. That ignores contention.

#### Recall

**What is the supplied SNR?**

30 dB -55 minus -85 equals 30.

**What does the empty-room test omit?**

Concurrent contention and client diversity The production load is different.

**Which degraded test matters?**

One AP unavailable under load It exposes remaining coverage and capacity.

#### References

- [Cisco wireless design resources](https://www.cisco.com/c/en/us/solutions/enterprise/design-zone-mobility/index.html)

## NETWORK-ENGINEERING-M07 — Wireless controllers, roaming and application continuity

### NETWORK-ENGINEERING-L07 — Wireless controllers, roaming and application continuity

Estimated study time: 150 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L06

A controller-based WLAN has separate discovery, join, configuration, client authentication and data-forwarding stages. An AP joined to a controller may still advertise the wrong WLAN or place clients into the wrong VLAN/policy. Distinguish central tunneling from local forwarding; each changes the data path and the consequences of controller or WAN failure. The chosen mode must be supported for the site's required offline behavior.

Roaming is not merely changing the strongest signal. A client makes decisions based on its implementation and environment, while the infrastructure supports discovery, authentication and state transfer. Fast transition mechanisms can reduce authentication interruption when the client and security design support them, but they do not guarantee that every application session survives. Address continuity, gateway placement, policy and real-time deadlines remain relevant.

Test controller failover, AP restart, authentication-service loss and WAN isolation separately. A branch may continue forwarding existing clients while being unable to admit new ones; the operating requirement must state which behavior is acceptable. Preserve console and management recovery, and verify that a replacement controller has the correct certificates, WLAN policies and licensing rather than merely a reachable address.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic branch WLAN: APs use local forwarding but central authentication. WAN failure leaves existing clients passing traffic; new clients cannot authenticate. A mobile voice client roams between APs with 120 ms measured interruption, while its application limit is 50 ms. Controller redundancy is configured but untested.

**Reasoning:** The WAN failure distinguishes established forwarding from new admission. The measured 120 ms interruption fails the 50 ms requirement even if the client reconnects successfully. Controller configuration is not failover evidence; test the supported mode and client behavior under each independent event.

#### Guided practice

Write an acceptance matrix for existing clients, new clients and roaming clients during WAN and controller failure.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** For each event, record whether forwarding, authentication and policy enforcement are required. Measure existing-session continuity, new admission and roaming delay using representative clients. Accept only the explicitly agreed degraded behavior.

#### Independent task

Environment: emulator

Commission WLAN control and data planes with independently measured roaming, admission and failure behavior.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Forwarding mode and failure dependencies are documented.
- Roaming meets application limits.
- Existing and new-client behavior is tested separately.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0061 · single · diagnosis**

Why do existing clients work while new ones fail?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic branch WLAN: APs use local forwarding but central authentication. WAN failure leaves existing clients passing traffic; new clients cannot authenticate. A mobile voice client roams between APs with 120 ms measured interruption, while its application limit is 50 ms. Controller redundancy is configured but untested.

1. Every client uses the same session state
2. The AP has no working radio
3. Forwarding is local but authentication is central

**Correct option(s):** 3

- Option 1: Incorrect. New admission differs.
- Option 2: Incorrect. Existing traffic disproves that.
- Option 3: Correct. The WAN affects one dependency first.

**NETWORK-ENGINEERING-Q0062 · single · design**

Does 120 ms meet the 50 ms requirement?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic branch WLAN: APs use local forwarding but central authentication. WAN failure leaves existing clients passing traffic; new clients cannot authenticate. A mobile voice client roams between APs with 120 ms measured interruption, while its application limit is 50 ms. Controller redundancy is configured but untested.

1. No
2. Yes, controller redundancy removes latency
3. Yes, any successful roam passes

**Correct option(s):** 1

- Option 1: Correct. Recovery occurred but exceeded the limit.
- Option 2: Incorrect. It does not prove that.
- Option 3: Incorrect. The timing constraint is explicit.

**NETWORK-ENGINEERING-Q0063 · single · implementation**

What does AP join alone not establish?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic branch WLAN: APs use local forwarding but central authentication. WAN failure leaves existing clients passing traffic; new clients cannot authenticate. A mobile voice client roams between APs with 120 ms measured interruption, while its application limit is 50 ms. Controller redundancy is configured but untested.

1. Some controller reachability
2. An AP control relationship
3. Correct WLAN and client policy

**Correct option(s):** 3

- Option 1: Incorrect. Join provides that evidence.
- Option 2: Incorrect. That is what join establishes.
- Option 3: Correct. Join precedes full service validation.

**NETWORK-ENGINEERING-Q0064 · single · diagnosis**

Why distinguish local from central forwarding?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic branch WLAN: APs use local forwarding but central authentication. WAN failure leaves existing clients passing traffic; new clients cannot authenticate. A mobile voice client roams between APs with 120 ms measured interruption, while its application limit is 50 ms. Controller redundancy is configured but untested.

1. Only the SSID name changes
2. Their WAN/controller dependencies differ
3. They always have identical failure behavior

**Correct option(s):** 2

- Option 1: Incorrect. Forwarding architecture changes.
- Option 2: Correct. The data path changes.
- Option 3: Incorrect. They do not.

**NETWORK-ENGINEERING-Q0065 · single · implementation**

What should a roaming test observe?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic branch WLAN: APs use local forwarding but central authentication. WAN failure leaves existing clients passing traffic; new clients cannot authenticate. A mobile voice client roams between APs with 120 ms measured interruption, while its application limit is 50 ms. Controller redundancy is configured but untested.

1. Only controller CPU at idle
2. Application interruption and policy continuity
3. Only strongest RSSI

**Correct option(s):** 2

- Option 1: Incorrect. It does not measure roam impact.
- Option 2: Correct. Association success alone is partial.
- Option 3: Incorrect. Clients and state transitions matter.

**NETWORK-ENGINEERING-Q0066 · single · implementation**

Which condition affects fast-transition suitability?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic branch WLAN: APs use local forwarding but central authentication. WAN failure leaves existing clients passing traffic; new clients cannot authenticate. A mobile voice client roams between APs with 120 ms measured interruption, while its application limit is 50 ms. Controller redundancy is configured but untested.

1. Only AP paint color
2. Client and security-method support
3. Only the controller hostname

**Correct option(s):** 2

- Option 1: Incorrect. It has no protocol meaning.
- Option 2: Correct. Features must interoperate.
- Option 3: Incorrect. It does not establish support.

**NETWORK-ENGINEERING-Q0067 · single · implementation**

What should controller replacement restore?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic branch WLAN: APs use local forwarding but central authentication. WAN failure leaves existing clients passing traffic; new clients cannot authenticate. A mobile voice client roams between APs with 120 ms measured interruption, while its application limit is 50 ms. Controller redundancy is configured but untested.

1. Only a DNS record
2. Only the old dashboard theme
3. Trust, WLAN policy and required platform state

**Correct option(s):** 3

- Option 1: Incorrect. It does not restore configuration.
- Option 2: Incorrect. It does not establish service.
- Option 3: Correct. Address reachability is insufficient.

**NETWORK-ENGINEERING-Q0068 · single · diagnosis**

Why test new clients during degradation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic branch WLAN: APs use local forwarding but central authentication. WAN failure leaves existing clients passing traffic; new clients cannot authenticate. A mobile voice client roams between APs with 120 ms measured interruption, while its application limit is 50 ms. Controller redundancy is configured but untested.

1. Authentication never depends on WAN
2. Existing client tests prove all future admission
3. Admission can fail while existing sessions survive

**Correct option(s):** 3

- Option 1: Incorrect. The case explicitly does.
- Option 2: Incorrect. They do not.
- Option 3: Correct. Operating requirements may include both.

**NETWORK-ENGINEERING-Q0069 · single · implementation**

What does configured redundancy still need?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic branch WLAN: APs use local forwarding but central authentication. WAN failure leaves existing clients passing traffic; new clients cannot authenticate. A mobile voice client roams between APs with 120 ms measured interruption, while its application limit is 50 ms. Controller redundancy is configured but untested.

1. Automatic production ownership
2. No further work
3. An observed failover test

**Correct option(s):** 3

- Option 1: Incorrect. A configuration is not experience.
- Option 2: Incorrect. That would assume success.
- Option 3: Correct. Intent is not behavior.

**NETWORK-ENGINEERING-Q0070 · single · implementation**

What should a nun met roaming limit trigger?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic branch WLAN: APs use local forwarding but central authentication. WAN failure leaves existing clients passing traffic; new clients cannot authenticate. A mobile voice client roams between APs with 120 ms measured interruption, while its application limit is 50 ms. Controller redundancy is configured but untested.

1. Diagnosis and design revision or approved requirement change
2. Relabeling 120 ms as 50 ms
3. Deleting the failed sample

**Correct option(s):** 1

- Option 1: Correct. Do not silently relax it.
- Option 2: Incorrect. That falsifies measurement.
- Option 3: Incorrect. That destroys the evidence.

#### Recall

**Why do existing clients work while new ones fail?**

Forwarding is local but authentication is central The WAN affects one dependency first.

**What should a roaming test observe?**

Application interruption and policy continuity Association success alone is partial.

**What does configured redundancy still need?**

An observed failover test Intent is not behavior.

#### References

- [Cisco wireless controller guides](https://www.cisco.com/c/en/us/support/wireless/catalyst-9800-series-wireless-controllers/products-installation-and-configuration-guides-list.html)

## NETWORK-ENGINEERING-M08 — 802.1X, EAP-TLS and NAC authorization state

### NETWORK-ENGINEERING-L08 — 802.1X, EAP-TLS and NAC authorization state

Estimated study time: 150 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L07

Network admission separates the supplicant, authenticator and authentication server. The endpoint exchanges EAP through the switch or AP; the authenticator carries the relevant exchange to a RADIUS service and applies the resulting authorization. A successful identity check does not necessarily grant the production role: policy can assign a restricted VLAN, downloadable ACL or other supported enforcement result.

EAP-TLS uses certificate-based authentication. Validate trust chains, identities, intended certificate usage, validity period and revocation behavior according to the deployed design. The endpoint must authenticate the server as well as present its own identity; ignoring server validation can expose credentials or trust to an unauthorized authenticator. Clock errors can make otherwise valid certificates appear expired or not yet valid.

MAC-based fallback is an exception mechanism with weaker identity assurance, not an equivalent replacement for certificate-based admission. Profiling can inform policy but a guessed device type is not strong proof of ownership. Design explicit restricted roles for incapable devices, with monitored exceptions and an expiry/review process.

Commission successful admission, wrong certificate, revoked certificate, server outage, posture failure and role change. A change-of-authorization event must actually reach and update the enforcement device; a controller policy record alone is not effective isolation.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA — not captured from equipment.
NAC: a valid trusted endpoint certificate authenticates successfully. Authorization selects QuarantineVLAN because posture is unknown. An operator proposes MAB production access. The server policy later changes to Production, but blocked CoA prevents the switch session from updating.

**Reasoning:** Authentication succeeded; the remaining decision is authorization and posture. MAB would weaken identity without fixing posture requirements. The changed server rule has not reached the enforcement point because CoA is blocked. Verify the actual switch session and policy before declaring release from quarantine.

#### Guided practice

Design tests proving that a valid certificate with failed posture remains restricted, then transitions correctly after remediation.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Authenticate with the valid identity, verify restricted VLAN/ACL and denied production traffic, remediate posture through approved means, deliver a valid CoA or reauthentication, and verify effective role plus allowed/denied flows. Retain RADIUS and switch session correlation.

#### Independent task

Environment: emulator

Implement and independently assess certificate-based admission, restricted exceptions and effective NAC policy transitions.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Authentication and authorization outcomes are distinguished.
- Weak fallback cannot bypass required posture.
- Role changes are verified on the enforcement device.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0071 · single · diagnosis**

Why is a valid certificate still quarantined?

SYNTHETIC TEACHING DATA — not captured from equipment.
NAC: a valid trusted endpoint certificate authenticates successfully. Authorization selects QuarantineVLAN because posture is unknown. An operator proposes MAB production access. The server policy later changes to Production, but blocked CoA prevents the switch session from updating.

1. Authorization includes posture
2. The switch has no link
3. TLS necessarily failed

**Correct option(s):** 1

- Option 1: Correct. Identity success does not satisfy every policy condition.
- Option 2: Incorrect. Admission exchanges occurred.
- Option 3: Incorrect. Authentication succeeded.

**NETWORK-ENGINEERING-Q0072 · single · implementation**

What does CoA blockage explain?

SYNTHETIC TEACHING DATA — not captured from equipment.
NAC: a valid trusted endpoint certificate authenticates successfully. Authorization selects QuarantineVLAN because posture is unknown. An operator proposes MAB production access. The server policy later changes to Production, but blocked CoA prevents the switch session from updating.

1. The live session retains old authorization
2. All RADIUS authentication is down
3. The certificate became invalid

**Correct option(s):** 1

- Option 1: Correct. Controller policy alone has not updated enforcement.
- Option 2: Incorrect. Authentication already worked.
- Option 3: Incorrect. CoA delivery does not alter certificate validity.

**NETWORK-ENGINEERING-Q0073 · single · diagnosis**

Why is MAB not equivalent to EAP-TLS?

SYNTHETIC TEACHING DATA — not captured from equipment.
NAC: a valid trusted endpoint certificate authenticates successfully. Authorization selects QuarantineVLAN because posture is unknown. An operator proposes MAB production access. The server policy later changes to Production, but blocked CoA prevents the switch session from updating.

1. EAP-TLS never validates servers
2. MAB always uses client certificates
3. A MAC address is weaker identity evidence

**Correct option(s):** 3

- Option 1: Incorrect. It should validate server trust.
- Option 2: Incorrect. It does not.
- Option 3: Correct. It can be copied and does not prove private-key possession.

**NETWORK-ENGINEERING-Q0074 · single · implementation**

Which observation proves current role?

SYNTHETIC TEACHING DATA — not captured from equipment.
NAC: a valid trusted endpoint certificate authenticates successfully. Authorization selects QuarantineVLAN because posture is unknown. An operator proposes MAB production access. The server policy later changes to Production, but blocked CoA prevents the switch session from updating.

1. Only endpoint hostname
2. The authenticator's session and effective policy
3. Only a policy edit timestamp

**Correct option(s):** 2

- Option 1: Incorrect. It does not show authorization.
- Option 2: Correct. Server intent maybe stale.
- Option 3: Incorrect. That shows intent.

**NETWORK-ENGINEERING-Q0075 · single · implementation**

What can clock error break?

SYNTHETIC TEACHING DATA — not captured from equipment.
NAC: a valid trusted endpoint certificate authenticates successfully. Authorization selects QuarantineVLAN because posture is unknown. An operator proposes MAB production access. The server policy later changes to Production, but blocked CoA prevents the switch session from updating.

1. Only cable polarity
2. Certificate validity evaluation
3. The certificate's public-key length

**Correct option(s):** 2

- Option 1: Incorrect. That is physical.
- Option 2: Correct. Time bounds depend on correct time.
- Option 3: Incorrect. Clock does not change it.

**NETWORK-ENGINEERING-Q0076 · single · diagnosis**

Why validate the server certificate on the endpoint?

SYNTHETIC TEACHING DATA — not captured from equipment.
NAC: a valid trusted endpoint certificate authenticates successfully. Authorization selects QuarantineVLAN because posture is unknown. An operator proposes MAB production access. The server policy later changes to Production, but blocked CoA prevents the switch session from updating.

1. To authenticate the admission service
2. To replace posture checks
3. To assign a VLAN automatically

**Correct option(s):** 1

- Option 1: Correct. Mutual trust matters.
- Option 2: Incorrect. They remain separate.
- Option 3: Incorrect. Authorization policy does that.

**NETWORK-ENGINEERING-Q0077 · single · implementation**

What should an incapable-device exception include?

SYNTHETIC TEACHING DATA — not captured from equipment.
NAC: a valid trusted endpoint certificate authenticates successfully. Authorization selects QuarantineVLAN because posture is unknown. An operator proposes MAB production access. The server policy later changes to Production, but blocked CoA prevents the switch session from updating.

1. Restricted scope, owner and review/expiry
2. No monitoring to avoid noise
3. Unrestricted permanent production access

**Correct option(s):** 1

- Option 1: Correct. Weak identity needs bounded authority.
- Option 2: Incorrect. Exceptions need oversight.
- Option 3: Incorrect. That discards control.

**NETWORK-ENGINEERING-Q0078 · single · implementation**

Which test checks revocation behavior?

SYNTHETIC TEACHING DATA — not captured from equipment.
NAC: a valid trusted endpoint certificate authenticates successfully. Authorization selects QuarantineVLAN because posture is unknown. An operator proposes MAB production access. The server policy later changes to Production, but blocked CoA prevents the switch session from updating.

1. Only an expired password
2. Use an appropriately revoked test certificate
3. Only a valid certificate login

**Correct option(s):** 2

- Option 1: Incorrect. That tests another mechanism.
- Option 2: Correct. Observe actual failure handling.
- Option 3: Incorrect. That omits the negative case.

**NETWORK-ENGINEERING-Q0079 · single · implementation**

What should posture remediation trigger?

SYNTHETIC TEACHING DATA — not captured from equipment.
NAC: a valid trusted endpoint certificate authenticates successfully. Authorization selects QuarantineVLAN because posture is unknown. An operator proposes MAB production access. The server policy later changes to Production, but blocked CoA prevents the switch session from updating.

1. Deletion of audit logs
2. A verified authorization transition
3. Automatic trust of every MAC

**Correct option(s):** 2

- Option 1: Incorrect. That removes evidence.
- Option 2: Correct. The effective policy must change.
- Option 3: Incorrect. That is unrelated widening.

**NETWORK-ENGINEERING-Q0080 · single · implementation**

What closes NAC commissioning?

SYNTHETIC TEACHING DATA — not captured from equipment.
NAC: a valid trusted endpoint certificate authenticates successfully. Authorization selects QuarantineVLAN because posture is unknown. An operator proposes MAB production access. The server policy later changes to Production, but blocked CoA prevents the switch session from updating.

1. Positive, negative, outage and role-transition tests
2. Only one accepted login
3. Only an installed ISE server

**Correct option(s):** 1

- Option 1: Correct. All states matter.
- Option 2: Incorrect. That is too narrow.
- Option 3: Incorrect. Installation is not demonstrated admission behavior.

#### Recall

**Why is a valid certificate still quarantined?**

Authorization includes posture Identity success does not satisfy every policy condition.

**What can clock error break?**

Certificate validity evaluation Time bounds depend on correct time.

**What should posture remediation trigger?**

A verified authorization transition The effective policy must change.

#### References

- [Cisco ISE administrator guides](https://www.cisco.com/c/en/us/support/security/identity-services-engine/products-installation-and-configuration-guides-list.html)
- [EAP-TLS 1.3](https://www.rfc-editor.org/rfc/rfc9190.html)

## NETWORK-ENGINEERING-M09 — Network PKI, certificate lifecycle and AAA continuity

### NETWORK-ENGINEERING-L09 — Network PKI, certificate lifecycle and AAA continuity

Estimated study time: 150 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L08

PKI operation extends beyond issuing a certificate. A relying party builds a chain to a trusted authority, checks the intended identity and usage, evaluates validity time and applies its revocation policy. A trusted issuer does not make every certificate valid for every hostname or role. Renewal can change chain intermediates or algorithms, so test the actual clients before replacing a widely used management or EAP service certificate.

Revocation checking itself has availability dependencies. If a client cannot reach a revocation service, the configured failure policy determines the result. Soft failure may preserve access at the cost of accepting uncertainty; hard failure may deny legitimate clients during an outage. Choose explicitly for the risk and operating requirement, and test the degraded state. Do not discover the policy during a production admission failure.

Keep separate inventories for certificates, private keys, trust anchors and service bindings. A renewed file stored on disk may not be the one used by a running service. Monitor expiry with enough lead time for issuance, validation and rollback. Protect private keys and rotate compromised authorities through a dependency-aware plan that preserves controlled recovery access.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA — not captured from equipment.
Renewal: RADIUS presents a new leaf certificate under IntermediateB. Clients trust RootA but lack B and cannot fetch it. The identity is radius.example.test. Revocation service is unreachable and clients use hard-fail. One standby still presents the old certificate.

**Reasoning:** Trust-anchor presence alone does not guarantee successful chain building if the required intermediate is unavailable. Hard-fail revocation adds another independent admission dependency. The standby can reintroduce the old certificate during failover, so inspect the certificate actually presented by each service endpoint.

#### Guided practice

Create a renewal test covering both active/standby servers and clients with and without cached intermediates.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Validate chain delivery, identity, intended usage, time and revocation behavior for both servers. Force controlled failover and new client admission. Confirm the presented serial/fingerprint rather than merely checking a file on disk.

#### Independent task

Environment: emulator

Operate network certificates and AAA dependencies through renewal, revocation failure and server failover.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Every endpoint presents the approved certificate chain.
- Revocation outage behavior is explicitly accepted.
- Renewal and failover preserve intended admission.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0081 · single · diagnosis**

Why can Root A trust still fail?

SYNTHETIC TEACHING DATA — not captured from equipment.
Renewal: RADIUS presents a new leaf certificate under IntermediateB. Clients trust RootA but lack B and cannot fetch it. The identity is radius.example.test. Revocation service is unreachable and clients use hard-fail. One standby still presents the old certificate.

1. The hostname is necessarily wrong
2. Intermediate B is unavailable
3. Root trust guarantees every chain

**Correct option(s):** 2

- Option 1: Incorrect. The case says it matches.
- Option 2: Correct. The client needs a valid chain.
- Option 3: Incorrect. Intermediate construction still matters.

**NETWORK-ENGINEERING-Q0082 · single · implementation**

What does hard-fail revocation do here?

SYNTHETIC TEACHING DATA — not captured from equipment.
Renewal: RADIUS presents a new leaf certificate under IntermediateB. Clients trust RootA but lack B and cannot fetch it. The identity is radius.example.test. Revocation service is unreachable and clients use hard-fail. One standby still presents the old certificate.

1. Repair the revocation server
2. Always allow unknown status
3. Deny when required status cannot be established

**Correct option(s):** 3

- Option 1: Incorrect. Client policy does not repair it.
- Option 2: Incorrect. That is not hard-fail.
- Option 3: Correct. Availability follows the configured policy.

**NETWORK-ENGINEERING-Q0083 · single · diagnosis**

Why inspect the standby certificate?

SYNTHETIC TEACHING DATA — not captured from equipment.
Renewal: RADIUS presents a new leaf certificate under IntermediateB. Clients trust RootA but lack B and cannot fetch it. The identity is radius.example.test. Revocation service is unreachable and clients use hard-fail. One standby still presents the old certificate.

1. Standby servers never authenticate clients
2. Failover can present stale identity material
3. All certificates replicate automatically

**Correct option(s):** 2

- Option 1: Incorrect. They can after failover.
- Option 2: Correct. Active-server testing is incomplete.
- Option 3: Incorrect. That must be verified.

**NETWORK-ENGINEERING-Q0084 · single · implementation**

Which observation proves the deployed certificate?

SYNTHETIC TEACHING DATA — not captured from equipment.
Renewal: RADIUS presents a new leaf certificate under IntermediateB. Clients trust RootA but lack B and cannot fetch it. The identity is radius.example.test. Revocation service is unreachable and clients use hard-fail. One standby still presents the old certificate.

1. The certificate actually presented by the service
2. Only a filename
3. Only an issuance receipt

**Correct option(s):** 1

- Option 1: Correct. A stored file may not be bound.
- Option 2: Incorrect. It can be unused.
- Option 3: Incorrect. Issuance is not deployment.

**NETWORK-ENGINEERING-Q0085 · single · implementation**

What does issuer trust not prove?

SYNTHETIC TEACHING DATA — not captured from equipment.
Renewal: RADIUS presents a new leaf certificate under IntermediateB. Clients trust RootA but lack B and cannot fetch it. The identity is radius.example.test. Revocation service is unreachable and clients use hard-fail. One standby still presents the old certificate.

1. A trust anchor exists
2. Chain validation is possible with all dependencies
3. Correct hostname and usage

**Correct option(s):** 3

- Option 1: Incorrect. That isthe stated trust relationship.
- Option 2: Incorrect. It can be.
- Option 3: Correct. Those require separate checks.

**NETWORK-ENGINEERING-Q0086 · single · diagnosis**

Why test clients without cached intermediates?

SYNTHETIC TEACHING DATA — not captured from equipment.
Renewal: RADIUS presents a new leaf certificate under IntermediateB. Clients trust RootA but lack B and cannot fetch it. The identity is radius.example.test. Revocation service is unreachable and clients use hard-fail. One standby still presents the old certificate.

1. Caches always invalidate certificates
2. Caches can hide incomplete deployment
3. Only old clients matter

**Correct option(s):** 2

- Option 1: Incorrect. They can help chain building.
- Option 2: Correct. Fresh clients need full chain availability.
- Option 3: Incorrect. New admission is required too.

**NETWORK-ENGINEERING-Q0087 · single · implementation**

What must private-key handling protect?

SYNTHETIC TEACHING DATA — not captured from equipment.
Renewal: RADIUS presents a new leaf certificate under IntermediateB. Clients trust RootA but lack B and cannot fetch it. The identity is radius.example.test. Revocation service is unreachable and clients use hard-fail. One standby still presents the old certificate.

1. Only the public certificate
2. Only the hostname label
3. Confidentiality and authorized use

**Correct option(s):** 3

- Option 1: Incorrect. That material is intended to be public.
- Option 2: Incorrect. It does not protect the key.
- Option 3: Correct. Possession can confer identity authority.

**NETWORK-ENGINEERING-Q0088 · single · implementation**

Which lead time should expiry planning include?

SYNTHETIC TEACHING DATA — not captured from equipment.
Renewal: RADIUS presents a new leaf certificate under IntermediateB. Clients trust RootA but lack B and cannot fetch it. The identity is radius.example.test. Revocation service is unreachable and clients use hard-fail. One standby still presents the old certificate.

1. Only the certificate download
2. Only the last minute
3. Issuance, testing, deployment and recovery

**Correct option(s):** 3

- Option 1: Incorrect. That omits client validation.
- Option 2: Incorrect. That leaves no recovery margin.
- Option 3: Correct. Renewal is a multi-stage operation.

**NETWORK-ENGINEERING-Q0089 · single · implementation**

What should a compromised key trigger?

SYNTHETIC TEACHING DATA — not captured from equipment.
Renewal: RADIUS presents a new leaf certificate under IntermediateB. Clients trust RootA but lack B and cannot fetch it. The identity is radius.example.test. Revocation service is unreachable and clients use hard-fail. One standby still presents the old certificate.

1. Dependency-aware revocation and rotation
2. Ignoring it until expiry
3. Only changing the display name

**Correct option(s):** 1

- Option 1: Correct. Reusing the key preserves compromise.
- Option 2: Incorrect. The attacker retains access.
- Option 3: Incorrect. That does not remove the authority.

**NETWORK-ENGINEERING-Q0090 · single · implementation**

What closes the renewal exercise?

SYNTHETIC TEACHING DATA — not captured from equipment.
Renewal: RADIUS presents a new leaf certificate under IntermediateB. Clients trust RootA but lack B and cannot fetch it. The identity is radius.example.test. Revocation service is unreachable and clients use hard-fail. One standby still presents the old certificate.

1. Fresh admission and failover with validated chain and policy
2. Only server uptime
3. Only a nun expired date

**Correct option(s):** 1

- Option 1: Correct. File replacement alone is partial.
- Option 2: Incorrect. It does not test PKI behavior.
- Option 3: Incorrect. Identity and trust can still fail.

#### Recall

**Why can Root A trust still fail?**

Intermediate B is unavailable The client needs a valid chain.

**What does issuer trust not prove?**

Correct hostname and usage Those require separate checks.

**What should a compromised key trigger?**

Dependency-aware revocation and rotation Reusing the key preserves compromise.

#### References

- [PKIX certificate validation](https://www.rfc-editor.org/rfc/rfc5280.html)
- [TLS 1.3 current specification RFC 9846 (obsoletes RFC 8446)](https://www.rfc-editor.org/rfc/rfc9846.html)

## NETWORK-ENGINEERING-M10 — Hybrid DNS, private routing and boundary observability

### NETWORK-ENGINEERING-L10 — Hybrid DNS, private routing and boundary observability

Estimated study time: 150 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L09

Hybrid connectivity is a service chain: client resolver, DNS policy, returned address, route selection, security controls, tunnel or private interconnect, remote endpoint and return path. A private circuit does not automatically make names resolve privately or make every advertised prefix reachable. Overlapping address ranges can make routing ambiguous and complicate NAT or segmentation; resolve ownership before connecting networks.

Split-horizon DNS serves different answers according to the intended context. Conditional forwarding and resolver placement must preserve the required namespace without leaking internal names unnecessarily. A resolver can be reachable while returning the wrong view, and a cached answer can hide a corrected policy until its lifetime expires. Test the actual client query path and response, not only the authoritative server in isolation.

Cloud route tables, security groups, network ACLs and on-premises firewalls have distinct scopes and state behavior. Avoid assuming that an allowed rule at one layer overrides a denial elsewhere. Capture the packet tuple at each boundary and inspect the return path, including NAT transformations. Keep the course focused on network boundaries; cloud workload/platform specialization is a separate scope.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: internalapp.example.test should resolve to 10.80.0.10. The branch uses a public resolver and receives 198.51.100.10. Private route 10.80.0.0/24 exists. On-premises and cloud networks both use 10.90.0.0/16 for unrelated endpoints. The return path bypasses the forward stateful firewall.

**Reasoning:** The correct private route is irrelevant when DNS sends the client to the public address. Repair the intended resolver path and test cache behavior. Address overlap and asymmetric return routing are separate integration defects that require explicit boundary design, not a broad allow rule.

#### Guided practice

Build a fault table distinguishing wrong DNS view, absent route, security denial and asymmetric stateful return.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** For each hypothesis collect the client answer, route/FIB, relevant policy counters and packet observations on both sides. Use the actual translated tuple where NAT applies. Correct only the demonstrated dependency and retest the whole transaction.

#### Independent task

Environment: emulator

Engineer and diagnose hybrid name resolution and private routing without losing identity, policy or return-path visibility.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Names resolve through the intended view.
- Address ownership and NAT are explicit.
- Both traffic directions pass approved policy boundaries.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0091 · single · diagnosis**

Why does the private route not help this client?

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: internalapp.example.test should resolve to 10.80.0.10. The branch uses a public resolver and receives 198.51.100.10. Private route 10.80.0.0/24 exists. On-premises and cloud networks both use 10.90.0.0/16 for unrelated endpoints. The return path bypasses the forward stateful firewall.

1. Private routes are never usable
2. The resolver must be unreachable
3. DNS returns the public address

**Correct option(s):** 3

- Option 1: Incorrect. They can be when selected.
- Option 2: Incorrect. It returned a response.
- Option 3: Correct. The client does not send to 10.80.0.10.

**NETWORK-ENGINEERING-Q0092 · single · implementation**

What does overlapping 10.90.0.0/16 create?

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: internalapp.example.test should resolve to 10.80.0.10. The branch uses a public resolver and receives 198.51.100.10. Private route 10.80.0.0/24 exists. On-premises and cloud networks both use 10.90.0.0/16 for unrelated endpoints. The return path bypasses the forward stateful firewall.

1. Guaranteed identical hosts
2. Automatic secure peering
3. Ambiguous address ownership

**Correct option(s):** 3

- Option 1: Incorrect. The networks are explicitly unrelated.
- Option 2: Incorrect. Overlap does not authorize connectivity.
- Option 3: Correct. Two unrelated networks share the prefix.

**NETWORK-ENGINEERING-Q0093 · single · implementation**

What can asymmetry break?

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: internalapp.example.test should resolve to 10.80.0.10. The branch uses a public resolver and receives 198.51.100.10. Private route 10.80.0.0/24 exists. On-premises and cloud networks both use 10.90.0.0/16 for unrelated endpoints. The return path bypasses the forward stateful firewall.

1. Only DNS record syntax
2. Every stateless route lookup necessarily
3. Stateful enforcement expectations

**Correct option(s):** 3

- Option 1: Incorrect. Routing asymmetry is different.
- Option 2: Incorrect. Some stateless paths tolerate it.
- Option 3: Correct. Return traffic may miss the forward state.

**NETWORK-ENGINEERING-Q0094 · single · implementation**

Which DNS test uses the correct perspective?

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: internalapp.example.test should resolve to 10.80.0.10. The branch uses a public resolver and receives 198.51.100.10. Private route 10.80.0.0/24 exists. On-premises and cloud networks both use 10.90.0.0/16 for unrelated endpoints. The return path bypasses the forward stateful firewall.

1. Only read the zone file
2. Only ping a resolver
3. Query through the actual client resolver path

**Correct option(s):** 3

- Option 1: Incorrect. That is intent, not client behavior.
- Option 2: Incorrect. Reachability is not correct answers.
- Option 3: Correct. Direct authoritative queries can miss forwarding policy.

**NETWORK-ENGINEERING-Q0095 · single · diagnosis**

Why consider cache lifetime after repair?

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: internalapp.example.test should resolve to 10.80.0.10. The branch uses a public resolver and receives 198.51.100.10. Private route 10.80.0.0/24 exists. On-premises and cloud networks both use 10.90.0.0/16 for unrelated endpoints. The return path bypasses the forward stateful firewall.

1. Old answers can persist
2. Caching changes all IP prefixes
3. TTL guarantees no stale answer ever

**Correct option(s):** 1

- Option 1: Correct. Corrected authority does not instantly erase caches.
- Option 2: Incorrect. It caches answers, not network ownership.
- Option 3: Incorrect. Operational caching must be observed.

**NETWORK-ENGINEERING-Q0096 · single · implementation**

What must NAT diagnosis retain?

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: internalapp.example.test should resolve to 10.80.0.10. The branch uses a public resolver and receives 198.51.100.10. Private route 10.80.0.0/24 exists. On-premises and cloud networks both use 10.90.0.0/16 for unrelated endpoints. The return path bypasses the forward stateful firewall.

1. Only the public IP
2. Only the application name
3. Original and translated tuples

**Correct option(s):** 3

- Option 1: Incorrect. Ports and internal identity may matter.
- Option 2: Incorrect. It does not identify translation.
- Option 3: Correct. Policy and return routing use different views.

**NETWORK-ENGINEERING-Q0097 · single · diagnosis**

Why not treat one allow rule as acceptance?

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: internalapp.example.test should resolve to 10.80.0.10. The branch uses a public resolver and receives 198.51.100.10. Private route 10.80.0.0/24 exists. On-premises and cloud networks both use 10.90.0.0/16 for unrelated endpoints. The return path bypasses the forward stateful firewall.

1. Other layers can still deny
2. All cloud controls are identical
3. Allow rules never work

**Correct option(s):** 1

- Option 1: Correct. Scopes and enforcement differ.
- Option 2: Incorrect. They are different mechanisms.
- Option 3: Incorrect. They can authorize at their layer.

**NETWORK-ENGINEERING-Q0098 · single · implementation**

Which scope is deliberately retained here?

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: internalapp.example.test should resolve to 10.80.0.10. The branch uses a public resolver and receives 198.51.100.10. Private route 10.80.0.0/24 exists. On-premises and cloud networks both use 10.90.0.0/16 for unrelated endpoints. The return path bypasses the forward stateful firewall.

1. Complete cloud application development
2. Only physical cabling
3. Hybrid network boundary engineering

**Correct option(s):** 3

- Option 1: Incorrect. That is outside this course's stated scope.
- Option 2: Incorrect. The boundary has logical dependencies.
- Option 3: Correct. It includes routing, DNS and policy.

**NETWORK-ENGINEERING-Q0099 · single · implementation**

What observation distinguishes DNS from route failure?

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: internalapp.example.test should resolve to 10.80.0.10. The branch uses a public resolver and receives 198.51.100.10. Private route 10.80.0.0/24 exists. On-premises and cloud networks both use 10.90.0.0/16 for unrelated endpoints. The return path bypasses the forward stateful firewall.

1. The returned address before forwarding
2. Only tunnel uptime
3. Only aggregate bandwidth

**Correct option(s):** 1

- Option 1: Correct. Wrong destinations election precedes routing.
- Option 2: Incorrect. It does not validate DNS.
- Option 3: Incorrect. It cannot identify the answer.

**NETWORK-ENGINEERING-Q0100 · single · implementation**

What closes the hybrid repair?

SYNTHETIC TEACHING DATA — not captured from equipment.
Hybrid: internalapp.example.test should resolve to 10.80.0.10. The branch uses a public resolver and receives 198.51.100.10. Private route 10.80.0.0/24 exists. On-premises and cloud networks both use 10.90.0.0/16 for unrelated endpoints. The return path bypasses the forward stateful firewall.

1. Only an up private circuit
2. Only an allowed security group
3. Correct resolution and bidirectional application delivery under policy

**Correct option(s):** 3

- Option 1: Incorrect. That isone layer.
- Option 2: Incorrect. Other controls remain.
- Option 3: Correct. All dependencies must align.

#### Recall

**Why does the private route not help this client?**

DNS returns the public address The client does not send to 10.80.0.10.

**Why consider cache lifetime after repair?**

Old answers can persist Corrected authority does not instantly erase caches.

**What observation distinguishes DNS from route failure?**

The returned address before forwarding Wrong destinations election precedes routing.

#### References

- [DNS concepts](https://www.rfc-editor.org/rfc/rfc1034.html)
- [IPsec architecture](https://www.rfc-editor.org/rfc/rfc4301.html)
- [Private addressing](https://www.rfc-editor.org/rfc/rfc1918.html)

## NETWORK-ENGINEERING-M11 — RoCE fabrics, collective workloads and congestion evidence

### NETWORK-ENGINEERING-L11 — RoCE fabrics, collective workloads and congestion evidence

Estimated study time: 150 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L10

RDMA enables applications to transfer data through supported network-adapter mechanisms with reduced CPU involvement. It does not eliminate memory registration, access keys, queue state or error handling. RoCEv 2 carries RDMA transport over UDP/IP and therefore depends on the IP fabric, MTU, routing and congestion design. A successful ordinary ping is not an RDMA workload test.

AI collectives can create synchronized traffic bursts and many-to-one pressure that differ from independent bulk transfers. Evaluate job completion and tail behavior with representative message sizes, concurrency and placement. A fabric can show high aggregate throughput while one slow participant delays the whole collective. GPU utilization alone cannot locate whether the bottleneck is compute, storage, PCIe, NIC or network.

Congestion management combines correct class mapping, switch queue behavior, ECN feedback, NIC reaction and carefully scoped PFC where the supported design requires it. A copied 'lossless' profile is not a validated system. Track pause duration, congestion notifications, drops, retransmission/error state and workload completion together. Test a link loss or reduced fabric bandwidth while preserving control and management traffic.

Physical topology and host locality matter. NIC-to-GPU placement, NUMA effects, PCIe bandwidth and supported peer-memory paths can limit performance before packets reach the switch. Separate host-path and network-path experiments to avoid tuning the wrong layer.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic AI lab:8 workers complete a collective only when the slowest worker finishes. Worker 7 has PCIe bottleneck; switch links are below 40% average. RoCE traffic maps to priority 3; one leaf maps DSCP to priority 4. PFC 3 is enabled; ECN counters grow on others. Ping passes everywhere.

**Reasoning:** The slow worker can bound collective completion even when fabric averages look low. The mismatched leaf classification is a separate congestion-policy defect. Ping validates neither RDMA queue operation nor message completion. Compare host-local transfers, adapter counters and representative collectives before changing global network buffers.

#### Guided practice

Design tests to separate worker 7 host limitations from the leaf's priority mismatch.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Hold workload placement constant and compare host-local PCIe/NIC measurements with peer RDMA tests. Then correct only the approved class mapping and observe per-priority counters and collective completion. Repeat under link failure with control-traffic latency monitored.

#### Independent task

Environment: emulator

Validate an AI Ethernet/RoCE path across host, adapter, network and workload boundaries.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Host and fabric bottlenecks are distinguished.
- Class and congestion behavior is consistent.
- Representative workload completion meets normal and degraded limits.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0101 · single · diagnosis**

Why can one worker bound collective time?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic AI lab:8 workers complete a collective only when the slowest worker finishes. Worker 7 has PCIe bottleneck; switch links are below 40% average. RoCE traffic maps to priority 3; one leaf maps DSCP to priority 4. PFC 3 is enabled; ECN counters grow on others. Ping passes everywhere.

1. Every collective ignores slow workers
2. Average link speed determines all jobs
3. Participants synchronize on shared progress

**Correct option(s):** 3

- Option 1: Incorrect. That is not the given model.
- Option 2: Incorrect. Host and collective behavior also matter.
- Option 3: Correct. The slowest dependency can delay completion.

**NETWORK-ENGINEERING-Q0102 · single · implementation**

What does ping not prove?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic AI lab:8 workers complete a collective only when the slowest worker finishes. Worker 7 has PCIe bottleneck; switch links are below 40% average. RoCE traffic maps to priority 3; one leaf maps DSCP to priority 4. PFC 3 is enabled; ECN counters grow on others. Ping passes everywhere.

1. RDMA queue and workload operation
2. Any IP connectivity
3. That an endpoint responded

**Correct option(s):** 1

- Option 1: Correct. It uses a different transport/application path.
- Option 2: Incorrect. It does show narrow reachability.
- Option 3: Incorrect. That isthe observation.

**NETWORK-ENGINEERING-Q0103 · single · implementation**

Which host constraint is supplied?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic AI lab:8 workers complete a collective only when the slowest worker finishes. Worker 7 has PCIe bottleneck; switch links are below 40% average. RoCE traffic maps to priority 3; one leaf maps DSCP to priority 4. PFC 3 is enabled; ECN counters grow on others. Ping passes everywhere.

1. A guaranteed router failure
2. A DNS lookup delay
3. Worker 7's PCIe bottleneck

**Correct option(s):** 3

- Option 1: Incorrect. No such evidence exists.
- Option 2: Incorrect. Not supplied.
- Option 3: Correct. Traffic can be limited before the switch.

**NETWORK-ENGINEERING-Q0104 · single · implementation**

What does the leaf mapping error affect?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic AI lab:8 workers complete a collective only when the slowest worker finishes. Worker 7 has PCIe bottleneck; switch links are below 40% average. RoCE traffic maps to priority 3; one leaf maps DSCP to priority 4. PFC 3 is enabled; ECN counters grow on others. Ping passes everywhere.

1. Every other leaf's firmware version
2. RDMA memory ownership automatically
3. Intended per-priority treatment

**Correct option(s):** 3

- Option 1: Incorrect. Mapping does not change that.
- Option 2: Incorrect. Classification is not memory authorization.
- Option 3: Correct. Traffic enters a different class.

**NETWORK-ENGINEERING-Q0105 · single · implementation**

Which metric is closest to useful AI service?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic AI lab:8 workers complete a collective only when the slowest worker finishes. Worker 7 has PCIe bottleneck; switch links are below 40% average. RoCE traffic maps to priority 3; one leaf maps DSCP to priority 4. PFC 3 is enabled; ECN counters grow on others. Ping passes everywhere.

1. Only peak port rate
2. Only switch uptime
3. Representative job or collective completion time

**Correct option(s):** 3

- Option 1: Incorrect. It omits the workload.
- Option 2: Incorrect. It omits transfer progress.
- Option 3: Correct. Throughput alone can hide a straggler.

**NETWORK-ENGINEERING-Q0106 · single · diagnosis**

Why inspect NIC and switch counters together?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic AI lab:8 workers complete a collective only when the slowest worker finishes. Worker 7 has PCIe bottleneck; switch links are below 40% average. RoCE traffic maps to priority 3; one leaf maps DSCP to priority 4. PFC 3 is enabled; ECN counters grow on others. Ping passes everywhere.

1. Switches perform all memory registration
2. NICs have no error state
3. Congestion control spans endpoint and network

**Correct option(s):** 3

- Option 1: Incorrect. That is an endpoint function.
- Option 2: Incorrect. They do.
- Option 3: Correct. One layer can hide a mismatched reaction.

**NETWORK-ENGINEERING-Q0107 · single · implementation**

What does low average utilization not exclude?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic AI lab:8 workers complete a collective only when the slowest worker finishes. Worker 7 has PCIe bottleneck; switch links are below 40% average. RoCE traffic maps to priority 3; one leaf maps DSCP to priority 4. PFC 3 is enabled; ECN counters grow on others. Ping passes everywhere.

1. Any working control path
2. Every physical packet
3. Synchronized bursts or host bottlenecks

**Correct option(s):** 3

- Option 1: Incorrect. It says little about that path.
- Option 2: Incorrect. Traffic can still flow.
- Option 3: Correct. Averages are incomplete.

**NETWORK-ENGINEERING-Q0108 · single · implementation**

What must a class-mapping repair preserve?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic AI lab:8 workers complete a collective only when the slowest worker finishes. Worker 7 has PCIe bottleneck; switch links are below 40% average. RoCE traffic maps to priority 3; one leaf maps DSCP to priority 4. PFC 3 is enabled; ECN counters grow on others. Ping passes everywhere.

1. Unlimited priority for all hosts
2. Approved control and management service
3. No audit logs

**Correct option(s):** 2

- Option 1: Incorrect. That can starve others.
- Option 2: Correct. AI performance does not override other constraints.
- Option 3: Incorrect. Observability remains required.

**NETWORK-ENGINEERING-Q0109 · single · diagnosis**

Why vary workload placement carefully?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic AI lab:8 workers complete a collective only when the slowest worker finishes. Worker 7 has PCIe bottleneck; switch links are below 40% average. RoCE traffic maps to priority 3; one leaf maps DSCP to priority 4. PFC 3 is enabled; ECN counters grow on others. Ping passes everywhere.

1. Placement never affects RDMA
2. Only hostnames matter
3. Locality changes PCIe and network demand

**Correct option(s):** 3

- Option 1: Incorrect. It can.
- Option 2: Incorrect. Physical/logical placement matters.
- Option 3: Correct. Uncontrolled placement confounds comparison.

**NETWORK-ENGINEERING-Q0110 · single · implementation**

What closes RoCE acceptance?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic AI lab:8 workers complete a collective only when the slowest worker finishes. Worker 7 has PCIe bottleneck; switch links are below 40% average. RoCE traffic maps to priority 3; one leaf maps DSCP to priority 4. PFC 3 is enabled; ECN counters grow on others. Ping passes everywhere.

1. Supported stack plus measured workload and failure behavior
2. Only a valid IP route
3. Only PFC enabled

**Correct option(s):** 1

- Option 1: Correct. A generic profile is not evidence.
- Option 2: Incorrect. RDMA adds dependencies.
- Option 3: Incorrect. Congestion behavior remains unproven.

#### Recall

**Why can one worker bound collective time?**

Participants synchronize on shared progress The slowest dependency can delay completion.

**Which metric is closest to useful AI service?**

Representative job or collective completion time Throughput alone can hide a straggler.

**Why vary workload placement carefully?**

Locality changes PCIe and network demand Uncontrolled placement confounds comparison.

#### References

- [NVIDIA RDMA programming guide](https://networking-docs.nvidia.com/rdmaawareprogramming)
- [Cisco Nexus QoS guides](https://www.cisco.com/c/en/us/support/switches/nexus-9000-series-switches/products-installation-and-configuration-guides-list.html)

## NETWORK-ENGINEERING-M12 — InfiniBand subnet management, partitions and RDMA diagnosis

### NETWORK-ENGINEERING-L12 — InfiniBand subnet management, partitions and RDMA diagnosis

Estimated study time: 150 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L11

InfiniBand is not Ethernet with different connectors. Its subnet-management, addressing, routing, link and partition mechanisms require their own engineering and evidence. The subnet manager discovers and configures the fabric according to supported policy; loss or conflict in management can affect initialization or topology changes even while some existing traffic continues. Record the active and standby management roles and their failure behavior.

Ports have persistent identifiers and assigned local addressing within the subnet. Link state, width and speed must be checked independently. A port can initialize at a lower width or speed than intended, producing a performance defect without complete loss. Partition membership controls which endpoints may communicate within the supported model; a matching physical link does not imply the required membership or queue-pair state.

RDMA diagnosis spans memory registration and access permissions, queue-pair transitions, completion status, transport retries and fabric forwarding. A completion error is evidence that must be interpreted, not a reason to reset the entire cluster immediately. Separate endpoint programming errors from path congestion or link impairment using a known-good peer and controlled message sizes.

Acceptance includes topology discovery, partition isolation, representative data transfers, subnet-manager failover and link degradation. An Ethernet emulator cannot demonstrate these InfiniBand mechanisms; use supported hardware or clearly label an analytical model's limits.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA — not captured from equipment.
InfiniBand: intended 4-lane link operates at 1 lane. Endpoints A and B share a partition; C does not. Subnet manager M 1 is active; M 2 has stale partition policy. A-to-B completes slowly; A-to-C is denied. No actual hardware output is claimed.

**Reasoning:** The A-B slowdown is consistent with reduced link width and requires physical/configuration investigation. C's denial can be correct isolation rather than a fault. A failover to stale M 2 may alter membership, so synchronize reviewed management policy and test the transition independently.

#### Guided practice

Design a failure test that preserves partition isolation when M 1 is lost.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Confirm M 2's approved policy and role, capture current membership, withdraw M 1 under controlled conditions, then test required A-B communication and denied A-C communication while observing link and manager state. Record interruption and new topology behavior.

#### Independent task

Environment: emulator

Engineer and test an InfiniBand fabric asan independent technology branch with partition and manager recovery evidence.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Expected link width/speed are verified.
- Partition isolation passes positive and negative tests.
- Manager failover preserves reviewed policy.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0111 · single · implementation**

What explains reduced potential link capacity?

SYNTHETIC TEACHING DATA — not captured from equipment.
InfiniBand: intended 4-lane link operates at 1 lane. Endpoints A and B share a partition; C does not. Subnet manager M 1 is active; M 2 has stale partition policy. A-to-B completes slowly; A-to-C is denied. No actual hardware output is claimed.

1. One lane instead of the intended four
2. Partition denial to C
3. The presence of M 2

**Correct option(s):** 1

- Option 1: Correct. Width is below design.
- Option 2: Incorrect. That is a separate flow.
- Option 3: Incorrect. A standby alone does not reduce width.

**NETWORK-ENGINEERING-Q0112 · single · diagnosis**

Is denied A-C communication necessarily a fault?

SYNTHETIC TEACHING DATA — not captured from equipment.
InfiniBand: intended 4-lane link operates at 1 lane. Endpoints A and B share a partition; C does not. Subnet manager M 1 is active; M 2 has stale partition policy. A-to-B completes slowly; A-to-C is denied. No actual hardware output is claimed.

1. Yes, every IB endpoint must communicate
2. Yes, linkup bypasses partitions
3. No, C is outside the approved partition

**Correct option(s):** 3

- Option 1: Incorrect. Partitions constrain access.
- Option 2: Incorrect. It does not.
- Option 3: Correct. Isolation can be intended.

**NETWORK-ENGINEERING-Q0113 · single · calculation**

What is the risk of stale M 2 policy?

SYNTHETIC TEACHING DATA — not captured from equipment.
InfiniBand: intended 4-lane link operates at 1 lane. Endpoints A and B share a partition; C does not. Subnet manager M 1 is active; M 2 has stale partition policy. A-to-B completes slowly; A-to-C is denied. No actual hardware output is claimed.

1. All links automatically run faster
2. Only the GUI color changes
3. Failover may change effective membership

**Correct option(s):** 3

- Option 1: Incorrect. Management staleness does not add speed.
- Option 2: Incorrect. Policy affects operation.
- Option 3: Correct. Standby intent must match approved state.

**NETWORK-ENGINEERING-Q0114 · single · implementation**

Which identifiers need distinction?

SYNTHETIC TEACHING DATA — not captured from equipment.
InfiniBand: intended 4-lane link operates at 1 lane. Endpoints A and B share a partition; C does not. Subnet manager M 1 is active; M 2 has stale partition policy. A-to-B completes slowly; A-to-C is denied. No actual hardware output is claimed.

1. Only application usernames
2. Persistent port identity and assigned subnet address
3. Only Ethernet MAC and IP always

**Correct option(s):** 2

- Option 1: Incorrect. They do not describe IB addressing.
- Option 2: Correct. They serve different roles.
- Option 3: Incorrect. IB has its own model.

**NETWORK-ENGINEERING-Q0115 · single · implementation**

What does a completion error require?

SYNTHETIC TEACHING DATA — not captured from equipment.
InfiniBand: intended 4-lane link operates at 1 lane. Endpoints A and B share a partition; C does not. Subnet manager M 1 is active; M 2 has stale partition policy. A-to-B completes slowly; A-to-C is denied. No actual hardware output is claimed.

1. Immediate cluster reset always
2. Interpret endpoint and transport status
3. Ignoring it if ping works

**Correct option(s):** 2

- Option 1: Incorrect. That destroys local evidence.
- Option 2: Correct. It is not automatically a fabric-wide failure.
- Option 3: Incorrect. Ping does not validate RDMA completion.

**NETWORK-ENGINEERING-Q0116 · single · diagnosis**

Why test partition negative cases?

SYNTHETIC TEACHING DATA — not captured from equipment.
InfiniBand: intended 4-lane link operates at 1 lane. Endpoints A and B share a partition; C does not. Subnet manager M 1 is active; M 2 has stale partition policy. A-to-B completes slowly; A-to-C is denied. No actual hardware output is claimed.

1. To make all jobs fail
2. To replace link tests
3. Reachability alone does not prove isolation

**Correct option(s):** 3

- Option 1: Incorrect. Denial should be scoped.
- Option 2: Incorrect. Both are required.
- Option 3: Correct. Unapproved peers must remain blocked.

**NETWORK-ENGINEERING-Q0117 · single · implementation**

What does an Ethernet emulator not demonstrate?

SYNTHETIC TEACHING DATA — not captured from equipment.
InfiniBand: intended 4-lane link operates at 1 lane. Endpoints A and B share a partition; C does not. Subnet manager M 1 is active; M 2 has stale partition policy. A-to-B completes slowly; A-to-C is denied. No actual hardware output is claimed.

1. An analytical topology idea
2. Actual IB subnet and link behavior
3. A written requirement

**Correct option(s):** 2

- Option 1: Incorrect. It can illustrate concepts.
- Option 2: Correct. The protocols and hardware differ.
- Option 3: Incorrect. That does not require IB hardware.

**NETWORK-ENGINEERING-Q0118 · single · diagnosis**

Which test separates endpoint from path faults?

SYNTHETIC TEACHING DATA — not captured from equipment.
InfiniBand: intended 4-lane link operates at 1 lane. Endpoints A and B share a partition; C does not. Subnet manager M 1 is active; M 2 has stale partition policy. A-to-B completes slowly; A-to-C is denied. No actual hardware output is claimed.

1. A known-good peer and controlled transfer
2. Only resetting all nodes
3. Only maximum advertised speed

**Correct option(s):** 1

- Option 1: Correct. It narrows the changing dependency.
- Option 2: Incorrect. That changes many variables.
- Option 3: Incorrect. That is not measured operation.

**NETWORK-ENGINEERING-Q0119 · single · implementation**

What must manager failover observe?

SYNTHETIC TEACHING DATA — not captured from equipment.
InfiniBand: intended 4-lane link operates at 1 lane. Endpoints A and B share a partition; C does not. Subnet manager M 1 is active; M 2 has stale partition policy. A-to-B completes slowly; A-to-C is denied. No actual hardware output is claimed.

1. Policy continuity and topology changes
2. Only a static diagram
3. Only M 1 power state

**Correct option(s):** 1

- Option 1: Correct. Existing traffic alone is incomplete.
- Option 2: Incorrect. It does not capture transition.
- Option 3: Incorrect. It omits M 2 behavior.

**NETWORK-ENGINEERING-Q0120 · single · implementation**

What closes IB commissioning?

SYNTHETIC TEACHING DATA — not captured from equipment.
InfiniBand: intended 4-lane link operates at 1 lane. Endpoints A and B share a partition; C does not. Subnet manager M 1 is active; M 2 has stale partition policy. A-to-B completes slowly; A-to-C is denied. No actual hardware output is claimed.

1. Width, speed, partition, transfer and failover evidence
2. Only a RoCE test
3. Only link initialization

**Correct option(s):** 1

- Option 1: Correct. Each mechanism needs testing.
- Option 2: Incorrect. RoCE is a different branch.
- Option 3: Incorrect. That isone stage.

#### Recall

**What explains reduced potential link capacity?**

One lane instead of the intended four Width is below design.

**What does a completion error require?**

Interpret endpoint and transport status It is not automatically a fabric-wide failure.

**What must manager failover observe?**

Policy continuity and topology changes Existing traffic alone is incomplete.

#### References

- [NVIDIA InfiniBand documentation](https://docs.nvidia.com/networking/)

## NETWORK-ENGINEERING-M13 — Time distribution, holdover and event-order uncertainty

### NETWORK-ENGINEERING-L13 — Time distribution, holdover and event-order uncertainty

Estimated study time: 150 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L12

Time is an infrastructure dependency for authentication, event reconstruction, control coordination and measurement. Different functions require different accuracy, precision and availability. A timestamp with many decimal places is not proof of accuracy. Define the maximum permitted offset and holdover interval for each function, then select and validate the distribution method.

NTP estimates clock offset across network exchanges and must cope with delay and asymmetry. PTP can use hardware time stamping and boundary/transparent clock behavior in supported designs to improve timing control, but the entire path and profile must be compatible. IRIG-B is a separate time-code interface whose electrical format, encoding and quality indications must match the equipment. Do not collapse them into one generic 'time synchronized' check box.

Reference loss creates holdover behavior: a clock continues from its oscillator with growing uncertainty. A misleading healthy flag can be worse than an explicit degraded state. Monitor source identity, selected reference, offset, delay, quality and last-valid synchronization. Time attacks or accidental source changes can affect trusted event ordering even when transport authentication succeeds.

Commission normal accuracy, asymmetric delay, source failure, failover and recovery. Correlate a known physical or logical event across devices and report the uncertainty bound. Do not claim event A caused event B when their separation is smaller than the combined timing uncertainty.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic timing: device A timestamp leads reference by 3 ms; device B lags by 2 ms. Event A logged 10:00:00.004; event B logged 10:00:00.003. Required ordering resolution is 1 ms. PTP reference fails; device continues holdover without quality alarm. IRIG-B receiver expects modulated input but source provides TTL.

**Reasoning:** Corrected A time is .001 and B time is .005, reversing the raw ordering. The stated offsets alone need uncertainty bounds before 1 ms claims are defensible. Holdover quality must be exposed, and the IRIG-B electrical mismatch is independent of IP timing service health.

#### Guided practice

Define acceptance evidence for a time-source failover without falsely claiming perfect synchronization.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Measure offset/uncertainty against a suitable reference before, during and after failover; record selected source and quality state; verify alarms and application tolerance. State the actual bound and holdover duration rather than only reporting synchronized=true.

#### Independent task

Environment: emulator

Engineer and verify time distribution across IP and time-code interfaces with bounded event-order claims.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Interface formats and profiles match.
- Holdover produces visible quality degradation.
- Causal ordering respects measured uncertainty.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0121 · single · implementation**

Which corrected event is earlier?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timing: device A timestamp leads reference by 3 ms; device B lags by 2 ms. Event A logged 10:00:00.004; event B logged 10:00:00.003. Required ordering resolution is 1 ms. PTP reference fails; device continues holdover without quality alarm. IRIG-B receiver expects modulated input but source provides TTL.

1. They are identical
2. B because.003 is less than.004
3. A at .001

**Correct option(s):** 3

- Option 1: Incorrect. The corrected times differ.
- Option 2: Incorrect. Raw clocks have known offsets.
- Option 3: Correct. Subtract A's 3 ms lead and add B's 2 ms lag.

**NETWORK-ENGINEERING-Q0122 · single · implementation**

What does decimal precision not prove?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timing: device A timestamp leads reference by 3 ms; device B lags by 2 ms. Event A logged 10:00:00.004; event B logged 10:00:00.003. Required ordering resolution is 1 ms. PTP reference fails; device continues holdover without quality alarm. IRIG-B receiver expects modulated input but source provides TTL.

1. That comparisons can be attempted
2. Clock accuracy
3. That a timestamp was formatted

**Correct option(s):** 2

- Option 1: Incorrect. They can, with uncertainty.
- Option 2: Correct. Display resolution is not reference error.
- Option 3: Incorrect. It does show format.

**NETWORK-ENGINEERING-Q0123 · single · diagnosis**

Why expose holdover quality?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timing: device A timestamp leads reference by 3 ms; device B lags by 2 ms. Event A logged 10:00:00.004; event B logged 10:00:00.003. Required ordering resolution is 1 ms. PTP reference fails; device continues holdover without quality alarm. IRIG-B receiver expects modulated input but source provides TTL.

1. Holdover always stops the clock
2. A clock need never recover
3. Uncertainty grows without a valid reference

**Correct option(s):** 3

- Option 1: Incorrect. It generally continues locally.
- Option 2: Incorrect. Recovery still matters.
- Option 3: Correct. Continued ticking is not continued accuracy.

**NETWORK-ENGINEERING-Q0124 · single · implementation**

What breaks the supplied IRIG-Binterface?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timing: device A timestamp leads reference by 3 ms; device B lags by 2 ms. Event A logged 10:00:00.004; event B logged 10:00:00.003. Required ordering resolution is 1 ms. PTP reference fails; device continues holdover without quality alarm. IRIG-B receiver expects modulated input but source provides TTL.

1. The number of IP routes
2. Electrical format mismatch
3. The NTP poll interval

**Correct option(s):** 2

- Option 1: Incorrect. IRIG-B here is a different interface.
- Option 2: Correct. Modulated and TTL inputs are not interchangeable.
- Option 3: Incorrect. That is a separate protocol.

**NETWORK-ENGINEERING-Q0125 · single · implementation**

Which condition can bias NTP estimates?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timing: device A timestamp leads reference by 3 ms; device B lags by 2 ms. Event A logged 10:00:00.004; event B logged 10:00:00.003. Required ordering resolution is 1 ms. PTP reference fails; device continues holdover without quality alarm. IRIG-B receiver expects modulated input but source provides TTL.

1. Only hostname capitalization
2. Only VLAN description length
3. Path delay asymmetry

**Correct option(s):** 3

- Option 1: Incorrect. It does not change timing.
- Option 2: Incorrect. It is not delay.
- Option 3: Correct. Two-way estimation assumptions matter.

**NETWORK-ENGINEERING-Q0126 · single · design**

What must a PTP design pin?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timing: device A timestamp leads reference by 3 ms; device B lags by 2 ms. Event A logged 10:00:00.004; event B logged 10:00:00.003. Required ordering resolution is 1 ms. PTP reference fails; device continues holdover without quality alarm. IRIG-B receiver expects modulated input but source provides TTL.

1. Only the grandmaster's label
2. Only the UDP port
3. Profile, time stamping and path-clock behavior

**Correct option(s):** 3

- Option 1: Incorrect. Labels are not timing quality.
- Option 2: Incorrect. That omits critical behavior.
- Option 3: Correct. Compatibility is end-to-end.

**NETWORK-ENGINEERING-Q0127 · single · implementation**

When is causal ordering unsupported?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timing: device A timestamp leads reference by 3 ms; device B lags by 2 ms. Event A logged 10:00:00.004; event B logged 10:00:00.003. Required ordering resolution is 1 ms. PTP reference fails; device continues holdover without quality alarm. IRIG-B receiver expects modulated input but source provides TTL.

1. Whenever timestamps differ at all
2. Only when devices use IPv6
3. Event separation is within combined uncertainty

**Correct option(s):** 3

- Option 1: Incorrect. Large differences can be interpretable.
- Option 2: Incorrect. Protocol family is not the criterion.
- Option 3: Correct. The order may not be distinguishable.

**NETWORK-ENGINEERING-Q0128 · single · implementation**

What should timing telemetry identify?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timing: device A timestamp leads reference by 3 ms; device B lags by 2 ms. Event A logged 10:00:00.004; event B logged 10:00:00.003. Required ordering resolution is 1 ms. PTP reference fails; device continues holdover without quality alarm. IRIG-B receiver expects modulated input but source provides TTL.

1. Only the clock's number of digits
2. Only the server's marketing name
3. Selected source, offset, quality and freshness

**Correct option(s):** 3

- Option 1: Incorrect. Precision is not accuracy.
- Option 2: Incorrect. It omits measured state.
- Option 3: Correct. Synchronized=true is too coarse.

**NETWORK-ENGINEERING-Q0129 · single · implementation**

Which acceptance event tests resilience?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timing: device A timestamp leads reference by 3 ms; device B lags by 2 ms. Event A logged 10:00:00.004; event B logged 10:00:00.003. Required ordering resolution is 1 ms. PTP reference fails; device continues holdover without quality alarm. IRIG-B receiver expects modulated input but source provides TTL.

1. Reference loss and controlled failover
2. Only a dashboard refresh
3. Only a configuration save

**Correct option(s):** 1

- Option 1: Correct. Normal synchronization is insufficient.
- Option 2: Incorrect. It is not a fault test.
- Option 3: Incorrect. It changes no reference.

**NETWORK-ENGINEERING-Q0130 · single · implementation**

What does authenticated timing not guarantee?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timing: device A timestamp leads reference by 3 ms; device B lags by 2 ms. Event A logged 10:00:00.004; event B logged 10:00:00.003. Required ordering resolution is 1 ms. PTP reference fails; device continues holdover without quality alarm. IRIG-B receiver expects modulated input but source provides TTL.

1. That the source identity was checked
2. That messages were received
3. Correct physical time or benign source behavior

**Correct option(s):** 3

- Option 1: Incorrect. Authentication can establish that.
- Option 2: Incorrect. Reception can be observed.
- Option 3: Correct. Authenticity and measurement correctness differ.

#### Recall

**Which corrected event is earlier?**

A at .001 Subtract A's 3 ms lead and add B's 2 ms lag.

**Which condition can bias NTP estimates?**

Path delay asymmetry Two-way estimation assumptions matter.

**Which acceptance event tests resilience?**

Reference loss and controlled failover Normal synchronization is insufficient.

#### References

- [NTPv 4](https://www.rfc-editor.org/rfc/rfc5905.html)
- [IEEE 1588 information](https://standards.ieee.org/ieee/1588/6825/)

## NETWORK-ENGINEERING-M14 — BACnet/IP, discovery scope and routed controls boundaries

### NETWORK-ENGINEERING-L14 — BACnet/IP, discovery scope and routed controls boundaries

Estimated study time: 150 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L13

BACnet carries building-control objects and services whose semantics matter beyond IP delivery. Device identity, object identifiers, properties, units, reliability and update behavior must match the engineering point list. A successful Who-Is/I-Am discovery exchange does not prove that a temperature point is correctly scaled or that a commanded output affects the intended equipment.

Broadcast discovery across IP subnets requires deliberate architecture. BACnet broadcast-management mechanisms can distribute selected broadcasts, but broad forwarding can create unnecessary load and widen the discovery boundary. Modern secure-connectivity options have different trust and infrastructure dependencies; choose a supported product design rather than assuming every controller implements the same feature set.

MS/TP introduces serial bus timing, addressing, token behavior, baud rate, termination and physical-layer constraints. A BACnet/IP-to-MS/TP router can remain ping able while the serial segment is mis configured or overloaded. Diagnose the IP side, router mapping and serial/application side separately. Polling many points aggressively can consume finite serial bandwidth and delay control-relevant updates.

Commission identity uniqueness, discovery scope, read/write permissions, value quality, freshness and recovery after router/controller loss. Use read-only points first. Any command test must use an isolated lab or an approved procedure tied to the physical consequence.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA — not captured from equipment.
Controls: router R responds to IP ping. MS/TP uses 38400 baud but one controller uses 76800. Two devices share BACnet device ID 4001. BMS retains 22.0°C without a freshness flag after serial loss. Discovery forwarding includes an unapproved subnet.

**Reasoning:** Ping validates only router IP reachability. The serial baud mismatch and duplicate BACnet identity can independently break application behavior. The retained 22°C value must be marked stale, and discovery scope should be restricted to the approved integration boundary.

#### Guided practice

Create a commissioning checklist that proves the displayed point corresponds to the intended physical input.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Verify unique device/object identity, units/scaling and quality; apply a controlled known input in the lab; observe value and timestamp through the whole path; disconnect the serial link and verify stale/alarm behavior; restore and confirm recovery without unauthorized writes.

#### Independent task

Environment: emulator

Commission BACnet network and application delivery across routed IP and serial boundaries.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Device/object identities are unique and mapped.
- Discovery remains within approved scope.
- Freshness and physical point correctness are verified separately.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0131 · single · implementation**

What does router ping not prove?

SYNTHETIC TEACHING DATA — not captured from equipment.
Controls: router R responds to IP ping. MS/TP uses 38400 baud but one controller uses 76800. Two devices share BACnet device ID 4001. BMS retains 22.0°C without a freshness flag after serial loss. Discovery forwarding includes an unapproved subnet.

1. The router has an address
2. MS/TP and BACnet application health
3. Any IP transport reachability

**Correct option(s):** 2

- Option 1: Incorrect. The response implies it.
- Option 2: Correct. The serial side is a separate dependency.
- Option 3: Incorrect. Ping does provide that.

**NETWORK-ENGINEERING-Q0132 · single · calculation**

What is the serial mismatch?

SYNTHETIC TEACHING DATA — not captured from equipment.
Controls: router R responds to IP ping. MS/TP uses 38400 baud but one controller uses 76800. Two devices share BACnet device ID 4001. BMS retains 22.0°C without a freshness flag after serial loss. Discovery forwarding includes an unapproved subnet.

1. The router's IP subnet alone
2. 38400 versus 76800 baud
3. Different BACnet object names

**Correct option(s):** 2

- Option 1: Incorrect. That does not determine the serial rate.
- Option 2: Correct. Participants need compatible bus settings.
- Option 3: Incorrect. Names do not set baud.

**NETWORK-ENGINEERING-Q0133 · single · diagnosis**

Why are duplicate device IDs harmful?

SYNTHETIC TEACHING DATA — not captured from equipment.
Controls: router R responds to IP ping. MS/TP uses 38400 baud but one controller uses 76800. Two devices share BACnet device ID 4001. BMS retains 22.0°C without a freshness flag after serial loss. Discovery forwarding includes an unapproved subnet.

1. Discovery and mapping can be ambiguous
2. They automatically merge physical devices safely
3. They increase point capacity

**Correct option(s):** 1

- Option 1: Correct. Identity should be unique in scope.
- Option 2: Incorrect. That is not a valid assumption.
- Option 3: Incorrect. Duplication does not add resources.

**NETWORK-ENGINEERING-Q0134 · single · implementation**

How should retained 22°C be presented after loss?

SYNTHETIC TEACHING DATA — not captured from equipment.
Controls: router R responds to IP ping. MS/TP uses 38400 baud but one controller uses 76800. Two devices share BACnet device ID 4001. BMS retains 22.0°C without a freshness flag after serial loss. Discovery forwarding includes an unapproved subnet.

1. As current healthy temperature
2. As exactly 0°C automatically
3. As stale or invalid per policy

**Correct option(s):** 3

- Option 1: Incorrect. Transport loss removes freshness.
- Option 2: Incorrect. That fabricates a physical value.
- Option 3: Correct. The last value is not current measurement.

**NETWORK-ENGINEERING-Q0135 · single · implementation**

What does broadcast management need?

SYNTHETIC TEACHING DATA — not captured from equipment.
Controls: router R responds to IP ping. MS/TP uses 38400 baud but one controller uses 76800. Two devices share BACnet device ID 4001. BMS retains 22.0°C without a freshness flag after serial loss. Discovery forwarding includes an unapproved subnet.

1. Explicit approved discovery scope
2. Every subnet by default
3. Only a DNS record

**Correct option(s):** 1

- Option 1: Correct. Unbounded forwarding widens exposure.
- Option 2: Incorrect. That ignores boundaries.
- Option 3: Incorrect. Discovery behavior is different.

**NETWORK-ENGINEERING-Q0136 · single · implementation**

Which test proves point mapping?

SYNTHETIC TEACHING DATA — not captured from equipment.
Controls: router R responds to IP ping. MS/TP uses 38400 baud but one controller uses 76800. Two devices share BACnet device ID 4001. BMS retains 22.0°C without a freshness flag after serial loss. Discovery forwarding includes an unapproved subnet.

1. Only successful Who-Is
2. Only router uptime
3. A controlled known input observed end to end

**Correct option(s):** 3

- Option 1: Incorrect. Discovery does not verify physical meaning.
- Option 2: Incorrect. It does not test the point.
- Option 3: Correct. Object names alone are insufficient.

**NETWORK-ENGINEERING-Q0137 · single · diagnosis**

Why bound polling rates?

SYNTHETIC TEACHING DATA — not captured from equipment.
Controls: router R responds to IP ping. MS/TP uses 38400 baud but one controller uses 76800. Two devices share BACnet device ID 4001. BMS retains 22.0°C without a freshness flag after serial loss. Discovery forwarding includes an unapproved subnet.

1. BACnet points never change
2. Serial bandwidth and controller processing are finite
3. Faster polling always improves control

**Correct option(s):** 2

- Option 1: Incorrect. They can change continuously.
- Option 2: Correct. Excess polling can delay updates.
- Option 3: Incorrect. It can overload dependencies.

**NETWORK-ENGINEERING-Q0138 · single · implementation**

What must write commissioning consider?

SYNTHETIC TEACHING DATA — not captured from equipment.
Controls: router R responds to IP ping. MS/TP uses 38400 baud but one controller uses 76800. Two devices share BACnet device ID 4001. BMS retains 22.0°C without a freshness flag after serial loss. Discovery forwarding includes an unapproved subnet.

1. Only the screen label
2. Only network latency
3. The physical consequence and authorization

**Correct option(s):** 3

- Option 1: Incorrect. Labels can be wrong.
- Option 2: Incorrect. Safety and function matter too.
- Option 3: Correct. A command can affect equipment.

**NETWORK-ENGINEERING-Q0139 · single · implementation**

Which layers should be diagnosed separately?

SYNTHETIC TEACHING DATA — not captured from equipment.
Controls: router R responds to IP ping. MS/TP uses 38400 baud but one controller uses 76800. Two devices share BACnet device ID 4001. BMS retains 22.0°C without a freshness flag after serial loss. Discovery forwarding includes an unapproved subnet.

1. Only the BMS screen
2. IP transport, router mapping, serial and application
3. Only the IP layer

**Correct option(s):** 2

- Option 1: Incorrect. It can hide staleness.
- Option 2: Correct. Success atone does not establish others.
- Option 3: Incorrect. That misses the supplied faults.

**NETWORK-ENGINEERING-Q0140 · single · implementation**

What closes the BACnet task?

SYNTHETIC TEACHING DATA — not captured from equipment.
Controls: router R responds to IP ping. MS/TP uses 38400 baud but one controller uses 76800. Two devices share BACnet device ID 4001. BMS retains 22.0°C without a freshness flag after serial loss. Discovery forwarding includes an unapproved subnet.

1. Identity, value, quality, freshness and failure recovery evidence
2. Only a discovery list
3. Only a valid temperature format

**Correct option(s):** 1

- Option 1: Correct. Ping alone is incomplete.
- Option 2: Incorrect. That isone stage.
- Option 3: Incorrect. Formatting does not prove physical correctness.

#### Recall

**What does router ping not prove?**

MS/TP and BACnet application health The serial side is a separate dependency.

**What does broadcast management need?**

Explicit approved discovery scope Unbounded forwarding widens exposure.

**Which layers should be diagnosed separately?**

IP transport, router mapping, serial and application Success atone does not establish others.

#### References

- [BACnet International technical resources](https://bacnetinternational.org/)
- [BACnet standard information](https://bacnet.org/)

## NETWORK-ENGINEERING-M15 — Modbus registers, gateway translation and write authority

### NETWORK-ENGINEERING-L15 — Modbus registers, gateway translation and write authority

Estimated study time: 150 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L14

Modbus requests identify an operation and data address, but the protocol does not by itself define the engineering meaning of a register. The device register map specifies units, scaling, signed ness, word order and allowed writes. A valid response can therefore carry a value that the client interprets incorrectly. Distinguish protocol success from physical measurement correctness.

Documentation often uses human-oriented register notation while the protocol transmits an address offset. Verify the device's convention rather than universally subtracting one from every number. Multi-register values add word-order and data-type assumptions; two 16-bit words may represent a 32-bit integer or floating-point value with a vendor-defined ordering. Read a known reference value to validate decoding before exposing it to operating decisions.

A TCP-to-RTU gateway translates a network transaction into a serial request. The TCP session can remain healthy while unit addressing, baud/parity, serial timing or a downstream device fails. Transaction identifiers help match TCP requests and responses; the unit identifier can select a downstream target according to the gateway design. Timeouts and retries must be bounded so an unavailable serial device does not create a polling storm.

Classic Modbus deployments may lack cryptographic authentication or fine-grained authorization. Use supported security features and boundary controls appropriate to the product, and strictly separate read monitoring from write authority. A syntactically correct write to the wrong register can change a set point or command equipment.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic map: register document 40001 means protocol offset 0 for this device only. Temperature raw 16-bit signed value=250, scale 0.1°C. Client displays 250°C. Gateway unit ID 7 maps to RTU device 7; request uses unit ID 8. TCP connection works. Write register 10 controls an isolated test pump command.

**Reasoning:** The temperature should be 25.0°C under the supplied map. The unit-ID mismatch selects another downstream destination even though TCP is healthy. Correct the documented address/identity mapping and test reads before any write. The pump command requires explicit laboratory authority and physical consequence review.

#### Guided practice

Provide a read-only acceptance test for scaling, signed ness, unit ID and serial loss.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Use known positive and negative reference values, confirm request address and unit ID, compare decoded engineering units with the reference, then remove the isolated serial target and verify bounded timeout, quality and freshness behavior. Do not write the pump command during this read-only test.

#### Independent task

Environment: emulator

Engineer Modbus point decoding and gateway delivery with bounded retries and separate command authority.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Address, unit, type and scale match the device map.
- Transport and application errors are distinguished.
- Read-only tests cannot issue control writes.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0141 · single · calculation**

What is the correct temperature?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic map: register document 40001 means protocol offset 0 for this device only. Temperature raw 16-bit signed value=250, scale 0.1°C. Client displays 250°C. Gateway unit ID 7 maps to RTU device 7; request uses unit ID 8. TCP connection works. Write register 10 controls an isolated test pump command.

1. 25.0°C
2. 250°C
3. 2.5°C

**Correct option(s):** 1

- Option 1: Correct. 250 multiplied by 0.1 equals 25.
- Option 2: Incorrect. That omits scaling.
- Option 3: Incorrect. That applies an extra factor of ten.

**NETWORK-ENGINEERING-Q0142 · single · implementation**

What does offset 0 mean here?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic map: register document 40001 means protocol offset 0 for this device only. Temperature raw 16-bit signed value=250, scale 0.1°C. Client displays 250°C. Gateway unit ID 7 maps to RTU device 7; request uses unit ID 8. TCP connection works. Write register 10 controls an isolated test pump command.

1. A write command automatically
2. Every vendor's first register universally
3. The supplied map's 40001 entry

**Correct option(s):** 3

- Option 1: Incorrect. Address and function differ.
- Option 2: Incorrect. Conventions must be checked.
- Option 3: Correct. The convention is device specific.

**NETWORK-ENGINEERING-Q0143 · single · diagnosis**

Why can TCP work while the read fails?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic map: register document 40001 means protocol offset 0 for this device only. Temperature raw 16-bit signed value=250, scale 0.1°C. Client displays 250°C. Gateway unit ID 7 maps to RTU device 7; request uses unit ID 8. TCP connection works. Write register 10 controls an isolated test pump command.

1. The scale value changes TCP routing
2. The unit ID selects the wrong downstream device
3. TCP success proves all RTU devices respond

**Correct option(s):** 2

- Option 1: Incorrect. Scaling is application interpretation.
- Option 2: Correct. Gateway application mapping is separate.
- Option 3: Incorrect. It does not.

**NETWORK-ENGINEERING-Q0144 · single · implementation**

What determines 32-bit word order?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic map: register document 40001 means protocol offset 0 for this device only. Temperature raw 16-bit signed value=250, scale 0.1°C. Client displays 250°C. Gateway unit ID 7 maps to RTU device 7; request uses unit ID 8. TCP connection works. Write register 10 controls an isolated test pump command.

1. The device's data map
2. Only the TCP source port
3. Only the IP address

**Correct option(s):** 1

- Option 1: Correct. Do not assume one universal order.
- Option 2: Incorrect. That is transport state.
- Option 3: Incorrect. It does not define encoding.

**NETWORK-ENGINEERING-Q0145 · single · diagnosis**

Why test a negative reference value?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic map: register document 40001 means protocol offset 0 for this device only. Temperature raw 16-bit signed value=250, scale 0.1°C. Client displays 250°C. Gateway unit ID 7 maps to RTU device 7; request uses unit ID 8. TCP connection works. Write register 10 controls an isolated test pump command.

1. To force all registers below zero
2. To replace unit-ID checks
3. To verifies ign ed interpretation

**Correct option(s):** 3

- Option 1: Incorrect. The testis controlled.
- Option 2: Incorrect. Identity remains separate.
- Option 3: Correct. Unsigned decoding can misrepresent it.

**NETWORK-ENGINEERING-Q0146 · single · implementation**

Which field correlates Modbus TCP transactions?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic map: register document 40001 means protocol offset 0 for this device only. Temperature raw 16-bit signed value=250, scale 0.1°C. Client displays 250°C. Gateway unit ID 7 maps to RTU device 7; request uses unit ID 8. TCP connection works. Write register 10 controls an isolated test pump command.

1. Transaction identifier
2. Only the engineering unit
3. Only the display label

**Correct option(s):** 1

- Option 1: Correct. It helps match requests and responses.
- Option 2: Incorrect. That is semantic metadata.
- Option 3: Incorrect. It does not identify the transaction.

**NETWORK-ENGINEERING-Q0147 · single · implementation**

What should serial loss produce?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic map: register document 40001 means protocol offset 0 for this device only. Temperature raw 16-bit signed value=250, scale 0.1°C. Client displays 250°C. Gateway unit ID 7 maps to RTU device 7; request uses unit ID 8. TCP connection works. Write register 10 controls an isolated test pump command.

1. Infinite retry at maximum rate
2. Bounded timeout and explicit bad/stale quality
3. A fabricated normal value

**Correct option(s):** 2

- Option 1: Incorrect. That can overload the gateway.
- Option 2: Correct. Do not present old data as current.
- Option 3: Incorrect. That hides failure.

**NETWORK-ENGINEERING-Q0148 · single · diagnosis**

Why separate write authority?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic map: register document 40001 means protocol offset 0 for this device only. Temperature raw 16-bit signed value=250, scale 0.1°C. Client displays 250°C. Gateway unit ID 7 maps to RTU device 7; request uses unit ID 8. TCP connection works. Write register 10 controls an isolated test pump command.

1. Every gateway blocks writes by default
2. A valid write can command physical equipment
3. Reads and writes always have identical impact

**Correct option(s):** 2

- Option 1: Incorrect. That must be verified.
- Option 2: Correct. Protocol correctness is not authorization.
- Option 3: Incorrect. They do not.

**NETWORK-ENGINEERING-Q0149 · single · implementation**

What does a valid Modbus response not prove?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic map: register document 40001 means protocol offset 0 for this device only. Temperature raw 16-bit signed value=250, scale 0.1°C. Client displays 250°C. Gateway unit ID 7 maps to RTU device 7; request uses unit ID 8. TCP connection works. Write register 10 controls an isolated test pump command.

1. Some downstream processing occurred
2. Correct physical meaning
3. A protocol response was received

**Correct option(s):** 2

- Option 1: Incorrect. That can be inferred within scope.
- Option 2: Correct. Scaling, mapping and sensor correctness remain.
- Option 3: Incorrect. That is observed.

**NETWORK-ENGINEERING-Q0150 · single · implementation**

What closes the point commissioning task?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic map: register document 40001 means protocol offset 0 for this device only. Temperature raw 16-bit signed value=250, scale 0.1°C. Client displays 250°C. Gateway unit ID 7 maps to RTU device 7; request uses unit ID 8. TCP connection works. Write register 10 controls an isolated test pump command.

1. Known-value, mapping, quality and failure evidence
2. Only no exception code
3. Only an open TCP socket

**Correct option(s):** 1

- Option 1: Correct. All semantic dependencies matter.
- Option 2: Incorrect. A successful response can still be mis decoded.
- Option 3: Incorrect. That is transport only.

#### Recall

**What is the correct temperature?**

25.0°C 250 multiplied by 0.1 equals 25.

**Why test a negative reference value?**

To verifies ign ed interpretation Unsigned decoding can misrepresent it.

**What does a valid Modbus response not prove?**

Correct physical meaning Scaling, mapping and sensor correctness remain.

#### References

- [Modbus application specification](https://www.modbus.org/file/secure/modbusprotocolspecification.pdf)

## NETWORK-ENGINEERING-M16 — OPC UA sessions, trust, subscriptions and data quality

### NETWORK-ENGINEERING-L16 — OPC UA sessions, trust, subscriptions and data quality

Estimated study time: 150 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L15

OPC UA combines an information model, service interactions and security mechanisms. A node identifier locates an item within the server's namespace model; a display name is not a stable universal identity. Namespace indexes can change between deployments, so clients should resolve the intended namespace URI and supported identifier mapping rather than hard-code an index without version control.

Secure-channel establishment, session authentication and application authorization are distinct. Trusting a server certificate does not authorize every node operation. Select supported security policies and message protection modes, validate certificates and application identity, and test the permissions of the actual service account. A monitoring integration should not inherit engineering write privileges.

Subscriptions and monitored items have publishing, sampling, queue and lifetime behavior. A connected session can still deliver stale or delayed values if sampling is too slow, queues overflow or the client stops processing notifications. OPC UA values can include status and source/server timestamps; preserve them through the historian or dashboard. Discarding quality while retaining the number creates false confidence.

Commission known values, bad quality, subscription interruption, reconnect, certificate rollover and denied writes. Reconnection should restore the intended monitored items without silently duplicating subscriptions or losing the interval during which data was unavailable.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA — not captured from equipment.
OPC UA: namespace URI urn:plant:epms moved from index 2 to 3 after upgrade. Client hard-codes ns=2;s=Meter 1.Power. Session connects but selects the wrong or absent node. Another value has Bad status and an old source timestamp; the dashboard stores only its number. Monitoring can write command nodes.

**Reasoning:** The client must resolve the intended namespace, not assume index 2 survives. A connected session does not prove correct node selection. Preserve status and source time, reject invalid data for operational decisions according to policy, and remove unnecessary write permission from the monitoring account.

#### Guided practice

Design a reconnect test that detects lost samples and duplicate subscriptions.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Record subscription and monitored-item identities, source sequence/timestamps and quality before interruption. Disconnect and restore the client, verify the intended item set exactly once, identify the gap, and test current values and denied writes. Do not fabricate samples forthe missing interval.

#### Independent task

Environment: emulator

Integrate OPCUA securely while preserving semantic identity, quality, freshness and subscription recovery.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Namespace resolution survives the defined upgrade.
- Quality and timestamps remain visible.
- Read-only service authority is enforced.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0151 · single · diagnosis**

Why can a connected session read the wrong node?

SYNTHETIC TEACHING DATA — not captured from equipment.
OPC UA: namespace URI urn:plant:epms moved from index 2 to 3 after upgrade. Client hard-codes ns=2;s=Meter 1.Power. Session connects but selects the wrong or absent node. Another value has Bad status and an old source timestamp; the dashboard stores only its number. Monitoring can write command nodes.

1. TLS necessarily failed
2. Display names are universal identifiers
3. The namespace index changed

**Correct option(s):** 3

- Option 1: Incorrect. The session connected.
- Option 2: Incorrect. They are not.
- Option 3: Correct. Session health does not validate identity mapping.

**NETWORK-ENGINEERING-Q0152 · single · implementation**

What should identify the namespace robustly?

SYNTHETIC TEACHING DATA — not captured from equipment.
OPC UA: namespace URI urn:plant:epms moved from index 2 to 3 after upgrade. Client hard-codes ns=2;s=Meter 1.Power. Session connects but selects the wrong or absent node. Another value has Bad status and an old source timestamp; the dashboard stores only its number. Monitoring can write command nodes.

1. Only the old numeric index
2. Only the dashboard label
3. Its URI with reviewed identifier mapping

**Correct option(s):** 3

- Option 1: Incorrect. That is the stale assumption.
- Option 2: Incorrect. It may not map uniquely.
- Option 3: Correct. Indexes can be deployment dependent.

**NETWORK-ENGINEERING-Q0153 · single · implementation**

What does Bad status require?

SYNTHETIC TEACHING DATA — not captured from equipment.
OPC UA: namespace URI urn:plant:epms moved from index 2 to 3 after upgrade. Client hard-codes ns=2;s=Meter 1.Power. Session connects but selects the wrong or absent node. Another value has Bad status and an old source timestamp; the dashboard stores only its number. Monitoring can write command nodes.

1. Preserve and handle invalid quality explicitly
2. Treat the number as healthy
3. Delete all historical values

**Correct option(s):** 1

- Option 1: Correct. A number alone is misleading.
- Option 2: Incorrect. Status contradicts that.
- Option 3: Incorrect. The record can remain with quality metadata.

**NETWORK-ENGINEERING-Q0154 · single · diagnosis**

Why retain source timestamps?

SYNTHETIC TEACHING DATA — not captured from equipment.
OPC UA: namespace URI urn:plant:epms moved from index 2 to 3 after upgrade. Client hard-codes ns=2;s=Meter 1.Power. Session connects but selects the wrong or absent node. Another value has Bad status and an old source timestamp; the dashboard stores only its number. Monitoring can write command nodes.

1. They authorize writes
2. They indicate when the source produced data
3. They replace all status codes

**Correct option(s):** 2

- Option 1: Incorrect. Time does not grant authority.
- Option 2: Correct. Receipt time alone can hide delay.
- Option 3: Incorrect. Quality remains separate.

**NETWORK-ENGINEERING-Q0155 · single · implementation**

Which privilege is excessive here?

SYNTHETIC TEACHING DATA — not captured from equipment.
OPC UA: namespace URI urn:plant:epms moved from index 2 to 3 after upgrade. Client hard-codes ns=2;s=Meter 1.Power. Session connects but selects the wrong or absent node. Another value has Bad status and an old source timestamp; the dashboard stores only its number. Monitoring can write command nodes.

1. Read access to assigned measurements
2. Monitoring account write access to commands
3. Access to quality metadata

**Correct option(s):** 2

- Option 1: Incorrect. That is needed.
- Option 2: Correct. Its task requires observation.
- Option 3: Incorrect. That supports interpretation.

**NETWORK-ENGINEERING-Q0156 · single · implementation**

What can subscription queues affect?

SYNTHETIC TEACHING DATA — not captured from equipment.
OPC UA: namespace URI urn:plant:epms moved from index 2 to 3 after upgrade. Client hard-codes ns=2;s=Meter 1.Power. Session connects but selects the wrong or absent node. Another value has Bad status and an old source timestamp; the dashboard stores only its number. Monitoring can write command nodes.

1. The certificate's issuer name
2. The server's physical sensor range automatically
3. Loss or delay of notifications

**Correct option(s):** 3

- Option 1: Incorrect. Queue state is unrelated.
- Option 2: Incorrect. That is another layer.
- Option 3: Correct. Finite queues and client processing matter.

**NETWORK-ENGINEERING-Q0157 · single · implementation**

What should are connect test detect?

SYNTHETIC TEACHING DATA — not captured from equipment.
OPC UA: namespace URI urn:plant:epms moved from index 2 to 3 after upgrade. Client hard-codes ns=2;s=Meter 1.Power. Session connects but selects the wrong or absent node. Another value has Bad status and an old source timestamp; the dashboard stores only its number. Monitoring can write command nodes.

1. Only a GUI login
2. Missing intervals and duplicate monitored items
3. Only socket establishment

**Correct option(s):** 2

- Option 1: Incorrect. It does not validate subscriptions.
- Option 2: Correct. Recovery can lose or duplicate state.
- Option 3: Incorrect. That is earlier in the chain.

**NETWORK-ENGINEERING-Q0158 · single · implementation**

What separates secure channel from authorization?

SYNTHETIC TEACHING DATA — not captured from equipment.
OPC UA: namespace URI urn:plant:epms moved from index 2 to 3 after upgrade. Client hard-codes ns=2;s=Meter 1.Power. Session connects but selects the wrong or absent node. Another value has Bad status and an old source timestamp; the dashboard stores only its number. Monitoring can write command nodes.

1. Authorization only sets sampling rate
2. They are always identical
3. Protected communication versus permitted operations

**Correct option(s):** 3

- Option 1: Incorrect. It controls access.
- Option 2: Incorrect. They have different roles.
- Option 3: Correct. Both are required.

**NETWORK-ENGINEERING-Q0159 · single · diagnosis**

Why not fabricate values during the gap?

SYNTHETIC TEACHING DATA — not captured from equipment.
OPC UA: namespace URI urn:plant:epms moved from index 2 to 3 after upgrade. Client hard-codes ns=2;s=Meter 1.Power. Session connects but selects the wrong or absent node. Another value has Bad status and an old source timestamp; the dashboard stores only its number. Monitoring can write command nodes.

1. Missing data is unknown
2. The last value always remains physically true
3. A continuous chart proves correctness

**Correct option(s):** 1

- Option 1: Correct. Interpolation must be explicitly modeled, not disguised as measurement.
- Option 2: Incorrect. Processes can change.
- Option 3: Incorrect. It can hide loss.

**NETWORK-ENGINEERING-Q0160 · single · implementation**

What closes the UA integration task?

SYNTHETIC TEACHING DATA — not captured from equipment.
OPC UA: namespace URI urn:plant:epms moved from index 2 to 3 after upgrade. Client hard-codes ns=2;s=Meter 1.Power. Session connects but selects the wrong or absent node. Another value has Bad status and an old source timestamp; the dashboard stores only its number. Monitoring can write command nodes.

1. Correct nodes, quality, permissions and recovery evidence
2. Only a trusted certificate
3. Only a numeric value

**Correct option(s):** 1

- Option 1: Correct. Connection alone is insufficient.
- Option 2: Incorrect. Semantic and authorization checks remain.
- Option 3: Incorrect. Its identity and quality maybe wrong.

#### Recall

**Why can a connected session read the wrong node?**

The namespace index changed Session health does not validate identity mapping.

**Which privilege is excessive here?**

Monitoring account write access to commands Its task requires observation.

**Why not fabricate values during the gap?**

Missing data is unknown Interpolation must be explicitly modeled, not disguised as measurement.

#### References

- [OPC Foundation specifications](https://reference.opcfoundation.org/)

## NETWORK-ENGINEERING-M17 — MQTT topic authority, retained state and delivery semantics

### NETWORK-ENGINEERING-L17 — MQTT topic authority, retained state and delivery semantics

Estimated study time: 150 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L16

MQTT de couples publishers and subscribers through a broker, but application meaning remains the engineer's responsibility. Topic names form a routing namespace; authorization must constrain who may publish and subscribe to each scope. A wildcard subscription can expose more data than intended, and an overly broad publish permission can let one device impersonate another process stream.

Quality-of-service levels describe protocol delivery behavior within their defined scope. They do not prove that a physical action occurred exactly once, that a database committed it once or that a downstream bridge preserved the same semantics. Applications need message identity, state/version rules and idempotent handling where duplicates or reconnects are possible. A command should include enough context to reject stale or unauthorized action.

Retained messages provide the last retained value to new subscribers. They are useful for state discovery but dangerous if treated as a fresh event without timestamp and validity checks. A retained command can be replayed to a newly connected consumer unless the application design prevents it. Session persistence, expiry and last-will behavior should be chosen for the operating requirement, not copied blindly.

Test broker loss, client reconnect, duplicate delivery, stale retained state, certificate renewal and denied topics. Observe both message transport and the application state transition. A broker acknowledgement alone cannot establish that a pump, breaker or database reached the requested state.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA — not captured from equipment.
MQTT: plant/pump1/cmd retains {"run":true,"timestamp":"old"}. A new consumer executes it without an age check. Sensor 2 may publish to plant/+/cmd. QoS 1 duplicates a message after reconnect; the application increments a setpoint on each receipt.

**Reasoning:** The retained command is stale state being treated as a new authorized event. Sensor 2 has command authority outside its monitoring role. QoS 1 permits at-least-once delivery, so increment-on-receipt is not safe without application de duplication or state-setting semantics. Correct all three independently.

#### Guided practice

Design an idempotent command envelope and negative topic tests for the isolated pump model.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Use an approved actor, explicit target, command ID, desired state/version, creation/expiry time and authorization context. Reject expired or duplicate commands according to policy. Test denied publishing/subscribing outside scope and verify the actual modeled state, not merely broker ACK.

#### Independent task

Environment: emulator

Engineer MQTT message and command semantics with scoped authority, staleness handling and reconnect correctness.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Topic permissions enforce publisher/subscriber scope.
- Duplicates and retained stale commands cannot repeat unsafe action.
- Application state is verified separately from broker delivery.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0161 · single · diagnosis**

Why is the retained run command dangerous?

SYNTHETIC TEACHING DATA — not captured from equipment.
MQTT: plant/pump1/cmd retains {"run":true,"timestamp":"old"}. A new consumer executes it without an age check. Sensor 2 may publish to plant/+/cmd. QoS 1 duplicates a message after reconnect; the application increments a setpoint on each receipt.

1. Retained messages are always invalid
2. A new consumer treat sold state as a fresh action
3. TCP necessarily duplicates every packet

**Correct option(s):** 2

- Option 1: Incorrect. They can be useful for state.
- Option 2: Correct. Age and command semantics are missing.
- Option 3: Incorrect. The application issue is broader.

**NETWORK-ENGINEERING-Q0162 · single · implementation**

What does QoS 1 permit?

SYNTHETIC TEACHING DATA — not captured from equipment.
MQTT: plant/pump1/cmd retains {"run":true,"timestamp":"old"}. A new consumer executes it without an age check. Sensor 2 may publish to plant/+/cmd. QoS 1 duplicates a message after reconnect; the application increments a setpoint on each receipt.

1. No retransmission ever
2. Exactly-once physical action
3. At-least-once delivery including duplicates

**Correct option(s):** 3

- Option 1: Incorrect. QoS 1 can re transmit.
- Option 2: Incorrect. Protocol delivery does not guarantee that.
- Option 3: Correct. The consumer needs correct handling.

**NETWORK-ENGINEERING-Q0163 · single · implementation**

Which permission is excessive for Sensor 2?

SYNTHETIC TEACHING DATA — not captured from equipment.
MQTT: plant/pump1/cmd retains {"run":true,"timestamp":"old"}. A new consumer executes it without an age check. Sensor 2 may publish to plant/+/cmd. QoS 1 duplicates a message after reconnect; the application increments a setpoint on each receipt.

1. Publishing its approved measurement
2. Publishing to command topics
3. Reading its own connection status

**Correct option(s):** 2

- Option 1: Incorrect. That can be appropriate.
- Option 2: Correct. Monitoring does not grant control authority.
- Option 3: Incorrect. That is not the supplied risk.

**NETWORK-ENGINEERING-Q0164 · single · implementation**

What is a safer repeated command semantic?

SYNTHETIC TEACHING DATA — not captured from equipment.
MQTT: plant/pump1/cmd retains {"run":true,"timestamp":"old"}. A new consumer executes it without an age check. Sensor 2 may publish to plant/+/cmd. QoS 1 duplicates a message after reconnect; the application increments a setpoint on each receipt.

1. Ignore all command IDs
2. Set desired state with identity/version checks
3. Increment one very receipt

**Correct option(s):** 2

- Option 1: Incorrect. That removes de duplication context.
- Option 2: Correct. Repeated application can be idempotent.
- Option 3: Incorrect. Duplicates repeat the effect.

**NETWORK-ENGINEERING-Q0165 · single · implementation**

What does a broker ACK not establish?

SYNTHETIC TEACHING DATA — not captured from equipment.
MQTT: plant/pump1/cmd retains {"run":true,"timestamp":"old"}. A new consumer executes it without an age check. Sensor 2 may publish to plant/+/cmd. QoS 1 duplicates a message after reconnect; the application increments a setpoint on each receipt.

1. The protocol transaction progressed
2. Some broker processing occurred
3. The physical/application state reached the target

**Correct option(s):** 3

- Option 1: Incorrect. That is its role.
- Option 2: Incorrect. It can indicate that.
- Option 3: Correct. Acknowledgement has a transport scope.

**NETWORK-ENGINEERING-Q0166 · single · diagnosis**

Why include command expiry?

SYNTHETIC TEACHING DATA — not captured from equipment.
MQTT: plant/pump1/cmd retains {"run":true,"timestamp":"old"}. A new consumer executes it without an age check. Sensor 2 may publish to plant/+/cmd. QoS 1 duplicates a message after reconnect; the application increments a setpoint on each receipt.

1. To replace authentication
2. To rejects tale action
3. To raise network throughput automatically

**Correct option(s):** 2

- Option 1: Incorrect. Identity remains necessary.
- Option 2: Correct. Delayed messages can outlive their authority.
- Option 3: Incorrect. It is a semantic control.

**NETWORK-ENGINEERING-Q0167 · single · implementation**

What should wildcard policy review check?

SYNTHETIC TEACHING DATA — not captured from equipment.
MQTT: plant/pump1/cmd retains {"run":true,"timestamp":"old"}. A new consumer executes it without an age check. Sensor 2 may publish to plant/+/cmd. QoS 1 duplicates a message after reconnect; the application increments a setpoint on each receipt.

1. Only the broker's CPU model
2. Expanded publish and subscribe scope
3. Only the length of topic strings

**Correct option(s):** 2

- Option 1: Incorrect. It does not define permissions.
- Option 2: Correct. Wildcard s can cross boundaries.
- Option 3: Incorrect. Length does not establish authority.

**NETWORK-ENGINEERING-Q0168 · single · implementation**

Which reconnect test is necessary?

SYNTHETIC TEACHING DATA — not captured from equipment.
MQTT: plant/pump1/cmd retains {"run":true,"timestamp":"old"}. A new consumer executes it without an age check. Sensor 2 may publish to plant/+/cmd. QoS 1 duplicates a message after reconnect; the application increments a setpoint on each receipt.

1. Only a DNS lookup
2. Duplicate and retained-message handling
3. Only TLS establishment

**Correct option(s):** 2

- Option 1: Incorrect. That precedes messaging.
- Option 2: Correct. A fresh connection can change delivery state.
- Option 3: Incorrect. Application semantics remain untested.

**NETWORK-ENGINEERING-Q0169 · single · implementation**

What should the consumer verify after a command?

SYNTHETIC TEACHING DATA — not captured from equipment.
MQTT: plant/pump1/cmd retains {"run":true,"timestamp":"old"}. A new consumer executes it without an age check. Sensor 2 may publish to plant/+/cmd. QoS 1 duplicates a message after reconnect; the application increments a setpoint on each receipt.

1. Only the sender's packet count
2. Only the topic name
3. Observed target state and result

**Correct option(s):** 3

- Option 1: Incorrect. It omits the outcome.
- Option 2: Incorrect. That does not prove action.
- Option 3: Correct. Receipt alone is incomplete.

**NETWORK-ENGINEERING-Q0170 · single · implementation**

What closes the MQTT commissioning task?

SYNTHETIC TEACHING DATA — not captured from equipment.
MQTT: plant/pump1/cmd retains {"run":true,"timestamp":"old"}. A new consumer executes it without an age check. Sensor 2 may publish to plant/+/cmd. QoS 1 duplicates a message after reconnect; the application increments a setpoint on each receipt.

1. Only maximum Qo S selected
2. Only an up broker
3. Authority, delivery, staleness and application-state tests

**Correct option(s):** 3

- Option 1: Incorrect. QoS does not solve all semantics.
- Option 2: Incorrect. That isone dependency.
- Option 3: Correct. All four constraints matter.

#### Recall

**Why is the retained run command dangerous?**

A new consumer treat sold state as a fresh action Age and command semantics are missing.

**What does a broker ACK not establish?**

The physical/application state reached the target Acknowledgement has a transport scope.

**What should the consumer verify after a command?**

Observed target state and result Receipt alone is incomplete.

#### References

- [OASIS MQTT 5 specification](https://docs.oasis-open.org/mqtt/mqtt/v5.0/mqtt-v5.0.html)

## NETWORK-ENGINEERING-M18 — Industrial redundancy, IEC 61850 traffic and protocol-specific recovery

### NETWORK-ENGINEERING-L18 — Industrial redundancy, IEC 61850 traffic and protocol-specific recovery

Estimated study time: 150 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L17

Industrial resilience mechanisms are not interchangeable labels for a redundant ring. A routed or spanning-tree network converges after detecting a change; specific industrial mechanisms may use prearranged alternate paths or duplicate delivery to meet a tighter requirement. PRP sends copies over two separate LANs in its intended architecture, while HSR uses a ring-oriented duplicate-forwarding approach. Their supported node roles, duplicate handling and failure assumptions require their own verification. REP is a different vendor mechanism with its own segment and topology rules.

IEC 61850 services have different communication patterns. MMS supports client/server interactions, while GOOSE carries event/state messages with defined retransmission and timing behavior. A successful MMS read does not establish that GOOSE reaches the intended subscribers within its deadline. VLAN, priority, multicast filtering, application identifiers and engineering configuration must agree. Treat protection/control semantics and network transport as separate but connected requirements.

Redundant networks must remain independent where the mechanism assumes independence. Bridging both PRP LANs together can destroy the intended architecture and create loops or duplicate behavior. During commissioning, inject only approved isolated faults and observe application sequence/state, duplicate handling and deadline compliance. Packet delivery alone cannot prove that a receiving controller acted on the correct event version.

Keep physical safety and protection authority with the qualified equipment owner. This course's synthetic studies explain network behavior; live switching or protection tests need the site's engineering procedure and authorization.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic lab: GOOSE deadline 4 ms. Normal delivery 1 ms; ring recovery interrupts 6 ms. MMS reads recover after 50 ms and dashboard reports healthy. Two PRP LANs share a single switch power supply and an accidental cross-link. Subscriber receives packets but has wrong application identifier.

**Reasoning:** The 6 ms interruption fails the 4 ms GOOSE requirement despite eventual MMS recovery. Shared power and cross-linking undermine the intended dual-LAN architecture. Packet reception with the wrong application identifier does not establish subscribed function delivery. Test each independent constraint.

#### Guided practice

Design an isolated redundancy test that proves both deadline and correct event interpretation.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Use a safe simulated publisher/subscriber and known event sequence. Withdraw each intended path, measure message gaps and duplicates, verify subscriber state and application ID, and check that the physical LAN separation matches the design. Record actual fidelity and never claim protection-system acceptance from a generic ping.

#### Independent task

Environment: emulator

Validate industrial communication resilience using protocol-specific timing, identity and application evidence.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Each protocol meets its own deadline.
- Redundancy assumptions are physically verified.
- Subscriber state matches intended events.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0171 · single · design**

Does 6 ms interruption meet the GOOSE requirement?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: GOOSE deadline 4 ms. Normal delivery 1 ms; ring recovery interrupts 6 ms. MMS reads recover after 50 ms and dashboard reports healthy. Two PRP LANs share a single switch power supply and an accidental cross-link. Subscriber receives packets but has wrong application identifier.

1. Yes, all rings are seamless
2. No, the limit is 4 ms
3. Yes, MMS recovers in 50 ms

**Correct option(s):** 2

- Option 1: Incorrect. Mechanisms differ.
- Option 2: Correct. Eventual recovery is insufficient.
- Option 3: Incorrect. That is another service.

**NETWORK-ENGINEERING-Q0172 · single · implementation**

What does successful MMS not prove?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: GOOSE deadline 4 ms. Normal delivery 1 ms; ring recovery interrupts 6 ms. MMS reads recover after 50 ms and dashboard reports healthy. Two PRP LANs share a single switch power supply and an accidental cross-link. Subscriber receives packets but has wrong application identifier.

1. That the dashboard received data
2. Some client/server communication
3. GOOSE deadline and membership correctness

**Correct option(s):** 3

- Option 1: Incorrect. The observation can show that.
- Option 2: Incorrect. It does support that.
- Option 3: Correct. Services have different behavior.

**NETWORK-ENGINEERING-Q0173 · single · diagnosis**

Why is the PRP cross-link problematic?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: GOOSE deadline 4 ms. Normal delivery 1 ms; ring recovery interrupts 6 ms. MMS reads recover after 50 ms and dashboard reports healthy. Two PRP LANs share a single switch power supply and an accidental cross-link. Subscriber receives packets but has wrong application identifier.

1. It only changes DNS
2. It violates intended LAN separation
3. It always doubles safety

**Correct option(s):** 2

- Option 1: Incorrect. The issue is physical/logical topology.
- Option 2: Correct. Duplicate-path assumptions can break.
- Option 3: Incorrect. Connectivity count is not independence.

**NETWORK-ENGINEERING-Q0174 · single · diagnosis**

What common cause remains?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: GOOSE deadline 4 ms. Normal delivery 1 ms; ring recovery interrupts 6 ms. MMS reads recover after 50 ms and dashboard reports healthy. Two PRP LANs share a single switch power supply and an accidental cross-link. Subscriber receives packets but has wrong application identifier.

1. Shared switch power
2. Different LAN names
3. Different packet sequence numbers

**Correct option(s):** 1

- Option 1: Correct. Both paths depend on it.
- Option 2: Incorrect. Names do not create common failure.
- Option 3: Incorrect. Those are not power dependencies.

**NETWORK-ENGINEERING-Q0175 · single · diagnosis**

Why can received GOOSE packets be unused?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: GOOSE deadline 4 ms. Normal delivery 1 ms; ring recovery interrupts 6 ms. MMS reads recover after 50 ms and dashboard reports healthy. Two PRP LANs share a single switch power supply and an accidental cross-link. Subscriber receives packets but has wrong application identifier.

1. MMS automatically rewrites every identifier
2. Application identifier does not match subscription
3. Ethernet arrival guarantees act ua tion

**Correct option(s):** 2

- Option 1: Incorrect. That is not established.
- Option 2: Correct. Transport delivery is not semantic delivery.
- Option 3: Incorrect. It does not.

**NETWORK-ENGINEERING-Q0176 · single · implementation**

What distinguishes PRP from HSR?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: GOOSE deadline 4 ms. Normal delivery 1 ms; ring recovery interrupts 6 ms. MMS reads recover after 50 ms and dashboard reports healthy. Two PRP LANs share a single switch power supply and an accidental cross-link. Subscriber receives packets but has wrong application identifier.

1. Dual-LAN versus ring-oriented architecture
2. They are just two names forthe same configuration
3. Both are ordinary TCP multipath

**Correct option(s):** 1

- Option 1: Correct. Their roles and assumptions differ.
- Option 2: Incorrect. They are not.
- Option 3: Incorrect. That misstates the mechanisms.

**NETWORK-ENGINEERING-Q0177 · single · implementation**

What should a failure test measure?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: GOOSE deadline 4 ms. Normal delivery 1 ms; ring recovery interrupts 6 ms. MMS reads recover after 50 ms and dashboard reports healthy. Two PRP LANs share a single switch power supply and an accidental cross-link. Subscriber receives packets but has wrong application identifier.

1. Only cumulative uptime
2. Message gaps, duplicates and subscriber state
3. Only final port LEDs

**Correct option(s):** 2

- Option 1: Incorrect. It omits the event.
- Option 2: Correct. Ping misses application semantics.
- Option 3: Incorrect. They omit transients.

**NETWORK-ENGINEERING-Q0178 · single · diagnosis**

Why separate REP from PRP claims?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: GOOSE deadline 4 ms. Normal delivery 1 ms; ring recovery interrupts 6 ms. MMS reads recover after 50 ms and dashboard reports healthy. Two PRP LANs share a single switch power supply and an accidental cross-link. Subscriber receives packets but has wrong application identifier.

1. Every ring protocol is identical
2. Protocol names never affect design
3. They are different mechanisms with different rules

**Correct option(s):** 3

- Option 1: Incorrect. That is false.
- Option 2: Incorrect. Mechanisms determine rules.
- Option 3: Correct. One test cannot validate all.

**NETWORK-ENGINEERING-Q0179 · single · implementation**

What authority is needed for live protection tests?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: GOOSE deadline 4 ms. Normal delivery 1 ms; ring recovery interrupts 6 ms. MMS reads recover after 50 ms and dashboard reports healthy. Two PRP LANs share a single switch power supply and an accidental cross-link. Subscriber receives packets but has wrong application identifier.

1. Only completing this quiz
2. Only network administrator login
3. The site's qualified owner and approved procedure

**Correct option(s):** 3

- Option 1: Incorrect. Knowledge is not authorization.
- Option 2: Incorrect. Access is not full operating authority.
- Option 3: Correct. The physical consequence matters.

**NETWORK-ENGINEERING-Q0180 · single · implementation**

What closes the controls network acceptance?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: GOOSE deadline 4 ms. Normal delivery 1 ms; ring recovery interrupts 6 ms. MMS reads recover after 50 ms and dashboard reports healthy. Two PRP LANs share a single switch power supply and an accidental cross-link. Subscriber receives packets but has wrong application identifier.

1. Only eventual ping recovery
2. Deadline, identity, function and failure evidence
3. Only a healthy MMS dashboard

**Correct option(s):** 2

- Option 1: Incorrect. That is transport only.
- Option 2: Correct. All are explicit requirements.
- Option 3: Incorrect. That omits the faster event service.

#### Recall

**Does 6 ms interruption meet the GOOSE requirement?**

No, the limit is 4 ms Eventual recovery is insufficient.

**Why can received GOOSE packets be unused?**

Application identifier does not match subscription Transport delivery is not semantic delivery.

**What authority is needed for live protection tests?**

The site's qualified owner and approved procedure The physical consequence matters.

#### References

- [IEC 61850 information](https://www.iec.ch/61850)
- [IEC 62439 standards information](https://webstore.iec.ch/)

## NETWORK-ENGINEERING-M19 — Network telemetry: SNMP, syslog and actionable service observation

### NETWORK-ENGINEERING-L19 — Network telemetry: SNMP, syslog and actionable service observation

Estimated study time: 150 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L18

Operational monitoring combines inventory, configuration, performance, events and application checks. SNMP polling can retrieve counters and state, while notifications report selected events; syslog carries event records with source, severity and time semantics. None is a complete source of truth alone. A device can be reachable while its application data is stale, and a trap can be lost while polling still works.

Use authenticated and protected management protocols supported by the equipment. Restrict monitoring identities to the needed objects and operations. SNMPv3 security levels and user configuration must match; merely choosing version 3 does not prove privacy and authentication are both enabled. Syslog transport and collector handling also determine delivery and trust properties. Preserve source identity and time quality so records can be correlated.

Counters need units, interval and reset awareness. A cumulative interface-octet counter becomes a rate only after a timed delta; counter wrap, reboot or poll gaps can invalidate naive subtraction. Alarm thresholds should represent the service consequence and include appropriate persistence, ownership and recovery conditions. Avoid a dashboard where missing data silently remains green.

Validate monitoring by controlled events: interface loss, denied login, configuration change, stale application value and collector outage. Confirm the device emitted the expected record, the transport delivered it, the collector parsed it and the operator received an actionable alert. A log existing on disk is not the same as a functioning response workflow.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA — not captured from equipment.
Operations: SNMPv3 uses authNoPriv while policy requires authPriv. Octet counter rises from 1,000,000 to 4,000,000 in 30 seconds. Syslog clock is 5 minutes slow. Collector rejects unknown formats, so interface failure produces no alert. Collector loss leaves the last healthy dashboard state unchanged.

**Reasoning:** The rate is 3,000,000 bytes/30 s=100,000 B/s or 800,000 bit/s, assuming no reset/wrap. Security mode fails the privacy requirement. Clock offset, parsing failure and stale-health display are separate observability defects. Test the whole event-to-response chain.

#### Guided practice

Create an operational test for interface failure that distinguishes emission, transport, parsing and notification.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Generate the approved lab event, record the local device event, observe transport arrival, verify parsed fields and timestamp, then confirm the assigned operator receives the correct alarm and clearance. Disconnect the collector and verify unknown/degraded status rather than healthy.

#### Independent task

Environment: emulator

Commission network monitoring asan end-to-end service with protected access, correct metrics and actionable alarms.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Telemetry security meets specified mode.
- Rates and timestamps preserve semantics.
- Missing data and failed alert stages are visible.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0181 · single · calculation**

What is the counter-derived bitrate?

SYNTHETIC TEACHING DATA — not captured from equipment.
Operations: SNMPv3 uses authNoPriv while policy requires authPriv. Octet counter rises from 1,000,000 to 4,000,000 in 30 seconds. Syslog clock is 5 minutes slow. Collector rejects unknown formats, so interface failure produces no alert. Collector loss leaves the last healthy dashboard state unchanged.

1. 100000 bit/s
2. 800000 bit/s
3. 24000000 bit/s

**Correct option(s):** 2

- Option 1: Incorrect. That omits byte-to-bit conversion.
- Option 2: Correct. Three million bytes over 30 seconds times 8.
- Option 3: Incorrect. That omits the 30-second interval.

**NETWORK-ENGINEERING-Q0182 · single · diagnosis**

Why does authNoPriv fail the policy?

SYNTHETIC TEACHING DATA — not captured from equipment.
Operations: SNMPv3 uses authNoPriv while policy requires authPriv. Octet counter rises from 1,000,000 to 4,000,000 in 30 seconds. Syslog clock is 5 minutes slow. Collector rejects unknown formats, so interface failure produces no alert. Collector loss leaves the last healthy dashboard state unchanged.

1. It means no authentication
2. It lacks required privacy
3. All SNMPv3 modes are identical

**Correct option(s):** 2

- Option 1: Incorrect. The name includes authentication.
- Option 2: Correct. Authentication alone is insufficient.
- Option 3: Incorrect. Security levels differ.

**NETWORK-ENGINEERING-Q0183 · single · implementation**

What does a 5-minute clock offset affect?

SYNTHETIC TEACHING DATA — not captured from equipment.
Operations: SNMPv3 uses authNoPriv while policy requires authPriv. Octet counter rises from 1,000,000 to 4,000,000 in 30 seconds. Syslog clock is 5 minutes slow. Collector rejects unknown formats, so interface failure produces no alert. Collector loss leaves the last healthy dashboard state unchanged.

1. Event correlation and ordering
2. The interface's physical speed
3. The counter'sun it automatically

**Correct option(s):** 1

- Option 1: Correct. Raw timestamps can mislead.
- Option 2: Incorrect. Clock metadata is separate.
- Option 3: Incorrect. Units remain octets here.

**NETWORK-ENGINEERING-Q0184 · single · diagnosis**

Why can emitted syslog fail to alert?

SYNTHETIC TEACHING DATA — not captured from equipment.
Operations: SNMPv3 uses authNoPriv while policy requires authPriv. Octet counter rises from 1,000,000 to 4,000,000 in 30 seconds. Syslog clock is 5 minutes slow. Collector rejects unknown formats, so interface failure produces no alert. Collector loss leaves the last healthy dashboard state unchanged.

1. SNMP polling replaces all alerts
2. Every emitted log is guaranteed actionable
3. Collector parsing drops the format

**Correct option(s):** 3

- Option 1: Incorrect. It serves different observation needs.
- Option 2: Incorrect. Delivery and processing can fail.
- Option 3: Correct. Emission is only one stage.

**NETWORK-ENGINEERING-Q0185 · single · implementation**

What should collector failure produce?

SYNTHETIC TEACHING DATA — not captured from equipment.
Operations: SNMPv3 uses authNoPriv while policy requires authPriv. Octet counter rises from 1,000,000 to 4,000,000 in 30 seconds. Syslog clock is 5 minutes slow. Collector rejects unknown formats, so interface failure produces no alert. Collector loss leaves the last healthy dashboard state unchanged.

1. An invented interface-down event
2. Unknown/degraded observation state
3. A perpetual green state

**Correct option(s):** 2

- Option 1: Incorrect. The actual device state is unknown.
- Option 2: Correct. Old health cannot remain current.
- Option 3: Incorrect. That hides missing evidence.

**NETWORK-ENGINEERING-Q0186 · single · calculation**

Which assumption underlies the calculated rate?

SYNTHETIC TEACHING DATA — not captured from equipment.
Operations: SNMPv3 uses authNoPriv while policy requires authPriv. Octet counter rises from 1,000,000 to 4,000,000 in 30 seconds. Syslog clock is 5 minutes slow. Collector rejects unknown formats, so interface failure produces no alert. Collector loss leaves the last healthy dashboard state unchanged.

1. No counter reset/wrap and correct interval
2. The interface is full duplex
3. The device has zero users

**Correct option(s):** 1

- Option 1: Correct. Otherwise the delta is invalid.
- Option 2: Incorrect. That alone is not the needed assumption.
- Option 3: Incorrect. Rate calculation does not require that.

**NETWORK-ENGINEERING-Q0187 · single · implementation**

What should monitoring credentials permit?

SYNTHETIC TEACHING DATA — not captured from equipment.
Operations: SNMPv3 uses authNoPriv while policy requires authPriv. Octet counter rises from 1,000,000 to 4,000,000 in 30 seconds. Syslog clock is 5 minutes slow. Collector rejects unknown formats, so interface failure produces no alert. Collector loss leaves the last healthy dashboard state unchanged.

1. Anonymous administration
2. Only required read/notification operations
3. Unrestricted configuration writes

**Correct option(s):** 2

- Option 1: Incorrect. That loses accountability.
- Option 2: Correct. Least authority limits impact.
- Option 3: Incorrect. Monitoring does not need them.

**NETWORK-ENGINEERING-Q0188 · single · implementation**

What makes an alarm actionable?

SYNTHETIC TEACHING DATA — not captured from equipment.
Operations: SNMPv3 uses authNoPriv while policy requires authPriv. Octet counter rises from 1,000,000 to 4,000,000 in 30 seconds. Syslog clock is 5 minutes slow. Collector rejects unknown formats, so interface failure produces no alert. Collector loss leaves the last healthy dashboard state unchanged.

1. Only high severity text
2. Only a larger log file
3. Condition, impact, owner and recovery criteria

**Correct option(s):** 3

- Option 1: Incorrect. Without context it may not guide action.
- Option 2: Incorrect. Size is not usefulness.
- Option 3: Correct. A red icon alone is insufficient.

**NETWORK-ENGINEERING-Q0189 · single · implementation**

Which test covers the whole pipeline?

SYNTHETIC TEACHING DATA — not captured from equipment.
Operations: SNMPv3 uses authNoPriv while policy requires authPriv. Octet counter rises from 1,000,000 to 4,000,000 in 30 seconds. Syslog clock is 5 minutes slow. Collector rejects unknown formats, so interface failure produces no alert. Collector loss leaves the last healthy dashboard state unchanged.

1. Device event through operator notification
2. Only pinging the device
3. Only checking the collector process

**Correct option(s):** 1

- Option 1: Correct. Each stage can fail.
- Option 2: Incorrect. That does not test event delivery.
- Option 3: Incorrect. The device or parser may fail.

**NETWORK-ENGINEERING-Q0190 · single · implementation**

What closes the monitoring task?

SYNTHETIC TEACHING DATA — not captured from equipment.
Operations: SNMPv3 uses authNoPriv while policy requires authPriv. Octet counter rises from 1,000,000 to 4,000,000 in 30 seconds. Syslog clock is 5 minutes slow. Collector rejects unknown formats, so interface failure produces no alert. Collector loss leaves the last healthy dashboard state unchanged.

1. Only a connected collector
2. Validated security, semantics, freshness and response behavior
3. Only a dashboard screenshot

**Correct option(s):** 2

- Option 1: Incorrect. Data can still be wrong.
- Option 2: Correct. Installation alone is incomplete.
- Option 3: Incorrect. It may hide stale values.

#### Recall

**What is the counter-derived bitrate?**

800000 bit/s Three million bytes over 30 seconds times 8.

**What should collector failure produce?**

Unknown/degraded observation state Old health cannot remain current.

**Which test covers the whole pipeline?**

Device event through operator notification Each stage can fail.

#### References

- [SNMP architecture](https://www.rfc-editor.org/rfc/rfc3411.html)
- [SNMPv3 USM](https://www.rfc-editor.org/rfc/rfc3414.html)
- [Syslog protocol](https://www.rfc-editor.org/rfc/rfc5424.html)

## NETWORK-ENGINEERING-M20 — Network automation, configuration drift and production change ownership

### NETWORK-ENGINEERING-L20 — Network automation, configuration drift and production change ownership

Estimated study time: 150 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L19

Production network automation begins with controlled intent and inventory. A device list must identify platform, version, role, management endpoint and ownership; an automation job should reject an unexpected target rather than treating every reachable device as eligible. Separate read-only discovery from proposed change and authorized execution. Store secrets outside source control and keep attributable service identities.

Validate syntax and meaning before deployment. A route policy can parse correctly while exporting the wrong prefixes, and a VLAN list can be well formed while omitting an essential controls segment. Build semantic invariants from the requirements, then compare intended and effective state. Drift detection should classify approved manual changes, unauthorized changes and incomplete prior automation rather than overwriting everything automatically.

Use staged rollout with fresh preconditions, bounded scope and service tests. A canary reduces initial exposure but does not prove every hardware variant or site. Concurrent writers need coordination. On partial failure, capture what actually changed and choose a reviewed forward recovery or rollback; do not mark the job successful merely because some tasks completed.

Operational ownership continues after deployment: backups, restoration drills, firmware support, spares, alert quality, incident diagnosis and measured improvement all belong to the system's lifecycle. An AI or MCP analysis tool may help interpret evidence, but it should not acquire execution authority merely because it can propose a plausible command.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA — not captured from equipment.
Automation: inventory expects NX-OS 10.x but the target is another platform. Proposed export 10.0.0.0/8 exceeds approved 10.40.0.0/16. A write token is readable by the analysis assistant. Deployment succeeds on 3 of 5 targets but reports complete success.

**Reasoning:** Reject the platform mismatch and overbroad export before execution. Isolate the write credential from the read-only assistant. The 3/5 outcome is partial application and requires explicit recovery plus service validation. Source-code correctness does not establish deployed state.

#### Guided practice

Write a pre flight and partial-failure decision table for this campaign.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Check target identity/version, approved scope, credentials and fresh state; validate export semantics and canary service; apply bounded batches; on partial failure stop other writers, capture actual state, protect service invariants and execute reviewed recovery. Report unresolved devices honestly.

#### Independent task

Environment: emulator

Operate a version-aware network change pipeline with semantic gates, scoped authority and tested recovery.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Unexpected targets and unsafe semantics are rejected.
- Partial state is reported accurately.
- Read-only analysis cannot execute production writes.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0191 · single · implementation**

What should happen on platform mismatch?

SYNTHETIC TEACHING DATA — not captured from equipment.
Automation: inventory expects NX-OS 10.x but the target is another platform. Proposed export 10.0.0.0/8 exceeds approved 10.40.0.0/16. A write token is readable by the analysis assistant. Deployment succeeds on 3 of 5 targets but reports complete success.

1. Apply the same syntax blindly
2. Reject or hold the target pending review
3. Rename the device to fit

**Correct option(s):** 2

- Option 1: Incorrect. That risks unsupported changes.
- Option 2: Correct. Templates depend on supported behavior.
- Option 3: Incorrect. Names do not change platforms.

**NETWORK-ENGINEERING-Q0192 · single · diagnosis**

Why is the export policy unsafe?

SYNTHETIC TEACHING DATA — not captured from equipment.
Automation: inventory expects NX-OS 10.x but the target is another platform. Proposed export 10.0.0.0/8 exceeds approved 10.40.0.0/16. A write token is readable by the analysis assistant. Deployment succeeds on 3 of 5 targets but reports complete success.

1. All aggregates are always forbidden
2. 10.0.0.0/8 exceeds approved 10.40.0.0/16
3. The policy cannot be parsed

**Correct option(s):** 2

- Option 1: Incorrect. The issue is this requirement.
- Option 2: Correct. Valid syntax can still violate scope.
- Option 3: Incorrect. No syntax error is given.

**NETWORK-ENGINEERING-Q0193 · single · implementation**

How should 3 of 5 deployment be reported?

SYNTHETIC TEACHING DATA — not captured from equipment.
Automation: inventory expects NX-OS 10.x but the target is another platform. Proposed export 10.0.0.0/8 exceeds approved 10.40.0.0/16. A write token is readable by the analysis assistant. Deployment succeeds on 3 of 5 targets but reports complete success.

1. Partially applied
2. Complete success
3. No change occurred

**Correct option(s):** 1

- Option 1: Correct. Two targets remain unresolved.
- Option 2: Incorrect. That hides failure.
- Option 3: Incorrect. Three targets did change.

**NETWORK-ENGINEERING-Q0194 · single · implementation**

What authority should the analysis assistant receive?

SYNTHETIC TEACHING DATA — not captured from equipment.
Automation: inventory expects NX-OS 10.x but the target is another platform. Proposed export 10.0.0.0/8 exceeds approved 10.40.0.0/16. A write token is readable by the analysis assistant. Deployment succeeds on 3 of 5 targets but reports complete success.

1. The pipeline write token automatically
2. Only the approved read scope
3. Every administrator password

**Correct option(s):** 2

- Option 1: Incorrect. That crosses the boundary.
- Option 2: Correct. Proposals are not execution authorization.
- Option 3: Incorrect. That is excessive authority.

**NETWORK-ENGINEERING-Q0195 · single · implementation**

What distinguishes semantic validation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Automation: inventory expects NX-OS 10.x but the target is another platform. Proposed export 10.0.0.0/8 exceeds approved 10.40.0.0/16. A write token is readable by the analysis assistant. Deployment succeeds on 3 of 5 targets but reports complete success.

1. It only checks indentation
2. It checks required behavior and scope
3. It eliminates live testing

**Correct option(s):** 2

- Option 1: Incorrect. That is syntax.
- Option 2: Correct. Parsing alone is insufficient.
- Option 3: Incorrect. Effective state can still differ.

**NETWORK-ENGINEERING-Q0196 · single · implementation**

What should drift reconciliation consider?

SYNTHETIC TEACHING DATA — not captured from equipment.
Automation: inventory expects NX-OS 10.x but the target is another platform. Proposed export 10.0.0.0/8 exceeds approved 10.40.0.0/16. A write token is readable by the analysis assistant. Deployment succeeds on 3 of 5 targets but reports complete success.

1. Only the old template
2. Only whether the device answers ping
3. Approval history and actual state

**Correct option(s):** 3

- Option 1: Incorrect. Intent may have changed.
- Option 2: Incorrect. Reachability is not authorization.
- Option 3: Correct. Blind overwrite can destroy valid changes.

**NETWORK-ENGINEERING-Q0197 · single · diagnosis**

Why coordinate writers?

SYNTHETIC TEACHING DATA — not captured from equipment.
Automation: inventory expects NX-OS 10.x but the target is another platform. Proposed export 10.0.0.0/8 exceeds approved 10.40.0.0/16. A write token is readable by the analysis assistant. Deployment succeeds on 3 of 5 targets but reports complete success.

1. Locks prove the policy is safe
2. Concurrent changes can invalidate plans
3. Only one person can ever administer networks

**Correct option(s):** 2

- Option 1: Incorrect. They prevent races, not bad intent.
- Option 2: Correct. Recovery needs controlled state.
- Option 3: Incorrect. Coordination need not mean that.

**NETWORK-ENGINEERING-Q0198 · single · implementation**

Which outcome proves restoration?

SYNTHETIC TEACHING DATA — not captured from equipment.
Automation: inventory expects NX-OS 10.x but the target is another platform. Proposed export 10.0.0.0/8 exceeds approved 10.40.0.0/16. A write token is readable by the analysis assistant. Deployment succeeds on 3 of 5 targets but reports complete success.

1. Effective configuration and service tests
2. Only a completed download
3. Only an unchanged filename

**Correct option(s):** 1

- Option 1: Correct. A backup file alone is insufficient.
- Option 2: Incorrect. That is staging.
- Option 3: Incorrect. It does not show restored behavior.

**NETWORK-ENGINEERING-Q0199 · single · implementation**

What remains after initial deployment?

SYNTHETIC TEACHING DATA — not captured from equipment.
Automation: inventory expects NX-OS 10.x but the target is another platform. Proposed export 10.0.0.0/8 exceeds approved 10.40.0.0/16. A write token is readable by the analysis assistant. Deployment succeeds on 3 of 5 targets but reports complete success.

1. Only certificate collection
2. No further responsibility
3. Operations, maintenance, diagnosis and recovery

**Correct option(s):** 3

- Option 1: Incorrect. Credentials do not operate the system.
- Option 2: Incorrect. That contradicts the programme.
- Option 3: Correct. Lifecycle ownership continues.

**NETWORK-ENGINEERING-Q0200 · single · implementation**

What closes the campaign?

SYNTHETIC TEACHING DATA — not captured from equipment.
Automation: inventory expects NX-OS 10.x but the target is another platform. Proposed export 10.0.0.0/8 exceeds approved 10.40.0.0/16. A write token is readable by the analysis assistant. Deployment succeeds on 3 of 5 targets but reports complete success.

1. Only some green tasks
2. All scoped targets and service invariants verified or honestly unresolved
3. Only merged source code

**Correct option(s):** 2

- Option 1: Incorrect. That omits the failures.
- Option 2: Correct. No hidden partial success.
- Option 3: Incorrect. Code can exist without correct deployment.

#### Recall

**What should happen on platform mismatch?**

Reject or hold the target pending review Templates depend on supported behavior.

**What distinguishes semantic validation?**

It checks required behavior and scope Parsing alone is insufficient.

**What remains after initial deployment?**

Operations, maintenance, diagnosis and recovery Lifecycle ownership continues.

#### References

- [Cisco developer documentation](https://developer.cisco.com/)
- [BGP operational security](https://www.rfc-editor.org/rfc/rfc7454.html)

## NETWORK-ENGINEERING-M21 — Independent storage-network acceptance across FC and IP transports

### NETWORK-ENGINEERING-L21 — Independent storage-network acceptance across FC and IP transports

Estimated study time: 150 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L20

A storage network must deliver correct I/O, not merely packets. FC zoning, IP routing, host identity, target authorization, multipathing and the storage protocol's own state form different dependencies. A host can reach a target address yet lack authorization to a namespace or LUN. Conversely, a visible device may be the wrong one. Record stable storage identity and ownership before testing writes.

FC, iSCSI and NVMe-over-Fabrics require separate component teaching and evidence. Use the detailed CCNP/CCIE SAN chapters for FC login, zoning and credit behavior, then implement the chosen IP storage transport with its supported host and target. TCP-based and RDMA-based NVMe transports have different congestion and endpoint dependencies. Do not claim one passing iSCSI test establishes FC or RDMA competence.

Multipathing needs independent physical and logical paths, compatible host policy and array/controller behavior. Two sessions over one NIC or one switch can fail together. Recovery timing must meet the application deadline, and failback needs its own test. A write acknowledged by one layer is not proof that every durability requirement is satisfied; use the storage owner's documented semantics and an integrity-aware test workload.

Commission on disposable data with known checksums and controlled failures. Observe I/O errors, latency, path state and integrity before, during and after each failure. Keep backup/restore separate from path redundancy: redundant access cannot recover accidental deletion or corrupted application data by itself.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA — not captured from equipment.
Storage: two iSCSI sessions to LUN 7 share NIC 1 and Switch A. FC has not been tested. NVMe/TCP namespace N 1 authorizes H 1, but the request uses H 2. Required recovery 3 seconds; supplied recovery 8 seconds. The disposable dataset checksum changes unexpectedly after recovery.

**Reasoning:** The two iSCSI sessions share physical failure points. The NVMe host identity is unauthorized, and neither IP test establishes FC capability. Eight-second recovery fails the deadline. Unexpected checksum change is an integrity failure that blocks acceptance even if all paths return green.

#### Guided practice

Create separate FC and IP-storage acceptance records and define what would justify each competence claim.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** For FC retain login, zoning, masking, credit and I/O failure evidence. For IP storage retain routing, identity, session/namespace, multipath and I/O evidence. Both require independent paths, measured recovery and unchanged expected data. Label each actual environment and un executed branch.

#### Independent task

Environment: emulator

Demonstrate FC and IP-storage capability independently with identity, path, deadline and integrity acceptance.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Transport branches have separate evidence.
- No claimed redundant paths share an unaccepted common cause.
- Application integrity and deadline both pass.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0201 · single · diagnosis**

Why are the two sessions not independent?

SYNTHETIC TEACHING DATA — not captured from equipment.
Storage: two iSCSI sessions to LUN 7 share NIC 1 and Switch A. FC has not been tested. NVMe/TCP namespace N 1 authorizes H 1, but the request uses H 2. Required recovery 3 seconds; supplied recovery 8 seconds. The disposable dataset checksum changes unexpectedly after recovery.

1. They access one LUN
2. They share NIC 1 and Switch A
3. They have different session IDs

**Correct option(s):** 2

- Option 1: Incorrect. Shared storage identity is expected.
- Option 2: Correct. Logical sessions do not remove physical common causes.
- Option 3: Incorrect. IDs do not create topology diversity.

**NETWORK-ENGINEERING-Q0202 · single · diagnosis**

Why does namespace N 1 reject H 2?

SYNTHETIC TEACHING DATA — not captured from equipment.
Storage: two iSCSI sessions to LUN 7 share NIC 1 and Switch A. FC has not been tested. NVMe/TCP namespace N 1 authorizes H 1, but the request uses H 2. Required recovery 3 seconds; supplied recovery 8 seconds. The disposable dataset checksum changes unexpectedly after recovery.

1. NVMe cannot use TCP
2. Every namespace is public
3. Authorization is for H 1

**Correct option(s):** 3

- Option 1: Incorrect. NVMe/TCP is a supported transport category.
- Option 2: Incorrect. Access is controlled.
- Option 3: Correct. Reachability does not grant storage ownership.

**NETWORK-ENGINEERING-Q0203 · single · implementation**

Does iSCSI success establish FC competence?

SYNTHETIC TEACHING DATA — not captured from equipment.
Storage: two iSCSI sessions to LUN 7 share NIC 1 and Switch A. FC has not been tested. NVMe/TCP namespace N 1 authorizes H 1, but the request uses H 2. Required recovery 3 seconds; supplied recovery 8 seconds. The disposable dataset checksum changes unexpectedly after recovery.

1. No, FC mechanisms need separate demonstration
2. Yes, all storage protocols are identical
3. Yes, a LUN number proves fabric login

**Correct option(s):** 1

- Option 1: Correct. The protocols and control states differ.
- Option 2: Incorrect. They are not.
- Option 3: Incorrect. It does not.

**NETWORK-ENGINEERING-Q0204 · single · implementation**

Does 8 s recovery meet the 3 s deadline?

SYNTHETIC TEACHING DATA — not captured from equipment.
Storage: two iSCSI sessions to LUN 7 share NIC 1 and Switch A. FC has not been tested. NVMe/TCP namespace N 1 authorizes H 1, but the request uses H 2. Required recovery 3 seconds; supplied recovery 8 seconds. The disposable dataset checksum changes unexpectedly after recovery.

1. No
2. Yes, there are two sessions
3. Yes, any multipath design passes

**Correct option(s):** 1

- Option 1: Correct. Eventual path return is too slow.
- Option 2: Incorrect. Count does not establish timing.
- Option 3: Incorrect. Behavior must be measured.

**NETWORK-ENGINEERING-Q0205 · single · implementation**

What does the checksum change imply?

SYNTHETIC TEACHING DATA — not captured from equipment.
Storage: two iSCSI sessions to LUN 7 share NIC 1 and Switch A. FC has not been tested. NVMe/TCP namespace N 1 authorizes H 1, but the request uses H 2. Required recovery 3 seconds; supplied recovery 8 seconds. The disposable dataset checksum changes unexpectedly after recovery.

1. Integrity acceptance fails
2. A guaranteed network root cause
3. Only a cosmetic warning

**Correct option(s):** 1

- Option 1: Correct. Reachability cannot override changed data.
- Option 2: Incorrect. The cause still requires diagnosis.
- Option 3: Incorrect. Data correctness is central.

**NETWORK-ENGINEERING-Q0206 · single · implementation**

What should storage identity records include?

SYNTHETIC TEACHING DATA — not captured from equipment.
Storage: two iSCSI sessions to LUN 7 share NIC 1 and Switch A. FC has not been tested. NVMe/TCP namespace N 1 authorizes H 1, but the request uses H 2. Required recovery 3 seconds; supplied recovery 8 seconds. The disposable dataset checksum changes unexpectedly after recovery.

1. Host, target and LUN/namespace ownership
2. Only port LED colors
3. Only switch hostnames

**Correct option(s):** 1

- Option 1: Correct. Any visible device is not necessarily correct.
- Option 2: Incorrect. They omit logical identity.
- Option 3: Incorrect. They omit data ownership.

**NETWORK-ENGINEERING-Q0207 · single · diagnosis**

Why test failback separately?

SYNTHETIC TEACHING DATA — not captured from equipment.
Storage: two iSCSI sessions to LUN 7 share NIC 1 and Switch A. FC has not been tested. NVMe/TCP namespace N 1 authorizes H 1, but the request uses H 2. Required recovery 3 seconds; supplied recovery 8 seconds. The disposable dataset checksum changes unexpectedly after recovery.

1. A returned link never affects I/O
2. Restoration can change ownership and path selection
3. Failback is always identical to failover

**Correct option(s):** 2

- Option 1: Incorrect. It can.
- Option 2: Correct. It can introduce new interruption.
- Option 3: Incorrect. States can differ.

**NETWORK-ENGINEERING-Q0208 · single · implementation**

What does path redundancy not replace?

SYNTHETIC TEACHING DATA — not captured from equipment.
Storage: two iSCSI sessions to LUN 7 share NIC 1 and Switch A. FC has not been tested. NVMe/TCP namespace N 1 authorizes H 1, but the request uses H 2. Required recovery 3 seconds; supplied recovery 8 seconds. The disposable dataset checksum changes unexpectedly after recovery.

1. Some availability protection
2. Backup and trusted data recovery
3. Alternative access paths

**Correct option(s):** 2

- Option 1: Incorrect. It can provide that.
- Option 2: Correct. Multiple paths do not repair deletion.
- Option 3: Incorrect. That is its role.

**NETWORK-ENGINEERING-Q0209 · single · diagnosis**

Which workload is suitable for initial fault testing?

SYNTHETIC TEACHING DATA — not captured from equipment.
Storage: two iSCSI sessions to LUN 7 share NIC 1 and Switch A. FC has not been tested. NVMe/TCP namespace N 1 authorizes H 1, but the request uses H 2. Required recovery 3 seconds; supplied recovery 8 seconds. The disposable dataset checksum changes unexpectedly after recovery.

1. Unplanned production writes
2. Only an idle ping
3. Disposable verified data under controlled conditions

**Correct option(s):** 3

- Option 1: Incorrect. That lacks authorization and safeguards.
- Option 2: Incorrect. It does not exercise I/O.
- Option 3: Correct. It bounds integrity risk.

**NETWORK-ENGINEERING-Q0210 · single · implementation**

What closes the storage branch assessment?

SYNTHETIC TEACHING DATA — not captured from equipment.
Storage: two iSCSI sessions to LUN 7 share NIC 1 and Switch A. FC has not been tested. NVMe/TCP namespace N 1 authorizes H 1, but the request uses H 2. Required recovery 3 seconds; supplied recovery 8 seconds. The disposable dataset checksum changes unexpectedly after recovery.

1. Separate protocol, identity, failure and integrity evidence
2. Only a target ping
3. Only green path icons

**Correct option(s):** 1

- Option 1: Correct. One generic connectivity testis insufficient.
- Option 2: Incorrect. That is transport reachability.
- Option 3: Incorrect. They omit deadlines and data correctness.

#### Recall

**Why are the two sessions not independent?**

They share NIC 1 and Switch A Logical sessions do not remove physical common causes.

**What does the checksum change imply?**

Integrity acceptance fails Reachability cannot override changed data.

**Which workload is suitable for initial fault testing?**

Disposable verified data under controlled conditions It bounds integrity risk.

#### References

- [iSCSI protocol](https://www.rfc-editor.org/rfc/rfc7143.html)
- [NVM Express specifications](https://nvmexpress.org/specifications/)
- [Cisco MDS guides](https://www.cisco.com/c/en/us/support/storage-networking/mds-9000-nx-os-san-os-software/products-installation-and-configuration-guides-list.html)

## NETWORK-ENGINEERING-M22 — OSPF component lab: adjacency states, LSAs and summarization

### NETWORK-ENGINEERING-L22 — OSPF component lab: adjacency states, LSAs and summarization

Estimated study time: 210 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L21

### Topology and requirements
Use an isolated emulator with three routers in area 0 and an ABR into area 10. Hosts in 10.10.10.0/24 and 10.10.20.0/24 must reach a service in 10.0.100.0/24, while a separate management prefix remains excluded from redistribution. Give every router a unique stable router ID. Use explicit interface network types and record reference bandwidth/cost assumptions rather than relying on unrelated device defaults.

An OSPF router first discovers compatible neighbors through Hellos. The neighbor state progresses through discovery and bidirectional recognition before database exchange. ExStart negotiates database-description roles; Exchange transfers summaries; Loading requests missing LSAs; Full means the required database synchronization completed for that adjacency. On a broadcast network, routers use DR/BDR relationships to reduce full-adjacency count. A 2-Way relationship between two non-DR routers can therefore be normal. Interpret state in topology context.

### Read control state in layers
On a supported IOS XE lab, adapt these read-only examples to the installed release:

```text
show ip ospf neighbor
show ip ospf interface
show ip ospf database
show ip route ospf
show ip route 10.0.100.0
show ip cef 10.0.100.10
```
These commands were not run on vendor equipment here. Save actual output during the lab. A neighbor table answers who synchronized; the LSDB answers what topology information exists; the RIB answers which route won; the FIB/adjacency answers what forwarding was installed. A single 'Full' line cannot answer all four questions.

### Area and route reasoning
Within an area, routers compute paths from the area's link-state information. An ABR connects areas and represents reachability across the boundary through the applicable summary mechanisms. An ASBR originates external information under explicit redistribution policy. Do not redistribute every connected or static route merely to make a missing service reachable: that can expose management or create feedback between protocols.

Summarization is a promise of reachability for an aggregate. If 10.10.0.0/16 remains advertised while 10.10.20.0/24 disappears, a remote router can continue sending traffic into the aggregate even though the component is absent. The design must state how discard routes, component tracking and failure behavior prevent loops and bound blackholing. A smaller routing table is not automatically a more correct one.

### Guided implementation sequence
Bring up point-to-point area 0 links first and verify expected neighbors. Add area 10 on the ABR and confirm each intended subnet appears in the correct database and routing views. Add only the approved external route, tag or otherwise constrain redistribution according to the platform design, and prove the management prefix remains absent. Introduce one MTU mismatch in the isolated lab and observe the database-exchange failure. Restore it before introducing an area mismatch so symptoms remain attributable.

For failure testing, remove one transit link, then one component subnet under the summary. Record route withdrawal, FIB change and application interruption separately. Repeat using IPv6 in the later dual-stack component rather than assuming the IPv4 result transfers automatically. The independent artifact is a route-state timeline with a complete positive/negative prefix matrix and an executed rollback.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. SYNTHETIC topology: R 1—R 2—R 3 in area 0; R 2 is ABR to area 10. Area 10 has 10.10.10.0/24 and 10.10.20.0/24. R 2 advertises summary 10.10.0.0/16. The 20/24 component fails; summary remains. R 1 also learns 10.0.100.0/24 from a competing protocol with a preferred administrative distance. One neighbor pair is ExStart after an MTU mismatch.

**Reasoning:** The remaining summary can still attract 20/24 traffic, so inspect the ABR's component and discard behavior. The service LSA can exist without winning the RIB because another source is preferred. ExStart localizes a separate adjacency-exchange issue. Treat each layer independently and preserve the management-prefix exclusion.

#### Guided practice

Predict the neighbor, LSDB, RIB and FIB evidence for the MTU fault, then for a withdrawn component under the aggregate.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** The MTU fault prevents completed database exchange on the affected adjacency; remote effects depend on alternate paths. The component withdrawal removes specific reachability but may leave the aggregate advertised, so traffic still arrives at the ABR and needs defined discard/alternate behavior. Neither condition is diagnosed by router-ID comparison alone.

#### Independent task

Environment: emulator

Build the multi-area IGP and prove adjacency, redistribution exclusion and aggregate failure behavior with actual emulator output.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Expected neighbor relationships match network type.
- Management prefixes never enter unauthorized redistribution.
- Summary behavior and application recovery are measured.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0211 · single · diagnosis**

Why can the summary attract traffic to the failed 20/24?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC topology: R 1—R 2—R 3 in area 0; R 2 is ABR to area 10. Area 10 has 10.10.10.0/24 and 10.10.20.0/24. R 2 advertises summary 10.10.0.0/16. The 20/24 component fails; summary remains. R 1 also learns 10.0.100.0/24 from a competing protocol with a preferred administrative distance. One neighbor pair is ExStart after an MTU mismatch.

1. OSPF automatically creates the missing subnet
2. The aggregate still covers that destination
3. The source host must change its address

**Correct option(s):** 2

- Option 1: Incorrect. Advertisements do not create endpoint reachability.
- Option 2: Correct. Specific reachability can disappear while the aggregate remains.
- Option 3: Incorrect. The failure is routing coverage.

**NETWORK-ENGINEERING-Q0212 · single · implementation**

What can make the service LSA lose RIB selection?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC topology: R 1—R 2—R 3 in area 0; R 2 is ABR to area 10. Area 10 has 10.10.10.0/24 and 10.10.20.0/24. R 2 advertises summary 10.10.0.0/16. The 20/24 component fails; summary remains. R 1 also learns 10.0.100.0/24 from a competing protocol with a preferred administrative distance. One neighbor pair is ExStart after an MTU mismatch.

1. A preferred competing route source
2. A different interface description
3. A longer hostname

**Correct option(s):** 1

- Option 1: Correct. LSDB presence does not override all route-selection rules.
- Option 2: Incorrect. Descriptions do not select routes.
- Option 3: Incorrect. Names are irrelevant to preference.

**NETWORK-ENGINEERING-Q0213 · single · implementation**

Which observation best locates the MTU problem?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC topology: R 1—R 2—R 3 in area 0; R 2 is ABR to area 10. Area 10 has 10.10.10.0/24 and 10.10.20.0/24. R 2 advertises summary 10.10.0.0/16. The 20/24 component fails; summary remains. R 1 also learns 10.0.100.0/24 from a competing protocol with a preferred administrative distance. One neighbor pair is ExStart after an MTU mismatch.

1. Only the application timeout
2. Only a Full neighbor on another link
3. ExStart plus interface MTU comparison

**Correct option(s):** 3

- Option 1: Incorrect. It is a downstream symptom.
- Option 2: Incorrect. That does not validate this adjacency.
- Option 3: Correct. Database exchange is the affected stage.

**NETWORK-ENGINEERING-Q0214 · single · diagnosis**

Why retain a negative redistribution test?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC topology: R 1—R 2—R 3 in area 0; R 2 is ABR to area 10. Area 10 has 10.10.10.0/24 and 10.10.20.0/24. R 2 advertises summary 10.10.0.0/16. The 20/24 component fails; summary remains. R 1 also learns 10.0.100.0/24 from a competing protocol with a preferred administrative distance. One neighbor pair is ExStart after an MTU mismatch.

1. All redistribution is forbidden
2. Broad redistribution can expose management prefixes
3. A route tag proves every filter works

**Correct option(s):** 2

- Option 1: Incorrect. The task permits one approved external route.
- Option 2: Correct. Reachability must remain scoped.
- Option 3: Incorrect. Effective advertisements still need testing.

**NETWORK-ENGINEERING-Q0215 · single · diagnosis**

What does a 2-Way non-DR relationship require before calling it faulty?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC topology: R 1—R 2—R 3 in area 0; R 2 is ABR to area 10. Area 10 has 10.10.10.0/24 and 10.10.20.0/24. R 2 advertises summary 10.10.0.0/16. The 20/24 component fails; summary remains. R 1 also learns 10.0.100.0/24 from a competing protocol with a preferred administrative distance. One neighbor pair is ExStart after an MTU mismatch.

1. Comparison with the broadcast adjacency design
2. An immediate reboot
3. Automatic removal of the subnet

**Correct option(s):** 1

- Option 1: Correct. It may be expected.
- Option 2: Incorrect. That skips topology reasoning.
- Option 3: Incorrect. The state alone does not justify that.

**NETWORK-ENGINEERING-Q0216 · single · implementation**

Which view establishes hardware forwarding intent after RIB selection?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC topology: R 1—R 2—R 3 in area 0; R 2 is ABR to area 10. Area 10 has 10.10.10.0/24 and 10.10.20.0/24. R 2 advertises summary 10.10.0.0/16. The 20/24 component fails; summary remains. R 1 also learns 10.0.100.0/24 from a competing protocol with a preferred administrative distance. One neighbor pair is ExStart after an MTU mismatch.

1. Only the router LSA
2. FIB and adjacency state
3. Only the Hello timer

**Correct option(s):** 2

- Option 1: Incorrect. That is topology input.
- Option 2: Correct. Control selection must be installed.
- Option 3: Incorrect. That affects neighbor maintenance.

**NETWORK-ENGINEERING-Q0217 · single · design**

What should summarization design document?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC topology: R 1—R 2—R 3 in area 0; R 2 is ABR to area 10. Area 10 has 10.10.10.0/24 and 10.10.20.0/24. R 2 advertises summary 10.10.0.0/16. The 20/24 component fails; summary remains. R 1 also learns 10.0.100.0/24 from a competing protocol with a preferred administrative distance. One neighbor pair is ExStart after an MTU mismatch.

1. Component loss, discard and alternate-path behavior
2. Only the count of areas
3. Only shorter configuration length

**Correct option(s):** 1

- Option 1: Correct. The aggregate can outlive a component.
- Option 2: Incorrect. It omits failure behavior.
- Option 3: Incorrect. That is not reachability correctness.

**NETWORK-ENGINEERING-Q0218 · single · diagnosis**

Why inject one fault at a time initially?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC topology: R 1—R 2—R 3 in area 0; R 2 is ABR to area 10. Area 10 has 10.10.10.0/24 and 10.10.20.0/24. R 2 advertises summary 10.10.0.0/16. The 20/24 component fails; summary remains. R 1 also learns 10.0.100.0/24 from a competing protocol with a preferred administrative distance. One neighbor pair is ExStart after an MTU mismatch.

1. Multiple faults can never coexist
2. To learn each causal signature
3. It guarantees no outage

**Correct option(s):** 2

- Option 1: Incorrect. They can in later assessment.
- Option 2: Correct. Interacting faults come after component understanding.
- Option 3: Incorrect. The lab deliberately tests failure.

**NETWORK-ENGINEERING-Q0219 · single · implementation**

What separates ABR from ASBR responsibility?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC topology: R 1—R 2—R 3 in area 0; R 2 is ABR to area 10. Area 10 has 10.10.10.0/24 and 10.10.20.0/24. R 2 advertises summary 10.10.0.0/16. The 20/24 component fails; summary remains. R 1 also learns 10.0.100.0/24 from a competing protocol with a preferred administrative distance. One neighbor pair is ExStart after an MTU mismatch.

1. ASBR means any switch with a default route
2. Area interconnection versus external route origination
3. ABR always performs NAT

**Correct option(s):** 2

- Option 1: Incorrect. The role is protocol-specific.
- Option 2: Correct. A router can have roles that must be distinguished.
- Option 3: Incorrect. That is not its defining role.

**NETWORK-ENGINEERING-Q0220 · single · implementation**

What closes this component lab?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC topology: R 1—R 2—R 3 in area 0; R 2 is ABR to area 10. Area 10 has 10.10.10.0/24 and 10.10.20.0/24. R 2 advertises summary 10.10.0.0/16. The 20/24 component fails; summary remains. R 1 also learns 10.0.100.0/24 from a competing protocol with a preferred administrative distance. One neighbor pair is ExStart after an MTU mismatch.

1. Only reaching one host normally
2. Layered route evidence plus scoped failure recovery
3. Only saving the OSPF configuration

**Correct option(s):** 2

- Option 1: Incorrect. It omits exclusion and failure states.
- Option 2: Correct. A Full neighbor alone is incomplete.
- Option 3: Incorrect. Intent is not forwarding.

#### Recall

**Why can the summary attract traffic to the failed 20/24?**

The aggregate still covers that destination Specific reachability can disappear while the aggregate remains.

**What does a 2-Way non-DR relationship require before calling it faulty?**

Comparison with the broadcast adjacency design It may be expected.

**What separates ABR from ASBR responsibility?**

Area interconnection versus external route origination A router can have roles that must be distinguished.

#### References

- [OSPFv 2 specification](https://www.rfc-editor.org/rfc/rfc2328.html)
- [Cisco enterprise routing documentation](https://www.cisco.com/c/en/us/support/routers/products-installation-and-configuration-guides-list.html)

## NETWORK-ENGINEERING-M23 — BGP component lab: import/export policy and recursive forwarding

### NETWORK-ENGINEERING-L23 — BGP component lab: import/export policy and recursive forwarding

Estimated study time: 210 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L22

### Build a bounded inter domain model
Create an isolated four-router lab: enterprise AS 65000, customer AS 65010, peer AS 65020 and transit AS 65030. Use documentation/private addressing only inside the lab. Customer 65010 is authorized to originate 10.10.0.0/16. The enterprise originates 10.40.0.0/16. The peer supplies 10.20.0.0/16; transit supplies a default. Define export permission for each relationship before enabling sessions. No command in this exercise authorizes public route announcements.

A BGP TCP session carries route information; policy determines what is accepted and advertised. The best route must also have a usable next hop in the correct routing context. In iBGP designs, next-hop handling and route-reflection rules can leave control information visible while forwarding recursion fails. A route reflector need not carry the traffic and must not be assumed to supply a physical path merely because it reflects an NLRI.

### Policy example and limits
The following is an illustrative IOS XE-style lab fragment, not a production-ready configuration. Verify syntax and behavior against the installed release:

```text
ip prefix-list CUST-IN seq 10 permit 10.10.0.0/16
ip prefix-list OUR-OUT seq 10 permit 10.40.0.0/16
route-map CUST-IN permit 10
 match ip address prefix-list CUST-IN
route-map OUR-OUT permit 10
 match ip address prefix-list OUR-OUT
```
The exact prefix statement permits that prefix length; it does not automatically authorize every more-specific route. Add ` ge `/` le ` only when the relationship explicitly permits the range. The route map must be attached to the correct neighbor and direction, and implicit denial must be understood. A correct unattached policy object does not enforce anything.

Use supported ` show bgp ipv 4 unicast`, neighbor advertised/received route views, routing-table and forwarding-table commands to compare received, accepted, selected and installed states. Some received-route views require appropriate platform support or retained pre-policy information; do not assume every device can reconstruct discarded routes without configuration implications.

### Selection and traffic engineering
Local preference generally expresses outbound preference within the AS. AS-path length, origin, MED and other attributes participate according to the platform's selection rules and policy. Do not reduce the entire algorithm to 'shortest AS path always wins'. Remote networks retain their own policy, so pre pending or community signaling influences inbound traffic without guaranteeing it. Record the intended effect and validate actual paths.

Test the contracted prefix, an unauthorized default, an unauthorized more-specific and a peer-to-peer leak. Then make the preferred next hop unreachable while retaining its BGP advertisement and observe eligibility/installation. Finally withdraw transit and measure application behavior over the remaining approved route. Preserve a management route that does not depend on the policy being changed.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. SYNTHETIC lab: customer sends 10.10.0.0/16, 10.10.1.0/24 and 0.0.0.0/0. Exact CUST-IN policy permits only/16. OUR-OUT object exists but is not attached to peer 65020. Internal router receives a preferred route whose next hop is 10.255.0.9, absent from its routing table.

**Reasoning:** The exact-prefix policy should reject the/24 and default under this contract. The unattached export object provides no enforcement. The internal route needs valid next-hop recursion; session health and preference do not establish that. Verify each result with actual route views in the isolated lab.

#### Guided practice

Write the smallest approved policy change if the customer is later authorized to advertise/24 s within 10.10.0.0/16, but no other ranges.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Use a bounded prefix-length range within the authorized aggregate under the installed platform syntax, attach it in the intended import direction and test/16,/24 and out-of-range cases. Do not replace the policy with permit-any. Recheck exports so accepted customer routes do not create unintended transit.

#### Independent task

Environment: emulator

Implement and assess BGP policy with exact-prefix semantics, attachment verification, next-hop recursion and relationship-aware exports.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Unauthorized defaults and prefixes are rejected.
- Policy objects are attached in the correct direction.
- Selected forwarding is verified through neighbor loss.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0221 · single · implementation**

Does the exact/16 statement permit 10.10.1.0/24 here?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC lab: customer sends 10.10.0.0/16, 10.10.1.0/24 and 0.0.0.0/0. Exact CUST-IN policy permits only/16. OUR-OUT object exists but is not attached to peer 65020. Internal router receives a preferred route whose next hop is 10.255.0.9, absent from its routing table.

1. Only if the hostname matches
2. Yes, all subnets are always included
3. No

**Correct option(s):** 3

- Option 1: Incorrect. Names do not affect prefix matching.
- Option 2: Incorrect. Prefix-list length semantics matter.
- Option 3: Correct. More-specific permission requires an explicit permitted length range.

**NETWORK-ENGINEERING-Q0222 · single · implementation**

What is wrong with the unattached OUR-OUT object?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC lab: customer sends 10.10.0.0/16, 10.10.1.0/24 and 0.0.0.0/0. Exact CUST-IN policy permits only/16. OUR-OUT object exists but is not attached to peer 65020. Internal router receives a preferred route whose next hop is 10.255.0.9, absent from its routing table.

1. It automatically applies to every peer
2. It does not enforce neighbor export
3. Its name is too short

**Correct option(s):** 2

- Option 1: Incorrect. That cannot be assumed.
- Option 2: Correct. Definition and attachment are separate.
- Option 3: Incorrect. Names do not create this fault.

**NETWORK-ENGINEERING-Q0223 · single · diagnosis**

Why is next-hop 10.255.0.9 significant?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC lab: customer sends 10.10.0.0/16, 10.10.1.0/24 and 0.0.0.0/0. Exact CUST-IN policy permits only/16. OUR-OUT object exists but is not attached to peer 65020. Internal router receives a preferred route whose next hop is 10.255.0.9, absent from its routing table.

1. Forwarding recursion cannot resolve it
2. It makes the TCP session impossible necessarily
3. It must be the destination host

**Correct option(s):** 1

- Option 1: Correct. BGP visibility alone is insufficient.
- Option 2: Incorrect. Control transport can use another path.
- Option 3: Incorrect. A next hop is a forwarding dependency.

**NETWORK-ENGINEERING-Q0224 · single · design**

Which requirement justifies adding a prefix-length range?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC lab: customer sends 10.10.0.0/16, 10.10.1.0/24 and 0.0.0.0/0. Exact CUST-IN policy permits only/16. OUR-OUT object exists but is not attached to peer 65020. Internal router receives a preferred route whose next hop is 10.255.0.9, absent from its routing table.

1. A successful neighbor ping
2. Explicit customer authorization for those more-specifics
3. A desire for more routes

**Correct option(s):** 2

- Option 1: Incorrect. Reachability does not grant export scope.
- Option 2: Correct. The filter should follow the contract.
- Option 3: Incorrect. Quantity is not authorization.

**NETWORK-ENGINEERING-Q0225 · single · diagnosis**

Why is shortest AS path not the whole decision?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC lab: customer sends 10.10.0.0/16, 10.10.1.0/24 and 0.0.0.0/0. Exact CUST-IN policy permits only/16. OUR-OUT object exists but is not attached to peer 65020. Internal router receives a preferred route whose next hop is 10.255.0.9, absent from its routing table.

1. Every vendor ignores policy
2. AS paths never matter
3. Policy and other selection attributes apply

**Correct option(s):** 3

- Option 1: Incorrect. Policy is central to BGP.
- Option 2: Incorrect. They do participate.
- Option 3: Correct. Local preference can dominate in common designs.

**NETWORK-ENGINEERING-Q0226 · single · implementation**

What does route reflection not guarantee?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC lab: customer sends 10.10.0.0/16, 10.10.1.0/24 and 0.0.0.0/0. Exact CUST-IN policy permits only/16. OUR-OUT object exists but is not attached to peer 65020. Internal router receives a preferred route whose next hop is 10.255.0.9, absent from its routing table.

1. Distribution of eligible route information
2. A usable data-plane path through the reflector
3. An iBGP control relationship

**Correct option(s):** 2

- Option 1: Incorrect. That is its role.
- Option 2: Correct. Control distribution and forwarding differ.
- Option 3: Incorrect. It supports that.

**NETWORK-ENGINEERING-Q0227 · single · implementation**

Which negative advertisement is essential here?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC lab: customer sends 10.10.0.0/16, 10.10.1.0/24 and 0.0.0.0/0. Exact CUST-IN policy permits only/16. OUR-OUT object exists but is not attached to peer 65020. Internal router receives a preferred route whose next hop is 10.255.0.9, absent from its routing table.

1. An unauthorized default
2. Only another copy of the permitted/16
3. Only the enterprise's own hostname

**Correct option(s):** 1

- Option 1: Correct. It tests broad traffic-attraction prevention.
- Option 2: Incorrect. That repeats the positive case.
- Option 3: Incorrect. It is not a route advertisement.

**NETWORK-ENGINEERING-Q0228 · single · diagnosis**

Why verify the neighbor direction?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC lab: customer sends 10.10.0.0/16, 10.10.1.0/24 and 0.0.0.0/0. Exact CUST-IN policy permits only/16. OUR-OUT object exists but is not attached to peer 65020. Internal router receives a preferred route whose next hop is 10.255.0.9, absent from its routing table.

1. Directions are interchangeable
2. Direction only affects logging
3. Import and export constrain different flows of routes

**Correct option(s):** 3

- Option 1: Incorrect. They are not.
- Option 2: Incorrect. It affects route acceptance/advertisement.
- Option 3: Correct. Correct policy on the wrong direction misses the requirement.

**NETWORK-ENGINEERING-Q0229 · single · implementation**

What limits inbound traffic-engineering guarantees?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC lab: customer sends 10.10.0.0/16, 10.10.1.0/24 and 0.0.0.0/0. Exact CUST-IN policy permits only/16. OUR-OUT object exists but is not attached to peer 65020. Internal router receives a preferred route whose next hop is 10.255.0.9, absent from its routing table.

1. Only local interface speed
2. The absence of all BGP attributes
3. Remote AS policy

**Correct option(s):** 3

- Option 1: Incorrect. Capacity does not control remote preference.
- Option 2: Incorrect. Attributes exist but are not absolute authority.
- Option 3: Correct. Your attributes are inputs to others' decisions.

**NETWORK-ENGINEERING-Q0230 · single · implementation**

What closes the BGP build?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC lab: customer sends 10.10.0.0/16, 10.10.1.0/24 and 0.0.0.0/0. Exact CUST-IN policy permits only/16. OUR-OUT object exists but is not attached to peer 65020. Internal router receives a preferred route whose next hop is 10.255.0.9, absent from its routing table.

1. Only a full route table
2. Received/accepted/advertised/installed evidence and application tests
3. Only the policy text

**Correct option(s):** 2

- Option 1: Incorrect. It may include unauthorized routes.
- Option 2: Correct. A session-up result is incomplete.
- Option 3: Incorrect. It may be unattached.

#### Recall

**Does the exact/16 statement permit 10.10.1.0/24 here?**

No More-specific permission requires an explicit permitted length range.

**Why is shortest AS path not the whole decision?**

Policy and other selection attributes apply Local preference can dominate in common designs.

**What limits inbound traffic-engineering guarantees?**

Remote AS policy Your attributes are inputs to others' decisions.

#### References

- [BGP-4](https://www.rfc-editor.org/rfc/rfc4271.html)
- [BGP operational security](https://www.rfc-editor.org/rfc/rfc7454.html)

## NETWORK-ENGINEERING-M24 — IPv6 component lab: neighbor discovery, RA policy and PMTU

### NETWORK-ENGINEERING-L24 — IPv6 component lab: neighbor discovery, RA policy and PMTU

Estimated study time: 210 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L23

### Do not treat IPv6 as a second address label
Build a lab with two access segments, a routed transit and a dual-stack service. Document IPv6 prefixes, router advertisements, address-assignment method, DNS answers and security policy independently from IPv4. A client can prefer an IPv6 destination returned by DNS even when the IPv4 service is healthy, so a partial IPv6 deployment can create intermittent-looking application failures.

Neighbor discovery resolves link-layer neighbors, discovers routers and supports reachability behavior. Router advertisements provide default-router and prefix information according to their flags and lifetimes. DHCPv 6 can provide address/configuration information in supported designs, but do not assume it universally supplies the IPv6 default gateway in the same way as a familiar IPv4 DHCP deployment. Inspect the host's actual default-router state.

### Follow an IPv6 packet
For an on-link destination, the host resolves the neighbor on that link. For an off-link destination, it selects a default or more-specific router and resolves that router's link-layer address. The router forwards according to its IPv6 FIB. If a transit link cannot carry the packet, IPv6 routers do not fragment it on behalf of the source; the source needs appropriate path-MTU behavior. Blocking every IC MPv 6 message can therefore break more than ping.

In a Linux lab, use read-only observations such as:

```text
ip -6 address show
ip -6 route show
ip -6 neigh show
```
Capture the relevant IC MPv 6 exchanges in an authorized isolated environment and correlate them with route/neighbor state. These command examples are not evidence that the user's platform was configured or tested. Use the operating system's installed documentation for capture filters and interface selection.

### Control the first-hop trust boundary
Only intended routers should advertise routing information on an access segment. Apply supported RA protection at the correct boundary and test its actual handling of the traffic forms relevant to the platform. A simplistic filter that misses extension-header or fragmentation cases can fail to enforce the intended policy; use current supported guidance. Do not disable legitimate neighbor discovery to block one unwanted router.

Test router lifetime expiry, prefix changes, duplicate addressing, neighbor un reachability and a lower-MTU transit. Observe both existing sessions and new connections. A DNS cache can retain an old AAAA answer after a server moves, so distinguish name selection from forwarding failure. Also verify that IPv6 management and application ACLs express the same intended boundary as IPv4 without assuming identical syntax or default behavior.

The final evidence set includes host address/router state, packet traces, installed routes, required IC MPv 6 behavior and positive/negative application tests. A successful IPv4 ping or an assigned IPv6 address is not a substitute.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. SYNTHETIC lab: host receives an unauthorized RA with preferred default router fe 80::bad. Legitimate router is fe 80::1. DNS returns AAAA 2001:db 8:20::10 and A 192.0.2.10. IPv4 works. IPv6 path includes 1280-byte MTU; source sends larger packets but Packet Too Big messages are blocked.

**Reasoning:** Two independent IPv6 defects exist: wrong first-hop selection and broken size adaptation. Confirm host router state and capture the RA source, then enforce the intended boundary. Restore required PMTU signaling under policy and test maximum intended application behavior. IPv4 success does not clear either fault.

#### Guided practice

Predict what changes after fixing RA policy but leaving Packet Too Big blocked.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Small IPv6 traffic can recover through the legitimate router, while larger transfers may still fail at the lower-MTU link. That partial improvement proves one dependency was repaired, not the whole IPv6 service. Continue size-stratified tests and preserve required IC MPv 6.

#### Independent task

Environment: emulator

Implement and independently assess IPv6 host discovery, first-hop protection and path-MTU behavior alongside IPv4.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Only intended routers influence access-host routing.
- Required IPv6 control traffic is preserved.
- Both small and large application transactions pass approved policy.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0231 · single · implementation**

What selects the supplied wrong first hop?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC lab: host receives an unauthorized RA with preferred default router fe 80::bad. Legitimate router is fe 80::1. DNS returns AAAA 2001:db 8:20::10 and A 192.0.2.10. IPv4 works. IPv6 path includes 1280-byte MTU; source sends larger packets but Packet Too Big messages are blocked.

1. The healthy IPv4 route
2. The unauthorized router advertisement
3. The A record alone

**Correct option(s):** 2

- Option 1: Incorrect. IPv4 and IPv6 route state differ.
- Option 2: Correct. Host default-router state reflects the RA.
- Option 3: Incorrect. The IPv6 path uses the AAAA destination.

**NETWORK-ENGINEERING-Q0232 · single · implementation**

What remains after RA repair alone?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC lab: host receives an unauthorized RA with preferred default router fe 80::bad. Legitimate router is fe 80::1. DNS returns AAAA 2001:db 8:20::10 and A 192.0.2.10. IPv4 works. IPv6 path includes 1280-byte MTU; source sends larger packets but Packet Too Big messages are blocked.

1. The PMTU feedback defect
2. No possible IPv6 failure
3. A guaranteed DNS outage

**Correct option(s):** 1

- Option 1: Correct. Larger packets can still fail.
- Option 2: Incorrect. Only one dependency changed.
- Option 3: Incorrect. DNS was not the supplied failure.

**NETWORK-ENGINEERING-Q0233 · single · implementation**

Do IPv6 transit routers fragment oversized packets here?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC lab: host receives an unauthorized RA with preferred default router fe 80::bad. Legitimate router is fe 80::1. DNS returns AAAA 2001:db 8:20::10 and A 192.0.2.10. IPv4 works. IPv6 path includes 1280-byte MTU; source sends larger packets but Packet Too Big messages are blocked.

1. No
2. Only when IPv4 works
3. Yes, every router fragments automatically

**Correct option(s):** 1

- Option 1: Correct. The source must respond to the relevant path-MTU information.
- Option 2: Incorrect. The families' success states do not define fragmentation.
- Option 3: Incorrect. That is not IPv6 transit behavior.

**NETWORK-ENGINEERING-Q0234 · single · diagnosis**

Why is blanket IC MPv 6 denial unsafe?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC lab: host receives an unauthorized RA with preferred default router fe 80::bad. Legitimate router is fe 80::1. DNS returns AAAA 2001:db 8:20::10 and A 192.0.2.10. IPv4 works. IPv6 path includes 1280-byte MTU; source sends larger packets but Packet Too Big messages are blocked.

1. It always improves all security
2. IC MPv 6 carries all application passwords
3. It can break essential control and PMTU functions

**Correct option(s):** 3

- Option 1: Incorrect. It can deny required function.
- Option 2: Incorrect. That is not its role.
- Option 3: Correct. IC MPv 6 is not merely an optional ping service.

**NETWORK-ENGINEERING-Q0235 · single · implementation**

What should the host inspect for off-link delivery?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC lab: host receives an unauthorized RA with preferred default router fe 80::bad. Legitimate router is fe 80::1. DNS returns AAAA 2001:db 8:20::10 and A 192.0.2.10. IPv4 works. IPv6 path includes 1280-byte MTU; source sends larger packets but Packet Too Big messages are blocked.

1. Only its IPv4 ARP table
2. Only the Ethernet speed
3. Its IPv6 route and next-hop neighbor state

**Correct option(s):** 3

- Option 1: Incorrect. IPv6 uses neighbor discovery.
- Option 2: Incorrect. That does not select the router.
- Option 3: Correct. Address assignment alone is insufficient.

**NETWORK-ENGINEERING-Q0236 · single · diagnosis**

Why test cached AAAA behavior?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC lab: host receives an unauthorized RA with preferred default router fe 80::bad. Legitimate router is fe 80::1. DNS returns AAAA 2001:db 8:20::10 and A 192.0.2.10. IPv4 works. IPv6 path includes 1280-byte MTU; source sends larger packets but Packet Too Big messages are blocked.

1. Caching cannot affect IPv6
2. Old name answers can persist across changes
3. AAAA records are never cached

**Correct option(s):** 2

- Option 1: Incorrect. DNS caching applies to AAAA too.
- Option 2: Correct. Correct routing to a wrong address still fails the service.
- Option 3: Incorrect. They can be.

**NETWORK-ENGINEERING-Q0237 · single · implementation**

What must RA protection testing preserve?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC lab: host receives an unauthorized RA with preferred default router fe 80::bad. Legitimate router is fe 80::1. DNS returns AAAA 2001:db 8:20::10 and A 192.0.2.10. IPv4 works. IPv6 path includes 1280-byte MTU; source sends larger packets but Packet Too Big messages are blocked.

1. Legitimate neighbor-discovery behavior
2. Every RA regardless of source
3. No IC MPv 6 at all

**Correct option(s):** 1

- Option 1: Correct. Blocking an attacker must not disable required control.
- Option 2: Incorrect. That defeats the trust boundary.
- Option 3: Incorrect. That breaks required functions.

**NETWORK-ENGINEERING-Q0238 · single · implementation**

What does a configured IPv6 address not prove?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC lab: host receives an unauthorized RA with preferred default router fe 80::bad. Legitimate router is fe 80::1. DNS returns AAAA 2001:db 8:20::10 and A 192.0.2.10. IPv4 works. IPv6 path includes 1280-byte MTU; source sends larger packets but Packet Too Big messages are blocked.

1. That an address value exists
2. A usable default path and application policy
3. That the host can attempt IPv6

**Correct option(s):** 2

- Option 1: Incorrect. It proves that limited fact.
- Option 2: Correct. Host configuration is one stage.
- Option 3: Incorrect. It can, subject to state.

**NETWORK-ENGINEERING-Q0239 · single · implementation**

Which test distinguishes size-dependent failure?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC lab: host receives an unauthorized RA with preferred default router fe 80::bad. Legitimate router is fe 80::1. DNS returns AAAA 2001:db 8:20::10 and A 192.0.2.10. IPv4 works. IPv6 path includes 1280-byte MTU; source sends larger packets but Packet Too Big messages are blocked.

1. Controlled packet/application sizes over the same path
2. Only a controller uptime check
3. Only restarting DNS

**Correct option(s):** 1

- Option 1: Correct. It holds other dependencies stable.
- Option 2: Incorrect. It omits data plane size.
- Option 3: Incorrect. That changes an unrelated layer.

**NETWORK-ENGINEERING-Q0240 · single · implementation**

What closes the dual-stack host lab?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC lab: host receives an unauthorized RA with preferred default router fe 80::bad. Legitimate router is fe 80::1. DNS returns AAAA 2001:db 8:20::10 and A 192.0.2.10. IPv4 works. IPv6 path includes 1280-byte MTU; source sends larger packets but Packet Too Big messages are blocked.

1. Only a Full OSPF adjacency
2. Only a valid AAAA answer
3. Router, neighbor, PMTU and application evidence in both families

**Correct option(s):** 3

- Option 1: Incorrect. Host first-hop state remains separate.
- Option 2: Incorrect. The path may still fail.
- Option 3: Correct. One-family success is not enough.

#### Recall

**What selects the supplied wrong first hop?**

The unauthorized router advertisement Host default-router state reflects the RA.

**What should the host inspect for off-link delivery?**

Its IPv6 route and next-hop neighbor state Address assignment alone is insufficient.

**Which test distinguishes size-dependent failure?**

Controlled packet/application sizes over the same path It holds other dependencies stable.

#### References

- [IPv6 specification](https://www.rfc-editor.org/rfc/rfc8200.html)
- [Neighbor Discovery](https://www.rfc-editor.org/rfc/rfc4861.html)
- [IPv6 PMTU](https://www.rfc-editor.org/rfc/rfc8201.html)
- [RA Guard implementation](https://www.rfc-editor.org/rfc/rfc7113.html)

## NETWORK-ENGINEERING-M25 — RF component lab: link budget, airtime and survey interpretation

### NETWORK-ENGINEERING-L25 — RF component lab: link budget, airtime and survey interpretation

Estimated study time: 210 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L24

### Define the wireless service before placing APs
Specify client population, concurrent activity, application latency/loss, coverage locations, roaming routes and degraded operation after an AP loss. Identify devices with limited transmit power, antennas or band support. A design optimized for one survey laptop can fail handheld s or embedded operational clients. Regulatory channel and power limits are location-specific and must be checked for the deployment region.

A simplified received-power model adds transmitter power and antenna gains, then subtracts cable and path losses. It is useful for reasoning but does not capture all multipath, interference and building effects. Link margin should be evaluated in both directions. Raising AP power without improving the client uplink can create a cell the client hears but cannot reliably use.

### Interpret the measurements
RSSI estimates received power; noise and interference determine whether the signal can be decoded reliably. SNR is a ratio expressed in decibels, computed as signal dBm minus noise dBm under the measurement's assumptions. A 30 dB SNR from -55 dBm signal and -85 dBm noise does not establish capacity when channel utilization is 90%. The medium can be busy with other transmitters even while the desired signal is strong.

Airtime is the scarce shared resource. Management overhead, contention, retries and lower-rate transmissions consume it. A 100 Mbit transfer at a low effective rate occupies the channel longer than the same payload at a higher effective rate, but advertised PHY rate is not net payload service. Do not simply add client speed labels to calculate AP capacity. Measure representative concurrent applications and the distribution of retries and latency.

### Survey workflow
Begin with a predictive model using current floor plans and material assumptions. Use it to choose candidate locations, not to claim measured coverage. On site, record passive observations and active tests at defined points and along roaming paths. Note AP placement/antenna, channel, width, power, client hardware and background occupancy. Repeat problem locations with another representative client to distinguish device-specific behavior.

For a dense room, compare narrower channels with wider channels under the same offered load. Wider channels can improve one client's peak rate while reducing reuse across the site. The correct choice is the one that meets the concurrent service requirement within the available spectrum and interference environment. Keep a record of the trade-off rather than labeling wider as automatically advanced.

### Failure and maintenance
Disable one AP only under an approved isolated or controlled test and measure remaining coverage, load and roaming. Verify that clients do not cling to an unusable cell or require an authentication path that has also failed. Capture tail latency and loss for the actual application, not only a speed test. The independent evidence is a survey map plus raw measurements and a clear distinction between prediction, physical measurement and untested areas.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. SYNTHETIC comparison: Design A uses 80 MHz and achieves high single-client peak, but 4 adjacent cells share limited reuse. Design B uses 20 MHz with lower peak but more reuse. Client uplink transmit power is 12 dB below AP power. Loaded voice 95th-percentile latency is 18 ms, 99.9th-percentile is 140 ms; requirement is below 50 ms at 99.9th.

**Reasoning:** The high peak and 95th-percentile value do not satisfy the stated 99.9th-percentile constraint. Compare the two channel designs under identical representative concurrency. The 12 dB transmit-power difference flags a bidirectional-budget concern, though antenna and path factors must also be included before computing exact coverage.

#### Guided practice

Design a measurement plan that can reject a visually attractive but capacity-deficient heat map.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Collect loaded airtime, retries, application tail latency and client-specific uplink/down link behavior at required locations. Compare the prediction with physical results, including AP loss. Reject any plan that misses the defined percentile or coverage boundary even if its signal map looks strong.

#### Independent task

Environment: emulator

Perform an RF design comparison using bidirectional budgets, concurrent airtime demand and application-tail acceptance.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Survey claims identify predictive versus measured evidence.
- Representative clients meet the defined percentile constraint.
- Channel/power choices remain valid under degraded operation.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0241 · single · design**

Does 18 ms at 95th percentile prove the 99.9th requirement?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC comparison: Design A uses 80 MHz and achieves high single-client peak, but 4 adjacent cells share limited reuse. Design B uses 20 MHz with lower peak but more reuse. Client uplink transmit power is 12 dB below AP power. Loaded voice 95th-percentile latency is 18 ms, 99.9th-percentile is 140 ms; requirement is below 50 ms at 99.9th.

1. Yes, any percentile is equivalent
2. Yes, strong RSSI overrides latency
3. No

**Correct option(s):** 3

- Option 1: Incorrect. Percentiles describe different tail portions.
- Option 2: Incorrect. The application limit remains.
- Option 3: Correct. The supplied 99.9th value is 140 ms, above 50 ms.

**NETWORK-ENGINEERING-Q0242 · single · diagnosis**

Why might 20 MHz outperform 80 MHz at site scale?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC comparison: Design A uses 80 MHz and achieves high single-client peak, but 4 adjacent cells share limited reuse. Design B uses 20 MHz with lower peak but more reuse. Client uplink transmit power is 12 dB below AP power. Loaded voice 95th-percentile latency is 18 ms, 99.9th-percentile is 140 ms; requirement is below 50 ms at 99.9th.

1. Narrow channels always have higher PHY rate
2. Improved channel reuse can offset lower per-client peak
3. Channel width does not affect reuse

**Correct option(s):** 2

- Option 1: Incorrect. That is not the claim.
- Option 2: Correct. Concurrent cells share spectrum.
- Option 3: Incorrect. It does.

**NETWORK-ENGINEERING-Q0243 · single · implementation**

What does the 12 dB power difference suggest?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC comparison: Design A uses 80 MHz and achieves high single-client peak, but 4 adjacent cells share limited reuse. Design B uses 20 MHz with lower peak but more reuse. Client uplink transmit power is 12 dB below AP power. Loaded voice 95th-percentile latency is 18 ms, 99.9th-percentile is 140 ms; requirement is below 50 ms at 99.9th.

1. Exactly 12 dB packet loss
2. Potential uplink/down link asymmetry
3. Guaranteed full coverage

**Correct option(s):** 2

- Option 1: Incorrect. Power difference is not packet-loss percentage.
- Option 2: Correct. Complete budgets still need antenna/path data.
- Option 3: Incorrect. The client may not reach back.

**NETWORK-ENGINEERING-Q0244 · single · implementation**

Which observation is a physical measurement?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC comparison: Design A uses 80 MHz and achieves high single-client peak, but 4 adjacent cells share limited reuse. Design B uses 20 MHz with lower peak but more reuse. Client uplink transmit power is 12 dB below AP power. Loaded voice 95th-percentile latency is 18 ms, 99.9th-percentile is 140 ms; requirement is below 50 ms at 99.9th.

1. An AP vendor's maximum rate
2. An on-site survey sample with method and location
3. A heat map generated only from plans

**Correct option(s):** 2

- Option 1: Incorrect. That is a specification, not site measurement.
- Option 2: Correct. A prediction is different evidence.
- Option 3: Incorrect. That is modeled.

**NETWORK-ENGINEERING-Q0245 · single · diagnosis**

Why include multiple client types?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC comparison: Design A uses 80 MHz and achieves high single-client peak, but 4 adjacent cells share limited reuse. Design B uses 20 MHz with lower peak but more reuse. Client uplink transmit power is 12 dB below AP power. Loaded voice 95th-percentile latency is 18 ms, 99.9th-percentile is 140 ms; requirement is below 50 ms at 99.9th.

1. All clients use identical antennas
2. Radio and power capabilities differ
3. Only server CPU matters

**Correct option(s):** 2

- Option 1: Incorrect. They do not.
- Option 2: Correct. One laptop may not represent the service.
- Option 3: Incorrect. Wireless link properties matter.

**NETWORK-ENGINEERING-Q0246 · single · implementation**

What consumes airtime besides payload?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC comparison: Design A uses 80 MHz and achieves high single-client peak, but 4 adjacent cells share limited reuse. Design B uses 20 MHz with lower peak but more reuse. Client uplink transmit power is 12 dB below AP power. Loaded voice 95th-percentile latency is 18 ms, 99.9th-percentile is 140 ms; requirement is below 50 ms at 99.9th.

1. Only wired routing updates
2. Only the application's file bytes
3. Contention, management and retries

**Correct option(s):** 3

- Option 1: Incorrect. Wireless overhead also matters.
- Option 2: Incorrect. That omits protocol work.
- Option 3: Correct. Useful throughput is below raw signaling rate.

**NETWORK-ENGINEERING-Q0247 · single · implementation**

What should an AP-loss test measure?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC comparison: Design A uses 80 MHz and achieves high single-client peak, but 4 adjacent cells share limited reuse. Design B uses 20 MHz with lower peak but more reuse. Client uplink transmit power is 12 dB below AP power. Loaded voice 95th-percentile latency is 18 ms, 99.9th-percentile is 140 ms; requirement is below 50 ms at 99.9th.

1. Only whether an SSID exists
2. Only controller uptime
3. Coverage, load, roaming and application continuity

**Correct option(s):** 3

- Option 1: Incorrect. That does not prove service.
- Option 2: Incorrect. The RF path can still fail.
- Option 3: Correct. Remaining signal alone is partial.

**NETWORK-ENGINEERING-Q0248 · single · diagnosis**

Why record background occupancy?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC comparison: Design A uses 80 MHz and achieves high single-client peak, but 4 adjacent cells share limited reuse. Design B uses 20 MHz with lower peak but more reuse. Client uplink transmit power is 12 dB below AP power. Loaded voice 95th-percentile latency is 18 ms, 99.9th-percentile is 140 ms; requirement is below 50 ms at 99.9th.

1. It replaces client counts
2. It guarantees identical future conditions
3. It affects contention and comparability

**Correct option(s):** 3

- Option 1: Incorrect. Both matter.
- Option 2: Incorrect. It is abounded observation.
- Option 3: Correct. Different load can confound design comparison.

**NETWORK-ENGINEERING-Q0249 · single · implementation**

Which choice should drive channel width?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC comparison: Design A uses 80 MHz and achieves high single-client peak, but 4 adjacent cells share limited reuse. Design B uses 20 MHz with lower peak but more reuse. Client uplink transmit power is 12 dB below AP power. Loaded voice 95th-percentile latency is 18 ms, 99.9th-percentile is 140 ms; requirement is below 50 ms at 99.9th.

1. Always narrowest without testing
2. Measured compliance with concurrent requirements
3. Always widest available

**Correct option(s):** 2

- Option 1: Incorrect. Suitability depends on requirements.
- Option 2: Correct. Peak speed alone is insufficient.
- Option 3: Incorrect. That ignores reuse.

**NETWORK-ENGINEERING-Q0250 · single · implementation**

What closes the RF comparison?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC comparison: Design A uses 80 MHz and achieves high single-client peak, but 4 adjacent cells share limited reuse. Design B uses 20 MHz with lower peak but more reuse. Client uplink transmit power is 12 dB below AP power. Loaded voice 95th-percentile latency is 18 ms, 99.9th-percentile is 140 ms; requirement is below 50 ms at 99.9th.

1. A reproducible measurement set and constraint-based decision
2. Only maximum RSSI
3. Only one empty-room speed test

**Correct option(s):** 1

- Option 1: Correct. Aesthetic heat maps are insufficient.
- Option 2: Incorrect. It omits capacity.
- Option 3: Incorrect. It omits representative concurrency.

#### Recall

**Does 18 ms at 95th percentile prove the 99.9th requirement?**

No The supplied 99.9th value is 140 ms, above 50 ms.

**Why include multiple client types?**

Radio and power capabilities differ One laptop may not represent the service.

**Which choice should drive channel width?**

Measured compliance with concurrent requirements Peak speed alone is insufficient.

#### References

- [Cisco wireless design resources](https://www.cisco.com/c/en/us/solutions/enterprise/design-zone-mobility/index.html)

## NETWORK-ENGINEERING-M26 — NAC component lab: EAP-TLS exchange and effective ISE policy

### NETWORK-ENGINEERING-L26 — NAC component lab: EAP-TLS exchange and effective ISE policy

Estimated study time: 210 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L25

### Define identities and policy before configuring ports
Build an isolated access-switch/AP, RADIUS/ISE and endpoint lab. Use a dedicated test PKI. Define three outcomes: managed compliant endpoint gets the approved production role; authenticated but non compliant endpoint gets remediation-only access; unknown or invalid identity is denied or receives an explicitly bounded exception. Write the required services in each role, including DNS, DHCP, certificate validation and remediation. A quarantine network that cannot reach its required remediation service cannot complete its intended function.

The endpoint is the supplicant, the switch/AP is the authenticator, and ISE provides the configured authentication/authorization decision. EAP travels between endpoint and authenticator and is carried through the relevant RADIUS exchange. With EAP-TLS, certificate/private-key proof and server authentication establish identity under the trust policy. Authorization then combines identity, endpoint/context attributes and policy order to choose the enforcement result. A successful TLS exchange is therefore not synonymous with production access.

### Trace one session
Record endpoint identity, certificate serial/issuer, network-device identity, session identifier, EAP method, authentication result, authorization rule and returned enforcement attributes. On the switch/AP, record the effective session role, VLAN/ACL or supported policy result and actual allowed/denied traffic. Correlate the two records by session rather than assuming that a recent ISE log belongs to the endpoint currently being tested.

A conceptual evidence trace is:

```text
Endpoint certificate: trusted, in date, intended identity
Authentication result: success
Posture state: unknown
Authorization rule: remediation-only
Authenticator session: restricted role applied
Traffic: remediation allowed; production database denied
```
This is synthetic teaching data, not literal ISE output. Reproduce the evidence with the installed vendor tools and preserve raw records.

### Certificate and outage cases
Test wrong issuer, wrong identity, expired certificate, revoked certificate and unreachable revocation service according to the chosen failure policy. The endpoint must validate the RADIUS server identity; disabling server validation to make a lab connect teaches the wrong trust boundary. Clock errors can affect validity checks, so record time quality during diagnosis.

Now interrupt the RADIUS service. Existing sessions and new admissions may behave differently according to the supported configuration. Test the explicit degraded requirement; do not allow a generic fail-open behavior to bypass the production-role conditions. For incapable devices using MAB or another exception, enforce a narrower role with owner, expiry and monitoring because a MAC address is not equivalent to certificate-backed identity.

### Role transition and recovery
After posture remediation, initiate a supported CoA or reauthentication. Verify the packet reaches the authenticator, the session changes, and the new role is effective. A policy edit in ISE does not automatically prove the live switch session changed. Test a denied action after the transition to catch an overbroad role. Finally restore the baseline and record any manual assistance so the independent assessment reflects actual capability.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. SYNTHETIC session 42: EAP-TLS succeeds, posture=unknown, ISE rule=remediation-only, returned ACL permits DNS and remediation HTTPS. Switch session 42 still uses old Production role because a CoA was blocked. A second client has wrong server trust but administrator disabled validation to connect.

**Reasoning:** The first endpoint is over-authorized at the enforcement point despite a correct new server decision. Fix the supported CoA/session transition and verify restricted traffic immediately. The second endpoint's workaround removes server authentication; restore proper trust rather than accepting the connection as a pass.

#### Guided practice

Create two negative tests: one for stale effective authorization and one for a nun trusted authentication server.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** For stale authorization, attempt a production database connection after the remediation-only decision and confirm denial only when the authenticator actually updates. For server trust, present the controlled un trusted test server and confirm the endpoint rejects it while the legitimate server still works.

#### Independent task

Environment: emulator

Build and diagnose a complete certificate-based NAC session from supplicant trust through effective authorization and role recovery.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Server and client trust are both verified.
- Effective role matches the current authorized decision.
- Outage and exception behavior cannot silently bypass required conditions.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0251 · single · implementation**

What is wrong in session 42?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC session 42: EAP-TLS succeeds, posture=unknown, ISE rule=remediation-only, returned ACL permits DNS and remediation HTTPS. Switch session 42 still uses old Production role because a CoA was blocked. A second client has wrong server trust but administrator disabled validation to connect.

1. The authenticator retains the old Production role
2. EAP-TLS necessarily failed
3. The remediation ACL is automatically unrestricted

**Correct option(s):** 1

- Option 1: Correct. Server intent and effective enforcement disagree.
- Option 2: Incorrect. Authentication succeeded.
- Option 3: Incorrect. Its stated scope is limited.

**NETWORK-ENGINEERING-Q0252 · single · implementation**

Which observation proves the policy transition completed?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC session 42: EAP-TLS succeeds, posture=unknown, ISE rule=remediation-only, returned ACL permits DNS and remediation HTTPS. Switch session 42 still uses old Production role because a CoA was blocked. A second client has wrong server trust but administrator disabled validation to connect.

1. Only certificate expiry date
2. Only the policy save timestamp
3. The live authenticator session and traffic tests

**Correct option(s):** 3

- Option 1: Incorrect. That is another dependency.
- Option 2: Incorrect. That is intent.
- Option 3: Correct. An ISE rule edit alone is insufficient.

**NETWORK-ENGINEERING-Q0253 · single · diagnosis**

Why is disabled server validation unacceptable as a fix?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC session 42: EAP-TLS succeeds, posture=unknown, ISE rule=remediation-only, returned ACL permits DNS and remediation HTTPS. Switch session 42 still uses old Production role because a CoA was blocked. A second client has wrong server trust but administrator disabled validation to connect.

1. It improves mutual authentication
2. It only changes a GUI preference
3. The endpoint no longer authenticates the intended server

**Correct option(s):** 3

- Option 1: Incorrect. It does opposite.
- Option 2: Incorrect. It changes security behavior.
- Option 3: Correct. Connectivity was obtained by removing trust.

**NETWORK-ENGINEERING-Q0254 · single · implementation**

What must remediation role permit?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC session 42: EAP-TLS succeeds, posture=unknown, ISE rule=remediation-only, returned ACL permits DNS and remediation HTTPS. Switch session 42 still uses old Production role because a CoA was blocked. A second client has wrong server trust but administrator disabled validation to connect.

1. Only services needed for controlled remediation
2. All production services permanently
3. Nothing including DNS/remediation

**Correct option(s):** 1

- Option 1: Correct. Otherwise the workflow cannot complete.
- Option 2: Incorrect. That bypasses posture conditions.
- Option 3: Incorrect. That can prevent recovery.

**NETWORK-ENGINEERING-Q0255 · single · diagnosis**

Why correlate by session identifier?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC session 42: EAP-TLS succeeds, posture=unknown, ISE rule=remediation-only, returned ACL permits DNS and remediation HTTPS. Switch session 42 still uses old Production role because a CoA was blocked. A second client has wrong server trust but administrator disabled validation to connect.

1. All endpoints always share one session
2. Session ID s grant administrator rights
3. Logs from different attempts can mislead

**Correct option(s):** 3

- Option 1: Incorrect. They do not.
- Option 2: Incorrect. They are correlation data.
- Option 3: Correct. Identity and time alone can be ambiguous.

**NETWORK-ENGINEERING-Q0256 · single · implementation**

What distinguishes MAB assurance?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC session 42: EAP-TLS succeeds, posture=unknown, ISE rule=remediation-only, returned ACL permits DNS and remediation HTTPS. Switch session 42 still uses old Production role because a CoA was blocked. A second client has wrong server trust but administrator disabled validation to connect.

1. It relies on a MAC identity that can be copied
2. It automatically uses mutual TLS
3. It eliminates exception review

**Correct option(s):** 1

- Option 1: Correct. It is weaker than certificate private-key proof.
- Option 2: Incorrect. It does not.
- Option 3: Incorrect. Weaker identity needs bounded policy.

**NETWORK-ENGINEERING-Q0257 · single · implementation**

What should RADIUS outage testing separate?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC session 42: EAP-TLS succeeds, posture=unknown, ISE rule=remediation-only, returned ACL permits DNS and remediation HTTPS. Switch session 42 still uses old Production role because a CoA was blocked. A second client has wrong server trust but administrator disabled validation to connect.

1. Only wired and wireless labels
2. Existing sessions and new admission
3. Only account names

**Correct option(s):** 2

- Option 1: Incorrect. Both still need state-specific tests.
- Option 2: Correct. Their dependencies and state differ.
- Option 3: Incorrect. Names do not show behavior.

**NETWORK-ENGINEERING-Q0258 · single · implementation**

Which result rejects a nun trusted server correctly?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC session 42: EAP-TLS succeeds, posture=unknown, ISE rule=remediation-only, returned ACL permits DNS and remediation HTTPS. Switch session 42 still uses old Production role because a CoA was blocked. A second client has wrong server trust but administrator disabled validation to connect.

1. Endpoint refuses authentication while valid server still works
2. All network access fails permanently
3. Endpoint connects to any server

**Correct option(s):** 1

- Option 1: Correct. Both negative and positive trust cases matter.
- Option 2: Incorrect. That does not prove a usable trusted design.
- Option 3: Incorrect. That removes identity assurance.

**NETWORK-ENGINEERING-Q0259 · single · diagnosis**

Why include time quality in TLS diagnosis?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC session 42: EAP-TLS succeeds, posture=unknown, ISE rule=remediation-only, returned ACL permits DNS and remediation HTTPS. Switch session 42 still uses old Production role because a CoA was blocked. A second client has wrong server trust but administrator disabled validation to connect.

1. Time changes the private key
2. Validity checks depend on clock state
3. RADIUS never uses timestamps

**Correct option(s):** 2

- Option 1: Incorrect. It does not.
- Option 2: Correct. An incorrect clock can mimic certificate expiry.
- Option 3: Incorrect. Certificate validation uses time bounds.

**NETWORK-ENGINEERING-Q0260 · single · implementation**

What closes the NAC component?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC session 42: EAP-TLS succeeds, posture=unknown, ISE rule=remediation-only, returned ACL permits DNS and remediation HTTPS. Switch session 42 still uses old Production role because a CoA was blocked. A second client has wrong server trust but administrator disabled validation to connect.

1. Only a valid client certificate
2. Identity, authorization, enforcement, negative cases and recovery evidence
3. Only installed ISE software

**Correct option(s):** 2

- Option 1: Incorrect. Effective policy can still be wrong.
- Option 2: Correct. A login result alone is incomplete.
- Option 3: Incorrect. Installation is not capability.

#### Recall

**What is wrong in session 42?**

The authenticator retains the old Production role Server intent and effective enforcement disagree.

**Why correlate by session identifier?**

Logs from different attempts can mislead Identity and time alone can be ambiguous.

**Why include time quality in TLS diagnosis?**

Validity checks depend on clock state An incorrect clock can mimic certificate expiry.

#### References

- [Cisco ISE administrator guides](https://www.cisco.com/c/en/us/support/security/identity-services-engine/products-installation-and-configuration-guides-list.html)
- [EAP-TLS 1.3](https://www.rfc-editor.org/rfc/rfc9190.html)
- [RADIUS dynamic authorization](https://www.rfc-editor.org/rfc/rfc5176.html)

## NETWORK-ENGINEERING-M27 — Hybrid component lab: route domains, NAT and DNS transaction traces

### NETWORK-ENGINEERING-L27 — Hybrid component lab: route domains, NAT and DNS transaction traces

Estimated study time: 210 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L26

### Model the boundary as a transaction
Use an isolated on-premises subnet, a simulated cloud route domain and a service endpoint. Record the client's source address, DNS resolver, returned destination, selected route, any NAT transformation, each policy boundary and the return path. Do not begin with 'the VPN is up'; begin with the service transaction that must succeed and the prohibited flows that must remain blocked.

Suppose on-premises 10.1.0.0/24 accesses private service 10.2.0.10 over a tunnel. The client resolver must return the private address for the intended namespace. The on-premises router must select the tunnel, the cloud route domain must know the client or translated source, and both sides' security controls must permit the actual tuple. If NAT changes 10.1.0.20 to 10.254.0.20, the remote policy and return route may need to refer to the translated identity. Keep the original identity in logs so investigation can trace the actor.

### DNS trace
Test through the actual client resolver chain. Record query name, type, resolver, response, TTL and whether the answer came from cache. A direct authoritative query can show correct configuration while the client still uses a public recursive resolver or cached public answer. Conditional forwarding must be narrow enough to avoid leaking unrelated internal names and must have an explicit failure behavior. Resolver redundancy can still share one WAN or identity dependency.

### Route and policy trace
For every hop, record route-table selection and next hop. Use the platform's read-only route and packet-counter tools; in a Linux namespace lab, `ip route show` and `ip rule show` help expose table/policy selection. These observations are only models of a cloud boundary unless actual provider routing/policy is also tested. Security groups, network ACLs and stateful firewalls have different scope and state behavior; no single allow overrides a denial elsewhere.

Introduce asymmetric return routing in the isolated lab. Observe whether the chosen firewall design has the required state on the return path. Do not declare all asymmetry inherently broken: the effect depends on stateful enforcement, reverse-path checks and the actual topology. The task is to show whether this design meets its requirement.

### Address overlap and recovery
If both sides use 10.90.0.0/16 for unrelated endpoints, routing alone cannot unambiguously identify the desired destination. Compare read dressing, segmentation and explicit translation with their lifecycle cost and observability consequences. A quick NAT workaround can create difficult logging and application-identity dependencies; document them rather than hiding the overlap.

Acceptance tests include correct and wrong DNS views, permitted and denied subnets, translated and untranslated flows, maximum intended packets, tunnel rekey/failure and resolver loss. Restore a known baseline after each component fault before the integrated assessment.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. SYNTHETIC flow: client 10.1.0.20 resolvesdb.private.test to 10.2.0.10. Firewall translates source to 10.254.0.20. Cloud policy permits 10.1.0.0/24 only; return route covers 10.1.0.0/24 but not 10.254.0.0/24. Tunnel counters show outbound encrypted packets and no successful application replies.

**Reasoning:** DNS and outbound tunnel transport pass, but remote policy and return routing refer to the untranslated source. Inspect the post-NAT tuple and review whether translation is intended. Correct both approved policy and return path; changing DNS would not address this evidence.

#### Guided practice

Choose evidence that distinguishes remote denial from a missing return route without disabling all security controls.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Inspect remote policy decision/counters for source 10.254.0.20 and the service port, then inspect the effective return route for 10.254.0.20. Capture at approved points to see whether a reply is generated and where it stops. Preserve narrow policy rather than permitting all traffic.

#### Independent task

Environment: emulator

Build a hybrid transaction trace that reconciles DNS, NAT, route domains, policy and return-path state.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Every boundary records the effective packet tuple.
- NAT does not obscure required actor attribution.
- Positive, negative and recovery tests pass without broad exceptions.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0261 · single · implementation**

Which source does the cloud policy actually see?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC flow: client 10.1.0.20 resolvesdb.private.test to 10.2.0.10. Firewall translates source to 10.254.0.20. Cloud policy permits 10.1.0.0/24 only; return route covers 10.1.0.0/24 but not 10.254.0.0/24. Tunnel counters show outbound encrypted packets and no successful application replies.

1. 10.1.0.20 necessarily
2. 10.2.0.10
3. 10.254.0.20

**Correct option(s):** 3

- Option 1: Incorrect. That was the pre-NAT identity.
- Option 2: Incorrect. That is the destination service.
- Option 3: Correct. The firewall translated the original source.

**NETWORK-ENGINEERING-Q0262 · single · diagnosis**

Why can the cloud deny the flow?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC flow: client 10.1.0.20 resolvesdb.private.test to 10.2.0.10. Firewall translates source to 10.254.0.20. Cloud policy permits 10.1.0.0/24 only; return route covers 10.1.0.0/24 but not 10.254.0.0/24. Tunnel counters show outbound encrypted packets and no successful application replies.

1. Its permit covers the wrong source prefix
2. The tunnel must be absent
3. DNS returned the wrong address

**Correct option(s):** 1

- Option 1: Correct. Policy must match the effective tuple.
- Option 2: Incorrect. Outbound encryption is observed.
- Option 3: Incorrect. The supplied answer is intended.

**NETWORK-ENGINEERING-Q0263 · single · implementation**

What additional return dependency is missing?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC flow: client 10.1.0.20 resolvesdb.private.test to 10.2.0.10. Firewall translates source to 10.254.0.20. Cloud policy permits 10.1.0.0/24 only; return route covers 10.1.0.0/24 but not 10.254.0.0/24. Tunnel counters show outbound encrypted packets and no successful application replies.

1. A broader client hostname
2. Another A record for the client
3. A route for the translated source

**Correct option(s):** 3

- Option 1: Incorrect. Names do not create the route.
- Option 2: Incorrect. DNS does not replace IP routing.
- Option 3: Correct. Replies must reach 10.254.0.20.

**NETWORK-ENGINEERING-Q0264 · single · diagnosis**

Why preserve pre-NAT identity in logs?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC flow: client 10.1.0.20 resolvesdb.private.test to 10.2.0.10. Firewall translates source to 10.254.0.20. Cloud policy permits 10.1.0.0/24 only; return route covers 10.1.0.0/24 but not 10.254.0.0/24. Tunnel counters show outbound encrypted packets and no successful application replies.

1. To attribute the original actor
2. To eliminate all NAT state
3. To bypass authorization

**Correct option(s):** 1

- Option 1: Correct. Translated addresses can hide ownership.
- Option 2: Incorrect. State still matters.
- Option 3: Incorrect. Logging does not grant access.

**NETWORK-ENGINEERING-Q0265 · single · implementation**

Which query tests real client DNS behavior?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC flow: client 10.1.0.20 resolvesdb.private.test to 10.2.0.10. Firewall translates source to 10.254.0.20. Cloud policy permits 10.1.0.0/24 only; return route covers 10.1.0.0/24 but not 10.254.0.0/24. Tunnel counters show outbound encrypted packets and no successful application replies.

1. The client's actual resolver chain
2. Only a different administrator's resolver
3. Only a static zone file

**Correct option(s):** 1

- Option 1: Correct. Direct authority queries may miss caching/forwarding.
- Option 2: Incorrect. Its view may differ.
- Option 3: Incorrect. That is intent, not client result.

**NETWORK-ENGINEERING-Q0266 · single · implementation**

What makes overlap difficult?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC flow: client 10.1.0.20 resolvesdb.private.test to 10.2.0.10. Firewall translates source to 10.254.0.20. Cloud policy permits 10.1.0.0/24 only; return route covers 10.1.0.0/24 but not 10.254.0.0/24. Tunnel counters show outbound encrypted packets and no successful application replies.

1. NAT always has zero cost
2. Two unrelated endpoints claim the same address space
3. Private addresses are never rou table

**Correct option(s):** 2

- Option 1: Incorrect. It adds state and observability effects.
- Option 2: Correct. Routing needs unambiguous scope.
- Option 3: Incorrect. They can be routed privately.

**NETWORK-ENGINEERING-Q0267 · single · implementation**

When can asymmetry matter?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC flow: client 10.1.0.20 resolvesdb.private.test to 10.2.0.10. Firewall translates source to 10.254.0.20. Cloud policy permits 10.1.0.0/24 only; return route covers 10.1.0.0/24 but not 10.254.0.0/24. Tunnel counters show outbound encrypted packets and no successful application replies.

1. When state or validation depends on the forward path
2. It always breaks every packet
3. It never affects firewalls

**Correct option(s):** 1

- Option 1: Correct. The design must be examined.
- Option 2: Incorrect. Some designs allow it.
- Option 3: Incorrect. Stateful enforcement can depend on path.

**NETWORK-ENGINEERING-Q0268 · single · implementation**

What does encrypted outbound count not prove?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC flow: client 10.1.0.20 resolvesdb.private.test to 10.2.0.10. Firewall translates source to 10.254.0.20. Cloud policy permits 10.1.0.0/24 only; return route covers 10.1.0.0/24 but not 10.254.0.0/24. Tunnel counters show outbound encrypted packets and no successful application replies.

1. Some packet entered encryption
2. The tunnel processed outbound traffic
3. Successful remote application delivery

**Correct option(s):** 3

- Option 1: Incorrect. That is the counter's scope.
- Option 2: Incorrect. That is observed.
- Option 3: Correct. Policy and return routing remain.

**NETWORK-ENGINEERING-Q0269 · single · implementation**

Which repair is appropriately narrow?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC flow: client 10.1.0.20 resolvesdb.private.test to 10.2.0.10. Firewall translates source to 10.254.0.20. Cloud policy permits 10.1.0.0/24 only; return route covers 10.1.0.0/24 but not 10.254.0.0/24. Tunnel counters show outbound encrypted packets and no successful application replies.

1. Change all DNS names
2. Permit every prefix everywhere
3. Align intended NAT, remote policy and return route

**Correct option(s):** 3

- Option 1: Incorrect. That does not address source translation.
- Option 2: Incorrect. That drops isolation.
- Option 3: Correct. All must agree on the approved tuple.

**NETWORK-ENGINEERING-Q0270 · single · implementation**

What closes the hybrid component?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC flow: client 10.1.0.20 resolvesdb.private.test to 10.2.0.10. Firewall translates source to 10.254.0.20. Cloud policy permits 10.1.0.0/24 only; return route covers 10.1.0.0/24 but not 10.254.0.0/24. Tunnel counters show outbound encrypted packets and no successful application replies.

1. Only an up VPN
2. A complete bidirectional transaction and negative boundary tests
3. Only a cloud allow rule

**Correct option(s):** 2

- Option 1: Incorrect. It omits semantics.
- Option 2: Correct. Tunnel status alone is insufficient.
- Option 3: Incorrect. Return routing can still fail.

#### Recall

**Which source does the cloud policy actually see?**

10.254.0.20 The firewall translated the original source.

**Which query tests real client DNS behavior?**

The client's actual resolver chain Direct authority queries may miss caching/forwarding.

**Which repair is appropriately narrow?**

Align intended NAT, remote policy and return route All must agree on the approved tuple.

#### References

- [IPsec architecture](https://www.rfc-editor.org/rfc/rfc4301.html)
- [DNS concepts](https://www.rfc-editor.org/rfc/rfc1034.html)
- [NAT behavioral requirements](https://www.rfc-editor.org/rfc/rfc4787.html)

## NETWORK-ENGINEERING-M28 — AI fabric component lab: RDMA state, locality and straggler diagnosis

### NETWORK-ENGINEERING-L28 — AI fabric component lab: RDMA state, locality and straggler diagnosis

Estimated study time: 210 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L27

### Separate application, endpoint and fabric state
An RDMA application uses registered memory, access permissions, queue-pair state and completion handling through the supported adapter/software stack. The network transports operations but does not decide whether the application registered the correct memory or supplied valid access information. A remote-access error and a congestion timeout can look like the same failed job at a high level while requiring different repairs.

Build an isolated two-host component test before an eight-worker collective. Pin adapter, driver, firmware, operating-system and RDMA library versions. Record NIC-to-CPU/NUMA and NIC-to-GPU locality, PCIe width/speed and supported memory paths. A fabric upgrade cannot fix a host link that negotiated below its intended PCIe width. Conversely, a fast host-local copy does not prove the network path is healthy.

### Queue and completion reasoning
A queue pair has required state transitions and connection parameters for the chosen transport. Posted work produces completion/error information according to the operation and configuration. Interpret the status and which side reported it. A request can fail before useful network transfer if memory registration or access keys are wrong. Do not respond to every completion error by increasing switch buffers.

A conceptual diagnostic matrix is:

| Observation | First discriminating check |
|---|---|
| Local memory/registration error | Endpoint registration and permissions |
| Only one peer pair fails | Peer parameters, path and partition/policy |
| Every transfer through one host is slow | Host locality, PCIe, NIC and driver |
| Many flows stall with pause growth | Congestion and shared queue dependencies |
| Collective stalls despite good pairwise tests | Placement, concurrency and straggler behavior |

The matrix narrows hypotheses; it does not declare a root cause without further evidence.

### Workload-aware experiment
Run a known-good pairwise transfer with controlled size and direction. Vary one factor at a time: host locality, peer, path or concurrency. Capture completion status, latency, throughput, adapter errors and switch class counters. Then run a representative collective with the same placement and track per-worker progress. Averages can hide the one participant that gates the job.

For RoCE, verify actual marking, ECN/PFC policy and endpoint reaction on the supported stack. For InfiniBand, independently verify subnet management, partition membership, link width/speed and routing. One branch's passing result is not evidence for the other. Keep each fault campaign separate before combining them.

Test degraded capacity and management/control traffic concurrently. Acceptance is useful job completion within constraints, with known isolation and recovery. Label an analytical packet/queue model as such; hardware timing and GPU direct behavior require actual supported equipment.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. SYNTHETIC evidence: H 1↔H 2 pairwise RDMA passes. Every pair involving H 3 is slow; H 3 PCIe link negotiates x 4 where approved design expects x 16. H 4 reports remote access error before transfer; its registered memory key changed. Under 8-worker load, one leaf's priority mapping differs and pause duration rises. These are three separate faults.

**Reasoning:** H 3 suggests a host-path bottleneck; H 4's error points to endpoint access state; the load-dependent pause problem requires fabric classification/congestion analysis. Global buffer tuning would not repair all three. Confirm each hypothesis with one controlled experiment before an integrated retest.

#### Guided practice

Choose one discriminating test per fault and define the expected observation if the hypothesis is wrong.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** For H 3 compare local PCIe/NIC performance and an approved known-goods lot/configuration; if unchanged, continue host/driver analysis. For H 4 validate key/registration and completion status; persistent error after correct registration demands another endpoint check. For the leaf compare actual markings and class counters under identical load; no association with mapping would weaken that hypothesis.

#### Independent task

Environment: emulator

Diagnose an AI training network through endpoint state, physical locality, congestion and collective behavior.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Endpoint programming errors are separated from network faults.
- RoCE and InfiniBand claims retain separate evidence.
- Collective acceptance includes stragglers and degraded operation.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0271 · single · diagnosis**

Which evidence points first to H 3's host path?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC evidence: H 1↔H 2 pairwise RDMA passes. Every pair involving H 3 is slow; H 3 PCIe link negotiates x 4 where approved design expects x 16. H 4 reports remote access error before transfer; its registered memory key changed. Under 8-worker load, one leaf's priority mapping differs and pause duration rises. These are three separate faults.

1. All H 3 pairs are slow and PCIe width is reduced
2. Only one global BGP session
3. A valid memory key on H 4

**Correct option(s):** 1

- Option 1: Correct. The common factor is H 3's local path.
- Option 2: Incorrect. No such fault is supplied.
- Option 3: Incorrect. That is another host.

**NETWORK-ENGINEERING-Q0272 · single · implementation**

What should H 4's remote access error trigger?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC evidence: H 1↔H 2 pairwise RDMA passes. Every pair involving H 3 is slow; H 3 PCIe link negotiates x 4 where approved design expects x 16. H 4 reports remote access error before transfer; its registered memory key changed. Under 8-worker load, one leaf's priority mapping differs and pause duration rises. These are three separate faults.

1. Registration, key and permission checks
2. Rebuilding every IB partition
3. Immediate PFC increase everywhere

**Correct option(s):** 1

- Option 1: Correct. The operation can fail before useful transfer.
- Option 2: Incorrect. The error is endpoint-specific in this evidence.
- Option 3: Incorrect. That does not fix memory authority.

**NETWORK-ENGINEERING-Q0273 · single · diagnosis**

Why can good pairwise tests not prove collective performance?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC evidence: H 1↔H 2 pairwise RDMA passes. Every pair involving H 3 is slow; H 3 PCIe link negotiates x 4 where approved design expects x 16. H 4 reports remote access error before transfer; its registered memory key changed. Under 8-worker load, one leaf's priority mapping differs and pause duration rises. These are three separate faults.

1. Collectives never use networks
2. Concurrency and synchronization add dependencies
3. Pairwise results are always meaningless

**Correct option(s):** 2

- Option 1: Incorrect. They do.
- Option 2: Correct. A straggler can gate completion.
- Option 3: Incorrect. They are useful component evidence.

**NETWORK-ENGINEERING-Q0274 · single · implementation**

Which variable must remain controlled in a comparison?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC evidence: H 1↔H 2 pairwise RDMA passes. Every pair involving H 3 is slow; H 3 PCIe link negotiates x 4 where approved design expects x 16. H 4 reports remote access error before transfer; its registered memory key changed. Under 8-worker load, one leaf's priority mapping differs and pause duration rises. These are three separate faults.

1. Only the project name
2. Only the screenshot format
3. Placement and offered workload

**Correct option(s):** 3

- Option 1: Incorrect. It does not affect performance.
- Option 2: Incorrect. It is not the experimental variable.
- Option 3: Correct. Otherwise causality is confounded.

**NETWORK-ENGINEERING-Q0275 · single · implementation**

What does lower PCIe width change?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC evidence: H 1↔H 2 pairwise RDMA passes. Every pair involving H 3 is slow; H 3 PCIe link negotiates x 4 where approved design expects x 16. H 4 reports remote access error before transfer; its registered memory key changed. Under 8-worker load, one leaf's priority mapping differs and pause duration rises. These are three separate faults.

1. Every switch'sport rate
2. Potential host-to-adapter capacity
3. The application's authorization automatically

**Correct option(s):** 2

- Option 1: Incorrect. It is a host link.
- Option 2: Correct. The bottleneck can precede the fabric.
- Option 3: Incorrect. Bandwidth and authority differ.

**NETWORK-ENGINEERING-Q0276 · single · diagnosis**

Why separate RoCE and IB evidence?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC evidence: H 1↔H 2 pairwise RDMA passes. Every pair involving H 3 is slow; H 3 PCIe link negotiates x 4 where approved design expects x 16. H 4 reports remote access error before transfer; its registered memory key changed. Under 8-worker load, one leaf's priority mapping differs and pause duration rises. These are three separate faults.

1. Their management and transport mechanisms differ
2. Neither needs endpoint state
3. Both use identical subnet managers

**Correct option(s):** 1

- Option 1: Correct. One passing branch cannot stand for both.
- Option 2: Incorrect. Both do.
- Option 3: Incorrect. They do not.

**NETWORK-ENGINEERING-Q0277 · single · implementation**

What should completion status interpretation include?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC evidence: H 1↔H 2 pairwise RDMA passes. Every pair involving H 3 is slow; H 3 PCIe link negotiates x 4 where approved design expects x 16. H 4 reports remote access error before transfer; its registered memory key changed. Under 8-worker load, one leaf's priority mapping differs and pause duration rises. These are three separate faults.

1. Only total job duration
2. Operation, reporting side and endpoint state
3. Only switch temperature

**Correct option(s):** 2

- Option 1: Incorrect. That is downstream impact.
- Option 2: Correct. A generic failed-job label is too coarse.
- Option 3: Incorrect. It cannot decode the operation error.

**NETWORK-ENGINEERING-Q0278 · single · implementation**

What observation connects the leaf policy to failing load?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC evidence: H 1↔H 2 pairwise RDMA passes. Every pair involving H 3 is slow; H 3 PCIe link negotiates x 4 where approved design expects x 16. H 4 reports remote access error before transfer; its registered memory key changed. Under 8-worker load, one leaf's priority mapping differs and pause duration rises. These are three separate faults.

1. Only a configured queue label
2. Only ping at idle
3. Actual class mapping and pause behavior under controlled concurrency

**Correct option(s):** 3

- Option 1: Incorrect. It shows intent.
- Option 2: Incorrect. It omits the workload.
- Option 3: Correct. Policy name alone is insufficient.

**NETWORK-ENGINEERING-Q0279 · single · implementation**

What does a queue model not establish?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC evidence: H 1↔H 2 pairwise RDMA passes. Every pair involving H 3 is slow; H 3 PCIe link negotiates x 4 where approved design expects x 16. H 4 reports remote access error before transfer; its registered memory key changed. Under 8-worker load, one leaf's priority mapping differs and pause duration rises. These are three separate faults.

1. Actual hardware timing and GPU path behavior
2. A reasoned hypothesis
3. A calculable backlog scenario

**Correct option(s):** 1

- Option 1: Correct. Simulation fidelity is bounded.
- Option 2: Incorrect. Models can provide that.
- Option 3: Incorrect. That is valid model work.

**NETWORK-ENGINEERING-Q0280 · single · implementation**

What closes the AI component?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC evidence: H 1↔H 2 pairwise RDMA passes. Every pair involving H 3 is slow; H 3 PCIe link negotiates x 4 where approved design expects x 16. H 4 reports remote access error before transfer; its registered memory key changed. Under 8-worker load, one leaf's priority mapping differs and pause duration rises. These are three separate faults.

1. Only enabling RDMA
2. Only a link-speed label
3. Endpoint, fabric and collective tests with failure recovery

**Correct option(s):** 3

- Option 1: Incorrect. Configuration is not demonstrated function.
- Option 2: Incorrect. It is not workload evidence.
- Option 3: Correct. Peak throughput alone is partial.

#### Recall

**Which evidence points first to H 3's host path?**

All H 3 pairs are slow and PCIe width is reduced The common factor is H 3's local path.

**What does lower PCIe width change?**

Potential host-to-adapter capacity The bottleneck can precede the fabric.

**What does a queue model not establish?**

Actual hardware timing and GPU path behavior Simulation fidelity is bounded.

#### References

- [NVIDIA RDMA programming guide](https://networking-docs.nvidia.com/rdmaawareprogramming)
- [NVIDIA networking documentation](https://docs.nvidia.com/networking/)

## NETWORK-ENGINEERING-M29 — Controls serial component lab: RS-485 timing, framing and gateway limits

### NETWORK-ENGINEERING-L29 — Controls serial component lab: RS-485 timing, framing and gateway limits

Estimated study time: 210 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L28

### Define the physical and protocol layers separately
RS-485 describes an electrical signaling arrangement, not a complete application protocol. Modbus RTU and BACnet MS/TP add their own addressing, framing, timing and bus-access behavior. A converter advertised as RS-485 does not automatically translate between those protocols. Confirm two-wire/four-wire requirements, polarity convention, reference/grounding approach, biasing, termination and isolation against the equipment documentation and site design.

Termination belongs atthe appropriate physical bus ends under the supported topology. Adding termination ate very device can load the bus incorrectly; omitting it can create reflections. Biasing must establish a defined idle condition according to the design without uncontrolled competing networks. Cable length, baud rate, stubs and environment affect signal integrity. Actual electrical measurements and safety practices require qualified physical work; a Python frame parser cannot prove the bus is healthy.

### Framing and timing model
For an asynchronous serial format with 1 start bit,8 data bits,1 parity bit and 1 stop bit, each character occupies 11 bit times. At 9600 bit/s, this is about 1.146 ms per character. A 20-character frame occupies about 22.9 ms before turnaround and inter-frame spacing. This simple model reveals why aggressive polling can consume a low-rate bus quickly. Use the actual configured format;8N1 would have 10 bits per character instead.

Modbus RTU uses timing and CRC rules to delimit and validate frames. BACnet MS/TP uses its own token and frame behavior. A correct CRC proves the frame matches its check, not that the register or object represents the correct sensor. Serial address uniqueness and gateway mapping must be verified separately.

### Gateway experiment
Build an isolated master/gateway and two test devices. Record baud, parity, stop bits, unit/device addresses and application map. Start with one read-only request at a low rate. Capture gateway IP transactions and supported serial diagnostics with correlated timestamps. Increase polling only within the calculated and measured capacity. Observe whether one offline slave causes head-of-line delay for other requests.

Inject a wrong baud setting, duplicate address and unreachable device one at a time. Predict whether the gateway remains IP-reachable, whether frames are rejected, whether timeouts occur and whether other devices suffer. Bound retries and queue length so an offline endpoint does not monopolize the segment. Restore the baseline after each test and verify freshness/quality in the final application.

The acceptance artifact includes physical inspection/test evidence, frame/timing analysis, semantic mapping and application recovery. Clearly separate an emulated serial transaction from actual voltage, wiring and noise measurements.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. SYNTHETIC bus:9600 bit/s,8 data+parity+1 stop+1 start=11 bits/character. Request 20 characters, response 40 characters, turnaround 10 ms. Ten devices are polled sequentially once per second. Gateway retries an offline device 10 times before moving on. One device has duplicate address 3.

**Reasoning:** One normal transaction occupies approximately 60×11/9600 seconds+0.010≈78.75 ms, excluding additional protocol gaps. Ten take at least 787.5 ms, leaving limited margin in one second. Ten retries against an offline device can dominate the cycle. Duplicate address 3 can create ambiguous or colliding responses independently of load.

#### Guided practice

Calculate a feasible polling plan with a bounded fault budget and state what must be measured rather than assumed.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Include request, response, turnaround, protocol gaps and worst permitted timeout/retry budget. Reduce unnecessary reads, group supported registers, stagger low-priority polls and bound retries. Measure actual device processing and bus error behavior; do not treat the ideal arithmetic as electrical validation.

#### Independent task

Environment: emulator

Engineer a serial controls segment and gateway with correct physical assumptions, bounded timing and semantic recovery.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Electrical and protocol identities are explicit.
- Normal and fault polling cycles meet freshness limits.
- Offline devices cannot cause unbounded staleness elsewhere.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0281 · single · calculation**

What is the character time under these assumptions?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC bus:9600 bit/s,8 data+parity+1 stop+1 start=11 bits/character. Request 20 characters, response 40 characters, turnaround 10 ms. Ten devices are polled sequentially once per second. Gateway retries an offline device 10 times before moving on. One device has duplicate address 3.

1. Exactly 10 ms
2. About 1.146 ms
3. About 0.104 ms

**Correct option(s):** 2

- Option 1: Incorrect. That isthe turnaround assumption.
- Option 2: Correct. 11 bits divided by 9600 bit/s.
- Option 3: Incorrect. That isone bit, not one 11-bit character.

**NETWORK-ENGINEERING-Q0282 · single · calculation**

What is the normal transaction's modeled minimum?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC bus:9600 bit/s,8 data+parity+1 stop+1 start=11 bits/character. Request 20 characters, response 40 characters, turnaround 10 ms. Ten devices are polled sequentially once per second. Gateway retries an offline device 10 times before moving on. One device has duplicate address 3.

1. About 78.75 ms
2. About 1 second
3. About 10 ms

**Correct option(s):** 1

- Option 1: Correct. 60 characters×11/9600 plus 10 ms.
- Option 2: Incorrect. That does not follow the supplied frame lengths.
- Option 3: Incorrect. That omits transmission.

**NETWORK-ENGINEERING-Q0283 · single · diagnosis**

Why is ten-device 1 Hz polling tight?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC bus:9600 bit/s,8 data+parity+1 stop+1 start=11 bits/character. Request 20 characters, response 40 characters, turnaround 10 ms. Ten devices are polled sequentially once per second. Gateway retries an offline device 10 times before moving on. One device has duplicate address 3.

1. Normal traffic uses at least 787.5 ms
2. 9600 bit/s means 9600 transactions/s
3. Every device polls simultaneously without contention

**Correct option(s):** 1

- Option 1: Correct. Gaps, retries and processing need additional margin.
- Option 2: Incorrect. Bits are not transactions.
- Option 3: Incorrect. The case is sequential.

**NETWORK-ENGINEERING-Q0284 · single · calculation**

What is the risk often retries?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC bus:9600 bit/s,8 data+parity+1 stop+1 start=11 bits/character. Request 20 characters, response 40 characters, turnaround 10 ms. Ten devices are polled sequentially once per second. Gateway retries an offline device 10 times before moving on. One device has duplicate address 3.

1. Retries always improve all freshness
2. One offline endpoint can monopolize the cycle
3. An offline endpoint produces valid data

**Correct option(s):** 2

- Option 1: Incorrect. They consume time.
- Option 2: Correct. Freshness of others can fail.
- Option 3: Incorrect. It does not.

**NETWORK-ENGINEERING-Q0285 · single · implementation**

What does RS-485 not define by itself?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC bus:9600 bit/s,8 data+parity+1 stop+1 start=11 bits/character. Request 20 characters, response 40 characters, turnaround 10 ms. Ten devices are polled sequentially once per second. Gateway retries an offline device 10 times before moving on. One device has duplicate address 3.

1. Differential electrical signaling
2. The application protocol and point map
3. Relevant physical interface constraints

**Correct option(s):** 2

- Option 1: Incorrect. That is its scope.
- Option 2: Correct. Electrical signaling is not complete semantics.
- Option 3: Incorrect. Those are part of the design.

**NETWORK-ENGINEERING-Q0286 · single · diagnosis**

Why not terminate every device blindly?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC bus:9600 bit/s,8 data+parity+1 stop+1 start=11 bits/character. Request 20 characters, response 40 characters, turnaround 10 ms. Ten devices are polled sequentially once per second. Gateway retries an offline device 10 times before moving on. One device has duplicate address 3.

1. Termination assigns slave addresses
2. Excess termination can load the bus
3. Termination is never needed

**Correct option(s):** 2

- Option 1: Incorrect. It does not.
- Option 2: Correct. Placement must match topology and guidance.
- Option 3: Incorrect. It can be necessary.

**NETWORK-ENGINEERING-Q0287 · single · implementation**

What does a valid CRC not prove?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC bus:9600 bit/s,8 data+parity+1 stop+1 start=11 bits/character. Request 20 characters, response 40 characters, turnaround 10 ms. Ten devices are polled sequentially once per second. Gateway retries an offline device 10 times before moving on. One device has duplicate address 3.

1. That a check was computed
2. Correct physical meaning of the value
3. Frame check consistency

**Correct option(s):** 2

- Option 1: Incorrect. It can establish that.
- Option 2: Correct. Mapping and sensor correctness remain.
- Option 3: Incorrect. That is its function.

**NETWORK-ENGINEERING-Q0288 · single · diagnosis**

What does duplicate address 3 cause?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC bus:9600 bit/s,8 data+parity+1 stop+1 start=11 bits/character. Request 20 characters, response 40 characters, turnaround 10 ms. Ten devices are polled sequentially once per second. Gateway retries an offline device 10 times before moving on. One device has duplicate address 3.

1. Automatic safe aggregation
2. More usable bandwidth
3. Ambiguous or colliding responses

**Correct option(s):** 3

- Option 1: Incorrect. The protocol does not assume one logical device.
- Option 2: Incorrect. Duplicates do not add capacity.
- Option 3: Correct. Identity uniqueness matters.

**NETWORK-ENGINEERING-Q0289 · single · implementation**

Which test requires physical equipment?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC bus:9600 bit/s,8 data+parity+1 stop+1 start=11 bits/character. Request 20 characters, response 40 characters, turnaround 10 ms. Ten devices are polled sequentially once per second. Gateway retries an offline device 10 times before moving on. One device has duplicate address 3.

1. Arithmetic transmission time
2. A written retry policy
3. Signal, wiring and noise validation

**Correct option(s):** 3

- Option 1: Incorrect. That can be calculated.
- Option 2: Incorrect. That can be designed without hardware.
- Option 3: Correct. A frame model cannot measure voltage.

**NETWORK-ENGINEERING-Q0290 · single · implementation**

What closes the serial component?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC bus:9600 bit/s,8 data+parity+1 stop+1 start=11 bits/character. Request 20 characters, response 40 characters, turnaround 10 ms. Ten devices are polled sequentially once per second. Gateway retries an offline device 10 times before moving on. One device has duplicate address 3.

1. Only a gateway socket
2. Physical, timing, mapping and freshness evidence
3. Only a correct baud label

**Correct option(s):** 2

- Option 1: Incorrect. Serial and application layers remain.
- Option 2: Correct. IP ping alone is partial.
- Option 3: Incorrect. Effective wiring and behavior still need checks.

#### Recall

**What is the character time under these assumptions?**

About 1.146 ms 11 bits divided by 9600 bit/s.

**What does RS-485 not define by itself?**

The application protocol and point map Electrical signaling is not complete semantics.

**Which test requires physical equipment?**

Signal, wiring and noise validation A frame model cannot measure voltage.

#### References

- [Modbus serial-line guide](https://www.modbus.org/file/secure/modbusoverserial.pdf)
- [BACnet information](https://bacnet.org/)

## NETWORK-ENGINEERING-M30 — WLAN component lab: mobility event traces and degraded admission

### NETWORK-ENGINEERING-L30 — WLAN component lab: mobility event traces and degraded admission

Estimated study time: 210 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L29

### Build the event trace before optimizing roaming
Use two APs, a supported controller design, an authentication service and a representative mobile client in an authorized RF lab. Record SSID/security method, client capabilities, AP channels/power, forwarding mode, client addressing and application deadline. Place a continuous sequence-numbered application stream on the client so interruption is measured atthe service layer rather than inferred from association timestamps alone.

A roam can involve scanning, target selection, authentication/key state, association, policy application and data-path update. The client participates in the decision; the controller cannot universally force every client to behave identically. Supported fast-transition mechanisms can reduce some authentication work, but compatibility and security-method assumptions must be verified. A successful association does not prove the IP address, gateway or application session remained usable.

Create an event table with client logs, AP/controller events, RADIUS events and application sequence observations. Normalize clocks and retain uncertainty. Identify the last successful packet on the old path and first successful packet on the new path; that interval is closer to the interruption requirement than a single controller's roam duration field. Also detect duplicates, out-of-order delivery and policy changes where relevant.

### Separate failure cases
Test ordinary movement first. Then independently test AP restart, controller failover, authentication-server loss and WAN isolation. In a local-forwarding/central-authentication design, established clients may continue while new clients fail admission. That is neither automatically acceptable nor automatically unacceptable: the operating requirement must specify the degraded service and security boundary.

For each case, test existing clients, new clients and clients roaming between APs. A network that keeps one idle client online can still fail every new operational device after a controller event. Conversely, a fail-open admission policy may preserve connectivity while violating identity requirements. Record both availability and authorization results.

### Recovery and maintenance
Before controller maintenance, verify the standby's software compatibility, certificates, WLAN policies, licenses and management access. A second controller address does not prove it can assume the service. Preserve an independent recovery path and supported rollback. After failback, repeat new admission and roaming because restored topology can change tunnels, policy or RF load.

The independent assessment uses an unannounced combination of client capability and failure condition. The learner must identify which stage caused the delay and propose a scoped change. Increasing AP power or disabling certificate validation is not a generic roaming repair. Acceptance requires the measured application bound, correct role and an honest account of un executed client types.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. SYNTHETIC trace: last good packet on AP 1 at 12:00:00.000; association to AP 2 completes.020; authorizationapplies.065; firstgoodapplicationpacket.090. Required interruption≤50 ms. WAN failure permits established local forwarding but new EAP sessions timeout. Standby controller has expired server certificate.

**Reasoning:** The measured application gap is 90 ms, not the 20 ms association interval, and fails the 50 ms requirement. Authorization/data-path stages need investigation. WAN loss and standby certificate expiry create independent admission risks that ordinary roaming does not resolve.

#### Guided practice

Identify which timestamps are facts and which causal conclusions need additional evidence.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** The supplied events establish a 90 ms service gap and their recorded order, subject to clock quality. They suggest post-association delay, but packet/policy traces are needed to locate the exact 45 ms authorization interval and 25 ms post authorization gap. Do not assign all 90 ms to RF scanning without evidence.

#### Independent task

Environment: emulator

Diagnose WLAN mobility and degraded admission through a multi-source event trace and application acceptance.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Roam interruption is measured atthe application.
- Existing, new and roaming clients are tested during failures.
- Standby trust and policy a revalidated before maintenance.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0291 · single · calculation**

What is the application interruption?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC trace: last good packet on AP 1 at 12:00:00.000; association to AP 2 completes.020; authorizationapplies.065; firstgoodapplicationpacket.090. Required interruption≤50 ms. WAN failure permits established local forwarding but new EAP sessions timeout. Standby controller has expired server certificate.

1. 90 ms
2. 45 ms
3. 20 ms

**Correct option(s):** 1

- Option 1: Correct. First good at.090 minus last good at.000.
- Option 2: Incorrect. That is one intermediate interval.
- Option 3: Incorrect. That is association completion only.

**NETWORK-ENGINEERING-Q0292 · single · implementation**

Does association at 20 ms prove the 50 ms service bound?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC trace: last good packet on AP 1 at 12:00:00.000; association to AP 2 completes.020; authorizationapplies.065; firstgoodapplicationpacket.090. Required interruption≤50 ms. WAN failure permits established local forwarding but new EAP sessions timeout. Standby controller has expired server certificate.

1. No
2. Yes, association is the whole application
3. Yes, authorization does not affect data

**Correct option(s):** 1

- Option 1: Correct. Useful traffic resumes at 90 ms.
- Option 2: Incorrect. It isone stage.
- Option 3: Incorrect. It can.

**NETWORK-ENGINEERING-Q0293 · single · implementation**

What does WAN failure distinguish?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC trace: last good packet on AP 1 at 12:00:00.000; association to AP 2 completes.020; authorizationapplies.065; firstgoodapplicationpacket.090. Required interruption≤50 ms. WAN failure permits established local forwarding but new EAP sessions timeout. Standby controller has expired server certificate.

1. Only AP power levels
2. Established forwarding from new admission
3. All clients have identical state

**Correct option(s):** 2

- Option 1: Incorrect. That is not the given effect.
- Option 2: Correct. Their dependencies differ.
- Option 3: Incorrect. Existing and new sessions differ.

**NETWORK-ENGINEERING-Q0294 · single · diagnosis**

Why inspect the standby certificate during WLAN failover?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC trace: last good packet on AP 1 at 12:00:00.000; association to AP 2 completes.020; authorizationapplies.065; firstgoodapplicationpacket.090. Required interruption≤50 ms. WAN failure permits established local forwarding but new EAP sessions timeout. Standby controller has expired server certificate.

1. Certificates only affect dashboards
2. Failover may break trusted admission
3. An expired certificate is always ignored

**Correct option(s):** 2

- Option 1: Incorrect. They can authenticate services.
- Option 2: Correct. Standby reachability is insufficient.
- Option 3: Incorrect. Clients may reject it.

**NETWORK-ENGINEERING-Q0295 · single · diagnosis**

Which claim needs more evidence?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC trace: last good packet on AP 1 at 12:00:00.000; association to AP 2 completes.020; authorizationapplies.065; firstgoodapplicationpacket.090. Required interruption≤50 ms. WAN failure permits established local forwarding but new EAP sessions timeout. Standby controller has expired server certificate.

1. The measured gap is 90 ms
2. Association completed at.020
3. All 90 ms came from RF scanning

**Correct option(s):** 3

- Option 1: Incorrect. That follows from the timestamps.
- Option 2: Incorrect. That is a supplied event.
- Option 3: Correct. The timeline includes authorization and datapath stages.

**NETWORK-ENGINEERING-Q0296 · single · diagnosis**

Why include new-client testing after failback?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC trace: last good packet on AP 1 at 12:00:00.000; association to AP 2 completes.020; authorizationapplies.065; firstgoodapplicationpacket.090. Required interruption≤50 ms. WAN failure permits established local forwarding but new EAP sessions timeout. Standby controller has expired server certificate.

1. Restored infrastructure may fail admission
2. Failback never changes policy
3. Only roaming clients need authentication

**Correct option(s):** 1

- Option 1: Correct. Existing sessions can hide such faults.
- Option 2: Incorrect. It can.
- Option 3: Incorrect. New clients certainly do.

**NETWORK-ENGINEERING-Q0297 · single · implementation**

What does clock normalization protect?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC trace: last good packet on AP 1 at 12:00:00.000; association to AP 2 completes.020; authorizationapplies.065; firstgoodapplicationpacket.090. Required interruption≤50 ms. WAN failure permits established local forwarding but new EAP sessions timeout. Standby controller has expired server certificate.

1. Automatic zero latency
2. Certificate private-key secrecy
3. Correct event ordering and duration interpretation

**Correct option(s):** 3

- Option 1: Incorrect. It changes analysis, not network behavior.
- Option 2: Incorrect. That is a separate control.
- Option 3: Correct. Different sources may be offset.

**NETWORK-ENGINEERING-Q0298 · single · implementation**

Which repair is not justified generically?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC trace: last good packet on AP 1 at 12:00:00.000; association to AP 2 completes.020; authorizationapplies.065; firstgoodapplicationpacket.090. Required interruption≤50 ms. WAN failure permits established local forwarding but new EAP sessions timeout. Standby controller has expired server certificate.

1. Verify AP 2 datapath installation
2. Disable server certificate validation
3. Inspect the authorization stage

**Correct option(s):** 2

- Option 1: Incorrect. Traffic resumes after association.
- Option 2: Correct. That removes trust rather than diagnosing roaming.
- Option 3: Incorrect. The timeline justifies it.

**NETWORK-ENGINEERING-Q0299 · single · implementation**

What should a fail-open decision require?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC trace: last good packet on AP 1 at 12:00:00.000; association to AP 2 completes.020; authorizationapplies.065; firstgoodapplicationpacket.090. Required interruption≤50 ms. WAN failure permits established local forwarding but new EAP sessions timeout. Standby controller has expired server certificate.

1. No logging because it is emergency
2. Explicit risk and service approval with bounded scope
3. Only a desire to reduce complaints

**Correct option(s):** 2

- Option 1: Incorrect. Accountability remains important.
- Option 2: Correct. Availability cannot silently erase identity controls.
- Option 3: Incorrect. That is not sufficient.

**NETWORK-ENGINEERING-Q0300 · single · implementation**

What closes the mobility lab?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC trace: last good packet on AP 1 at 12:00:00.000; association to AP 2 completes.020; authorizationapplies.065; firstgoodapplicationpacket.090. Required interruption≤50 ms. WAN failure permits established local forwarding but new EAP sessions timeout. Standby controller has expired server certificate.

1. Only a 20 ms association message
2. Only two APs powered on
3. Application timing, role and failure-recovery evidence

**Correct option(s):** 3

- Option 1: Incorrect. That misses the 90 ms gap.
- Option 2: Incorrect. That is not service evidence.
- Option 3: Correct. Controller event status alone is partial.

#### Recall

**What is the application interruption?**

90 ms First good at.090 minus last good at.000.

**Which claim needs more evidence?**

All 90 ms came from RF scanning The timeline includes authorization and datapath stages.

**What should a fail-open decision require?**

Explicit risk and service approval with bounded scope Availability cannot silently erase identity controls.

#### References

- [Cisco wireless controller guides](https://www.cisco.com/c/en/us/support/wireless/catalyst-9800-series-wireless-controllers/products-installation-and-configuration-guides-list.html)

## NETWORK-ENGINEERING-M31 — Device-administration component lab: TACACS+, roles and recovery

### NETWORK-ENGINEERING-L31 — Device-administration component lab: TACACS+, roles and recovery

Estimated study time: 210 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L30

### Separate access, identity, authorization and accounting
A network operator needs a reachable management path, a verified identity, permission for the requested action and a record of what happened. These are separate gates. A successful SSH login can still be followed by a denied configuration command, and a permitted command can fail operationally. Keep authentication, authorization, execution and accounting outcomes as different fields in the change record.

TACACS+ commonly supports separate administrative authentication and command authorization/accounting in supported platform designs. RADIUS is used extensively for network admission and can also serve administration in some platforms; choose based on actual supported semantics, not a protocol name preference. Protect management transport and shared secrets according to the platform guidance. The TACACS+ protocol's legacy protection properties are not equivalent to assuming a modern end-to-end TLS channel for every deployment.

### Define roles as executable tests
Create roles for viewer, network operator, automation writer and emergency administrator. For each, list exact required operations and explicitly forbidden ones. A viewer can inspect interfaces/routes but cannot change AAA, export policy or boot settings. A recovery operator may need scoped restart or rollback authority without unrestricted tenant changes. Test the actual vendor command/API granularity; a textual role name is not enforcement.

Build a positive/negative action matrix using a disposable lab device. Record the central authorization decision and the device's result. Then test central AAA unavailability separately from an explicit reject. Method-list fallback rules can treat them differently. Ensure that an attacker cannot turn a deliberate central denial into local administrator access by simply retrying another method.

### Preserve emergency authority
A break-glass path should survive the defined failure of in-band routing or central identity. Verify power, network, console and credential dependencies. Store and rotate emergency credentials under controlled procedure, and record every use. A shared account used daily is not a credible emergency control because it weakens attribution and can already be compromised.

During an AAA or management ACL change, retain a known working session, validate independent console access and test a new authorized session before closing the old one. Test denied sources and denied commands as well. Account for API tokens and automation runners; changing an interactive password does not revoke all execution authority.

The practical closeout requires fresh command/API accounting that identifies actor, target, time, operation and result without logging credentials. Simulate a collector failure and verify the operating response. Security configuration is not sufficient if ordinary maintenance or trusted recovery becomes impossible.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. SYNTHETIC roles: Viewer may read routes/interfaces; Operator may apply approved interface changes but not modify AAA; Pipeline may change only Tenant Blue. Current Viewer account can write AAA. TACACS+ server returns reject for Operator; local fallback exists. Accounting collector is unreachable, but changes continuously execute without an alert.

**Reasoning:** The Viewer role is over privileged; constrain and test it. An explicit reject must be interpreted according to the configured method semantics, not treated automatically as server failure. Accounting loss is a separate operational control failure that must be visible and handled under the approved policy.

#### Guided practice

Create a role test that proves the Pipeline cannot modify Tenant Red while a legitimate Tenant Blue change and rollback still work.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Use the actual scoped service identity, attempt a harmless authorized Blue test change in the lab, verify it and rollback, then attempt a Red operation and confirm rejection with an audit record. Do not test by using an administrator token and assuming the role name was applied.

#### Independent task

Environment: emulator

Implement independently tested device-administration roles, central AAA failure handling and accountable recovery access.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Allowed and forbidden operations match each role.
- Rejection and unavailability are tested separately.
- Emergency access and accounting failures are observable and controlled.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0301 · single · implementation**

Which role violation is supplied?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC roles: Viewer may read routes/interfaces; Operator may apply approved interface changes but not modify AAA; Pipeline may change only Tenant Blue. Current Viewer account can write AAA. TACACS+ server returns reject for Operator; local fallback exists. Accounting collector is unreachable, but changes continuously execute without an alert.

1. Operator cannot modify AAA
2. Viewer can write AAA
3. Pipeline is limited to Blue

**Correct option(s):** 2

- Option 1: Incorrect. That is the stated intended restriction.
- Option 2: Correct. Read-only responsibility does not require identity-policy changes.
- Option 3: Incorrect. That is appropriate scope.

**NETWORK-ENGINEERING-Q0302 · single · implementation**

What must explicit reject be kept separate from?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC roles: Viewer may read routes/interfaces; Operator may apply approved interface changes but not modify AAA; Pipeline may change only Tenant Blue. Current Viewer account can write AAA. TACACS+ server returns reject for Operator; local fallback exists. Accounting collector is unreachable, but changes continuously execute without an alert.

1. Another explicit authorization denial
2. A successful read
3. Server unavailability

**Correct option(s):** 3

- Option 1: Incorrect. That is the same category.
- Option 2: Incorrect. That is not a failure case.
- Option 3: Correct. Fallback semantics can differ.

**NETWORK-ENGINEERING-Q0303 · single · implementation**

What does a collector outage remove?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC roles: Viewer may read routes/interfaces; Operator may apply approved interface changes but not modify AAA; Pipeline may change only Tenant Blue. Current Viewer account can write AAA. TACACS+ server returns reject for Operator; local fallback exists. Accounting collector is unreachable, but changes continuously execute without an alert.

1. All identity authentication necessarily
2. Reliable current accounting delivery
3. Every device's configuration automatically

**Correct option(s):** 2

- Option 1: Incorrect. Services can fail independently.
- Option 2: Correct. Actions may occur without central records.
- Option 3: Incorrect. Logging failure does not imply that.

**NETWORK-ENGINEERING-Q0304 · single · implementation**

How should Pipeline rejection on Red be tested?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC roles: Viewer may read routes/interfaces; Operator may apply approved interface changes but not modify AAA; Pipeline may change only Tenant Blue. Current Viewer account can write AAA. TACACS+ server returns reject for Operator; local fallback exists. Accounting collector is unreachable, but changes continuously execute without an alert.

1. By allowing Red temporarily
2. Only by reading the role name
3. With the actual scoped identity

**Correct option(s):** 3

- Option 1: Incorrect. That defeats the negative case.
- Option 2: Incorrect. Names are intent.
- Option 3: Correct. An admin token would test another authority.

**NETWORK-ENGINEERING-Q0305 · single · implementation**

What does command authorization not prove?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC roles: Viewer may read routes/interfaces; Operator may apply approved interface changes but not modify AAA; Pipeline may change only Tenant Blue. Current Viewer account can write AAA. TACACS+ server returns reject for Operator; local fallback exists. Accounting collector is unreachable, but changes continuously execute without an alert.

1. Successful intended execution
2. That an authorization decision occurred
3. That a role permitted the operation

**Correct option(s):** 1

- Option 1: Correct. The command can still fail or have unintended effects.
- Option 2: Incorrect. It can establish that.
- Option 3: Incorrect. That is its scope.

**NETWORK-ENGINEERING-Q0306 · single · diagnosis**

Why retain a working session during AAA change?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC roles: Viewer may read routes/interfaces; Operator may apply approved interface changes but not modify AAA; Pipeline may change only Tenant Blue. Current Viewer account can write AAA. TACACS+ server returns reject for Operator; local fallback exists. Accounting collector is unreachable, but changes continuously execute without an alert.

1. To preserve rollback authority until new access passes
2. To avoid testing new logins
3. To bypass all future controls

**Correct option(s):** 1

- Option 1: Correct. Closing it early risks lockout.
- Option 2: Incorrect. The session does not prove them.
- Option 3: Incorrect. It is a temporary controlled recovery measure.

**NETWORK-ENGINEERING-Q0307 · single · implementation**

What should break-glass dependency analysis include?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC roles: Viewer may read routes/interfaces; Operator may apply approved interface changes but not modify AAA; Pipeline may change only Tenant Blue. Current Viewer account can write AAA. TACACS+ server returns reject for Operator; local fallback exists. Accounting collector is unreachable, but changes continuously execute without an alert.

1. Power, console, network and identity
2. Only a cabinet label
3. Only password length

**Correct option(s):** 1

- Option 1: Correct. A separate account alone is insufficient.
- Option 2: Incorrect. It does not show dependencies.
- Option 3: Incorrect. That omits availability.

**NETWORK-ENGINEERING-Q0308 · single · implementation**

Which audit field should not be stored?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC roles: Viewer may read routes/interfaces; Operator may apply approved interface changes but not modify AAA; Pipeline may change only Tenant Blue. Current Viewer account can write AAA. TACACS+ server returns reject for Operator; local fallback exists. Accounting collector is unreachable, but changes continuously execute without an alert.

1. Actor identity
2. Operation result
3. The credential secret

**Correct option(s):** 3

- Option 1: Incorrect. That is needed.
- Option 2: Incorrect. That is needed.
- Option 3: Correct. Records need attribution, not password disclosure.

**NETWORK-ENGINEERING-Q0309 · single · diagnosis**

Why include API credentials in review?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC roles: Viewer may read routes/interfaces; Operator may apply approved interface changes but not modify AAA; Pipeline may change only Tenant Blue. Current Viewer account can write AAA. TACACS+ server returns reject for Operator; local fallback exists. Accounting collector is unreachable, but changes continuously execute without an alert.

1. Only interactive users can change devices
2. APIs are always read-only
3. They are independent execution authority

**Correct option(s):** 3

- Option 1: Incorrect. Automation can do so.
- Option 2: Incorrect. They can write.
- Option 3: Correct. Password changes may not revoke tokens.

**NETWORK-ENGINEERING-Q0310 · single · implementation**

What closes the administration lab?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC roles: Viewer may read routes/interfaces; Operator may apply approved interface changes but not modify AAA; Pipeline may change only Tenant Blue. Current Viewer account can write AAA. TACACS+ server returns reject for Operator; local fallback exists. Accounting collector is unreachable, but changes continuously execute without an alert.

1. Only central AAA uptime
2. Role, denial, outage, recovery and accounting evidence
3. Only creating four role names

**Correct option(s):** 2

- Option 1: Incorrect. Device fallback and roles remain untested.
- Option 2: Correct. Login success alone is partial.
- Option 3: Incorrect. That does not enforce permissions.

#### Recall

**Which role violation is supplied?**

Viewer can write AAA Read-only responsibility does not require identity-policy changes.

**What does command authorization not prove?**

Successful intended execution The command can still fail or have unintended effects.

**Why include API credentials in review?**

They are independent execution authority Password changes may not revoke tokens.

#### References

- [TACACS+ protocol](https://www.rfc-editor.org/rfc/rfc8907.html)
- [Cisco ISE administrator guides](https://www.cisco.com/c/en/us/support/security/identity-services-engine/products-installation-and-configuration-guides-list.html)

## NETWORK-ENGINEERING-M32 — Campus services component lab: DHCP, DNS, multicast and failure scope

### NETWORK-ENGINEERING-L32 — Campus services component lab: DHCP, DNS, multicast and failure scope

Estimated study time: 210 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L31

### Treat address and name services as part of network delivery
A campus endpoint needs more than a forwarding VLAN. It may depend on DHCP, DNS, time, authentication and application discovery before useful work begins. Build a dependency map that shows which services are local, centralized or reached through relays. A redundant distribution layer cannot preserve admission if both DHCP servers depend on one failed WAN or identity service.

DHCP relay carries client requests across a routed boundary under the supported protocol. Relay addressing and server scope selection must correspond to the client's intended subnet. A wrong relay or scope can assign an address, gateway or DNS server that is syntactically valid but operationally wrong. Protect the trust boundary against unauthorized servers using the supported access-layer controls and test legitimate relay traffic remains allowed.

DNS operation requires correct answers, freshness and availability. Split views, conditional forwarding and cache behavior can make the client's answer different from the authoritative record an administrator inspected. Measure the actual query path. A DHCP lease containing a public resolver can break private application resolution even when the private DNS servers are healthy.

### Multicast at campus scale
Separate host membership from routed distribution. IGMP/MLD reports indicate receiver interest; snooping bridges need coherent querier behavior; routed multicast needs the appropriate source-facing and outgoing state. A missing querier may not break traffic immediately because cached membership persists until aging. A unicast route change can alter RPF expectations and break multicast while ordinary unicast still works.

### Build the lab in stages
Use two access VLANs, a routed distribution pair, a DHCP/DNS service segment and a disposable multicast source/receiver. First establish addressing and name resolution for each VLAN. Record lease options, relay address, assigned scope, DNS answer and application test. Then enable the approved multicast distribution and record source/group, membership, RPF and receiver sequence state.

Inject an unauthorized DHCP server only in an isolated lab and confirm containment. Change one relay/scope mapping and observe whether clients receive wrong configuration or fail admission. Remove the querier and observe the full aging interval. Finally withdraw a distribution path and test new leases, renewals, DNS queries and multicast delivery separately. Existing clients can retain leases and cached answers, masking failures that affect new clients.

Acceptance includes service correctness, unauthorized-server denial, cache/lease expiration behavior and controlled recovery. Do not use an existing client's successful ping as proof that the campus can admit and support a new operational device.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. SYNTHETIC campus: VLAN 10 clients receive gateway 10.20.0.1 because relay points to wrong scope. Existing VLAN 20 clients work from cached leases. DHCP options name a public resolver that returns wrong view for plant.private.test. Multicast querier is removed; receivers work for 3 minutes then stop as membership ages.

**Reasoning:** The wrong scope causes invalid gateway selection for VLAN 10; cached VLAN 20 operation does not prove new admission. Wrong resolver distribution is a separate name-service fault. Delayed multicast failure fits membership aging after querier loss. Test each dependency and preserve intended trust controls.

#### Guided practice

Create four tests that cannot be passed merely by an existing client's cached state.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Use a new client lease, an explicit renewal/rebind case, a DNS query after controlled cache expiry, and a multicast join after membership aging. Observe actual server/relay and querier state, then restore baseline and verify allowed service plus unauthorized-server denial.

#### Independent task

Environment: emulator

Commission campus infrastructure services with correct relay, namespace, membership and new-client recovery behavior.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- New and existing clients receive correct network parameters.
- Unauthorized service offers are contained.
- Multicast and name-service freshness are tested through failure.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0311 · single · diagnosis**

Why is gateway 10.20.0.1 wrong for VLAN 10?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC campus: VLAN 10 clients receive gateway 10.20.0.1 because relay points to wrong scope. Existing VLAN 20 clients work from cached leases. DHCP options name a public resolver that returns wrong view for plant.private.test. Multicast querier is removed; receivers work for 3 minutes then stop as membership ages.

1. The client must ignore all gateways
2. All DHCP relays are unsupported
3. Relay/scope mapping selects another subnet's parameters

**Correct option(s):** 3

- Option 1: Incorrect. It needs the intended one.
- Option 2: Incorrect. Relays are standard mechanisms.
- Option 3: Correct. A valid address format does not imply correct assignment.

**NETWORK-ENGINEERING-Q0312 · single · implementation**

What do cached VLAN 20 leases hide?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC campus: VLAN 10 clients receive gateway 10.20.0.1 because relay points to wrong scope. Existing VLAN 20 clients work from cached leases. DHCP options name a public resolver that returns wrong view for plant.private.test. Multicast querier is removed; receivers work for 3 minutes then stop as membership ages.

1. Every physical link failure
2. All DNS answers permanently
3. Potential failure of new admission or renewal

**Correct option(s):** 3

- Option 1: Incorrect. Cached leases do not restore links.
- Option 2: Incorrect. Caches have bounded lifetimes.
- Option 3: Correct. Existing configuration can outlive service failure.

**NETWORK-ENGINEERING-Q0313 · single · diagnosis**

Why can healthy private DNS still be unused?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC campus: VLAN 10 clients receive gateway 10.20.0.1 because relay points to wrong scope. Existing VLAN 20 clients work from cached leases. DHCP options name a public resolver that returns wrong view for plant.private.test. Multicast querier is removed; receivers work for 3 minutes then stop as membership ages.

1. DNS servers automatically override all leases
2. DHCP distributes a different resolver
3. Private names cannot be queried

**Correct option(s):** 2

- Option 1: Incorrect. They do not.
- Option 2: Correct. Clients follow their effective configuration.
- Option 3: Incorrect. They can through appropriate resolver s.

**NETWORK-ENGINEERING-Q0314 · single · diagnosis**

Why did multicast stop after 3 minutes rather than immediately?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC campus: VLAN 10 clients receive gateway 10.20.0.1 because relay points to wrong scope. Existing VLAN 20 clients work from cached leases. DHCP options name a public resolver that returns wrong view for plant.private.test. Multicast querier is removed; receivers work for 3 minutes then stop as membership ages.

1. Membership aged without the querier
2. The source changed to TCP automatically
3. Multicast always waits exactly 3 minutes

**Correct option(s):** 1

- Option 1: Correct. Retained state can mask the initiating failure.
- Option 2: Incorrect. No such transition is given.
- Option 3: Incorrect. The time is configuration-specific.

**NETWORK-ENGINEERING-Q0315 · single · implementation**

Which test checks the DHCP trust boundary?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC campus: VLAN 10 clients receive gateway 10.20.0.1 because relay points to wrong scope. Existing VLAN 20 clients work from cached leases. DHCP options name a public resolver that returns wrong view for plant.private.test. Multicast querier is removed; receivers work for 3 minutes then stop as membership ages.

1. Only ping the legitimate server
2. Only inspect lease duration
3. An isolated unauthorized-server offer

**Correct option(s):** 3

- Option 1: Incorrect. That does not test rogue offers.
- Option 2: Incorrect. That does not show trust enforcement.
- Option 3: Correct. Verify it is blocked without breaking legitimate relay.

**NETWORK-ENGINEERING-Q0316 · single · implementation**

What must a multicast RPF check use?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC campus: VLAN 10 clients receive gateway 10.20.0.1 because relay points to wrong scope. Existing VLAN 20 clients work from cached leases. DHCP options name a public resolver that returns wrong view for plant.private.test. Multicast querier is removed; receivers work for 3 minutes then stop as membership ages.

1. Only the default gateway MAC
2. The route toward the source
3. Only the route toward the group's text label

**Correct option(s):** 2

- Option 1: Incorrect. That is insufficient.
- Option 2: Correct. Receiver-facing reachability is different.
- Option 3: Incorrect. Group labels are not source routes.

**NETWORK-ENGINEERING-Q0317 · single · diagnosis**

Why test new clients during failover?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC campus: VLAN 10 clients receive gateway 10.20.0.1 because relay points to wrong scope. Existing VLAN 20 clients work from cached leases. DHCP options name a public resolver that returns wrong view for plant.private.test. Multicast querier is removed; receivers work for 3 minutes then stop as membership ages.

1. Old clients prove every dependency
2. Existing clients retain leases and caches
3. New clients never need DNS

**Correct option(s):** 2

- Option 1: Incorrect. They do not.
- Option 2: Correct. They can hide admission failure.
- Option 3: Incorrect. They often do.

**NETWORK-ENGINEERING-Q0318 · single · implementation**

Which artifact links relay to intended scope?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC campus: VLAN 10 clients receive gateway 10.20.0.1 because relay points to wrong scope. Existing VLAN 20 clients work from cached leases. DHCP options name a public resolver that returns wrong view for plant.private.test. Multicast querier is removed; receivers work for 3 minutes then stop as membership ages.

1. Only the VLAN display name
2. Client subnet, relay address and server scope mapping
3. Only the DNS zone serial

**Correct option(s):** 2

- Option 1: Incorrect. Names do not select scope universally.
- Option 2: Correct. All three must agree.
- Option 3: Incorrect. That is a separate service.

**NETWORK-ENGINEERING-Q0319 · single · implementation**

What should name-service testing preserve?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC campus: VLAN 10 clients receive gateway 10.20.0.1 because relay points to wrong scope. Existing VLAN 20 clients work from cached leases. DHCP options name a public resolver that returns wrong view for plant.private.test. Multicast querier is removed; receivers work for 3 minutes then stop as membership ages.

1. Actual client resolver path and cache context
2. Only an authoritative screenshot
3. Only successful TCP connection to port 53

**Correct option(s):** 1

- Option 1: Correct. Direct server queries may mislead.
- Option 2: Incorrect. It omits client selection.
- Option 3: Incorrect. That does not prove correct answers.

**NETWORK-ENGINEERING-Q0320 · single · implementation**

What closes the services lab?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC campus: VLAN 10 clients receive gateway 10.20.0.1 because relay points to wrong scope. Existing VLAN 20 clients work from cached leases. DHCP options name a public resolver that returns wrong view for plant.private.test. Multicast querier is removed; receivers work for 3 minutes then stop as membership ages.

1. Only two DHCP server processes
2. Correct new admission, names, multicast and negative/failure tests
3. Only an IGMP group entry

**Correct option(s):** 2

- Option 1: Incorrect. They can share dependencies.
- Option 2: Correct. Cached ping is insufficient.
- Option 3: Incorrect. It may age or have wrong forwarding.

#### Recall

**Why is gateway 10.20.0.1 wrong for VLAN 10?**

Relay/scope mapping selects another subnet's parameters A valid address format does not imply correct assignment.

**Which test checks the DHCP trust boundary?**

An isolated unauthorized-server offer Verify it is blocked without breaking legitimate relay.

**What should name-service testing preserve?**

Actual client resolver path and cache context Direct server queries may mislead.

#### References

- [DHCP](https://www.rfc-editor.org/rfc/rfc2131.html)
- [DNS concepts](https://www.rfc-editor.org/rfc/rfc1034.html)
- [IGMPv 3](https://www.rfc-editor.org/rfc/rfc3376.html)
- [PIM-SM](https://www.rfc-editor.org/rfc/rfc7761.html)

## NETWORK-ENGINEERING-M33 — Production ownership component: on-call, maintenance and measured improvement

### NETWORK-ENGINEERING-L33 — Production ownership component: on-call, maintenance and measured improvement

Estimated study time: 210 minutes before independent work. Prerequisite chapters: NETWORK-ENGINEERING-L32

### Define the service you own
An operating campaign is a sustained sequence of ordinary service, planned changes, fault diagnosis and recovery, not a single successful build. Select one campus branch, one edge/hybrid branch and one controls branch with actual authorized lab or field access. For each, record owners, service objectives, dependencies, inventory, supported software, backups, spares, monitoring and escalation boundaries. Keep the environment label explicit: emulation is not production experience.

Create a daily operating check that can find meaningful degradation: stale controls data, unexpected route advertisements, certificate expiry risk, failed redundant paths, backup failure or queue drops under load. Avoid a checklist that only confirms devices are powered on. An operator needs to know whether the data center's required function remains correct and within limits.

### Planned maintenance
Before a change, state the objective, required preconditions, affected failure domain, implementation steps, stop criteria, rollback and post checks. Verify the remaining path and capacity before withdrawing anything. Preserve independent management access. A change approved last week must be re-evaluated if current load or redundancy differs from the plan.

Execute a controlled change in the authorized environment and record each gate. A failed post check stops expansion. If rollback is needed, validate actual service after restoration rather than marking the ticket closed when a command finishes. Update the as-built and automation source only after reconciling what actually changed.

### Incident response and recovery
Use a hypothesis ledger with facts, assumptions, next tests and scope. Prefer read-only discriminating observations before broad resets. Coordinate parallel work so two operators do not change shared state in conflicting ways. For a security incident, preserve evidence and restore trust as well as availability: a backup can contain unauthorized accounts or routing policy.

Measure detection delay, diagnosis time, service interruption, recovery time and residual impact using defined start/endpoints. These are observations from this campaign, not general claims of world-class performance. Include false alarms, missed alarms and operator assistance because they affect real operability.

### Improvement and independent assessment
Choose one recurring problem and implement a bounded improvement: a semantic policy check, a better stale-data alarm, a tested spare, a clearer dependency record or a smaller change blast radius. Compare before/after under comparable conditions and record trade-offs. Do not claim benefit from a configuration change alone.

An independent reviewer selects an unfamiliar fault or change and checks the learner's diagnosis, implementation, safety/security boundaries and evidence. The final portfolio claim must match the highest actual environment and independence achieved. Certification knowledge supports this work; it does not substitute for hands-on lifecycle ownership or authorization.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. SYNTHETIC campaign: backup jobs report green but no restore test exists. Secondary WAN path has been down for 2 weeks unnoticed. Planned primary maintenance would remove all connectivity. Controls dashboard last value is healthy but source age is 20 minutes. An automation check can reject maintenance when remaining capacity or path health fails.

**Reasoning:** The current maintenance precondition fails because the secondary path is unusable. Backup status and stale health display are separate unproven recovery/observability claims. Repair and test the alternate path, execute a representative restore, and make staleness visible before claiming operational readiness.

#### Guided practice

Design a two-week lab operating campaign with one planned change, one unknown fault, one trusted restore and one measured improvement.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Define daily service observations and evidence capture; have an assessor inject a bounded fault; execute an approved maintenance plan with stop/rollback gates; restore from a reviewed backup into an isolated environment; then compare an implemented improvement using equivalent load and clear metrics. Label all results a slab evidence.

#### Independent task

Environment: emulator

Demonstrate sustained network and controls-network ownership through ordinary operation, maintenance, incident response, recovery and measured improvement.

**Packaged starter material**

- course_labs/NETWORK-ENGINEERING/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Maintenance cannot proceed on failed redundancy assumptions.
- Restoration and freshness are actually tested.
- Portfolio claims match environment, independence and observed performance.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**NETWORK-ENGINEERING-Q0321 · single · diagnosis**

Why must primary maintenance stop?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC campaign: backup jobs report green but no restore test exists. Secondary WAN path has been down for 2 weeks unnoticed. Planned primary maintenance would remove all connectivity. Controls dashboard last value is healthy but source age is 20 minutes. An automation check can reject maintenance when remaining capacity or path health fails.

1. The backup dashboard is green
2. The alternate path is already down
3. Maintenance is never allowed

**Correct option(s):** 2

- Option 1: Incorrect. That does not restore the WAN path.
- Option 2: Correct. The remaining connectivity requirement would be violated.
- Option 3: Incorrect. It is allowed when preconditions pass.

**NETWORK-ENGINEERING-Q0322 · single · implementation**

What does a green backup job not prove?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC campaign: backup jobs report green but no restore test exists. Secondary WAN path has been down for 2 weeks unnoticed. Planned primary maintenance would remove all connectivity. Controls dashboard last value is healthy but source age is 20 minutes. An automation check can reject maintenance when remaining capacity or path health fails.

1. That some backup process ran
2. That a job reported completion
3. A usable tested restore

**Correct option(s):** 3

- Option 1: Incorrect. The job record can indicate that.
- Option 2: Incorrect. It can prove that limited fact.
- Option 3: Correct. Artifact creation is not restoration.

**NETWORK-ENGINEERING-Q0323 · single · implementation**

What is wrong with the controls health claim?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC campaign: backup jobs report green but no restore test exists. Secondary WAN path has been down for 2 weeks unnoticed. Planned primary maintenance would remove all connectivity. Controls dashboard last value is healthy but source age is 20 minutes. An automation check can reject maintenance when remaining capacity or path health fails.

1. The source value is stale
2. The numeric value is necessarily false
3. Every controller is powered off

**Correct option(s):** 1

- Option 1: Correct. Last-known healthy is not current evidence.
- Option 2: Incorrect. It may coincidentally match, but freshness is unknown.
- Option 3: Incorrect. No such evidence exists.

**NETWORK-ENGINEERING-Q0324 · single · implementation**

What should an automated maintenance gate inspect?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC campaign: backup jobs report green but no restore test exists. Secondary WAN path has been down for 2 weeks unnoticed. Planned primary maintenance would remove all connectivity. Controls dashboard last value is healthy but source age is 20 minutes. An automation check can reject maintenance when remaining capacity or path health fails.

1. Only the ticket title
2. Only the calendar window
3. Actual remaining path health and capacity

**Correct option(s):** 3

- Option 1: Incorrect. It contains no live evidence.
- Option 2: Incorrect. Time approval does not establish feasibility.
- Option 3: Correct. The saved plan maybe stale.

**NETWORK-ENGINEERING-Q0325 · single · diagnosis**

Why define metric start/endpoints?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC campaign: backup jobs report green but no restore test exists. Secondary WAN path has been down for 2 weeks unnoticed. Planned primary maintenance would remove all connectivity. Controls dashboard last value is healthy but source age is 20 minutes. An automation check can reject maintenance when remaining capacity or path health fails.

1. To guarantee a fast result
2. Otherwise recovery times are ambiguous
3. To avoid recording failures

**Correct option(s):** 2

- Option 1: Incorrect. Definitions do not improve performance by themselves.
- Option 2: Correct. Boot time and service recovery differ.
- Option 3: Incorrect. Failures remain essential evidence.

**NETWORK-ENGINEERING-Q0326 · single · implementation**

What should a security restore add to availability checks?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC campaign: backup jobs report green but no restore test exists. Secondary WAN path has been down for 2 weeks unnoticed. Planned primary maintenance would remove all connectivity. Controls dashboard last value is healthy but source age is 20 minutes. An automation check can reject maintenance when remaining capacity or path health fails.

1. Trust and authority validation
2. Only a configuration filename
3. Only a faster ping

**Correct option(s):** 1

- Option 1: Correct. A backup can reintroduce compromise.
- Option 2: Incorrect. It does not prove benign state.
- Option 3: Incorrect. That omits identity.

**NETWORK-ENGINEERING-Q0327 · single · implementation**

Which improvement claim is defensible?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC campaign: backup jobs report green but no restore test exists. Secondary WAN path has been down for 2 weeks unnoticed. Planned primary maintenance would remove all connectivity. Controls dashboard last value is healthy but source age is 20 minutes. An automation check can reject maintenance when remaining capacity or path health fails.

1. Measured benefit under comparable conditions
2. All future incidents are prevented
3. The new script is automatically better

**Correct option(s):** 1

- Option 1: Correct. Implementation alone does not prove effect.
- Option 2: Incorrect. That exceeds the test scope.
- Option 3: Incorrect. It needs evidence.

**NETWORK-ENGINEERING-Q0328 · single · diagnosis**

Why retain assistance records?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC campaign: backup jobs report green but no restore test exists. Secondary WAN path has been down for 2 weeks unnoticed. Planned primary maintenance would remove all connectivity. Controls dashboard last value is healthy but source age is 20 minutes. An automation check can reject maintenance when remaining capacity or path health fails.

1. To replace actual outputs
2. They qualify independence claims
3. To disqualify all learning

**Correct option(s):** 2

- Option 1: Incorrect. It is additional context.
- Option 2: Correct. A guided task differs from independent execution.
- Option 3: Incorrect. Assistance is useful but must be labeled.

**NETWORK-ENGINEERING-Q0329 · single · implementation**

What should as-built updates reflect?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC campaign: backup jobs report green but no restore test exists. Secondary WAN path has been down for 2 weeks unnoticed. Planned primary maintenance would remove all connectivity. Controls dashboard last value is healthy but source age is 20 minutes. An automation check can reject maintenance when remaining capacity or path health fails.

1. Only the last GUI screenshot
2. Reconciled effective state
3. Only the original proposal

**Correct option(s):** 2

- Option 1: Incorrect. It may omit dependencies.
- Option 2: Correct. Intent can differ from execution.
- Option 3: Incorrect. Changes may have diverged.

**NETWORK-ENGINEERING-Q0330 · single · implementation**

What closes the operating campaign?

SYNTHETIC TEACHING DATA — not captured from equipment.
SYNTHETIC campaign: backup jobs report green but no restore test exists. Secondary WAN path has been down for 2 weeks unnoticed. Planned primary maintenance would remove all connectivity. Controls dashboard last value is healthy but source age is 20 minutes. An automation check can reject maintenance when remaining capacity or path health fails.

1. Only a production-like diagram
2. Only passing the question bank
3. Reviewed evidence across service, change, fault, recovery and improvement

**Correct option(s):** 3

- Option 1: Incorrect. A model is not field experience.
- Option 2: Incorrect. Recall is not operation.
- Option 3: Correct. One build is not full lifecycle ownership.

#### Recall

**Why must primary maintenance stop?**

The alternate path is already down The remaining connectivity requirement would be violated.

**Why define metric start/endpoints?**

Otherwise recovery times are ambiguous Boot time and service recovery differ.

**What should as-built updates reflect?**

Reconciled effective state Intent can differ from execution.

#### References

- [NIST SP 800-82 Rev 3](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [BGP operational security](https://www.rfc-editor.org/rfc/rfc7454.html)
