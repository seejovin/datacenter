# GICSP — GICSP — independent industrial cybersecurity study course

Original independent instruction and practice. Read the teaching, work the demonstrations and guided exercise, then attempt questions before reading their explanations. Independent tasks require your own evidence.

Source baseline: [GIAC public certification objectives](https://www.giac.org/certifications/global-industrial-cyber-security-professional-gicsp/) · Public objective groups checked 2026-09-19; provider supplies no numbered objective version on the page · checked 2026-09-19

Original instruction mapped to every public objective group. Authored atomic objective IDs are not GIAC IDs. Public groups do not expose a complete item-level examination blueprint or weighting; no official equivalence or readiness guarantee is asserted.

## Scope and external requirements

- No paid SANS teaching or actual GIAC questions are reproduced.

- Synthetic evidence exercises and offline programs do not replace the practical fluency required for the current registered examination.

- The provider determines examination format and award; consult the rules for the registered attempt.

- The course covers every public objective group through original teaching and assessment; public groups do not establish exhaustive private exam coverage or replace vendor-specific hands-on competence. The current public Modbus specification links were verified during final source review. FieldComm technology-page retrieval was denied during source checking, so product details require current authorised documentation.

- Pass the provider examination under the requirements for the registered attempt; this independent app does not award a GIAC credential.

- Perform the specified authorised operating-system, protocol and vendor exercises; analytical reasoning cannot establish physical, field or production competence.

- Retain curriculum-required teaching, supervised practice, independent acceptance and evidence of all nine lifecycle responsibilities in the declared D4–D7 scope.

## Preparation

Prior courses: See the knowledge prerequisites below.

- Basic IP addressing, operating-system navigation and file handling.

- Authorised isolated Windows/Linux and vendor-tool access for the external practical tasks; supplied Python labs are offline substitutes only for their declared analytical functions.

## GICSP-M01 — ICS processes, responsibilities and operating consequences

### GICSP-L001 — Physical processes, operating modes and consequences

Estimated study time: 50 minutes before independent work. Prerequisite chapters: Use the course prerequisites.

### Identify the process before choosing a control
An industrial control system observes and influences a physical process. A continuous process changes without a natural stop between individual products: a cooling loop transports heat while pumps, valves and heat rejection respond to changing load. A batch process operates through a defined recipe and phases: a chemical mixing vessel may fill, heat, mix and discharge. A discrete process changes through individual events or positions: a conveyor sorts packages or a transfer sequence changes which source supplies a load. Real facilities combine these patterns. The classification helps identify state and timing requirements; it does not assign a universal security priority.

Describe the controlled quantity, the manipulated input, disturbances, measurements and independent protections. For a cooling loop the controlled quantity might be supply temperature, manipulated input a valve position, disturbance IT heat demand and measurement a temperature transmitter. Distinguish a required service from the equipment that implements it. A historian outage can remove evidence while local temperature control continues. An output failure can affect the physical process even if dashboards and databases remain healthy. Security decisions must address both kinds of consequence.

### Modes change the meaning of an action
Normal, startup, shutdown, maintenance, degraded and emergency operation can permit different actions. A command legal during commissioning may be prohibited during normal service. A pump restart may require a permissive that was already true in steady operation but is absent after an outage. Record transitions explicitly: current mode, event, required condition, allowed action, expected feedback and next state. A state machine makes omissions visible. If communication loss is not represented, an application may accidentally retain an unsafe last command or discard an essential locally valid command.

Do not confuse a fail-safe design decision with a universal command to stop. Closing a valve can prevent one hazard and create another. Loss of cooling may require continued circulation; another process may require controlled isolation. The authorised process/safety owners define the required state and independent protection. A cybersecurity engineer translates that decision into access, monitoring, continuity and recovery requirements, then tests the interface without inventing protective settings.

### Time and integrity are process properties
A measurement is useful only if its identity, scale, time and quality are fit for the decision. “24°C” without a sensor identity and timestamp is insufficient. Late correct data can be unusable for a fast protection decision, while an inaccurate but fresh value can drive the wrong action. Define maximum age separately from network round-trip time. Include sampling, protocol scheduling, gateway queues, application processing and display. An alarm acknowledgement records operator awareness; it does not establish that the process recovered.

Translate consequences into acceptance tests. For the training process, require the local controller to maintain its approved state during loss of the supervisory server, require the operator view to mark stale data, and require unauthorised writes to remain denied after restoration. Test these separately. A green dashboard cannot prove local autonomy, and successful local control cannot prove that operators still receive necessary alarms.

### Keep scope and evidence aligned
Purdue levels describe functional organisation; they do not determine the severity of every failure. A shared identity or time service at an upper level can affect lower-level operations. Physical access, maintenance mistakes and supplier dependencies can bypass a carefully drawn network boundary. Start with the process consequence and trace every supporting dependency. The programme uses data-center examples while retaining industrial breadth: the reasoning also applies to manufacturing, energy and utilities, but real equipment requires its own process knowledge and authority.

#### Worked demonstrations

**Evidence walkthrough**

SYNTHETIC PROCESS BRIEF, not equipment observations.
Loop C1 maintains coolant supply temperature. Local controller PLC1 executes every 100 ms. BMS polls every 2 s and must mark observations older than 6 s stale. Independent protective device P1 has separate sensing/authority. Approved modes: RUN, MAINTENANCE, DEGRADED. During BMS loss, PLC1 remains in local RUN and the approved operator response uses an independent observation route. No remote override of P1 is permitted.
Events: 10:00:00 BMS acquisition stops; 10:00:08 display still shows 24.0°C as current; PLC1 continues bounded local control; a vendor proposes disabling P1 alarms to reduce incident noise.

**Reasoning:** The physical-control path and operator-observation path have different outcomes. Local RUN behaviour matches the supplied loss-of-supervisor requirement, but the display violates the six-second freshness condition. The actual 10:00:08 temperature is not established by the cached value. Preserve acquisition and controller evidence, restore trustworthy observation through the approved route and reject the proposed protective-alarm suppression: no stated authority or process justification permits it. Full recovery requires current point identity/quality, stale detection, necessary alarms and denied remote override.

#### Guided practice

Write a transition row for return from DEGRADED observation to normal operator visibility.

**Hint:** Name the enabling evidence, not merely a server-start event.

**Worked solution:** Require fresh correctly mapped observations, appropriate independent comparison, functioning required alarms and authorised access; only then record restored visibility. Keep local-control and protection results separate.

#### Independent task

Environment: analytical

Assess a batch-fill process using the same method; define the consequence of stale level data during fill and identify which independent protections remain external.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L001.json
- course_labs/GICSP/lab.py
- course_labs/GICSP/fixture.json
- course_labs/GICSP/README.md

**Evidence to produce**

- Mode/transition table
- Three measurable requirements
- Separate physical-control and observation tests

**Acceptance criteria**

- Each requirement names identity, mode and acceptance evidence.
- No protective setting or safe state is invented.
- Missing measurement remains unknown.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0001 · single · calculation**

Which supplied observation establishes that the BMS display failed its requirement?

SYNTHETIC PROCESS BRIEF, not equipment observations.
Loop C1 maintains coolant supply temperature. Local controller PLC1 executes every 100 ms. BMS polls every 2 s and must mark observations older than 6 s stale. Independent protective device P1 has separate sensing/authority. Approved modes: RUN, MAINTENANCE, DEGRADED. During BMS loss, PLC1 remains in local RUN and the approved operator response uses an independent observation route. No remote override of P1 is permitted.
Events: 10:00:00 BMS acquisition stops; 10:00:08 display still shows 24.0°C as current; PLC1 continues bounded local control; a vendor proposes disabling P1 alarms to reduce incident noise.

1. The controller executes every 100 ms.
2. P1 has separate sensing.
3. The last successful acquisition is eight seconds old while the limit is six seconds.
4. The process uses a liquid loop.

**Correct option(s):** 3

- Option 1: That is a local-control cadence, not display age.
- Option 2: Protection independence does not establish display validity.
- Option 3: Source age exceeds the explicit display-validity rule.
- Option 4: Process type alone does not prove failure.

**GICSP-Q0002 · single · diagnosis**

What can be concluded about current coolant temperature at 10:00:08?

SYNTHETIC PROCESS BRIEF, not equipment observations.
Loop C1 maintains coolant supply temperature. Local controller PLC1 executes every 100 ms. BMS polls every 2 s and must mark observations older than 6 s stale. Independent protective device P1 has separate sensing/authority. Approved modes: RUN, MAINTENANCE, DEGRADED. During BMS loss, PLC1 remains in local RUN and the approved operator response uses an independent observation route. No remote override of P1 is permitted.
Events: 10:00:00 BMS acquisition stops; 10:00:08 display still shows 24.0°C as current; PLC1 continues bounded local control; a vendor proposes disabling P1 alarms to reduce incident noise.

1. It is a new measurement because the BMS polling interval is shorter than the eight-second outage.
2. It is exactly 24.0°C because PLC1 runs.
3. It must exceed the protective threshold.
4. It is unestablished by the cached 24.0°C tile.

**Correct option(s):** 4

- Option 1: Configured polling does not create observations while acquisition has stopped.
- Option 2: Controller operation does not validate the old observation.
- Option 3: No supplied fresh measurement establishes that.
- Option 4: The record is older than the validity boundary.

**GICSP-Q0003 · single · diagnosis**

Which function is demonstrated to continue during BMS loss in this fixture?

SYNTHETIC PROCESS BRIEF, not equipment observations.
Loop C1 maintains coolant supply temperature. Local controller PLC1 executes every 100 ms. BMS polls every 2 s and must mark observations older than 6 s stale. Independent protective device P1 has separate sensing/authority. Approved modes: RUN, MAINTENANCE, DEGRADED. During BMS loss, PLC1 remains in local RUN and the approved operator response uses an independent observation route. No remote override of P1 is permitted.
Events: 10:00:00 BMS acquisition stops; 10:00:08 display still shows 24.0°C as current; PLC1 continues bounded local control; a vendor proposes disabling P1 alarms to reduce incident noise.

1. The specified local RUN control behaviour.
2. Remote protective overrides are available.
3. All historical measurements are preserved.
4. Every operator alarm reaches its destination.

**Correct option(s):** 1

- Option 1: The brief explicitly records continuing bounded local control.
- Option 2: Those overrides are prohibited.
- Option 3: Acquisition has stopped, so completeness is unresolved.
- Option 4: Alarm delivery is not demonstrated.

**GICSP-Q0004 · single · operations**

Why should the proposed suppression of P1 alarms be rejected?

SYNTHETIC PROCESS BRIEF, not equipment observations.
Loop C1 maintains coolant supply temperature. Local controller PLC1 executes every 100 ms. BMS polls every 2 s and must mark observations older than 6 s stale. Independent protective device P1 has separate sensing/authority. Approved modes: RUN, MAINTENANCE, DEGRADED. During BMS loss, PLC1 remains in local RUN and the approved operator response uses an independent observation route. No remote override of P1 is permitted.
Events: 10:00:00 BMS acquisition stops; 10:00:08 display still shows 24.0°C as current; PLC1 continues bounded local control; a vendor proposes disabling P1 alarms to reduce incident noise.

1. BMS failure proves P1 has failed.
2. A vendor can never perform any maintenance.
3. Suppressing the alarms is within the vendor’s normal diagnostic discretion.
4. It lacks the required protective authority and a justified process decision.

**Correct option(s):** 4

- Option 1: Separate sensing may still function; investigate rather than assume.
- Option 2: Authorised vendor work can be appropriate within its scope.
- Option 3: The fixture does not authorise remote override of P1 or suppression of its independent protective information.
- Option 4: Incident noise is not permission to change independent protection.

**GICSP-Q0005 · multi · design**

Which fields belong in a process-mode transition record?

SYNTHETIC PROCESS BRIEF, not equipment observations.
Loop C1 maintains coolant supply temperature. Local controller PLC1 executes every 100 ms. BMS polls every 2 s and must mark observations older than 6 s stale. Independent protective device P1 has separate sensing/authority. Approved modes: RUN, MAINTENANCE, DEGRADED. During BMS loss, PLC1 remains in local RUN and the approved operator response uses an independent observation route. No remote override of P1 is permitted.
Events: 10:00:00 BMS acquisition stops; 10:00:08 display still shows 24.0°C as current; PLC1 continues bounded local control; a vendor proposes disabling P1 alarms to reduce incident noise.

1. Permissives and expected feedback
2. Current mode and transition event
3. Allowed action and resulting mode
4. Only the IP addresses of routers

**Correct option(s):** 1, 2, 3

- Option 1: They establish conditions and evidence for the transition.
- Option 2: They identify the starting state and trigger.
- Option 3: These specify the intended state change.
- Option 4: Addresses omit process state and action semantics.

**GICSP-Q0006 · single · design**

A controller retains the last output on communication loss. Is that behaviour automatically safe?

SYNTHETIC PROCESS BRIEF, not equipment observations.
Loop C1 maintains coolant supply temperature. Local controller PLC1 executes every 100 ms. BMS polls every 2 s and must mark observations older than 6 s stale. Independent protective device P1 has separate sensing/authority. Approved modes: RUN, MAINTENANCE, DEGRADED. During BMS loss, PLC1 remains in local RUN and the approved operator response uses an independent observation route. No remote override of P1 is permitted.
Events: 10:00:00 BMS acquisition stops; 10:00:08 display still shows 24.0°C as current; PLC1 continues bounded local control; a vendor proposes disabling P1 alarms to reduce incident noise.

1. Yes, because no new command is issued.
2. Yes, because encrypting the communication path validates the held process output.
3. No; every output must become zero.
4. No; the approved process requirement determines the acceptable degraded behaviour.

**Correct option(s):** 4

- Option 1: Unchanged output can still become hazardous as conditions change.
- Option 2: Transport confidentiality does not determine whether a held output is safe in the current process state.
- Option 3: Zero is not a universal safe state.
- Option 4: A retained output can have different consequences in different processes.

**GICSP-Q0007 · single · mechanism**

What distinguishes batch-process assessment from merely listing installed devices?

SYNTHETIC PROCESS BRIEF, not equipment observations.
Loop C1 maintains coolant supply temperature. Local controller PLC1 executes every 100 ms. BMS polls every 2 s and must mark observations older than 6 s stale. Independent protective device P1 has separate sensing/authority. Approved modes: RUN, MAINTENANCE, DEGRADED. During BMS loss, PLC1 remains in local RUN and the approved operator response uses an independent observation route. No remote override of P1 is permitted.
Events: 10:00:00 BMS acquisition stops; 10:00:08 display still shows 24.0°C as current; PLC1 continues bounded local control; a vendor proposes disabling P1 alarms to reduce incident noise.

1. It treats a recipe file as physical evidence of execution.
2. It assumes every batch process is slower than every continuous process.
3. It removes the need for identity controls.
4. It evaluates phase-dependent commands, transitions and consequences.

**Correct option(s):** 4

- Option 1: A file is intention, not observed process behaviour.
- Option 2: That timing comparison is not universal.
- Option 3: Command authority remains important.
- Option 4: The same action can be acceptable in one recipe phase and wrong in another.

**GICSP-Q0008 · single · mechanism**

A fresh but incorrectly scaled sensor value is delivered on time. Which property failed?

SYNTHETIC PROCESS BRIEF, not equipment observations.
Loop C1 maintains coolant supply temperature. Local controller PLC1 executes every 100 ms. BMS polls every 2 s and must mark observations older than 6 s stale. Independent protective device P1 has separate sensing/authority. Approved modes: RUN, MAINTENANCE, DEGRADED. During BMS loss, PLC1 remains in local RUN and the approved operator response uses an independent observation route. No remote override of P1 is permitted.
Events: 10:00:00 BMS acquisition stops; 10:00:08 display still shows 24.0°C as current; PLC1 continues bounded local control; a vendor proposes disabling P1 alarms to reduce incident noise.

1. Measurement integrity/meaning despite acceptable freshness.
2. Only availability.
3. No property, because the packet arrived.
4. Only confidentiality.

**Correct option(s):** 1

- Option 1: Correct timing cannot compensate for wrong engineering scaling.
- Option 2: The value is available, but semantically wrong.
- Option 3: Delivery alone does not meet the measurement requirement.
- Option 4: No disclosure is established.

**GICSP-Q0009 · order · implementation**

Order the reasoning used to choose a bounded containment action for an unfamiliar process.

SYNTHETIC PROCESS BRIEF, not equipment observations.
Loop C1 maintains coolant supply temperature. Local controller PLC1 executes every 100 ms. BMS polls every 2 s and must mark observations older than 6 s stale. Independent protective device P1 has separate sensing/authority. Approved modes: RUN, MAINTENANCE, DEGRADED. During BMS loss, PLC1 remains in local RUN and the approved operator response uses an independent observation route. No remote override of P1 is permitted.
Events: 10:00:00 BMS acquisition stops; 10:00:08 display still shows 24.0°C as current; PLC1 continues bounded local control; a vendor proposes disabling P1 alarms to reduce incident noise.

1. Verify the resulting process/service state and record limitations
2. Compare candidate actions against local autonomy, observation and protection
3. Select the authorised option and define verification/recovery
4. Identify current mode and consequence of losing each required function

**Correct sequence:** 4, 2, 3, 1

- Option 1: Post-action evidence establishes the actual result.
- Option 2: Candidate effects must be evaluated against required functions.
- Option 3: Selection follows the comparison and authority check.
- Option 4: Process context is needed before choosing an action.

**GICSP-Q0010 · single · recovery**

What closes restoration of operator visibility?

SYNTHETIC PROCESS BRIEF, not equipment observations.
Loop C1 maintains coolant supply temperature. Local controller PLC1 executes every 100 ms. BMS polls every 2 s and must mark observations older than 6 s stale. Independent protective device P1 has separate sensing/authority. Approved modes: RUN, MAINTENANCE, DEGRADED. During BMS loss, PLC1 remains in local RUN and the approved operator response uses an independent observation route. No remote override of P1 is permitted.
Events: 10:00:00 BMS acquisition stops; 10:00:08 display still shows 24.0°C as current; PLC1 continues bounded local control; a vendor proposes disabling P1 alarms to reduce incident noise.

1. Fresh mapped data, required alarms and access checks against the stated acceptance criteria.
2. A historical chart is continuous after estimated backfill.
3. The BMS process appears in a task list.
4. The incident ticket has a closed status.

**Correct option(s):** 1

- Option 1: These verify the operational function and authority.
- Option 2: Backfill does not demonstrate timely current data.
- Option 3: A running process does not prove usable observation.
- Option 4: Administrative status is not functional evidence.

#### Recall

**Why is stop not a universal OT safe state?**

Process owners define safe/degraded behaviour; stopping a needed cooling or circulation function can create a hazard.

**What makes a measurement operationally useful?**

Correct identity, units/scaling, quality and age appropriate to the decision.

**What must be separated during an outage?**

Physical control, operator observation, independent protection and historical evidence can fail differently.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

### GICSP-L002 — Feedback control, scan timing and misleading observations

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L001

### Follow the feedback chain
A feedback loop compares a measured process variable with a desired setpoint and changes a manipulated input. A controller may sample temperature, calculate error and command a valve. The process responds with delay; the next measurement closes the loop. In an open-loop action, the command is not corrected using the relevant measured outcome. A command acknowledgement therefore has less evidential value than a verified process response. Keep command, reported actuator position and independently observed effect as different points.

A common proportional relationship is output change proportional to error, subject to the selected sign convention and limits. Integral action accumulates persistent error and can remove steady offset; derivative action responds to the rate of change and can amplify measurement noise unless implemented appropriately. Do not memorise one tuning recipe as universal. Process gain, lag, dead time, sampling and actuator limits govern useful tuning. The cybersecurity task is often to recognise an unauthorised parameter change or a measurement defect and preserve the approved loop, not to retune a plant during an incident.

### Timing changes behaviour
In a simple cyclic PLC execution model, inputs are sampled, logic is executed and outputs are updated. Actual PLCs can also have asynchronous communications, event tasks and specialised I/O; pin the product model. A 100 ms cyclic task does not guarantee every external sensor is sampled at that rate. A slow gateway may deliver a two-second-old measurement into a fast controller. If a command arrives just after the relevant input/logic phase, it may wait until a later cycle. Account for the complete observation-to-action path rather than treating CPU scan time as the end-to-end deadline.

A watchdog or task-overrun indication concerns the configured execution boundary. It is not the same as process protection, although the approved design may associate it with a defined output response. Repeated communication requests can consume shared resources on constrained devices, but a normal engineering download, a logic loop or a hardware fault can produce similar symptoms. Correlate task duration, protocol load, project changes and process observations before choosing a cause.

### Limits and modes matter
An actuator can saturate at its physical or configured limit. If integral action continues accumulating while output cannot increase, recovery may overshoot when the constraint clears. Supported anti-windup and tracking behaviour address this in the control design. Manual/automatic transfer can also create a step if the controller's internal state and actual output disagree. These are mechanisms to understand when reviewing a sequence or suspicious parameter change; they are not authority to alter controller tuning on live equipment.

Interlocks and permissives constrain actions according to approved conditions. A permissive may be required before a start; an interlock may force or inhibit an action when a condition occurs. Exact semantics are project-specific. A supervisory write should not bypass required local enforcement merely because the HMI hides an unavailable button. Test the enforcement point using safe simulated inputs and the authorised sequence.

### Diagnose the observation path
A sensor can be biased, stuck, scaled incorrectly, associated with the wrong asset or stale. A historian can hold the last value while the process changes. A compromised or faulty engineering interface can alter the reported setpoint without producing the intended actual output. Compare multiple layers: source timestamp, controller input, setpoint, calculated output, actuator feedback and independent process observation. Agreement among screens that all use the same sensor is not independent corroboration.

A robust assessment supplies a known bounded model, exercises a disturbance, injects one measurement defect, and tests the approved degraded behaviour. Preserve which signals are simulated and which are measured. Control knowledge helps recognise causal relationships and choose a discriminating observation; it does not replace qualified instrumentation, calibration or functional-safety instruction.

#### Worked demonstrations

**Evidence walkthrough**

SYNTHETIC LOW-ENERGY LOOP MODEL; no live PLC commands.
Required level: 60%. Sensor raw range: 4–20 mA represents 0–100%. Input reads 12 mA; HMI shows 75%. Controller uses raw-derived 50%, setpoint 60%, valve command 80%; valve feedback 20%. Independent simulator level rises slowly. Cyclic task: 100 ms. Gateway refresh: 2 s. Audit record: HMI scale changed from 0–100 to 0–150 yesterday; no approved change references it.

**Reasoning:** The linear conversion is (12−4)/(20−4)×100 = 50%. The HMI's 75% is consistent with the changed 0–150 scale, while the controller's input is consistent with the specified 0–100 range. This identifies a display/configuration discrepancy, not automatically a failed transmitter. Valve command 80% and feedback 20% require separate investigation of output mapping, actuator status and simulated physical response. Gateway refresh means external observation can lag several PLC cycles; a fast task does not eliminate that delay. Restore approved scaling through the controlled process and retest end-to-end meaning and access.

#### Guided practice

A controller receives a fresh packet every 100 ms, but the source timestamp advances only every two seconds. What should a freshness monitor evaluate?

**Hint:** Distinguish transport reception from source observation.

**Worked solution:** Evaluate age of the actual source measurement, preserve receive time separately and flag the unsupported claim of 100 ms physical sampling. Determine whether gateway caching is intended and whether the two-second source cadence meets the process requirement.

#### Independent task

Environment: analytical

Use a spreadsheet or an offline script to model a bounded delayed feedback loop, then inject a sensor scaling error and a stuck actuator.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L002.json
- course_labs/GICSP/lab.py
- course_labs/GICSP/fixture.json
- course_labs/GICSP/README.md

**Evidence to produce**

- Signal/units table
- Normal and defective traces
- Diagnosis and acceptance report

**Acceptance criteria**

- Source, controller and display values remain distinguishable.
- Two faults are distinguished using different observations.
- No live tuning or protective setting changes occur.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0011 · single · calculation**

What physical level corresponds to 12 mA under the specified 4–20 mA range?

SYNTHETIC LOW-ENERGY LOOP MODEL; no live PLC commands.
Required level: 60%. Sensor raw range: 4–20 mA represents 0–100%. Input reads 12 mA; HMI shows 75%. Controller uses raw-derived 50%, setpoint 60%, valve command 80%; valve feedback 20%. Independent simulator level rises slowly. Cyclic task: 100 ms. Gateway refresh: 2 s. Audit record: HMI scale changed from 0–100 to 0–150 yesterday; no approved change references it.

1. 50%
2. 12%
3. 60%
4. 75%

**Correct option(s):** 1

- Option 1: Eight mA above the lower endpoint is half of the 16 mA span.
- Option 2: Current units must be converted using both endpoints.
- Option 3: That is the setpoint, not the measured value.
- Option 4: That follows the unapproved 0–150 display scale.

**GICSP-Q0012 · single · diagnosis**

Which fault does the supplied scaling evidence most directly support?

SYNTHETIC LOW-ENERGY LOOP MODEL; no live PLC commands.
Required level: 60%. Sensor raw range: 4–20 mA represents 0–100%. Input reads 12 mA; HMI shows 75%. Controller uses raw-derived 50%, setpoint 60%, valve command 80%; valve feedback 20%. Independent simulator level rises slowly. Cyclic task: 100 ms. Gateway refresh: 2 s. Audit record: HMI scale changed from 0–100 to 0–150 yesterday; no approved change references it.

1. The network changed the current into volts.
2. The transmitter is definitely electrically failed.
3. The HMI transformation differs from the approved range.
4. The 60% setpoint must be changed to match the HMI’s 75% display.

**Correct option(s):** 3

- Option 1: No such conversion mechanism is shown.
- Option 2: No independent current measurement establishes such a failure.
- Option 3: The raw input and controller agree with the stated range; the display matches the altered range.
- Option 4: The known range mismatch explains the display; changing the setpoint would alter the intended control objective.

**GICSP-Q0013 · single · diagnosis**

Why does command 80% with feedback 20% require further investigation?

SYNTHETIC LOW-ENERGY LOOP MODEL; no live PLC commands.
Required level: 60%. Sensor raw range: 4–20 mA represents 0–100%. Input reads 12 mA; HMI shows 75%. Controller uses raw-derived 50%, setpoint 60%, valve command 80%; valve feedback 20%. Independent simulator level rises slowly. Cyclic task: 100 ms. Gateway refresh: 2 s. Audit record: HMI scale changed from 0–100 to 0–150 yesterday; no approved change references it.

1. Commanded intent and reported actuator state disagree.
2. The discrepancy proves a malicious operator.
3. The HMI scaling correction automatically repairs the valve.
4. Every valve must instantly equal its command.

**Correct option(s):** 1

- Option 1: The mismatch can arise in mapping, actuation or feedback and needs discrimination.
- Option 2: Fault cause and attribution are not established.
- Option 3: These are separate signal paths.
- Option 4: Dynamics and position feedback characteristics can create legitimate transient differences.

**GICSP-Q0014 · single · mechanism**

What does a 100 ms cyclic task establish by itself?

SYNTHETIC LOW-ENERGY LOOP MODEL; no live PLC commands.
Required level: 60%. Sensor raw range: 4–20 mA represents 0–100%. Input reads 12 mA; HMI shows 75%. Controller uses raw-derived 50%, setpoint 60%, valve command 80%; valve feedback 20%. Independent simulator level rises slowly. Cyclic task: 100 ms. Gateway refresh: 2 s. Audit record: HMI scale changed from 0–100 to 0–150 yesterday; no approved change references it.

1. Every measurement is physically renewed ten times per second.
2. Every output acts without process delay.
3. The stated task execution cadence, not end-to-end sensor freshness.
4. The loop is stable for all gains.

**Correct option(s):** 3

- Option 1: External acquisition may be slower.
- Option 2: Actuators and processes have dynamics.
- Option 3: The gateway can update much more slowly.
- Option 4: Stability depends on the complete loop.

**GICSP-Q0015 · multi · design**

Which observations help separate a stuck actuator from a stale display?

SYNTHETIC LOW-ENERGY LOOP MODEL; no live PLC commands.
Required level: 60%. Sensor raw range: 4–20 mA represents 0–100%. Input reads 12 mA; HMI shows 75%. Controller uses raw-derived 50%, setpoint 60%, valve command 80%; valve feedback 20%. Independent simulator level rises slowly. Cyclic task: 100 ms. Gateway refresh: 2 s. Audit record: HMI scale changed from 0–100 to 0–150 yesterday; no approved change references it.

1. Actuator feedback with source timestamp
2. A second screen reading the same cached tag only
3. An appropriate independent process-response observation
4. Controller command history

**Correct option(s):** 1, 3, 4

- Option 1: It tests the reported actuator state and age.
- Option 2: It repeats the same dependency rather than independently corroborating it.
- Option 3: It checks the effect beyond the shared display path.
- Option 4: It establishes what was requested and when.

**GICSP-Q0016 · single · mechanism**

Why can integral accumulation during output saturation cause trouble when the limit clears?

SYNTHETIC LOW-ENERGY LOOP MODEL; no live PLC commands.
Required level: 60%. Sensor raw range: 4–20 mA represents 0–100%. Input reads 12 mA; HMI shows 75%. Controller uses raw-derived 50%, setpoint 60%, valve command 80%; valve feedback 20%. Independent simulator level rises slowly. Cyclic task: 100 ms. Gateway refresh: 2 s. Audit record: HMI scale changed from 0–100 to 0–150 yesterday; no approved change references it.

1. Accumulated error can continue driving an excessive output until the internal state unwinds.
2. The saturated output proves the sensor range is wrong.
3. Derivative action alone stores the accumulated steady error.
4. Integral action guarantees zero overshoot.

**Correct option(s):** 1

- Option 1: This is the mechanism anti-windup designs address.
- Option 2: Saturation can occur with correct scaling; integral state can continue accumulating during the limit.
- Option 3: The integral term accumulates error; derivative action responds to its rate of change.
- Option 4: It does not provide that guarantee.

**GICSP-Q0017 · single · implementation**

A start button is hidden when a permissive is false, but an API can still start the simulated actuator. What failed?

SYNTHETIC LOW-ENERGY LOOP MODEL; no live PLC commands.
Required level: 60%. Sensor raw range: 4–20 mA represents 0–100%. Input reads 12 mA; HMI shows 75%. Controller uses raw-derived 50%, setpoint 60%, valve command 80%; valve feedback 20%. Independent simulator level rises slowly. Cyclic task: 100 ms. Gateway refresh: 2 s. Audit record: HMI scale changed from 0–100 to 0–150 yesterday; no approved change references it.

1. The input sample rate is insufficient to display the button state.
2. The hidden button is sufficient if the API is used only by maintenance staff.
3. The required permissive is not enforced on every command path.
4. The simulator’s process model is necessarily unstable.

**Correct option(s):** 3

- Option 1: The supplied defect is accepted API action despite the false permissive, not demonstrated sampling error.
- Option 2: The stated permissive must be enforced on every authorised command path, including maintenance APIs.
- Option 3: Presentation control alone does not enforce the process rule.
- Option 4: The demonstrated defect is that the API bypasses the intended permissive authority, not proven loop instability.

**GICSP-Q0018 · single · diagnosis**

A watchdog alarm appears after a project change and increased polling. Which attribution is justified?

SYNTHETIC LOW-ENERGY LOOP MODEL; no live PLC commands.
Required level: 60%. Sensor raw range: 4–20 mA represents 0–100%. Input reads 12 mA; HMI shows 75%. Controller uses raw-derived 50%, setpoint 60%, valve command 80%; valve feedback 20%. Independent simulator level rises slowly. Cyclic task: 100 ms. Gateway refresh: 2 s. Audit record: HMI scale changed from 0–100 to 0–150 yesterday; no approved change references it.

1. The project is certainly correct because it compiled.
2. The polling client is certainly hostile.
3. Neither cause is established; compare execution, request and project evidence.
4. The process is certainly safe because the watchdog exists.

**Correct option(s):** 3

- Option 1: Compilation does not establish timing behaviour.
- Option 2: Increased load alone does not establish intent.
- Option 3: Both changes and other causes can affect execution timing.
- Option 4: The configured response and independent protection require verification.

**GICSP-Q0019 · order · implementation**

Order a controlled correction of the HMI scaling discrepancy.

SYNTHETIC LOW-ENERGY LOOP MODEL; no live PLC commands.
Required level: 60%. Sensor raw range: 4–20 mA represents 0–100%. Input reads 12 mA; HMI shows 75%. Controller uses raw-derived 50%, setpoint 60%, valve command 80%; valve feedback 20%. Independent simulator level rises slowly. Cyclic task: 100 ms. Gateway refresh: 2 s. Audit record: HMI scale changed from 0–100 to 0–150 yesterday; no approved change references it.

1. Repeat raw-to-display and required alarm tests
2. Preserve the raw values, audit entry and approved range
3. Confirm the scope and expected result against the requirement
4. Apply the reviewed scaling correction within the authorised change

**Correct sequence:** 2, 3, 4, 1

- Option 1: Retesting follows implementation.
- Option 2: Preserve the initial evidence before changing it.
- Option 3: The approved mapping determines the correction.
- Option 4: Execution follows review and authority.

**GICSP-Q0020 · single · recovery**

Which statement is strongest after the display retest passes?

SYNTHETIC LOW-ENERGY LOOP MODEL; no live PLC commands.
Required level: 60%. Sensor raw range: 4–20 mA represents 0–100%. Input reads 12 mA; HMI shows 75%. Controller uses raw-derived 50%, setpoint 60%, valve command 80%; valve feedback 20%. Independent simulator level rises slowly. Cyclic task: 100 ms. Gateway refresh: 2 s. Audit record: HMI scale changed from 0–100 to 0–150 yesterday; no approved change references it.

1. The tested mapping is restored; actuator mismatch remains a separate open requirement.
2. The unapproved change was definitely an attack.
3. Every control-loop property is accepted.
4. Physical sensor calibration is complete.

**Correct option(s):** 1

- Option 1: One corrected layer does not close an unrelated defect.
- Option 2: A discrepancy does not by itself establish malicious intent.
- Option 3: Dynamics, actuation and other criteria still need evidence.
- Option 4: No physical calibration was performed.

#### Recall

**How is 4–20 mA converted to a 0–100% span?**

Subtract 4 mA, divide by the 16 mA span, then multiply by 100; validate the actual transmitter/range.

**Why separate command, feedback and effect?**

They represent requested action, reported actuator state and actual process response, which can fail independently.

**What is integral windup?**

Accumulated error during a limiting condition can prolong excessive drive; supported anti-windup/tracking addresses the control mechanism.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

### GICSP-L003 — Operational roles, work authority and useful handover

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L002

### Roles describe decisions, not just job titles
An asset owner is accountable for the required service and its risk decisions. Operations understands current process state and coordinates operating actions. Control engineers understand the sequence, instrumentation and supported configuration. Network engineers maintain communication paths. Cybersecurity staff assess threats, access and evidence. Vendors supply product knowledge and supported methods; a vendor account does not automatically grant permission for every action. The incident commander coordinates the response when that role is activated. Exact titles vary, so record who may decide, who executes, who advises and who verifies for each consequential action.

Distinguish competence, access and authority. A person may know how to download a PLC project but lack permission during the current operating mode. An account may technically permit the action even though the work window has ended. A manager may approve service risk but lack the competence to design a protective sequence. The correct response to an unresolved boundary is a specific hold/escalation with evidence and a requested decision, not silent action or indefinite ambiguity.

### Build a work package that can be used
A method of procedure describes a planned task; a standard operating procedure supports repeatable ordinary operation; an emergency procedure addresses a defined urgent condition. Names alone do not establish quality. A useful document identifies the asset, approved baseline, purpose, prerequisites, roles, permitted actions, stop conditions, expected observations, restoration and evidence. The procedure must match the exact product and configuration. Substituting an apparently similar controller can invalidate firmware, connection and recovery assumptions.

Before a change, compare current state with the assumed starting state. An unavailable redundant component, expired recovery credential or unexpected override can make yesterday's approved sequence inappropriate today. Record a precondition failure and re-evaluate. Do not erase the failed precheck merely because the maintenance window is scarce. An urgent operational decision may justify a different authorised approach, but it needs a documented basis and scope.

### Handover must transfer situational understanding
The receiving operator needs current mode, service impact, active alarms, inhibitions, temporary permissions, work in progress, remaining redundancy, next decision and accountable owner. An alarm acknowledged by the outgoing shift can still require action. A temporary firewall rule can outlive its ticket if expiry is not technically enforced. A handover test should ask the receiver to explain and perform a representative bounded action using the supplied records. A signature establishes receipt, not necessarily usable understanding.

Communication should separate observed facts, hypotheses and requests. “The firewall broke cooling” overstates evidence if only a stale display was observed. A better report supplies acquisition time, affected service, relevant change, local process observation, tested flows and the question the next owner can answer. Use a common time basis or disclose uncertainty. Explicitly name decisions that remain open and which conditions trigger escalation.

### Preserve protective independence
A process-safety or electrical specialist may own an independent protective function. Security containment must preserve that boundary. An IT response habit such as immediate isolation of every subnet can remove required alarms, engineering access or a recovery service. Evaluate options with the operational owner and use the least disruptive action that meets the stated containment need. The objective is not to avoid every interruption; it is to make a justified authorised decision with known consequences and a verified recovery path.

After work, demonstrate return to the required state, remove temporary authority, reconcile records and hand over residual conditions. Close performed work and accepted service as separate milestones where necessary. A realistic course assessment rewards a well-supported hold and escalation when evidence is insufficient; it does not teach that confidence or administrator privileges replace engineering responsibility.

#### Worked demonstrations

**Evidence walkthrough**

SYNTHETIC SHIFT/CHANGE RECORD.
WO-77 permits vendor V to collect read-only PLC diagnostics from 13:00–14:00 through jump host J. Operations owner O may approve service interruptions; controls engineer C owns the supported project method. Protective panel P is excluded. At 13:40 redundant collector B is unavailable. V requests a PLC restart to refresh a stale HMI and proposes extending its account overnight. The approved rollback depends on a credential last tested six months ago. The outgoing shift marks an alarm acknowledged, but its cause remains active.

**Reasoning:** The permitted task is read-only collection. A restart, extension of access and action on P are outside it. The lost collector changes the assumed resilience; preserve the current state and seek a bounded decision from O with C's supported recovery analysis. Verify recovery access before any authorised restart. Handover must show the active alarm cause, B's unavailable state, the expiring vendor window, next decision and owner. Neither ticket acknowledgement nor a vendor recommendation closes those conditions.

#### Guided practice

Write a 90-word escalation to O without asserting a root cause.

**Hint:** Use observed impact, permitted scope, changed precondition and requested decision.

**Worked solution:** State that HMI data are stale, PLC restart is unapproved, collector B is unavailable and rollback access is unverified. Request an operational decision on a supported bounded diagnostic/change after C reviews recovery. Preserve required observation and P independence; name the 14:00 access expiry.

#### Independent task

Environment: analytical

Produce a revised work package and receiving-shift briefing for WO-77.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L003.json

**Evidence to produce**

- Scope and RACI table
- Precheck/hold register
- Handover and restoration criteria

**Acceptance criteria**

- Restart and read-only collection remain separate authorities.
- Every temporary condition has an owner and decision/expiry.
- Receiver can identify the required stop condition.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0021 · single · operations**

Which requested action is already authorised by WO-77?

SYNTHETIC SHIFT/CHANGE RECORD.
WO-77 permits vendor V to collect read-only PLC diagnostics from 13:00–14:00 through jump host J. Operations owner O may approve service interruptions; controls engineer C owns the supported project method. Protective panel P is excluded. At 13:40 redundant collector B is unavailable. V requests a PLC restart to refresh a stale HMI and proposes extending its account overnight. The approved rollback depends on a credential last tested six months ago. The outgoing shift marks an alarm acknowledged, but its cause remains active.

1. Read-only diagnostics through J before 14:00
2. Overnight vendor access
3. PLC restart at 13:45
4. Protective-panel reconfiguration

**Correct option(s):** 1

- Option 1: This matches the stated function, route and window.
- Option 2: The permitted window ends at 14:00.
- Option 3: Restart is a disruptive write outside the permit.
- Option 4: P is explicitly excluded.

**GICSP-Q0022 · single · diagnosis**

Why does collector B's unavailability matter to the precheck?

SYNTHETIC SHIFT/CHANGE RECORD.
WO-77 permits vendor V to collect read-only PLC diagnostics from 13:00–14:00 through jump host J. Operations owner O may approve service interruptions; controls engineer C owns the supported project method. Protective panel P is excluded. At 13:40 redundant collector B is unavailable. V requests a PLC restart to refresh a stale HMI and proposes extending its account overnight. The approved rollback depends on a credential last tested six months ago. The outgoing shift marks an alarm acknowledged, but its cause remains active.

1. It proves the PLC caused the outage.
2. The proposed action now occurs with less observation resilience than assumed.
3. It automatically authorises a restart.
4. It removes the need for rollback.

**Correct option(s):** 2

- Option 1: No causal link is supplied.
- Option 2: A changed starting state can invalidate a maintenance plan.
- Option 3: Degradation does not expand permission.
- Option 4: Reduced resilience makes recovery readiness more important.

**GICSP-Q0023 · single · operations**

Who should govern the decision to accept a service interruption in this fixture?

SYNTHETIC SHIFT/CHANGE RECORD.
WO-77 permits vendor V to collect read-only PLC diagnostics from 13:00–14:00 through jump host J. Operations owner O may approve service interruptions; controls engineer C owns the supported project method. Protective panel P is excluded. At 13:40 redundant collector B is unavailable. V requests a PLC restart to refresh a stale HMI and proposes extending its account overnight. The approved rollback depends on a credential last tested six months ago. The outgoing shift marks an alarm acknowledged, but its cause remains active.

1. The person who acknowledges the alarm, without checking the supplied risk-authority matrix.
2. O, informed by the relevant technical owners and stated process.
3. The access gateway’s successful login result.
4. V solely because its account can restart.

**Correct option(s):** 2

- Option 1: Alarm acknowledgement does not transfer authority for service interruption.
- Option 2: O has the specified operational decision authority.
- Option 3: Technical authentication does not authorise acceptance of operational consequences.
- Option 4: Technical capability is not decision authority.

**GICSP-Q0024 · single · recovery**

What must be established about the rollback credential before relying on it?

SYNTHETIC SHIFT/CHANGE RECORD.
WO-77 permits vendor V to collect read-only PLC diagnostics from 13:00–14:00 through jump host J. Operations owner O may approve service interruptions; controls engineer C owns the supported project method. Protective panel P is excluded. At 13:40 redundant collector B is unavailable. V requests a PLC restart to refresh a stale HMI and proposes extending its account overnight. The approved rollback depends on a credential last tested six months ago. The outgoing shift marks an alarm acknowledged, but its cause remains active.

1. That the approved recovery route is currently usable and appropriately protected.
2. That it is copied into the public report.
3. That its name appears in the procedure.
4. That V knows a different privileged password.

**Correct option(s):** 1

- Option 1: A six-month-old test does not establish today's access.
- Option 2: Publication would expose sensitive authority.
- Option 3: A documented name can refer to expired or unavailable access.
- Option 4: An unrelated credential may bypass the approved custody and scope.

**GICSP-Q0025 · single · operations**

Which statement should be included in the alarm handover?

SYNTHETIC SHIFT/CHANGE RECORD.
WO-77 permits vendor V to collect read-only PLC diagnostics from 13:00–14:00 through jump host J. Operations owner O may approve service interruptions; controls engineer C owns the supported project method. Protective panel P is excluded. At 13:40 redundant collector B is unavailable. V requests a PLC restart to refresh a stale HMI and proposes extending its account overnight. The approved rollback depends on a credential last tested six months ago. The outgoing shift marks an alarm acknowledged, but its cause remains active.

1. Resolved because someone acknowledged it.
2. Definitely a cyberattack.
3. Removed because the shift changed.
4. Acknowledged; underlying cause remains active, with responder and next action.

**Correct option(s):** 4

- Option 1: Acknowledgement does not prove cause clearance.
- Option 2: The record supplies no attribution evidence.
- Option 3: Shift changes cannot eliminate the physical condition.
- Option 4: Recognition and resolution are distinct.

**GICSP-Q0026 · single · mechanism**

What best explains the relationship between C and O?

SYNTHETIC SHIFT/CHANGE RECORD.
WO-77 permits vendor V to collect read-only PLC diagnostics from 13:00–14:00 through jump host J. Operations owner O may approve service interruptions; controls engineer C owns the supported project method. Protective panel P is excluded. At 13:40 redundant collector B is unavailable. V requests a PLC restart to refresh a stale HMI and proposes extending its account overnight. The approved rollback depends on a credential last tested six months ago. The outgoing shift marks an alarm acknowledged, but its cause remains active.

1. C supplies the supported technical method; O governs the stated interruption decision.
2. Only one role may contribute evidence.
3. C's method automatically approves any outage.
4. O's approval makes any firmware sequence supported.

**Correct option(s):** 1

- Option 1: Technical competence and operational accountability complement each other.
- Option 2: Multidisciplinary decisions require relevant evidence from several owners.
- Option 3: Technical feasibility does not accept all service consequences.
- Option 4: Approval cannot change product constraints.

**GICSP-Q0027 · single · diagnosis**

Which escalation wording is supported?

SYNTHETIC SHIFT/CHANGE RECORD.
WO-77 permits vendor V to collect read-only PLC diagnostics from 13:00–14:00 through jump host J. Operations owner O may approve service interruptions; controls engineer C owns the supported project method. Protective panel P is excluded. At 13:40 redundant collector B is unavailable. V requests a PLC restart to refresh a stale HMI and proposes extending its account overnight. The approved rollback depends on a credential last tested six months ago. The outgoing shift marks an alarm acknowledged, but its cause remains active.

1. The HMI is stale; restart has been proposed, while the cause remains unverified.
2. The PLC is broken because V recommends restart.
3. Cooling has stopped because the tile is old.
4. The firewall is malicious.

**Correct option(s):** 1

- Option 1: This separates observation, proposal and uncertainty.
- Option 2: A recommendation is not a diagnostic proof.
- Option 3: Stale observation does not establish physical state.
- Option 4: No firewall evidence or intent is supplied.

**GICSP-Q0028 · multi · operations**

Which items must remain visible in the receiving-shift record? Select all that apply.

SYNTHETIC SHIFT/CHANGE RECORD.
WO-77 permits vendor V to collect read-only PLC diagnostics from 13:00–14:00 through jump host J. Operations owner O may approve service interruptions; controls engineer C owns the supported project method. Protective panel P is excluded. At 13:40 redundant collector B is unavailable. V requests a PLC restart to refresh a stale HMI and proposes extending its account overnight. The approved rollback depends on a credential last tested six months ago. The outgoing shift marks an alarm acknowledged, but its cause remains active.

1. Collector B unavailable
2. Unverified rollback access
3. Vendor access expiry and extension decision
4. Only alarms that were never acknowledged

**Correct option(s):** 1, 2, 3

- Option 1: This affects observation resilience.
- Option 2: Recovery readiness is an open precondition.
- Option 3: Temporary authority must not silently persist.
- Option 4: Acknowledged unresolved conditions still matter.

**GICSP-Q0029 · single · implementation**

What demonstrates that the handover is operationally usable?

SYNTHETIC SHIFT/CHANGE RECORD.
WO-77 permits vendor V to collect read-only PLC diagnostics from 13:00–14:00 through jump host J. Operations owner O may approve service interruptions; controls engineer C owns the supported project method. Protective panel P is excluded. At 13:40 redundant collector B is unavailable. V requests a PLC restart to refresh a stale HMI and proposes extending its account overnight. The approved rollback depends on a credential last tested six months ago. The outgoing shift marks an alarm acknowledged, but its cause remains active.

1. Two signatures from the outgoing operator.
2. The receiving operator confirms receipt without reviewing the current degraded state.
3. The receiver identifies current degraded conditions and performs a representative bounded procedure correctly.
4. A longer asset list without owners.

**Correct option(s):** 3

- Option 1: Repeated signatures do not test the receiver.
- Option 2: Receipt proves transfer of information, not that the receiver can operate the current configuration.
- Option 3: This tests understanding and use of the material.
- Option 4: Volume does not resolve accountability.

**GICSP-Q0030 · single · operations**

After approved diagnostics end, what closes the vendor-access condition?

SYNTHETIC SHIFT/CHANGE RECORD.
WO-77 permits vendor V to collect read-only PLC diagnostics from 13:00–14:00 through jump host J. Operations owner O may approve service interruptions; controls engineer C owns the supported project method. Protective panel P is excluded. At 13:40 redundant collector B is unavailable. V requests a PLC restart to refresh a stale HMI and proposes extending its account overnight. The approved rollback depends on a credential last tested six months ago. The outgoing shift marks an alarm acknowledged, but its cause remains active.

1. Effective access expiry/revocation and verification against the authorised scope.
2. Changing the account description to completed.
3. Leaving the session active because it was opened before 14:00.
4. Removing logs to avoid confusion.

**Correct option(s):** 1

- Option 1: Ticket closure must correspond to actual enforcement.
- Option 2: A description does not remove privileges.
- Option 3: Session lifetime must obey the approved access requirement.
- Option 4: Logs support accountability and investigation.

#### Recall

**Competence, access and authority are different because…**

Knowing a method, possessing a privilege and being permitted to act in the current state are separate conditions.

**What makes a handover useful?**

It identifies actual and degraded state, temporary authority, unresolved alarms, next decisions and owners, then supports a demonstrated operating task.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

### GICSP-L004 — OT security priorities without slogans

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L003

### Replace universal priority rankings with consequences
A familiar slogan says OT always prioritises availability over confidentiality. It can be a useful reminder that an interruption may affect a physical process, but it is not a decision rule. An available controller accepting unauthorised setpoints can be worse than a controlled interruption. Disclosure of recovery credentials can enable later loss of control. A privacy-sensitive access-control record may require confidentiality even when its loss would not immediately stop the plant. Define the function, adversary or fault, consequence and required property before ranking treatments.

Integrity includes more than preventing file modification. It includes correct point identity, units, command authority, sequence logic, time and provenance. Availability includes usable service within a time bound, not merely host uptime. Confidentiality limits inappropriate disclosure, including diagrams, credentials, incident records and personal data. Safety is a property of the process and its risk controls; security can affect it but is not identical to it. Resilience concerns surviving and recovering from disturbances within specified limits. A secure design must negotiate these properties explicitly rather than treating one metric as a universal substitute.

### Operational constraints change implementation
Industrial components can remain in service for long periods and depend on validated software, specialised interfaces or scarce maintenance windows. A desktop patch practice may not transfer unchanged to a controller or supervisory server. That does not justify ignoring vulnerabilities indefinitely. Determine affected version, exposure, consequence, supported remediation, compensating controls, recovery method and an accountable deadline. A bounded exception has an owner, evidence and expiry; “legacy” is a description, not permanent risk acceptance.

Security tooling can affect the system it observes. Active discovery may create load or unsupported requests on constrained devices. An endpoint agent may conflict with a vendor application, consume CPU or block a required driver. Test compatibility and operational behaviour on a representative authorised environment before deployment. Passive monitoring also has limits: encrypted traffic, mirror loss, silent devices and serial networks can reduce visibility. Choose tools from the required evidence and test their effect rather than assuming passive means complete or active means always forbidden.

### Availability and integrity need different tests
An HMI login proves only one interface is reachable. It does not prove that values are current, commands are correctly mapped or independent protection is maintained. An access control test must include both required allowed operations and prohibited operations. A backup test must restore the application, data and authority through the failure being considered. A successful image copy alone cannot establish recovery when its decryption key or identity service was lost with the host.

Use performance budgets to make trade-offs reviewable. State acceptable command delay, observation age, outage duration, data loss and recovery time. Separate normal operation from degraded and maintenance states. If a security control adds delay, measure whether the complete service still meets the requirement. If it fails, investigate a supported alternative or escalate the requirement/design decision; do not silently disable the control or pretend the delay is irrelevant.

### Document the engineering decision
A defensible treatment records the requirement, evidence, options, consequences, chosen authority, implementation and acceptance tests. Where evidence is insufficient, preserve uncertainty and choose a bounded next observation. A well-supported decision may be to patch now, stage and schedule, isolate a specific administration path, or hold an incompatible proposal. The course teaches the reasoning mechanism rather than prescribing one answer for every OT system. The same discipline connects cybersecurity to commissioning, ordinary operation, maintenance, optimisation, troubleshooting, incident response and trusted recovery.

#### Worked demonstrations

**Evidence walkthrough**

SYNTHETIC TREATMENT COMPARISON.
A supervisory server must deliver valid alarms within 5 s. An endpoint agent in a representative lab blocks an unsupported driver and alarms arrive after 18 s. An unpatched remotely exploitable service is reachable only through an approved jump host. A proposed exception removes all access logging permanently. A supported patched version is available but requires a 20-minute restart; the site has a 30-minute approved window next week. Independent process protection remains local and is not changed by this exercise.

**Reasoning:** The tested agent fails the stated alarm requirement; its general security benefit does not prove operational acceptance. The reachable vulnerable service still needs treatment: assess the specific exposure, constrain authorised access, preserve monitoring and prepare the supported patch within a verified recovery/change plan. A permanent logging removal is not a bounded exception. The 30-minute window must include restart, validation and any rollback requirement; a 20-minute restart alone does not prove the work fits.

#### Guided practice

Propose a temporary treatment record until the supported patch window.

**Hint:** Include exposure reduction, monitoring, expiry and verification.

**Worked solution:** Name the affected service/version, permitted jump-host identities, restricted flows, compensating observations, owner and next-week expiry. Verify alarm delivery and denied unapproved access. Stage the supported patch and time complete restoration/rollback rather than assuming ten minutes is enough.

#### Independent task

Environment: analytical

Compare three treatments for a synthetic legacy collector: supported patch, protocol gateway restriction and incompatible endpoint agent.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L004.json

**Evidence to produce**

- Consequence/property matrix
- Measured acceptance plan
- Time-bounded exception record

**Acceptance criteria**

- Security and operational effects are evaluated separately.
- No unsupported agent is accepted from marketing claims.
- Exception has owner, expiry and measurable compensating controls.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0031 · single · calculation**

Which observation prevents accepting the tested agent as configured?

SYNTHETIC TREATMENT COMPARISON.
A supervisory server must deliver valid alarms within 5 s. An endpoint agent in a representative lab blocks an unsupported driver and alarms arrive after 18 s. An unpatched remotely exploitable service is reachable only through an approved jump host. A proposed exception removes all access logging permanently. A supported patched version is available but requires a 20-minute restart; the site has a 30-minute approved window next week. Independent process protection remains local and is not changed by this exercise.

1. Any endpoint agent is unsuitable solely because the server is supervisory.
2. The product’s security classification is enough to reject it without measuring alarm delivery.
3. The future supported patch’s restart requirement proves this agent cannot run.
4. Alarm delivery takes 18 s against a 5 s requirement.

**Correct option(s):** 4

- Option 1: Suitability depends on the tested impact and required functions, not that categorical label.
- Option 2: The observed 18-second delay against the five-second limit is the concrete acceptance failure.
- Option 3: The rejected agent’s driver impact is separate from the planned patch restart.
- Option 4: The required operational function fails under the measured configuration.

**GICSP-Q0032 · single · design**

Does rejecting the incompatible agent justify leaving the vulnerability untreated?

SYNTHETIC TREATMENT COMPARISON.
A supervisory server must deliver valid alarms within 5 s. An endpoint agent in a representative lab blocks an unsupported driver and alarms arrive after 18 s. An unpatched remotely exploitable service is reachable only through an approved jump host. A proposed exception removes all access logging permanently. A supported patched version is available but requires a 20-minute restart; the site has a 30-minute approved window next week. Independent process protection remains local and is not changed by this exercise.

1. Install the same agent in production and rely on local protection to absorb the 18-second alarm delay.
2. Accept the jump host as a complete substitute without checking its remaining application privileges.
3. No; select and verify another supported treatment with accountable timing.
4. Defer the vulnerability indefinitely because the first tested agent was incompatible.

**Correct option(s):** 3

- Option 1: Independent protection does not waive the five-second supervisory requirement.
- Option 2: The jump host narrows access but does not automatically eliminate exploitation through an authorised path.
- Option 3: One unsuitable control does not remove the exposure.
- Option 4: Rejecting one treatment does not remove the reachable vulnerability or the available supported patch route.

**GICSP-Q0033 · single · mechanism**

Which property is primarily affected by unauthorised setpoint modification?

SYNTHETIC TREATMENT COMPARISON.
A supervisory server must deliver valid alarms within 5 s. An endpoint agent in a representative lab blocks an unsupported driver and alarms arrive after 18 s. An unpatched remotely exploitable service is reachable only through an approved jump host. A proposed exception removes all access logging permanently. A supported patched version is available but requires a 20-minute restart; the site has a 30-minute approved window next week. Independent process protection remains local and is not changed by this exercise.

1. Integrity of the authorised control action.
2. Only confidentiality.
3. Only file-system capacity.
4. None if the controller remains online.

**Correct option(s):** 1

- Option 1: The command no longer reflects approved intent.
- Option 2: Disclosure is not the sole issue.
- Option 3: No storage exhaustion is described.
- Option 4: Uptime does not establish trustworthy control.

**GICSP-Q0034 · single · operations**

Why is the permanent logging-removal proposal not a sound temporary exception?

SYNTHETIC TREATMENT COMPARISON.
A supervisory server must deliver valid alarms within 5 s. An endpoint agent in a representative lab blocks an unsupported driver and alarms arrive after 18 s. An unpatched remotely exploitable service is reachable only through an approved jump host. A proposed exception removes all access logging permanently. A supported patched version is available but requires a 20-minute restart; the site has a 30-minute approved window next week. Independent process protection remains local and is not changed by this exercise.

1. The proposal is acceptable because logging is unrelated to the affected alarm path.
2. Retain only firewall counters and assume they replace account and operation audit.
3. It has no bounded duration and removes evidence without a justified compensating plan.
4. A permanent exception needs only the original installer’s approval.

**Correct option(s):** 3

- Option 1: It removes investigation and accountability capability indefinitely without a bounded exception.
- Option 2: Counters cannot necessarily reconstruct the identity and action evidence removed by the proposal.
- Option 3: An exception needs scope, owner, expiry and consequence analysis.
- Option 4: Sustained risk, ownership, compensating measures and review require the applicable service authority.

**GICSP-Q0035 · single · design**

A patch restart takes 20 minutes in a 30-minute window. What remains unproven?

SYNTHETIC TREATMENT COMPARISON.
A supervisory server must deliver valid alarms within 5 s. An endpoint agent in a representative lab blocks an unsupported driver and alarms arrive after 18 s. An unpatched remotely exploitable service is reachable only through an approved jump host. A proposed exception removes all access logging permanently. A supported patched version is available but requires a 20-minute restart; the site has a 30-minute approved window next week. Independent process protection remains local and is not changed by this exercise.

1. Whether preparation, functional validation and the required rollback fit the full window.
2. Whether the displayed maintenance timer can show the full 30-minute window.
3. Whether 20 is less than 30.
4. Whether the same vendor supplied both the server and endpoint agent.

**Correct option(s):** 1

- Option 1: Restart duration is only one phase.
- Option 2: A timer display does not establish the duration of functional validation or rollback.
- Option 3: That arithmetic is known but insufficient.
- Option 4: Vendor identity does not establish that restart, restoration and acceptance fit the remaining window.

**GICSP-Q0036 · single · mechanism**

Which statement about passive discovery is accurate?

SYNTHETIC TREATMENT COMPARISON.
A supervisory server must deliver valid alarms within 5 s. An endpoint agent in a representative lab blocks an unsupported driver and alarms arrive after 18 s. An unpatched remotely exploitable service is reachable only through an approved jump host. A proposed exception removes all access logging permanently. A supported patched version is available but requires a 20-minute restart; the site has a 30-minute approved window next week. Independent process protection remains local and is not changed by this exercise.

1. A passive capture can be distributed freely because it sends no packets.
2. It can enumerate all six serial meters from the gateway IP address alone.
3. An observed device banner can be treated as authenticated inventory identity.
4. It can reduce active query impact while still missing silent, encrypted or unobserved traffic.

**Correct option(s):** 4

- Option 1: Passive evidence can still contain sensitive process or identity information.
- Option 2: A gateway address does not expose every downstream identity or silent device.
- Option 3: A banner is an unauthenticated observation requiring reconciliation.
- Option 4: Collection placement and protocol visibility limit completeness.

**GICSP-Q0037 · multi · design**

Which conditions belong in a supported temporary treatment? Select all that apply.

SYNTHETIC TREATMENT COMPARISON.
A supervisory server must deliver valid alarms within 5 s. An endpoint agent in a representative lab blocks an unsupported driver and alarms arrive after 18 s. An unpatched remotely exploitable service is reachable only through an approved jump host. A proposed exception removes all access logging permanently. A supported patched version is available but requires a 20-minute restart; the site has a 30-minute approved window next week. Independent process protection remains local and is not changed by this exercise.

1. A claim that risk is zero
2. Restricted relevant access
3. Verification of required alarms and denied unauthorised operations
4. Owner and expiry linked to the remediation plan

**Correct option(s):** 2, 3, 4

- Option 1: Residual exposure and uncertainty remain.
- Option 2: It can reduce exposure while preserving required function.
- Option 3: Both service and security effects need evidence.
- Option 4: They prevent an indefinite unreviewed exception.

**GICSP-Q0038 · single · diagnosis**

A collector stays online but presents wrongly mapped alarm points. Which acceptance claim fails?

SYNTHETIC TREATMENT COMPARISON.
A supervisory server must deliver valid alarms within 5 s. An endpoint agent in a representative lab blocks an unsupported driver and alarms arrive after 18 s. An unpatched remotely exploitable service is reachable only through an approved jump host. A proposed exception removes all access logging permanently. A supported patched version is available but requires a 20-minute restart; the site has a 30-minute approved window next week. Independent process protection remains local and is not changed by this exercise.

1. Only whether the field traffic is encrypted.
2. Usable, correct operational service despite host availability.
3. Only whether the collector’s rack installation passed inspection.
4. None; uptime is the sole OT criterion.

**Correct option(s):** 2

- Option 1: Encryption does not correct the wrong physical-to-logical alarm mapping.
- Option 2: Application meaning is part of integrity and useful availability.
- Option 3: The demonstrated defect concerns point meaning and valid alarm service, not rack fit.
- Option 4: The required function is incorrect.

**GICSP-Q0039 · single · mechanism**

Why might credential disclosure have availability consequences later?

SYNTHETIC TREATMENT COMPARISON.
A supervisory server must deliver valid alarms within 5 s. An endpoint agent in a representative lab blocks an unsupported driver and alarms arrive after 18 s. An unpatched remotely exploitable service is reachable only through an approved jump host. A proposed exception removes all access logging permanently. A supported patched version is available but requires a 20-minute restart; the site has a 30-minute approved window next week. Independent process protection remains local and is not changed by this exercise.

1. Confidentiality can be assessed independently because stolen credentials cannot affect service actions.
2. The password disclosure directly changes coolant temperature without any intervening authority or action.
3. Exposed authority can enable subsequent control changes or interruption.
4. The disclosed credential proves an outage has already occurred.

**Correct option(s):** 3

- Option 1: Credential exposure can enable integrity or availability impacts through their effective privileges.
- Option 2: The consequence requires a usable access path and control-changing capability, not a direct physical effect of text disclosure.
- Option 3: Security properties interact through an attack path.
- Option 4: Exposure creates a potential path; actual use and consequence require evidence.

**GICSP-Q0040 · single · implementation**

What evidence best supports accepting the eventual patch?

SYNTHETIC TREATMENT COMPARISON.
A supervisory server must deliver valid alarms within 5 s. An endpoint agent in a representative lab blocks an unsupported driver and alarms arrive after 18 s. An unpatched remotely exploitable service is reachable only through an approved jump host. A proposed exception removes all access logging permanently. A supported patched version is available but requires a 20-minute restart; the site has a 30-minute approved window next week. Independent process protection remains local and is not changed by this exercise.

1. Only a lower vulnerability count.
2. Supported version and staging results linked to service, denied-access and recovery tests.
3. Only an installer success code.
4. A promise to test during the next incident.

**Correct option(s):** 2

- Option 1: Counts can omit function and recovery consequences.
- Option 2: The record joins technical correction to the required outcomes.
- Option 3: Installation does not prove operational behaviour.
- Option 4: Required acceptance should precede release where the plan demands it.

#### Recall

**Why is “availability first” insufficient?**

An available but incorrectly controlled process can be dangerous; priorities follow consequences and defined functions.

**What makes a vulnerability exception bounded?**

Specific exposure, owner, compensating controls, verification, expiry and a supported remediation plan.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

### GICSP-L005 — Requirements, commissioning and lifecycle security evidence

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L004

### A requirement must be falsifiable
A requirement describes an outcome under stated conditions, not a preferred product. “Use a firewall” is an implementation choice. “The historian may read approved telemetry while its identity cannot change the test setpoint” is a testable access requirement. Add the system boundary, source/version, owner, permitted modes and acceptance evidence. Quantitative thresholds must come from the approved project; teaching examples use explicitly synthetic thresholds. Avoid combining unrelated criteria into a score that can hide a failed mandatory property.

Decompose the service into interfaces. A measured value moves through sensor, I/O conversion, controller, protocol, collector, database and display. Each stage can alter identity, unit, time or quality. A secure channel can carry the wrong point. A correct database value can be displayed with an incorrect scale. Test the complete service, then use intermediate observations to locate failures. This decomposition turns a broad “monitoring works” assertion into several checkable claims without confusing component success with system acceptance.

### Different tests answer different questions
A factory test or vendor simulation can examine logic and supported configuration before site deployment. Site testing addresses the actual installation and interfaces. Integrated testing exercises dependencies across systems. These names do not themselves guarantee fidelity: record which equipment, signals, loads and failures were actually represented. A simulator cannot establish real cable quality; a physical inspection cannot establish a correctly enforced application role.

Positive tests demonstrate required allowed behaviour. Negative tests demonstrate rejected forbidden behaviour or invalid inputs. Degraded tests exercise required operation after an identified loss. Recovery tests establish return of function, data and authority after the defined failure. Include the test origin, clock/measurement quality, actual configuration and completion criterion. An alarm test that starts its clock at display refresh instead of source failure can hide a long collection delay.

### Change requires regression, not just correction
Record a failed result, its supported diagnosis, the approved correction and a new test run. Do not overwrite the first result with the final pass. A correction can break another function: tightening a role may deny the historian's legitimate reads; fixing scale may leave alarm thresholds in old units. Select related regression tests from the affected interfaces and consequences. Repeating every possible test is not always necessary, but the selected scope needs a defensible reason.

A configuration baseline is approved for an identified context. Hashes can support byte-integrity checks, but do not prove a configuration is correct or that the deployed device uses it. Record effective state where supported. Test backup restoration with compatible versions and independently available keys/access. Some changes are not reversible by reloading an old file, so the recovery plan may require a supported rebuild or replacement rather than a promised downgrade.

### Sustain the accepted state
Commissioning is a baseline, not the end of responsibility. Operations detects drift and invalid observations; maintenance changes the configuration; optimisation must preserve constraints; troubleshooting and incidents challenge assumptions; recovery can expose hidden dependencies. Link each event back to requirements and update the approved design where evidence justifies it. The portfolio keeps learning, practical application, independent acceptance and field demonstration separate. A passed app assessment establishes reasoning within the supplied case; an accepted real implementation needs its actual evidence and authority.

#### Worked demonstrations

**Evidence walkthrough**

SYNTHETIC ACCEPTANCE REGISTER.
R1: Historian H may read point T1 every 2 s; source age displayed must remain ≤6 s in normal mode.
R2: H must not change setpoint SP1; engineer E may change SP1 only in approved MAINTENANCE mode.
R3: Acquisition loss must display stale status within 2 s after age exceeds 6 s.
R4: Recovery must restore valid observations and keep revoked vendor identity V denied.
Run A: H reads T1; H writes SP1 successfully. Run B after role correction: H write denied, but H read denied too. Run C after narrower correction: read succeeds, write denied; last sample 12:00:00, stale displayed 12:00:07. Restored snapshot enables V again.

**Reasoning:** Run A fails R2. Run B corrects one forbidden path but breaks R1, so it is not overall acceptance. Run C passes the supplied H read/write checks and stale timing: age exceeds six seconds before the seven-second indication, within the additional two-second allowance. The restored V identity fails R4 regardless of those successes. Reapply the approved revocation state and retest intended/denied access plus fresh acquisition. Retain all three runs and the restoration failure with their configuration revisions.

#### Guided practice

Write the minimum regression set after correcting H permissions.

**Hint:** Include what should remain possible, impossible and observable.

**Worked solution:** Test H read freshness, H write denial, E write only in MAINTENANCE, E denial outside the window/mode, acquisition-loss stale indication and restored revoked-V denial. Record exact identity/session state and configuration for each run.

#### Independent task

Environment: analytical

Create a requirement/test/evidence ledger for R1–R4 and execute the offline reasoning checks.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L005.json

**Evidence to produce**

- Traceability matrix
- Failure/correction/retest chain
- Bounded release disposition

**Acceptance criteria**

- Each mandatory criterion has a separate result.
- Run B is not counted as overall success.
- Recovery authority is tested after restore.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0041 · single · diagnosis**

Which requirement does Run A violate?

SYNTHETIC ACCEPTANCE REGISTER.
R1: Historian H may read point T1 every 2 s; source age displayed must remain ≤6 s in normal mode.
R2: H must not change setpoint SP1; engineer E may change SP1 only in approved MAINTENANCE mode.
R3: Acquisition loss must display stale status within 2 s after age exceeds 6 s.
R4: Recovery must restore valid observations and keep revoked vendor identity V denied.
Run A: H reads T1; H writes SP1 successfully. Run B after role correction: H write denied, but H read denied too. Run C after narrower correction: read succeeds, write denied; last sample 12:00:00, stale displayed 12:00:07. Restored snapshot enables V again.

1. R4 because E exists.
2. R1 merely because H reads T1.
3. R2, because H changes SP1.
4. R3 because no stale test is mentioned.

**Correct option(s):** 3

- Option 1: E's existence is not the restored revoked identity condition.
- Option 2: Reading is required behaviour.
- Option 3: H is permitted to read, not write the setpoint.
- Option 4: Missing test evidence is not the same as an observed R3 failure.

**GICSP-Q0042 · single · implementation**

Why is Run B not acceptable even though H's write is denied?

SYNTHETIC ACCEPTANCE REGISTER.
R1: Historian H may read point T1 every 2 s; source age displayed must remain ≤6 s in normal mode.
R2: H must not change setpoint SP1; engineer E may change SP1 only in approved MAINTENANCE mode.
R3: Acquisition loss must display stale status within 2 s after age exceeds 6 s.
R4: Recovery must restore valid observations and keep revoked vendor identity V denied.
Run A: H reads T1; H writes SP1 successfully. Run B after role correction: H write denied, but H read denied too. Run C after narrower correction: read succeeds, write denied; last sample 12:00:00, stale displayed 12:00:07. Restored snapshot enables V again.

1. The correction also denies H's required read.
2. The corrected role has a new version.
3. The denial is unacceptable simply because an engineer expected the request to succeed.
4. A port-level deny is sufficient even when it removes the required read operation.

**Correct option(s):** 1

- Option 1: Negative enforcement must preserve required legitimate function.
- Option 2: Version change is expected, not itself a defect.
- Option 3: The supplied requirement distinguishes permitted reads from forbidden writes; the missing read service is the failure.
- Option 4: The requirement demands both authority restriction and continuity of the permitted read.

**GICSP-Q0043 · single · calculation**

Does the 12:00:07 stale indication meet the supplied R3 timing?

SYNTHETIC ACCEPTANCE REGISTER.
R1: Historian H may read point T1 every 2 s; source age displayed must remain ≤6 s in normal mode.
R2: H must not change setpoint SP1; engineer E may change SP1 only in approved MAINTENANCE mode.
R3: Acquisition loss must display stale status within 2 s after age exceeds 6 s.
R4: Recovery must restore valid observations and keep revoked vendor identity V denied.
Run A: H reads T1; H writes SP1 successfully. Run B after role correction: H write denied, but H read denied too. Run C after narrower correction: read succeeds, write denied; last sample 12:00:00, stale displayed 12:00:07. Restored snapshot enables V again.

1. Yes, it occurs after age exceeds 6 s and within the additional 2 s.
2. No, every stale alarm must occur at exactly 6 s.
3. No, source age is measured from the next successful sample.
4. Yes, because display time is irrelevant.

**Correct option(s):** 1

- Option 1: The observed age is seven seconds under the stated origin.
- Option 2: R3 includes a bounded additional indication delay.
- Option 3: That would erase the outage interval.
- Option 4: The criterion explicitly concerns display timing.

**GICSP-Q0044 · single · recovery**

Which result remains a release blocker after Run C?

SYNTHETIC ACCEPTANCE REGISTER.
R1: Historian H may read point T1 every 2 s; source age displayed must remain ≤6 s in normal mode.
R2: H must not change setpoint SP1; engineer E may change SP1 only in approved MAINTENANCE mode.
R3: Acquisition loss must display stale status within 2 s after age exceeds 6 s.
R4: Recovery must restore valid observations and keep revoked vendor identity V denied.
Run A: H reads T1; H writes SP1 successfully. Run B after role correction: H write denied, but H read denied too. Run C after narrower correction: read succeeds, write denied; last sample 12:00:00, stale displayed 12:00:07. Restored snapshot enables V again.

1. The restored snapshot re-enables revoked V.
2. The successful H read.
3. The documented failed runs.
4. The use of a synthetic clock.

**Correct option(s):** 1

- Option 1: Recovery must retain denied authority under R4.
- Option 2: That satisfies part of R1.
- Option 3: Retaining failures is appropriate evidence practice.
- Option 4: It is valid for the labelled analytical exercise, though not field timing evidence.

**GICSP-Q0045 · single · implementation**

Which test distinguishes mode enforcement from a UI-only restriction?

SYNTHETIC ACCEPTANCE REGISTER.
R1: Historian H may read point T1 every 2 s; source age displayed must remain ≤6 s in normal mode.
R2: H must not change setpoint SP1; engineer E may change SP1 only in approved MAINTENANCE mode.
R3: Acquisition loss must display stale status within 2 s after age exceeds 6 s.
R4: Recovery must restore valid observations and keep revoked vendor identity V denied.
Run A: H reads T1; H writes SP1 successfully. Run B after role correction: H write denied, but H read denied too. Run C after narrower correction: read succeeds, write denied; last sample 12:00:00, stale displayed 12:00:07. Restored snapshot enables V again.

1. Attempt the authorised test API write as E outside MAINTENANCE and verify denial.
2. Check whether the button is grey.
3. Rename the mode variable in the display while leaving server-side checks unchanged.
4. Review the HMI’s screen list without exercising another command path.

**Correct option(s):** 1

- Option 1: The underlying command path must enforce the requirement.
- Option 2: Presentation alone does not prove command enforcement.
- Option 3: Presentation naming does not enforce the command precondition.
- Option 4: Screen coverage does not test whether the API enforces the same mode restriction.

**GICSP-Q0046 · single · mechanism**

What does a matching configuration hash prove by itself?

SYNTHETIC ACCEPTANCE REGISTER.
R1: Historian H may read point T1 every 2 s; source age displayed must remain ≤6 s in normal mode.
R2: H must not change setpoint SP1; engineer E may change SP1 only in approved MAINTENANCE mode.
R3: Acquisition loss must display stale status within 2 s after age exceeds 6 s.
R4: Recovery must restore valid observations and keep revoked vendor identity V denied.
Run A: H reads T1; H writes SP1 successfully. Run B after role correction: H write denied, but H read denied too. Run C after narrower correction: read succeeds, write denied; last sample 12:00:00, stale displayed 12:00:07. Restored snapshot enables V again.

1. Every role test passed.
2. The compared bytes match under the selected integrity method.
3. The file originated from an authorised engineer.
4. The controller is executing the intended logic.

**Correct option(s):** 2

- Option 1: A digest does not execute behavioural tests.
- Option 2: It does not establish correctness or deployment.
- Option 3: Origin requires a trustworthy provenance/authentication mechanism.
- Option 4: Effective device state needs separate evidence.

**GICSP-Q0047 · multi · operations**

Which records should remain after correcting Run B? Select all that apply.

SYNTHETIC ACCEPTANCE REGISTER.
R1: Historian H may read point T1 every 2 s; source age displayed must remain ≤6 s in normal mode.
R2: H must not change setpoint SP1; engineer E may change SP1 only in approved MAINTENANCE mode.
R3: Acquisition loss must display stale status within 2 s after age exceeds 6 s.
R4: Recovery must restore valid observations and keep revoked vendor identity V denied.
Run A: H reads T1; H writes SP1 successfully. Run B after role correction: H write denied, but H read denied too. Run C after narrower correction: read succeeds, write denied; last sample 12:00:00, stale displayed 12:00:07. Restored snapshot enables V again.

1. Original denied-read observation
2. The criterion and corrected retest
3. Only the final green summary
4. Configuration revisions and test parameters

**Correct option(s):** 1, 2, 4

- Option 1: It explains the regression introduced by the first correction.
- Option 2: They connect the remedy to acceptance.
- Option 3: That omits the defect and its context.
- Option 4: They make the comparison reproducible.

**GICSP-Q0048 · single · design**

A vendor simulator passes R1–R4. Which claim remains unsupported?

SYNTHETIC ACCEPTANCE REGISTER.
R1: Historian H may read point T1 every 2 s; source age displayed must remain ≤6 s in normal mode.
R2: H must not change setpoint SP1; engineer E may change SP1 only in approved MAINTENANCE mode.
R3: Acquisition loss must display stale status within 2 s after age exceeds 6 s.
R4: Recovery must restore valid observations and keep revoked vendor identity V denied.
Run A: H reads T1; H writes SP1 successfully. Run B after role correction: H write denied, but H read denied too. Run C after narrower correction: read succeeds, write denied; last sample 12:00:00, stale displayed 12:00:07. Restored snapshot enables V again.

1. The installed site's physical channel and actual interface performance are accepted.
2. The original test procedure has useful design evidence.
3. The tested simulated role logic met its supplied cases.
4. A site test can reuse the requirement IDs.

**Correct option(s):** 1

- Option 1: Simulator fidelity does not establish as-built physical behaviour.
- Option 2: It can support later implementation testing.
- Option 3: That is within the observed scope.
- Option 4: Reuse does not waive the new environment's evidence.

**GICSP-Q0049 · single · recovery**

Why test revoked V again after restoration rather than only before backup?

SYNTHETIC ACCEPTANCE REGISTER.
R1: Historian H may read point T1 every 2 s; source age displayed must remain ≤6 s in normal mode.
R2: H must not change setpoint SP1; engineer E may change SP1 only in approved MAINTENANCE mode.
R3: Acquisition loss must display stale status within 2 s after age exceeds 6 s.
R4: Recovery must restore valid observations and keep revoked vendor identity V denied.
Run A: H reads T1; H writes SP1 successfully. Run B after role correction: H write denied, but H read denied too. Run C after narrower correction: read succeeds, write denied; last sample 12:00:00, stale displayed 12:00:07. Restored snapshot enables V again.

1. The restored state can resurrect obsolete authority.
2. Authentication is random after every restart.
3. Restore testing should ignore access controls.
4. A revoked identity can never appear in a backup.

**Correct option(s):** 1

- Option 1: Backup contents and current revocation obligations can differ.
- Option 2: The issue is retained state and dependencies, not inherent randomness.
- Option 3: Trust is a required recovery property.
- Option 4: Older backups may contain it.

**GICSP-Q0050 · single · operations**

Which completion statement is justified by this app exercise?

SYNTHETIC ACCEPTANCE REGISTER.
R1: Historian H may read point T1 every 2 s; source age displayed must remain ≤6 s in normal mode.
R2: H must not change setpoint SP1; engineer E may change SP1 only in approved MAINTENANCE mode.
R3: Acquisition loss must display stale status within 2 s after age exceeds 6 s.
R4: Recovery must restore valid observations and keep revoked vendor identity V denied.
Run A: H reads T1; H writes SP1 successfully. Run B after role correction: H write denied, but H read denied too. Run C after narrower correction: read succeeds, write denied; last sample 12:00:00, stale displayed 12:00:07. Restored snapshot enables V again.

1. Every certificate objective is now mastered.
2. Site commissioning was witnessed.
3. The learner reasoned through supplied requirements and synthetic evidence.
4. The actual PLC is production-ready.

**Correct option(s):** 3

- Option 1: One case cannot establish that breadth or independence.
- Option 2: No site work occurred in the exercise.
- Option 3: No physical execution is implied.
- Option 4: No actual PLC acceptance evidence is supplied.

#### Recall

**Why pair positive and negative tests?**

Required service must work while forbidden operations fail; either dimension can regress independently.

**What must a recovery test include beyond boot?**

Correct required data/function, retained authority/revocation, dependencies and measured acceptance under the declared failure.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

## GICSP-M02 — Components, architecture and trust boundaries

### GICSP-L006 — Purdue functions, zones and conduits

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L005

### Use reference architecture as a question framework
A functional industrial hierarchy commonly distinguishes the physical process, basic control, supervisory control and site operations. In a simplified Purdue-oriented description, level 0 contains physical sensing/actuation at the process boundary; level 1 includes basic controllers; level 2 includes supervisory functions such as operator interfaces; level 3 includes site operations functions such as historians and production support. Real products can combine functions, and implementations vary. Classify what a component does rather than assigning a level solely from its operating system or IP subnet.

An intelligent drive can contain local control and diagnostics. An engineering workstation may interact with several controller families across functional levels. A virtual host can run an HMI and historian while its BMC has authority below both guest operating systems. Draw these relationships explicitly. Functional placement helps identify dependencies and owners, but does not make an upper-level asset low consequence or a lower-level asset automatically trustworthy.

### Zones group compatible requirements
A security zone groups assets according to defined common security needs and consequences. A conduit represents controlled communication between zones. The grouping should follow risk and required function, not merely physical location. Two devices in one room may need different administrative trust boundaries; two geographically separate devices may share a controlled functional zone. Record permitted flows, identities, operations, timing and management access for each conduit.

A VLAN provides a Layer 2 boundary and a VRF a separate routing context, but neither label independently proves the required access policy. Inter-zone routes, firewall rules, application roles and alternate management paths determine effective reachability and authority. A default route, dual-homed host or wireless maintenance interface can bypass an intended conduit. Test actual positive and negative operations using the deployed or represented paths.

### An industrial DMZ mediates exchange
An industrial demilitarised zone can separate enterprise and control environments by hosting carefully bounded exchange services. For example, an operations historian may replicate approved data to a broker or replica in the DMZ, which enterprise reporting then queries. This avoids granting arbitrary enterprise clients direct access to controllers. The design still needs explicit directions, identities, service dependencies, patching and recovery. A compromised DMZ service must not inherit unrestricted administration of both sides.

Dual-homing a server into enterprise and control networks does not automatically create safe mediation. Its routing, forwarding, host firewall, application behaviour and administrator authority may provide a bypass. A protocol proxy terminates and re-establishes a service according to its implementation; a data diode imposes a unidirectional physical communication property but may require specialised handling for acknowledgements and protocols. Do not infer either property from an ordinary two-interface server.

### Verify dependencies and changes
Document normal flows and exceptional ones: backup, time, directory, licensing, updates, engineering downloads and vendor support. A design that allows the process protocol but blocks required time or identity can fail during restart rather than normal operation. Conversely, a broad temporary rule can survive a maintenance window and defeat segmentation. Inspect effective state, not just the intended drawing.

Commission a zone/conduit matrix with actual source identity, destination, operation, expected result and observed evidence. Repeat consequential rows after failover, recovery and role changes. Include IPv6 or alternate interfaces when enabled. The final claim is specific: these functions and denials were demonstrated in this configuration and environment. A Purdue diagram is useful design context, but it cannot replace implementation and operating evidence.

#### Worked demonstrations

**Evidence walkthrough**

SYNTHETIC ARCHITECTURE.
PLC1 performs local pump control; HMI1 presents alarms and authorised commands; HIST1 stores operational trends. ENT-REPORT queries replica REP1 in an industrial DMZ. Approved flow: HIST1 → REP1 replication; ENT-REPORT → REP1 reports. No enterprise-to-PLC session is approved. ENG1 is an engineering workstation with an extra Wi-Fi interface on enterprise Wi-Fi. Its wired port is on the controller subnet; IP forwarding is unexpectedly enabled. A diagram shows one firewall conduit but omits ENG1 Wi-Fi and BMC management.

**Reasoning:** Map assets by function: PLC1 basic control, HMI1 supervisory, HIST1 operations support; the DMZ is an exchange boundary rather than proof of universal safety. The omitted ENG1 interfaces create a possible alternate path around the documented conduit. Verify forwarding, host policy and actual reachability using an authorised isolated test; do not assert exploitation merely from the configuration. Add BMC and support flows to the model, constrain the required path and test enterprise-to-PLC denial while preserving historian replication and reporting.

#### Guided practice

Design three positive and three negative rows for this architecture.

**Hint:** Use operations and identity, not only port reachability.

**Worked solution:** Positive: approved HIST1 replication, ENT-REPORT query to REP1, authorised HMI operator function. Negative: enterprise PLC command, REP1 controller administration, ENG1 unintended cross-interface forwarding. Observe application outcomes and host/network enforcement at the stated boundaries.

#### Independent task

Environment: analytical

Create an executable or tabular flow-policy evaluator for the supplied architecture, including alternate interfaces.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L006.json

**Evidence to produce**

- Functional-level map
- Zone/conduit and dependency matrix
- Positive/negative test results

**Acceptance criteria**

- Functional roles and trust boundaries are separate fields.
- Alternate interfaces and BMC authority are represented.
- Required reporting works without enterprise-to-controller authority.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0051 · single · mechanism**

Why classify HIST1 by function rather than by its Windows or Linux operating system?

SYNTHETIC ARCHITECTURE.
PLC1 performs local pump control; HMI1 presents alarms and authorised commands; HIST1 stores operational trends. ENT-REPORT queries replica REP1 in an industrial DMZ. Approved flow: HIST1 → REP1 replication; ENT-REPORT → REP1 reports. No enterprise-to-PLC session is approved. ENG1 is an engineering workstation with an extra Wi-Fi interface on enterprise Wi-Fi. Its wired port is on the controller subnet; IP forwarding is unexpectedly enabled. A diagram shows one firewall conduit but omits ENG1 Wi-Fi and BMC management.

1. HIST1 should inherit PLC1’s exact zone because its data originates there.
2. Its operations role determines the dependency being modelled.
3. HIST1 belongs in the enterprise zone because it stores historical rather than live values.
4. HIST1 and ENT-REPORT should share a zone because both run database clients.

**Correct option(s):** 2

- Option 1: Data origin does not make historian and controller functions or access requirements identical.
- Option 2: An OS can support several different industrial functions.
- Option 3: Its operational trend-storage function and dependencies still require OT architectural assessment.
- Option 4: Application technology alone does not establish equivalent trust or operational requirements.

**GICSP-Q0052 · single · diagnosis**

What is the principal concern with ENG1's omitted Wi-Fi and forwarding?

SYNTHETIC ARCHITECTURE.
PLC1 performs local pump control; HMI1 presents alarms and authorised commands; HIST1 stores operational trends. ENT-REPORT queries replica REP1 in an industrial DMZ. Approved flow: HIST1 → REP1 replication; ENT-REPORT → REP1 reports. No enterprise-to-PLC session is approved. ENG1 is an engineering workstation with an extra Wi-Fi interface on enterprise Wi-Fi. Its wired port is on the controller subnet; IP forwarding is unexpectedly enabled. A diagram shows one firewall conduit but omits ENG1 Wi-Fi and BMC management.

1. It may provide an unreviewed path between enterprise and controller networks.
2. Its wireless-to-wired forwarding is equivalent to the intended one-way replica flow.
3. The extra interface only affects radio performance and cannot change network reachability.
4. It proves the PLC was compromised.

**Correct option(s):** 1

- Option 1: Alternate interfaces can bypass the intended conduit.
- Option 2: It can create an alternate enterprise-to-controller path rather than the declared DMZ replication boundary.
- Option 3: Forwarding between interfaces can bypass the intended conduit.
- Option 4: Exposure is not proof of use or compromise.

**GICSP-Q0053 · single · mechanism**

Which statement best describes a security zone?

SYNTHETIC ARCHITECTURE.
PLC1 performs local pump control; HMI1 presents alarms and authorised commands; HIST1 stores operational trends. ENT-REPORT queries replica REP1 in an industrial DMZ. Approved flow: HIST1 → REP1 replication; ENT-REPORT → REP1 reports. No enterprise-to-PLC session is approved. ENG1 is an engineering workstation with an extra Wi-Fi interface on enterprise Wi-Fi. Its wired port is on the controller subnet; IP forwarding is unexpectedly enabled. A diagram shows one firewall conduit but omits ENG1 Wi-Fi and BMC management.

1. A grouping based on defined compatible security needs and consequences.
2. Every device in one building.
3. A guarantee that all members are trusted.
4. Every device with the same manufacturer.

**Correct option(s):** 1

- Option 1: Its rationale is risk/function, not only topology.
- Option 2: Physical co-location can contain different trust requirements.
- Option 3: Membership does not eliminate compromise or policy requirements.
- Option 4: Vendor identity does not establish common security needs.

**GICSP-Q0054 · single · design**

What is the intended benefit of REP1 in the DMZ?

SYNTHETIC ARCHITECTURE.
PLC1 performs local pump control; HMI1 presents alarms and authorised commands; HIST1 stores operational trends. ENT-REPORT queries replica REP1 in an industrial DMZ. Approved flow: HIST1 → REP1 replication; ENT-REPORT → REP1 reports. No enterprise-to-PLC session is approved. ENG1 is an engineering workstation with an extra Wi-Fi interface on enterprise Wi-Fi. Its wired port is on the controller subnet; IP forwarding is unexpectedly enabled. A diagram shows one firewall conduit but omits ENG1 Wi-Fi and BMC management.

1. It guarantees that all traffic is encrypted.
2. The replica removes the need to maintain HIST1 or test its recovery.
3. It supports bounded data exchange without arbitrary direct enterprise controller access.
4. It makes every enterprise client a controller administrator.

**Correct option(s):** 3

- Option 1: Encryption requires an explicit supported mechanism.
- Option 2: The architectural decoupling does not eliminate the source service’s lifecycle responsibilities.
- Option 3: Mediation separates reporting needs from control authority.
- Option 4: That contradicts the approved flow.

**GICSP-Q0055 · single · implementation**

Which evidence establishes enterprise-to-PLC denial more strongly than a diagram?

SYNTHETIC ARCHITECTURE.
PLC1 performs local pump control; HMI1 presents alarms and authorised commands; HIST1 stores operational trends. ENT-REPORT queries replica REP1 in an industrial DMZ. Approved flow: HIST1 → REP1 replication; ENT-REPORT → REP1 reports. No enterprise-to-PLC session is approved. ENG1 is an engineering workstation with an extra Wi-Fi interface on enterprise Wi-Fi. Its wired port is on the controller subnet; IP forwarding is unexpectedly enabled. A diagram shows one firewall conduit but omits ENG1 Wi-Fi and BMC management.

1. REP1's report query succeeds.
2. An authorised negative application-path test covering the actual alternate routes.
3. The diagram places a firewall on the intended path, without testing ENG1’s alternate interface.
4. The VLAN’s security label is sufficient without a negative reachability test.

**Correct option(s):** 2

- Option 1: A positive report path does not test the forbidden controller path.
- Option 2: Effective enforcement must be observed.
- Option 3: A drawn boundary does not establish that every effective path crosses it.
- Option 4: A label does not establish actual path enforcement.

**GICSP-Q0056 · single · mechanism**

Why add BMC management to the architecture?

SYNTHETIC ARCHITECTURE.
PLC1 performs local pump control; HMI1 presents alarms and authorised commands; HIST1 stores operational trends. ENT-REPORT queries replica REP1 in an industrial DMZ. Approved flow: HIST1 → REP1 replication; ENT-REPORT → REP1 reports. No enterprise-to-PLC session is approved. ENG1 is an engineering workstation with an extra Wi-Fi interface on enterprise Wi-Fi. Its wired port is on the controller subnet; IP forwarding is unexpectedly enabled. A diagram shows one firewall conduit but omits ENG1 Wi-Fi and BMC management.

1. BMC is another name for the historian database.
2. BMC traffic always follows the host firewall.
3. It can provide powerful administrative authority independent of the host OS path.
4. BMC accounts cannot affect availability.

**Correct option(s):** 3

- Option 1: It is a separate management subsystem.
- Option 2: That is not guaranteed by the architecture.
- Option 3: Management dependencies can cross guest/application boundaries.
- Option 4: Their supported functions may include power and boot control.

**GICSP-Q0057 · multi · design**

Which flows require explicit design even if they are not the primary process protocol? Select all that apply.

SYNTHETIC ARCHITECTURE.
PLC1 performs local pump control; HMI1 presents alarms and authorised commands; HIST1 stores operational trends. ENT-REPORT queries replica REP1 in an industrial DMZ. Approved flow: HIST1 → REP1 replication; ENT-REPORT → REP1 reports. No enterprise-to-PLC session is approved. ENG1 is an engineering workstation with an extra Wi-Fi interface on enterprise Wi-Fi. Its wired port is on the controller subnet; IP forwarding is unexpectedly enabled. A diagram shows one firewall conduit but omits ENG1 Wi-Fi and BMC management.

1. Time and identity services
2. Unrestricted enterprise browsing from every controller
3. Backup and recovery access
4. Approved engineering and update services

**Correct option(s):** 1, 3, 4

- Option 1: They can determine authentication and event meaning.
- Option 2: No requirement justifies this blanket flow.
- Option 3: Restoration depends on those supporting paths.
- Option 4: Their authority and timing need controlled paths.

**GICSP-Q0058 · single · implementation**

A firewall permits only the approved TCP port, but REP1's account can change controller logic through that service. What is missing?

SYNTHETIC ARCHITECTURE.
PLC1 performs local pump control; HMI1 presents alarms and authorised commands; HIST1 stores operational trends. ENT-REPORT queries replica REP1 in an industrial DMZ. Approved flow: HIST1 → REP1 replication; ENT-REPORT → REP1 reports. No enterprise-to-PLC session is approved. ENG1 is an engineering workstation with an extra Wi-Fi interface on enterprise Wi-Fi. Its wired port is on the controller subnet; IP forwarding is unexpectedly enabled. A diagram shows one firewall conduit but omits ENG1 Wi-Fi and BMC management.

1. Move REP1 to a different subnet while keeping its unrestricted controller role.
2. Deny the entire TCP service even if the required reporting path is lost.
3. Add inventory labels for REP1’s account without changing or testing its effective role.
4. Operation-level authority control matching the requirement.

**Correct option(s):** 4

- Option 1: Subnet placement alone does not remove the application capability carried by the permitted service.
- Option 2: The design must preserve required operations while restricting consequential ones.
- Option 3: Documentation alone does not remove the controller-changing operation capability.
- Option 4: A port allowance can carry several application operations.

**GICSP-Q0059 · single · recovery**

Does disabling ENG1 forwarding alone prove the complete segmentation requirement?

SYNTHETIC ARCHITECTURE.
PLC1 performs local pump control; HMI1 presents alarms and authorised commands; HIST1 stores operational trends. ENT-REPORT queries replica REP1 in an industrial DMZ. Approved flow: HIST1 → REP1 replication; ENT-REPORT → REP1 reports. No enterprise-to-PLC session is approved. ENG1 is an engineering workstation with an extra Wi-Fi interface on enterprise Wi-Fi. Its wired port is on the controller subnet; IP forwarding is unexpectedly enabled. A diagram shows one firewall conduit but omits ENG1 Wi-Fi and BMC management.

1. Yes; every possible bypass used that single setting.
2. Yes if the administrator says the command succeeded.
3. No; verify other paths, host/application behaviour and required positive/negative outcomes.
4. No; segmentation is impossible.

**Correct option(s):** 3

- Option 1: The supplied model was incomplete.
- Option 2: Command success is not complete service evidence.
- Option 3: One correction does not audit every alternate dependency.
- Option 4: Suitable controls and testing can establish bounded enforcement.

**GICSP-Q0060 · single · operations**

Which final architecture claim is defensible after isolated tests pass?

SYNTHETIC ARCHITECTURE.
PLC1 performs local pump control; HMI1 presents alarms and authorised commands; HIST1 stores operational trends. ENT-REPORT queries replica REP1 in an industrial DMZ. Approved flow: HIST1 → REP1 replication; ENT-REPORT → REP1 reports. No enterprise-to-PLC session is approved. ENG1 is an engineering workstation with an extra Wi-Fi interface on enterprise Wi-Fi. Its wired port is on the controller subnet; IP forwarding is unexpectedly enabled. A diagram shows one firewall conduit but omits ENG1 Wi-Fi and BMC management.

1. Production cutover authority has been awarded.
2. The enterprise has no possible threat path.
3. Every Purdue-based plant is now secure.
4. The documented flows and denials passed in the specified lab configuration.

**Correct option(s):** 4

- Option 1: Authority is a separate organisational decision.
- Option 2: Tested boundaries do not establish universal absence of paths.
- Option 3: A reference model does not generalise one lab to all plants.
- Option 4: Scope and fidelity match the observations.

#### Recall

**Purdue level versus security zone?**

A functional level describes what a system does; a zone groups common security requirements. Neither alone proves enforcement.

**What does an industrial DMZ need beyond placement?**

Explicit bounded services, identities, directions, patching, monitoring, recovery and tests that prevent unintended cross-boundary authority.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

### GICSP-L007 — Asset reconciliation and dependency graphs

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L006

### An address is an observation, not an asset
Inventory should distinguish physical devices, network interfaces, logical services and identities. A server can have production, storage and BMC addresses; a virtual IP can move between nodes; a serial gateway can represent many downstream devices through one IP. Counting addresses as devices produces both overcounting and blind spots. Use stable identifiers appropriate to the asset, such as serial number, supported device identifier or a governed application record, and record how each observation was matched.

Reconcile several evidence sources rather than declaring one complete. Procurement records show what was ordered; physical inspection shows what is present at a permitted location; switch and routing observations show communication; management interfaces expose supported inventory; application configuration shows expected dependencies. Each can be stale or incomplete. Passive traffic does not reveal a silent spare. A configuration entry does not establish that a device is still installed. Mark conflicting or unverified relationships explicitly and retain the evidence that would resolve them.

### A useful asset record supports decisions
Record role, location, owner, critical function, hardware/firmware/software versions, support status, interfaces, administrative identity, time source, backup method and recovery dependencies. Do not place actual credentials in the inventory export. Link to their governed custody mechanism and required recovery procedure. Version fields must identify their source and observation time; a six-month-old scan is not current firmware evidence.

Data flows add meaning to the asset graph. For each required service, identify the source, destination, operation, direction, identity, timing and loss behaviour. Include less obvious dependencies: a licence service, DNS, certificate validation, a backup catalogue, storage zoning or a remote support portal. One shared administrator across several segments can create a common compromise path even when their network routes are separated. Distinguish physical, communication, data and authority dependencies because different failures affect them differently.

### Find cycles before an incident
A restoration plan may contain a dependency cycle. The backup catalogue runs on the server that must be restored; the catalogue's credentials are available only through the failed directory; the directory backup is encrypted with a key stored in that catalogue. Drawing directed edges reveals that no first recovery step is available. Break the cycle with separately protected and tested recovery access, compatible offline records and the approved key custody. The solution must remain secure: a public plaintext copy is independent but unacceptable.

Use the graph to plan order and scope. Restore prerequisites before dependent services, or provide an explicitly supported temporary alternative. Parallel tasks can reduce elapsed time only when their dependencies and resources permit it. A topological ordering is useful for an acyclic model, but it is not a complete operational runbook: actual configuration, authority, verification and fallback still matter. Test at least one unavailable dependency rather than preparing every prerequisite silently.

### Keep uncertainty and change visible
An asset inventory is maintained through receiving, deployment, change, incident, replacement and retirement. A new motherboard can change management identity; a replacement HBA can change storage access; a retired server may leave valid certificates behind. Reconcile the expected and actual records after work, and inspect unexplained drift. Acceptance should state which inventory population was observed, which interfaces remain hidden and when the evidence was collected. This is a foundation for architecture, vulnerability assessment and response; it is not merely an administrative spreadsheet.

#### Worked demonstrations

**Evidence walkthrough**

SYNTHETIC RECONCILIATION SET.
Physical register: servers S1,S2; gateway G1; six serial meters M1–M6. Network observation: S1 host 192.0.2.11 and BMC .111; S2 host .12 and BMC .112; G1 .20. HIST service runs on S1; DIRECTORY and BACKUP-CATALOG run as guests on S2. Backup media are offline, but their decryption key is retrievable only through DIRECTORY. S2 recovery procedure first requires BACKUP-CATALOG login. G1 configuration lists M1–M6; traffic confirms only M1–M4 today. Shared account vendor_admin administers both BMCs and the backup console.

**Reasoning:** The listed physical population is nine devices if all six meter entries correspond to installed devices: two servers, one gateway and six meters. Only four downstream meters have current traffic confirmation; M5/M6 remain unverified, not absent by default. Host and BMC addresses are interfaces of their servers. Recovery of S2 has a catalogue/identity dependency cycle despite offline media. Shared vendor_admin is an authority dependency across management and backup. Create separately governed recovery access and key custody, then test S2 recovery with its ordinary directory/catalogue unavailable.

#### Guided practice

Draw four kinds of dependency for HIST: physical, communication, data and authority.

**Hint:** Avoid treating every edge as a cable.

**Worked solution:** Physical: S1 power/cooling/host. Communication: required meter/gateway and client paths. Data: historian database/backups. Authority: service identity and management/recovery accounts. Include time and DNS where the selected implementation requires them; mark unknown facts rather than inventing dependencies.

#### Independent task

Environment: analytical

Reconcile the supplied population and produce a recovery ordering that works with S2 unavailable.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L007.json

**Evidence to produce**

- Asset/interface/service tables
- Evidence-confidence register
- Dependency cycle and corrected recovery graph

**Acceptance criteria**

- IP count is not reported as physical-device count.
- M5/M6 remain explicitly unverified.
- The corrected graph has a protected independently usable first recovery step.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0061 · single · calculation**

How many physical devices are listed, assuming the six meters are distinct installed units?

SYNTHETIC RECONCILIATION SET.
Physical register: servers S1,S2; gateway G1; six serial meters M1–M6. Network observation: S1 host 192.0.2.11 and BMC .111; S2 host .12 and BMC .112; G1 .20. HIST service runs on S1; DIRECTORY and BACKUP-CATALOG run as guests on S2. Backup media are offline, but their decryption key is retrievable only through DIRECTORY. S2 recovery procedure first requires BACKUP-CATALOG login. G1 configuration lists M1–M6; traffic confirms only M1–M4 today. Shared account vendor_admin administers both BMCs and the backup console.

1. Nine
2. Eleven
3. Five
4. Seven

**Correct option(s):** 1

- Option 1: Two servers plus one gateway plus six meters equals nine.
- Option 2: Host and BMC interfaces must not be counted as separate servers.
- Option 3: That counts observed IP endpoints but omits serial devices.
- Option 4: That omits two listed devices without justification.

**GICSP-Q0062 · single · diagnosis**

What is justified about M5 and M6 from today's traffic alone?

SYNTHETIC RECONCILIATION SET.
Physical register: servers S1,S2; gateway G1; six serial meters M1–M6. Network observation: S1 host 192.0.2.11 and BMC .111; S2 host .12 and BMC .112; G1 .20. HIST service runs on S1; DIRECTORY and BACKUP-CATALOG run as guests on S2. Backup media are offline, but their decryption key is retrievable only through DIRECTORY. S2 recovery procedure first requires BACKUP-CATALOG login. G1 configuration lists M1–M6; traffic confirms only M1–M4 today. Shared account vendor_admin administers both BMCs and the backup console.

1. They are necessarily compromised.
2. Their current communication/installation status is not confirmed by that observation.
3. They have definitely been decommissioned.
4. They are healthy because configuration lists them.

**Correct option(s):** 2

- Option 1: Lack of traffic does not establish compromise.
- Option 2: Silence can have several causes.
- Option 3: No retirement evidence is supplied.
- Option 4: Intended configuration is not current functional evidence.

**GICSP-Q0063 · single · recovery**

Why is offline backup media insufficient for the stated S2 recovery?

SYNTHETIC RECONCILIATION SET.
Physical register: servers S1,S2; gateway G1; six serial meters M1–M6. Network observation: S1 host 192.0.2.11 and BMC .111; S2 host .12 and BMC .112; G1 .20. HIST service runs on S1; DIRECTORY and BACKUP-CATALOG run as guests on S2. Backup media are offline, but their decryption key is retrievable only through DIRECTORY. S2 recovery procedure first requires BACKUP-CATALOG login. G1 configuration lists M1–M6; traffic confirms only M1–M4 today. Shared account vendor_admin administers both BMCs and the backup console.

1. A BMC address is missing from the record.
2. The backup must contain malware.
3. Offline media can never be restored.
4. The usable key and catalogue access still depend on services hosted by S2.

**Correct option(s):** 4

- Option 1: Both BMCs are listed; the issue is the recovery dependency.
- Option 2: No compromise evidence is supplied.
- Option 3: They can be useful with appropriate access and methods.
- Option 4: Media survival does not guarantee a usable restore path.

**GICSP-Q0064 · single · design**

What risk does vendor_admin create despite separate host networks?

SYNTHETIC RECONCILIATION SET.
Physical register: servers S1,S2; gateway G1; six serial meters M1–M6. Network observation: S1 host 192.0.2.11 and BMC .111; S2 host .12 and BMC .112; G1 .20. HIST service runs on S1; DIRECTORY and BACKUP-CATALOG run as guests on S2. Backup media are offline, but their decryption key is retrievable only through DIRECTORY. S2 recovery procedure first requires BACKUP-CATALOG login. G1 configuration lists M1–M6; traffic confirms only M1–M4 today. Shared account vendor_admin administers both BMCs and the backup console.

1. The common account improves backup independence by giving both BMCs the same access.
2. A shared administrative compromise can affect BMC and backup authority.
3. The common account provides cryptographic protection for the serial bus.
4. It guarantees both servers will fail together.

**Correct option(s):** 2

- Option 1: Shared authority can create a common compromise path rather than independent recovery custody.
- Option 2: Segmentation does not remove shared identity exposure.
- Option 3: Shared administrative credentials do not change serial transport confidentiality.
- Option 4: Shared exposure is not certainty.

**GICSP-Q0065 · single · implementation**

Which identifier best supports distinguishing S1's host and BMC observations as one physical server?

SYNTHETIC RECONCILIATION SET.
Physical register: servers S1,S2; gateway G1; six serial meters M1–M6. Network observation: S1 host 192.0.2.11 and BMC .111; S2 host .12 and BMC .112; G1 .20. HIST service runs on S1; DIRECTORY and BACKUP-CATALOG run as guests on S2. Backup media are offline, but their decryption key is retrievable only through DIRECTORY. S2 recovery procedure first requires BACKUP-CATALOG login. G1 configuration lists M1–M6; traffic confirms only M1–M4 today. Shared account vendor_admin administers both BMCs and the backup console.

1. A verified stable device/service-tag relationship from the actual platform.
2. The number of open ports.
3. A matching operating-system hostname between the host and BMC records.
4. The final octet alone.

**Correct option(s):** 1

- Option 1: It connects interfaces to the physical asset.
- Option 2: Services do not establish physical identity.
- Option 3: Names do not independently establish the physical/interface relationship; use stable identity evidence.
- Option 4: Address conventions can be wrong or reused.

**GICSP-Q0066 · multi · design**

Which inventory fields should reference protected custody rather than expose secrets? Select all that apply.

SYNTHETIC RECONCILIATION SET.
Physical register: servers S1,S2; gateway G1; six serial meters M1–M6. Network observation: S1 host 192.0.2.11 and BMC .111; S2 host .12 and BMC .112; G1 .20. HIST service runs on S1; DIRECTORY and BACKUP-CATALOG run as guests on S2. Backup media are offline, but their decryption key is retrievable only through DIRECTORY. S2 recovery procedure first requires BACKUP-CATALOG login. G1 configuration lists M1–M6; traffic confirms only M1–M4 today. Shared account vendor_admin administers both BMCs and the backup console.

1. A public copy of every private key
2. Recovery-key retrieval procedure
3. Administrative credential owner/custody reference
4. Certificate/identity lifecycle owner

**Correct option(s):** 2, 3, 4

- Option 1: Publication would expose authority.
- Option 2: The inventory needs usable governed access, not plaintext keys.
- Option 3: Accountability can be recorded without disclosing credentials.
- Option 4: Ownership supports renewal and revocation planning.

**GICSP-Q0067 · single · calculation**

What must be true before two recovery tasks are credited as parallel time savings?

SYNTHETIC RECONCILIATION SET.
Physical register: servers S1,S2; gateway G1; six serial meters M1–M6. Network observation: S1 host 192.0.2.11 and BMC .111; S2 host .12 and BMC .112; G1 .20. HIST service runs on S1; DIRECTORY and BACKUP-CATALOG run as guests on S2. Backup media are offline, but their decryption key is retrievable only through DIRECTORY. S2 recovery procedure first requires BACKUP-CATALOG login. G1 configuration lists M1–M6; traffic confirms only M1–M4 today. Shared account vendor_admin administers both BMCs and the backup console.

1. Their dependencies, resources and authorised methods allow concurrent execution.
2. Both tasks use a network.
3. They have different ticket numbers.
4. They are performed by the same person at the same time.

**Correct option(s):** 1

- Option 1: A diagram alone cannot remove resource or ordering constraints.
- Option 2: Common technology does not establish parallel feasibility.
- Option 3: Administrative labels do not establish independence.
- Option 4: A shared human resource may prevent genuine concurrency.

**GICSP-Q0068 · single · operations**

A replacement HBA has a new WWN but the storage register keeps the old one. What is required?

SYNTHETIC RECONCILIATION SET.
Physical register: servers S1,S2; gateway G1; six serial meters M1–M6. Network observation: S1 host 192.0.2.11 and BMC .111; S2 host .12 and BMC .112; G1 .20. HIST service runs on S1; DIRECTORY and BACKUP-CATALOG run as guests on S2. Backup media are offline, but their decryption key is retrievable only through DIRECTORY. S2 recovery procedure first requires BACKUP-CATALOG login. G1 configuration lists M1–M6; traffic confirms only M1–M4 today. Shared account vendor_admin administers both BMCs and the backup console.

1. Assume the replacement inherits the old WWN because the operating-system hostname is unchanged.
2. Remove zoning restrictions temporarily without a target-specific access and rollback plan.
3. Update the asset label and retain the old WWN in zoning and masking.
4. Reconcile identity and approved storage access, then verify the required I/O path.

**Correct option(s):** 4

- Option 1: The HBA identity changes independently of the host name.
- Option 2: That broadens storage authority instead of validating the replacement’s intended access.
- Option 3: The effective storage authorisation must be reconciled to the replacement identity.
- Option 4: Hardware replacement can alter external authorisation dependencies.

**GICSP-Q0069 · single · recovery**

Which recovery change breaks the cycle without casually exposing secrets?

SYNTHETIC RECONCILIATION SET.
Physical register: servers S1,S2; gateway G1; six serial meters M1–M6. Network observation: S1 host 192.0.2.11 and BMC .111; S2 host .12 and BMC .112; G1 .20. HIST service runs on S1; DIRECTORY and BACKUP-CATALOG run as guests on S2. Backup media are offline, but their decryption key is retrievable only through DIRECTORY. S2 recovery procedure first requires BACKUP-CATALOG login. G1 configuration lists M1–M6; traffic confirms only M1–M4 today. Shared account vendor_admin administers both BMCs and the backup console.

1. A second copy of the inaccessible encrypted file.
2. Another catalogue guest on the same failed host.
3. A plaintext key in the public repository.
4. Separately governed recovery identity and key access, tested with normal services unavailable.

**Correct option(s):** 4

- Option 1: Copying ciphertext does not restore key availability.
- Option 2: The physical failure dependency remains.
- Option 3: Independence does not justify disclosure.
- Option 4: It provides a protected independent starting point.

**GICSP-Q0070 · single · operations**

What should an inventory completeness claim include?

SYNTHETIC RECONCILIATION SET.
Physical register: servers S1,S2; gateway G1; six serial meters M1–M6. Network observation: S1 host 192.0.2.11 and BMC .111; S2 host .12 and BMC .112; G1 .20. HIST service runs on S1; DIRECTORY and BACKUP-CATALOG run as guests on S2. Backup media are offline, but their decryption key is retrievable only through DIRECTORY. S2 recovery procedure first requires BACKUP-CATALOG login. G1 configuration lists M1–M6; traffic confirms only M1–M4 today. Shared account vendor_admin administers both BMCs and the backup console.

1. Only purchase-order totals.
2. Observed population, evidence dates, reconciliation method and unresolved visibility limits.
3. A promise that passive capture sees every device.
4. Only the total row count.

**Correct option(s):** 2

- Option 1: Purchased, installed and operating populations can differ.
- Option 2: Completeness depends on scope and evidence quality.
- Option 3: Silent and downstream devices may remain unseen.
- Option 4: Rows can duplicate or omit assets.

#### Recall

**Why separate assets, interfaces and services?**

One device can expose many interfaces/services, while one gateway or virtual address can represent several devices.

**What is a recovery dependency cycle?**

A service needed for restoration is itself recoverable only through another unavailable dependent service; establish protected independent access and test it.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

### GICSP-L008 — Routing, segmentation and application enforcement

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L007

### Start with the packet path
For a local IPv4 destination, a host uses its prefix/mask decision and ARP to resolve the appropriate link-layer destination. For a remote destination it normally sends to a next-hop gateway. Routers select the most-specific matching route, then apply the relevant forwarding and policy behaviour. A default route is less specific than a listed subnet route; it does not automatically replace a stale more-specific path. Inspect both the route decision and the actual next-hop/return path when a service fails.

IPv6 adds its own address scopes, neighbour discovery and router-advertisement behaviour. An IPv4 deny rule does not necessarily cover IPv6. Essential ICMPv6 supports functions such as neighbour discovery and path-MTU discovery; a blanket block can produce failures that only appear with larger traffic. Inventory enabled families and test each required permitted and denied path. Disabling a family can be an approved design choice, but assuming it is absent without verification is not evidence.

### Segmentation is a system of enforcement points
A VLAN separates a broadcast domain; inter-VLAN routing can restore reachability. A VRF separates routing contexts; deliberate or accidental route leaking can connect them. A firewall can constrain source, destination, service and supported application attributes, but its capability must be verified on the selected product. Classic port filtering cannot distinguish every industrial read from write when both use the same transport port. Where the requirement is operation-level authority, enforce it through the supported application/protocol gateway or device control and test that specific operation.

Stateful inspection records aspects of a session. If forward and reverse traffic traverse incompatible stateful paths, an otherwise valid route can fail. High-availability devices may synchronise state only for supported protocols and configurations. Test established and new sessions during failover; they can behave differently. An asymmetric path is not inherently invalid IP routing, but can conflict with the deployed enforcement design.

### Read effective policy in context
Rule order, object definitions, address translation and inherited policy affect the result. A narrow deny below a broad permit may never match. A log's source address may be pre- or post-translation depending on the observation point. A disabled rule or wrong zone pair can make an accurate-looking policy irrelevant. Record the actual evaluated rule, interfaces/zones, state and application outcome. A “deny” log may be correct enforcement, while absence of logs may reflect logging configuration rather than absence of traffic.

Plan negative tests from requirements. If a historian may read but not write, test both operations. If a vendor may reach one controller, test an unrelated controller and the management plane. If a guest network is excluded, test all enabled address families and alternate interfaces. Do not satisfy a failed legitimate flow by installing an allow-all rule; that can make a different mandatory criterion fail.

### Changes and recovery preserve the matrix
Back up approved policy with its object definitions and dependencies. Stage a correction on a bounded lab target, observe effect and verify related allowed/denied paths. Rollback restores effective service and authority, not merely configuration text. Retain the route/policy evidence before and after the change, including any period of excess access. The programme's independent task uses documentation addresses and an offline model; actual device timing and protocol enforcement require supported isolated platform practice.

#### Worked demonstrations

**Evidence walkthrough**

SYNTHETIC POLICY, first match wins; ordinary transport ACL only.
1 permit tcp 192.0.2.0/24 → 198.51.100.20/32 port 502
2 deny tcp 192.0.2.10/32 → 198.51.100.20/32 port 502
3 deny any
Requirement: historian .10 may read controller .20 but must not write. No application role check is configured.
Routing: 198.51.100.0/24 via unavailable next hop N1 remains installed; default via N2 is healthy.
IPv4 guest-to-management denial passes; IPv6 guest-to-management reaches the service.
Failover: forward traffic changes firewall, return traffic still crosses the old firewall without shared state.

**Reasoning:** Rule 1 matches the historian before rule 2, so the intended narrow deny is shadowed. Even reversing the two rules would deny both reads and writes; a transport-only ACL cannot express this operation requirement by itself. Add the supported operation-level enforcement and test it. The stale /24 wins over the default, explaining a path-specific outage. IPv6 provides an unblocked management path, so dual-stack isolation fails. The stateful asymmetry is a separate failover issue that requires supported path/state handling rather than broad policy removal.

#### Guided practice

Create a revised two-layer design that permits reads and denies writes.

**Hint:** Keep network scope and application operation distinct.

**Worked solution:** Use a narrow approved source/destination/service allowance at the transport layer and a supported authenticated operation/role control or industrial gateway for read/write restriction. Classic Modbus does not gain user authentication from this design label; select and verify actual capabilities. Test authorised reads, denied writes, unrelated sources and both enabled families.

#### Independent task

Environment: analytical

Run the supplied offline policy lab, then explain where its application fields exceed ordinary port ACL capability.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L008.json
- course_labs/GICSP/lab.py
- course_labs/GICSP/fixture.json
- course_labs/GICSP/README.md

**Evidence to produce**

- First-match trace
- Layered flow matrix
- Routing and failover diagnosis

**Acceptance criteria**

- Read/write enforcement is not attributed to port filtering alone.
- The stale specific route and IPv6 bypass are identified separately.
- Corrections retain required positive service.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0071 · single · implementation**

Which rule evaluates the historian's TCP 502 traffic first?

SYNTHETIC POLICY, first match wins; ordinary transport ACL only.
1 permit tcp 192.0.2.0/24 → 198.51.100.20/32 port 502
2 deny tcp 192.0.2.10/32 → 198.51.100.20/32 port 502
3 deny any
Requirement: historian .10 may read controller .20 but must not write. No application role check is configured.
Routing: 198.51.100.0/24 via unavailable next hop N1 remains installed; default via N2 is healthy.
IPv4 guest-to-management denial passes; IPv6 guest-to-management reaches the service.
Failover: forward traffic changes firewall, return traffic still crosses the old firewall without shared state.

1. Rule 2 because it is more specific
2. Rule 1
3. No rule because TCP 502 cannot be filtered
4. Rule 3 because deny always overrides permit

**Correct option(s):** 2

- Option 1: ACL order, not routing longest-prefix logic, controls this stated model.
- Option 2: The broad source subnet includes .10 and first-match evaluation stops there.
- Option 3: Transport filters can match the port.
- Option 4: That is not the supplied first-match semantics.

**GICSP-Q0072 · single · design**

Would moving rule 2 above rule 1 alone satisfy the historian requirement?

SYNTHETIC POLICY, first match wins; ordinary transport ACL only.
1 permit tcp 192.0.2.0/24 → 198.51.100.20/32 port 502
2 deny tcp 192.0.2.10/32 → 198.51.100.20/32 port 502
3 deny any
Requirement: historian .10 may read controller .20 but must not write. No application role check is configured.
Routing: 198.51.100.0/24 via unavailable next hop N1 remains installed; default via N2 is healthy.
IPv4 guest-to-management denial passes; IPv6 guest-to-management reaches the service.
Failover: forward traffic changes firewall, return traffic still crosses the old firewall without shared state.

1. No; first-match order has no effect when a broader permit exists.
2. No; it would deny required reads as well as writes.
3. Yes; putting the historian deny first preserves its read traffic while rejecting writes.
4. Yes; the Modbus unit identifier authenticates H and enforces its role.

**Correct option(s):** 2

- Option 1: Moving the specific deny changes the match but blocks both reads and writes rather than meeting the requirement.
- Option 2: The rule does not inspect application operation.
- Option 3: The transport ACL cannot distinguish read from write within the same TCP service.
- Option 4: The unit field identifies a protocol target context, not a user’s read-only authority.

**GICSP-Q0073 · single · mechanism**

Which route normally handles traffic to 198.51.100.20 in the supplied table?

SYNTHETIC POLICY, first match wins; ordinary transport ACL only.
1 permit tcp 192.0.2.0/24 → 198.51.100.20/32 port 502
2 deny tcp 192.0.2.10/32 → 198.51.100.20/32 port 502
3 deny any
Requirement: historian .10 may read controller .20 but must not write. No application role check is configured.
Routing: 198.51.100.0/24 via unavailable next hop N1 remains installed; default via N2 is healthy.
IPv4 guest-to-management denial passes; IPv6 guest-to-management reaches the service.
Failover: forward traffic changes firewall, return traffic still crosses the old firewall without shared state.

1. Both routes equally
2. The installed /24 route via N1
3. The default because N2 is healthy
4. No route because an ACL exists

**Correct option(s):** 2

- Option 1: They are different prefix lengths, not equal-cost alternatives.
- Option 2: It is more specific than the default.
- Option 3: Health does not override a still-installed more-specific route by itself.
- Option 4: Routing and filtering are distinct decisions.

**GICSP-Q0074 · single · diagnosis**

What does the IPv6 guest test demonstrate?

SYNTHETIC POLICY, first match wins; ordinary transport ACL only.
1 permit tcp 192.0.2.0/24 → 198.51.100.20/32 port 502
2 deny tcp 192.0.2.10/32 → 198.51.100.20/32 port 502
3 deny any
Requirement: historian .10 may read controller .20 but must not write. No application role check is configured.
Routing: 198.51.100.0/24 via unavailable next hop N1 remains installed; default via N2 is healthy.
IPv4 guest-to-management denial passes; IPv6 guest-to-management reaches the service.
Failover: forward traffic changes firewall, return traffic still crosses the old firewall without shared state.

1. The IPv4 test result was fabricated
2. IPv6 cannot support access controls
3. DNS is necessarily compromised
4. The intended management isolation is incomplete across enabled families.

**Correct option(s):** 4

- Option 1: Both observations can be true.
- Option 2: Suitable IPv6 policy mechanisms exist.
- Option 3: Direct reachability does not establish DNS compromise.
- Option 4: IPv4 success does not cover the IPv6 path.

**GICSP-Q0075 · single · diagnosis**

What can explain the failover session loss?

SYNTHETIC POLICY, first match wins; ordinary transport ACL only.
1 permit tcp 192.0.2.0/24 → 198.51.100.20/32 port 502
2 deny tcp 192.0.2.10/32 → 198.51.100.20/32 port 502
3 deny any
Requirement: historian .10 may read controller .20 but must not write. No application role check is configured.
Routing: 198.51.100.0/24 via unavailable next hop N1 remains installed; default via N2 is healthy.
IPv4 guest-to-management denial passes; IPv6 guest-to-management reaches the service.
Failover: forward traffic changes firewall, return traffic still crosses the old firewall without shared state.

1. Forward/return traffic crosses incompatible stateful paths.
2. The application must have changed its password
3. IP universally requires symmetric routing
4. Every failover requires a physical cable fault

**Correct option(s):** 1

- Option 1: A firewall can lack the state expected for the returning packets.
- Option 2: No identity evidence supports this cause.
- Option 3: IP itself can support asymmetry.
- Option 4: Policy and state transitions can cause failure without media damage.

**GICSP-Q0076 · single · mechanism**

Which packet-size-dependent problem can a blanket ICMPv6 block create?

SYNTHETIC POLICY, first match wins; ordinary transport ACL only.
1 permit tcp 192.0.2.0/24 → 198.51.100.20/32 port 502
2 deny tcp 192.0.2.10/32 → 198.51.100.20/32 port 502
3 deny any
Requirement: historian .10 may read controller .20 but must not write. No application role check is configured.
Routing: 198.51.100.0/24 via unavailable next hop N1 remains installed; default via N2 is healthy.
IPv4 guest-to-management denial passes; IPv6 guest-to-management reaches the service.
Failover: forward traffic changes firewall, return traffic still crosses the old firewall without shared state.

1. Broken path-MTU discovery when Packet Too Big feedback is needed.
2. Automatic IPv4 encryption
3. It increases the fibre link budget available to the connection.
4. It strengthens application authorisation by removing packet-size feedback.

**Correct option(s):** 1

- Option 1: Large transfers can fail while small probes succeed.
- Option 2: The families and security mechanisms are separate.
- Option 3: Network error-message policy does not change optical power loss.
- Option 4: Blocking essential ICMPv6 can break path-MTU discovery without adding operation-level authority.

**GICSP-Q0077 · multi · implementation**

Which observations belong in a useful policy test? Select all that apply.

SYNTHETIC POLICY, first match wins; ordinary transport ACL only.
1 permit tcp 192.0.2.0/24 → 198.51.100.20/32 port 502
2 deny tcp 192.0.2.10/32 → 198.51.100.20/32 port 502
3 deny any
Requirement: historian .10 may read controller .20 but must not write. No application role check is configured.
Routing: 198.51.100.0/24 via unavailable next hop N1 remains installed; default via N2 is healthy.
IPv4 guest-to-management denial passes; IPv6 guest-to-management reaches the service.
Failover: forward traffic changes firewall, return traffic still crosses the old firewall without shared state.

1. The return path and session state when relevant
2. Only a screenshot of the intended rule order
3. The actual evaluated rule and address/zone context
4. The required application operation and outcome

**Correct option(s):** 1, 3, 4

- Option 1: Stateful enforcement can depend on both directions.
- Option 2: Intended configuration may differ from effective state.
- Option 3: They identify the enforcement decision.
- Option 4: Port reachability alone is insufficient.

**GICSP-Q0078 · single · operations**

A deny log appears for an unrelated vendor target. What is the first interpretation to test?

SYNTHETIC POLICY, first match wins; ordinary transport ACL only.
1 permit tcp 192.0.2.0/24 → 198.51.100.20/32 port 502
2 deny tcp 192.0.2.10/32 → 198.51.100.20/32 port 502
3 deny any
Requirement: historian .10 may read controller .20 but must not write. No application role check is configured.
Routing: 198.51.100.0/24 via unavailable next hop N1 remains installed; default via N2 is healthy.
IPv4 guest-to-management denial passes; IPv6 guest-to-management reaches the service.
Failover: forward traffic changes firewall, return traffic still crosses the old firewall without shared state.

1. It may be correct enforcement of the approved scope.
2. The firewall must be disabled
3. The controller is offline
4. Every vendor task failed

**Correct option(s):** 1

- Option 1: A blocked request is not automatically a fault.
- Option 2: Broad removal is not justified by a deny.
- Option 3: Policy denial does not establish device state.
- Option 4: The approved target may still work.

**GICSP-Q0079 · single · diagnosis**

Why must a translated-address log identify its observation point?

SYNTHETIC POLICY, first match wins; ordinary transport ACL only.
1 permit tcp 192.0.2.0/24 → 198.51.100.20/32 port 502
2 deny tcp 192.0.2.10/32 → 198.51.100.20/32 port 502
3 deny any
Requirement: historian .10 may read controller .20 but must not write. No application role check is configured.
Routing: 198.51.100.0/24 via unavailable next hop N1 remains installed; default via N2 is healthy.
IPv4 guest-to-management denial passes; IPv6 guest-to-management reaches the service.
Failover: forward traffic changes firewall, return traffic still crosses the old firewall without shared state.

1. Translation changes packet time into local time
2. Address translation proves the payload was encrypted before forwarding.
3. Every translated address represents a unique person
4. Pre- and post-translation addresses can differ, affecting attribution and rule matching.

**Correct option(s):** 4

- Option 1: NAT does not define timestamp semantics.
- Option 2: NAT changes addressing context, not necessarily payload confidentiality.
- Option 3: Several identities can share an address.
- Option 4: The same flow can appear differently across boundaries.

**GICSP-Q0080 · single · recovery**

What is the correct post-correction acceptance scope?

SYNTHETIC POLICY, first match wins; ordinary transport ACL only.
1 permit tcp 192.0.2.0/24 → 198.51.100.20/32 port 502
2 deny tcp 192.0.2.10/32 → 198.51.100.20/32 port 502
3 deny any
Requirement: historian .10 may read controller .20 but must not write. No application role check is configured.
Routing: 198.51.100.0/24 via unavailable next hop N1 remains installed; default via N2 is healthy.
IPv4 guest-to-management denial passes; IPv6 guest-to-management reaches the service.
Failover: forward traffic changes firewall, return traffic still crosses the old firewall without shared state.

1. Only the removal of rule 2
2. Only a successful ping
3. Required read service, forbidden writes/sources, enabled-family isolation and failover behaviour.
4. Only the intended rule text

**Correct option(s):** 3

- Option 1: Deleting a rule does not by itself restore the design.
- Option 2: ICMP does not test the operation boundary.
- Option 3: Related positive and negative requirements must all hold.
- Option 4: Effective state and outcomes remain untested.

#### Recall

**Why is a port allowance not read-only permission?**

Several application operations can share one port; supported operation-level enforcement is needed for a read/write boundary.

**Why can a backup default fail to restore one subnet?**

A stale installed more-specific route still wins longest-prefix selection for that destination.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [RFC 4861: IPv6 Neighbor Discovery](https://www.rfc-editor.org/rfc/rfc4861)

### GICSP-L009 — Remote support, management planes and recoverable identity

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L008

### Remote access is a chain of authority
A vendor connection can involve an identity provider, VPN gateway, jump host, engineering application and target device. Each layer answers a different question. VPN authentication establishes a peer/session according to the configured method; it does not authorise every destination or every controller operation. The jump host may limit the path while the target account still grants excessive rights. Trace the complete chain and record which identity is visible at each enforcement and logging point.

Begin with the work purpose, approved targets, operations, window and owner. Separate diagnostic observation from configuration, firmware update and process command. Use individual identities or a governed supported alternative where a legacy device cannot provide them, retaining attribution through the entry path. Multifactor authentication strengthens an authentication step; it does not repair a shared unrestricted downstream account or remove authority from an already active session.

### Sessions can outlive account changes
Removing a group, expiring a ticket or disabling an entry account may not immediately invalidate a VPN, remote desktop, application token or device session. The effect depends on the implementation. Define the required removal latency and test actual existing as well as new sessions. Record cache, token, certificate and session behaviour. A five-minute access requirement cannot be accepted solely because the directory displays an expiry time.

Protect remote administration from ordinary browsing and unnecessary software where the selected platform permits. Limit clipboard, file transfer, virtual media and drive redirection according to the task and supported controls. An engineering workstation may require project transfer, so a blanket prohibition can break the approved workflow. Provide a scanned, controlled, attributable transfer method and verify project identity. Keep credentials out of recorded screens and public evidence.

### Out-of-band is a design property
A console server, BMC or alternate path can support recovery when normal management fails. It is independent only for the failures its actual network, power, identity and access dependencies survive. A console server on the same failed switch is not a recovery path for that switch failure. A break-glass credential stored exclusively in the failed directory is not independently available. Establish protected custody, use logging where feasible, review use and return to normal controlled access after the event.

BMC authority deserves separate attention because it may include power control, remote console and virtual media below the host OS. Host firewall rules do not automatically govern a dedicated/shared management interface. Verify device-specific modes, supported protocols, certificates, permissions and logs. Redfish or another management API provides an interface, not a guarantee that a collection script is read-only; the service account and exposed actions must enforce that boundary.

### Verify the useful boundary
Use an isolated support exercise to prove an authorised task succeeds, an unrelated target and operation fail, expiry removes both new and existing access within the requirement, and observation remains available during a bounded containment. Preserve the source of each log and its time quality. During incident response, choose account/session/path restrictions with the operational owner rather than disconnecting every supporting service blindly. Restoration includes removal of temporary exceptions and verification that revoked authority cannot return through a backup or alternate interface.

#### Worked demonstrations

**Evidence walkthrough**

SYNTHETIC ACCESS TEST.
Vendor V may read PLC1 diagnostics 09:00–10:00; writes and PLC2 access are forbidden. VPN MFA succeeds at 09:10. Jump host uses shared target account maint_admin with write rights. At 10:00 V's directory role expires; new VPN login fails at 10:01, but an existing engineering session writes PLC1 at 10:04. Required removal latency: ≤2 minutes. OOB console depends on the same directory and switch as the normal path. BMC collection script has administrator credentials although its prompt says read-only.

**Reasoning:** The entry MFA test is positive but downstream operation scope fails. Existing-session write at 10:04 also exceeds the two-minute removal requirement despite new-login denial. The OOB path does not survive the specified shared dependencies; redesign and test protected independent access. The collection script's administrative capability contradicts enforced read-only authority. Correct the target role/session handling and service credentials, then retest legitimate diagnostics, write/PLC2 denial, existing-session expiry and recovery access.

#### Guided practice

Define a test for emergency access without publishing the emergency secret.

**Hint:** Verify custody, actual use and post-use restoration separately.

**Worked solution:** Use the approved protected retrieval process in an isolated exercise, record who authorised and used the identity without exposing the credential, perform the bounded recovery task, then rotate/reseal as required and verify normal/revoked access. Test with the ordinary directory unavailable.

#### Independent task

Environment: analytical

Build an access-chain diagram and test matrix for V, the jump host, PLC1/PLC2 and BMC collection.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L009.json

**Evidence to produce**

- Identity/session dependency map
- Allowed/denied/expiry test results
- OOB failure-scope record

**Acceptance criteria**

- MFA success is not equated with least privilege.
- Existing sessions are tested after expiry.
- Read-only collection is enforced by actual permissions.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0081 · single · diagnosis**

Which requirement fails when maint_admin can write PLC1?

SYNTHETIC ACCESS TEST.
Vendor V may read PLC1 diagnostics 09:00–10:00; writes and PLC2 access are forbidden. VPN MFA succeeds at 09:10. Jump host uses shared target account maint_admin with write rights. At 10:00 V's directory role expires; new VPN login fails at 10:01, but an existing engineering session writes PLC1 at 10:04. Required removal latency: ≤2 minutes. OOB console depends on the same directory and switch as the normal path. BMC collection script has administrator credentials although its prompt says read-only.

1. MFA necessarily failed.
2. PLC2 must be offline.
3. The downstream operation scope exceeds approved read-only diagnostics.
4. The ability to write proves the VPN tunnel is plaintext.

**Correct option(s):** 3

- Option 1: MFA can succeed while authorisation is excessive.
- Option 2: No such observation is supplied.
- Option 3: Entry authentication does not constrain target privileges automatically.
- Option 4: Encrypted transport can carry an operation that exceeds the authorised role.

**GICSP-Q0082 · single · mechanism**

What does new-login denial at 10:01 establish?

SYNTHETIC ACCESS TEST.
Vendor V may read PLC1 diagnostics 09:00–10:00; writes and PLC2 access are forbidden. VPN MFA succeeds at 09:10. Jump host uses shared target account maint_admin with write rights. At 10:00 V's directory role expires; new VPN login fails at 10:01, but an existing engineering session writes PLC1 at 10:04. Required removal latency: ≤2 minutes. OOB console depends on the same directory and switch as the normal path. BMC collection script has administrator credentials although its prompt says read-only.

1. The two-minute removal requirement fully passed.
2. The target account became read-only.
3. The tested new authentication attempt was denied.
4. Every existing device session ended.

**Correct option(s):** 3

- Option 1: Existing authority remained usable beyond it.
- Option 2: Target rights are a separate enforcement point.
- Option 3: It does not establish termination of existing sessions.
- Option 4: The 10:04 write contradicts that assumption.

**GICSP-Q0083 · single · calculation**

How late is the observed write relative to the 10:00 role expiry?

SYNTHETIC ACCESS TEST.
Vendor V may read PLC1 diagnostics 09:00–10:00; writes and PLC2 access are forbidden. VPN MFA succeeds at 09:10. Jump host uses shared target account maint_admin with write rights. At 10:00 V's directory role expires; new VPN login fails at 10:01, but an existing engineering session writes PLC1 at 10:04. Required removal latency: ≤2 minutes. OOB console depends on the same directory and switch as the normal path. BMC collection script has administrator credentials although its prompt says read-only.

1. Exactly two minutes.
2. Zero, because the session began earlier.
3. One minute.
4. Four minutes, exceeding the two-minute removal limit.

**Correct option(s):** 4

- Option 1: The write occurred at 10:04.
- Option 2: The requirement applies to effective authority after expiry.
- Option 3: That is the new-login test delay, not the write time.
- Option 4: The supplied timestamps show continuing authority outside the requirement.

**GICSP-Q0084 · single · implementation**

Which change best addresses the collection script's authority boundary?

SYNTHETIC ACCESS TEST.
Vendor V may read PLC1 diagnostics 09:00–10:00; writes and PLC2 access are forbidden. VPN MFA succeeds at 09:10. Jump host uses shared target account maint_admin with write rights. At 10:00 V's directory role expires; new VPN login fails at 10:01, but an existing engineering session writes PLC1 at 10:04. Required removal latency: ≤2 minutes. OOB console depends on the same directory and switch as the normal path. BMC collection script has administrator credentials although its prompt says read-only.

1. Rename the script read_only while keeping the BMC administrator credential.
2. Disable the script’s audit logging while retaining its administrator credential.
3. Keep administrator credentials but hide the reset button.
4. Use supported credentials and exposed operations that actually lack configuration-write permission.

**Correct option(s):** 4

- Option 1: The credential’s effective authority remains broader than the intended collection function.
- Option 2: That reduces accountability without narrowing the execution capability.
- Option 3: Other API paths may remain usable.
- Option 4: A prompt alone does not constrain the underlying API authority.

**GICSP-Q0085 · single · design**

Why is the claimed OOB route not independent for the stated fault?

SYNTHETIC ACCESS TEST.
Vendor V may read PLC1 diagnostics 09:00–10:00; writes and PLC2 access are forbidden. VPN MFA succeeds at 09:10. Jump host uses shared target account maint_admin with write rights. At 10:00 V's directory role expires; new VPN login fails at 10:01, but an existing engineering session writes PLC1 at 10:04. Required removal latency: ≤2 minutes. OOB console depends on the same directory and switch as the normal path. BMC collection script has administrator credentials although its prompt says read-only.

1. The console protocol is separate, so the shared switch and directory cannot affect it.
2. The route has a different IP address.
3. A second console URL provides an independent recovery path even on the same failed dependencies.
4. It shares the normal path's switch and directory dependencies.

**Correct option(s):** 4

- Option 1: Protocol difference does not remove the supplied common network and identity dependencies.
- Option 2: Different addressing does not establish failure independence.
- Option 3: Independence must be assessed against the stated fault, not the number of URLs.
- Option 4: Those failures can remove both routes.

**GICSP-Q0086 · multi · design**

Which remote-support capabilities should be explicitly scoped? Select all that apply.

SYNTHETIC ACCESS TEST.
Vendor V may read PLC1 diagnostics 09:00–10:00; writes and PLC2 access are forbidden. VPN MFA succeeds at 09:10. Jump host uses shared target account maint_admin with write rights. At 10:00 V's directory role expires; new VPN login fails at 10:01, but an existing engineering session writes PLC1 at 10:04. Required removal latency: ≤2 minutes. OOB console depends on the same directory and switch as the normal path. BMC collection script has administrator credentials although its prompt says read-only.

1. Target devices and application operations
2. Window, session expiry and responsible owner
3. File transfer and virtual media where available
4. Every reachable management endpoint by default

**Correct option(s):** 1, 2, 3

- Option 1: Reachability and command authority need separate limits.
- Option 2: Effective duration and accountability are part of the boundary.
- Option 3: They can change code/data and boot environment.
- Option 4: That exceeds a task-specific scope.

**GICSP-Q0087 · single · operations**

A supported legacy device has only a shared local account. What is the strongest bounded treatment?

SYNTHETIC ACCESS TEST.
Vendor V may read PLC1 diagnostics 09:00–10:00; writes and PLC2 access are forbidden. VPN MFA succeeds at 09:10. Jump host uses shared target account maint_admin with write rights. At 10:00 V's directory role expires; new VPN login fails at 10:01, but an existing engineering session writes PLC1 at 10:04. Required removal latency: ≤2 minutes. OOB console depends on the same directory and switch as the normal path. BMC collection script has administrator credentials although its prompt says read-only.

1. Publish the password so every responder can recover.
2. Claim full individual device attribution from the shared username.
3. Use controlled attributable entry, restricted operations/path, credential custody and explicit residual-risk review.
4. Assume a VPN log proves every command by itself.

**Correct option(s):** 3

- Option 1: Access must remain governed and protected.
- Option 2: That username alone cannot identify the person.
- Option 3: Compensating controls can reduce risk without pretending the device has individual accounts.
- Option 4: Command attribution requires correlated relevant evidence.

**GICSP-Q0088 · single · implementation**

Which test most directly examines whether expiry removes existing authority?

SYNTHETIC ACCESS TEST.
Vendor V may read PLC1 diagnostics 09:00–10:00; writes and PLC2 access are forbidden. VPN MFA succeeds at 09:10. Jump host uses shared target account maint_admin with write rights. At 10:00 V's directory role expires; new VPN login fails at 10:01, but an existing engineering session writes PLC1 at 10:04. Required removal latency: ≤2 minutes. OOB console depends on the same directory and switch as the normal path. BMC collection script has administrator credentials although its prompt says read-only.

1. Restart every controller.
2. Keep a permitted lab session open across expiry and test the formerly allowed action after the required deadline.
3. Attempt only a fresh login.
4. Check the account's display name.

**Correct option(s):** 2

- Option 1: That is a disproportionate unscoped action, not a targeted expiry test.
- Option 2: It observes effective session revocation behaviour.
- Option 3: That tests new authentication, not existing state.
- Option 4: Naming is unrelated to session authority.

**GICSP-Q0089 · single · operations**

What must remain true during a bounded vendor-access containment?

SYNTHETIC ACCESS TEST.
Vendor V may read PLC1 diagnostics 09:00–10:00; writes and PLC2 access are forbidden. VPN MFA succeeds at 09:10. Jump host uses shared target account maint_admin with write rights. At 10:00 V's directory role expires; new VPN login fails at 10:01, but an existing engineering session writes PLC1 at 10:04. Required removal latency: ≤2 minutes. OOB console depends on the same directory and switch as the normal path. BMC collection script has administrator credentials although its prompt says read-only.

1. Required operational observation and independent protections remain within their approved criteria.
2. Every supporting network service must be stopped.
3. All evidence must be erased before revocation.
4. The vendor must receive permanent emergency access.

**Correct option(s):** 1

- Option 1: Containment must consider physical/service consequences.
- Option 2: Broad shutdown can create avoidable loss of function.
- Option 3: Preserve relevant evidence through the authorised response.
- Option 4: Containment does not justify expanded lasting authority.

**GICSP-Q0090 · single · recovery**

Which recovery check detects authority resurrected by a snapshot?

SYNTHETIC ACCESS TEST.
Vendor V may read PLC1 diagnostics 09:00–10:00; writes and PLC2 access are forbidden. VPN MFA succeeds at 09:10. Jump host uses shared target account maint_admin with write rights. At 10:00 V's directory role expires; new VPN login fails at 10:01, but an existing engineering session writes PLC1 at 10:04. Required removal latency: ≤2 minutes. OOB console depends on the same directory and switch as the normal path. BMC collection script has administrator credentials although its prompt says read-only.

1. Count backup files.
2. Assume the newest snapshot is always trusted.
3. Retest revoked identities and sessions after applying the restored state and current revocation obligations.
4. Verify only that the login page loads.

**Correct option(s):** 3

- Option 1: File count does not establish effective roles.
- Option 2: Timing and provenance still require assessment.
- Option 3: Old state can contain rights that are no longer permitted.
- Option 4: Interface availability does not prove denied authority.

#### Recall

**Why test existing sessions after account expiry?**

Cached/token/session authority can outlive directory changes; observe effective removal within the required limit.

**What makes OOB access independent?**

Its actual path, power, identity and recovery dependencies survive the specific failure being claimed.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [NIST SP 800-193: firmware resiliency](https://csrc.nist.gov/pubs/sp/800/193/final)

### GICSP-L010 — Capacity, redundancy and time-quality budgets

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L009

### Capacity is state-dependent
Installed port rates and device counts are not service guarantees. Define offered traffic, packet sizes, application timing, shared links and the required normal, failure and maintenance states. A link carrying several sources may saturate during failover even if each normal path is lightly loaded. Compare demand and usable capacity at the actual boundary; protocol overhead, processing and traffic distribution can reduce useful delivery. A negative arithmetic margin disproves an unconstrained claim, while a positive margin still needs performance tests.

For serial or sequential polling, a simple lower bound is the sum of transaction service times. If 20 devices each occupy a shared channel for 80 ms, one successful pass needs 1.6 seconds before extra turnaround, retries or application delay. Asking the software to poll each device once per second cannot overcome that lower bound. Faulty or absent devices can consume timeout/retry slots and delay healthy devices; assess the scheduler's supported behaviour rather than assuming every endpoint is independent.

### Freshness accumulates through the pipeline
A measurement age budget can include source sampling phase, gateway wait, protocol transfer, collector processing, queueing and display delay. Avoid double-counting overlapping stages or omitting asynchronous phase effects. State whether each number is a bound, mean or observed percentile; adding means does not produce a guaranteed worst case. Track source observation time separately from receipt and rendering. A fast display refresh can repeatedly show the same old sample.

Redundancy must address a fault model. Two communication links may share power, cable route, firmware, identity or configuration automation. A gateway pair can share one downstream serial bus. A failover protocol can restore forwarding while the application waits for a session retry. Test required useful transactions, not only interface status. Repeat relevant tests during the declared maintenance state, when some protection is already unavailable.

### Time evidence has uncertainty
Clock resolution is the smallest represented increment; it is not synchronisation accuracy. A log displaying microseconds can still be seconds wrong. NTP, PTP and time-code interfaces have different architectures and implementation limits. Record the chosen source, configuration, offset evidence, holdover and failure behaviour. When combining events from two clocks with bounded independent unknown offsets, use conservative interval reasoning rather than ordering them solely by displayed time.

If event A is recorded at 10:00:05 with uncertainty ±2 seconds and event B at 10:00:06 with uncertainty ±2 seconds, their possible real-time intervals overlap. The display does not prove A preceded B. Additional sequence numbers, request/response relationships or a shared trusted capture point may establish order. Preserve original timestamps and any normalised values with their transformation method; do not silently rewrite evidence to fit a preferred story.

### Restore function and revise the model
A recovery timeline should include detection, route/session restoration, first valid observation, required alarm delivery and acceptance. If network convergence takes 300 ms but usable telemetry returns after eight seconds, investigate the remaining stages before aggressively reducing protocol timers. Controller load, retries, gateway caches, database backlog and identity can dominate. After correction, repeat a representative test and compare both normal service and failure behaviour. The result establishes a bounded measured capability, not universal losslessness or production authority.

#### Worked demonstrations

**Evidence walkthrough**

SYNTHETIC TIMING/CAPACITY CASE.
Twenty serial devices share one sequential channel; each successful transaction occupies 80 ms. Required per-device sample interval is 1 s. One missing device consumes a 500 ms timeout with one additional retry.
Freshness budget 5 s: source phase 1.0 s, gateway wait 2.0 s, processing/render 0.8 s, uncertainty allowance 0.4 s.
Two uplinks each carry 65 Mb/s; one surviving uplink has demonstrated usable capacity 100 Mb/s. Both switches share cabinet power.
Fault test: link recovery 0.3 s; first valid application sample 8 s. Event A: 10:00:05 ±2 s; event B: 10:00:06 ±2 s.

**Reasoning:** The normal polling lower bound is 20×0.08=1.6 s, already slower than the one-second target. With one absent device replacing one normal transaction and two 0.5 s waits, the pass is at least 19×0.08+1.0=2.52 s before other overhead. The remaining freshness allocation for network/queues is 5−1−2−0.8−0.4=0.8 s under the stated additive bound model. Failover demand is 130 Mb/s against 100 Mb/s measured capacity, and shared power is a separate common cause. Link recovery does not explain the full eight-second application gap. A and B intervals overlap, so displayed timestamps alone do not establish order.

#### Guided practice

Design a bounded test that distinguishes serial queue delay from IP path failure.

**Hint:** Observe the stages using one known source and a controlled missing-device condition.

**Worked solution:** Record request scheduling, serial response/timeout, gateway source timestamp, IP delivery and application arrival. Compare normal and authorised absent-device simulation while keeping offered work fixed. A healthy IP path with delayed source updates supports the serial scheduler hypothesis; preserve uncertainty and do not attribute every delay to the network.

#### Independent task

Environment: analytical

Calculate the budgets and build a small offline schedule/time-interval model.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L010.json

**Evidence to produce**

- Unit-checked timing worksheet
- Normal/failure/maintenance state table
- Event-order uncertainty report

**Acceptance criteria**

- The one-second polling claim is rejected from the lower bound.
- Timeout replacement is not double-counted with a successful transaction.
- Overlapping time intervals remain unordered without additional evidence.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0091 · single · calculation**

What is the successful-pass lower bound for twenty 80 ms transactions?

SYNTHETIC TIMING/CAPACITY CASE.
Twenty serial devices share one sequential channel; each successful transaction occupies 80 ms. Required per-device sample interval is 1 s. One missing device consumes a 500 ms timeout with one additional retry.
Freshness budget 5 s: source phase 1.0 s, gateway wait 2.0 s, processing/render 0.8 s, uncertainty allowance 0.4 s.
Two uplinks each carry 65 Mb/s; one surviving uplink has demonstrated usable capacity 100 Mb/s. Both switches share cabinet power.
Fault test: link recovery 0.3 s; first valid application sample 8 s. Event A: 10:00:05 ±2 s; event B: 10:00:06 ±2 s.

1. 1.6 seconds
2. 0.16 seconds
3. 1 second because the configured poll rate says so
4. 16 seconds

**Correct option(s):** 1

- Option 1: Twenty times 0.08 seconds equals 1.6 seconds.
- Option 2: This loses a factor of ten.
- Option 3: A setting cannot override channel service time.
- Option 4: This adds an extra factor of ten.

**GICSP-Q0092 · single · calculation**

If one transaction is replaced by two 500 ms timeout waits, what is the stated pass lower bound?

SYNTHETIC TIMING/CAPACITY CASE.
Twenty serial devices share one sequential channel; each successful transaction occupies 80 ms. Required per-device sample interval is 1 s. One missing device consumes a 500 ms timeout with one additional retry.
Freshness budget 5 s: source phase 1.0 s, gateway wait 2.0 s, processing/render 0.8 s, uncertainty allowance 0.4 s.
Two uplinks each carry 65 Mb/s; one surviving uplink has demonstrated usable capacity 100 Mb/s. Both switches share cabinet power.
Fault test: link recovery 0.3 s; first valid application sample 8 s. Event A: 10:00:05 ±2 s; event B: 10:00:06 ±2 s.

1. 1.6 seconds
2. 2.6 seconds
3. 0.5 seconds
4. 2.52 seconds

**Correct option(s):** 4

- Option 1: It ignores the timeout path.
- Option 2: That incorrectly retains all twenty successful transactions as well as the missing-device waits.
- Option 3: It counts only one wait and omits the other work.
- Option 4: Nineteen successful transactions take 1.52 s; the two waits add 1 s.

**GICSP-Q0093 · single · calculation**

How much of the stated freshness budget remains for network and queue delay?

SYNTHETIC TIMING/CAPACITY CASE.
Twenty serial devices share one sequential channel; each successful transaction occupies 80 ms. Required per-device sample interval is 1 s. One missing device consumes a 500 ms timeout with one additional retry.
Freshness budget 5 s: source phase 1.0 s, gateway wait 2.0 s, processing/render 0.8 s, uncertainty allowance 0.4 s.
Two uplinks each carry 65 Mb/s; one surviving uplink has demonstrated usable capacity 100 Mb/s. Both switches share cabinet power.
Fault test: link recovery 0.3 s; first valid application sample 8 s. Event A: 10:00:05 ±2 s; event B: 10:00:06 ±2 s.

1. 0.8 seconds
2. 2 seconds
3. Negative 0.8 seconds
4. 5 seconds

**Correct option(s):** 1

- Option 1: Five minus 1.0, 2.0, 0.8 and 0.4 is 0.8.
- Option 2: That omits required pipeline contributions.
- Option 3: The supplied allocations total 4.2, not 5.8.
- Option 4: The entire budget cannot be assigned again to one stage.

**GICSP-Q0094 · single · design**

What does the failover traffic arithmetic show?

SYNTHETIC TIMING/CAPACITY CASE.
Twenty serial devices share one sequential channel; each successful transaction occupies 80 ms. Required per-device sample interval is 1 s. One missing device consumes a 500 ms timeout with one additional retry.
Freshness budget 5 s: source phase 1.0 s, gateway wait 2.0 s, processing/render 0.8 s, uncertainty allowance 0.4 s.
Two uplinks each carry 65 Mb/s; one surviving uplink has demonstrated usable capacity 100 Mb/s. Both switches share cabinet power.
Fault test: link recovery 0.3 s; first valid application sample 8 s. Event A: 10:00:05 ±2 s; event B: 10:00:06 ±2 s.

1. 130 Mb/s demand exceeds the surviving path's measured 100 Mb/s capacity.
2. The two-link nominal capacity remains available after one uplink fails.
3. Routing convergence creates the missing 30 Mb/s.
4. The 30 Mb/s excess means every application loses exactly 30% of its packets.

**Correct option(s):** 1

- Option 1: Load management or a different supported design is needed.
- Option 2: The survivor has only 100 Mb/s usable capacity against 130 Mb/s offered load.
- Option 3: Route selection does not create bandwidth.
- Option 4: Aggregate capacity arithmetic does not determine per-application loss distribution or packet percentages.

**GICSP-Q0095 · single · design**

Which supplied physical common cause is not mitigated merely by the two switches?

SYNTHETIC TIMING/CAPACITY CASE.
Twenty serial devices share one sequential channel; each successful transaction occupies 80 ms. Required per-device sample interval is 1 s. One missing device consumes a 500 ms timeout with one additional retry.
Freshness budget 5 s: source phase 1.0 s, gateway wait 2.0 s, processing/render 0.8 s, uncertainty allowance 0.4 s.
Two uplinks each carry 65 Mb/s; one surviving uplink has demonstrated usable capacity 100 Mb/s. Both switches share cabinet power.
Fault test: link recovery 0.3 s; first valid application sample 8 s. Event A: 10:00:05 ±2 s; event B: 10:00:06 ±2 s.

1. A wrong hostname in one collector’s local configuration.
2. A single cable defect on one otherwise independent path.
3. Their shared cabinet-power loss.
4. A software defect confined to one switch’s independent control process.

**Correct option(s):** 3

- Option 1: That is an application configuration issue, not the supplied common power dependency.
- Option 2: That may be within the redundancy design, subject to testing.
- Option 3: The common supply can defeat both paths.
- Option 4: The stated shared cabinet power is the supplied physical common cause; this option describes a different failure scope.

**GICSP-Q0096 · single · diagnosis**

Does A's earlier displayed timestamp prove it occurred before B?

SYNTHETIC TIMING/CAPACITY CASE.
Twenty serial devices share one sequential channel; each successful transaction occupies 80 ms. Required per-device sample interval is 1 s. One missing device consumes a 500 ms timeout with one additional retry.
Freshness budget 5 s: source phase 1.0 s, gateway wait 2.0 s, processing/render 0.8 s, uncertainty allowance 0.4 s.
Two uplinks each carry 65 Mb/s; one surviving uplink has demonstrated usable capacity 100 Mb/s. Both switches share cabinet power.
Fault test: link recovery 0.3 s; first valid application sample 8 s. Event A: 10:00:05 ±2 s; event B: 10:00:06 ±2 s.

1. No event ordering is ever possible.
2. Yes, because both show seconds.
3. Yes, because five is less than six.
4. No; their bounded possible times overlap.

**Correct option(s):** 4

- Option 1: Additional causal/sequence evidence can establish order.
- Option 2: Resolution does not establish clock accuracy.
- Option 3: Displayed order ignores uncertainty.
- Option 4: A spans 03–07 and B spans 04–08 seconds.

**GICSP-Q0097 · single · implementation**

Which observation can strengthen causal ordering despite uncertain clocks?

SYNTHETIC TIMING/CAPACITY CASE.
Twenty serial devices share one sequential channel; each successful transaction occupies 80 ms. Required per-device sample interval is 1 s. One missing device consumes a 500 ms timeout with one additional retry.
Freshness budget 5 s: source phase 1.0 s, gateway wait 2.0 s, processing/render 0.8 s, uncertainty allowance 0.4 s.
Two uplinks each carry 65 Mb/s; one surviving uplink has demonstrated usable capacity 100 Mb/s. Both switches share cabinet power.
Fault test: link recovery 0.3 s; first valid application sample 8 s. Event A: 10:00:05 ±2 s; event B: 10:00:06 ±2 s.

1. Deleting the uncertainty field.
2. Changing both displayed times to the preferred story.
3. Increasing the number of decimal places.
4. A verified request/response sequence or shared capture relationship.

**Correct option(s):** 4

- Option 1: Omission hides the limitation.
- Option 2: Rewriting evidence does not create truth.
- Option 3: Resolution does not correct offset.
- Option 4: Protocol/sequence evidence can add an ordering constraint.

**GICSP-Q0098 · single · diagnosis**

What should be investigated after 0.3 s link recovery but an 8 s valid-sample gap?

SYNTHETIC TIMING/CAPACITY CASE.
Twenty serial devices share one sequential channel; each successful transaction occupies 80 ms. Required per-device sample interval is 1 s. One missing device consumes a 500 ms timeout with one additional retry.
Freshness budget 5 s: source phase 1.0 s, gateway wait 2.0 s, processing/render 0.8 s, uncertainty allowance 0.4 s.
Two uplinks each carry 65 Mb/s; one surviving uplink has demonstrated usable capacity 100 Mb/s. Both switches share cabinet power.
Fault test: link recovery 0.3 s; first valid application sample 8 s. Event A: 10:00:05 ±2 s; event B: 10:00:06 ±2 s.

1. Session retries, polling, caches, queues and application/identity dependencies.
2. Only lowering the link timer below 0.3 s.
3. Replacing every optic without physical evidence.
4. Declaring the 8 s result irrelevant.

**Correct option(s):** 1

- Option 1: These stages can dominate useful-service recovery.
- Option 2: That may not address the remaining delay.
- Option 3: The supplied link recovery does not identify an optic fault.
- Option 4: Application freshness is the required outcome.

**GICSP-Q0099 · multi · design**

Which claims require separate evidence? Select all that apply.

SYNTHETIC TIMING/CAPACITY CASE.
Twenty serial devices share one sequential channel; each successful transaction occupies 80 ms. Required per-device sample interval is 1 s. One missing device consumes a 500 ms timeout with one additional retry.
Freshness budget 5 s: source phase 1.0 s, gateway wait 2.0 s, processing/render 0.8 s, uncertainty allowance 0.4 s.
Two uplinks each carry 65 Mb/s; one surviving uplink has demonstrated usable capacity 100 Mb/s. Both switches share cabinet power.
Fault test: link recovery 0.3 s; first valid application sample 8 s. Event A: 10:00:05 ±2 s; event B: 10:00:06 ±2 s.

1. Application recovery after the stated fault
2. Power/failure-domain independence
3. Zero-loss behaviour for every possible failure
4. Normal-state capacity

**Correct option(s):** 1, 2, 4

- Option 1: Link state alone does not establish it.
- Option 2: Device count alone does not prove it.
- Option 3: No finite supplied test establishes this universal claim.
- Option 4: It differs from reduced-path capacity.

**GICSP-Q0100 · single · mechanism**

What should a model do with mean delays when the requirement is a worst-case bound?

SYNTHETIC TIMING/CAPACITY CASE.
Twenty serial devices share one sequential channel; each successful transaction occupies 80 ms. Required per-device sample interval is 1 s. One missing device consumes a 500 ms timeout with one additional retry.
Freshness budget 5 s: source phase 1.0 s, gateway wait 2.0 s, processing/render 0.8 s, uncertainty allowance 0.4 s.
Two uplinks each carry 65 Mb/s; one surviving uplink has demonstrated usable capacity 100 Mb/s. Both switches share cabinet power.
Fault test: link recovery 0.3 s; first valid application sample 8 s. Event A: 10:00:05 ±2 s; event B: 10:00:06 ±2 s.

1. Treat the mean-delay sum as a worst-case bound because all measured components are positive.
2. Label the means and obtain justified bounds or an appropriate probabilistic acceptance model.
3. Ignore source sampling because IP is fast.
4. Remove uncertainty terms to make the mean estimate equal the requirement.

**Correct option(s):** 2

- Option 1: Positive averages still do not bound scheduling tails or unmeasured delays.
- Option 2: Summed averages are not a guaranteed maximum.
- Option 3: Source timing is part of end-to-end age.
- Option 4: Changing the model to fit the target does not establish a valid bound.

#### Recall

**Why is link convergence not service recovery?**

Sessions, polling, identity, queues and application validation can recover later than forwarding.

**How should overlapping timestamp intervals be treated?**

Order remains unresolved from clocks alone; preserve uncertainty and seek causal or sequence evidence.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [RFC 5905: NTPv4](https://www.rfc-editor.org/rfc/rfc5905)

## GICSP-M03 — Windows and Unix endpoint protection

### GICSP-L011 — Windows services, permissions and audit evidence

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L010

### Separate the operating system from the industrial function
A Windows supervisory host combines service processes, interactive users, device drivers, local/domain identities and application permissions. Hardening begins with the supported product baseline and required function. Record the Windows edition/build, application and driver versions, services, approved ports, account rights and recovery method. A generic desktop security baseline can be a useful input, but each relevant setting needs compatibility and operational validation on the selected industrial platform.

A service runs under a configured identity. LocalSystem has extensive local authority; a dedicated supported service account may reduce consequence when its rights are narrowly scoped. Domain membership can provide central management but also introduces directory, DNS, time and privileged-administration dependencies. Do not change a service identity casually: file, registry, database, certificate/private-key and network access may depend on it. Test required function and denied administration after a reviewed change.

### File permissions can undermine a service boundary
Inspect the effective permissions of the executable, parent directories, configuration files and update mechanism. If ordinary users can replace code executed by a privileged service, the service identity's privilege can become reachable through that writable path. A configuration file may also redirect loading or change operational endpoints, so protecting only the main executable is incomplete. NTFS ACL inheritance and explicit entries both matter; inspect effective access for the relevant user, not merely the owner name.

A service executable path containing spaces should use the supported unambiguous quoting and configuration. An unquoted path can create ambiguity in executable resolution depending on the actual command and filesystem state. Treat this as a configuration weakness to review, not proof that exploitation occurred. Correct the supported path and permissions, preserve the initial evidence and test service start plus required operational behaviour. Do not introduce a test binary into a production path to demonstrate the concern.

For an authorised Windows Server 2022/PowerShell 5.1 lab, read-only inspection can include `Get-CimInstance Win32_Service`, `sc.exe qc HistorianSvc` and `icacls` on the exact approved path. These commands inspect different aspects; their output must be tied to the host and time. The course supplies synthetic excerpts and does not claim that they were executed on a real host.

### Audit events need fields and context
Windows event identifiers are useful entry points, not complete incident conclusions. A successful-logon event, failed-logon event and process-creation event describe different observations. Logon type differentiates service, network and remote-interactive contexts. Correlate account, host, logon identifier, process, source and time where available. A network logon does not by itself prove an interactive desktop session. A process event may omit command-line detail unless the relevant policy is enabled; absence of that field is not proof that no arguments existed.

Audit configuration, collection health, retention and clock quality determine what evidence is available. Preserve original event data and note missing fields. New service installation or changed permissions can arise from authorised updates as well as malicious activity; compare change records and signed/provenance evidence. Do not infer intent from an executable name alone.

### Acceptance remains operational
Constrain host firewall rules to required services and sources, then test both approved clients and rejected paths. Stage supported updates and endpoint controls, verify driver/application compatibility, and retain a recovery route independent of the failed host. A hardened host that cannot deliver required alarms fails operational acceptance; a working historian with broad writable service paths fails the security boundary. Review both dimensions before release.

#### Worked demonstrations

**Evidence walkthrough**

SYNTHETIC WINDOWS SERVER 2022 / POWERSHELL 5.1 EXCERPTS; not executed output.
sc qc HistorianSvc: SERVICE_START_NAME=LocalSystem; BINARY_PATH_NAME=C:\Program Files\Plant Tools\hist.exe --service
icacls summary: directory C:\Program Files\Plant Tools grants BUILTIN\Users:(M); configuration hist.ini inherits that permission.
Firewall: inbound historian TCP 7443 allowed from Any.
Security events: 08:00 event 4624, account svc_hist, LogonType=5; 08:15 event 4625, account vendor1, LogonType=10, source 192.0.2.50; 08:16 event 4624, account vendor1, LogonType=3, source 192.0.2.50; 08:17 event 4688, process maintenance.exe, command line absent.
Approved vendor window starts 09:00. Required clients are only 192.0.2.10 and .11.

**Reasoning:** The service executable/configuration directory is writable by ordinary Users while the service uses a highly privileged identity; review and correct the supported ACL and path configuration. The unquoted spaced path is a separate ambiguity, not proof of execution abuse. Firewall Any exceeds the specified client set. The 08:15 event is failed remote-interactive authentication; 08:16 is a successful network logon, not proof of a successful RDP desktop. The 08:17 process record lacks arguments, so command purpose remains unresolved. Correlate identifiers, change records and additional logs; the out-of-window activity warrants investigation without inventing attribution.

#### Guided practice

Plan a supported service-account/permission change and the tests required after it.

**Hint:** List every resource the service actually needs.

**Worked solution:** Inventory executable/configuration, database, certificate/private-key and network dependencies; choose the vendor-supported least-privilege identity and ACLs; stage the change; verify startup, alarm/data transactions and legitimate updates; test ordinary-user modification denial and recovery. Keep rollback and secrets governed.

#### Independent task

Environment: analytical

Review the synthetic host baseline and audit sequence; optionally reproduce read-only inspection on an authorised disposable Windows lab.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L011.json

**Evidence to produce**

- Permission/identity findings
- Event timeline with unresolved fields
- Supported correction and acceptance matrix

**Acceptance criteria**

- No network logon is labelled successful RDP solely from type 3.
- Unquoted-path exposure is not claimed as observed exploitation.
- Required clients and ordinary-user write denials are tested separately.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0101 · single · diagnosis**

What is the strongest service-path finding?

SYNTHETIC WINDOWS SERVER 2022 / POWERSHELL 5.1 EXCERPTS; not executed output.
sc qc HistorianSvc: SERVICE_START_NAME=LocalSystem; BINARY_PATH_NAME=C:\Program Files\Plant Tools\hist.exe --service
icacls summary: directory C:\Program Files\Plant Tools grants BUILTIN\Users:(M); configuration hist.ini inherits that permission.
Firewall: inbound historian TCP 7443 allowed from Any.
Security events: 08:00 event 4624, account svc_hist, LogonType=5; 08:15 event 4625, account vendor1, LogonType=10, source 192.0.2.50; 08:16 event 4624, account vendor1, LogonType=3, source 192.0.2.50; 08:17 event 4688, process maintenance.exe, command line absent.
Approved vendor window starts 09:00. Required clients are only 192.0.2.10 and .11.

1. LocalSystem ownership protects hist.ini even though Users inherits Modify.
2. Ordinary Users can modify code/configuration used by a LocalSystem service.
3. The missing path quotes alone prove an attacker has already executed a replacement binary.
4. The main issue is that TCP 7443 uses a nonstandard number; directory permissions are secondary to renumbering it.

**Correct option(s):** 2

- Option 1: The inherited permission grants modification rights despite the service identity.
- Option 2: Writable privileged execution inputs create an authority weakness.
- Option 3: The record identifies a weakness, not an observed exploitation event.
- Option 4: The writable service/configuration path is a direct privilege concern; changing a port does not repair it.

**GICSP-Q0102 · single · mechanism**

What does the unquoted spaced binary path establish?

SYNTHETIC WINDOWS SERVER 2022 / POWERSHELL 5.1 EXCERPTS; not executed output.
sc qc HistorianSvc: SERVICE_START_NAME=LocalSystem; BINARY_PATH_NAME=C:\Program Files\Plant Tools\hist.exe --service
icacls summary: directory C:\Program Files\Plant Tools grants BUILTIN\Users:(M); configuration hist.ini inherits that permission.
Firewall: inbound historian TCP 7443 allowed from Any.
Security events: 08:00 event 4624, account svc_hist, LogonType=5; 08:15 event 4625, account vendor1, LogonType=10, source 192.0.2.50; 08:16 event 4624, account vendor1, LogonType=3, source 192.0.2.50; 08:17 event 4688, process maintenance.exe, command line absent.
Approved vendor window starts 09:00. Required clients are only 192.0.2.10 and .11.

1. The unquoted path proves hist.exe itself is writable by ordinary users.
2. A configuration ambiguity requiring supported correction and context review.
3. Quoting the binary path also removes inherited Users Modify from hist.ini.
4. A confirmed attacker process launch.

**Correct option(s):** 2

- Option 1: Path ambiguity and file ACLs are separate; the directory permissions provide the stated modification evidence.
- Option 2: It is a potential weakness, not proof of exploitation.
- Option 3: Quoting resolves command-line ambiguity, not filesystem permissions.
- Option 4: No such execution evidence is supplied.

**GICSP-Q0103 · single · diagnosis**

How should event 4624 with LogonType 5 be interpreted here?

SYNTHETIC WINDOWS SERVER 2022 / POWERSHELL 5.1 EXCERPTS; not executed output.
sc qc HistorianSvc: SERVICE_START_NAME=LocalSystem; BINARY_PATH_NAME=C:\Program Files\Plant Tools\hist.exe --service
icacls summary: directory C:\Program Files\Plant Tools grants BUILTIN\Users:(M); configuration hist.ini inherits that permission.
Firewall: inbound historian TCP 7443 allowed from Any.
Security events: 08:00 event 4624, account svc_hist, LogonType=5; 08:15 event 4625, account vendor1, LogonType=10, source 192.0.2.50; 08:16 event 4624, account vendor1, LogonType=3, source 192.0.2.50; 08:17 event 4688, process maintenance.exe, command line absent.
Approved vendor window starts 09:00. Required clients are only 192.0.2.10 and .11.

1. A guaranteed interactive user desktop.
2. The recorded successful logon is a service logon context.
3. A file-integrity hash match.
4. A failed remote desktop attempt.

**Correct option(s):** 2

- Option 1: Service logon is not interactive desktop evidence.
- Option 2: Type 5 identifies service startup context in the stated event model.
- Option 3: Logon events do not establish file integrity.
- Option 4: The supplied failure uses event 4625 and type 10.

**GICSP-Q0104 · single · diagnosis**

What does the 08:16 type-3 success prove most narrowly?

SYNTHETIC WINDOWS SERVER 2022 / POWERSHELL 5.1 EXCERPTS; not executed output.
sc qc HistorianSvc: SERVICE_START_NAME=LocalSystem; BINARY_PATH_NAME=C:\Program Files\Plant Tools\hist.exe --service
icacls summary: directory C:\Program Files\Plant Tools grants BUILTIN\Users:(M); configuration hist.ini inherits that permission.
Firewall: inbound historian TCP 7443 allowed from Any.
Security events: 08:00 event 4624, account svc_hist, LogonType=5; 08:15 event 4625, account vendor1, LogonType=10, source 192.0.2.50; 08:16 event 4624, account vendor1, LogonType=3, source 192.0.2.50; 08:17 event 4688, process maintenance.exe, command line absent.
Approved vendor window starts 09:00. Required clients are only 192.0.2.10 and .11.

1. The vendor action was authorised.
2. The earlier failure was fabricated.
3. A successful type-10 remote-interactive session.
4. A successful network logon for the recorded identity/context.

**Correct option(s):** 4

- Option 1: Authentication success does not establish the work-window permission.
- Option 2: A failure and later different successful attempt can coexist.
- Option 3: That is a different logon type.
- Option 4: It does not by itself establish an RDP desktop.

**GICSP-Q0105 · single · diagnosis**

What can be inferred from the missing 4688 command-line field?

SYNTHETIC WINDOWS SERVER 2022 / POWERSHELL 5.1 EXCERPTS; not executed output.
sc qc HistorianSvc: SERVICE_START_NAME=LocalSystem; BINARY_PATH_NAME=C:\Program Files\Plant Tools\hist.exe --service
icacls summary: directory C:\Program Files\Plant Tools grants BUILTIN\Users:(M); configuration hist.ini inherits that permission.
Firewall: inbound historian TCP 7443 allowed from Any.
Security events: 08:00 event 4624, account svc_hist, LogonType=5; 08:15 event 4625, account vendor1, LogonType=10, source 192.0.2.50; 08:16 event 4624, account vendor1, LogonType=3, source 192.0.2.50; 08:17 event 4688, process maintenance.exe, command line absent.
Approved vendor window starts 09:00. Required clients are only 192.0.2.10 and .11.

1. The supplied record does not reveal the arguments; audit configuration and other evidence must be checked.
2. The binary is necessarily signed by the OEM.
3. The process used no arguments.
4. The process did not execute.

**Correct option(s):** 1

- Option 1: Missing data is not proof of no arguments.
- Option 2: No signature/provenance evidence is included.
- Option 3: Logging may omit them.
- Option 4: The event records creation despite missing arguments.

**GICSP-Q0106 · single · implementation**

Which firewall correction matches the stated client requirement?

SYNTHETIC WINDOWS SERVER 2022 / POWERSHELL 5.1 EXCERPTS; not executed output.
sc qc HistorianSvc: SERVICE_START_NAME=LocalSystem; BINARY_PATH_NAME=C:\Program Files\Plant Tools\hist.exe --service
icacls summary: directory C:\Program Files\Plant Tools grants BUILTIN\Users:(M); configuration hist.ini inherits that permission.
Firewall: inbound historian TCP 7443 allowed from Any.
Security events: 08:00 event 4624, account svc_hist, LogonType=5; 08:15 event 4625, account vendor1, LogonType=10, source 192.0.2.50; 08:16 event 4624, account vendor1, LogonType=3, source 192.0.2.50; 08:17 event 4688, process maintenance.exe, command line absent.
Approved vendor window starts 09:00. Required clients are only 192.0.2.10 and .11.

1. Deny all traffic without testing alarms.
2. Allow every port from Any.
3. Change 7443 to a random number and assume protection.
4. Restrict the supported 7443 service to the approved clients and test their transactions plus denied sources.

**Correct option(s):** 4

- Option 1: Required clients must remain functional.
- Option 2: That expands exposure without a requirement.
- Option 3: Port renaming does not establish authentication or least privilege.
- Option 4: Scope should follow required service identities/paths.

**GICSP-Q0107 · multi · design**

Which dependencies must be checked before changing the service identity? Select all that apply.

SYNTHETIC WINDOWS SERVER 2022 / POWERSHELL 5.1 EXCERPTS; not executed output.
sc qc HistorianSvc: SERVICE_START_NAME=LocalSystem; BINARY_PATH_NAME=C:\Program Files\Plant Tools\hist.exe --service
icacls summary: directory C:\Program Files\Plant Tools grants BUILTIN\Users:(M); configuration hist.ini inherits that permission.
Firewall: inbound historian TCP 7443 allowed from Any.
Security events: 08:00 event 4624, account svc_hist, LogonType=5; 08:15 event 4625, account vendor1, LogonType=10, source 192.0.2.50; 08:16 event 4624, account vendor1, LogonType=3, source 192.0.2.50; 08:17 event 4688, process maintenance.exe, command line absent.
Approved vendor window starts 09:00. Required clients are only 192.0.2.10 and .11.

1. Database and required network permissions
2. Only the account display name
3. Supported vendor service-account requirements
4. Certificate/private-key and configuration access

**Correct option(s):** 1, 3, 4

- Option 1: The service may need remote resources.
- Option 2: Naming is insufficient to establish rights.
- Option 3: The selected platform's operation must remain supported.
- Option 4: Identity changes can break these resources.

**GICSP-Q0108 · single · operations**

Why is the 08:15–08:17 activity worth investigating even if a credential is valid?

SYNTHETIC WINDOWS SERVER 2022 / POWERSHELL 5.1 EXCERPTS; not executed output.
sc qc HistorianSvc: SERVICE_START_NAME=LocalSystem; BINARY_PATH_NAME=C:\Program Files\Plant Tools\hist.exe --service
icacls summary: directory C:\Program Files\Plant Tools grants BUILTIN\Users:(M); configuration hist.ini inherits that permission.
Firewall: inbound historian TCP 7443 allowed from Any.
Security events: 08:00 event 4624, account svc_hist, LogonType=5; 08:15 event 4625, account vendor1, LogonType=10, source 192.0.2.50; 08:16 event 4624, account vendor1, LogonType=3, source 192.0.2.50; 08:17 event 4688, process maintenance.exe, command line absent.
Approved vendor window starts 09:00. Required clients are only 192.0.2.10 and .11.

1. It precedes the approved vendor window and must be correlated with authorised work and actual actions.
2. The failed remote-interactive login alone proves that vendor1 executed maintenance.exe.
3. The process name maintenance.exe establishes that its 08:17 execution was approved.
4. No investigation is needed after any success event.

**Correct option(s):** 1

- Option 1: Valid authentication does not authorise timing or operations.
- Option 2: The events require session/process correlation; the supplied command line is absent.
- Option 3: The work window begins at 09:00, and a descriptive filename is not approval evidence.
- Option 4: Success can be relevant to an incident.

**GICSP-Q0109 · single · implementation**

What would show that corrected ACLs are effective?

SYNTHETIC WINDOWS SERVER 2022 / POWERSHELL 5.1 EXCERPTS; not executed output.
sc qc HistorianSvc: SERVICE_START_NAME=LocalSystem; BINARY_PATH_NAME=C:\Program Files\Plant Tools\hist.exe --service
icacls summary: directory C:\Program Files\Plant Tools grants BUILTIN\Users:(M); configuration hist.ini inherits that permission.
Firewall: inbound historian TCP 7443 allowed from Any.
Security events: 08:00 event 4624, account svc_hist, LogonType=5; 08:15 event 4625, account vendor1, LogonType=10, source 192.0.2.50; 08:16 event 4624, account vendor1, LogonType=3, source 192.0.2.50; 08:17 event 4688, process maintenance.exe, command line absent.
Approved vendor window starts 09:00. Required clients are only 192.0.2.10 and .11.

1. A bounded test that ordinary users cannot modify protected inputs while the supported service/update workflow works.
2. A screenshot of a desired baseline document.
3. Only changing the directory owner name.
4. Removing the directory from inventory.

**Correct option(s):** 1

- Option 1: Both denial and required function need evidence.
- Option 2: Intent does not establish applied state.
- Option 3: Effective inherited/explicit permissions can still grant modification.
- Option 4: Concealing it does not alter access.

**GICSP-Q0110 · single · operations**

Which report avoids overstating the synthetic audit evidence?

SYNTHETIC WINDOWS SERVER 2022 / POWERSHELL 5.1 EXCERPTS; not executed output.
sc qc HistorianSvc: SERVICE_START_NAME=LocalSystem; BINARY_PATH_NAME=C:\Program Files\Plant Tools\hist.exe --service
icacls summary: directory C:\Program Files\Plant Tools grants BUILTIN\Users:(M); configuration hist.ini inherits that permission.
Firewall: inbound historian TCP 7443 allowed from Any.
Security events: 08:00 event 4624, account svc_hist, LogonType=5; 08:15 event 4625, account vendor1, LogonType=10, source 192.0.2.50; 08:16 event 4624, account vendor1, LogonType=3, source 192.0.2.50; 08:17 event 4688, process maintenance.exe, command line absent.
Approved vendor window starts 09:00. Required clients are only 192.0.2.10 and .11.

1. Out-of-window network authentication and process creation are recorded; exact action linkage and intent remain under investigation.
2. The vendor definitely altered PLC logic.
3. The historian was fully restored by reading the logs.
4. No security event occurred because RDP failed.

**Correct option(s):** 1

- Option 1: Correlation and missing arguments limit the conclusion.
- Option 2: No controller/project evidence establishes that.
- Option 3: Analysis alone does not perform restoration.
- Option 4: Other successful activity remains relevant.

#### Recall

**Why inspect service parent-directory ACLs?**

A protected executable can still be replaced or redirected through writable surrounding paths/configuration.

**Does a Windows type-3 logon prove RDP?**

No. It denotes network logon context; remote-interactive type 10 is different, and full activity needs correlation.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [Microsoft Windows security auditing](https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/security-auditing-overview)

### GICSP-L012 — Unix permissions, service isolation and accountable administration

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L011

### Permissions apply to objects and paths
Unix-style permission bits distinguish owner, group and others, with read, write and execute meanings that differ for files and directories. For a regular file, execute permits execution subject to other controls; for a directory, execute supports traversal and write permits changing entries under the relevant rules. A read-only file inside a writable directory can still be vulnerable to replacement depending on directory permissions and ownership. Inspect the full path, ACLs, mounts and service behaviour rather than checking one numeric mode in isolation.

A mode such as 0640 gives the owner read/write, the group read and others no access. A mode 0666 gives everyone read/write; it does not add executable permission, but a writable configuration can still influence a privileged service. A directory mode 0777 permits broad entry changes; the sticky bit changes deletion/rename rules in shared directories but is not a general integrity policy. Do not repair every problem by assigning 0777. Determine the exact service/user needs and use the narrow supported ownership, groups and permissions.

### Services should have bounded authority
A Linux service may run as root or a dedicated user, and service-manager settings can impose additional restrictions. A systemd unit's effective behaviour depends on its main unit file, drop-ins, environment files, executable and platform version. Read the actual merged configuration. Changing `User=` can break access to device nodes, storage, sockets or certificates; compatibility tests are required. Capabilities can grant selected privileges without full root, but each granted capability still needs justification. Containers share host resources and are not automatically equivalent to separate physical trust boundaries.

For an authorised Linux lab with systemd and OpenSSH, read-only observations can include `id`, `stat`, `systemctl cat collector.service`, `systemctl show collector.service` and inspection of the relevant journal. These examples are not a promise that every distribution exposes identical fields or paths. Preserve the command, version and time with the output. Do not include credential contents in evidence exports.

### Administration must be attributable and constrained
SSH authentication can use keys, passwords or supported additional methods. A private key must remain protected, and host-key verification helps the client identify the expected endpoint. Disabling host-key checks to silence a warning removes evidence about server identity; investigate legitimate replacement and unexpected interception through a trusted verification route. Restrict permitted users and authentication methods according to the approved platform design, retaining a recoverable emergency method.

Sudo policy delegates commands or roles. A rule allowing a general-purpose shell, editor with command execution, interpreter or unrestricted wildcard can grant more authority than its friendly description suggests. Evaluate what the permitted program can actually do and how arguments are constrained. Use the supported policy validation and a safe lab test before deployment. Command logging is useful but may contain sensitive data; protect it and verify collection rather than assuming every action is recorded.

### Logs and hardening need operational verification
A journal message is an observation from a source whose collection, time and retention can fail. Correlate service start/failure, authentication, configuration and process evidence. File timestamps can change during legitimate updates or be altered, so use them with hashes, package/provenance records and audit evidence. A package signature supports origin/integrity under its trust model, not universal benign behaviour or compatibility with the OT application.

Hardening includes removing unnecessary services, limiting network exposure, supported updates and application confinement. SELinux/AppArmor or service restrictions can reduce privilege, but an unexplained denial should be diagnosed against the required operation rather than disabling enforcement globally. Test required acquisition, alarm handling, restart and restoration together with denied unauthorised modification. The accepted result is a supported least-privilege service, not simply a booted host or an empty warning screen.

#### Worked demonstrations

**Evidence walkthrough**

SYNTHETIC LINUX/SYSTEMD/OPENSSH LAB RECORD; exact distribution not asserted.
collector.service effective fields: User=root; ExecStart=/opt/collector/bin/collector; EnvironmentFile=/etc/collector/collector.env
stat: /opt/collector/bin mode 0777 owner root:root; collector executable mode 0755 root:root; collector.env mode 0666 root:root.
sudo policy grants operator: ALL=(root) NOPASSWD: /usr/bin/python3 *
SSH client reports changed host key after an undocumented motherboard replacement. Journal: service starts, then database authentication fails; acquisition buffers increase. The proposed fix is chmod 777 on every path and disabling host-key checks.

**Reasoning:** The executable's 0755 mode does not compensate for a broadly writable parent directory, and the 0666 environment file can alter inputs read by the root service. The sudo rule delegates a general-purpose interpreter, effectively much broader execution capability than a narrow diagnostic task. The changed SSH host key needs trusted reconciliation with the actual replacement record; it is not automatically an attack or automatically harmless. Database authentication failure should be investigated at the identity/configuration boundary, not treated with universal permissions. Correct supported ownership/roles and verify both useful acquisition and denied modification.

#### Guided practice

Explain why a dedicated collector identity requires more than changing User=root to User=collector.

**Hint:** Trace every resource and recovery dependency.

**Worked solution:** Determine required data directories, device access, database identity, certificates and sockets; assign supported permissions/groups and any justified capabilities; validate restart, acquisition, alarms and backup restore. Confirm ordinary operators cannot replace code/configuration or obtain unrestricted root through sudo.

#### Independent task

Environment: analytical

Review the supplied Unix baseline and write a narrow supported permission/delegation design.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L012.json

**Evidence to produce**

- Path-by-path access matrix
- Sudo capability analysis
- Service and denied-modification tests

**Acceptance criteria**

- Directory replacement risk is considered separately from file execute bits.
- The interpreter grant is recognised as broad authority.
- Database authentication failure is not repaired with global chmod.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0111 · single · diagnosis**

Why is executable mode 0755 insufficient in the supplied path?

SYNTHETIC LINUX/SYSTEMD/OPENSSH LAB RECORD; exact distribution not asserted.
collector.service effective fields: User=root; ExecStart=/opt/collector/bin/collector; EnvironmentFile=/etc/collector/collector.env
stat: /opt/collector/bin mode 0777 owner root:root; collector executable mode 0755 root:root; collector.env mode 0666 root:root.
sudo policy grants operator: ALL=(root) NOPASSWD: /usr/bin/python3 *
SSH client reports changed host key after an undocumented motherboard replacement. Journal: service starts, then database authentication fails; acquisition buffers increase. The proposed fix is chmod 777 on every path and disabling host-key checks.

1. Root ownership of the executable prevents replacement through its parent directory.
2. Its parent directory is broadly writable, allowing entry changes under the stated ordinary directory rules.
3. The environment file is safe because it is not executable.
4. Mode 0755 gives ordinary users write permission to the executable itself.

**Correct option(s):** 2

- Option 1: Directory write and search authority can permit replacing a directory entry despite file ownership.
- Option 2: Full-path integrity matters.
- Option 3: A privileged service consumes that writable file as configuration, so execution permission is not the only concern.
- Option 4: 0755 grants group/other read and execute, not write; the demonstrated risk is the writable parent.

**GICSP-Q0112 · single · mechanism**

What does 0666 mean for the regular environment file?

SYNTHETIC LINUX/SYSTEMD/OPENSSH LAB RECORD; exact distribution not asserted.
collector.service effective fields: User=root; ExecStart=/opt/collector/bin/collector; EnvironmentFile=/etc/collector/collector.env
stat: /opt/collector/bin mode 0777 owner root:root; collector executable mode 0755 root:root; collector.env mode 0666 root:root.
sudo policy grants operator: ALL=(root) NOPASSWD: /usr/bin/python3 *
SSH client reports changed host key after an undocumented motherboard replacement. Journal: service starts, then database authentication fails; acquisition buffers increase. The proposed fix is chmod 777 on every path and disabling host-key checks.

1. Everyone can execute but nobody can write.
2. Owner, group and others can read and write; execute is not granted.
3. It is encrypted at rest.
4. Only root can read it.

**Correct option(s):** 2

- Option 1: That reverses the bit meanings.
- Option 2: Each 6 is read plus write.
- Option 3: Permission mode does not establish encryption.
- Option 4: The group/other fields also grant read/write.

**GICSP-Q0113 · single · design**

What is the security significance of the sudo Python rule?

SYNTHETIC LINUX/SYSTEMD/OPENSSH LAB RECORD; exact distribution not asserted.
collector.service effective fields: User=root; ExecStart=/opt/collector/bin/collector; EnvironmentFile=/etc/collector/collector.env
stat: /opt/collector/bin mode 0777 owner root:root; collector executable mode 0755 root:root; collector.env mode 0666 root:root.
sudo policy grants operator: ALL=(root) NOPASSWD: /usr/bin/python3 *
SSH client reports changed host key after an undocumented motherboard replacement. Journal: service starts, then database authentication fails; acquisition buffers increase. The proposed fix is chmod 777 on every path and disabling host-key checks.

1. It is harmless because no password is stored in the rule.
2. It grants a general-purpose interpreter as root with broad argument scope.
3. It permits only printing Python's version.
4. It makes every Python script read-only.

**Correct option(s):** 2

- Option 1: The delegated execution authority is the concern.
- Option 2: The interpreter can perform much more than a narrow diagnostic operation.
- Option 3: The wildcard does not impose that restriction.
- Option 4: Sudo does not impose such a property.

**GICSP-Q0114 · single · operations**

Which response to the changed SSH host key is justified?

SYNTHETIC LINUX/SYSTEMD/OPENSSH LAB RECORD; exact distribution not asserted.
collector.service effective fields: User=root; ExecStart=/opt/collector/bin/collector; EnvironmentFile=/etc/collector/collector.env
stat: /opt/collector/bin mode 0777 owner root:root; collector executable mode 0755 root:root; collector.env mode 0666 root:root.
sudo policy grants operator: ALL=(root) NOPASSWD: /usr/bin/python3 *
SSH client reports changed host key after an undocumented motherboard replacement. Journal: service starts, then database authentication fails; acquisition buffers increase. The proposed fix is chmod 777 on every path and disabling host-key checks.

1. Disable checking permanently.
2. Verify the expected device/key through a trusted replacement and identity process before accepting it.
3. Copy any key offered by the network into the trusted list without review.
4. Declare a confirmed interception solely from the warning.

**Correct option(s):** 2

- Option 1: That removes endpoint-identity assurance.
- Option 2: A legitimate change and an unexpected endpoint both remain possible.
- Option 3: That trusts the unverified endpoint.
- Option 4: The undocumented replacement is another hypothesis.

**GICSP-Q0115 · single · diagnosis**

Why is global chmod 777 a poor response to database authentication failure?

SYNTHETIC LINUX/SYSTEMD/OPENSSH LAB RECORD; exact distribution not asserted.
collector.service effective fields: User=root; ExecStart=/opt/collector/bin/collector; EnvironmentFile=/etc/collector/collector.env
stat: /opt/collector/bin mode 0777 owner root:root; collector executable mode 0755 root:root; collector.env mode 0666 root:root.
sudo policy grants operator: ALL=(root) NOPASSWD: /usr/bin/python3 *
SSH client reports changed host key after an undocumented motherboard replacement. Journal: service starts, then database authentication fails; acquisition buffers increase. The proposed fix is chmod 777 on every path and disabling host-key checks.

1. 0777 guarantees valid passwords.
2. Filesystem modes are irrelevant because the visible error mentions database authentication.
3. It broadens filesystem authority without diagnosing the credential/database permission problem.
4. Making every path executable supplies the missing database credential.

**Correct option(s):** 3

- Option 1: Modes do not repair credentials.
- Option 2: Permissions may matter to service behaviour, but a blanket chmod does not diagnose or justify this change.
- Option 3: The proposed change targets an unproven cause and creates exposure.
- Option 4: Unix permission bits do not substitute for the database’s authentication material.

**GICSP-Q0116 · multi · implementation**

Which evidence should be read to understand a systemd service's effective configuration? Select all that apply.

SYNTHETIC LINUX/SYSTEMD/OPENSSH LAB RECORD; exact distribution not asserted.
collector.service effective fields: User=root; ExecStart=/opt/collector/bin/collector; EnvironmentFile=/etc/collector/collector.env
stat: /opt/collector/bin mode 0777 owner root:root; collector executable mode 0755 root:root; collector.env mode 0666 root:root.
sudo policy grants operator: ALL=(root) NOPASSWD: /usr/bin/python3 *
SSH client reports changed host key after an undocumented motherboard replacement. Journal: service starts, then database authentication fails; acquisition buffers increase. The proposed fix is chmod 777 on every path and disabling host-key checks.

1. The main unit and applicable drop-ins
2. Referenced environment/configuration files
3. Relevant platform/version and runtime properties
4. Only the unit's friendly description

**Correct option(s):** 1, 2, 3

- Option 1: Overrides can change the deployed behaviour.
- Option 2: They can alter service inputs.
- Option 3: Implementation and effective state matter.
- Option 4: Description text does not establish execution settings.

**GICSP-Q0117 · single · mechanism**

What does directory execute permission principally enable in this context?

SYNTHETIC LINUX/SYSTEMD/OPENSSH LAB RECORD; exact distribution not asserted.
collector.service effective fields: User=root; ExecStart=/opt/collector/bin/collector; EnvironmentFile=/etc/collector/collector.env
stat: /opt/collector/bin mode 0777 owner root:root; collector executable mode 0755 root:root; collector.env mode 0666 root:root.
sudo policy grants operator: ALL=(root) NOPASSWD: /usr/bin/python3 *
SSH client reports changed host key after an undocumented motherboard replacement. Journal: service starts, then database authentication fails; acquisition buffers increase. The proposed fix is chmod 777 on every path and disabling host-key checks.

1. Traversal/search of directory entries subject to the remaining access checks.
2. Encrypting the directory.
3. Automatic ownership of child files.
4. Running every file inside regardless of its mode.

**Correct option(s):** 1

- Option 1: Directory bits have meanings distinct from regular-file execution.
- Option 2: Permission bits do not provide encryption.
- Option 3: Traversal does not change ownership.
- Option 4: File permissions and other controls still apply.

**GICSP-Q0118 · single · implementation**

A confinement policy blocks a required collector operation. What is the best engineering response?

SYNTHETIC LINUX/SYSTEMD/OPENSSH LAB RECORD; exact distribution not asserted.
collector.service effective fields: User=root; ExecStart=/opt/collector/bin/collector; EnvironmentFile=/etc/collector/collector.env
stat: /opt/collector/bin mode 0777 owner root:root; collector executable mode 0755 root:root; collector.env mode 0666 root:root.
sudo policy grants operator: ALL=(root) NOPASSWD: /usr/bin/python3 *
SSH client reports changed host key after an undocumented motherboard replacement. Journal: service starts, then database authentication fails; acquisition buffers increase. The proposed fix is chmod 777 on every path and disabling host-key checks.

1. Identify the exact denied operation and adopt a narrow supported policy/configuration correction with tests.
2. Grant every capability to the service.
3. Ignore the collection outage because the host boots.
4. Disable all confinement permanently.

**Correct option(s):** 1

- Option 1: Preserve useful confinement while restoring required function.
- Option 2: Excess privilege is not a targeted correction.
- Option 3: Required service remains failed.
- Option 4: That removes unrelated protections without assessment.

**GICSP-Q0119 · single · mechanism**

Which statement about a signed software package is defensible?

SYNTHETIC LINUX/SYSTEMD/OPENSSH LAB RECORD; exact distribution not asserted.
collector.service effective fields: User=root; ExecStart=/opt/collector/bin/collector; EnvironmentFile=/etc/collector/collector.env
stat: /opt/collector/bin mode 0777 owner root:root; collector executable mode 0755 root:root; collector.env mode 0666 root:root.
sudo policy grants operator: ALL=(root) NOPASSWD: /usr/bin/python3 *
SSH client reports changed host key after an undocumented motherboard replacement. Journal: service starts, then database authentication fails; acquisition buffers increase. The proposed fix is chmod 777 on every path and disabling host-key checks.

1. It proves the running process uses that package unchanged.
2. A valid signature proves the package has no exploitable defects.
3. It guarantees correct controller point mapping.
4. Its signature supports integrity/origin under the trusted signing model; compatibility and behaviour still need testing.

**Correct option(s):** 4

- Option 1: Deployed/runtime state needs separate evidence.
- Option 2: Signature validation identifies integrity/signer under policy, not absence of vulnerabilities.
- Option 3: Application configuration is a different requirement.
- Option 4: Provenance is not a universal correctness guarantee.

**GICSP-Q0120 · single · recovery**

What closes the service-hardening acceptance after correction?

SYNTHETIC LINUX/SYSTEMD/OPENSSH LAB RECORD; exact distribution not asserted.
collector.service effective fields: User=root; ExecStart=/opt/collector/bin/collector; EnvironmentFile=/etc/collector/collector.env
stat: /opt/collector/bin mode 0777 owner root:root; collector executable mode 0755 root:root; collector.env mode 0666 root:root.
sudo policy grants operator: ALL=(root) NOPASSWD: /usr/bin/python3 *
SSH client reports changed host key after an undocumented motherboard replacement. Journal: service starts, then database authentication fails; acquisition buffers increase. The proposed fix is chmod 777 on every path and disabling host-key checks.

1. Only the absence of journal warnings.
2. Only changing root to another username in documentation.
3. Required acquisition/alarm/restart/recovery tests plus denied unauthorised code/configuration changes.
4. Only a successful system boot.

**Correct option(s):** 3

- Option 1: Collection gaps or disabled logging can hide problems.
- Option 2: The effective implementation must be observed.
- Option 3: Function and reduced authority must both be demonstrated.
- Option 4: Boot does not establish the collector's function or boundary.

#### Recall

**Why inspect parent-directory permissions?**

Writable directory entries can undermine a protected file through replacement or path changes.

**Why is an unrestricted interpreter in sudo broad authority?**

It can execute many operations beyond a fixed diagnostic command; evaluate the program and argument scope.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [Linux kernel documentation](https://docs.kernel.org/)

### GICSP-L013 — Patch decisions, endpoint protection and application control

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L012

### A vulnerability identifier starts an investigation
Determine the exact affected product, version, component and reachable condition. A matching name in an inventory is not enough when the vulnerable feature is absent or the version evidence is stale. Conversely, lack of Internet exposure does not eliminate a path through vendor access, engineering workstations or removable media. Relate technical severity to process consequence, existing controls, detection and recovery. A numerical score helps organise review but cannot decide every plant-specific treatment.

A patch plan records approved package provenance, dependencies, prerequisites, interruption, recovery and tests. Some updates require an intermediate version or companion driver; unsupported downgrade may make replacement or OEM recovery the fallback. Stage on a representative authorised system with a realistic service workload. Verify alarm timing, data integrity, protocol compatibility and relevant security behaviour before release. Retain an explicit owner and deadline when a supported change must be deferred.

### Endpoint controls observe or constrain different behaviour
Antimalware can identify known malicious content or suspicious behaviour, while endpoint detection/response adds telemetry and response capabilities according to its implementation. A detection is evidence to investigate; quarantine or process termination can affect an industrial application. Define who may invoke those actions and how required service is protected. A sensor reporting no alerts is not proof of no compromise if it is unhealthy, excluded or unable to observe the relevant layer.

Application control limits executable or script execution using supported rule types. A hash rule binds a specific file content; an authorised update changes the hash and may require a reviewed rule update. A publisher rule depends on signature trust and its configured scope, such as product/version constraints. A path rule depends on directory integrity: allowing all execution from a user-writable directory can permit unintended content. None of these rule types alone proves software is benign or appropriate for the process.

Start in an explicitly controlled observation/audit phase where supported, collect the legitimate execution set, review exceptions and test enforcement on a bounded system. Do not turn every observed program into an approved program automatically: the baseline can already contain unwanted activity. Include maintenance, backup, restart and recovery tools, not only steady operation. Protect policy modification and its audit trail.

### Exceptions need narrow technical boundaries
An exclusion can reduce a compatibility issue but also remove visibility or enforcement. Specify exact path, process, behaviour, reason, version, owner, expiry and compensating observation. Excluding an entire drive because one database file is busy is a much larger change than the evidence justifies. Test that required operation works and representative prohibited activity remains blocked in a harmless isolated fixture. Do not use real malware against operational systems to prove effectiveness.

### Release and sustain
Compare the effective deployed policy with the approved version. Record agent health, update status, collection coverage and application performance. After a patch or rule change, test the actual vulnerability condition or an appropriate safe surrogate, relevant allowed/denied execution and restoration. An installer success message or falling alert count cannot establish complete acceptance. Investigate whether reduced alerts reflect fewer malicious events, changed workload or missing telemetry. The aim is a supported, observable endpoint boundary that preserves the required industrial function.

#### Worked demonstrations

**Evidence walkthrough**

SYNTHETIC ENDPOINT CONTROL REVIEW.
Collector version 4.1 is affected by advisory A when its remote administration feature is enabled; that feature is enabled through a vendor route. Supported patch 4.3 requires driver D7 first; downgrade to 4.1 is unsupported.
Application-control proposal: allow any executable under C:\Plant\Temp (Operators have Modify); allow signed VendorCo code without product/version limits; existing collector.exe hash H1 is approved, but patch installs H2.
Agent trial blocks a required database writer and increases alarm delay from 2 s to 11 s against a 5 s maximum. Proposed exclusion: entire C: drive, permanent. Agent telemetry stopped during the reported zero-alert period.

**Reasoning:** The advisory condition is present and reachable through a bounded but relevant route. Plan the supported D7→4.3 dependency with tested recovery rather than a fictitious downgrade. The writable path and broad publisher rule permit more than the reviewed execution set; H2 requires intentional approval, not blind reuse of H1. The agent trial fails the alarm requirement. Diagnose the specific compatibility issue and scope any approved temporary exclusion narrowly; a drive-wide permanent exception is unsupported. Zero alerts during telemetry loss says nothing about event absence.

#### Guided practice

Design post-patch application-control tests for H2 without authorising every future VendorCo binary.

**Hint:** Separate provenance, rule scope and observed execution.

**Worked solution:** Verify trusted package/version and H2, approve the supported intended binary or narrowly constrained publisher policy, test legitimate startup/maintenance, test a harmless unapproved binary in the writable path, verify protected policy changes and alarm timing, then document recovery limitations.

#### Independent task

Environment: analytical

Write a patch/control decision record and an enforcement test matrix from the fixture.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L013.json

**Evidence to produce**

- Exposure and dependency analysis
- Narrow rule/exception specification
- Positive/negative/service/recovery tests

**Acceptance criteria**

- No unsupported downgrade is promised.
- Writable-path and broad-publisher risks are distinguished.
- Zero alerts with missing telemetry is reported as an evidence gap.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0121 · single · diagnosis**

Which fact makes advisory A relevant to this collector?

SYNTHETIC ENDPOINT CONTROL REVIEW.
Collector version 4.1 is affected by advisory A when its remote administration feature is enabled; that feature is enabled through a vendor route. Supported patch 4.3 requires driver D7 first; downgrade to 4.1 is unsupported.
Application-control proposal: allow any executable under C:\Plant\Temp (Operators have Modify); allow signed VendorCo code without product/version limits; existing collector.exe hash H1 is approved, but patch installs H2.
Agent trial blocks a required database writer and increases alarm delay from 2 s to 11 s against a 5 s maximum. Proposed exclusion: entire C: drive, permanent. Agent telemetry stopped during the reported zero-alert period.

1. The vendor route makes the collector exempt because it is not directly Internet-facing.
2. The affected version and enabled reachable administration feature match its stated condition.
3. The collector’s version is sufficient without checking whether remote administration is enabled.
4. The new patch hash H2 is the vulnerability’s enabling condition.

**Correct option(s):** 2

- Option 1: The relevant feature is reachable through the vendor route; direct Internet exposure is not required.
- Option 2: Applicability requires component/version/exposure evidence.
- Option 3: The advisory includes an enabling feature condition, which the fixture confirms.
- Option 4: H2 is a release/application-control issue; the advisory concerns version 4.1 with remote administration enabled.

**GICSP-Q0122 · single · recovery**

What is wrong with promising rollback from 4.3 to 4.1?

SYNTHETIC ENDPOINT CONTROL REVIEW.
Collector version 4.1 is affected by advisory A when its remote administration feature is enabled; that feature is enabled through a vendor route. Supported patch 4.3 requires driver D7 first; downgrade to 4.1 is unsupported.
Application-control proposal: allow any executable under C:\Plant\Temp (Operators have Modify); allow signed VendorCo code without product/version limits; existing collector.exe hash H1 is approved, but patch installs H2.
Agent trial blocks a required database writer and increases alarm delay from 2 s to 11 s against a 5 s maximum. Proposed exclusion: entire C: drive, permanent. Agent telemetry stopped during the reported zero-alert period.

1. The supplied vendor path explicitly does not support downgrade.
2. Retaining the old installer establishes rollback even after an incompatible schema migration.
3. Driver D7 is an antivirus signature.
4. Reject the supported patch permanently because a simple downgrade is unavailable.

**Correct option(s):** 1

- Option 1: Recovery must use a supported alternative.
- Option 2: Availability of old files does not prove that the new state can be safely downgraded.
- Option 3: The fixture identifies it as a required driver dependency.
- Option 4: A tested alternative recovery plan may support the update; irreversibility requires planning, not automatic rejection.

**GICSP-Q0123 · single · design**

Why is the C:\Plant\Temp path rule weak?

SYNTHETIC ENDPOINT CONTROL REVIEW.
Collector version 4.1 is affected by advisory A when its remote administration feature is enabled; that feature is enabled through a vendor route. Supported patch 4.3 requires driver D7 first; downgrade to 4.1 is unsupported.
Application-control proposal: allow any executable under C:\Plant\Temp (Operators have Modify); allow signed VendorCo code without product/version limits; existing collector.exe hash H1 is approved, but patch installs H2.
Agent trial blocks a required database writer and increases alarm delay from 2 s to 11 s against a 5 s maximum. Proposed exclusion: entire C: drive, permanent. Agent telemetry stopped during the reported zero-alert period.

1. The path is acceptable because Operators cannot change the application-control policy.
2. The rule restricts files there to the supported collector version.
3. A path rule binds execution to the approved H1 digest.
4. Operators can place or replace executable content in the allowed location.

**Correct option(s):** 4

- Option 1: They can still replace content inside the broadly allowed writable path.
- Option 2: No product or version constraint is included in the path rule.
- Option 3: The proposal permits any executable in a writable directory, not a specific content hash.
- Option 4: A trusted path rule depends on write integrity of the path.

**GICSP-Q0124 · single · implementation**

What must happen when the approved binary changes from H1 to H2?

SYNTHETIC ENDPOINT CONTROL REVIEW.
Collector version 4.1 is affected by advisory A when its remote administration feature is enabled; that feature is enabled through a vendor route. Supported patch 4.3 requires driver D7 first; downgrade to 4.1 is unsupported.
Application-control proposal: allow any executable under C:\Plant\Temp (Operators have Modify); allow signed VendorCo code without product/version limits; existing collector.exe hash H1 is approved, but patch installs H2.
Agent trial blocks a required database writer and increases alarm delay from 2 s to 11 s against a 5 s maximum. Proposed exclusion: entire C: drive, permanent. Agent telemetry stopped during the reported zero-alert period.

1. Review and update the supported rule after verifying the intended patch/provenance.
2. Keep H1 and claim H2 will match.
3. Delete the audit history.
4. Allow every executable to avoid maintenance.

**Correct option(s):** 1

- Option 1: Content-based approval does not automatically cover changed bytes.
- Option 2: Different hashes do not match an exact hash rule.
- Option 3: The history explains the authorised transition.
- Option 4: That removes the intended boundary.

**GICSP-Q0125 · single · mechanism**

Why can an unconstrained VendorCo publisher allowance be too broad?

SYNTHETIC ENDPOINT CONTROL REVIEW.
Collector version 4.1 is affected by advisory A when its remote administration feature is enabled; that feature is enabled through a vendor route. Supported patch 4.3 requires driver D7 first; downgrade to 4.1 is unsupported.
Application-control proposal: allow any executable under C:\Plant\Temp (Operators have Modify); allow signed VendorCo code without product/version limits; existing collector.exe hash H1 is approved, but patch installs H2.
Agent trial blocks a required database writer and increases alarm delay from 2 s to 11 s against a 5 s maximum. Proposed exclusion: entire C: drive, permanent. Agent telemetry stopped during the reported zero-alert period.

1. It may permit other signed products or versions beyond the approved task.
2. Publisher approval prevents any signed VendorCo utility from using administrative capabilities.
3. The publisher rule checks whether each invocation matches an approved work order.
4. It guarantees the code is malicious.

**Correct option(s):** 1

- Option 1: Signature trust and permitted application scope are distinct.
- Option 2: A broad publisher rule can admit other signed tools with capabilities outside the required application.
- Option 3: Code-signing identity does not supply operation-specific authorisation.
- Option 4: Excess scope is a risk, not proof of maliciousness.

**GICSP-Q0126 · single · calculation**

Which trial result blocks acceptance of the agent as tested?

SYNTHETIC ENDPOINT CONTROL REVIEW.
Collector version 4.1 is affected by advisory A when its remote administration feature is enabled; that feature is enabled through a vendor route. Supported patch 4.3 requires driver D7 first; downgrade to 4.1 is unsupported.
Application-control proposal: allow any executable under C:\Plant\Temp (Operators have Modify); allow signed VendorCo code without product/version limits; existing collector.exe hash H1 is approved, but patch installs H2.
Agent trial blocks a required database writer and increases alarm delay from 2 s to 11 s against a 5 s maximum. Proposed exclusion: entire C: drive, permanent. Agent telemetry stopped during the reported zero-alert period.

1. The agent records a process name.
2. The collector uses a database.
3. The patch changes the executable hash.
4. The required alarm delay is 11 s against a 5 s limit.

**Correct option(s):** 4

- Option 1: Telemetry itself is expected behaviour.
- Option 2: That is not automatically incompatible.
- Option 3: A legitimate update can change it through review.
- Option 4: Operational acceptance failed.

**GICSP-Q0127 · single · design**

Which exception is better supported by the evidence?

SYNTHETIC ENDPOINT CONTROL REVIEW.
Collector version 4.1 is affected by advisory A when its remote administration feature is enabled; that feature is enabled through a vendor route. Supported patch 4.3 requires driver D7 first; downgrade to 4.1 is unsupported.
Application-control proposal: allow any executable under C:\Plant\Temp (Operators have Modify); allow signed VendorCo code without product/version limits; existing collector.exe hash H1 is approved, but patch installs H2.
Agent trial blocks a required database writer and increases alarm delay from 2 s to 11 s against a 5 s maximum. Proposed exclusion: entire C: drive, permanent. Agent telemetry stopped during the reported zero-alert period.

1. A reviewed narrow exclusion tied to the proven conflict, version, owner, expiry and compensating tests.
2. Excluding every vendor process forever.
3. A permanent entire-drive exclusion.
4. Disabling all agent health reporting.

**Correct option(s):** 1

- Option 1: Scope should match the demonstrated need.
- Option 2: That is broad and unbounded.
- Option 3: It removes far more protection than justified.
- Option 4: It conceals whether protection is operating.

**GICSP-Q0128 · single · diagnosis**

What does the zero-alert period establish when telemetry stopped?

SYNTHETIC ENDPOINT CONTROL REVIEW.
Collector version 4.1 is affected by advisory A when its remote administration feature is enabled; that feature is enabled through a vendor route. Supported patch 4.3 requires driver D7 first; downgrade to 4.1 is unsupported.
Application-control proposal: allow any executable under C:\Plant\Temp (Operators have Modify); allow signed VendorCo code without product/version limits; existing collector.exe hash H1 is approved, but patch installs H2.
Agent trial blocks a required database writer and increases alarm delay from 2 s to 11 s against a 5 s maximum. Proposed exclusion: entire C: drive, permanent. Agent telemetry stopped during the reported zero-alert period.

1. The application-control rules passed.
2. The endpoint population is clean because the alert dashboard is empty.
3. The lack of alerts proves the patch removed the exploitable feature.
4. No usable detection observations were collected for that interval.

**Correct option(s):** 4

- Option 1: Rule enforcement needs its own tests.
- Option 2: A failed data source can produce the same display without establishing endpoint state.
- Option 3: Stopped telemetry prevents that conclusion from the alert count.
- Option 4: It does not establish absence of events.

**GICSP-Q0129 · multi · implementation**

Which actions belong in a realistic application-control acceptance set? Select all that apply.

SYNTHETIC ENDPOINT CONTROL REVIEW.
Collector version 4.1 is affected by advisory A when its remote administration feature is enabled; that feature is enabled through a vendor route. Supported patch 4.3 requires driver D7 first; downgrade to 4.1 is unsupported.
Application-control proposal: allow any executable under C:\Plant\Temp (Operators have Modify); allow signed VendorCo code without product/version limits; existing collector.exe hash H1 is approved, but patch installs H2.
Agent trial blocks a required database writer and increases alarm delay from 2 s to 11 s against a 5 s maximum. Proposed exclusion: entire C: drive, permanent. Agent telemetry stopped during the reported zero-alert period.

1. Normal and maintenance/recovery execution
2. Automatically approve every baseline observation
3. Protected policy modification and audit
4. Harmless unapproved execution attempts in an isolated lab

**Correct option(s):** 1, 3, 4

- Option 1: The allowed set must support the full declared lifecycle.
- Option 2: An observed program is not necessarily authorised.
- Option 3: The control itself needs governed administration.
- Option 4: They test enforcement without live malware.

**GICSP-Q0130 · single · recovery**

A staged patch succeeds but removes the only recovery tool from the allowlist. What is the disposition?

SYNTHETIC ENDPOINT CONTROL REVIEW.
Collector version 4.1 is affected by advisory A when its remote administration feature is enabled; that feature is enabled through a vendor route. Supported patch 4.3 requires driver D7 first; downgrade to 4.1 is unsupported.
Application-control proposal: allow any executable under C:\Plant\Temp (Operators have Modify); allow signed VendorCo code without product/version limits; existing collector.exe hash H1 is approved, but patch installs H2.
Agent trial blocks a required database writer and increases alarm delay from 2 s to 11 s against a 5 s maximum. Proposed exclusion: entire C: drive, permanent. Agent telemetry stopped during the reported zero-alert period.

1. Hold release until a supported authorised recovery route is restored and tested.
2. Assume the tool will be allowed during an emergency.
3. Accept because normal collection works.
4. Permanently disable application control.

**Correct option(s):** 1

- Option 1: Required recovery is part of acceptance.
- Option 2: Unverified emergency behaviour is not a recovery plan.
- Option 3: Steady operation does not cover failure recovery.
- Option 4: A narrow supported correction should be assessed.

#### Recall

**Hash, publisher and path rules differ because…**

They match exact content, signing attributes or location; each has different update and trust assumptions.

**Why is zero alerts weak evidence?**

Sensor health, exclusions, collection coverage and relevant detection capability must also be established.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [Microsoft Windows security auditing](https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/security-auditing-overview)
- [CISA ICS advisories](https://www.cisa.gov/news-events/ics-advisories)

### GICSP-L014 — Firmware, BMC and the platform trust chain

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L013

### The host operating system is not the whole platform
An industrial server can contain UEFI/BIOS, BMC, network/storage adapter firmware, bootloaders, operating-system components and application code. These layers have different update paths and authorities. Reinstalling the OS changes one layer; it does not automatically remove an unauthorised BMC account, correct boot settings or establish peripheral firmware integrity. Inventory the actual trust and recovery boundary before declaring a host clean.

Secure Boot checks applicable boot components against configured signature/policy requirements. It does not prove every signed component is vulnerability-free, measure every device firmware layer or ensure that the policy itself was configured appropriately. Measured boot records measurements that can support a later assessment against an expected baseline. A measurement log or TPM presence becomes useful only when a trustworthy verifier, reference values, freshness and response policy are defined. Do not call the existence of a TPM complete remote attestation.

### Management can operate below host controls
A BMC can expose console, virtual media, power control and configuration even while the main OS is stopped. Its dedicated or shared network mode, credentials, certificates and firmware therefore need explicit controls. A host firewall may not govern the BMC's traffic. Restrict management sources and operations, record accountable identities and preserve a supported emergency path. Test certificate/name validation rather than turning off trust checks because the browser warns.

Standard management interfaces such as Redfish organise supported resources and actions, but implementations vary. Discover linked resources through the documented service root rather than assuming a hard-coded identifier. A missing health property is unavailable data, not a zero measurement. A read-only inventory service must have appropriately limited credentials and exposed methods; administrator credentials behind a polite script remain excessive authority.

### Updates are dependency changes
Verify package provenance, exact supported model, required intermediate versions, BIOS/driver relationships, restart impact and recovery options. A checksum supports byte integrity only when its expected value comes through a trustworthy channel; a hash supplied beside an untrusted image does not independently prove origin. A signed package still needs compatibility and operational validation. Some firmware transitions are not downgradeable; record the supported recovery or replacement route rather than inventing a reverse installation.

After update, confirm effective version, platform settings, required device enumeration, management restrictions, logs/time and representative application/storage/network function. A successful updater message is not complete acceptance. A board replacement can change BMC identity or TPM-bound key access, so protected independent recovery keys and identity reconciliation belong in the initial plan.

### Respond to uncertainty honestly
When management compromise is suspected, preserve available logs/configuration and coordinate containment with operations. Restore supported trusted firmware/configuration where the platform and authority permit, rotate affected credentials, revoke obsolete trust and validate required function. If the hardware lacks a reliable way to establish a disputed firmware state, record that limitation and escalate to the supported OEM or replacement route. Do not claim a clean host solely from an antimalware scan above the unresolved layer.

NIST firmware-resiliency guidance separates protection, detection and recovery. Apply those ideas to the exact platform rather than treating a feature list as proof. The course's synthetic exercise tests reasoning and acceptance design; actual firmware operations require the selected model's supported procedure, isolated equipment and authorised supervision.

#### Worked demonstrations

**Evidence walkthrough**

SYNTHETIC PLATFORM RECORD.
Host OS was rebuilt from a verified image. BMC still contains account temp_support created during the incident; its old certificate remains trusted by automation with certificate verification disabled. BIOS 3.0 requires NIC driver 8.2, but the host has 7.9. Proposed firmware plan jumps BMC 2.1→2.4 although the supplied OEM fixture requires 2.2 first; downgrade from 2.4 is unsupported. TPM is present, but no verifier or expected measurements are defined. Redfish sensor reading is absent; collector substitutes 0°C.

**Reasoning:** OS restoration alone leaves management authority and configuration unresolved. Remove/reconcile temp_support through the incident plan, restore expected certificate/identity validation and assess the BMC trust boundary. The update proposal violates both the stated sequence and driver compatibility; stage a supported coordinated path and recovery alternative. TPM presence is not attestation. Substituting 0°C fabricates a measurement and can mislead alarms/models; preserve unavailable quality. Accept only after required platform, service and denied-old-authority tests pass.

#### Guided practice

Write a trust-acceptance checklist for replacing the motherboard.

**Hint:** Include identity, keys and the software-dependent service, not only hardware detection.

**Worked solution:** Reconcile serial/BMC identities, supported firmware/driver/boot policy, certificates and revoked accounts; recover TPM-bound secrets through protected approved custody; verify management restrictions, logs/time, storage/network service and denied obsolete authority. State unverified firmware layers explicitly.

#### Independent task

Environment: analytical

Review the supplied platform plan and produce a supported restoration dependency sequence.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L014.json

**Evidence to produce**

- Layered trust map
- Update/driver compatibility findings
- Function and authority acceptance tests

**Acceptance criteria**

- OS rebuild is not treated as BMC eradication.
- Unsupported downgrade is not promised.
- Missing telemetry remains unavailable rather than zero.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0131 · single · recovery**

Which fact prevents declaring trusted recovery from the OS rebuild alone?

SYNTHETIC PLATFORM RECORD.
Host OS was rebuilt from a verified image. BMC still contains account temp_support created during the incident; its old certificate remains trusted by automation with certificate verification disabled. BIOS 3.0 requires NIC driver 8.2, but the host has 7.9. Proposed firmware plan jumps BMC 2.1→2.4 although the supplied OEM fixture requires 2.2 first; downgrade from 2.4 is unsupported. TPM is present, but no verifier or expected measurements are defined. Redfish sensor reading is absent; collector substitutes 0°C.

1. A trusted old BMC certificate proves the current management account set is approved.
2. Rebuilding the host OS removes temp_support from the separately managed BMC.
3. The incident-created BMC account remains active.
4. The TPM’s presence makes the unverified BMC state acceptable without a verifier.

**Correct option(s):** 3

- Option 1: Certificate trust does not validate the current BMC account configuration.
- Option 2: The record explicitly says the BMC account remains after the OS rebuild.
- Option 3: Management authority exists below the rebuilt OS boundary.
- Option 4: No expected measurements or attestation decision process exists in the fixture.

**GICSP-Q0132 · single · mechanism**

What does TPM presence establish by itself?

SYNTHETIC PLATFORM RECORD.
Host OS was rebuilt from a verified image. BMC still contains account temp_support created during the incident; its old certificate remains trusted by automation with certificate verification disabled. BIOS 3.0 requires NIC driver 8.2, but the host has 7.9. Proposed firmware plan jumps BMC 2.1→2.4 although the supplied OEM fixture requires 2.2 first; downgrade from 2.4 is unsupported. TPM is present, but no verifier or expected measurements are defined. Redfish sensor reading is absent; collector substitutes 0°C.

1. The TPM makes recovery-key custody unnecessary after the OS rebuild.
2. The TPM proves every boot and peripheral measurement matches an approved reference automatically.
3. Remote attestation has passed.
4. The platform exposes that hardware feature; an attestation design is still required.

**Correct option(s):** 4

- Option 1: Recovery dependencies still need protected, usable key management.
- Option 2: No verifier or expected measurements are defined, and coverage must be established.
- Option 3: No assessment process or result is supplied.
- Option 4: A verifier, expected state, freshness and policy are missing.

**GICSP-Q0133 · single · design**

Why is certificate verification disabled a concern for BMC automation?

SYNTHETIC PLATFORM RECORD.
Host OS was rebuilt from a verified image. BMC still contains account temp_support created during the incident; its old certificate remains trusted by automation with certificate verification disabled. BIOS 3.0 requires NIC driver 8.2, but the host has 7.9. Proposed firmware plan jumps BMC 2.1→2.4 although the supplied OEM fixture requires 2.2 first; downgrade from 2.4 is unsupported. TPM is present, but no verifier or expected measurements are defined. Redfish sensor reading is absent; collector substitutes 0°C.

1. It necessarily disables all encryption.
2. It proves the certificate was stolen.
3. It guarantees better availability with no trade-off.
4. The client is not applying the expected endpoint-identity validation.

**Correct option(s):** 4

- Option 1: Encryption may remain while identity checking is weakened.
- Option 2: No such event is established.
- Option 3: Trust and failure behaviour must be evaluated.
- Option 4: Encryption alone does not establish the intended peer.

**GICSP-Q0134 · single · implementation**

Which update-plan defect is directly stated?

SYNTHETIC PLATFORM RECORD.
Host OS was rebuilt from a verified image. BMC still contains account temp_support created during the incident; its old certificate remains trusted by automation with certificate verification disabled. BIOS 3.0 requires NIC driver 8.2, but the host has 7.9. Proposed firmware plan jumps BMC 2.1→2.4 although the supplied OEM fixture requires 2.2 first; downgrade from 2.4 is unsupported. TPM is present, but no verifier or expected measurements are defined. Redfish sensor reading is absent; collector substitutes 0°C.

1. Unsupported downgrade means the update has a verified rollback path.
2. The host OS rebuild satisfies the BMC update prerequisite.
3. The proposed jump omits required intermediate BMC 2.2.
4. The plan is accepted because 2.4 is numerically newer than 2.1.

**Correct option(s):** 3

- Option 1: It means that simple downgrade cannot be promised as rollback.
- Option 2: The stated prerequisite is a BMC version transition, not host OS state.
- Option 3: The selected OEM fixture defines that prerequisite.
- Option 4: The supplied OEM path requires the intermediate 2.2 transition.

**GICSP-Q0135 · single · design**

Why must NIC driver 7.9 be reviewed before BIOS 3.0?

SYNTHETIC PLATFORM RECORD.
Host OS was rebuilt from a verified image. BMC still contains account temp_support created during the incident; its old certificate remains trusted by automation with certificate verification disabled. BIOS 3.0 requires NIC driver 8.2, but the host has 7.9. Proposed firmware plan jumps BMC 2.1→2.4 although the supplied OEM fixture requires 2.2 first; downgrade from 2.4 is unsupported. TPM is present, but no verifier or expected measurements are defined. Redfish sensor reading is absent; collector substitutes 0°C.

1. Driver version numbers are temperatures.
2. BIOS and devices can never have dependencies.
3. The supplied support relationship requires driver 8.2.
4. Any boot success proves every driver function.

**Correct option(s):** 3

- Option 1: They identify software revisions.
- Option 2: Firmware/driver compatibility can be coupled.
- Option 3: Compatibility is a combined platform state.
- Option 4: Enumeration/performance/recovery still need tests.

**GICSP-Q0136 · single · implementation**

How should the absent Redfish temperature be represented?

SYNTHETIC PLATFORM RECORD.
Host OS was rebuilt from a verified image. BMC still contains account temp_support created during the incident; its old certificate remains trusted by automation with certificate verification disabled. BIOS 3.0 requires NIC driver 8.2, but the host has 7.9. Proposed firmware plan jumps BMC 2.1→2.4 although the supplied OEM fixture requires 2.2 first; downgrade from 2.4 is unsupported. TPM is present, but no verifier or expected measurements are defined. Redfish sensor reading is absent; collector substitutes 0°C.

1. The previous value as newly measured.
2. A random value inside the normal range.
3. 0°C with good quality.
4. Unavailable, with the resource/source context and collection status.

**Correct option(s):** 4

- Option 1: It misstates freshness/provenance.
- Option 2: Plausibility does not create evidence.
- Option 3: That fabricates a physical value.
- Option 4: Missing is not a measured zero.

**GICSP-Q0137 · multi · mechanism**

Which statements about Secure Boot are justified? Select all that apply.

SYNTHETIC PLATFORM RECORD.
Host OS was rebuilt from a verified image. BMC still contains account temp_support created during the incident; its old certificate remains trusted by automation with certificate verification disabled. BIOS 3.0 requires NIC driver 8.2, but the host has 7.9. Proposed firmware plan jumps BMC 2.1→2.4 although the supplied OEM fixture requires 2.2 first; downgrade from 2.4 is unsupported. TPM is present, but no verifier or expected measurements are defined. Redfish sensor reading is absent; collector substitutes 0°C.

1. It guarantees all signed code is free of vulnerabilities.
2. Its configuration and trust roots require governance.
3. It checks applicable boot components under the configured signature/policy model.
4. It automatically attests every peripheral firmware device.

**Correct option(s):** 2, 3

- Option 1: Signing does not prove correctness.
- Option 2: An inappropriate policy can weaken the intended boundary.
- Option 3: Its scope depends on platform and policy.
- Option 4: That broader claim is not inherent in the feature.

**GICSP-Q0138 · single · diagnosis**

A firmware hash matches one posted beside an untrusted download. What is still missing?

SYNTHETIC PLATFORM RECORD.
Host OS was rebuilt from a verified image. BMC still contains account temp_support created during the incident; its old certificate remains trusted by automation with certificate verification disabled. BIOS 3.0 requires NIC driver 8.2, but the host has 7.9. Proposed firmware plan jumps BMC 2.1→2.4 although the supplied OEM fixture requires 2.2 first; downgrade from 2.4 is unsupported. TPM is present, but no verifier or expected measurements are defined. Redfish sensor reading is absent; collector substitutes 0°C.

1. Publish the signing private key so the downloaded firmware can be independently verified.
2. A trustworthy expected-value/provenance channel.
3. Any byte-integrity comparison at all.
4. Matching a checksum from the same untrusted site establishes independent vendor provenance.

**Correct option(s):** 2

- Option 1: Verification uses the trusted public-key/provenance path; disclosing the private key would undermine signing trust.
- Option 2: Matching two attacker-controlled artefacts does not independently establish origin.
- Option 3: The comparison may still show equality to the provided value.
- Option 4: An attacker can replace both content and its posted checksum; a trusted reference is still needed.

**GICSP-Q0139 · single · recovery**

What is appropriate when the disputed firmware state cannot be reliably established on this platform?

SYNTHETIC PLATFORM RECORD.
Host OS was rebuilt from a verified image. BMC still contains account temp_support created during the incident; its old certificate remains trusted by automation with certificate verification disabled. BIOS 3.0 requires NIC driver 8.2, but the host has 7.9. Proposed firmware plan jumps BMC 2.1→2.4 although the supplied OEM fixture requires 2.2 first; downgrade from 2.4 is unsupported. TPM is present, but no verifier or expected measurements are defined. Redfish sensor reading is absent; collector substitutes 0°C.

1. Delete the incident account log.
2. Run arbitrary firmware images until one boots.
3. Record the limitation and use the authorised OEM recovery/replacement escalation.
4. Declare clean because the OS scanner found nothing.

**Correct option(s):** 3

- Option 1: Evidence should be preserved through the response.
- Option 2: Unsupported changes can damage recovery and trust.
- Option 3: Do not invent assurance the platform cannot provide.
- Option 4: The scanner may not observe the disputed layer.

**GICSP-Q0140 · single · operations**

Which post-update result supports release?

SYNTHETIC PLATFORM RECORD.
Host OS was rebuilt from a verified image. BMC still contains account temp_support created during the incident; its old certificate remains trusted by automation with certificate verification disabled. BIOS 3.0 requires NIC driver 8.2, but the host has 7.9. Proposed firmware plan jumps BMC 2.1→2.4 although the supplied OEM fixture requires 2.2 first; downgrade from 2.4 is unsupported. TPM is present, but no verifier or expected measurements are defined. Redfish sensor reading is absent; collector substitutes 0°C.

1. Only the updater's success message.
2. A shorter reboot time without checking driver compatibility or management access.
3. Effective supported versions/settings, required service tests and denied obsolete management authority.
4. A new firmware version recorded in inventory without functional or recovery checks.

**Correct option(s):** 3

- Option 1: It does not test the complete outcome.
- Option 2: Timing improvement does not resolve the stated dependencies and trust gaps.
- Option 3: Platform function and trust must both be verified.
- Option 4: Version evidence alone does not establish operational acceptance.

#### Recall

**Secure Boot versus measured boot?**

Secure Boot enforces applicable signature policy; measured boot records values that can support a separately defined trust assessment.

**Why can OS rebuild leave compromise unresolved?**

BMC, firmware, peripheral state and administrative identities can lie outside the rebuilt layer.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [NIST SP 800-193: firmware resiliency](https://csrc.nist.gov/pubs/sp/800/193/final)

### GICSP-L015 — Removable media, backup isolation and verified disposition

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L014

### Treat transfer as a governed data flow
Removable media can carry controller projects, firmware packages, reports, diagnostic tools and malicious or unintended content across a network boundary. An isolated network is therefore not isolated from every transfer path. Define the permitted purpose, source, asset identity, custodian, content type, inspection process and destination. A media serial label supports custody but does not prove its contents are safe. A clean scan is one observation limited by the scanner's health, configuration and detection knowledge.

Use a supported controlled transfer station or equivalent workflow appropriate to the site. Validate package provenance and integrity against a trustworthy expected value; distinguish executable content from operational data and inspect the actual file type rather than trusting an extension. Auto-run behaviour, macros, scripts and project-specific executable features require explicit treatment. A read-only destination policy can limit writes but may not prevent code execution by an authorised interpreter. Do not connect found or unexplained media to operational devices merely to learn who owns it.

### Backups have their own trust boundary
A snapshot on the same storage and controlled by the same administrator can be useful for a local rollback yet fail under array loss or compromised administration. Independence depends on media, location, authority, timing and recovery access. An immutable retention feature is meaningful only within its actual implementation and administrative escape paths. Record what can modify, delete or decrypt each retained copy and what happens if the live directory or backup console fails.

Choose backup methods that preserve the application's consistency requirements. A database dump, supported online backup, filesystem copy and virtual-machine snapshot capture different states. A snapshot excluding an external database cannot be assumed to restore the full application. Keep controller projects, device configuration, certificates/keys under approved custody, licence dependencies and compatible recovery software in the recovery design. Test restoration with synthetic data and required historical/current transactions; successful backup creation alone does not establish usable recovery.

Encryption protects retained media only under its implementation and key-custody assumptions. Losing the only key can make an otherwise intact backup unusable. Compromising a key can expose old copies even after a new key is generated. Retain required historical decryption access through protected governed custody, and assess whether incident response requires re-encryption or another treatment of exposed retained data.

### Disposition includes more than file deletion
When retiring or reusing media, select the required sanitisation outcome using applicable guidance and exact device capabilities. A quick format or deleted directory is not proof that all relevant data is inaccessible. Flash remapping can make a host overwrite different from a device-supported purge method. Cryptographic erase requires evidence that relevant data were suitably encrypted and that usable relevant key material is treated as required. Record the operation, device identity, errors, verification, validation and final custody.

A controller project export or BMC backup may contain secrets even after the main data disk is handled. Revoke retired identities and reconcile copies, licences, accounts and asset records. Use sacrificial lab media and synthetic data for learning; do not perform destructive commands against required information. The independent assessment includes a justified hold of inadequate evidence and acceptance only when the selected method and actual asset can be linked.

#### Worked demonstrations

**Evidence walkthrough**

SYNTHETIC MEDIA/RECOVERY RECORD.
USB U7 arrives from a contractor with firmware.bin and report.pdf.exe. The supplied SHA-256 text is on the same USB; no trusted vendor reference has been checked. Scanner status: signatures stale, scan completed without alert.
Backup B1 is a VM snapshot on the same array; external historian database is excluded. Backup B2 is an offline application-consistent copy encrypted with K_old, whose only retrievable copy is in the live directory vault. BMC export includes a support credential.
Retirement record says SSD D4 was quick-formatted and therefore purged; no model, supported method or custody check is attached.

**Reasoning:** Hold U7 transfer pending the approved inspection/provenance process; report.pdf.exe is executable content despite its misleading first extension. A matching hash from the same untrusted medium does not independently establish vendor origin, and stale detection cannot prove cleanliness. B1 lacks full application and failure-domain independence. B2 has better media isolation but a key-recovery dependency. Protect/reconcile BMC export secrets. Reject D4's purge claim: empty filesystem and unsupported paperwork do not establish the required sanitisation outcome or asset custody.

#### Guided practice

Design a restore test for B2 with the live directory unavailable.

**Hint:** The encrypted copy, key and recovery software must all be usable through authorised independent paths.

**Worked solution:** Use a protected separately governed recovery-key route, verify copy provenance/consistency, restore into an isolated environment with compatible software, validate historical/current transactions and permissions, then measure total accepted-service time including key retrieval. Record any untested physical or platform assumptions.

#### Independent task

Environment: analytical

Create a transfer and disposition ledger for U7, B1/B2, the BMC export and D4.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L015.json

**Evidence to produce**

- Content/provenance decisions
- Backup dependency and restore plan
- Sanitisation hold/correction criteria

**Acceptance criteria**

- A clean scan is not treated as an origin guarantee.
- Data copy and decryption-key independence are assessed separately.
- No destructive action is performed on required data.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0141 · single · implementation**

Which fact requires treating report.pdf.exe as executable content in this fixture?

SYNTHETIC MEDIA/RECOVERY RECORD.
USB U7 arrives from a contractor with firmware.bin and report.pdf.exe. The supplied SHA-256 text is on the same USB; no trusted vendor reference has been checked. Scanner status: signatures stale, scan completed without alert.
Backup B1 is a VM snapshot on the same array; external historian database is excluded. Backup B2 is an offline application-consistent copy encrypted with K_old, whose only retrievable copy is in the live directory vault. BMC export includes a support credential.
Retirement record says SSD D4 was quick-formatted and therefore purged; no model, supported method or custody check is attached.

1. Its actual terminal extension/type is executable, despite the PDF-looking name.
2. The leading report.pdf text means the operating system will treat the file as a PDF.
3. The no-alert scan result is enough to handle the file as a passive document.
4. The supplied USB checksum identifies the file as vendor-approved firmware.

**Correct option(s):** 1

- Option 1: Content handling must not rely on a reassuring substring.
- Option 2: The final executable extension and content handling must govern the assessment.
- Option 3: Stale signatures and a no-alert result do not change executable content into a document.
- Option 4: The checksum shares the same untrusted source and concerns content equality, not approval.

**GICSP-Q0142 · single · mechanism**

What does the USB-supplied hash establish if the file matches it?

SYNTHETIC MEDIA/RECOVERY RECORD.
USB U7 arrives from a contractor with firmware.bin and report.pdf.exe. The supplied SHA-256 text is on the same USB; no trusted vendor reference has been checked. Scanner status: signatures stale, scan completed without alert.
Backup B1 is a VM snapshot on the same array; external historian database is excluded. Backup B2 is an offline application-consistent copy encrypted with K_old, whose only retrievable copy is in the live directory vault. BMC export includes a support credential.
Retirement record says SSD D4 was quick-formatted and therefore purged; no model, supported method or custody check is attached.

1. Equality to the supplied expected bytes, without independently proving trusted origin.
2. The firmware is compatible with every controller.
3. The scanner signatures are current.
4. The vendor signed the file.

**Correct option(s):** 1

- Option 1: The medium could carry both changed content and its matching hash.
- Option 2: Compatibility requires exact product/version evidence.
- Option 3: Hash comparison does not update detection data.
- Option 4: A plain digest is not a digital signature.

**GICSP-Q0143 · single · diagnosis**

What limits the no-alert scan result?

SYNTHETIC MEDIA/RECOVERY RECORD.
USB U7 arrives from a contractor with firmware.bin and report.pdf.exe. The supplied SHA-256 text is on the same USB; no trusted vendor reference has been checked. Scanner status: signatures stale, scan completed without alert.
Backup B1 is a VM snapshot on the same array; external historian database is excluded. Backup B2 is an offline application-consistent copy encrypted with K_old, whose only retrievable copy is in the live directory vault. BMC export includes a support credential.
Retirement record says SSD D4 was quick-formatted and therefore purged; no model, supported method or custody check is attached.

1. A completed scan with stale signatures establishes that the file will not exhibit harmful behaviour later.
2. Stale signatures prove the USB is infected.
3. A no-alert result makes report.pdf.exe safe to open on the engineering workstation.
4. Detection knowledge is stale and scanning is not a complete benignness/provenance proof.

**Correct option(s):** 4

- Option 1: The scan’s detection scope and current knowledge are limited.
- Option 2: They reduce confidence but do not establish infection.
- Option 3: No alert is not execution approval, especially with stale signatures and untrusted origin.
- Option 4: Tool health and scope bound the observation.

**GICSP-Q0144 · single · recovery**

Which failure is B1 specifically poorly prepared to survive?

SYNTHETIC MEDIA/RECOVERY RECORD.
USB U7 arrives from a contractor with firmware.bin and report.pdf.exe. The supplied SHA-256 text is on the same USB; no trusted vendor reference has been checked. Scanner status: signatures stale, scan completed without alert.
Backup B1 is a VM snapshot on the same array; external historian database is excluded. Backup B2 is an offline application-consistent copy encrypted with K_old, whose only retrievable copy is in the live directory vault. BMC export includes a support credential.
Retirement record says SSD D4 was quick-formatted and therefore purged; no model, supported method or custody check is attached.

1. A reversible configuration error in content actually included in the snapshot.
2. Accidental deletion of a captured file while the array and usable snapshot remain healthy.
3. Loss of the shared array together with the excluded external database dependency.
4. Loss of the workstation used only to view the backup catalogue, with catalogue and array still available.

**Correct option(s):** 3

- Option 1: That differs from a dependency omitted from the copy or loss of the shared storage itself.
- Option 2: A usable point-in-time copy can address that bounded logical-deletion case; the supplied shared-array failure removes the copy too.
- Option 3: The snapshot does not cover either full application state or independent storage survival.
- Option 4: A viewer failure does not by itself remove the stored snapshot and is not the identified shared-array weakness.

**GICSP-Q0145 · single · recovery**

Why can B2 fail restoration despite offline media?

SYNTHETIC MEDIA/RECOVERY RECORD.
USB U7 arrives from a contractor with firmware.bin and report.pdf.exe. The supplied SHA-256 text is on the same USB; no trusted vendor reference has been checked. Scanner status: signatures stale, scan completed without alert.
Backup B1 is a VM snapshot on the same array; external historian database is excluded. Backup B2 is an offline application-consistent copy encrypted with K_old, whose only retrievable copy is in the live directory vault. BMC export includes a support credential.
Retirement record says SSD D4 was quick-formatted and therefore purged; no model, supported method or custody check is attached.

1. Application consistency is impossible for offline copies.
2. The backup’s archive extension alone determines whether the directory-dependent key is available.
3. Encrypted offline media cannot be restored by any authorised operator.
4. The decryption key is available only through the unavailable live directory vault.

**Correct option(s):** 4

- Option 1: B2 is explicitly application-consistent; the problem is its key’s dependence on the unavailable directory.
- Option 2: File naming does not resolve the missing decryption dependency.
- Option 3: It can be restored if the correct key and compatible recovery process are available.
- Option 4: A usable backup includes protected key access.

**GICSP-Q0146 · single · operations**

Which secret-bearing artefact needs separate handling from the main data backup?

SYNTHETIC MEDIA/RECOVERY RECORD.
USB U7 arrives from a contractor with firmware.bin and report.pdf.exe. The supplied SHA-256 text is on the same USB; no trusted vendor reference has been checked. Scanner status: signatures stale, scan completed without alert.
Backup B1 is a VM snapshot on the same array; external historian database is excluded. Backup B2 is an offline application-consistent copy encrypted with K_old, whose only retrievable copy is in the live directory vault. BMC export includes a support credential.
Retirement record says SSD D4 was quick-formatted and therefore purged; no model, supported method or custody check is attached.

1. The BMC export containing a support credential.
2. The scanner's window title.
3. The generic public firmware manual.
4. Only the USB's physical label.

**Correct option(s):** 1

- Option 1: Management backups can carry authority outside application data.
- Option 2: Presentation is not the sensitive artefact here.
- Option 3: Public documentation is not the recorded credential source.
- Option 4: A label is not the supplied secret-bearing content.

**GICSP-Q0147 · single · design**

Why is the D4 purge claim unsupported?

SYNTHETIC MEDIA/RECOVERY RECORD.
USB U7 arrives from a contractor with firmware.bin and report.pdf.exe. The supplied SHA-256 text is on the same USB; no trusted vendor reference has been checked. Scanner status: signatures stale, scan completed without alert.
Backup B1 is a VM snapshot on the same array; external historian database is excluded. Backup B2 is an offline application-consistent copy encrypted with K_old, whose only retrievable copy is in the live directory vault. BMC export includes a support credential.
Retirement record says SSD D4 was quick-formatted and therefore purged; no model, supported method or custody check is attached.

1. Device custody can be omitted once the filesystem appears empty.
2. A quick format is equivalent to validated purge on this SSD model.
3. The user-visible empty filesystem demonstrates all prior flash pages are unrecoverable.
4. Quick format and missing device/method evidence do not establish the required sanitisation outcome.

**Correct option(s):** 4

- Option 1: Sanitisation evidence includes the actual device and handling scope, not just an empty directory view.
- Option 2: The record lacks a supported method, model and verification evidence for that claim.
- Option 3: Logical emptiness does not establish sanitisation of underlying storage.
- Option 4: Filesystem appearance is narrower than verified media treatment.

**GICSP-Q0148 · multi · implementation**

Which prerequisites matter before accepting cryptographic erase? Select all that apply.

SYNTHETIC MEDIA/RECOVERY RECORD.
USB U7 arrives from a contractor with firmware.bin and report.pdf.exe. The supplied SHA-256 text is on the same USB; no trusted vendor reference has been checked. Scanner status: signatures stale, scan completed without alert.
Backup B1 is a VM snapshot on the same array; external historian database is excluded. Backup B2 is an offline application-consistent copy encrypted with K_old, whose only retrievable copy is in the live directory vault. BMC export includes a support credential.
Retirement record says SSD D4 was quick-formatted and therefore purged; no model, supported method or custody check is attached.

1. Relevant data were protected by suitable encryption under the required assumptions.
2. Usable relevant key copies are handled according to the approved method.
3. Only the user password was changed.
4. The actual device/implementation and disposition requirement are identified.

**Correct option(s):** 1, 2, 4

- Option 1: Unencrypted remnants are not solved by deleting unrelated keys.
- Option 2: Surviving keys can defeat the intended outcome.
- Option 3: A login password is not necessarily the media key.
- Option 4: Method suitability is configuration-specific.

**GICSP-Q0149 · single · operations**

A contractor asks to plug U7 into PLC1 to identify its owner. What is the better first step?

SYNTHETIC MEDIA/RECOVERY RECORD.
USB U7 arrives from a contractor with firmware.bin and report.pdf.exe. The supplied SHA-256 text is on the same USB; no trusted vendor reference has been checked. Scanner status: signatures stale, scan completed without alert.
Backup B1 is a VM snapshot on the same array; external historian database is excluded. Backup B2 is an offline application-consistent copy encrypted with K_old, whose only retrievable copy is in the live directory vault. BMC export includes a support credential.
Retirement record says SSD D4 was quick-formatted and therefore purged; no model, supported method or custody check is attached.

1. Use the approved controlled receiving/inspection process without connecting unexplained media to the operational target.
2. Connect it because the PLC is not Internet-facing.
3. Assume the media label proves every file's origin.
4. Enable automatic execution to inspect it faster.

**Correct option(s):** 1

- Option 1: Identification does not justify crossing the process boundary.
- Option 2: Removable media is itself a transfer path.
- Option 3: Custody and content provenance are distinct.
- Option 4: That can execute unreviewed content.

**GICSP-Q0150 · single · recovery**

Which restore test best demonstrates B2's intended recovery value?

SYNTHETIC MEDIA/RECOVERY RECORD.
USB U7 arrives from a contractor with firmware.bin and report.pdf.exe. The supplied SHA-256 text is on the same USB; no trusted vendor reference has been checked. Scanner status: signatures stale, scan completed without alert.
Backup B1 is a VM snapshot on the same array; external historian database is excluded. Backup B2 is an offline application-consistent copy encrypted with K_old, whose only retrievable copy is in the live directory vault. BMC export includes a support credential.
Retirement record says SSD D4 was quick-formatted and therefore purged; no model, supported method or custody check is attached.

1. Only the backup job's success status.
2. An isolated application-consistent restore with independent key access and verified history/current transactions/authority.
3. A successful file listing of the encrypted backup.
4. A checksum of the encrypted backup without demonstrating access to K_old.

**Correct option(s):** 2

- Option 1: Creation is different from restoration.
- Option 2: It exercises the declared failure and complete service.
- Option 3: Listing does not decrypt or restore the application.
- Option 4: Content integrity alone does not establish decryptability during the directory outage.

#### Recall

**Why is offline backup media not enough?**

Recovery also needs compatible software, trustworthy data, independently usable keys/identities and a tested application method.

**Why does a quick format not establish purge?**

It changes filesystem structures without proving the required treatment of all relevant media locations or keys.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [NIST SP 800-88 Rev. 2: media sanitization](https://csrc.nist.gov/pubs/sp/800/88/r2/final)

## GICSP-M04 — Programme governance and enforceable policy

### GICSP-L016 — Programme scope, accountability and risk ownership

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L015

### A programme is a sustained decision system
A cybersecurity programme connects business/process requirements to accountable implementation and continuing assurance. Begin with the industrial functions and consequences, the organisational and technical boundary, asset owners, operational dependencies and applicable obligations. An enterprise policy can supply common requirements, but the OT implementation needs its actual process modes, lifecycle, vendor constraints and work authority. A programme that names tools without accountable owners or maintenance resources cannot reliably sustain the intended protection.

A charter should state purpose, scope, decision rights, executive sponsorship, responsible roles, coordination with operations/safety, resource commitments and reporting. Define how risk is identified, treated, accepted and revisited. The engineer supplies evidence and options; the accountable owner accepts residual risk within delegated authority. A project manager's deadline or a supplier's reassurance does not automatically authorise that acceptance. Record who can approve which level of consequence and when escalation is required.

### Inventory the control obligation, not only the equipment
For each important requirement identify its owner, implementation, verification method, operating frequency and evidence location. For example, remote-access expiry needs identity configuration, session handling, an accountable work owner and a test of effective revocation. Buying an MFA gateway does not complete that obligation. Backup readiness needs restore methods, protected keys, compatible software, trained people and measured recovery. A line in a budget is not an implemented control.

Prioritise by consequence, exposure and dependencies. A small shared identity service can affect many otherwise isolated systems. A high-severity vulnerability on a decommissioned unreachable lab device can have a different urgency from a moderately rated issue on an exposed operational administration path. Use a documented method and avoid false numerical precision when likelihood data are weak. Urgent treatment can proceed while uncertainty is investigated, provided the decision and operating constraints remain explicit.

### Fund the lifecycle
Programme resources include engineering time, supported licences, training, lab access, spare/recovery capability, monitoring, review and maintenance windows. A one-time installation budget can leave no capacity to renew certificates or test restoration. Assign recurring tasks and their triggers: staff changes, new assets, vendor end-of-support notices, incidents, process changes and model/configuration drift. A backlog entry needs consequence, owner, due date, compensating measures and escalation rules.

### Measure implementation and outcome
Distinguish a policy approved, a control deployed, a control operating and an outcome verified. These are different milestones. Use evidence that can reveal failure: sampled revocation tests, restoration trials, supported configuration checks and investigated detection misses. Report residual gaps alongside achievements. A dashboard that counts purchased licences or completed training alone cannot show that the required service remains secure and recoverable.

The independent course task is to produce a reviewable charter and control register for a bounded installation. It does not require inventing a complete corporate compliance framework. Keep the near-term D4–D7 scope and specialist interface owners explicit, while integrating security through design, implementation, commissioning, operations, maintenance, optimisation, troubleshooting, incident response and recovery.

#### Worked demonstrations

**Evidence walkthrough**

SYNTHETIC PROGRAMME PROPOSAL.
Scope statement: “All devices connected to VLAN 60.” Missing from scope: serial meters behind a gateway, contractor support identities and offline recovery keys. Sponsor approves a one-time firewall purchase, but no owner or budget exists for rule review, certificate renewal or restore testing. Engineer E records a residual risk affecting a required alarm service; project manager P marks it accepted to meet Friday’s launch. The organisation’s supplied authority matrix assigns that risk decision to service owner O. Monthly report counts 200 purchased licences as 200 effective controls.

**Reasoning:** The VLAN definition omits relevant non-IP assets and authority/recovery dependencies. Expand scope from required functions and flows. Assign sustained control owners/resources rather than treating procurement as operation. P’s launch decision does not satisfy O’s delegated risk-acceptance authority; escalate the specific consequence and options. Licence count is a procurement metric, not an effectiveness result. Report deployed/healthy/verified control states and open gaps with denominators and evidence.

#### Guided practice

Draft a charter paragraph that fixes the boundary without claiming ownership of every facility discipline.

**Hint:** Scope the functions, dependencies and responsible interfaces.

**Worked solution:** Include the OT/network/hardware/security services, downstream devices, remote identities and recovery materials; identify operations/safety/power/cooling interface owners; name O’s risk authority and recurring control duties; preserve D1 exclusion and later D2/D3 development boundaries.

#### Independent task

Environment: analytical

Turn the proposal into a charter and five-row accountable control register.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L016.json

**Evidence to produce**

- Scope/dependency statement
- Decision-rights table
- Funded recurring duties
- Evidence-based status report

**Acceptance criteria**

- Risk acceptance follows the supplied authority matrix.
- Non-IP and identity/recovery dependencies are included.
- Procurement status is distinct from verified control operation.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0151 · single · design**

Why is “VLAN 60” an incomplete programme boundary?

SYNTHETIC PROGRAMME PROPOSAL.
Scope statement: “All devices connected to VLAN 60.” Missing from scope: serial meters behind a gateway, contractor support identities and offline recovery keys. Sponsor approves a one-time firewall purchase, but no owner or budget exists for rule review, certificate renewal or restore testing. Engineer E records a residual risk affecting a required alarm service; project manager P marks it accepted to meet Friday’s launch. The organisation’s supplied authority matrix assigns that risk decision to service owner O. Monthly report counts 200 purchased licences as 200 effective controls.

1. Required serial, identity and recovery dependencies extend beyond that IP segment.
2. VLAN membership is sufficient because serial meters inherit their gateway’s complete security scope automatically.
3. Contractor identities and offline keys belong only to corporate IT and can be excluded from the alarm-service programme.
4. The boundary should expand to every nearby facility system without assigning an interface or authority owner.

**Correct option(s):** 1

- Option 1: Scope should follow functions and consequences.
- Option 2: The meters and their mappings still need explicit scope and lifecycle responsibility.
- Option 3: Those dependencies directly affect the operational service and recovery.
- Option 4: Scope follows declared service dependencies and responsibility, not proximity alone.

**GICSP-Q0152 · single · operations**

Who may accept the stated residual alarm-service risk under the supplied matrix?

SYNTHETIC PROGRAMME PROPOSAL.
Scope statement: “All devices connected to VLAN 60.” Missing from scope: serial meters behind a gateway, contractor support identities and offline recovery keys. Sponsor approves a one-time firewall purchase, but no owner or budget exists for rule review, certificate renewal or restore testing. Engineer E records a residual risk affecting a required alarm service; project manager P marks it accepted to meet Friday’s launch. The organisation’s supplied authority matrix assigns that risk decision to service owner O. Monthly report counts 200 purchased licences as 200 effective controls.

1. P solely because launch is Friday
2. E solely because E discovered it
3. The firewall reseller
4. O

**Correct option(s):** 4

- Option 1: Schedule ownership does not expand delegated risk authority.
- Option 2: Technical analysis is not automatically acceptance authority.
- Option 3: Product knowledge does not confer organisational risk ownership.
- Option 4: The matrix assigns that decision to the service owner.

**GICSP-Q0153 · single · design**

Which missing resource threatens sustained firewall effectiveness?

SYNTHETIC PROGRAMME PROPOSAL.
Scope statement: “All devices connected to VLAN 60.” Missing from scope: serial meters behind a gateway, contractor support identities and offline recovery keys. Sponsor approves a one-time firewall purchase, but no owner or budget exists for rule review, certificate renewal or restore testing. Engineer E records a residual risk affecting a required alarm service; project manager P marks it accepted to meet Friday’s launch. The organisation’s supplied authority matrix assigns that risk decision to service owner O. Monthly report counts 200 purchased licences as 200 effective controls.

1. A permanent freeze on every rule change.
2. An accountable recurring rule-review and maintenance process.
3. A larger initial rule set with no ongoing owner.
4. A one-time successful ping across the firewall.

**Correct option(s):** 2

- Option 1: Freezing configuration does not address changing service needs, vulnerabilities or credential dependencies.
- Option 2: Installed policy can drift or retain obsolete access.
- Option 3: More rules do not provide the review, renewal and maintenance duty missing from the programme.
- Option 4: Reachability at one moment does not establish sustained rule correctness or lifecycle maintenance.

**GICSP-Q0154 · single · mechanism**

What does the count of 200 purchased licences establish?

SYNTHETIC PROGRAMME PROPOSAL.
Scope statement: “All devices connected to VLAN 60.” Missing from scope: serial meters behind a gateway, contractor support identities and offline recovery keys. Sponsor approves a one-time firewall purchase, but no owner or budget exists for rule review, certificate renewal or restore testing. Engineer E records a residual risk affecting a required alarm service; project manager P marks it accepted to meet Friday’s launch. The organisation’s supplied authority matrix assigns that risk decision to service owner O. Monthly report counts 200 purchased licences as 200 effective controls.

1. Zero residual risk
2. All assets are in the programme scope
3. Procurement quantity only.
4. Two hundred independently verified controls

**Correct option(s):** 3

- Option 1: Counts cannot establish universal risk elimination.
- Option 2: Scope requires asset/function reconciliation.
- Option 3: Deployment, health and tested effect remain separate.
- Option 4: A licence is not a behavioural test.

**GICSP-Q0155 · multi · operations**

Which fields make a backlog exception governable? Select all that apply.

SYNTHETIC PROGRAMME PROPOSAL.
Scope statement: “All devices connected to VLAN 60.” Missing from scope: serial meters behind a gateway, contractor support identities and offline recovery keys. Sponsor approves a one-time firewall purchase, but no owner or budget exists for rule review, certificate renewal or restore testing. Engineer E records a residual risk affecting a required alarm service; project manager P marks it accepted to meet Friday’s launch. The organisation’s supplied authority matrix assigns that risk decision to service owner O. Monthly report counts 200 purchased licences as 200 effective controls.

1. An indefinite accepted label with no authority
2. Owner, deadline and escalation trigger
3. The evidence and acceptance criterion still missing
4. Consequence and compensating measures

**Correct option(s):** 2, 3, 4

- Option 1: That conceals an unresolved obligation.
- Option 2: They support accountable resolution.
- Option 3: They define what will close the gap.
- Option 4: They explain exposure while the gap remains.

**GICSP-Q0156 · single · operations**

A certificate renewal has no assigned owner. Which lifecycle gap is most direct?

SYNTHETIC PROGRAMME PROPOSAL.
Scope statement: “All devices connected to VLAN 60.” Missing from scope: serial meters behind a gateway, contractor support identities and offline recovery keys. Sponsor approves a one-time firewall purchase, but no owner or budget exists for rule review, certificate renewal or restore testing. Engineer E records a residual risk affecting a required alarm service; project manager P marks it accepted to meet Friday’s launch. The organisation’s supplied authority matrix assigns that risk decision to service owner O. Monthly report counts 200 purchased licences as 200 effective controls.

1. Only physical rack installation
2. Continuing identity/service maintenance.
3. Only initial procurement
4. No gap if the first login worked

**Correct option(s):** 2

- Option 1: The problem concerns ongoing identity operation.
- Option 2: An initially valid certificate can later expire and break trust or availability.
- Option 3: Purchase does not sustain validity.
- Option 4: Initial success does not prove future renewal.

**GICSP-Q0157 · single · design**

Which report best distinguishes programme milestones?

SYNTHETIC PROGRAMME PROPOSAL.
Scope statement: “All devices connected to VLAN 60.” Missing from scope: serial meters behind a gateway, contractor support identities and offline recovery keys. Sponsor approves a one-time firewall purchase, but no owner or budget exists for rule review, certificate renewal or restore testing. Engineer E records a residual risk affecting a required alarm service; project manager P marks it accepted to meet Friday’s launch. The organisation’s supplied authority matrix assigns that risk decision to service owner O. Monthly report counts 200 purchased licences as 200 effective controls.

1. Approved requirement, deployed configuration, observed operation and tested outcome are separate states.
2. Every policy document is marked implemented immediately.
3. Only successful tests are retained.
4. Every training completion is counted as successful recovery.

**Correct option(s):** 1

- Option 1: Each answers a different assurance question.
- Option 2: Approval does not apply controls.
- Option 3: Failures and limitations are needed for honest status.
- Option 4: Knowledge does not demonstrate restoration.

**GICSP-Q0158 · single · mechanism**

Why can a small shared identity service deserve high priority?

SYNTHETIC PROGRAMME PROPOSAL.
Scope statement: “All devices connected to VLAN 60.” Missing from scope: serial meters behind a gateway, contractor support identities and offline recovery keys. Sponsor approves a one-time firewall purchase, but no owner or budget exists for rule review, certificate renewal or restore testing. Engineer E records a residual risk affecting a required alarm service; project manager P marks it accepted to meet Friday’s launch. The organisation’s supplied authority matrix assigns that risk decision to service owner O. Monthly report counts 200 purchased licences as 200 effective controls.

1. Only hardware price determines importance.
2. Its failure or compromise can affect many dependent systems.
3. Small servers are inherently less secure.
4. Identity services cannot be backed up.

**Correct option(s):** 2

- Option 1: Service impact and exposure govern priority.
- Option 2: Dependency consequence is not proportional to server count.
- Option 3: Size alone is not a security property.
- Option 4: Appropriate recovery can be engineered.

**GICSP-Q0159 · single · operations**

What should E provide to O for the decision?

SYNTHETIC PROGRAMME PROPOSAL.
Scope statement: “All devices connected to VLAN 60.” Missing from scope: serial meters behind a gateway, contractor support identities and offline recovery keys. Sponsor approves a one-time firewall purchase, but no owner or budget exists for rule review, certificate renewal or restore testing. Engineer E records a residual risk affecting a required alarm service; project manager P marks it accepted to meet Friday’s launch. The organisation’s supplied authority matrix assigns that risk decision to service owner O. Monthly report counts 200 purchased licences as 200 effective controls.

1. A product warranty in place of the engineering risk and acceptance evidence.
2. The Friday date and purchase approval without the authority matrix.
3. The launch risk rating without the affected service or residual capability.
4. Specific consequence, supporting evidence, treatment options, constraints and residual uncertainty.

**Correct option(s):** 4

- Option 1: A warranty does not establish that this alarm-service residual risk is acceptable.
- Option 2: Schedule and procurement approval do not transfer the risk decision from O.
- Option 3: The owner needs the concrete consequence, alternatives and remaining exposure.
- Option 4: The owner needs a reviewable engineering basis.

**GICSP-Q0160 · single · operations**

Which event should trigger review of the programme's operating assumptions?

SYNTHETIC PROGRAMME PROPOSAL.
Scope statement: “All devices connected to VLAN 60.” Missing from scope: serial meters behind a gateway, contractor support identities and offline recovery keys. Sponsor approves a one-time firewall purchase, but no owner or budget exists for rule review, certificate renewal or restore testing. Engineer E records a residual risk affecting a required alarm service; project manager P marks it accepted to meet Friday’s launch. The organisation’s supplied authority matrix assigns that risk decision to service owner O. Monthly report counts 200 purchased licences as 200 effective controls.

1. Training attendance alone, without a changed role, asset or service dependency.
2. No event until an incident occurs
3. A document reformat that leaves scope, dependencies and control behaviour unchanged.
4. A vendor ends support for a required platform.

**Correct option(s):** 4

- Option 1: Attendance does not itself demonstrate a changed operational assumption.
- Option 2: Proactive lifecycle triggers are necessary.
- Option 3: That is not a material change to the programme’s operating assumptions.
- Option 4: Treatment, spares, recovery and migration assumptions may change.

#### Recall

**What does an OT programme charter establish?**

Scope, purpose, accountable decision rights, coordination, resources and continuing assurance obligations.

**Why is a licence count not control effectiveness?**

Procurement, deployment, healthy operation and verified outcomes are distinct evidence states.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

### GICSP-L017 — Policy, standards, procedures and bounded exceptions

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L016

### Give each document a distinct job
A policy states required organisational intent and accountability. A supporting standard can define mandatory implementation expectations within that authority. A procedure specifies an authorised repeatable action. A guideline assists judgment where variation is permitted. Organisations use names differently, so the important properties are scope, authority, version, owner and required behaviour. A document titled standard is not automatically a law, and a vendor recommendation does not automatically override the organisation’s approved requirement.

Translate broad intent into measurable outcomes. “Vendor access is controlled” needs approved purpose, identity, target, operation, duration, logging, removal and verification. “Backups are maintained” needs protected scope, consistency, retention, custody, restoration and recovery objectives. A procedure should identify the actual system and supported method, preconditions, stop conditions and acceptance evidence. Link the procedure to its governing requirement so changes can be assessed for their consequences.

### Establish applicable obligations carefully
Maintain an obligations register with jurisdiction, contract, source/version, relevant system/data, accountable specialist and required action. Privacy, breach reporting, safety, employment and record-retention obligations can vary. Do not import a convenient deadline from another jurisdiction or assume all standards are mandatory everywhere. Qualified organisational/legal/safety owners validate applicability; the engineer implements and verifies the approved requirement. This course teaches the process, not a universal legal schedule.

### An exception is a controlled departure
An exception should identify exactly what requirement cannot presently be met, why, which assets/modes are affected, the consequence, compensating measures, owner, approving authority, expiry and closure evidence. A compensating control must address the relevant failure or attack path. More logging may improve detection but does not directly prevent an unauthorised write. Reduced network exposure may help while a patch is staged, but its effect must be tested and its limits stated.

The exception must also preserve required operational function. An account lockout rule can restrict repeated guessing yet affect unattended service accounts. An emergency-access route may be needed during directory loss but should not silently become ordinary permanent administration. Test the actual trade-off and supported implementation. If the proposed exception changes a mandatory external obligation, the authorised owner must resolve that issue; an internal ticket alone cannot waive it.

### Enforce and review
Technical enforcement, workflow and evidence should agree. A ticket expiry without session termination may leave authority active. A policy requiring quarterly review needs a defined population, reviewer competence, evidence and action on findings. Track exceptions through expiry and retest closure. Report overdue items and unverified compensating measures as open, rather than automatically renewing them to keep a dashboard green.

When updating a document, preserve previous versions and the reason for change. Review dependent configurations, teaching, runbooks and tests. A new procedure that references an old device model can create an implementation defect despite a formally approved cover page. The programme's acceptance contract requires that a competent person can use the current procedure and demonstrate the required result in the stated environment.

#### Worked demonstrations

**Evidence walkthrough**

SYNTHETIC POLICY EXCERPTS.
P-12: vendor administration requires named approval, least privilege and removal within 10 minutes after the work window.
STD-12 v3: supports individual identities, MFA at entry, target/operation restriction, session revocation test and retained audit evidence.
SOP-12 v1 still references an obsolete VPN with no session-termination step.
EX-9 requests a shared local controller account for 30 days while a supported upgrade is staged; it proposes jump-host attribution, restricted target/read operations, daily review and owner O. Approval is pending. A manager suggests “extra logs replace the read-only requirement.” A separate draft assigns a 72-hour legal reporting deadline without identifying any jurisdiction or obligation source.

**Reasoning:** The SOP is inconsistent with the current standard and needs an effective session-removal step plus tests. EX-9 is a proposed bounded exception, not approved authority; evaluate whether the listed measures actually constrain operations and provide sufficient attribution. Extra logs can support detection/accountability but do not enforce read-only action. The legal deadline is ungrounded until the applicable source and qualified owner validate it. Preserve the original requirements and evidence, then verify the revised procedure on the supported platform.

#### Guided practice

Define evidence that would close EX-9 at expiry.

**Hint:** Closure must show the required replacement capability works and temporary authority is removed.

**Worked solution:** Demonstrate the supported upgraded individual-identity/operation controls, permitted diagnostics and forbidden writes, removal of the shared temporary path and existing sessions, retained audit correlation, and updated SOP/training. Record any unmet criterion rather than auto-extending the exception.

#### Independent task

Environment: analytical

Review P-12/STD-12/SOP-12/EX-9 and produce a conflict/closure register.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L017.json

**Evidence to produce**

- Document authority/version map
- Exception treatment analysis
- Revocation and expiry tests
- Obligations-source question

**Acceptance criteria**

- Pending approval is not treated as permission.
- Detection is not equated with prevention.
- No legal deadline is asserted without applicable authority.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0161 · single · implementation**

What is the concrete SOP-12 gap against STD-12 v3?

SYNTHETIC POLICY EXCERPTS.
P-12: vendor administration requires named approval, least privilege and removal within 10 minutes after the work window.
STD-12 v3: supports individual identities, MFA at entry, target/operation restriction, session revocation test and retained audit evidence.
SOP-12 v1 still references an obsolete VPN with no session-termination step.
EX-9 requests a shared local controller account for 30 days while a supported upgrade is staged; it proposes jump-host attribution, restricted target/read operations, daily review and owner O. Approval is pending. A manager suggests “extra logs replace the read-only requirement.” A separate draft assigns a 72-hour legal reporting deadline without identifying any jurisdiction or obligation source.

1. The obsolete VPN reference is harmless if a new login is denied after the window.
2. The procedure is invalid merely because its revision number is lower than the standard’s.
3. The procedure may omit session termination because the policy already states the desired outcome.
4. It lacks the current session-termination/verification step on the supported platform.

**Correct option(s):** 4

- Option 1: The standard also requires removal of existing session authority and its verification.
- Option 2: Revision numbers belong to separate artefacts; the missing revocation step is the substantive conflict.
- Option 3: Executable steps and acceptance evidence are needed to implement the policy requirement.
- Option 4: Procedure content must implement the governing requirement.

**GICSP-Q0162 · single · operations**

What authority does EX-9 have while approval is pending?

SYNTHETIC POLICY EXCERPTS.
P-12: vendor administration requires named approval, least privilege and removal within 10 minutes after the work window.
STD-12 v3: supports individual identities, MFA at entry, target/operation restriction, session revocation test and retained audit evidence.
SOP-12 v1 still references an obsolete VPN with no session-termination step.
EX-9 requests a shared local controller account for 30 days while a supported upgrade is staged; it proposes jump-host attribution, restricted target/read operations, daily review and owner O. Approval is pending. A manager suggests “extra logs replace the read-only requirement.” A separate draft assigns a 72-hour legal reporting deadline without identifying any jurisdiction or obligation source.

1. The vendor may approve it for the organisation.
2. It remains a proposed departure, not permission to use the shared route.
3. It is automatically approved because it lasts 30 days.
4. It permanently replaces STD-12.

**Correct option(s):** 2

- Option 1: No such delegation is supplied.
- Option 2: Required acceptance has not occurred.
- Option 3: Duration alone does not grant authority.
- Option 4: An exception does not silently rewrite the standard.

**GICSP-Q0163 · single · mechanism**

Why do extra logs not replace a read-only requirement?

SYNTHETIC POLICY EXCERPTS.
P-12: vendor administration requires named approval, least privilege and removal within 10 minutes after the work window.
STD-12 v3: supports individual identities, MFA at entry, target/operation restriction, session revocation test and retained audit evidence.
SOP-12 v1 still references an obsolete VPN with no session-termination step.
EX-9 requests a shared local controller account for 30 days while a supported upgrade is staged; it proposes jump-host attribution, restricted target/read operations, daily review and owner O. Approval is pending. A manager suggests “extra logs replace the read-only requirement.” A separate draft assigns a 72-hour legal reporting deadline without identifying any jurisdiction or obligation source.

1. Every log automatically rolls back commands.
2. Logs have no security value.
3. Logging observes activity but does not necessarily prevent a write.
4. Read-only can be enforced by renaming an account.

**Correct option(s):** 3

- Option 1: No such capability is specified.
- Option 2: They can support investigation and attribution.
- Option 3: Detection/accountability and preventive authority are distinct.
- Option 4: Effective permissions must implement it.

**GICSP-Q0164 · single · design**

Which statement about the drafted 72-hour reporting deadline is defensible?

SYNTHETIC POLICY EXCERPTS.
P-12: vendor administration requires named approval, least privilege and removal within 10 minutes after the work window.
STD-12 v3: supports individual identities, MFA at entry, target/operation restriction, session revocation test and retained audit evidence.
SOP-12 v1 still references an obsolete VPN with no session-termination step.
EX-9 requests a shared local controller account for 30 days while a supported upgrade is staged; it proposes jump-host attribution, restricted target/read operations, daily review and owner O. Approval is pending. A manager suggests “extra logs replace the read-only requirement.” A separate draft assigns a 72-hour legal reporting deadline without identifying any jurisdiction or obligation source.

1. An engineer may waive any deadline with an internal ticket.
2. It applies universally to every industrial incident.
3. No organisation ever has reporting duties.
4. Its applicability is unresolved until the jurisdiction/source and accountable specialist validate it.

**Correct option(s):** 4

- Option 1: Internal workflow does not automatically override external duties.
- Option 2: Reporting requirements vary.
- Option 3: Applicable obligations may exist.
- Option 4: A copied number is not an obligations analysis.

**GICSP-Q0165 · multi · design**

Which EX-9 details support a bounded review? Select all that apply.

SYNTHETIC POLICY EXCERPTS.
P-12: vendor administration requires named approval, least privilege and removal within 10 minutes after the work window.
STD-12 v3: supports individual identities, MFA at entry, target/operation restriction, session revocation test and retained audit evidence.
SOP-12 v1 still references an obsolete VPN with no session-termination step.
EX-9 requests a shared local controller account for 30 days while a supported upgrade is staged; it proposes jump-host attribution, restricted target/read operations, daily review and owner O. Approval is pending. A manager suggests “extra logs replace the read-only requirement.” A separate draft assigns a 72-hour legal reporting deadline without identifying any jurisdiction or obligation source.

1. A claim that the shared account becomes individually attributable by its username alone
2. Specific target/operation limits and daily review
3. Defined 30-day duration and owner
4. The supported upgrade plan

**Correct option(s):** 2, 3, 4

- Option 1: Shared identity alone cannot identify the person.
- Option 2: These can be evaluated against the affected risk.
- Option 3: They establish accountability and a review endpoint.
- Option 4: It gives a concrete route toward closing the departure.

**GICSP-Q0166 · single · calculation**

A ticket ends at 16:00 but an existing session still writes at 16:20. Which requirement fails?

SYNTHETIC POLICY EXCERPTS.
P-12: vendor administration requires named approval, least privilege and removal within 10 minutes after the work window.
STD-12 v3: supports individual identities, MFA at entry, target/operation restriction, session revocation test and retained audit evidence.
SOP-12 v1 still references an obsolete VPN with no session-termination step.
EX-9 requests a shared local controller account for 30 days while a supported upgrade is staged; it proposes jump-host attribution, restricted target/read operations, daily review and owner O. Approval is pending. A manager suggests “extra logs replace the read-only requirement.” A separate draft assigns a 72-hour legal reporting deadline without identifying any jurisdiction or obligation source.

1. No requirement, because the session began earlier.
2. P-12's effective removal within ten minutes.
3. Only the document-retention requirement.
4. MFA must have failed at login.

**Correct option(s):** 2

- Option 1: The supplied removal rule concerns effective authority after the window.
- Option 2: Administrative closure did not remove authority within the allowed interval.
- Option 3: The observed defect is continuing write authority.
- Option 4: Initial MFA can succeed while later revocation fails.

**GICSP-Q0167 · single · design**

Which fact would make a proposed compensating control unconvincing?

SYNTHETIC POLICY EXCERPTS.
P-12: vendor administration requires named approval, least privilege and removal within 10 minutes after the work window.
STD-12 v3: supports individual identities, MFA at entry, target/operation restriction, session revocation test and retained audit evidence.
SOP-12 v1 still references an obsolete VPN with no session-termination step.
EX-9 requests a shared local controller account for 30 days while a supported upgrade is staged; it proposes jump-host attribution, restricted target/read operations, daily review and owner O. Approval is pending. A manager suggests “extra logs replace the read-only requirement.” A separate draft assigns a 72-hour legal reporting deadline without identifying any jurisdiction or obligation source.

1. It has an owner.
2. It requires verification.
3. It does not address the attack/failure path created by the exception.
4. It is different from the original control.

**Correct option(s):** 3

- Option 1: Accountability is appropriate.
- Option 2: Testing strengthens the evidence.
- Option 3: A control must reduce the relevant consequence or exposure.
- Option 4: Compensation can use a different mechanism if justified.

**GICSP-Q0168 · single · operations**

How should a recurring overdue exception be reported?

SYNTHETIC POLICY EXCERPTS.
P-12: vendor administration requires named approval, least privilege and removal within 10 minutes after the work window.
STD-12 v3: supports individual identities, MFA at entry, target/operation restriction, session revocation test and retained audit evidence.
SOP-12 v1 still references an obsolete VPN with no session-termination step.
EX-9 requests a shared local controller account for 30 days while a supported upgrade is staged; it proposes jump-host attribution, restricted target/read operations, daily review and owner O. Approval is pending. A manager suggests “extra logs replace the read-only requirement.” A separate draft assigns a 72-hour legal reporting deadline without identifying any jurisdiction or obligation source.

1. As closed because it appeared in a previous report.
2. As an open overdue obligation with consequence, owner and escalation, unless a new authorised decision is made.
3. As a permanent policy change without review.
4. As risk-free because no incident was observed.

**Correct option(s):** 2

- Option 1: Reporting is not remediation.
- Option 2: Automatic renewal would hide unresolved exposure.
- Option 3: That exceeds exception governance.
- Option 4: Absence of observed incidents does not eliminate exposure.

**GICSP-Q0169 · single · implementation**

What should change with an updated SOP beyond its cover-page version?

SYNTHETIC POLICY EXCERPTS.
P-12: vendor administration requires named approval, least privilege and removal within 10 minutes after the work window.
STD-12 v3: supports individual identities, MFA at entry, target/operation restriction, session revocation test and retained audit evidence.
SOP-12 v1 still references an obsolete VPN with no session-termination step.
EX-9 requests a shared local controller account for 30 days while a supported upgrade is staged; it proposes jump-host attribution, restricted target/read operations, daily review and owner O. Approval is pending. A manager suggests “extra logs replace the read-only requirement.” A separate draft assigns a 72-hour legal reporting deadline without identifying any jurisdiction or obligation source.

1. Only the document-control register, leaving the executable steps and training unchanged.
2. Nothing if the document is signed.
3. All previous evidence must be deleted.
4. Dependent configuration, training and acceptance tests must be reconciled with the new method.

**Correct option(s):** 4

- Option 1: Register updates do not reconcile the people, configuration and tests that implement the method.
- Option 2: A signature does not apply or validate the method.
- Option 3: History explains decisions and revisions.
- Option 4: Documentation and implementation need to agree.

**GICSP-Q0170 · single · operations**

What demonstrates that the revised procedure is usable?

SYNTHETIC POLICY EXCERPTS.
P-12: vendor administration requires named approval, least privilege and removal within 10 minutes after the work window.
STD-12 v3: supports individual identities, MFA at entry, target/operation restriction, session revocation test and retained audit evidence.
SOP-12 v1 still references an obsolete VPN with no session-termination step.
EX-9 requests a shared local controller account for 30 days while a supported upgrade is staged; it proposes jump-host attribution, restricted target/read operations, daily review and owner O. Approval is pending. A manager suggests “extra logs replace the read-only requirement.” A separate draft assigns a 72-hour legal reporting deadline without identifying any jurisdiction or obligation source.

1. A competent authorised operator performs the bounded task and required verification using it.
2. A supplier promise that similar procedures work.
3. Only a grammatical review.
4. A desktop review that checks all step numbers but does not exercise the task or verification.

**Correct option(s):** 1

- Option 1: The result tests the intended operational use.
- Option 2: This method and platform need relevant evidence.
- Option 3: Clear language helps but does not prove technical completeness.
- Option 4: Structural review can help, but operational usability needs a representative performance of the method.

#### Recall

**Policy versus procedure?**

Policy sets authorised intent; a procedure describes the repeatable implementation and verification for a defined task.

**What makes a compensating control relevant?**

It addresses the specific exposure/consequence, is supported and measurable, and retains owner, expiry and residual limits.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

### GICSP-L018 — Procurement, supplier evidence and sustained support

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L017

Procurement determines future defensive options. A specification that asks for a “secure gateway” leaves the supplier free to interpret security as a password screen. Start with the required function and consequence, then specify observable behaviour: supported authentication, role boundaries, audit fields, update verification, recovery method, time synchronisation, exported configuration and failure behaviour. Requirements need an owner and acceptance method. Some are document checks; others need witnessed demonstrations on the proposed hardware and firmware combination. A marketing statement is evidence of a claim, not evidence that the delivered unit meets it.

A bill of materials identifies components and versions for vulnerability and lifecycle decisions. It does not establish that each component is vulnerable, reachable, exploitable or malicious. An SBOM may include libraries compiled out of the delivered feature set; an omitted dependency may still matter. Record product edition, firmware, enabled features, dependency relationship, provenance and update date. Combine component information with supplier advisories and the actual deployment. Keep the delivered baseline linked to its later maintenance history; a commissioning SBOM becomes stale when an update changes dependencies.

A digital signature can authenticate an update origin when the signing identity and trust chain are validated. It does not prove the update has no defects, or that the signing infrastructure was never compromised. A hash retrieved from the same untrusted download location provides an integrity comparison but weak independent provenance. Obtain releases through approved channels, verify against a trusted source, preserve verification results, and test functional compatibility. Evaluate secure boot, recovery and rollback separately: a device may verify updates yet have no supported rollback after a schema conversion.

Support agreements should state security contact routes, vulnerability reporting, update delivery, support dates and escalation arrangements. “Ten-year hardware life” does not necessarily mean ten years of security updates. End-of-support planning needs replacement lead time, migration dependencies and compensating controls. Licence or subscription expiry can affect update availability, logging, certificate services or access to configuration tools; investigate the actual failure behaviour. Keep an export and recovery capability that is lawful, usable and tested rather than assuming a procurement contract alone guarantees continuity.

Supplier access is another acquired dependency. Define named identities, approved windows, least privilege, session revocation, logging and the local operational authority. Avoid a contract granting permanent unrestricted access merely because remote maintenance is convenient. A supplier that cannot remove a shared embedded credential may require a bounded architecture, documented residual exposure and an owner decision; deleting it blindly may also break supported operation. The contract, architecture and acceptance evidence must describe the same arrangement.

At acceptance, compare the delivered asset against the approved bill of materials, firmware, interfaces and configuration. Test negative permissions and degraded/recovery behaviour as well as the nominal function. Record discrepancies before final acceptance: an open exception is not a passed requirement. Maintain the evidence package through operation and retirement, including destruction or return of credential-bearing components. In the curriculum scope, these are D4–D7 engineering duties and interface obligations; assessing a power-control gateway does not confer authority to redesign primary electrical protection.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic procurement review, Gateway G revision B: requirement R1 signed updates; R2 named remote identities with immediate session revocation; R3 supported recovery without supplier cloud; R4 security support through 2031. Supplier provides a valid release signature, a 2024 SBOM and a brochure saying “10-year design life.” Delivered firmware is 2026.2. Remote support uses one shared account and existing sessions survive account disablement. A restore demonstration requires the supplier cloud. Contract security-support end date is 2028. Alarm forwarding itself passes its timing test.

**Reasoning:** Accept only the demonstrated alarm function. The signature is relevant to R1, subject to trusted-key validation, but does not satisfy R2–R4. Refresh component evidence for 2026.2. The shared account and surviving sessions fail the stated identity/revocation criterion. Cloud dependence conflicts with R3; either redesign/retest or obtain an authorised requirement change. Design life does not supersede the 2028 support end date. Record separate nonconformities, consequence and options before acceptance.

#### Guided practice

Create three targeted supplier clarification requests.

**Hint:** Ask for evidence tied to a requirement, version and method.

**Worked solution:** Request current component/provenance evidence for 2026.2; a demonstration of named identity and existing-session termination; a supported offline restore procedure plus binding security-support dates.

#### Independent task

Environment: analytical

Write a procurement acceptance matrix and maintenance exit plan.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L018.json

**Evidence to produce**

- Requirement-to-evidence matrix
- Three nonconformity records
- Support/renewal milestones
- Supplier access specification

**Acceptance criteria**

- A passed alarm test does not close unrelated requirements.
- Support dates use the contract rather than design-life marketing.
- Each unresolved requirement has a decision owner and retest method.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0171 · single · diagnosis**

Which evidence resolves the security-support end date for the supplied contract?

Synthetic procurement review, Gateway G revision B: requirement R1 signed updates; R2 named remote identities with immediate session revocation; R3 supported recovery without supplier cloud; R4 security support through 2031. Supplier provides a valid release signature, a 2024 SBOM and a brochure saying “10-year design life.” Delivered firmware is 2026.2. Remote support uses one shared account and existing sessions survive account disablement. A restore demonstration requires the supplier cloud. Contract security-support end date is 2028. Alarm forwarding itself passes its timing test.

1. The explicit 2028 contractual support date.
2. The ten-year design-life brochure.
3. The 2026 firmware number plus ten years.
4. The passed alarm timing test.

**Correct option(s):** 1

- Option 1: It directly states the supplied obligation.
- Option 2: Physical design life is not a security-update commitment.
- Option 3: Version naming does not establish support duration.
- Option 4: Timing does not establish future support.

**GICSP-Q0172 · single · mechanism**

What can the validated release signature establish?

Synthetic procurement review, Gateway G revision B: requirement R1 signed updates; R2 named remote identities with immediate session revocation; R3 supported recovery without supplier cloud; R4 security support through 2031. Supplier provides a valid release signature, a 2024 SBOM and a brochure saying “10-year design life.” Delivered firmware is 2026.2. Remote support uses one shared account and existing sessions survive account disablement. A restore demonstration requires the supplier cloud. Contract security-support end date is 2028. Alarm forwarding itself passes its timing test.

1. Compatibility with every controller model.
2. Independence from the supplier cloud.
3. Absence of exploitable software defects.
4. Integrity and origin relative to the trusted signing key.

**Correct option(s):** 4

- Option 1: Compatibility requires platform-specific evidence.
- Option 2: The signature says nothing about restore dependencies.
- Option 3: Authentic software can contain vulnerabilities.
- Option 4: Verification links the bytes to that key.

**GICSP-Q0173 · single · diagnosis**

Why is the 2024 SBOM insufficient by itself for the delivered baseline?

Synthetic procurement review, Gateway G revision B: requirement R1 signed updates; R2 named remote identities with immediate session revocation; R3 supported recovery without supplier cloud; R4 security support through 2031. Supplier provides a valid release signature, a 2024 SBOM and a brochure saying “10-year design life.” Delivered firmware is 2026.2. Remote support uses one shared account and existing sessions survive account disablement. A restore demonstration requires the supplier cloud. Contract security-support end date is 2028. Alarm forwarding itself passes its timing test.

1. Firmware components can be excluded from the SBOM because only host applications use libraries.
2. The 2024 SBOM proves that all components in delivered 2026.2 are identical to that earlier list.
3. The SBOM is invalid solely because it is more than one calendar year old.
4. The 2026.2 dependencies may differ.

**Correct option(s):** 4

- Option 1: Embedded firmware can include third-party components relevant to vulnerability and support scope.
- Option 2: The delivered baseline needs a corresponding component inventory or verified reconciliation.
- Option 3: The issue is whether it accurately represents delivered firmware2026.2, not an invented fixed expiry.
- Option 4: Component evidence must match the delivered version.

**GICSP-Q0174 · single · diagnosis**

Which R2 failure remains even if the shared account is renamed for each visit?

Synthetic procurement review, Gateway G revision B: requirement R1 signed updates; R2 named remote identities with immediate session revocation; R3 supported recovery without supplier cloud; R4 security support through 2031. Supplier provides a valid release signature, a 2024 SBOM and a brochure saying “10-year design life.” Delivered firmware is 2026.2. Remote support uses one shared account and existing sessions survive account disablement. A restore demonstration requires the supplier cloud. Contract security-support end date is 2028. Alarm forwarding itself passes its timing test.

1. Existing sessions survive disablement.
2. The signing key is necessarily stolen.
3. The design life is shorter than two years.
4. Alarm forwarding is too slow.

**Correct option(s):** 1

- Option 1: Renaming does not demonstrate session revocation.
- Option 2: No evidence supports key compromise.
- Option 3: The brochure states ten years, though that is a different claim.
- Option 4: The supplied timing test passed.

**GICSP-Q0175 · single · design**

Which evidence would directly test R3?

Synthetic procurement review, Gateway G revision B: requirement R1 signed updates; R2 named remote identities with immediate session revocation; R3 supported recovery without supplier cloud; R4 security support through 2031. Supplier provides a valid release signature, a 2024 SBOM and a brochure saying “10-year design life.” Delivered firmware is 2026.2. Remote support uses one shared account and existing sessions survive account disablement. A restore demonstration requires the supplier cloud. Contract security-support end date is 2028. Alarm forwarding itself passes its timing test.

1. A restore while the supplier performs cloud activation.
2. A signature check on the installer alone.
3. A screenshot showing local backup filenames.
4. A controlled restore with supplier-cloud access unavailable.

**Correct option(s):** 4

- Option 1: That preserves the disputed dependency.
- Option 2: Authentic installation bytes do not test licensing or restore dependencies.
- Option 3: File presence does not prove usable recovery.
- Option 4: It tests the specified independence and recovery path.

**GICSP-Q0176 · single · operations**

What should happen to R4 when the supplier cannot extend support?

Synthetic procurement review, Gateway G revision B: requirement R1 signed updates; R2 named remote identities with immediate session revocation; R3 supported recovery without supplier cloud; R4 security support through 2031. Supplier provides a valid release signature, a 2024 SBOM and a brochure saying “10-year design life.” Delivered firmware is 2026.2. Remote support uses one shared account and existing sessions survive account disablement. A restore demonstration requires the supplier cloud. Contract security-support end date is 2028. Alarm forwarding itself passes its timing test.

1. Mark it passed because hardware is expected to last.
2. Escalate the gap for an authorised requirement decision or select a supported alternative.
3. Delete the requirement from the test report silently.
4. Assume compensating segmentation extends the supplier contract.

**Correct option(s):** 2

- Option 1: Longevity does not deliver updates.
- Option 2: The acceptance baseline must reflect a legitimate decision.
- Option 3: That conceals a material discrepancy.
- Option 4: Segmentation may reduce exposure but changes no contractual date.

**GICSP-Q0177 · multi · design**

Which items belong in a useful supplier vulnerability notice? Select all that apply.

Synthetic procurement review, Gateway G revision B: requirement R1 signed updates; R2 named remote identities with immediate session revocation; R3 supported recovery without supplier cloud; R4 security support through 2031. Supplier provides a valid release signature, a 2024 SBOM and a brochure saying “10-year design life.” Delivered firmware is 2026.2. Remote support uses one shared account and existing sessions survive account disablement. A restore demonstration requires the supplier cloud. Contract security-support end date is 2028. Alarm forwarding itself passes its timing test.

1. A guarantee that every possible attack is prevented.
2. Only a severity score without product identification.
3. Available mitigation and update constraints.
4. Affected versions and conditions.

**Correct option(s):** 3, 4

- Option 1: Such a universal assurance is not supported by a vulnerability notice.
- Option 2: The score alone cannot establish applicability.
- Option 3: Operators need actionable, compatible treatment options.
- Option 4: These connect the advisory to the deployment.

**GICSP-Q0178 · single · operations**

Why retain a supported configuration export before contract exit?

Synthetic procurement review, Gateway G revision B: requirement R1 signed updates; R2 named remote identities with immediate session revocation; R3 supported recovery without supplier cloud; R4 security support through 2031. Supplier provides a valid release signature, a 2024 SBOM and a brochure saying “10-year design life.” Delivered firmware is 2026.2. Remote support uses one shared account and existing sessions survive account disablement. A restore demonstration requires the supplier cloud. Contract security-support end date is 2028. Alarm forwarding itself passes its timing test.

1. Migration and recovery may otherwise depend on unavailable supplier access.
2. Treat the export as nonsensitive without checking for embedded service secrets.
3. The configuration export alone reconstructs physical wiring and calibrated point mapping.
4. An export cancels software licence obligations.

**Correct option(s):** 1

- Option 1: Export capability reduces a concrete lifecycle dependency.
- Option 2: Configuration exports can include credentials and require appropriate custody.
- Option 3: Digital configuration must be reconciled with actual installation and measurement evidence.
- Option 4: Technical possession does not alter legal permissions.

**GICSP-Q0179 · single · implementation**

Which delivered characteristic must be checked against procurement evidence?

Synthetic procurement review, Gateway G revision B: requirement R1 signed updates; R2 named remote identities with immediate session revocation; R3 supported recovery without supplier cloud; R4 security support through 2031. Supplier provides a valid release signature, a 2024 SBOM and a brochure saying “10-year design life.” Delivered firmware is 2026.2. Remote support uses one shared account and existing sessions survive account disablement. A restore demonstration requires the supplier cloud. Contract security-support end date is 2028. Alarm forwarding itself passes its timing test.

1. The actual hardware revision and firmware combination.
2. The brochure’s design-life claim instead of the contractual security-support end date.
3. The supplier identity without checking the delivered revision and firmware baseline.
4. The alarm timing result alone, ignoring the delivered remote-access and recovery characteristics.

**Correct option(s):** 1

- Option 1: A different combination may change compatibility and security behaviour.
- Option 2: Design life and security support are different commitments.
- Option 3: A known vendor can supply a configuration that fails specific procurement requirements.
- Option 4: Functional timing passes do not satisfy the independent R2–R4 security and lifecycle requirements.

**GICSP-Q0180 · single · diagnosis**

What is the defensible acceptance status here?

Synthetic procurement review, Gateway G revision B: requirement R1 signed updates; R2 named remote identities with immediate session revocation; R3 supported recovery without supplier cloud; R4 security support through 2031. Supplier provides a valid release signature, a 2024 SBOM and a brochure saying “10-year design life.” Delivered firmware is 2026.2. Remote support uses one shared account and existing sessions survive account disablement. A restore demonstration requires the supplier cloud. Contract security-support end date is 2028. Alarm forwarding itself passes its timing test.

1. All failures become observations after purchase.
2. Everything passed because the main function works.
3. Alarm timing passed; R2–R4 remain unresolved failures against the supplied criteria.
4. Nothing was tested successfully.

**Correct option(s):** 3

- Option 1: Procurement completion does not change acceptance criteria.
- Option 2: Security and recovery requirements are still binding.
- Option 3: Evidence is assessed requirement by requirement.
- Option 4: The timing result is valid within its scope.

#### Recall

**What does an SBOM support?**

Component and dependency identification for applicability and lifecycle analysis; it does not alone prove exploitability or safety.

**Design life versus support life?**

Expected physical service life and promised security maintenance are different commitments; verify both.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

### GICSP-L019 — Competence, identity lifecycle and separation of duties

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L018

People controls are engineered through work design, authority and evidence. Training attendance is not competence. Define the action a role must perform, its consequence, the knowledge needed, the environment for supervised practice and observable acceptance criteria. A controller engineer may understand logic but lack authority to approve production changes; a cyber responder may understand malware but need operations guidance on safe isolation. Assign decisions to the role that owns the consequence, and make escalation usable during an incident rather than leaving a generic contact list.

Identity lifecycle starts before account creation. A named sponsor requests a role for a defined purpose, the relevant owner approves it, the access is provisioned narrowly, and the actual permissions are checked. During transfers, remove obsolete rights instead of merely adding new ones. On departure, disable interactive and remote identities, revoke active sessions and refresh or revoke attributable secrets where required. A password reset does not necessarily invalidate API tokens, SSH keys, certificates, cached sessions or access through a supplier identity provider. Inventory these mechanisms rather than assuming one directory account is the whole identity.

Separate personal user accounts from service identities. Deleting a departed engineer's personal account must not unexpectedly stop an application that was configured to run under it. Discover this dependency in advance, migrate the service to an approved identity, constrain its logon and permissions, and test the change. Service-account ownership remains assigned to a responsible team; “non-human” does not mean unowned or exempt from credential lifecycle. Emergency accounts need controlled custody, defined use, alerting, post-use review and restoration of secrecy. Test whether their dependencies survive the outage they are intended to address.

Separation of duties reduces unilateral harmful action and undetected error. The person who prepares a consequential change may not also approve it or certify the final evidence. Exact combinations depend on the organisation and consequence; small teams may need independent review or an explicit compensating arrangement. Two usernames operated by one person do not provide independent review. Equally, requiring unavailable approvers without an emergency path can delay a necessary operational response. Define emergency authority, bounded action and retrospective review without turning emergency status into unlimited permanent access.

Social engineering often exploits operational urgency. A caller may correctly name a supplier and fault because those facts are public or previously exposed. Verify the request through a known independent channel and the work order, not a new contact number supplied by the same caller. Never treat a shared secret read aloud by the caller as proof that the action is authorised. Preserve the incident details if impersonation is suspected, but do not accuse a person solely because a call failed verification. The operational team can pursue the genuine fault through the approved support route.

Periodic access review should compare effective entitlements with current roles and approved needs. Listing account names is insufficient when group nesting, local administrators, application roles and gateway sessions create different authority. Sample high-impact actions and reconcile exceptions, dormant accounts, failed deprovisioning and shared credentials. Retain who reviewed which permissions, what changed, and whether removal worked. The result becomes evidence of maintained control, rather than a signed spreadsheet detached from the systems it claims to represent.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic shift case: Alex transfers from controller engineering to reporting. Directory group ENG is removed, but a local PLC-project tool still grants Alex Download and a jump-host session remains active. The historian service runs under Alex's personal identity. Change CH42 was prepared, approved and acceptance-signed by Alex using three account names. A caller claiming supplier support requests the emergency password and gives a new callback number; no approved ticket exists. The emergency account depends on the same directory currently unavailable.

**Reasoning:** Remove or reassign each effective entitlement through an approved transition and verify revocation, while migrating the historian service dependency so reporting continues under an owned service identity. CH42 has one human decision maker despite three account names. Review its approval and acceptance independently. Verify support through the known supplier route without sharing the emergency secret. The emergency account design has a common dependency and needs an independently recoverable authorised method, not an untested assumption.

#### Guided practice

Design a transfer checklist that does not unexpectedly stop the historian.

**Hint:** Separate personal authority removal from service identity migration.

**Worked solution:** Inventory directory/local/application/token/session rights and service dependencies; approve a service identity; test migration; remove Alex’s obsolete control authority and terminate relevant sessions; independently verify the historian and negative download test.

#### Independent task

Environment: analytical

Produce a role-transition plan and independently review CH42.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L019.json

**Evidence to produce**

- Entitlement/dependency map
- Ordered transition with operational checks
- Approval-independence finding
- Verified supplier-contact decision

**Acceptance criteria**

- Directory removal is not treated as complete revocation.
- Service continuity has a tested identity migration.
- Three accounts belonging to one human do not count as independent review.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0181 · single · diagnosis**

Why can Alex still download a project after removal from ENG?

Synthetic shift case: Alex transfers from controller engineering to reporting. Directory group ENG is removed, but a local PLC-project tool still grants Alex Download and a jump-host session remains active. The historian service runs under Alex's personal identity. Change CH42 was prepared, approved and acceptance-signed by Alex using three account names. A caller claiming supplier support requests the emergency password and gives a new callback number; no approved ticket exists. The emergency account depends on the same directory currently unavailable.

1. The local tool entitlement is a separate authority path.
2. Removal from ENG necessarily changes the local tool role after its next screen refresh.
3. The remaining project-download capability is explained only by the historian service account.
4. Directory group removal fails because Alex used three account names for CH42.

**Correct option(s):** 1

- Option 1: Directory membership removal need not change local application roles.
- Option 2: The fixture retains a separate local Download grant; a display refresh is not a revocation mechanism.
- Option 3: The explicit local tool privilege and active jump session already provide residual access paths.
- Option 4: That is a separation-of-duties issue, distinct from the local grant and active-session revocation gap.

**GICSP-Q0182 · single · operations**

What should be discovered before disabling Alex's personal identity?

Synthetic shift case: Alex transfers from controller engineering to reporting. Directory group ENG is removed, but a local PLC-project tool still grants Alex Download and a jump-host session remains active. The historian service runs under Alex's personal identity. Change CH42 was prepared, approved and acceptance-signed by Alex using three account names. A caller claiming supplier support requests the emergency password and gives a new callback number; no approved ticket exists. The emergency account depends on the same directory currently unavailable.

1. Services and scheduled jobs that depend on that identity.
2. Only the account creation date.
3. Only whether Alex remembers the password.
4. Whether the account name is shorter than the service name.

**Correct option(s):** 1

- Option 1: The historian dependency could cause avoidable disruption.
- Option 2: Age does not reveal runtime dependencies.
- Option 3: Services may hold credentials independently.
- Option 4: Naming length has no bearing on dependency.

**GICSP-Q0183 · single · diagnosis**

Which finding invalidates the claimed independent CH42 review?

Synthetic shift case: Alex transfers from controller engineering to reporting. Directory group ENG is removed, but a local PLC-project tool still grants Alex Download and a jump-host session remains active. The historian service runs under Alex's personal identity. Change CH42 was prepared, approved and acceptance-signed by Alex using three account names. A caller claiming supplier support requests the emergency password and gives a new callback number; no approved ticket exists. The emergency account depends on the same directory currently unavailable.

1. The preparer understood controller logic.
2. One human controlled preparation, approval and acceptance.
3. The acceptance occurred after preparation.
4. The change has a numeric identifier.

**Correct option(s):** 2

- Option 1: Technical competence does not itself prohibit preparation.
- Option 2: Different usernames do not create independent judgment.
- Option 3: That order is expected.
- Option 4: Identifiers assist traceability.

**GICSP-Q0184 · single · operations**

How should the supplier caller be verified?

Synthetic shift case: Alex transfers from controller engineering to reporting. Directory group ENG is removed, but a local PLC-project tool still grants Alex Download and a jump-host session remains active. The historian service runs under Alex's personal identity. Change CH42 was prepared, approved and acceptance-signed by Alex using three account names. A caller claiming supplier support requests the emergency password and gives a new callback number; no approved ticket exists. The emergency account depends on the same directory currently unavailable.

1. Use the established supplier contact route and approved work-order process.
2. Call only the newly supplied number.
3. Ask the caller to repeat public model information.
4. Share the emergency password and audit later.

**Correct option(s):** 1

- Option 1: Independent verification avoids relying on caller-controlled details.
- Option 2: The same impersonator may control it.
- Option 3: Public knowledge does not establish authority.
- Option 4: Disclosure creates immediate unauthorised access risk.

**GICSP-Q0185 · single · diagnosis**

Which facts make the emergency account inadequate for this directory outage?

Synthetic shift case: Alex transfers from controller engineering to reporting. Directory group ENG is removed, but a local PLC-project tool still grants Alex Download and a jump-host session remains active. The historian service runs under Alex's personal identity. Change CH42 was prepared, approved and acceptance-signed by Alex using three account names. A caller claiming supplier support requests the emergency password and gives a new callback number; no approved ticket exists. The emergency account depends on the same directory currently unavailable.

1. The emergency account’s descriptive name is sufficient to make it independent of the directory.
2. Its use requires an incident record.
3. Its password is held under controlled custody.
4. Its authentication depends on the unavailable directory.

**Correct option(s):** 4

- Option 1: Its authentication dependency remains the unavailable directory.
- Option 2: Recording can be appropriate and does not imply directory dependence.
- Option 3: Custody can support availability when properly designed.
- Option 4: The recovery path shares the failed dependency.

**GICSP-Q0186 · multi · design**

Which are effective-access review targets? Select all that apply.

Synthetic shift case: Alex transfers from controller engineering to reporting. Directory group ENG is removed, but a local PLC-project tool still grants Alex Download and a jump-host session remains active. The historian service runs under Alex's personal identity. Change CH42 was prepared, approved and acceptance-signed by Alex using three account names. A caller claiming supplier support requests the emergency password and gives a new callback number; no approved ticket exists. The emergency account depends on the same directory currently unavailable.

1. Only the employee's job title.
2. Only completed training attendance.
3. Nested group and local administrator rights.
4. Application roles and active remote sessions.

**Correct option(s):** 3, 4

- Option 1: A title does not reveal technical entitlements.
- Option 2: Attendance does not describe permissions.
- Option 3: Both can grant authority beyond the visible primary role.
- Option 4: Their persistence may differ from the central account.

**GICSP-Q0187 · single · design**

What is a meaningful competence check for a revocation operator?

Synthetic shift case: Alex transfers from controller engineering to reporting. Directory group ENG is removed, but a local PLC-project tool still grants Alex Download and a jump-host session remains active. The historian service runs under Alex's personal identity. Change CH42 was prepared, approved and acceptance-signed by Alex using three account names. A caller claiming supplier support requests the emergency password and gives a new callback number; no approved ticket exists. The emergency account depends on the same directory currently unavailable.

1. The operator removes authorised test access and verifies denial without disrupting the specified service.
2. The operator successfully provisions a new account but has not performed removal or service-dependency checks.
3. The operator can describe account deletion but has never tested active-session revocation.
4. The operator signs that a video was watched.

**Correct option(s):** 1

- Option 1: This demonstrates the task and its operational constraint.
- Option 2: Provisioning a new identity does not demonstrate the distinct revocation and continuity task.
- Option 3: The task includes effective removal of continuing authority, not only knowledge of account administration.
- Option 4: Attendance alone does not demonstrate execution.

**GICSP-Q0188 · single · operations**

How should a necessary emergency change handle unavailable normal approvers?

Synthetic shift case: Alex transfers from controller engineering to reporting. Directory group ENG is removed, but a local PLC-project tool still grants Alex Download and a jump-host session remains active. The historian service runs under Alex's personal identity. Change CH42 was prepared, approved and acceptance-signed by Alex using three account names. A caller claiming supplier support requests the emergency password and gives a new callback number; no approved ticket exists. The emergency account depends on the same directory currently unavailable.

1. Always wait indefinitely regardless of physical consequences.
2. Record the change as routine to avoid review.
3. Use a predefined delegated emergency authority with bounded actions and subsequent review.
4. Let any logged-in user approve unlimited changes.

**Correct option(s):** 3

- Option 1: A usable emergency process is needed for urgent risk.
- Option 2: Concealment removes the required oversight.
- Option 3: This preserves accountability while allowing timely response.
- Option 4: That abandons the authority boundary.

**GICSP-Q0189 · single · recovery**

What should follow use of a shared break-glass secret?

Synthetic shift case: Alex transfers from controller engineering to reporting. Directory group ENG is removed, but a local PLC-project tool still grants Alex Download and a jump-host session remains active. The historian service runs under Alex's personal identity. Change CH42 was prepared, approved and acceptance-signed by Alex using three account names. A caller claiming supplier support requests the emergency password and gives a new callback number; no approved ticket exists. The emergency account depends on the same directory currently unavailable.

1. Assume MFA on unrelated user accounts protected it.
2. Review the action and restore controlled secrecy according to the approved mechanism.
3. Keep the shared break-glass secret unchanged because the incident has ended.
4. Delete the incident record once service returns.

**Correct option(s):** 2

- Option 1: Protection must apply to the actual emergency path.
- Option 2: Use changes the exposure of the credential.
- Option 3: Use should trigger the defined custody, rotation and access review rather than indefinite reuse without assessment.
- Option 4: The record is needed for accountability and improvement.

**GICSP-Q0190 · single · diagnosis**

Which evidence best closes Alex's transfer action?

Synthetic shift case: Alex transfers from controller engineering to reporting. Directory group ENG is removed, but a local PLC-project tool still grants Alex Download and a jump-host session remains active. The historian service runs under Alex's personal identity. Change CH42 was prepared, approved and acceptance-signed by Alex using three account names. A caller claiming supplier support requests the emergency password and gives a new callback number; no approved ticket exists. The emergency account depends on the same directory currently unavailable.

1. A screenshot of ENG removal alone.
2. An HR email saying the transfer is complete.
3. A successful login to the reporting portal.
4. Verified denial of obsolete controller actions and successful historian operation under its approved service identity.

**Correct option(s):** 4

- Option 1: Local rights and sessions remain untested.
- Option 2: It does not prove technical access changed.
- Option 3: New access does not establish removal of old access.
- Option 4: Both authority reduction and continuity are demonstrated.

#### Recall

**Why are three accounts not necessarily separation of duties?**

Independence concerns the people and decision authority behind the accounts, not the number of usernames.

**What must an access removal check include?**

Effective local/application/group rights, keys and tokens, active sessions and service dependencies—not just the primary directory entry.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

### GICSP-L020 — Assurance metrics, sampling and control effectiveness

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L019

A control can be purchased, installed, configured, healthy and effective at its intended function; those are different states. A licence count measures entitlement, while a heartbeat measures that something reported. Neither alone proves that the intended event is detected or an unauthorised action is blocked. Define the assurance claim first. For a remote-access control, a useful claim might be that revoked supplier identities cannot start or continue a session after the approved interval. Choose a test that observes both new and existing sessions, with identity, timestamp and result.

Metrics need an explicit population and denominator. “Ninety percent patched” is ambiguous if the denominator excludes disconnected controllers or counts each virtual interface as an asset. Freeze the reporting population or explain additions and removals. Distinguish applicable assets from supported update candidates and from successfully updated, verified assets. An unsupported device can remain an exposure even if it is excluded from an operational patch-completion metric. Report this exclusion separately instead of making the risk disappear mathematically.

Time matters. A snapshot can miss repeated gaps between checks. Measure exposure duration, the age of exceptions and time since a meaningful recovery test. Do not automatically interpret a longer interval as unacceptable; compare it with the approved consequence-based requirement and change history. A backup job that succeeds nightly can still have no demonstrated restore capability. Likewise, certificate expiry in thirty days is not equivalent to a failure today, but may require action now if replacement needs a six-week outage lead time.

Sampling provides evidence about the sampled items under sampled conditions. Random samples and targeted high-consequence samples answer different questions. If five of five tested revocations work, the untested remainder is not proven perfect. Identify the selection method, shared configurations and known exclusions. A failed sample may reveal a systemic configuration defect, or an isolated condition requiring scope investigation. Avoid extrapolating a precise population failure rate from an intentionally biased sample. Combine coverage measurements with test quality and consequence.

Detection metrics require ground truth or a defined adjudication process. Precision is true positives divided by all positive alerts; recall is true positives divided by all actual positive events in the evaluated dataset. High precision with low recall can mean many missed events. Overall accuracy can be misleading for rare incidents because a detector that always says normal can score highly on an overwhelmingly normal dataset. A synthetic replay evaluates the supplied event set and environment, not every real attack. Document event labels, collection gaps and uncertainty before treating a score as a readiness claim.

Audits trace claims through evidence to outcomes. Keep the requirement, test version, system baseline, execution identity, timestamps, raw results, interpretation, reviewer and unresolved limitations. An exception register should distinguish authorised acceptance from overdue review or an unapproved workaround. Closure requires evidence that the treatment achieved its criterion, or an authorised residual-risk decision. Report decision-relevant changes and open consequences to the owner. A green dashboard that hides failed sensors or shrinks its denominator makes management less informed even if every number is arithmetically correct.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic monthly assurance: inventory has 120 in-scope assets. Patch dashboard includes 100 supported IP endpoints, reports 90 verified updated and 10 pending; 20 legacy/serial assets are excluded. Remote-access tests deliberately select five highest-risk suppliers: four pass, one active session survives revocation. Detector replay has 20 labelled malicious events and 180 normal events; it alerts on 12 malicious and 3 normal events. Eight malicious events have no alert. Last month contained 80 dashboard endpoints; 76 were patched. A restored backup has not been tested for nine months.

**Reasoning:** Patch completion within the dashboard is 90/100=90%; verified updates as a fraction of all scoped assets are 90/120=75%, but that second ratio does not imply the other thirty are all patchable. Report twenty exclusions and their treatment. Last month was 95% of a smaller population, so explain the population change. The targeted revocation sample found a real failure, not a statistically representative 20% population estimate. Replay precision is 12/15=80%; recall is 12/20=60%. Successful backup jobs cannot replace the missing restore evidence.

#### Guided practice

Compute precision, recall and the information needed to compare patch months.

**Hint:** Use different denominators for different claims.

**Worked solution:** Precision 80%, recall 60%; compare the same asset cohort or reconcile twenty added endpoints, applicability, approved exceptions and verification methods before attributing the change to worse operations.

#### Independent task

Environment: analytical

Rebuild the dashboard as a one-page assurance report with evidence and decisions.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L020.json

**Evidence to produce**

- Population reconciliation
- Detector confusion matrix
- Sample limitations
- Owner actions for revocation and recovery evidence

**Acceptance criteria**

- Precision and recall use correct denominators.
- Excluded assets remain visible in scope and risk treatment.
- Targeted sampling is not presented as a representative population rate.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0191 · single · calculation**

What is the reported patch completion rate within the dashboard population?

Synthetic monthly assurance: inventory has 120 in-scope assets. Patch dashboard includes 100 supported IP endpoints, reports 90 verified updated and 10 pending; 20 legacy/serial assets are excluded. Remote-access tests deliberately select five highest-risk suppliers: four pass, one active session survives revocation. Detector replay has 20 labelled malicious events and 180 normal events; it alerts on 12 malicious and 3 normal events. Eight malicious events have no alert. Last month contained 80 dashboard endpoints; 76 were patched. A restored backup has not been tested for nine months.

1. 75%.
2. 100%.
3. 90%.
4. 95%.

**Correct option(s):** 3

- Option 1: This uses all 120 scoped assets, a different denominator.
- Option 2: Ten included endpoints remain pending.
- Option 3: Ninety verified updated endpoints divided by one hundred included endpoints.
- Option 4: That was last month's smaller population.

**GICSP-Q0192 · single · calculation**

What fraction of all scoped assets has a verified update in the supplied report?

Synthetic monthly assurance: inventory has 120 in-scope assets. Patch dashboard includes 100 supported IP endpoints, reports 90 verified updated and 10 pending; 20 legacy/serial assets are excluded. Remote-access tests deliberately select five highest-risk suppliers: four pass, one active session survives revocation. Detector replay has 20 labelled malicious events and 180 normal events; it alerts on 12 malicious and 3 normal events. Eight malicious events have no alert. Last month contained 80 dashboard endpoints; 76 were patched. A restored backup has not been tested for nine months.

1. 75%.
2. 25%.
3. 83.3%.
4. 90%.

**Correct option(s):** 1

- Option 1: Ninety divided by 120 equals 0.75.
- Option 2: Thirty out of 120 is the complement, not the requested fraction.
- Option 3: One hundred divided by 120 measures dashboard inclusion, not verified updates.
- Option 4: That excludes twenty scoped assets from the denominator.

**GICSP-Q0193 · single · calculation**

What is detector precision in the replay?

Synthetic monthly assurance: inventory has 120 in-scope assets. Patch dashboard includes 100 supported IP endpoints, reports 90 verified updated and 10 pending; 20 legacy/serial assets are excluded. Remote-access tests deliberately select five highest-risk suppliers: four pass, one active session survives revocation. Detector replay has 20 labelled malicious events and 180 normal events; it alerts on 12 malicious and 3 normal events. Eight malicious events have no alert. Last month contained 80 dashboard endpoints; 76 were patched. A restored backup has not been tested for nine months.

1. 98.3%.
2. 80%.
3. 60%.
4. 90%.

**Correct option(s):** 2

- Option 1: This confuses normal-event behaviour with alert correctness.
- Option 2: Twelve true positive alerts divided by fifteen total alerts.
- Option 3: Twelve of twenty malicious events is recall.
- Option 4: The supplied counts do not yield this precision.

**GICSP-Q0194 · single · calculation**

What is detector recall in the replay?

Synthetic monthly assurance: inventory has 120 in-scope assets. Patch dashboard includes 100 supported IP endpoints, reports 90 verified updated and 10 pending; 20 legacy/serial assets are excluded. Remote-access tests deliberately select five highest-risk suppliers: four pass, one active session survives revocation. Detector replay has 20 labelled malicious events and 180 normal events; it alerts on 12 malicious and 3 normal events. Eight malicious events have no alert. Last month contained 80 dashboard endpoints; 76 were patched. A restored backup has not been tested for nine months.

1. 60%.
2. 80%.
3. 15%.
4. 40%.

**Correct option(s):** 1

- Option 1: Twelve detected malicious events divided by twenty actual malicious events.
- Option 2: That is precision using all alerts.
- Option 3: Fifteen alerts are not the number of actual malicious events.
- Option 4: Eight missed events divided by twenty is the miss fraction.

**GICSP-Q0195 · single · diagnosis**

What can be concluded from the five deliberately high-risk revocation tests?

Synthetic monthly assurance: inventory has 120 in-scope assets. Patch dashboard includes 100 supported IP endpoints, reports 90 verified updated and 10 pending; 20 legacy/serial assets are excluded. Remote-access tests deliberately select five highest-risk suppliers: four pass, one active session survives revocation. Detector replay has 20 labelled malicious events and 180 normal events; it alerts on 12 malicious and 3 normal events. Eight malicious events have no alert. Last month contained 80 dashboard endpoints; 76 were patched. A restored backup has not been tested for nine months.

1. At least one tested access path failed the revocation criterion.
2. The failed result is invalid because the sample was targeted.
3. Exactly 20% of all suppliers will fail.
4. All low-risk suppliers passed.

**Correct option(s):** 1

- Option 1: That is directly observed without unjustified population extrapolation.
- Option 2: Targeted testing can validly find a defect.
- Option 3: A targeted five-item sample is not a representative population estimate.
- Option 4: They were not tested.

**GICSP-Q0196 · single · diagnosis**

Which extra information is essential before interpreting 95% last month versus 90% this month?

Synthetic monthly assurance: inventory has 120 in-scope assets. Patch dashboard includes 100 supported IP endpoints, reports 90 verified updated and 10 pending; 20 legacy/serial assets are excluded. Remote-access tests deliberately select five highest-risk suppliers: four pass, one active session survives revocation. Detector replay has 20 labelled malicious events and 180 normal events; it alerts on 12 malicious and 3 normal events. Eight malicious events have no alert. Last month contained 80 dashboard endpoints; 76 were patched. A restored backup has not been tested for nine months.

1. Only the highest vulnerability score observed in either month.
2. The population changes and comparable asset-level verification status.
3. Only the absolute count of patched assets, without the included population.
4. An assumption that all new assets arrived patched.

**Correct option(s):** 2

- Option 1: Severity may inform priority but does not reconcile patch-population comparability.
- Option 2: Different denominators can explain the apparent trend.
- Option 3: Ninety versus seventy-six cannot explain the rate change without denominator and cohort reconciliation.
- Option 4: That assumption needs evidence.

**GICSP-Q0197 · single · design**

Which backup metric directly addresses the present evidence gap?

Synthetic monthly assurance: inventory has 120 in-scope assets. Patch dashboard includes 100 supported IP endpoints, reports 90 verified updated and 10 pending; 20 legacy/serial assets are excluded. Remote-access tests deliberately select five highest-risk suppliers: four pass, one active session survives revocation. Detector replay has 20 labelled malicious events and 180 normal events; it alerts on 12 malicious and 3 normal events. Eight malicious events have no alert. Last month contained 80 dashboard endpoints; 76 were patched. A restored backup has not been tested for nine months.

1. Number of backup job notifications.
2. Total backup-file size alone.
3. Number of purchased backup licences.
4. Time and result of a successful representative restore with acceptance checks.

**Correct option(s):** 4

- Option 1: Notifications do not demonstrate restoration.
- Option 2: Large files may still be unusable.
- Option 3: Entitlement is not recovery evidence.
- Option 4: Recovery capability is the missing assurance claim.

**GICSP-Q0198 · single · mechanism**

Why might a detector with 99% accuracy still be poor for rare incidents?

Synthetic monthly assurance: inventory has 120 in-scope assets. Patch dashboard includes 100 supported IP endpoints, reports 90 verified updated and 10 pending; 20 legacy/serial assets are excluded. Remote-access tests deliberately select five highest-risk suppliers: four pass, one active session survives revocation. Detector replay has 20 labelled malicious events and 180 normal events; it alerts on 12 malicious and 3 normal events. Eight malicious events have no alert. Last month contained 80 dashboard endpoints; 76 were patched. A restored backup has not been tested for nine months.

1. Reducing false positives necessarily reduces false negatives by the same count.
2. Accuracy directly states how many harmful events were detected.
3. A large dataset makes the eight missed harmful events statistically irrelevant.
4. Normal events may dominate the dataset while malicious events are missed.

**Correct option(s):** 4

- Option 1: The two error populations and threshold tradeoffs need separate measurement.
- Option 2: Recall answers that question; accuracy includes the potentially dominant true negatives.
- Option 3: Sample size does not eliminate the operational consequence of false negatives.
- Option 4: Class imbalance can hide low recall.

**GICSP-Q0199 · multi · design**

Which records should accompany a passed control test? Select all that apply.

Synthetic monthly assurance: inventory has 120 in-scope assets. Patch dashboard includes 100 supported IP endpoints, reports 90 verified updated and 10 pending; 20 legacy/serial assets are excluded. Remote-access tests deliberately select five highest-risk suppliers: four pass, one active session survives revocation. Detector replay has 20 labelled malicious events and 180 normal events; it alerts on 12 malicious and 3 normal events. Eight malicious events have no alert. Last month contained 80 dashboard endpoints; 76 were patched. A restored backup has not been tested for nine months.

1. The applicable criterion and tested system baseline.
2. Only an unsigned green tick.
3. Raw observations, timing and execution/review identity.
4. A substituted result from an unrelated version.

**Correct option(s):** 1, 3

- Option 1: They establish what was required and evaluated.
- Option 2: It does not show how the conclusion was reached.
- Option 3: They support traceability and interpretation.
- Option 4: Different software may behave differently.

**GICSP-Q0200 · single · diagnosis**

How should the twenty excluded legacy/serial assets be represented?

Synthetic monthly assurance: inventory has 120 in-scope assets. Patch dashboard includes 100 supported IP endpoints, reports 90 verified updated and 10 pending; 20 legacy/serial assets are excluded. Remote-access tests deliberately select five highest-risk suppliers: four pass, one active session survives revocation. Detector replay has 20 labelled malicious events and 180 normal events; it alerts on 12 malicious and 3 normal events. Eight malicious events have no alert. Last month contained 80 dashboard endpoints; 76 were patched. A restored backup has not been tested for nine months.

1. As outside organisational responsibility automatically.
2. As decommissioned because no dashboard entry exists.
3. As fully updated without evidence.
4. As scoped assets with explicit applicability, exposure and treatment status.

**Correct option(s):** 4

- Option 1: Scope was already supplied as including them.
- Option 2: Exclusion is not removal from service.
- Option 3: Unsupported does not mean remediated.
- Option 4: Operational metric exclusions must not erase risk visibility.

#### Recall

**Precision versus recall?**

Precision asks how many alerts are true positives; recall asks how many actual positive events were detected.

**What does a targeted sample prove?**

Observed behaviour of the selected items and conditions; population estimates require an appropriate sampling basis.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

## GICSP-M05 — Intelligence and practical threat modelling

### GICSP-L021 — Adversaries, accidental actions and consequence-led threat analysis

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L020

A threat model describes how an unwanted outcome might occur and what evidence or controls matter. It is not a list of frightening actor names. Begin with the function that must be preserved: reliable measurement, authorised control, alarm delivery, correct project logic or recoverable operation. Describe the consequence of lost confidentiality, integrity or availability in that context. Disclosure of a plant diagram may enable later access planning; alteration of a sensor value may mislead an operator before any server visibly fails.

Threat actors differ in intent, resources and access. Financially motivated criminals may seek disruption or extortion; an espionage actor may prioritise quiet information access; a malicious insider may already possess useful process knowledge; a contractor may accidentally apply an incompatible change. Actor categories are hypotheses for planning, not conclusions established by a single IP address or malware family. The same stolen remote credential can be used by several actors, and commodity tools can appear in both legitimate administration and intrusions.

Separate intent from capability and opportunity. An actor may want to affect a controller but lack a route, credential, tool or process knowledge. Conversely, an authorised engineer has technical capability but not necessarily malicious intent. A viable path needs its prerequisites. Map entry, trust-boundary crossings, privilege and action to the consequence. State whether each link is observed, documented possible, experimentally demonstrated in an authorised environment or still assumed. This distinction prevents a plausible diagram becoming a false claim that compromise occurred.

Accidental and environmental initiating events can lead to similar operational consequences. A misconfigured NTP source can disorder records; an expired certificate can break authenticated telemetry; a contractor can restore the wrong project version. Defensive design should address these pathways where relevant rather than treating cybersecurity as malware-only. Do not label ordinary faults as attacks merely because their effects resemble an attack technique. Preserve alternative explanations and collect discriminating evidence: maintenance records, authentication events, project differences, device diagnostics and independent physical observations.

Consequence analysis should follow propagation and safeguards. An altered supervisory setpoint may be bounded by controller limits and an independent protection function, or it may bypass an assumption in the operating procedure. Identify what is independent and what shares sensors, power, logic, communications or administration. A second display reading the same compromised source is not independent confirmation. Safety and process specialists determine acceptable operating envelopes and safe action; security analysis provides the access and evidence model without inventing authority over those decisions.

Use the model to prioritise questions and treatments. A threat statement can name the initiating access, action, affected asset, failed property and business/process consequence. Add existing controls, dependencies, uncertainty and an owner. Select controls that break specific paths or reduce consequences, then define tests and monitoring. Revisit the model after architectural, role, firmware or process changes. A useful model helps an engineer decide what to verify next; a catalogue of actor names without a path, asset or consequence does not.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic facility case: a supplier account can reach engineering workstation E through jump host J. E can download controller C projects when an operator-approved maintenance key is enabled. The key is normally disabled, but no record exists for the last shift. HMI and historian both obtain temperature from the same C tag. A high-temperature event occurred after a project download and a cooling maintenance activity. The download used a valid supplier identity. No malware or actor attribution evidence is available. Independent local protection status is not yet collected.

**Reasoning:** The account/J/E/C path is a documented possibility; download authentication is observed, while human identity, authority, project effect and protection status remain uncertain. Valid credentials do not prove authorised work or malicious intent. Compare the project, maintenance approval, key state and independent process/protection evidence. HMI and historian agreement is not independent corroboration because they share the source. Maintain both malicious change and maintenance/fault hypotheses until evidence discriminates them.

#### Guided practice

Write a threat statement and two nonmalicious alternatives.

**Hint:** Name the access, action, consequence and uncertainty separately.

**Worked solution:** Threat: misuse of supplier access through E could alter C logic and impair thermal control if the maintenance key permits download. Alternatives: approved but erroneous project deployment; cooling work caused the event without a harmful logic change. Seek project and process evidence before attribution.

#### Independent task

Environment: analytical

Build a consequence-led threat worksheet with evidence labels.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L021.json

**Evidence to produce**

- Two attack-path hypotheses
- Two accidental/fault hypotheses
- Safeguard dependency map
- Discriminating collection requests

**Acceptance criteria**

- Valid login is not equated with authorised action or attribution.
- Shared-source displays are not labelled independent.
- Operational authority owns safe-state and protection judgments.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0201 · single · diagnosis**

What does the valid supplier identity establish by itself?

Synthetic facility case: a supplier account can reach engineering workstation E through jump host J. E can download controller C projects when an operator-approved maintenance key is enabled. The key is normally disabled, but no record exists for the last shift. HMI and historian both obtain temperature from the same C tag. A high-temperature event occurred after a project download and a cooling maintenance activity. The download used a valid supplier identity. No malware or actor attribution evidence is available. Independent local protection status is not yet collected.

1. The high-temperature event proves the download caused it because the download occurred first.
2. The system accepted that credential or identity mechanism.
3. The matching historian and HMI values provide two independent temperature measurements.
4. The valid supplier login establishes that the subsequent project download was within its approved task.

**Correct option(s):** 2

- Option 1: Cooling maintenance and other process causes remain alternatives requiring evidence.
- Option 2: It does not identify the actual human or authorise the work.
- Option 3: Both consume the same controller tag, so they share the relevant source dependency.
- Option 4: Authentication does not establish the maintenance-key state or operation authority.

**GICSP-Q0202 · single · diagnosis**

Which prerequisite for the E-to-C download path needs clarification?

Synthetic facility case: a supplier account can reach engineering workstation E through jump host J. E can download controller C projects when an operator-approved maintenance key is enabled. The key is normally disabled, but no record exists for the last shift. HMI and historian both obtain temperature from the same C tag. A high-temperature event occurred after a project download and a cooling maintenance activity. The download used a valid supplier identity. No malware or actor attribution evidence is available. Independent local protection status is not yet collected.

1. The maintenance-key state and approved use at the relevant time.
2. Whether the controller has a recent backup filename.
3. Whether the supplier identity had a successful login at another site.
4. Whether the HMI and historian temperature charts agree.

**Correct option(s):** 1

- Option 1: The supplied mechanism gates project download.
- Option 2: Backup naming does not establish whether the download-gating condition held at the incident time.
- Option 3: A different site login does not establish this controller maintenance-key state or local authority.
- Option 4: They share a controller source and do not establish the key condition governing project download.

**GICSP-Q0203 · single · diagnosis**

Why is matching HMI and historian temperature weak independent corroboration?

Synthetic facility case: a supplier account can reach engineering workstation E through jump host J. E can download controller C projects when an operator-approved maintenance key is enabled. The key is normally disabled, but no record exists for the last shift. HMI and historian both obtain temperature from the same C tag. A high-temperature event occurred after a project download and a cooling maintenance activity. The download used a valid supplier identity. No malware or actor attribution evidence is available. Independent local protection status is not yet collected.

1. The historian’s storage role makes its copy more authoritative than the controller source.
2. The HMI value is an independent operator measurement because it is visible on a screen.
3. The two matching records prove the sensor itself was accurate during the event.
4. Both consume the same controller tag.

**Correct option(s):** 4

- Option 1: Storage does not remove the common upstream measurement dependency.
- Option 2: It still originates from the same C tag as the historian.
- Option 3: Both can agree while sharing an erroneous or manipulated source tag.
- Option 4: One source error can propagate to both records.

**GICSP-Q0204 · single · diagnosis**

Which evidence most directly distinguishes a harmful logic change from an unrelated maintenance effect?

Synthetic facility case: a supplier account can reach engineering workstation E through jump host J. E can download controller C projects when an operator-approved maintenance key is enabled. The key is normally disabled, but no record exists for the last shift. HMI and historian both obtain temperature from the same C tag. A high-temperature event occurred after a project download and a cooling maintenance activity. The download used a valid supplier identity. No malware or actor attribution evidence is available. Independent local protection status is not yet collected.

1. An authorised baseline comparison plus independent process and maintenance records.
2. The high-temperature alarm’s severity label without time-aligned process evidence.
3. An antivirus inventory without accepted-project and cooling-maintenance evidence.
4. The supplier’s reputation without comparing the project or maintenance records.

**Correct option(s):** 1

- Option 1: These relate the change and physical event to competing hypotheses.
- Option 2: Severity describes consequence priority, not which change caused it.
- Option 3: Product counts do not resolve the specific logic-versus-maintenance hypothesis.
- Option 4: Reputation does not distinguish the specific causal alternatives.

**GICSP-Q0205 · single · mechanism**

Which statement correctly separates intent and capability?

Synthetic facility case: a supplier account can reach engineering workstation E through jump host J. E can download controller C projects when an operator-approved maintenance key is enabled. The key is normally disabled, but no record exists for the last shift. HMI and historian both obtain temperature from the same C tag. A high-temperature event occurred after a project download and a cooling maintenance activity. The download used a valid supplier identity. No malware or actor attribution evidence is available. Independent local protection status is not yet collected.

1. E has controller-download capability, while the operator's intent remains unproven.
2. An actor category determines exact tool access.
3. Good intent makes all changes safe.
4. Controller access proves malicious intent.

**Correct option(s):** 1

- Option 1: Technical ability and motive are different claims.
- Option 2: Capability must be established in the actual environment.
- Option 3: Mistakes can cause harmful consequences.
- Option 4: Engineers may legitimately need that capability.

**GICSP-Q0206 · multi · design**

Which events can legitimately appear in a consequence-led security analysis? Select all that apply.

Synthetic facility case: a supplier account can reach engineering workstation E through jump host J. E can download controller C projects when an operator-approved maintenance key is enabled. The key is normally disabled, but no record exists for the last shift. HMI and historian both obtain temperature from the same C tag. A high-temperature event occurred after a project download and a cooling maintenance activity. The download used a valid supplier identity. No malware or actor attribution evidence is available. Independent local protection status is not yet collected.

1. An incorrect project restored by an authorised technician.
2. Only events containing a named malware family.
3. Only events already attributed to a government.
4. An expired certificate disrupting authenticated telemetry.

**Correct option(s):** 1, 4

- Option 1: Accidental integrity failures can affect the process.
- Option 2: That excludes important misuse and error paths.
- Option 3: Attribution is not required to analyse a consequence.
- Option 4: Availability can fail without malicious code.

**GICSP-Q0207 · single · diagnosis**

What should be stated about local protection in the current model?

Synthetic facility case: a supplier account can reach engineering workstation E through jump host J. E can download controller C projects when an operator-approved maintenance key is enabled. The key is normally disabled, but no record exists for the last shift. HMI and historian both obtain temperature from the same C tag. A high-temperature event occurred after a project download and a cooling maintenance activity. The download used a valid supplier identity. No malware or actor attribution evidence is available. Independent local protection status is not yet collected.

1. Its state and independence are unresolved evidence needs.
2. It must be compromised because the HMI alarmed.
3. It is irrelevant to consequence propagation.
4. It certainly prevented all physical consequences.

**Correct option(s):** 1

- Option 1: The supplied records do not establish its behaviour.
- Option 2: An alarm does not prove protection compromise.
- Option 3: Protection can materially change the outcome.
- Option 4: No supporting status or test is supplied.

**GICSP-Q0208 · single · design**

Which threat statement is most actionable?

Synthetic facility case: a supplier account can reach engineering workstation E through jump host J. E can download controller C projects when an operator-approved maintenance key is enabled. The key is normally disabled, but no record exists for the last shift. HMI and historian both obtain temperature from the same C tag. A high-temperature event occurred after a project download and a cooling maintenance activity. The download used a valid supplier identity. No malware or actor attribution evidence is available. Independent local protection status is not yet collected.

1. Misused supplier access could enable an unauthorised C project download when the maintenance key permits it, impairing thermal control.
2. Hackers may do bad things.
3. All suppliers are malicious.
4. The site is secure because it has a jump host.

**Correct option(s):** 1

- Option 1: It identifies access, action, condition and consequence.
- Option 2: This lacks a testable path and affected function.
- Option 3: This unsupported generalisation is not a threat model.
- Option 4: A device name does not establish effective controls.

**GICSP-Q0209 · single · operations**

When should this threat model be revisited?

Synthetic facility case: a supplier account can reach engineering workstation E through jump host J. E can download controller C projects when an operator-approved maintenance key is enabled. The key is normally disabled, but no record exists for the last shift. HMI and historian both obtain temperature from the same C tag. A high-temperature event occurred after a project download and a cooling maintenance activity. The download used a valid supplier identity. No malware or actor attribution evidence is available. Independent local protection status is not yet collected.

1. Review only the campaign name while leaving local dependencies and operating modes unchanged in the model.
2. When remote access, controller permissions, safeguards or operating modes change.
3. Retain the commissioning model unchanged while adding new remote support capabilities.
4. Wait until a threat actor is conclusively identified before reviewing a changed maintenance path.

**Correct option(s):** 2

- Option 1: The model must track the actual service and authority environment.
- Option 2: These changes alter prerequisites and consequences.
- Option 3: New paths and privileges require reassessment of the original assumptions.
- Option 4: Architecture and authority changes can invalidate the model without attribution.

**GICSP-Q0210 · single · operations**

Who should approve a proposed process-safe containment action?

Synthetic facility case: a supplier account can reach engineering workstation E through jump host J. E can download controller C projects when an operator-approved maintenance key is enabled. The key is normally disabled, but no record exists for the last shift. HMI and historian both obtain temperature from the same C tag. A high-temperature event occurred after a project download and a cooling maintenance activity. The download used a valid supplier identity. No malware or actor attribution evidence is available. Independent local protection status is not yet collected.

1. Whichever analyst first names a threat actor.
2. The delegated operations/process authority using the engineering and incident evidence.
3. The dashboard vendor regardless of site responsibilities.
4. The supplier account automatically.

**Correct option(s):** 2

- Option 1: Naming an actor does not confer operational authority.
- Option 2: Safety consequences require the appropriate owner and competence.
- Option 3: Authority follows the site governance and consequence, not a product label.
- Option 4: Technical access is not decision authority.

#### Recall

**Actor category versus attribution?**

Categories support planning; attribution requires specific corroborated evidence and is not established by a tool, credential or IP alone.

**What makes a threat path actionable?**

Explicit prerequisites, trust crossings, affected functions, consequences, evidence strength and controls that can be verified.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

### GICSP-L022 — Intelligence requirements, provenance and sharing

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L021

Intelligence begins with a decision and a question. “Collect all threat feeds” has no stopping rule and may create a large workload without changing a control. A priority intelligence requirement could ask whether a remotely reachable gateway version used at this site is being exploited through its enabled management service. Specify the assets, time horizon, decision owner and action that new information could change. Collect sources able to answer that question: supplier advisories, government notices, internal logs, relevant peer reporting and technically supported research.

Keep collection, observation and analysis distinct. A report may state that a supplier observed exploitation elsewhere; your own gateway may show only a connection attempt. Those are different observations. Record the original source, publication and event dates, retrieval date, evidence method, affected versions, and any restrictions. Multiple articles repeating one original post are not independent corroboration. Source reliability concerns the source's record and access; information credibility concerns this particular claim. A normally reliable source can publish an uncertain preliminary finding.

Indicators such as hashes, addresses and domains are useful matching keys, not complete verdicts. A file hash identifies bytes, but a renamed or modified payload has another hash. An address may belong to shared hosting, a legitimate update service or reassigned infrastructure. A domain match may represent a blocked lookup rather than a successful session. Preserve context such as direction, action, destination role, time and application. Never equate an indicator match with completed process compromise. Behavioural descriptions can remain useful after infrastructure changes, but they need sufficiently specific collection and interpretation to avoid broad false positives.

Use confidence language consistently. Confidence is a judgment about the evidence supporting an assessment, not the numerical likelihood that an event will occur. If probabilities are used, define their meaning and basis separately. Explain competing hypotheses and what new evidence would change the conclusion. For example, an unusual project download from an approved workstation may be unauthorised use, a legitimate emergency change or a clock/recording issue. The intelligence product should identify which observations support or weaken each possibility rather than simply attaching a red severity label.

Handling restrictions travel with the information. FIRST TLP 2.0 describes sharing boundaries, not an encryption algorithm or a legal classification system. TLP:RED is confined to the individual recipients. TLP:AMBER permits need-to-know sharing within the receiving organisation and its clients, while AMBER+STRICT narrows this to the organisation. GREEN permits community sharing, not public posting; CLEAR removes TLP disclosure limits. Additional source restrictions still matter. When wider disclosure is necessary, obtain the source's permission through the authorised process.

Deliver a concise assessment linked to a decision: what is known, what is inferred, the confidence and limitations, affected local conditions, recommended verification, and the time for review. Keep the raw evidence separately so the conclusion can be checked. Feedback closes the cycle: did the report support a patch, rule review, collection change or incident triage? Retire stale indicators or re-evaluate their context rather than accumulating permanent blocks without ownership. Intelligence should improve the quality of operational decisions, not substitute an external headline for local engineering evidence.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic intelligence packet: Report A dated 12 September describes observed exploitation of Gateway X 4.0–4.2 through enabled service M, and is marked TLP:AMBER+STRICT. Reports B and C quote A without new evidence. Local inventory lists X 4.1 but last verification was six months ago. A firewall record shows DENY from address 203.0.113.44 to M at 03:00; an external feed lists that address as suspicious from July. The address is shared hosting. An analyst writes “three independent sources prove our gateway was compromised.”

**Reasoning:** A, B and C represent one supplied evidence chain. Applicability needs current version and enabled-service verification. The DENY record supports a blocked attempt at that boundary, not a completed compromise; inspect other paths and host evidence as warranted. The July shared-hosting indicator needs context and currency. Limit A to need-to-know recipients in the organisation under AMBER+STRICT and preserve its marking. Replace the unsupported compromise conclusion with a bounded exposure/verification assessment.

#### Guided practice

Rewrite the analyst conclusion in three sentences.

**Hint:** Separate external exploitation, local applicability and observed traffic.

**Worked solution:** One original report describes exploitation elsewhere of specified versions and service conditions. Our stale inventory suggests possible applicability, while the supplied firewall record shows a denied attempt on one path. Verify the deployed baseline and other relevant evidence before concluding local compromise; retain the source sharing restriction.

#### Independent task

Environment: analytical

Create an intelligence assessment and collection plan from the packet.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L022.json

**Evidence to produce**

- Source lineage and confidence table
- Local applicability questions
- Indicator context review
- Authorised dissemination list

**Acceptance criteria**

- Repeated reporting is not counted as independent corroboration.
- Denied traffic is not represented as successful exploitation.
- TLP:AMBER+STRICT remains organisation-limited unless the source authorises wider sharing.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0211 · single · diagnosis**

How many independent evidence origins are supplied by A, B and C?

Synthetic intelligence packet: Report A dated 12 September describes observed exploitation of Gateway X 4.0–4.2 through enabled service M, and is marked TLP:AMBER+STRICT. Reports B and C quote A without new evidence. Local inventory lists X 4.1 but last verification was six months ago. A firewall record shows DENY from address 203.0.113.44 to M at 03:00; an external feed lists that address as suspicious from July. The address is shared hosting. An analyst writes “three independent sources prove our gateway was compromised.”

1. Two.
2. Three.
3. Zero.
4. One.

**Correct option(s):** 4

- Option 1: Neither secondary report adds a new observation independent of A.
- Option 2: B and C repeat A; separate publications do not supply separate observation origins.
- Option 3: A supplies one underlying report; uncertainty about local applicability does not erase that source origin.
- Option 4: B and C repeat A without new evidence.

**GICSP-Q0212 · single · diagnosis**

What does the local DENY record establish?

Synthetic intelligence packet: Report A dated 12 September describes observed exploitation of Gateway X 4.0–4.2 through enabled service M, and is marked TLP:AMBER+STRICT. Reports B and C quote A without new evidence. Local inventory lists X 4.1 but last verification was six months ago. A firewall record shows DENY from address 203.0.113.44 to M at 03:00; an external feed lists that address as suspicious from July. The address is shared hosting. An analyst writes “three independent sources prove our gateway was compromised.”

1. The gateway executed the exploit.
2. The entire site has never been compromised.
3. The recorded attempt was denied at that boundary.
4. The source address is the human attacker's identity.

**Correct option(s):** 3

- Option 1: A deny record is not execution evidence.
- Option 2: One record cannot establish a universal negative.
- Option 3: It does not establish the outcome of other paths or sessions.
- Option 4: Infrastructure addresses do not identify the operator.

**GICSP-Q0213 · single · implementation**

What is the next applicability check for the external vulnerability report?

Synthetic intelligence packet: Report A dated 12 September describes observed exploitation of Gateway X 4.0–4.2 through enabled service M, and is marked TLP:AMBER+STRICT. Reports B and C quote A without new evidence. Local inventory lists X 4.1 but last verification was six months ago. A firewall record shows DENY from address 203.0.113.44 to M at 03:00; an external feed lists that address as suspicious from July. The address is shared hosting. An analyst writes “three independent sources prove our gateway was compromised.”

1. Verify current Gateway X version and whether service M is enabled and reachable.
2. Block every shared-hosting address permanently.
3. Count how often the report was reposted.
4. Assume the six-month-old inventory is exact.

**Correct option(s):** 1

- Option 1: These are the stated affected conditions.
- Option 2: That is broader than the supplied evidence and may disrupt valid services.
- Option 3: Popularity does not establish local exposure.
- Option 4: Configuration may have changed.

**GICSP-Q0214 · single · diagnosis**

Can Report A be forwarded to a client under its supplied marking without further source permission?

Synthetic intelligence packet: Report A dated 12 September describes observed exploitation of Gateway X 4.0–4.2 through enabled service M, and is marked TLP:AMBER+STRICT. Reports B and C quote A without new evidence. Local inventory lists X 4.1 but last verification was six months ago. A firewall record shows DENY from address 203.0.113.44 to M at 03:00; an external feed lists that address as suspicious from July. The address is shared hosting. An analyst writes “three independent sources prove our gateway was compromised.”

1. Yes, if the client receives a password-protected archive.
2. Yes; all AMBER variants automatically include clients.
3. No; AMBER+STRICT restricts it to the receiving organisation.
4. Yes; TLP is a malware severity label.

**Correct option(s):** 3

- Option 1: Transport protection does not expand AMBER+STRICT’s permitted recipient scope.
- Option 2: That ignores the strict restriction.
- Option 3: The strict qualifier narrows ordinary AMBER sharing.
- Option 4: TLP concerns sharing boundaries.

**GICSP-Q0215 · single · mechanism**

What does a hash indicator match most directly show?

Synthetic intelligence packet: Report A dated 12 September describes observed exploitation of Gateway X 4.0–4.2 through enabled service M, and is marked TLP:AMBER+STRICT. Reports B and C quote A without new evidence. Local inventory lists X 4.1 but last verification was six months ago. A firewall record shows DENY from address 203.0.113.44 to M at 03:00; an external feed lists that address as suspicious from July. The address is shared hosting. An analyst writes “three independent sources prove our gateway was compromised.”

1. The compared content has the matching cryptographic digest, subject to the hash method and evidence integrity.
2. The actor has not changed any other files.
3. The process outcome is known.
4. The file was executed successfully.

**Correct option(s):** 1

- Option 1: It is a byte-identification aid, not a complete impact conclusion.
- Option 2: The indicator says nothing about unrelated content.
- Option 3: Impact requires additional evidence.
- Option 4: Presence or matching does not prove execution.

**GICSP-Q0216 · single · diagnosis**

Why should the July address indicator be re-evaluated?

Synthetic intelligence packet: Report A dated 12 September describes observed exploitation of Gateway X 4.0–4.2 through enabled service M, and is marked TLP:AMBER+STRICT. Reports B and C quote A without new evidence. Local inventory lists X 4.1 but last verification was six months ago. A firewall record shows DENY from address 203.0.113.44 to M at 03:00; an external feed lists that address as suspicious from July. The address is shared hosting. An analyst writes “three independent sources prove our gateway was compromised.”

1. Infrastructure ownership, shared use and relevance may have changed.
2. Keep the address blocked indefinitely because an external feed once listed it.
3. Dismiss the indicator solely because the address belongs to shared hosting.
4. Expire the July indicator solely after a fixed thirty days, regardless of current corroboration.

**Correct option(s):** 1

- Option 1: Context and time affect the significance of an address match.
- Option 2: Infrastructure and relevance can change, and broad blocking can affect legitimate services.
- Option 3: Shared hosting can be abused, but a match requires tenant/time context and local evidence.
- Option 4: Validity should follow source and local context rather than an invented universal interval.

**GICSP-Q0217 · single · design**

Which item is a focused intelligence requirement?

Synthetic intelligence packet: Report A dated 12 September describes observed exploitation of Gateway X 4.0–4.2 through enabled service M, and is marked TLP:AMBER+STRICT. Reports B and C quote A without new evidence. Local inventory lists X 4.1 but last verification was six months ago. A firewall record shows DENY from address 203.0.113.44 to M at 03:00; an external feed lists that address as suspicious from July. The address is shared hosting. An analyst writes “three independent sources prove our gateway was compromised.”

1. Collect more indicators without naming a local asset, decision or required evidence.
2. Attribute the campaign before checking whether service M is enabled locally.
3. Determine whether the site's enabled Gateway X service is subject to relevant exploitation so the owner can prioritise treatment.
4. Block the July address first and use the resulting outage as an applicability test.

**Correct option(s):** 3

- Option 1: That is broad collection, not a focused decision-support requirement.
- Option 2: Actor attribution is not the immediate applicability question.
- Option 3: It connects an answer to assets and a decision.
- Option 4: That bypasses current-context assessment and can disrupt shared hosting unnecessarily.

**GICSP-Q0218 · single · mechanism**

How should confidence and probability be treated?

Synthetic intelligence packet: Report A dated 12 September describes observed exploitation of Gateway X 4.0–4.2 through enabled service M, and is marked TLP:AMBER+STRICT. Reports B and C quote A without new evidence. Local inventory lists X 4.1 but last verification was six months ago. A firewall record shows DENY from address 203.0.113.44 to M at 03:00; an external feed lists that address as suspicious from July. The address is shared hosting. An analyst writes “three independent sources prove our gateway was compromised.”

1. Use a numeric percentage without explaining its basis.
2. Treat high confidence as a 100% chance of future compromise.
3. Infer low consequence from low confidence.
4. State evidence confidence separately from any estimated event likelihood.

**Correct option(s):** 4

- Option 1: Unsupported precision can mislead decisions.
- Option 2: Confidence in an assessment is not certainty of a future event.
- Option 3: Uncertain evidence can concern a serious consequence.
- Option 4: They answer different questions and need defined meanings.

**GICSP-Q0219 · multi · design**

Which information should accompany an indicator match? Select all that apply.

Synthetic intelligence packet: Report A dated 12 September describes observed exploitation of Gateway X 4.0–4.2 through enabled service M, and is marked TLP:AMBER+STRICT. Reports B and C quote A without new evidence. Local inventory lists X 4.1 but last verification was six months ago. A firewall record shows DENY from address 203.0.113.44 to M at 03:00; an external feed lists that address as suspicious from July. The address is shared hosting. An analyst writes “three independent sources prove our gateway was compromised.”

1. Time, traffic direction and observed allow/deny or response outcome.
2. The feed’s severity label without the observation date or local matching evidence.
3. The feed’s subscriber count without source provenance or indicator validity.
4. The affected asset's role and relevant application context.

**Correct option(s):** 1, 4

- Option 1: These distinguish attempts and interactions.
- Option 2: A label alone cannot establish relevance or reproduce the match.
- Option 3: Popularity is not independent evidence of current applicability.
- Option 4: The same indicator can have different significance across services.

**GICSP-Q0220 · single · operations**

What closes the intelligence cycle usefully?

Synthetic intelligence packet: Report A dated 12 September describes observed exploitation of Gateway X 4.0–4.2 through enabled service M, and is marked TLP:AMBER+STRICT. Reports B and C quote A without new evidence. Local inventory lists X 4.1 but last verification was six months ago. A firewall record shows DENY from address 203.0.113.44 to M at 03:00; an external feed lists that address as suspicious from July. The address is shared hosting. An analyst writes “three independent sources prove our gateway was compromised.”

1. Keep every indicator blocked permanently.
2. Archive every report without reviewing outcomes.
3. Declare compromise whenever two feeds agree.
4. Check whether the assessment informed the intended decision and update unanswered requirements.

**Correct option(s):** 4

- Option 1: Context and operational consequences change.
- Option 2: Storage alone does not improve decisions.
- Option 3: Agreement can be derivative or contextually insufficient.
- Option 4: Feedback measures practical usefulness and directs further collection.

#### Recall

**What is independent corroboration?**

Evidence with an independent observation basis, not merely several publications repeating one report.

**What does TLP govern?**

Recipient sharing boundaries; it does not itself specify encryption, legal classification or technical severity.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [FIRST TLP version 2.0](https://www.first.org/tlp/)
- [CISA ICS advisories](https://www.cisa.gov/news-events/ics-advisories)

### GICSP-L023 — Attack paths, trust boundaries and treatment selection

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L022

An attack graph represents actions and prerequisites, not a prediction that every path will be used. Start from a defined initial capability, such as control of an ordinary enterprise workstation or possession of a supplier password. Enumerate reachable services and the authority required to use them. For each transition record the trust boundary, authentication, authorisation, software exposure and resulting privilege. A network route is only one prerequisite; a route to an engineering workstation does not automatically provide an authenticated desktop or controller-download authority.

AND and OR relationships matter. A path may require both VPN authentication and jump-host authorisation, while a separate local maintenance port offers an alternative route. Removing one condition in an AND path can break that path; it does not remove a separate OR path. Shared identity systems create dependencies: if the same compromised administrator can reset both the VPN and jump-host credentials, apparent independent barriers may share one authority root. Model actual administrative control, not just the count of login screens.

Use a data-flow diagram to expose what crosses each boundary: telemetry, commands, project files, authentication assertions, logs and backups. Identify who can originate each flow and what the receiver trusts. A read-only telemetry export reduces one command path but does not by itself protect the exporter from local code execution or its management interface. A unidirectional transfer design has a defined direction and support mechanisms; prove the complete arrangement rather than assuming all maintenance and acknowledgement paths are also one-way.

Select treatment according to the failed prerequisite or consequence. MFA may reduce misuse of a stolen password but does not stop an already-authorised session from making an excessive change. Least privilege can constrain actions after authentication. Application-aware authorisation can distinguish reads from writes if the implementation truly understands and enforces the operation. Segmentation limits reachability; hardening reduces attack surface; monitoring improves discovery; independent protection can limit physical consequences. These controls are complementary because they address different transitions and outcomes.

Evaluate residual paths explicitly. If an ACL blocks the remote engineering flow, consider local console access, a dual-homed laptop, removable media and privileged infrastructure administration where relevant. This is not a demand to imagine limitless attacks; keep the analysis tied to documented interfaces and plausible capabilities. Record assumptions and a bounded scope. A path that depends on an unavailable credential or disabled service remains a hypothesis unless those conditions can be established. Distinguish reachable, exploitable and consequential states.

Verification follows the graph. Test authorised traffic, denied traffic and the actual application operation under a controlled plan. Review whether established sessions and alternative protocols bypass the intended boundary. Test degraded operation and recovery because a control that blocks required alarms during failure may be unacceptable. Retain the baseline and evidence for each transition. The owner then receives a clear residual-risk statement: which paths were broken, which remain, what monitoring can detect them and which consequence assumptions still need specialist confirmation.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic paths to controller C: Path A requires supplier password + VPN MFA + jump-host role + E download privilege + maintenance key. Path B is a site laptop connected directly to a maintenance switch, requiring E-compatible software + C credential + maintenance key. One directory administrator can reset VPN recovery factors and jump-host roles. Proposed control T blocks J→E TCP 3389 but leaves an approved HTTPS remote-console service on E. C's legacy protocol has no per-command user identity. A local protection system is on separate hardware but shares C's temperature transmitter.

**Reasoning:** The path graph has two alternatives and multiple conjunctive prerequisites. Blocking TCP 3389 addresses one transport, while the HTTPS console may preserve the intended remote capability. Directory control is a common authority dependency across nominally separate barriers. Path B survives a J-only rule. C command attribution may require trusted gateway/engineering evidence because the legacy payload lacks a user identity. Separate protection hardware does not prove sensing independence when both rely on the same transmitter.

#### Guided practice

Identify a treatment and verification for each surviving path.

**Hint:** Break an actual prerequisite and retain the required maintenance function.

**Worked solution:** Constrain both remote-console services through approved identities/roles and session control; enforce physical/port and maintenance-laptop controls for B; verify controller permission/key behaviour; review shared identity reset authority and sensor dependence with the relevant owners.

#### Independent task

Environment: analytical

Draw a bounded attack graph and write a residual-path test plan.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L023.json

**Evidence to produce**

- AND/OR prerequisite graph
- Identity and sensor common-cause notes
- Treatment-to-transition mapping
- Positive/negative/degraded tests

**Acceptance criteria**

- Blocking RDP alone is not presented as blocking every console.
- The local maintenance path remains explicit.
- Separate hardware is not assumed to imply independent measurement.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0221 · single · mechanism**

Which condition best describes Path A?

Synthetic paths to controller C: Path A requires supplier password + VPN MFA + jump-host role + E download privilege + maintenance key. Path B is a site laptop connected directly to a maintenance switch, requiring E-compatible software + C credential + maintenance key. One directory administrator can reset VPN recovery factors and jump-host roles. Proposed control T blocks J→E TCP 3389 but leaves an approved HTTPS remote-console service on E. C's legacy protocol has no per-command user identity. A local protection system is on separate hardware but shares C's temperature transmitter.

1. Any one of the password, MFA or maintenance-key conditions is sufficient for Path A.
2. Jump-host access supplies C’s download authority without the separate E privilege and maintenance key.
3. Blocking RDP removes Path A even though the approved HTTPS remote-console service remains.
4. All five listed prerequisites must hold for the described path.

**Correct option(s):** 4

- Option 1: The stated path requires their conjunction along with role and download privilege.
- Option 2: Those are additional prerequisites explicitly listed in the path.
- Option 3: The alternate remote-console capability can preserve the path.
- Option 4: It is an AND chain, not a list of interchangeable options.

**GICSP-Q0222 · single · diagnosis**

What survives proposed control T?

Synthetic paths to controller C: Path A requires supplier password + VPN MFA + jump-host role + E download privilege + maintenance key. Path B is a site laptop connected directly to a maintenance switch, requiring E-compatible software + C credential + maintenance key. One directory administrator can reset VPN recovery factors and jump-host roles. Proposed control T blocks J→E TCP 3389 but leaves an approved HTTPS remote-console service on E. C's legacy protocol has no per-command user identity. A local protection system is on separate hardware but shares C's temperature transmitter.

1. The HTTPS console path to E, subject to its own permissions.
2. No remote capability can survive a port rule.
3. No remote-console capability remains because RDP was the first path listed.
4. Only telemetry remains because the surviving service uses HTTPS.

**Correct option(s):** 1

- Option 1: Blocking TCP 3389 does not block the supplied alternate service.
- Option 2: Multiple services can provide similar capability.
- Option 3: The approved HTTPS remote-console service remains available.
- Option 4: HTTPS can carry an administrative console; transport encryption does not make the application read-only.

**GICSP-Q0223 · single · diagnosis**

What is the shared identity risk in this design?

Synthetic paths to controller C: Path A requires supplier password + VPN MFA + jump-host role + E download privilege + maintenance key. Path B is a site laptop connected directly to a maintenance switch, requiring E-compatible software + C credential + maintenance key. One directory administrator can reset VPN recovery factors and jump-host roles. Proposed control T blocks J→E TCP 3389 but leaves an approved HTTPS remote-console service on E. C's legacy protocol has no per-command user identity. A local protection system is on separate hardware but shares C's temperature transmitter.

1. Every user can necessarily reset all factors.
2. The maintenance key is stored in DNS.
3. MFA and jump hosts can never be used together.
4. One administrator can modify both VPN recovery and jump-host authority.

**Correct option(s):** 4

- Option 1: Only the specified administrator capability is supplied.
- Option 2: No such dependency is described.
- Option 3: They can complement each other when dependencies are understood.
- Option 4: The two barriers share a privileged control root.

**GICSP-Q0224 · single · diagnosis**

Does a J→E block remove Path B?

Synthetic paths to controller C: Path A requires supplier password + VPN MFA + jump-host role + E download privilege + maintenance key. Path B is a site laptop connected directly to a maintenance switch, requiring E-compatible software + C credential + maintenance key. One directory administrator can reset VPN recovery factors and jump-host roles. Proposed control T blocks J→E TCP 3389 but leaves an approved HTTPS remote-console service on E. C's legacy protocol has no per-command user identity. A local protection system is on separate hardware but shares C's temperature transmitter.

1. Only if the log contains a username.
2. No; Path B uses a direct maintenance connection.
3. Yes if the block is logged.
4. Yes; all controller access must traverse J by definition.

**Correct option(s):** 2

- Option 1: Attribution fields do not block the direct route.
- Option 2: Its prerequisites do not include J.
- Option 3: Logging does not change topology.
- Option 4: The case explicitly supplies an alternative path.

**GICSP-Q0225 · single · design**

Which control most directly addresses excessive actions by an already authenticated engineer?

Synthetic paths to controller C: Path A requires supplier password + VPN MFA + jump-host role + E download privilege + maintenance key. Path B is a site laptop connected directly to a maintenance switch, requiring E-compatible software + C credential + maintenance key. One directory administrator can reset VPN recovery factors and jump-host roles. Proposed control T blocks J→E TCP 3389 but leaves an approved HTTPS remote-console service on E. C's legacy protocol has no per-command user identity. A local protection system is on separate hardware but shares C's temperature transmitter.

1. Only encrypting the network link.
2. Enforced least privilege and operation-specific authorisation.
3. Only another password prompt with the same unrestricted role.
4. Only hiding the controller name.

**Correct option(s):** 2

- Option 1: Encryption protects transport, not the legitimacy of an authorised action.
- Option 2: Authentication alone does not restrict permitted actions sufficiently.
- Option 3: It adds authentication without narrowing authority.
- Option 4: Obscurity does not enforce permissions.

**GICSP-Q0226 · single · diagnosis**

Why is separate protection hardware not enough to establish independence here?

Synthetic paths to controller C: Path A requires supplier password + VPN MFA + jump-host role + E download privilege + maintenance key. Path B is a site laptop connected directly to a maintenance switch, requiring E-compatible software + C credential + maintenance key. One directory administrator can reset VPN recovery factors and jump-host roles. Proposed control T blocks J→E TCP 3389 but leaves an approved HTTPS remote-console service on E. C's legacy protocol has no per-command user identity. A local protection system is on separate hardware but shares C's temperature transmitter.

1. The common transmitter can be ignored because its value is displayed by two systems.
2. Matching operating systems would make the two protection measurements independent.
3. The shared transmitter can feed a common erroneous measurement to both systems.
4. Separate protection hardware is sufficient despite sharing C’s transmitter.

**Correct option(s):** 3

- Option 1: Multiple consumers do not provide independent sensing.
- Option 2: Software similarity does not remove the shared transmitter.
- Option 3: Independence must consider inputs as well as hardware.
- Option 4: The shared measurement creates a common dependency that must be assessed.

**GICSP-Q0227 · single · mechanism**

Which distinction is correct for a reachable service?

Synthetic paths to controller C: Path A requires supplier password + VPN MFA + jump-host role + E download privilege + maintenance key. Path B is a site laptop connected directly to a maintenance switch, requiring E-compatible software + C credential + maintenance key. One directory administrator can reset VPN recovery factors and jump-host roles. Proposed control T blocks J→E TCP 3389 but leaves an approved HTTPS remote-console service on E. C's legacy protocol has no per-command user identity. A local protection system is on separate hardware but shares C's temperature transmitter.

1. Reachability does not by itself prove exploitability or harmful process effect.
2. A firewall allow automatically authenticates the application user.
3. Unreachable services can never become reachable after change.
4. Every reachable service is already compromised.

**Correct option(s):** 1

- Option 1: Further software, authority and consequence conditions are needed.
- Option 2: Transport permission and identity are different layers.
- Option 3: Configuration and topology can change.
- Option 4: A possible path is not an observed intrusion.

**GICSP-Q0228 · single · diagnosis**

What is needed to attribute a legacy C command to a human?

Synthetic paths to controller C: Path A requires supplier password + VPN MFA + jump-host role + E download privilege + maintenance key. Path B is a site laptop connected directly to a maintenance switch, requiring E-compatible software + C credential + maintenance key. One directory administrator can reset VPN recovery factors and jump-host roles. Proposed control T blocks J→E TCP 3389 but leaves an approved HTTPS remote-console service on E. C's legacy protocol has no per-command user identity. A local protection system is on separate hardware but shares C's temperature transmitter.

1. A universal username field assumed to exist in every protocol.
2. The TCP port alone.
3. The controller model number.
4. Correlated trusted access and engineering evidence with timing and scope limits.

**Correct option(s):** 4

- Option 1: The case explicitly says it is absent.
- Option 2: It identifies a service convention, not a person.
- Option 3: Product identity does not identify the operator.
- Option 4: The supplied protocol lacks a direct per-command user identity.

**GICSP-Q0229 · multi · design**

Which verification set tests the remote-console treatment meaningfully? Select all that apply.

Synthetic paths to controller C: Path A requires supplier password + VPN MFA + jump-host role + E download privilege + maintenance key. Path B is a site laptop connected directly to a maintenance switch, requiring E-compatible software + C credential + maintenance key. One directory administrator can reset VPN recovery factors and jump-host roles. Proposed control T blocks J→E TCP 3389 but leaves an approved HTTPS remote-console service on E. C's legacy protocol has no per-command user identity. A local protection system is on separate hardware but shares C's temperature transmitter.

1. Existing-session revocation and recovery behaviour.
2. Only a screenshot of the rule name.
3. Only a ping to the jump host.
4. Approved console use and denied unauthorised use on each enabled service.

**Correct option(s):** 1, 4

- Option 1: State and failure handling can preserve unintended access.
- Option 2: A label does not prove runtime behaviour.
- Option 3: ICMP reachability does not test console permissions.
- Option 4: This tests function and enforcement across alternatives.

**GICSP-Q0230 · single · operations**

What should a residual-risk statement identify?

Synthetic paths to controller C: Path A requires supplier password + VPN MFA + jump-host role + E download privilege + maintenance key. Path B is a site laptop connected directly to a maintenance switch, requiring E-compatible software + C credential + maintenance key. One directory administrator can reset VPN recovery factors and jump-host roles. Proposed control T blocks J→E TCP 3389 but leaves an approved HTTPS remote-console service on E. C's legacy protocol has no per-command user identity. A local protection system is on separate hardware but shares C's temperature transmitter.

1. A claim that no future attack is possible.
2. Only the first path discovered.
3. Surviving paths, verified barriers and unresolved consequence assumptions.
4. Only the number of purchased security products.

**Correct option(s):** 3

- Option 1: The bounded analysis cannot establish that universal guarantee.
- Option 2: Known alternatives materially affect the conclusion.
- Option 3: These support an informed owner decision.
- Option 4: Product count does not explain residual paths.

#### Recall

**AND path versus OR path?**

Every prerequisite in an AND path is required; an OR alternative can remain even when another path is broken.

**Why count administrative roots?**

Controls managed by the same compromised authority may share a failure cause despite separate interfaces or login screens.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

### GICSP-L024 — Vulnerability applicability and treatment priority

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L023

A vulnerability identifier describes a weakness, not the complete local risk. Start by matching the exact product, version, component, enabled feature and configuration to the supplier's affected conditions. A scanner banner can be useful but stale, proxied or incomplete; a library name in an SBOM can identify a dependency without proving that the vulnerable code path is used. Resolve uncertain applicability with supported inventory and supplier information before changing a production system. Do not run an exploit simply to settle an inventory question.

Separate severity from exposure and consequence. A base severity score describes technical characteristics under the scoring model. It does not know the site's process mode, safeguards, asset criticality, reachable paths or outage restrictions. Evidence of exploitation in the wild raises urgency but does not prove that a particular local device is compromised. Conversely, a lower-scored weakness on a reachable high-consequence control path may deserve earlier attention than a higher-scored weakness in a disabled optional feature. State the assumptions behind prioritisation instead of sorting by one number.

Exposure includes more than Internet reachability. A remote supplier, engineering workstation, removable medium or compromised management host can reach services that have no public address. Segmentation can reduce the set of possible sources, but an allowed jump host may still provide a route. Check alternative management interfaces and IPv6 where applicable. A compensating control is credible only when it blocks or reduces the relevant mechanism and remains operationally acceptable. Additional logging can improve detection but does not remove a writable vulnerable service.

Treatment choices include a supported update, feature disablement, privilege reduction, constrained connectivity, temporary isolation, replacement or an explicitly accepted residual risk. Each choice has conditions and side effects. A vendor workaround that disables an unused management service may be effective and low impact; the same workaround may be unacceptable if the service is required for alarms. A patch may alter drivers, schemas or timing. Plan compatibility checks, recovery materials, acceptance criteria and rollback feasibility before deployment. Unsupported rollback is not a safe fallback merely because a snapshot exists.

An exception needs a bounded rationale, owner, compensating controls, review trigger and expiry or milestone. “Cannot patch OT” is not an engineering analysis. Record why the update cannot currently be applied, what exposure remains, what controls reduce it, how their health is observed, and what event changes the decision. A planned outage or replacement can close the constraint. If a mitigation fails or exploitation changes, reassess rather than waiting for the original calendar date.

Close the treatment with evidence. Confirm the intended version or configuration, the absence or restriction of the vulnerable path, required functional performance and the state of monitoring and recovery. A green scanner result can be caused by loss of visibility; verify that the scanner or passive inventory can still observe the relevant asset. Preserve the prior baseline and decision record. Vulnerability management is a repeating lifecycle of applicability, prioritisation, treatment and assurance, not a one-time list of numbers or a count of patched devices.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic advisory set: V-A score 9.8 affects Gateway X 4.1 only when optional web-upload feature U is enabled; X at this site has U disabled, confirmed by signed configuration export. V-B score 7.5 affects Controller C remote-management service R, reachable from the supplier jump host; C supports a high-consequence cooling loop. A supplier-approved workaround disables R while preserving local control, but removes remote diagnostics. A patch changes C's configuration schema and cannot be downgraded. Current IDS sees only enterprise-to-DMZ traffic, not J→C. No local exploitation evidence is supplied.

**Reasoning:** V-A's required feature condition is absent in the verified baseline; retain change monitoring and supplier applicability confirmation. V-B has a relevant reachable service and consequence despite a lower score. Consider the approved workaround with an operations plan for diagnostics, then schedule a tested patch/recovery path. The IDS cannot be credited for J→C visibility. Do not infer local compromise from exposure, or promise downgrade after the schema change.

#### Guided practice

Write a defensible priority note for V-A and V-B.

**Hint:** Use affected conditions, exposure and consequence, then treatment constraints.

**Worked solution:** Prioritise V-B verification/treatment because R is reachable on a consequential service. V-A currently lacks its stated enabling condition; monitor feature changes and retain evidence. Coordinate R disablement and diagnostic alternatives with operations; test the irreversible schema migration and recovery route before patching.

#### Independent task

Environment: analytical

Build an applicability and treatment register for both findings.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L024.json

**Evidence to produce**

- Evidence-backed applicability assessment
- Temporary control verification
- Patch acceptance and recovery plan
- Exception triggers and owners

**Acceptance criteria**

- Scores are not treated as complete local risk.
- IDS visibility is limited to its actual capture scope.
- Irreversible migration has a supported recovery method rather than assumed downgrade.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0231 · single · diagnosis**

Which finding currently lacks a stated enabling condition?

Synthetic advisory set: V-A score 9.8 affects Gateway X 4.1 only when optional web-upload feature U is enabled; X at this site has U disabled, confirmed by signed configuration export. V-B score 7.5 affects Controller C remote-management service R, reachable from the supplier jump host; C supports a high-consequence cooling loop. A supplier-approved workaround disables R while preserving local control, but removes remote diagnostics. A patch changes C's configuration schema and cannot be downgraded. Current IDS sees only enterprise-to-DMZ traffic, not J→C. No local exploitation evidence is supplied.

1. V-B lacks an enabling condition because its score is lower than V-A’s.
2. Neither finding applies because no local exploitation has yet been observed.
3. V-A, because U is verified disabled.
4. Both findings have all enabling conditions because their affected versions are installed.

**Correct option(s):** 3

- Option 1: The reachable R service is an explicit local enabling condition independent of score.
- Option 2: Vulnerability applicability and observed exploitation are different questions.
- Option 3: The supplied advisory makes U an applicability condition.
- Option 4: V-A additionally requires U, which is verified disabled.

**GICSP-Q0232 · single · diagnosis**

Why might V-B merit earlier treatment despite its lower score?

Synthetic advisory set: V-A score 9.8 affects Gateway X 4.1 only when optional web-upload feature U is enabled; X at this site has U disabled, confirmed by signed configuration export. V-B score 7.5 affects Controller C remote-management service R, reachable from the supplier jump host; C supports a high-consequence cooling loop. A supplier-approved workaround disables R while preserving local control, but removes remote diagnostics. A patch changes C's configuration schema and cannot be downgraded. Current IDS sees only enterprise-to-DMZ traffic, not J→C. No local exploitation evidence is supplied.

1. It has a reachable affected service on a high-consequence loop.
2. Every cooling asset must be patched without testing.
3. A score of 7.5 always outranks 9.8.
4. The absence of exploitation evidence proves immediate exploitation.

**Correct option(s):** 1

- Option 1: Local exposure and consequence change priority.
- Option 2: Operational compatibility and safe change remain necessary.
- Option 3: No universal reversed ranking exists.
- Option 4: Exposure and observed compromise are different.

**GICSP-Q0233 · single · diagnosis**

What does disabling R trade off in this case?

Synthetic advisory set: V-A score 9.8 affects Gateway X 4.1 only when optional web-upload feature U is enabled; X at this site has U disabled, confirmed by signed configuration export. V-B score 7.5 affects Controller C remote-management service R, reachable from the supplier jump host; C supports a high-consequence cooling loop. A supplier-approved workaround disables R while preserving local control, but removes remote diagnostics. A patch changes C's configuration schema and cannot be downgraded. Current IDS sees only enterprise-to-DMZ traffic, not J→C. No local exploitation evidence is supplied.

1. It patches the schema automatically.
2. It removes the affected remote-management path but also remote diagnostics.
3. It makes all credentials irrelevant.
4. It necessarily stops the local control loop.

**Correct option(s):** 2

- Option 1: Service disablement is a workaround, not installation of the patch.
- Option 2: The workaround preserves local control while changing support capability.
- Option 3: Other access and recovery mechanisms still require control.
- Option 4: The supplier explicitly states local control is preserved.

**GICSP-Q0234 · single · diagnosis**

Can the current IDS be credited with detecting misuse on J→C?

Synthetic advisory set: V-A score 9.8 affects Gateway X 4.1 only when optional web-upload feature U is enabled; X at this site has U disabled, confirmed by signed configuration export. V-B score 7.5 affects Controller C remote-management service R, reachable from the supplier jump host; C supports a high-consequence cooling loop. A supplier-approved workaround disables R while preserving local control, but removes remote diagnostics. A patch changes C's configuration schema and cannot be downgraded. Current IDS sees only enterprise-to-DMZ traffic, not J→C. No local exploitation evidence is supplied.

1. Yes if the rule contains C's IP address.
2. No; the supplied observation point excludes that flow.
3. Credit the IDS because V-B has a published vulnerability score.
4. Credit the IDS because its product supports the controller protocol in principle.

**Correct option(s):** 2

- Option 1: A rule cannot inspect traffic it never receives.
- Option 2: Detection claims require relevant visibility.
- Option 3: A score does not establish local traffic visibility or an implemented analytic.
- Option 4: The current observation point does not see J→C traffic.

**GICSP-Q0235 · single · diagnosis**

What is wrong with planning a simple downgrade after the C patch?

Synthetic advisory set: V-A score 9.8 affects Gateway X 4.1 only when optional web-upload feature U is enabled; X at this site has U disabled, confirmed by signed configuration export. V-B score 7.5 affects Controller C remote-management service R, reachable from the supplier jump host; C supports a high-consequence cooling loop. A supplier-approved workaround disables R while preserving local control, but removes remote diagnostics. A patch changes C's configuration schema and cannot be downgraded. Current IDS sees only enterprise-to-DMZ traffic, not J→C. No local exploitation evidence is supplied.

1. The network configuration backup reverses the controller’s storage-schema migration.
2. A lower version number guarantees restore success.
3. The old firmware file is sufficient rollback evidence after the schema change.
4. The supplied schema change is not downgrade-compatible.

**Correct option(s):** 4

- Option 1: Those artefacts cover different state and cannot be assumed interchangeable.
- Option 2: Version order is not a recovery method.
- Option 3: An unsupported downgrade and changed schema require a tested alternative recovery plan.
- Option 4: Recovery must use a supported alternative.

**GICSP-Q0236 · single · diagnosis**

Which evidence would challenge the current V-A assessment?

Synthetic advisory set: V-A score 9.8 affects Gateway X 4.1 only when optional web-upload feature U is enabled; X at this site has U disabled, confirmed by signed configuration export. V-B score 7.5 affects Controller C remote-management service R, reachable from the supplier jump host; C supports a high-consequence cooling loop. A supplier-approved workaround disables R while preserving local control, but removes remote diagnostics. A patch changes C's configuration schema and cannot be downgraded. Current IDS sees only enterprise-to-DMZ traffic, not J→C. No local exploitation evidence is supplied.

1. The fact that V-B was patched.
2. An unchanged configuration export with U disabled.
3. A changed dashboard severity label without any new feature-state evidence.
4. A later approved or unauthorised change enables U.

**Correct option(s):** 4

- Option 1: A different asset's treatment does not change U.
- Option 2: This supports, rather than challenges, the assessment.
- Option 3: The current assessment depends on U being disabled, not the display label.
- Option 4: That would satisfy the previously absent condition.

**GICSP-Q0237 · multi · design**

Which elements make a temporary exception reviewable? Select all that apply.

Synthetic advisory set: V-A score 9.8 affects Gateway X 4.1 only when optional web-upload feature U is enabled; X at this site has U disabled, confirmed by signed configuration export. V-B score 7.5 affects Controller C remote-management service R, reachable from the supplier jump host; C supports a high-consequence cooling loop. A supplier-approved workaround disables R while preserving local control, but removes remote diagnostics. A patch changes C's configuration schema and cannot be downgraded. Current IDS sees only enterprise-to-DMZ traffic, not J→C. No local exploitation evidence is supplied.

1. A review trigger and planned treatment milestone.
2. A permanent waiver without configuration scope.
3. The specific exposure, responsible owner and measurable compensating control.
4. Only the phrase “OT cannot be patched.”

**Correct option(s):** 1, 3

- Option 1: They prevent an indefinite unexplained exception.
- Option 2: Changed conditions could invalidate the rationale.
- Option 3: These explain what remains and who manages it.
- Option 4: It omits the actual compatibility and treatment analysis.

**GICSP-Q0238 · single · diagnosis**

What should be checked if the scanner stops reporting V-B immediately after a firewall change?

Synthetic advisory set: V-A score 9.8 affects Gateway X 4.1 only when optional web-upload feature U is enabled; X at this site has U disabled, confirmed by signed configuration export. V-B score 7.5 affects Controller C remote-management service R, reachable from the supplier jump host; C supports a high-consequence cooling loop. A supplier-approved workaround disables R while preserving local control, but removes remote diagnostics. A patch changes C's configuration schema and cannot be downgraded. Current IDS sees only enterprise-to-DMZ traffic, not J→C. No local exploitation evidence is supplied.

1. Whether the finding disappeared because the scanner lost visibility.
2. Delete the asset from scope.
3. Assume the firmware was patched remotely.
4. Conclude the controller was removed from service.

**Correct option(s):** 1

- Option 1: Reduced observation is not necessarily remediation.
- Option 2: Scope depends on function and responsibility, not scanner reachability.
- Option 3: No patch installation evidence is supplied.
- Option 4: A missing scan response does not establish retirement.

**GICSP-Q0239 · single · diagnosis**

What does public exploitation evidence establish about a local device?

Synthetic advisory set: V-A score 9.8 affects Gateway X 4.1 only when optional web-upload feature U is enabled; X at this site has U disabled, confirmed by signed configuration export. V-B score 7.5 affects Controller C remote-management service R, reachable from the supplier jump host; C supports a high-consequence cooling loop. A supplier-approved workaround disables R while preserving local control, but removes remote diagnostics. A patch changes C's configuration schema and cannot be downgraded. Current IDS sees only enterprise-to-DMZ traffic, not J→C. No local exploitation evidence is supplied.

1. The weakness is being exploited somewhere described by the source, while local compromise still needs evidence.
2. The device can be safely exploited for confirmation.
3. A patch is guaranteed compatible with all deployments.
4. Every affected local device is already compromised.

**Correct option(s):** 1

- Option 1: Threat relevance and local incident status are distinct.
- Option 2: Production testing requires separate authority and risk assessment.
- Option 3: Exploitation evidence says nothing about local compatibility.
- Option 4: Applicability does not prove execution.

**GICSP-Q0240 · single · implementation**

Which closure evidence is strongest after R disablement?

Synthetic advisory set: V-A score 9.8 affects Gateway X 4.1 only when optional web-upload feature U is enabled; X at this site has U disabled, confirmed by signed configuration export. V-B score 7.5 affects Controller C remote-management service R, reachable from the supplier jump host; C supports a high-consequence cooling loop. A supplier-approved workaround disables R while preserving local control, but removes remote diagnostics. A patch changes C's configuration schema and cannot be downgraded. Current IDS sees only enterprise-to-DMZ traffic, not J→C. No local exploitation evidence is supplied.

1. A change ticket marked complete before testing.
2. Only the controller's uptime counter.
3. Verified R denial plus normal local control and approved diagnostic alternatives.
4. Only the supplier's generic workaround article.

**Correct option(s):** 3

- Option 1: Administrative closure is not behaviour evidence.
- Option 2: Uptime does not prove R is unavailable.
- Option 3: It tests both mitigation and required operation.
- Option 4: The article supports the method but not this execution.

#### Recall

**Severity versus local risk?**

Severity is one input; local applicability, reachability, consequence, safeguards and treatment constraints determine the engineering decision.

**Why can a missing scanner finding mislead?**

The asset or service may have become invisible to the scanner rather than remediated.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [CISA ICS advisories](https://www.cisa.gov/news-events/ics-advisories)

### GICSP-L025 — Technique models, detection opportunities and control validation

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L024

Behavioural frameworks provide a common language for actions such as using valid accounts, transferring a project or inhibiting an alarm. They are not a compulsory linear sequence that every incident follows. An adversary may repeat a stage, skip an action or use several paths in parallel. A legitimate engineer can also perform actions described by a technique. Map the observable behaviour and context; do not treat a technique label as proof of malicious intent or actor identity.

Work backwards from the consequence to potential observations. If an attacker changes a controller programme, useful evidence may include the engineering tool session, controller change record, project hash or semantic comparison, operating-mode transition and process response. Each source has limitations. A network sensor may identify a download service without reconstructing the programme. A project hash detects byte changes but may change for benign metadata. A semantic comparison can identify altered logic but depends on the tool, baseline and completeness of the extracted project. A controller log may roll over or lack a reliable clock.

A detection hypothesis needs an observable condition and a reason it matters. “Alert on all engineering traffic” is usually too broad. A more useful hypothesis might detect a controller download outside an approved window from a source not in the authorised engineering set, then correlate with project and mode changes. The rule must define source identity, asset mapping, time zone, approved-window data, exceptions and missing-data behaviour. If the approval feed is unavailable, silently treating every change as approved creates a dangerous blind spot.

Test detections with labelled benign and suspicious examples. Include legitimate maintenance, denied attempts, retries, clock skew, duplicated logs and collection failures. Distinguish a rule firing from an analyst being able to reach the correct conclusion. A true alert with no asset owner or process context may still delay response. Measure both detection behaviour and the operational workflow: who receives the alert, what evidence is preserved, what safe actions are permitted and how uncertainty is escalated. Synthetic replay establishes performance on the supplied cases, not universal coverage.

Coverage is a set of supported claims. A matrix cell coloured green should link to a deployed data source, an implemented analytic, validated examples, known exclusions and an owner. Merely purchasing a product or writing a query is not evidence that the data arrives and the rule operates. Track sensor health separately from quiet process behaviour. A sensor outage can produce a perfect-looking zero-alert chart while all monitored actions go unseen.

Controls can prevent, detect, contain or help recover from different parts of the path. Evaluate them at those specific functions. MFA may reduce credential misuse, a role restriction may prevent a download, a change analytic may detect it, and a trusted project baseline may support recovery. One successful control does not prove the others work. Preserve the attack-path assumptions, test evidence and residual gaps so the next engineer can maintain the model after a firmware, topology or workflow change.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic labelled replay: E1 approved engineer downloads P2 during window W; E2 unknown laptop attempts a download outside W but controller denies it; E3 approved engineer downloads P3 outside W and controller accepts; E4 sensor heartbeat stops and no controller events arrive for 40 minutes. Rule D alerts only when source is unknown. The rule sees E2, misses E3 and reports no events for E4. A project hash changes between P2 and P3, but the exporter also includes a changing timestamp. Approval-feed outage behaviour is “treat missing window as approved.”

**Reasoning:** D detects source novelty, not all unauthorised changes; E3 demonstrates the gap. E2 is a denied attempt and must not be reported as a completed download. E4 is unknown visibility, not confirmed absence of changes. Add operation/outcome/window context and a separately surfaced approval-feed health state. A hash difference alone cannot isolate logic changes when export metadata varies; perform a supported semantic comparison against the approved baseline.

#### Guided practice

Draft two complementary analytics and their negative tests.

**Hint:** Separate change legitimacy from collection health.

**Worked solution:** Analytic one correlates accepted download, authorised identity and valid work window; test E1 benign, E2 denied and E3 accepted outside window. Analytic two raises loss-of-visibility status for missing heartbeat/data with expected collection cadence, using E4 and a known quiet-but-healthy period.

#### Independent task

Environment: analytical

Create a traceable detection coverage entry and replay evaluation.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L025.json

**Evidence to produce**

- Behaviour-to-data mapping
- Two analytic specifications
- Labelled expected results
- Residual visibility and attribution limits

**Acceptance criteria**

- Attempted and accepted actions are distinguished.
- Sensor silence is not automatically normal operation.
- Project byte differences are separated from semantic changes.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0241 · single · diagnosis**

Which replay event proves that source novelty alone misses a consequential change condition?

Synthetic labelled replay: E1 approved engineer downloads P2 during window W; E2 unknown laptop attempts a download outside W but controller denies it; E3 approved engineer downloads P3 outside W and controller accepts; E4 sensor heartbeat stops and no controller events arrive for 40 minutes. Rule D alerts only when source is unknown. The rule sees E2, misses E3 and reports no events for E4. A project hash changes between P2 and P3, but the exporter also includes a changing timestamp. Approval-feed outage behaviour is “treat missing window as approved.”

1. E1 should alert because every project download changes the baseline.
2. E3 is approved because its source identity is familiar.
3. E3.
4. E2 proves an accepted unauthorised runtime change.

**Correct option(s):** 3

- Option 1: E1 has the approved engineer and window context; the intended rule concerns unauthorised changes.
- Option 2: The accepted download is outside the authorised window despite the known source.
- Option 3: A known engineer source performed an accepted out-of-window download.
- Option 4: The controller denies E2, so it is an attempt rather than accepted change.

**GICSP-Q0242 · single · diagnosis**

How should E2 be described?

Synthetic labelled replay: E1 approved engineer downloads P2 during window W; E2 unknown laptop attempts a download outside W but controller denies it; E3 approved engineer downloads P3 outside W and controller accepts; E4 sensor heartbeat stops and no controller events arrive for 40 minutes. Rule D alerts only when source is unknown. The rule sees E2, misses E3 and reports no events for E4. A project hash changes between P2 and P3, but the exporter also includes a changing timestamp. Approval-feed outage behaviour is “treat missing window as approved.”

1. A sensor outage.
2. A successful malicious programme replacement.
3. An out-of-window download attempt from an unknown laptop that the controller denied.
4. Confirmed harmless traffic because it failed.

**Correct option(s):** 3

- Option 1: The event was observed and has a controller result.
- Option 2: The supplied outcome is denial.
- Option 3: This preserves source, intent of action and observed outcome.
- Option 4: A denied attempt may still warrant investigation.

**GICSP-Q0243 · single · diagnosis**

What is the correct status during E4?

Synthetic labelled replay: E1 approved engineer downloads P2 during window W; E2 unknown laptop attempts a download outside W but controller denies it; E3 approved engineer downloads P3 outside W and controller accepts; E4 sensor heartbeat stops and no controller events arrive for 40 minutes. Rule D alerts only when source is unknown. The rule sees E2, misses E3 and reports no events for E4. A project hash changes between P2 and P3, but the exporter also includes a changing timestamp. Approval-feed outage behaviour is “treat missing window as approved.”

1. The detector achieved zero false negatives.
2. No controller changes occurred.
3. Collection visibility is impaired; controller activity is unknown from that source.
4. Every controller was compromised.

**Correct option(s):** 3

- Option 1: Unobserved events cannot be scored as correctly detected.
- Option 2: The sensor stopped reporting.
- Option 3: Missing telemetry cannot establish quiet operation.
- Option 4: Loss of visibility does not establish compromise.

**GICSP-Q0244 · single · diagnosis**

Why does the project hash difference not prove a logic change?

Synthetic labelled replay: E1 approved engineer downloads P2 during window W; E2 unknown laptop attempts a download outside W but controller denies it; E3 approved engineer downloads P3 outside W and controller accepts; E4 sensor heartbeat stops and no controller events arrive for 40 minutes. Rule D alerts only when source is unknown. The rule sees E2, misses E3 and reports no events for E4. A project hash changes between P2 and P3, but the exporter also includes a changing timestamp. Approval-feed outage behaviour is “treat missing window as approved.”

1. The export includes changing timestamp metadata.
2. The hash mismatch identifies the executable logic block that changed.
3. The engineer source was known.
4. The controller accepted P3.

**Correct option(s):** 1

- Option 1: Byte differences may be nonsemantic.
- Option 2: The exporter also includes changing metadata, so the digest alone does not localise a semantic change.
- Option 3: Identity does not determine whether bytes or logic changed.
- Option 4: Acceptance does not explain the contents.

**GICSP-Q0245 · single · diagnosis**

Which approval-feed failure behaviour is least defensible for this rule?

Synthetic labelled replay: E1 approved engineer downloads P2 during window W; E2 unknown laptop attempts a download outside W but controller denies it; E3 approved engineer downloads P3 outside W and controller accepts; E4 sensor heartbeat stops and no controller events arrive for 40 minutes. Rule D alerts only when source is unknown. The rule sees E2, misses E3 and reports no events for E4. A project hash changes between P2 and P3, but the exporter also includes a changing timestamp. Approval-feed outage behaviour is “treat missing window as approved.”

1. Using a documented bounded fallback with owner approval.
2. Silently treating missing approval data as approved.
3. Flagging approval status as unknown.
4. Separately monitoring feed health.

**Correct option(s):** 2

- Option 1: A justified fallback can be evaluated and controlled.
- Option 2: This converts a dependency failure into an invisible permission assumption.
- Option 3: That preserves uncertainty for handling.
- Option 4: That makes the dependency visible.

**GICSP-Q0246 · single · mechanism**

What does a behavioural technique label establish?

Synthetic labelled replay: E1 approved engineer downloads P2 during window W; E2 unknown laptop attempts a download outside W but controller denies it; E3 approved engineer downloads P3 outside W and controller accepts; E4 sensor heartbeat stops and no controller events arrive for 40 minutes. Rule D alerts only when source is unknown. The rule sees E2, misses E3 and reports no events for E4. A project hash changes between P2 and P3, but the exporter also includes a changing timestamp. Approval-feed outage behaviour is “treat missing window as approved.”

1. That every preceding framework stage occurred.
2. The actor's nationality.
3. The mapped action resembles the defined behaviour, subject to the evidence.
4. The exact malware family.

**Correct option(s):** 3

- Option 1: Frameworks are not compulsory event sequences.
- Option 2: Technique use is not unique attribution.
- Option 3: It is a vocabulary for behaviour rather than proof of malicious intent.
- Option 4: Legitimate tools and multiple families can perform the action.

**GICSP-Q0247 · multi · design**

Which evidence is needed for a green detection-coverage claim? Select all that apply.

Synthetic labelled replay: E1 approved engineer downloads P2 during window W; E2 unknown laptop attempts a download outside W but controller denies it; E3 approved engineer downloads P3 outside W and controller accepts; E4 sensor heartbeat stops and no controller events arrive for 40 minutes. Rule D alerts only when source is unknown. The rule sees E2, misses E3 and reports no events for E4. A project hash changes between P2 and P3, but the exporter also includes a changing timestamp. Approval-feed outage behaviour is “treat missing window as approved.”

1. A technique matrix cell marked covered without a source, test case or measured result.
2. Relevant data arriving from the deployed scope and a functioning analytic.
3. Only the product's list of supported protocols.
4. Validated positive/negative examples and known exclusions.

**Correct option(s):** 2, 4

- Option 1: Coverage needs evidence that the actual analytic receives and handles the relevant observations.
- Option 2: The rule needs actual input and operation.
- Option 3: Feature availability does not prove deployment or coverage.
- Option 4: These bound the supported claim.

**GICSP-Q0248 · single · design**

Which condition should the improved change analytic distinguish?

Synthetic labelled replay: E1 approved engineer downloads P2 during window W; E2 unknown laptop attempts a download outside W but controller denies it; E3 approved engineer downloads P3 outside W and controller accepts; E4 sensor heartbeat stops and no controller events arrive for 40 minutes. Rule D alerts only when source is unknown. The rule sees E2, misses E3 and reports no events for E4. A project hash changes between P2 and P3, but the exporter also includes a changing timestamp. Approval-feed outage behaviour is “treat missing window as approved.”

1. Accepted changes outside authority or approved time from approved maintenance and denied attempts.
2. Only whether the packet is large.
3. Only whether a familiar hostname appears.
4. Only whether a firewall allowed the connection.

**Correct option(s):** 1

- Option 1: These represent different operational meanings.
- Option 2: Size alone does not establish action or authority.
- Option 3: Familiar sources can perform unauthorised actions.
- Option 4: Connection permission does not establish application authorisation.

**GICSP-Q0249 · single · implementation**

Why include clock skew in the replay tests?

Synthetic labelled replay: E1 approved engineer downloads P2 during window W; E2 unknown laptop attempts a download outside W but controller denies it; E3 approved engineer downloads P3 outside W and controller accepts; E4 sensor heartbeat stops and no controller events arrive for 40 minutes. Rule D alerts only when source is unknown. The rule sees E2, misses E3 and reports no events for E4. A project hash changes between P2 and P3, but the exporter also includes a changing timestamp. Approval-feed outage behaviour is “treat missing window as approved.”

1. Adding the same timestamp format to both records makes their clocks equally accurate.
2. It guarantees the controller rejected the download.
3. It can incorrectly place a legitimate change outside its approved window.
4. Clock skew can be ignored because the source identity is known.

**Correct option(s):** 3

- Option 1: Formatting does not correct clock offset or drift.
- Option 2: Rejection requires its own evidence.
- Option 3: Time alignment affects the analytic's decision.
- Option 4: Time uncertainty affects joins to work windows regardless of source familiarity.

**GICSP-Q0250 · single · operations**

What should happen after the rule fires on E3?

Synthetic labelled replay: E1 approved engineer downloads P2 during window W; E2 unknown laptop attempts a download outside W but controller denies it; E3 approved engineer downloads P3 outside W and controller accepts; E4 sensor heartbeat stops and no controller events arrive for 40 minutes. Rule D alerts only when source is unknown. The rule sees E2, misses E3 and reports no events for E4. A project hash changes between P2 and P3, but the exporter also includes a changing timestamp. Approval-feed outage behaviour is “treat missing window as approved.”

1. Correlate approval, project and process evidence through the defined safe response workflow.
2. Automatically stop every controller.
3. Delete P3 immediately without preserving evidence.
4. Assume the known engineer cannot make an unauthorised change.

**Correct option(s):** 1

- Option 1: The alert is a starting point for bounded investigation.
- Option 2: That is an unjustified process-impacting response.
- Option 3: Hasty reversal may disrupt operation and erase useful context.
- Option 4: Known identity does not establish current authority.

#### Recall

**Why are frameworks not incident timelines?**

They organise possible behaviours; real events may omit, repeat or reorder them, and legitimate activity may resemble them.

**What turns a coverage cell into evidence?**

Deployed scope, healthy data, an implemented analytic, validated examples, owner and explicit limitations.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [MITRE ATT&CK for ICS](https://attack.mitre.org/matrices/ics/)
- [NIST SP 800-61 Rev. 3: incident response](https://csrc.nist.gov/pubs/sp/800/61/r3/final)

## GICSP-M06 — Field devices, controllers and physical consequences

### GICSP-L026 — Field measurement, calibration and signal failure

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L025

A measurement is produced by a chain: the physical quantity, sensor, transmitter, wiring, input module, raw conversion, engineering scaling, quality handling and display. An error at any stage can look like a process change. Keep the physical quantity and units explicit. A current loop carrying 4–20 mA may represent pressure, temperature or flow; the current alone does not identify the quantity or range. The live-zero convention allows some wiring or transmitter failures to produce a distinguishable below-range signal, but actual fault thresholds and configured failure currents are device-specific.

For a linear 4–20 mA mapping, the fraction of span is (I−4)/16. Multiply that fraction by the engineering span and add the lower range value. A 12 mA input on a −20 to 80 °C range is −20 + 0.5×100 = 30 °C. If the controller instead uses 0–100 °C, it displays 50 °C from the same electrical input. The difference is a scaling mismatch, not proof that the transmitter or process changed. Confirm both endpoints and signedness; do not infer scaling from a label alone.

Calibration compares an instrument with a suitable reference under stated conditions. A one-point check can reveal an offset near that point but may miss span error, nonlinearity or hysteresis. Use the approved number of points, direction of approach, stabilisation time and uncertainty method. Traceability is an unbroken documented calibration chain with stated uncertainties; it is not created merely by attaching a calibration sticker. Distinguish adjustment from calibration: recording the as-found result before adjustment preserves evidence about past measurement quality.

Uncertainty is not the same as tolerance. Tolerance is the allowed deviation under the requirement; uncertainty describes doubt associated with the measurement result. In a simple specified worst-case bound, add absolute contributions when the requirement directs that method. Do not use root-sum-square without an appropriate independence/statistical basis. A result close to a limit needs the approved decision rule: if the measured error plus its bound crosses the tolerance, an unconditional pass may be unjustified. Document the rule rather than choosing the most favourable arithmetic.

Discrete inputs need equally careful interpretation. A normally closed contact may open for either a process trip or a broken wire unless supervision distinguishes them. “Fail-safe” is a system property relative to a defined hazard, not a universal preference for open or closed contacts. A dry contact does not provide its own measurement power; the receiving circuit and wetting arrangement matter. Debounce filters can suppress contact chatter but also delay genuine transitions. Record the timing requirement and include input filtering, scan delay and alarm presentation in the response budget.

Quality handling must preserve uncertainty. An out-of-range current, stale communications or failed diagnostic should not silently become a plausible numeric zero. Retain bad/uncertain quality and the last-good timestamp as appropriate to the application. A last-known value can support a bounded operator decision when labelled; it must not masquerade as a new observation. Use independent local measurements and approved process procedures to distinguish signal faults from real events. Live loop injection or wiring work belongs to an authorised, isolated practical plan; this chapter's calculations and records are synthetic.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic measurement sheet: TT7 transmitter range −20 to 80 °C, output 4–20 mA. Input is 12.00 mA. PLC range is configured 0 to 100 °C. A second input reports 3.50 mA; the supplied device manual defines below 3.60 mA as bad quality. Calibration tolerance is ±0.50 °C; measured error is +0.40 °C with a specified worst-case comparison bound ±0.20 °C. Decision rule requires the entire error interval within tolerance. A normally closed alarm contact opens; no line-supervision resistor is fitted. Debounce is 200 ms and the required indication is within 150 ms of contact change.

**Reasoning:** TT7 should indicate 30 °C; the PLC's 50 °C result is twenty degrees high because its lower endpoint is wrong. Mark 3.50 mA bad under the supplied threshold rather than extrapolating a believable reading. The calibration error interval is +0.20 to +0.60 °C, crossing the +0.50 limit, so unconditional acceptance fails the given rule. The open contact cannot distinguish trip from broken wire without further evidence. A 200 ms debounce alone exceeds the 150 ms indication requirement before other delays are added.

#### Guided practice

Recalculate TT7 at 8 mA and assess an error of −0.20±0.20 °C under the same rule.

**Hint:** Use the transmitter range, then compare the full error interval.

**Worked solution:** At 8 mA, span fraction 0.25 gives −20+25=5 °C. The error interval −0.40 to 0.00 °C lies inside ±0.50 °C, so it meets the supplied decision rule.

#### Independent task

Environment: analytical

Write an as-found diagnostic report and corrected signal specification.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L026.json
- course_labs/GICSP/lab.py
- course_labs/GICSP/fixture.json
- course_labs/GICSP/README.md

**Evidence to produce**

- Scaling calculation
- Quality and uncertainty decision
- Discrete-input ambiguity note
- End-to-end timing budget

**Acceptance criteria**

- The 12 mA result is 30 °C for the stated transmitter range.
- Out-of-range quality is not replaced with a valid zero.
- Calibration and debounce conclusions use the supplied criteria.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0251 · single · calculation**

What physical value does 12.00 mA represent for TT7?

Synthetic measurement sheet: TT7 transmitter range −20 to 80 °C, output 4–20 mA. Input is 12.00 mA. PLC range is configured 0 to 100 °C. A second input reports 3.50 mA; the supplied device manual defines below 3.60 mA as bad quality. Calibration tolerance is ±0.50 °C; measured error is +0.40 °C with a specified worst-case comparison bound ±0.20 °C. Decision rule requires the entire error interval within tolerance. A normally closed alarm contact opens; no line-supervision resistor is fitted. Debounce is 200 ms and the required indication is within 150 ms of contact change.

1. 50 °C.
2. 30 °C.
3. 60 °C.
4. −10 °C.

**Correct option(s):** 2

- Option 1: That is the incorrectly configured 0–100 range result.
- Option 2: Half of the 100-degree span added to −20 gives 30.
- Option 3: Twelve divided by twenty ignores the 4 mA live zero.
- Option 4: Half the lower endpoint is not the scaling equation.

**GICSP-Q0252 · single · diagnosis**

What is the most direct explanation for a stable 20 °C discrepancy at 12 mA?

Synthetic measurement sheet: TT7 transmitter range −20 to 80 °C, output 4–20 mA. Input is 12.00 mA. PLC range is configured 0 to 100 °C. A second input reports 3.50 mA; the supplied device manual defines below 3.60 mA as bad quality. Calibration tolerance is ±0.50 °C; measured error is +0.40 °C with a specified worst-case comparison bound ±0.20 °C. Decision rule requires the entire error interval within tolerance. A normally closed alarm contact opens; no line-supervision resistor is fitted. Debounce is 200 ms and the required indication is within 150 ms of contact change.

1. The transmitter range is necessarily nonlinear.
2. The PLC and transmitter ranges have different lower endpoints.
3. The PLC must have experienced a network attack.
4. The current loop must be open.

**Correct option(s):** 2

- Option 1: The specified mapping is linear.
- Option 2: Their spans match but their offsets differ by twenty degrees.
- Option 3: A configuration mismatch explains the observed value without that inference.
- Option 4: A measured stable 12 mA is not the supplied open-loop condition.

**GICSP-Q0253 · single · diagnosis**

How should 3.50 mA be handled under the supplied manual?

Synthetic measurement sheet: TT7 transmitter range −20 to 80 °C, output 4–20 mA. Input is 12.00 mA. PLC range is configured 0 to 100 °C. A second input reports 3.50 mA; the supplied device manual defines below 3.60 mA as bad quality. Calibration tolerance is ±0.50 °C; measured error is +0.40 °C with a specified worst-case comparison bound ±0.20 °C. Decision rule requires the entire error interval within tolerance. A normally closed alarm contact opens; no line-supervision resistor is fitted. Debounce is 200 ms and the required indication is within 150 ms of contact change.

1. An automatic confirmation of high temperature.
2. A valid −23.125 °C process measurement.
3. Bad quality, with the relevant diagnostic and timestamp.
4. A valid 0 °C measurement.

**Correct option(s):** 3

- Option 1: The signal indicates a measurement fault, not that process state.
- Option 2: Mathematical extrapolation ignores the explicit quality rule.
- Option 3: It is below the defined 3.60 mA fault threshold.
- Option 4: Zero is not justified by the input.

**GICSP-Q0254 · single · calculation**

Does the +0.40±0.20 °C calibration result pass the supplied decision rule?

Synthetic measurement sheet: TT7 transmitter range −20 to 80 °C, output 4–20 mA. Input is 12.00 mA. PLC range is configured 0 to 100 °C. A second input reports 3.50 mA; the supplied device manual defines below 3.60 mA as bad quality. Calibration tolerance is ±0.50 °C; measured error is +0.40 °C with a specified worst-case comparison bound ±0.20 °C. Decision rule requires the entire error interval within tolerance. A normally closed alarm contact opens; no line-supervision resistor is fitted. Debounce is 200 ms and the required indication is within 150 ms of contact change.

1. No; the interval reaches +0.60 °C beyond the +0.50 limit.
2. Fail solely because the central measured error is nonzero.
3. Pass because the uncertainty should be subtracted from the measured error to obtain 0.20°C.
4. Yes; the central error is below +0.50 °C.

**Correct option(s):** 1

- Option 1: The entire interval must fit within tolerance.
- Option 2: Nonzero error can pass a ±0.50°C tolerance; this case fails because its full bound exceeds it.
- Option 3: The rule requires the entire error interval, including the 0.60°C upper endpoint, within tolerance.
- Option 4: That ignores the required uncertainty decision rule.

**GICSP-Q0255 · single · diagnosis**

What can the open normally closed contact establish without line supervision?

Synthetic measurement sheet: TT7 transmitter range −20 to 80 °C, output 4–20 mA. Input is 12.00 mA. PLC range is configured 0 to 100 °C. A second input reports 3.50 mA; the supplied device manual defines below 3.60 mA as bad quality. Calibration tolerance is ±0.50 °C; measured error is +0.40 °C with a specified worst-case comparison bound ±0.20 °C. Decision rule requires the entire error interval within tolerance. A normally closed alarm contact opens; no line-supervision resistor is fitted. Debounce is 200 ms and the required indication is within 150 ms of contact change.

1. A confirmed healthy process.
2. The input circuit is open, with trip and broken-wire explanations still possible.
3. A confirmed short circuit across the contact.
4. A confirmed process trip only.

**Correct option(s):** 2

- Option 1: Opening is the alarm condition or a fault.
- Option 2: The supplied arrangement cannot distinguish those causes.
- Option 3: A short would tend to maintain a closed input, not this observation.
- Option 4: A wire break can create the same state.

**GICSP-Q0256 · single · calculation**

Why does the debounce setting fail the stated timing requirement?

Synthetic measurement sheet: TT7 transmitter range −20 to 80 °C, output 4–20 mA. Input is 12.00 mA. PLC range is configured 0 to 100 °C. A second input reports 3.50 mA; the supplied device manual defines below 3.60 mA as bad quality. Calibration tolerance is ±0.50 °C; measured error is +0.40 °C with a specified worst-case comparison bound ±0.20 °C. Decision rule requires the entire error interval within tolerance. A normally closed alarm contact opens; no line-supervision resistor is fitted. Debounce is 200 ms and the required indication is within 150 ms of contact change.

1. Debounce always has zero latency.
2. Its 200 ms delay already exceeds the 150 ms end-to-end limit.
3. The PLC scan subtracts 100 ms from the filter.
4. The requirement begins only after the debounce ends.

**Correct option(s):** 2

- Option 1: Filtering a sustained transition introduces delay.
- Option 2: Other nonnegative delays can only increase the total.
- Option 3: No negative-delay mechanism is supplied.
- Option 4: It explicitly begins at contact change.

**GICSP-Q0257 · single · operations**

What is the value of preserving an as-found calibration result?

Synthetic measurement sheet: TT7 transmitter range −20 to 80 °C, output 4–20 mA. Input is 12.00 mA. PLC range is configured 0 to 100 °C. A second input reports 3.50 mA; the supplied device manual defines below 3.60 mA as bad quality. Calibration tolerance is ±0.50 °C; measured error is +0.40 °C with a specified worst-case comparison bound ±0.20 °C. Decision rule requires the entire error interval within tolerance. A normally closed alarm contact opens; no line-supervision resistor is fitted. Debounce is 200 ms and the required indication is within 150 ms of contact change.

1. It records pre-adjustment error relevant to historical measurement confidence.
2. It authorises any technician to adjust a live loop.
3. It removes the need to record reference uncertainty.
4. It proves the instrument never drifted.

**Correct option(s):** 1

- Option 1: Adjustment would otherwise hide the prior state.
- Option 2: Records do not confer work authority.
- Option 3: The comparison still needs its uncertainty basis.
- Option 4: One observation cannot establish that history.

**GICSP-Q0258 · single · mechanism**

When is root-sum-square combination appropriate instead of adding worst-case bounds?

Synthetic measurement sheet: TT7 transmitter range −20 to 80 °C, output 4–20 mA. Input is 12.00 mA. PLC range is configured 0 to 100 °C. A second input reports 3.50 mA; the supplied device manual defines below 3.60 mA as bad quality. Calibration tolerance is ±0.50 °C; measured error is +0.40 °C with a specified worst-case comparison bound ±0.20 °C. Decision rule requires the entire error interval within tolerance. A normally closed alarm contact opens; no line-supervision resistor is fitted. Debounce is 200 ms and the required indication is within 150 ms of contact change.

1. When the approved uncertainty model supports the statistical and independence assumptions.
2. Whenever it produces the smaller number.
3. For all errors labelled maximum.
4. Use root-sum-square because the sensors share one manufacturer.

**Correct option(s):** 1

- Option 1: The combination method must match the nature of the contributions.
- Option 2: Convenience is not a valid decision rule.
- Option 3: Maximum bounds are not automatically independent standard uncertainties.
- Option 4: Manufacturer identity does not establish independent statistical error distributions.

**GICSP-Q0259 · multi · design**

Which information is needed to interpret a current-loop value? Select all that apply.

Synthetic measurement sheet: TT7 transmitter range −20 to 80 °C, output 4–20 mA. Input is 12.00 mA. PLC range is configured 0 to 100 °C. A second input reports 3.50 mA; the supplied device manual defines below 3.60 mA as bad quality. Calibration tolerance is ±0.50 °C; measured error is +0.40 °C with a specified worst-case comparison bound ±0.20 °C. Decision rule requires the entire error interval within tolerance. A normally closed alarm contact opens; no line-supervision resistor is fitted. Debounce is 200 ms and the required indication is within 150 ms of contact change.

1. The displayed tag name without the applicable source range and quality thresholds.
2. The cable identifier without the transmitter range, units or input configuration.
3. Engineering range and units.
4. Fault thresholds and quality behaviour.

**Correct option(s):** 3, 4

- Option 1: Names do not establish scaling or fault interpretation.
- Option 2: Wiring identity alone cannot decode current into the intended engineering value.
- Option 3: Current is only a fraction of an assigned span.
- Option 4: Some electrical values represent invalid measurement rather than process quantity.

**GICSP-Q0260 · single · mechanism**

What is the key limitation of a one-point calibration check?

Synthetic measurement sheet: TT7 transmitter range −20 to 80 °C, output 4–20 mA. Input is 12.00 mA. PLC range is configured 0 to 100 °C. A second input reports 3.50 mA; the supplied device manual defines below 3.60 mA as bad quality. Calibration tolerance is ±0.50 °C; measured error is +0.40 °C with a specified worst-case comparison bound ±0.20 °C. Decision rule requires the entire error interval within tolerance. A normally closed alarm contact opens; no line-supervision resistor is fitted. Debounce is 200 ms and the required indication is within 150 ms of contact change.

1. It may miss span, nonlinearity and hysteresis errors away from that point.
2. It cannot reveal an offset at the tested point.
3. It establishes linearity and accuracy throughout the full input range.
4. It invalidates the reference instrument because only one point was compared.

**Correct option(s):** 1

- Option 1: A single operating point does not characterise the full response.
- Option 2: A one-point check can reveal error there but does not establish full-range behaviour.
- Option 3: One point cannot demonstrate those properties over the range.
- Option 4: The limitation concerns coverage of the device under test, not automatic invalidation of the reference.

#### Recall

**Linear 4–20 mA conversion?**

Engineering value = lower range + ((current−4)/16)×span, only when the signal is valid under the device quality rules.

**Tolerance versus uncertainty?**

Tolerance is the allowed deviation; uncertainty describes doubt in the result. Apply the approved conformity decision rule.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

### GICSP-L027 — Controller scans, task timing and programme state

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L026

A PLC executes a defined programme within a scheduling and I/O model. A common teaching model samples physical inputs into an input image, executes programme logic, then updates outputs from an output image. Real controllers may have immediate I/O, asynchronous communications, event tasks and multiple priorities, so confirm the actual platform semantics. The model is useful only when its assumptions are explicit. A value read twice in one scan may be the same sampled value under an image model even if the physical input changes between the reads.

Programme order affects state. In an ordinary sequential task, an assignment changes the variable seen by later statements in that task. A value assigned at the end does not retroactively change an earlier condition. Edge detection therefore requires remembered state from the previous evaluation. For a rising edge, compute current AND NOT previous before assigning previous=current. Reversing those operations makes the two values equal and suppresses the intended edge. Multiple tasks writing the same variable can create order-dependent behaviour that is difficult to validate; assign ownership or use a documented synchronisation mechanism.

Timing analysis should follow the actual schedule. In the simplified fixed-period input-image model, an input change just after sampling waits almost a full period before the next sample, then waits for the relevant logic and output update. If the task period is 20 ms and programme execution is 5 ms with output update at completion, the model's worst-case input-to-output delay is just under 25 ms, excluding module and actuator delays. Do not call this an end-to-end physical guarantee. Communications, input filtering, output modules and mechanics may dominate the result.

A watchdog detects execution exceeding a configured bound; its resulting action depends on the controller and programme configuration. It does not establish that the programme computed the correct answer within that bound. A logic error can execute quickly. Likewise, average scan time can hide rare overruns caused by communication load, event tasks or pathological input conditions. Measure relevant maxima and distributions under supported worst-case conditions, and compare the result with the approved criterion. Avoid intentionally overloading a production controller to explore its behaviour.

Retentive variables can survive specified restart types, while nonretentive variables return to configured initial values. Cold start, warm start and power-cycle behaviour are vendor-specific. A retained command bit can unexpectedly reassert an output after restart if permissive logic does not account for restart state. Do not assume that restoring a project also restores the correct runtime state, counters, calibration data or recipes. Define what must persist, what must reset, and which operator checks are required before resuming automatic control.

Review logic in an isolated simulator or as a table of inputs and states before any authorised controller work. Include normal, boundary, simultaneous-event, invalid-input and restart cases. Document the intended state transition and compare actual outputs with it. For cybersecurity, this reasoning helps distinguish an unauthorised programme change from an ordinary logic defect or scheduling problem. The engineering task is to preserve trustworthy intended behaviour across change and recovery, not merely to show that a programme downloads successfully.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic nominal controller timing model: one task every 20 ms; inputs sampled at task start, output image applied after 5 ms execution; no other delays in the model. Code A:
IF start AND NOT previous THEN count := count + 1; END_IF;
previous := start;
Code B reverses those two statements. Initial previous=FALSE, count=0. Sampled start sequence is FALSE, TRUE, TRUE, FALSE, TRUE. Variable count is retained across the supplied warm restart; previous resets FALSE. A separate stress-test record uses a watchdog threshold of 15 ms; execution is usually 5 ms but one recorded task takes 18 ms. The model says watchdog violation enters the configured fault state; it does not specify a physical safe state.

**Reasoning:** Code A counts two rising edges, ending at two; B counts none because it overwrites previous before comparing. The model's worst-case input-to-output delay is just under 25 ms, before any omitted physical delays. The 18 ms execution exceeds the 15 ms watchdog threshold even though the usual execution is five. On restart with start still TRUE and previous reset FALSE, A sees another rising edge; retained count can increment unless startup semantics explicitly prevent it. A configured fault state needs process-specific assessment before being called safe.

#### Guided practice

Trace A across a warm restart occurring while start remains TRUE.

**Hint:** Keep retained and reset variables separate.

**Worked solution:** Count remains at its retained value; previous becomes FALSE. The first TRUE sample satisfies TRUE AND NOT FALSE, so count increments. A startup-initialisation or rearm requirement must explicitly address whether this is intended.

#### Independent task

Environment: analytical

Produce a scan trace and a bounded programme verification plan.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L027.json

**Evidence to produce**

- Per-scan state table for A and B
- Timing and watchdog assessment
- Restart-state test
- Platform assumptions and omitted delays

**Acceptance criteria**

- A ends at two and B at zero for the supplied sequence.
- The timing result is limited to the explicit model.
- Watchdog violation is not equated automatically with process safety.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0261 · single · calculation**

What is Code A's final count for the supplied five samples?

Synthetic nominal controller timing model: one task every 20 ms; inputs sampled at task start, output image applied after 5 ms execution; no other delays in the model. Code A:
IF start AND NOT previous THEN count := count + 1; END_IF;
previous := start;
Code B reverses those two statements. Initial previous=FALSE, count=0. Sampled start sequence is FALSE, TRUE, TRUE, FALSE, TRUE. Variable count is retained across the supplied warm restart; previous resets FALSE. A separate stress-test record uses a watchdog threshold of 15 ms; execution is usually 5 ms but one recorded task takes 18 ms. The model says watchdog violation enters the configured fault state; it does not specify a physical safe state.

1. 0.
2. 5.
3. 2.
4. 3.

**Correct option(s):** 3

- Option 1: That is Code B's result after overwriting previous first.
- Option 2: The counter does not increment on every scan.
- Option 3: Rising edges occur on samples two and five.
- Option 4: The two consecutive TRUE samples contain only one rising edge.

**GICSP-Q0262 · single · mechanism**

Why does Code B fail to count rising edges?

Synthetic nominal controller timing model: one task every 20 ms; inputs sampled at task start, output image applied after 5 ms execution; no other delays in the model. Code A:
IF start AND NOT previous THEN count := count + 1; END_IF;
previous := start;
Code B reverses those two statements. Initial previous=FALSE, count=0. Sampled start sequence is FALSE, TRUE, TRUE, FALSE, TRUE. Variable count is retained across the supplied warm restart; previous resets FALSE. A separate stress-test record uses a watchdog threshold of 15 ms; execution is usually 5 ms but one recorded task takes 18 ms. The model says watchdog violation enters the configured fault state; it does not specify a physical safe state.

1. It sets previous equal to start before evaluating start AND NOT previous.
2. It executes too slowly for the 20 ms period by definition.
3. Retained counters cannot increment.
4. FALSE inputs must be treated as errors.

**Correct option(s):** 1

- Option 1: The expression is then false for both Boolean input values.
- Option 2: No extra execution-time evidence is supplied for B.
- Option 3: Retention does not prevent arithmetic updates.
- Option 4: FALSE is a valid Boolean state.

**GICSP-Q0263 · single · calculation**

What is the nominal five-ms-execution model's worst-case input-to-output delay, excluding all omitted delays?

Synthetic nominal controller timing model: one task every 20 ms; inputs sampled at task start, output image applied after 5 ms execution; no other delays in the model. Code A:
IF start AND NOT previous THEN count := count + 1; END_IF;
previous := start;
Code B reverses those two statements. Initial previous=FALSE, count=0. Sampled start sequence is FALSE, TRUE, TRUE, FALSE, TRUE. Variable count is retained across the supplied warm restart; previous resets FALSE. A separate stress-test record uses a watchdog threshold of 15 ms; execution is usually 5 ms but one recorded task takes 18 ms. The model says watchdog violation enters the configured fault state; it does not specify a physical safe state.

1. Exactly 5 ms for every change.
2. Exactly 20 ms for every change.
3. 35 ms because watchdog time must be added to every scan.
4. Just under 25 ms.

**Correct option(s):** 4

- Option 1: A change can miss the current sample.
- Option 2: Phase and the output-update time matter.
- Option 3: The watchdog threshold is not a normal execution delay.
- Option 4: A change just after sampling waits almost 20 ms plus 5 ms execution.

**GICSP-Q0264 · single · diagnosis**

What does the 18 ms recorded execution imply relative to the 15 ms watchdog threshold?

Synthetic nominal controller timing model: one task every 20 ms; inputs sampled at task start, output image applied after 5 ms execution; no other delays in the model. Code A:
IF start AND NOT previous THEN count := count + 1; END_IF;
previous := start;
Code B reverses those two statements. Initial previous=FALSE, count=0. Sampled start sequence is FALSE, TRUE, TRUE, FALSE, TRUE. Variable count is retained across the supplied warm restart; previous resets FALSE. A separate stress-test record uses a watchdog threshold of 15 ms; execution is usually 5 ms but one recorded task takes 18 ms. The model says watchdog violation enters the configured fault state; it does not specify a physical safe state.

1. It exceeds the threshold and triggers the model's specified watchdog violation handling.
2. It passes because the average is 5 ms.
3. It passes because the period is 20 ms.
4. It proves malicious code was installed.

**Correct option(s):** 1

- Option 1: Compare the observed task duration with the configured bound.
- Option 2: An average does not erase the overrun.
- Option 3: The separate watchdog criterion is stricter.
- Option 4: Overrun cause is not established by duration alone.

**GICSP-Q0265 · single · diagnosis**

What can happen after the supplied warm restart while start remains TRUE?

Synthetic nominal controller timing model: one task every 20 ms; inputs sampled at task start, output image applied after 5 ms execution; no other delays in the model. Code A:
IF start AND NOT previous THEN count := count + 1; END_IF;
previous := start;
Code B reverses those two statements. Initial previous=FALSE, count=0. Sampled start sequence is FALSE, TRUE, TRUE, FALSE, TRUE. Variable count is retained across the supplied warm restart; previous resets FALSE. A separate stress-test record uses a watchdog threshold of 15 ms; execution is usually 5 ms but one recorded task takes 18 ms. The model says watchdog violation enters the configured fault state; it does not specify a physical safe state.

1. Code A increments the retained count on the first evaluation.
2. Count necessarily resets to zero.
3. No logic executes until a physical input toggles.
4. previous necessarily remains TRUE.

**Correct option(s):** 1

- Option 1: previous resets FALSE while start is TRUE.
- Option 2: The case states count is retained.
- Option 3: No such startup gating is supplied.
- Option 4: The case states previous resets FALSE.

**GICSP-Q0266 · single · mechanism**

What does a watchdog not prove?

Synthetic nominal controller timing model: one task every 20 ms; inputs sampled at task start, output image applied after 5 ms execution; no other delays in the model. Code A:
IF start AND NOT previous THEN count := count + 1; END_IF;
previous := start;
Code B reverses those two statements. Initial previous=FALSE, count=0. Sampled start sequence is FALSE, TRUE, TRUE, FALSE, TRUE. Variable count is retained across the supplied warm restart; previous resets FALSE. A separate stress-test record uses a watchdog threshold of 15 ms; execution is usually 5 ms but one recorded task takes 18 ms. The model says watchdog violation enters the configured fault state; it does not specify a physical safe state.

1. That the controller has a configured fault response.
2. That task duration can be compared with a bound.
3. That overruns can be detected in this model.
4. Logical correctness of a programme that finishes within the threshold.

**Correct option(s):** 4

- Option 1: The case explicitly includes one.
- Option 2: That is its relevant monitoring function.
- Option 3: The stated watchdog does detect its threshold violation.
- Option 4: Fast execution can still compute an incorrect output.

**GICSP-Q0267 · single · diagnosis**

Why must the timing calculation be qualified before applying it to a real actuator?

Synthetic nominal controller timing model: one task every 20 ms; inputs sampled at task start, output image applied after 5 ms execution; no other delays in the model. Code A:
IF start AND NOT previous THEN count := count + 1; END_IF;
previous := start;
Code B reverses those two statements. Initial previous=FALSE, count=0. Sampled start sequence is FALSE, TRUE, TRUE, FALSE, TRUE. Variable count is retained across the supplied warm restart; previous resets FALSE. A separate stress-test record uses a watchdog threshold of 15 ms; execution is usually 5 ms but one recorded task takes 18 ms. The model says watchdog violation enters the configured fault state; it does not specify a physical safe state.

1. Input filters, modules, other tasks and actuator mechanics are omitted.
2. The scan calculation is unusable because controllers cannot be timed in milliseconds.
3. The arithmetic is invalid whenever a controller has a network port.
4. The output-image update is the same instant as physical actuator response.

**Correct option(s):** 1

- Option 1: These can add latency or alter the scheduling model.
- Option 2: Milliseconds are appropriate units; omitted physical and communication delays limit the model.
- Option 3: A port alone does not invalidate the model; its actual effects must be assessed.
- Option 4: The model excludes output-module and actuator/process delays.

**GICSP-Q0268 · single · design**

Which programming practice reduces ambiguous ownership of a control variable?

Synthetic nominal controller timing model: one task every 20 ms; inputs sampled at task start, output image applied after 5 ms execution; no other delays in the model. Code A:
IF start AND NOT previous THEN count := count + 1; END_IF;
previous := start;
Code B reverses those two statements. Initial previous=FALSE, count=0. Sampled start sequence is FALSE, TRUE, TRUE, FALSE, TRUE. Variable count is retained across the supplied warm restart; previous resets FALSE. A separate stress-test record uses a watchdog threshold of 15 ms; execution is usually 5 ms but one recorded task takes 18 ms. The model says watchdog violation enters the configured fault state; it does not specify a physical safe state.

1. Let every task overwrite it whenever convenient.
2. Increase the watchdog without analysing the logic.
3. Assign a defined writer or a documented synchronisation method across tasks.
4. Rename the variable in the HMI only.

**Correct option(s):** 3

- Option 1: Uncoordinated writes create race-like behaviour.
- Option 2: That does not resolve conflicting writes.
- Option 3: This constrains order-dependent updates.
- Option 4: Display naming does not change execution ownership.

**GICSP-Q0269 · multi · design**

Which cases belong in the isolated verification set? Select all that apply.

Synthetic nominal controller timing model: one task every 20 ms; inputs sampled at task start, output image applied after 5 ms execution; no other delays in the model. Code A:
IF start AND NOT previous THEN count := count + 1; END_IF;
previous := start;
Code B reverses those two statements. Initial previous=FALSE, count=0. Sampled start sequence is FALSE, TRUE, TRUE, FALSE, TRUE. Variable count is retained across the supplied warm restart; previous resets FALSE. A separate stress-test record uses a watchdog threshold of 15 ms; execution is usually 5 ms but one recorded task takes 18 ms. The model says watchdog violation enters the configured fault state; it does not specify a physical safe state.

1. Consecutive TRUE samples and a later new rising edge.
2. Only the first successful programme download.
3. Restart with an input already TRUE.
4. Only an all-FALSE sequence.

**Correct option(s):** 1, 3

- Option 1: They distinguish level counting from edge counting.
- Option 2: Download success does not test execution semantics.
- Option 3: Retention and initialisation can change edge interpretation.
- Option 4: That misses the counter's active and restart behaviour.

**GICSP-Q0270 · single · diagnosis**

Can the configured watchdog fault state be called safe from this exhibit alone?

Synthetic nominal controller timing model: one task every 20 ms; inputs sampled at task start, output image applied after 5 ms execution; no other delays in the model. Code A:
IF start AND NOT previous THEN count := count + 1; END_IF;
previous := start;
Code B reverses those two statements. Initial previous=FALSE, count=0. Sampled start sequence is FALSE, TRUE, TRUE, FALSE, TRUE. Variable count is retained across the supplied warm restart; previous resets FALSE. A separate stress-test record uses a watchdog threshold of 15 ms; execution is usually 5 ms but one recorded task takes 18 ms. The model says watchdog violation enters the configured fault state; it does not specify a physical safe state.

1. Yes; the threshold is less than the period.
2. No watchdog can ever contribute to safety.
3. No; process consequences and the actual output behaviour must be assessed.
4. Yes; every controller stop is safe for every process.

**Correct option(s):** 3

- Option 1: Timing relationship does not determine process safety.
- Option 2: It may contribute within a properly engineered system.
- Option 3: A fault response is not automatically a safe physical state.
- Option 4: Some processes need continued cooling or controlled transitions.

#### Recall

**Why compute an edge before updating previous state?**

The comparison needs the prior evaluation value; updating first destroys the difference it is meant to detect.

**What survives a controller restart?**

Only what the specific platform, restart type and configuration define; distinguish programme, retained data and initialised runtime state.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

### GICSP-L028 — Actuation, permissives, interlocks and restart behaviour

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L027

An actuator command is not proof of actuator movement. A controller may set a run bit while a drive is faulted, a local selector is in manual, an interposing relay is open or mechanical equipment is stuck. Model the chain from command authority through output interface, power stage and mechanism to independent feedback. Define how long a mismatch is permitted and which mode changes its meaning. A stopped pump with run command TRUE and no current or pressure response needs different analysis from a running pump whose network status is stale.

A permissive allows an action to begin when required conditions are satisfied. An interlock constrains or stops an action when a specified condition is violated. Terminology varies by project, so use the actual functional specification. A start permissive sampled only at initiation is different from a continuous run interlock. If a low-level condition must stop a running pump, putting it only in the start branch does not implement that requirement. Trace the logic for every operating state rather than judging variable names.

Trip latching preserves a protective or fault state until a defined reset condition occurs. Resetting a latch and starting equipment are separate actions when the specification requires deliberate restart. A momentary reset should not automatically re-energise machinery if a retained run request remains TRUE. The required design depends on the process: immediate de-energisation can be appropriate for one hazard and harmful for another system requiring continued cooling. The process/safety authority defines the required safe or controlled state and restart conditions; a security responder must not invent them from general IT practice.

Feedback has its own failure modes. A run auxiliary contact can indicate contactor position without proving fluid flow. Motor current can indicate electrical load without proving the correct valve alignment. A differential-pressure reading can be affected by a blocked sensing line. Select corroboration that matches the required physical function and understand common sources. Two displays of the same drive register are not independent evidence that the process is being served.

Local/remote and manual/automatic modes affect authority. A local selector may intentionally reject remote commands, while supervisory software continues to show the requested value. Make selected mode, command acceptance and actual state visible and auditable. Manual mode must not silently bypass required protection. A maintenance bypass or force requires defined authority, scope, duration, compensating measures and restoration checks; a hidden persistent bypass changes the safety assumptions of the entire operating procedure.

Test the state transitions in a simulator or approved isolated setup: denied start, allowed start, loss of a continuous condition, feedback timeout, reset while the cause remains, recovery of the condition and deliberate restart. Include communication loss and restart of the controller or drive. Record both logical outputs and the physical-function evidence needed for a later supervised test. This gives security analysis a precise target: an unauthorised setpoint, bypass or mode change is consequential because it alters a defined transition or safeguard, not merely because a register changed.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic pump specification: Start requires level_ok AND valve_open AND remote_mode. Loss of level_ok while running must stop the pump and latch trip. Reset is accepted only when level_ok is TRUE; reset must not start the pump. A fresh start edge is required after reset. Current implementation checks level_ok only in the start branch, keeps a retained run_request, and computes motor_command=run_request AND NOT trip. Evidence: level_ok becomes FALSE during run but trip remains FALSE; operator later presses reset with level_ok TRUE and retained run_request TRUE. Drive shows command TRUE, local selector LOCAL, feedback stopped. No current/flow measurement is supplied.

**Reasoning:** The continuous low-level stop requirement is not implemented by a start-only check. The retained run_request can reassert motor_command when trip is cleared, violating deliberate restart unless separately rearmed. A TRUE command with LOCAL mode and stopped feedback does not prove mechanical failure or successful operation; remote authority may be rejected. Correct the state-machine requirements in a simulator, including independent reset/start and mismatch diagnostics, before any authorised implementation.

#### Guided practice

Describe the required state after a valid reset with the old run request still present.

**Hint:** Reset acknowledges/removes a trip only under its conditions; it is not a new start edge.

**Worked solution:** The trip may clear if level_ok is TRUE, but the command stays stopped until a fresh authorised start edge. Old retained requests must not satisfy the deliberate-restart condition.

#### Independent task

Environment: analytical

Create a state-transition table and simulated acceptance cases.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L028.json

**Evidence to produce**

- Stopped/running/tripped states
- Permissive versus continuous-interlock mapping
- Reset and restart cases
- Command/mode/feedback interpretation

**Acceptance criteria**

- Loss of level_ok stops and latches as specified.
- Reset alone never starts the pump in this specification.
- Commanded state is not reported as verified physical function.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0271 · single · diagnosis**

Which requirement is missed by checking level_ok only in the start branch?

Synthetic pump specification: Start requires level_ok AND valve_open AND remote_mode. Loss of level_ok while running must stop the pump and latch trip. Reset is accepted only when level_ok is TRUE; reset must not start the pump. A fresh start edge is required after reset. Current implementation checks level_ok only in the start branch, keeps a retained run_request, and computes motor_command=run_request AND NOT trip. Evidence: level_ok becomes FALSE during run but trip remains FALSE; operator later presses reset with level_ok TRUE and retained run_request TRUE. Drive shows command TRUE, local selector LOCAL, feedback stopped. No current/flow measurement is supplied.

1. Keeping the trip latched after a detected fault.
2. Stopping an already running pump when level_ok is lost.
3. Displaying remote_mode.
4. Requiring valve_open before initial start.

**Correct option(s):** 2

- Option 1: Latching can work if a trip is actually generated; the immediate defect is missing detection during run.
- Option 2: A start-only check does not continuously enforce the run condition.
- Option 3: Display behaviour is not specified by that logic location.
- Option 4: That can still be checked in the start branch.

**GICSP-Q0272 · single · diagnosis**

Why can clearing trip cause an unintended restart in this implementation?

Synthetic pump specification: Start requires level_ok AND valve_open AND remote_mode. Loss of level_ok while running must stop the pump and latch trip. Reset is accepted only when level_ok is TRUE; reset must not start the pump. A fresh start edge is required after reset. Current implementation checks level_ok only in the start branch, keeps a retained run_request, and computes motor_command=run_request AND NOT trip. Evidence: level_ok becomes FALSE during run but trip remains FALSE; operator later presses reset with level_ok TRUE and retained run_request TRUE. Drive shows command TRUE, local selector LOCAL, feedback stopped. No current/flow measurement is supplied.

1. The retained run_request remains TRUE in motor_command=run_request AND NOT trip.
2. Reset always generates a physical start pulse in every PLC.
3. level_ok TRUE means a new operator start edge occurred.
4. The drive feedback forces the command TRUE.

**Correct option(s):** 1

- Option 1: Clearing trip makes the expression TRUE without a fresh start.
- Option 2: That is not a universal controller behaviour.
- Option 3: A permissive is not an operator command.
- Option 4: No feedback-to-command assignment is supplied.

**GICSP-Q0273 · single · diagnosis**

What should happen when reset is requested while level_ok is FALSE?

Synthetic pump specification: Start requires level_ok AND valve_open AND remote_mode. Loss of level_ok while running must stop the pump and latch trip. Reset is accepted only when level_ok is TRUE; reset must not start the pump. A fresh start edge is required after reset. Current implementation checks level_ok only in the start branch, keeps a retained run_request, and computes motor_command=run_request AND NOT trip. Evidence: level_ok becomes FALSE during run but trip remains FALSE; operator later presses reset with level_ok TRUE and retained run_request TRUE. Drive shows command TRUE, local selector LOCAL, feedback stopped. No current/flow measurement is supplied.

1. Reject reset and retain the trip under the supplied specification.
2. Change the level threshold automatically.
3. Start briefly to test whether the level sensor is correct.
4. Clear trip because reset has the highest universal priority.

**Correct option(s):** 1

- Option 1: Reset requires level_ok TRUE.
- Option 2: The case provides no authority or mechanism for that change.
- Option 3: That conflicts with the stop condition and is not authorised.
- Option 4: No such priority overrides the explicit requirement.

**GICSP-Q0274 · single · diagnosis**

What does command TRUE with selector LOCAL and stopped feedback most directly require checking?

Synthetic pump specification: Start requires level_ok AND valve_open AND remote_mode. Loss of level_ok while running must stop the pump and latch trip. Reset is accepted only when level_ok is TRUE; reset must not start the pump. A fresh start edge is required after reset. Current implementation checks level_ok only in the start branch, keeps a retained run_request, and computes motor_command=run_request AND NOT trip. Evidence: level_ok becomes FALSE during run but trip remains FALSE; operator later presses reset with level_ok TRUE and retained run_request TRUE. Drive shows command TRUE, local selector LOCAL, feedback stopped. No current/flow measurement is supplied.

1. Whether local mode rejects remote authority and how command acceptance is reported.
2. Assume the motor is physically running.
3. Replace the flow sensor immediately.
4. Assume the network has been compromised.

**Correct option(s):** 1

- Option 1: The command may not control the drive in LOCAL.
- Option 2: Feedback says stopped and no process evidence supports running.
- Option 3: No flow sensor reading is supplied.
- Option 4: Mode selection is a plausible supplied explanation.

**GICSP-Q0275 · single · diagnosis**

Which observation best demonstrates the intended pumping function, subject to instrument validity?

Synthetic pump specification: Start requires level_ok AND valve_open AND remote_mode. Loss of level_ok while running must stop the pump and latch trip. Reset is accepted only when level_ok is TRUE; reset must not start the pump. A fresh start edge is required after reset. Current implementation checks level_ok only in the start branch, keeps a retained run_request, and computes motor_command=run_request AND NOT trip. Evidence: level_ok becomes FALSE during run but trip remains FALSE; operator later presses reset with level_ok TRUE and retained run_request TRUE. Drive shows command TRUE, local selector LOCAL, feedback stopped. No current/flow measurement is supplied.

1. Only a second screen showing the same command.
2. Only the presence of a network link.
3. Appropriate process flow or pressure evidence correlated with the run state.
4. Only the supervisory run request.

**Correct option(s):** 3

- Option 1: It repeats the same source.
- Option 2: Connectivity does not establish fluid movement.
- Option 3: Physical service requires process evidence beyond a command bit.
- Option 4: A request does not prove actuation.

**GICSP-Q0276 · single · mechanism**

Which statement about safe state is correct?

Synthetic pump specification: Start requires level_ok AND valve_open AND remote_mode. Loss of level_ok while running must stop the pump and latch trip. Reset is accepted only when level_ok is TRUE; reset must not start the pump. A fresh start edge is required after reset. Current implementation checks level_ok only in the start branch, keeps a retained run_request, and computes motor_command=run_request AND NOT trip. Evidence: level_ok becomes FALSE during run but trip remains FALSE; operator later presses reset with level_ok TRUE and retained run_request TRUE. Drive shows command TRUE, local selector LOCAL, feedback stopped. No current/flow measurement is supplied.

1. Stopping the pump is the required safe response in every operating mode without reviewing consequences.
2. Installing current firmware determines the site’s acceptable loss-of-communication state.
3. It is defined for the process consequence and operating conditions by the responsible authority.
4. A TRUE feedback bit is sufficient to declare safe state without identifying what it represents.

**Correct option(s):** 3

- Option 1: The safe state depends on process design, hazards and current conditions.
- Option 2: The site’s engineering design and authority define that behaviour; firmware capability must be configured and tested.
- Option 3: De-energisation is not universally the safest outcome.
- Option 4: Feedback meaning and independent process conditions must be established.

**GICSP-Q0277 · single · design**

Which simulated case verifies separation of reset and start?

Synthetic pump specification: Start requires level_ok AND valve_open AND remote_mode. Loss of level_ok while running must stop the pump and latch trip. Reset is accepted only when level_ok is TRUE; reset must not start the pump. A fresh start edge is required after reset. Current implementation checks level_ok only in the start branch, keeps a retained run_request, and computes motor_command=run_request AND NOT trip. Evidence: level_ok becomes FALSE during run but trip remains FALSE; operator later presses reset with level_ok TRUE and retained run_request TRUE. Drive shows command TRUE, local selector LOCAL, feedback stopped. No current/flow measurement is supplied.

1. Issue start while all permissives are healthy and ignore reset.
2. Clear a valid trip while the old request remains TRUE and confirm no start until a fresh edge.
3. Rename the reset button to acknowledge.
4. Disconnect the HMI and assume the pump stopped.

**Correct option(s):** 2

- Option 1: That tests initial start only.
- Option 2: This exposes retained-command restart behaviour.
- Option 3: A label change does not alter state transitions.
- Option 4: No physical or logical outcome is verified.

**GICSP-Q0278 · multi · design**

What should a maintenance bypass record include? Select all that apply.

Synthetic pump specification: Start requires level_ok AND valve_open AND remote_mode. Loss of level_ok while running must stop the pump and latch trip. Reset is accepted only when level_ok is TRUE; reset must not start the pump. A fresh start edge is required after reset. Current implementation checks level_ok only in the start branch, keeps a retained run_request, and computes motor_command=run_request AND NOT trip. Evidence: level_ok becomes FALSE during run but trip remains FALSE; operator later presses reset with level_ok TRUE and retained run_request TRUE. Drive shows command TRUE, local selector LOCAL, feedback stopped. No current/flow measurement is supplied.

1. Only the technician's verbal assurance.
2. A permanent hidden flag to avoid repeated approvals.
3. The exact function bypassed, authority, duration and compensating measures.
4. Restoration and verification criteria.

**Correct option(s):** 3, 4

- Option 1: It lacks durable scope and restoration evidence.
- Option 2: That converts a bounded bypass into unowned persistent exposure.
- Option 3: These define the changed operating assumptions.
- Option 4: The normal safeguard must be demonstrably reinstated.

**GICSP-Q0279 · single · mechanism**

Why is a contactor auxiliary contact insufficient by itself to prove fluid delivery?

Synthetic pump specification: Start requires level_ok AND valve_open AND remote_mode. Loss of level_ok while running must stop the pump and latch trip. Reset is accepted only when level_ok is TRUE; reset must not start the pump. A fresh start edge is required after reset. Current implementation checks level_ok only in the start branch, keeps a retained run_request, and computes motor_command=run_request AND NOT trip. Evidence: level_ok becomes FALSE during run but trip remains FALSE; operator later presses reset with level_ok TRUE and retained run_request TRUE. Drive shows command TRUE, local selector LOCAL, feedback stopped. No current/flow measurement is supplied.

1. The auxiliary contact should be ignored even when correlating motor command and contactor state.
2. A matching HMI run bit provides an independent flow measurement.
3. The contact proves rated motor current and therefore sufficient flow.
4. It can indicate contactor position without verifying valve alignment or actual flow.

**Correct option(s):** 4

- Option 1: It is useful evidence of one stage, but not sufficient evidence of fluid delivery.
- Option 2: The HMI bit may simply repeat the command or contact state, not measure flow.
- Option 3: Contactor state, electrical load and hydraulic delivery are distinct observations.
- Option 4: Electrical state and process function are different observations.

**GICSP-Q0280 · single · implementation**

Which test addresses controller-restart risk in this specification?

Synthetic pump specification: Start requires level_ok AND valve_open AND remote_mode. Loss of level_ok while running must stop the pump and latch trip. Reset is accepted only when level_ok is TRUE; reset must not start the pump. A fresh start edge is required after reset. Current implementation checks level_ok only in the start branch, keeps a retained run_request, and computes motor_command=run_request AND NOT trip. Evidence: level_ok becomes FALSE during run but trip remains FALSE; operator later presses reset with level_ok TRUE and retained run_request TRUE. Drive shows command TRUE, local selector LOCAL, feedback stopped. No current/flow measurement is supplied.

1. Increase the mismatch timeout indefinitely.
2. Only check that the project name is unchanged.
3. Only restart with all retained variables already FALSE.
4. Restart with retained run_request TRUE and verify deliberate-restart gating before command output.

**Correct option(s):** 4

- Option 1: That hides discrepancies rather than testing restart logic.
- Option 2: Name equality does not establish runtime state behaviour.
- Option 3: That misses the hazardous retained condition.
- Option 4: It tests the specific state persistence hazard.

#### Recall

**Command versus feedback versus function?**

A request, an equipment-state observation and evidence of delivered process service are distinct and should be correlated.

**Why separate reset from restart?**

Where required, clearing a trip must not turn an old retained request into an unintended fresh start.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

### GICSP-L029 — Project changes, forces and controller baselines

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L028

A controller project is more than a file name. It can contain logic, hardware configuration, task scheduling, communication settings, symbols, recipes and references to external libraries. A workstation project, downloaded executable and online controller state may differ. Record the tool version, target firmware, library versions and build settings that produce the intended executable. A source archive without the required compiler or protected library can be inadequate for recovery even if its checksum is intact.

Baseline comparison needs a defined object. A raw export hash is useful for byte integrity but may change when metadata or ordering changes. A vendor-supported online/offline comparison can reveal logic or configuration differences, subject to its coverage and access. Some runtime values, forces, retained memory, device parameters or safety signatures may be outside a routine comparison. Read the comparison scope and supplement it with the relevant state records. “No differences” is meaningful only for the things the tool actually compared.

An online edit can change running behaviour without a full project download or controller restart, depending on the platform. The method may involve pending, accepted, tested and committed stages; terminology and rollback capability are vendor-specific. Define the supported workflow before use. Record the approved change, affected functions, authorisation, pre-change state, verification and completion state. An abandoned pending edit can create ambiguity for the next engineer. Do not assume a successful transfer means the running process matches the approved requirements.

Forces override normal input/output or variable behaviour under platform-defined rules. A force can make a logic test convenient while hiding a real sensor state or holding an output despite normal logic. Forces need explicit scope, authority, indication, duration and restoration checks. Removing a force can also cause a sudden transition, so restoration must be planned with operations. A project restore may not clear every force table or external device override; verify rather than relying on a generic reboot.

Review the semantic effect of a change. Moving a comparison threshold, changing a timer preset, replacing an AND with OR, altering task period or bypassing a quality check can change consequences with only a few bytes. Conversely, adding a comment can change a file hash without changing execution. Trace each approved requirement to the actual changed logic and test boundary/degraded cases. Maintain a reasoned difference record so reviewers can understand why the new behaviour is intended.

Release and recovery evidence should establish what is running, who authorised it, which tests passed and which deviations remain. Keep a trusted approved baseline outside the engineering workstation's sole control, with protected history and usable restoration materials. After a suspected compromise, a recent backup may already include the unauthorised change. Select a known-good point using evidence, then validate the restored programme, runtime configuration, permissions, forces and physical process state before acceptance. The offline comparison in this lesson teaches interpretation; actual online work remains a separately authorised engineering activity.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic project review: approved P10 contains `IF temp > 35 AND quality_good THEN alarm := TRUE; END_IF;`. Workstation file P10-new changes 35 to 45; its comment says “display label only.” Controller comparison reports “logic equal” because the selected comparison scope includes configuration but excludes programme blocks; its heading is misleadingly copied into a summary. Controller force table holds input quality_good=TRUE. Tool version 7 compiles against library L2, while the recovery workstation has tool 6 and only L1. A full source zip has a valid hash, but no build or restore test was performed.

**Reasoning:** The threshold change is functional and conflicts with the claimed label-only change; test its approved requirement before release. The supplied comparison did not examine programme blocks, so it cannot prove logic equality. The force can conceal bad measurement quality and needs bounded restoration. Source integrity is not build reproducibility: tool/library compatibility and recovery execution remain unverified. Preserve the actual comparison scope and force state in the evidence package.

#### Guided practice

Evaluate an input of 40 °C with quality_good TRUE for P10 and P10-new, assuming alarm initially FALSE.

**Hint:** Apply the stated comparison thresholds.

**Worked solution:** P10 sets alarm TRUE because 40>35; P10-new does not set it because 40>45 is false. This is a functional difference, irrespective of the comment.

#### Independent task

Environment: analytical

Write a change rejection or conditional-release record with a recovery validation plan.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L029.json

**Evidence to produce**

- Semantic difference table
- Comparison-scope correction
- Force restoration plan
- Tool/library recovery dependency list

**Acceptance criteria**

- The 35→45 change is treated as functional.
- Configuration-only comparison is not claimed to verify logic.
- A source hash is not claimed to prove recoverable execution.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0281 · single · calculation**

At 40 °C with good quality and initially FALSE alarm, how do the supplied blocks differ?

Synthetic project review: approved P10 contains `IF temp > 35 AND quality_good THEN alarm := TRUE; END_IF;`. Workstation file P10-new changes 35 to 45; its comment says “display label only.” Controller comparison reports “logic equal” because the selected comparison scope includes configuration but excludes programme blocks; its heading is misleadingly copied into a summary. Controller force table holds input quality_good=TRUE. Tool version 7 compiles against library L2, while the recovery workstation has tool 6 and only L1. A full source zip has a valid hash, but no build or restore test was performed.

1. Both blocks leave alarm FALSE.
2. P10 leaves alarm FALSE while P10-new sets it TRUE.
3. Both blocks set alarm TRUE.
4. P10 sets the alarm; P10-new does not.

**Correct option(s):** 4

- Option 1: At 40°C with good quality, the approved greater-than-35 condition is true.
- Option 2: This reverses the effects of the 35°C and 45°C thresholds.
- Option 3: The revised greater-than-45 condition is false at 40°C.
- Option 4: Forty exceeds 35 but not 45.

**GICSP-Q0282 · single · diagnosis**

Why is the “logic equal” summary unsupported?

Synthetic project review: approved P10 contains `IF temp > 35 AND quality_good THEN alarm := TRUE; END_IF;`. Workstation file P10-new changes 35 to 45; its comment says “display label only.” Controller comparison reports “logic equal” because the selected comparison scope includes configuration but excludes programme blocks; its heading is misleadingly copied into a summary. Controller force table holds input quality_good=TRUE. Tool version 7 compiles against library L2, while the recovery workstation has tool 6 and only L1. A full source zip has a valid hash, but no build or restore test was performed.

1. The controller model was not printed in the comment.
2. A valid zip hash guarantees the summary is true.
3. All online comparisons are inherently useless.
4. Programme blocks were excluded from the actual comparison scope.

**Correct option(s):** 4

- Option 1: That may matter elsewhere but is not the supplied scope defect.
- Option 2: File integrity does not expand a tool's comparison scope.
- Option 3: Properly scoped comparisons can provide relevant evidence.
- Option 4: Configuration equality cannot establish logic equality.

**GICSP-Q0283 · single · diagnosis**

What is the effect of forcing quality_good TRUE?

Synthetic project review: approved P10 contains `IF temp > 35 AND quality_good THEN alarm := TRUE; END_IF;`. Workstation file P10-new changes 35 to 45; its comment says “display label only.” Controller comparison reports “logic equal” because the selected comparison scope includes configuration but excludes programme blocks; its heading is misleadingly copied into a summary. Controller force table holds input quality_good=TRUE. Tool version 7 compiles against library L2, while the recovery workstation has tool 6 and only L1. A full source zip has a valid hash, but no build or restore test was performed.

1. It prevents every temperature alarm.
2. Logic may treat invalid measurement as good despite the real input state.
3. It calibrates the physical transmitter.
4. It proves the input wiring is healthy.

**Correct option(s):** 2

- Option 1: The temperature condition can still set an alarm when forced quality is TRUE.
- Option 2: The force overrides the normal quality signal in the supplied model.
- Option 3: A logic force does not adjust sensor accuracy.
- Option 4: The override can hide wiring or measurement faults.

**GICSP-Q0284 · single · operations**

What must be considered before removing the quality force?

Synthetic project review: approved P10 contains `IF temp > 35 AND quality_good THEN alarm := TRUE; END_IF;`. Workstation file P10-new changes 35 to 45; its comment says “display label only.” Controller comparison reports “logic equal” because the selected comparison scope includes configuration but excludes programme blocks; its heading is misleadingly copied into a summary. Controller force table holds input quality_good=TRUE. Tool version 7 compiles against library L2, while the recovery workstation has tool 6 and only L1. A full source zip has a valid hash, but no build or restore test was performed.

1. Assume the current forced-good state represents the real sensor quality.
2. Remove the force solely because the project source matches its reference.
3. Delete the project archive first.
4. The resulting logic/process transition and an approved restoration check.

**Correct option(s):** 4

- Option 1: The force explicitly replaces that runtime input and can conceal bad quality.
- Option 2: Actual input quality and the operational consequences of releasing the override must be assessed.
- Option 3: That removes recovery evidence without helping restoration.
- Option 4: Returning to the real signal may change alarm or control behaviour.

**GICSP-Q0285 · single · diagnosis**

Which recovery dependency is unresolved despite the valid source-zip hash?

Synthetic project review: approved P10 contains `IF temp > 35 AND quality_good THEN alarm := TRUE; END_IF;`. Workstation file P10-new changes 35 to 45; its comment says “display label only.” Controller comparison reports “logic equal” because the selected comparison scope includes configuration but excludes programme blocks; its heading is misleadingly copied into a summary. Controller force table holds input quality_good=TRUE. Tool version 7 compiles against library L2, while the recovery workstation has tool 6 and only L1. A full source zip has a valid hash, but no build or restore test was performed.

1. Whether comments can be stored in text.
2. Whether the zip bytes changed after hashing.
3. Whether a project can contain source files.
4. Compatible tool and library availability to reproduce the intended build.

**Correct option(s):** 4

- Option 1: That is unrelated to build compatibility.
- Option 2: The supplied valid hash addresses that comparison.
- Option 3: The case explicitly supplies a source archive.
- Option 4: Integrity does not ensure tool 6/L1 can reproduce tool 7/L2 output.

**GICSP-Q0286 · single · mechanism**

What can an online edit change on a supporting platform?

Synthetic project review: approved P10 contains `IF temp > 35 AND quality_good THEN alarm := TRUE; END_IF;`. Workstation file P10-new changes 35 to 45; its comment says “display label only.” Controller comparison reports “logic equal” because the selected comparison scope includes configuration but excludes programme blocks; its heading is misleadingly copied into a summary. Controller force table holds input quality_good=TRUE. Tool version 7 compiles against library L2, while the recovery workstation has tool 6 and only L1. A full source zip has a valid hash, but no build or restore test was performed.

1. Nothing until the next hardware replacement.
2. Running programme behaviour without a full download or restart.
3. Only comments in the offline project, with no possible runtime effect.
4. Always every safety signature automatically and identically across vendors.

**Correct option(s):** 2

- Option 1: That is not the meaning of supported online editing.
- Option 2: The platform may apply staged changes to active execution.
- Option 3: Supported online editing can change active executable behaviour, not only descriptive text.
- Option 4: Semantics and protected domains are platform-specific.

**GICSP-Q0287 · single · mechanism**

Which change can be operationally significant despite a small byte difference?

Synthetic project review: approved P10 contains `IF temp > 35 AND quality_good THEN alarm := TRUE; END_IF;`. Workstation file P10-new changes 35 to 45; its comment says “display label only.” Controller comparison reports “logic equal” because the selected comparison scope includes configuration but excludes programme blocks; its heading is misleadingly copied into a summary. Controller force table holds input quality_good=TRUE. Tool version 7 compiles against library L2, while the recovery workstation has tool 6 and only L1. A full source zip has a valid hash, but no build or restore test was performed.

1. Reordering purely descriptive report headings.
2. Changing an AND condition to OR in a permissive.
3. Adding an unused comment without executable effect.
4. Changing an archive filename while preserving all content.

**Correct option(s):** 2

- Option 1: Those headings do not change controller execution.
- Option 2: It changes the required combination of conditions.
- Option 3: That may change bytes but not the stated runtime logic.
- Option 4: Naming alone does not establish a runtime change.

**GICSP-Q0288 · multi · design**

What should a trusted baseline include? Select all that apply.

Synthetic project review: approved P10 contains `IF temp > 35 AND quality_good THEN alarm := TRUE; END_IF;`. Workstation file P10-new changes 35 to 45; its comment says “display label only.” Controller comparison reports “logic equal” because the selected comparison scope includes configuration but excludes programme blocks; its heading is misleadingly copied into a summary. Controller force table holds input quality_good=TRUE. Tool version 7 compiles against library L2, while the recovery workstation has tool 6 and only L1. A full source zip has a valid hash, but no build or restore test was performed.

1. Only a screenshot saying download complete.
2. Relevant runtime/force-state checks and acceptance evidence.
3. Only the newest file on the engineering desktop.
4. Approved source/build dependencies and the intended deployed configuration.

**Correct option(s):** 2, 4

- Option 1: Transfer completion does not prove correct behaviour.
- Option 2: A project file alone may omit consequential active state.
- Option 3: Recency and location do not establish approval or integrity.
- Option 4: Recovery and comparison need a defined reproducible target.

**GICSP-Q0289 · single · recovery**

Why might the newest backup be unsuitable after a suspected unauthorised change?

Synthetic project review: approved P10 contains `IF temp > 35 AND quality_good THEN alarm := TRUE; END_IF;`. Workstation file P10-new changes 35 to 45; its comment says “display label only.” Controller comparison reports “logic equal” because the selected comparison scope includes configuration but excludes programme blocks; its heading is misleadingly copied into a summary. Controller force table holds input quality_good=TRUE. Tool version 7 compiles against library L2, while the recovery workstation has tool 6 and only L1. A full source zip has a valid hash, but no build or restore test was performed.

1. Any older copy can be accepted without checking its approval and build dependencies.
2. A controller project cannot be included in a backup at all.
3. The newest backup is unsuitable because recent files are less encrypted.
4. It may already contain the unwanted modification.

**Correct option(s):** 4

- Option 1: Age alone does not establish a trusted, compatible recovery source.
- Option 2: Projects can be backed up; provenance and active-state compatibility must be assessed.
- Option 3: The concern is that it may contain the unauthorised state, not its age implying weaker encryption.
- Option 4: Recovery-point selection needs evidence of trust, not recency alone.

**GICSP-Q0290 · single · diagnosis**

Which release conclusion follows from this evidence?

Synthetic project review: approved P10 contains `IF temp > 35 AND quality_good THEN alarm := TRUE; END_IF;`. Workstation file P10-new changes 35 to 45; its comment says “display label only.” Controller comparison reports “logic equal” because the selected comparison scope includes configuration but excludes programme blocks; its heading is misleadingly copied into a summary. Controller force table holds input quality_good=TRUE. Tool version 7 compiles against library L2, while the recovery workstation has tool 6 and only L1. A full source zip has a valid hash, but no build or restore test was performed.

1. Reject every future use of this engineering tool.
2. Accept because the archive hash is valid.
3. The functional change and incomplete comparison/recovery evidence require resolution before acceptance.
4. Accept because the summary uses the word equal.

**Correct option(s):** 3

- Option 1: The findings concern this change and evidence, not a universal product prohibition.
- Option 2: Integrity is only one requirement.
- Option 3: The supplied label-only rationale does not match the code.
- Option 4: The actual scope excludes the relevant blocks.

#### Recall

**What does a baseline comparison need?**

A defined object and scope: source, logic, configuration, runtime state and forces may require different checks.

**Why does a source archive not equal recovery capability?**

Correct tools, libraries, licences, target compatibility, runtime data and validated restoration may also be required.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

### GICSP-L030 — Remote I/O, drives and protection-device interfaces

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L029

Remote I/O extends controller inputs and outputs across a communication link. The controller may receive valid-looking cached values after an I/O adapter loses contact with its modules unless quality and age are propagated correctly. Define failure handling for each direction: what the controller knows about input validity, what outputs do on connection loss, and how reconnection is accepted. Hold-last-value, substitute value and de-energise are different behaviours with different process consequences; none is universally correct. The process specification and supported device settings determine the required choice.

A variable-frequency drive combines communication interfaces with local control, power electronics and protection functions. A supervisory speed reference is not the same as motor speed, and a run command is not the same as torque-producing operation. Local/remote selection, drive enable, interlocks, ramp limits and faults can prevent or delay the requested response. A communication timeout may trigger a configured ramp stop, coast, continued operation or other supported action. Verify the actual configuration and operating context. A safety-related stop function, where present and correctly engineered, has a distinct purpose and must not be casually equated with an ordinary network stop bit.

Intelligent electronic devices may perform metering, protection, event recording and control within the same enclosure. Access to a monitoring register does not authorise protection-setting changes. A gateway can expose several device functions through one IP endpoint, so classify operations rather than treating the device as uniformly read-only. Preserve the boundary between integrating status into EPMS/BMS and owning primary electrical protection design. Escalate setting, trip and selectivity questions to the authorised electrical/protection specialist; the network/security engineer can still analyse access paths, timing, provenance and evidence.

Serial and Ethernet failures require physical and protocol context. RS-485 is an electrical layer, not a complete application protocol; Modbus RTU is one protocol that can use it. Baud rate, parity, addressing, polarity, termination, biasing, cable topology and ground potential can affect communications. Two 120-ohm terminating resistors in parallel produce a nominal 60-ohm equivalent in the simplified isolated resistance model, but live circuits, bias networks and connected electronics can invalidate a simple measurement interpretation. Use approved vendor procedures and competent personnel for actual electrical work.

A shared serial bus is also a security and availability boundary. Duplicate addresses can create collisions or ambiguous responses; a gateway cannot necessarily attribute a response to a unique physical device without correct configuration. One noisy or malfunctioning participant can affect several downstream assets. IP inventory alone therefore understates the scope behind a gateway. Record unit addresses, physical locations, function maps, serial settings and ownership, and propagate device-specific quality instead of presenting one gateway heartbeat as proof that every field value is current.

For diagnosis, separate layers in the evidence: link/carrier state, transport connection, protocol response, device mode, command acceptance and actual physical function. A successful TCP connection to a gateway does not prove a healthy serial transaction. An application exception is different from a timeout. A device reboot can clear transient symptoms while erasing useful diagnostics and changing output state, so it needs a bounded operational decision. The supplied records are analytical; actual drive, protection and wiring interventions require their own authorised practical environment and specialist acceptance.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic interface case: Gateway G has Ethernet link up and TCP 502 available. Serial bus contains meter unit 7 and a newly added meter also configured as unit 7. Logs show CRC errors and intermittent response timeouts after addition. Remote I/O adapter A remains online to the controller but channel diagnostics say module lost; HMI substitutes last value 42.0 with quality GOOD and a fresh display timestamp. Drive D receives speed reference 60%, is in LOCAL mode and reports actual speed 0%. Its communication-loss action is configured hold last reference. IED P exposes both metering reads and setting writes through G; the project authority covers monitoring integration only.

**Reasoning:** TCP 502 availability proves only the gateway service path, not serial health. Duplicate unit addresses are a concrete configuration fault; CRC errors also require physical/timing diagnosis rather than automatic attack attribution. The I/O display misrepresents module-lost data as fresh/good. Drive command and mode explain why the remote reference need not produce speed; verify actual authority and timeout consequences. Restrict the IED integration to approved monitoring operations and route protection-setting decisions to the responsible specialist.

#### Guided practice

Create a layered fault tree for the gateway and field devices.

**Hint:** Separate Ethernet service, serial response, individual channel quality and process state.

**Worked solution:** Branches include gateway transport healthy but serial bus ambiguous; adapter online but module unavailable; drive local mode rejecting remote control; IED write capability beyond project authority. Each needs distinct evidence and owner.

#### Independent task

Environment: analytical

Produce an interface contract and evidence-based diagnosis.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L030.json

**Evidence to produce**

- Downstream device inventory
- Quality/age propagation specification
- Drive mode and timeout assessment
- IED authority boundary

**Acceptance criteria**

- Gateway reachability is not treated as device health.
- Duplicate serial addresses are identified without claiming a proven attacker.
- Protection settings remain under the designated specialist authority.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0291 · single · diagnosis**

What does the successful TCP 502 connection to G establish?

Synthetic interface case: Gateway G has Ethernet link up and TCP 502 available. Serial bus contains meter unit 7 and a newly added meter also configured as unit 7. Logs show CRC errors and intermittent response timeouts after addition. Remote I/O adapter A remains online to the controller but channel diagnostics say module lost; HMI substitutes last value 42.0 with quality GOOD and a fresh display timestamp. Drive D receives speed reference 60%, is in LOCAL mode and reports actual speed 0%. Its communication-loss action is configured hold last reference. IED P exposes both metering reads and setting writes through G; the project authority covers monitoring integration only.

1. The Ethernet link proves all downstream serial unit identities are unique.
2. The gateway's TCP service is reachable from the test point.
3. A duplicate unit address is harmless because both meters are on the same bus.
4. TCP 502 availability rules out serial bus faults.

**Correct option(s):** 2

- Option 1: The new meter duplicates unit 7 despite the upstream link remaining available.
- Option 2: It does not prove downstream serial responses are valid.
- Option 3: Competing responses and ambiguous addressing can explain the new errors.
- Option 4: The gateway’s listening service does not establish downstream serial communication health.

**GICSP-Q0292 · single · diagnosis**

Which supplied configuration defect directly creates serial-address ambiguity?

Synthetic interface case: Gateway G has Ethernet link up and TCP 502 available. Serial bus contains meter unit 7 and a newly added meter also configured as unit 7. Logs show CRC errors and intermittent response timeouts after addition. Remote I/O adapter A remains online to the controller but channel diagnostics say module lost; HMI substitutes last value 42.0 with quality GOOD and a fresh display timestamp. Drive D receives speed reference 60%, is in LOCAL mode and reports actual speed 0%. Its communication-loss action is configured hold last reference. IED P exposes both metering reads and setting writes through G; the project authority covers monitoring integration only.

1. The HMI displays one decimal place.
2. Two devices share unit address 7.
3. The gateway uses TCP port 502.
4. The drive reference is a percentage.

**Correct option(s):** 2

- Option 1: Formatting does not create duplicate device addresses.
- Option 2: The gateway cannot uniquely address them as distinct units on that bus.
- Option 3: That is consistent with the stated Modbus service.
- Option 4: This is unrelated to the meter bus addressing.

**GICSP-Q0293 · single · diagnosis**

Why is the remote-I/O HMI indication misleading?

Synthetic interface case: Gateway G has Ethernet link up and TCP 502 available. Serial bus contains meter unit 7 and a newly added meter also configured as unit 7. Logs show CRC errors and intermittent response timeouts after addition. Remote I/O adapter A remains online to the controller but channel diagnostics say module lost; HMI substitutes last value 42.0 with quality GOOD and a fresh display timestamp. Drive D receives speed reference 60%, is in LOCAL mode and reports actual speed 0%. Its communication-loss action is configured hold last reference. IED P exposes both metering reads and setting writes through G; the project authority covers monitoring integration only.

1. It labels a cached value GOOD with a fresh timestamp despite module loss.
2. Adapter connectivity is sufficient evidence that every remote channel remains valid.
3. The number 42.0 alone proves an impossible physical reading.
4. Delete the cached record so no missing-quality condition remains visible.

**Correct option(s):** 1

- Option 1: The presentation hides invalid source quality and age.
- Option 2: The adapter can be online while the module is lost.
- Option 3: No valid range is supplied; the defect is stale cached data presented as good/current after module loss.
- Option 4: Retaining value with explicit stale/bad quality is more informative than hiding the loss.

**GICSP-Q0294 · single · diagnosis**

What explains the difference between D's 60% reference and 0% actual speed without assuming a cyberattack?

Synthetic interface case: Gateway G has Ethernet link up and TCP 502 available. Serial bus contains meter unit 7 and a newly added meter also configured as unit 7. Logs show CRC errors and intermittent response timeouts after addition. Remote I/O adapter A remains online to the controller but channel diagnostics say module lost; HMI substitutes last value 42.0 with quality GOOD and a fresh display timestamp. Drive D receives speed reference 60%, is in LOCAL mode and reports actual speed 0%. Its communication-loss action is configured hold last reference. IED P exposes both metering reads and setting writes through G; the project authority covers monitoring integration only.

1. A 60% reference mathematically means 0% speed.
2. Every stopped drive has failed power electronics.
3. The Ethernet link guarantees the motor is turning.
4. LOCAL mode may prevent the remote reference from controlling the drive.

**Correct option(s):** 4

- Option 1: Those values have different meanings.
- Option 2: Several mode, enable and interlock conditions can stop it.
- Option 3: Link state does not establish actuation.
- Option 4: Mode and command authority must be checked.

**GICSP-Q0295 · single · design**

What must be assessed about D's communication-loss configuration?

Synthetic interface case: Gateway G has Ethernet link up and TCP 502 available. Serial bus contains meter unit 7 and a newly added meter also configured as unit 7. Logs show CRC errors and intermittent response timeouts after addition. Remote I/O adapter A remains online to the controller but channel diagnostics say module lost; HMI substitutes last value 42.0 with quality GOOD and a fresh display timestamp. Drive D receives speed reference 60%, is in LOCAL mode and reports actual speed 0%. Its communication-loss action is configured hold last reference. IED P exposes both metering reads and setting writes through G; the project authority covers monitoring integration only.

1. Assume a network disconnect always removes torque.
2. Whether holding the last reference is acceptable for the defined process and failure condition.
3. Change the setting immediately without operations review.
4. Assume hold-last is always the safest choice.

**Correct option(s):** 2

- Option 1: The supplied configuration says otherwise.
- Option 2: Timeout behaviour is a process-dependent requirement.
- Option 3: It can alter physical behaviour and needs authority.
- Option 4: Some processes require a controlled stop or other response.

**GICSP-Q0296 · single · mechanism**

Which distinction between RS-485 and Modbus RTU is correct?

Synthetic interface case: Gateway G has Ethernet link up and TCP 502 available. Serial bus contains meter unit 7 and a newly added meter also configured as unit 7. Logs show CRC errors and intermittent response timeouts after addition. Remote I/O adapter A remains online to the controller but channel diagnostics say module lost; HMI substitutes last value 42.0 with quality GOOD and a fresh display timestamp. Drive D receives speed reference 60%, is in LOCAL mode and reports actual speed 0%. Its communication-loss action is configured hold last reference. IED P exposes both metering reads and setting writes through G; the project authority covers monitoring integration only.

1. Modbus RTU necessarily provides user authentication.
2. RS-485 requires IP addresses.
3. RS-485 specifies an electrical signalling layer; Modbus RTU supplies protocol framing and application exchanges.
4. They are two names for the same complete protocol.

**Correct option(s):** 3

- Option 1: Traditional RTU exchanges do not supply that by default.
- Option 2: It is not inherently an IP network.
- Option 3: They describe different layers.
- Option 4: Electrical signalling does not define all message semantics.

**GICSP-Q0297 · single · calculation**

In the explicitly simplified isolated model, what is two 120-ohm terminations in parallel?

Synthetic interface case: Gateway G has Ethernet link up and TCP 502 available. Serial bus contains meter unit 7 and a newly added meter also configured as unit 7. Logs show CRC errors and intermittent response timeouts after addition. Remote I/O adapter A remains online to the controller but channel diagnostics say module lost; HMI substitutes last value 42.0 with quality GOOD and a fresh display timestamp. Drive D receives speed reference 60%, is in LOCAL mode and reports actual speed 0%. Its communication-loss action is configured hold last reference. IED P exposes both metering reads and setting writes through G; the project authority covers monitoring integration only.

1. 0 ohms.
2. 120 ohms.
3. 60 ohms.
4. 240 ohms.

**Correct option(s):** 3

- Option 1: Finite resistors do not form an ideal short.
- Option 2: That ignores the second parallel path.
- Option 3: Equal resistors in parallel halve the resistance.
- Option 4: That would be a series combination.

**GICSP-Q0298 · single · diagnosis**

Which operation is outside the supplied monitoring-integration authority?

Synthetic interface case: Gateway G has Ethernet link up and TCP 502 available. Serial bus contains meter unit 7 and a newly added meter also configured as unit 7. Logs show CRC errors and intermittent response timeouts after addition. Remote I/O adapter A remains online to the controller but channel diagnostics say module lost; HMI substitutes last value 42.0 with quality GOOD and a fresh display timestamp. Drive D receives speed reference 60%, is in LOCAL mode and reports actual speed 0%. Its communication-loss action is configured hold last reference. IED P exposes both metering reads and setting writes through G; the project authority covers monitoring integration only.

1. Changing IED protection settings.
2. Documenting the gateway's access paths.
3. Reporting an unauthorised-write exposure.
4. Reading approved metering values.

**Correct option(s):** 1

- Option 1: The project scope explicitly reserves that function to the specialist owner.
- Option 2: Network/security evidence is relevant to integration.
- Option 3: Identifying a gap does not itself change protection settings.
- Option 4: Monitoring reads are within the stated integration function.

**GICSP-Q0299 · multi · design**

What should the downstream inventory include? Select all that apply.

Synthetic interface case: Gateway G has Ethernet link up and TCP 502 available. Serial bus contains meter unit 7 and a newly added meter also configured as unit 7. Logs show CRC errors and intermittent response timeouts after addition. Remote I/O adapter A remains online to the controller but channel diagnostics say module lost; HMI substitutes last value 42.0 with quality GOOD and a fresh display timestamp. Drive D receives speed reference 60%, is in LOCAL mode and reports actual speed 0%. Its communication-loss action is configured hold last reference. IED P exposes both metering reads and setting writes through G; the project authority covers monitoring integration only.

1. Serial unit addresses and physical/function identities.
2. Only the number of Ethernet switch ports.
3. Serial settings and per-device quality expectations.
4. Only the gateway IP address.

**Correct option(s):** 1, 3

- Option 1: These distinguish devices behind one IP gateway.
- Option 2: Serial devices do not map one-to-one to those ports.
- Option 3: They support communications and freshness diagnosis.
- Option 4: That omits downstream assets and their consequences.

**GICSP-Q0300 · single · diagnosis**

What is a defensible interpretation of CRC errors after installation?

Synthetic interface case: Gateway G has Ethernet link up and TCP 502 available. Serial bus contains meter unit 7 and a newly added meter also configured as unit 7. Logs show CRC errors and intermittent response timeouts after addition. Remote I/O adapter A remains online to the controller but channel diagnostics say module lost; HMI substitutes last value 42.0 with quality GOOD and a fresh display timestamp. Drive D receives speed reference 60%, is in LOCAL mode and reports actual speed 0%. Its communication-loss action is configured hold last reference. IED P exposes both metering reads and setting writes through G; the project authority covers monitoring integration only.

1. They prove the protection logic is incorrect.
2. Communication integrity is failing; investigate address, wiring, timing and device conditions before attributing intent.
3. They prove malicious packet modification.
4. They can be ignored because TCP 502 is reachable.

**Correct option(s):** 2

- Option 1: Communications errors do not directly reveal logic settings.
- Option 2: Several accidental and malicious causes remain possible.
- Option 3: CRC errors alone do not establish intent.
- Option 4: Gateway transport health does not fix serial corruption.

#### Recall

**Does an online gateway mean every field point is healthy?**

No. Preserve downstream device/channel diagnostics, source timestamps and quality through the gateway and display.

**Why separate monitoring from protection authority?**

One device may expose both, but integrating status does not authorise changing primary protection design or settings.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

## GICSP-M07 — Supervisory and operations technology protection

### GICSP-L031 — HMI authority, alarms and truthful operator displays

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L030

An HMI is an operational interface to a model of the process. Its usefulness depends on both the underlying data and the way uncertainty and authority are shown. Distinguish requested value, accepted command, actual feedback, operating mode and data quality. A button animation that turns green when clicked may show only that the user interface accepted input. If the controller rejects the command or the device is in local mode, the display must not imply that the physical action occurred. Confirm consequential actions using appropriate feedback and process evidence.

An alarm should indicate an abnormal condition requiring a defined operator response. Events and status changes can be useful records without all becoming alarms. Rationalisation assigns the cause, consequence, required response, priority and timing to each alarm. Too many low-value or chattering alarms can obscure the important one. Priority follows consequence and available response time rather than the order in which a developer created tags. Operators need actionable context, not merely a large red count.

Deadband and delay address different problems. For a high alarm that activates above 30 °C and clears below 29 °C, the one-degree hysteresis prevents repeated toggling around 30. A three-second on-delay requires the condition to persist before activation, reducing short transients but adding detection delay. The actual boundary operators, scan interval and timer semantics must be stated. Do not tune delay merely to silence an inconvenient alarm if it consumes the response time needed to prevent a consequence. Off-delay, latching and acknowledgment add separate state transitions.

Acknowledgment usually records that an operator has recognised an alarm; it does not necessarily remove the abnormal condition or reset a protective trip. Shelving temporarily suppresses presentation under an authorised arrangement, while out-of-service status supports planned maintenance with its own controls. Exact platform terminology varies. Record who changed alarm state, the reason, duration and restoration condition. A permanent hidden suppression can remove a required response function even when the control loop continues to run.

Data age should be measured from the relevant source observation, not refreshed merely because the screen repaints. If a gateway repeatedly republishes the same old sample with a new receipt timestamp, the user can be misled unless both source time and quality are preserved. Show bad, uncertain or stale values distinctly and define the fallback operational procedure. A plausible number with a green quality icon can be more dangerous than an obvious missing value because it invites confident but unsupported action.

Enforce command permissions on the trusted server/controller path, not only by hiding buttons. A user who cannot see a write control may still call an API if authorisation is missing there. Log the requesting identity, target, requested value, acceptance or rejection, and subsequent feedback where supported. Test role boundaries, stale-data behaviour, alarm timing, shelving expiry, acknowledgment and recovery in an isolated environment. Operator usability and technical correctness are both acceptance concerns: a secure interface that obscures a critical condition has not met its operational purpose.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic HMI alarm definition: high alarm activates when temperature >30 °C continuously for 3.0 s; clears when temperature <29 °C; equality does neither. The analytical model has instantaneous sampling and timer evaluation. Trace: 0–2 s 31 °C, 2–4 s 29.5 °C, 4–8 s 31 °C, 8–10 s 29.5 °C, after 10 s 28.5 °C. Alarm is initially inactive. Acknowledge occurs at 7.5 s. Source sample timestamp is 12:00:00; gateway repaints at 12:00:20 with unchanged data and quality GOOD. Stale limit is 10 s. Viewer role has no button, but the write API accepts its request. Alarm shelving has no expiry.

**Reasoning:** The first two-second excursion does not satisfy the delay. The second excursion activates at 7 s, remains active through acknowledgment and 29.5 °C, and clears after the value becomes 28.5 °C at 10 s under the stated ideal model. At 12:00:20 the source is twenty seconds old, beyond the stale limit despite repainting. The API lacks the required role enforcement. Unlimited shelving needs bounded authority and restoration, not a cosmetic display change.

#### Guided practice

Explain the alarm state at 7.8 s and 9 s, and the effect of acknowledgment.

**Hint:** Separate active condition, hysteresis and acknowledged state.

**Worked solution:** At both times the alarm remains active and acknowledged: it activated at 7 s, acknowledgment does not clear the condition, and 29.5 °C has not crossed below the 29 °C clearing threshold.

#### Independent task

Environment: analytical

Write an HMI acceptance script using the trace and authority defects.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L031.json

**Evidence to produce**

- Alarm-state timeline
- Source-age display checks
- Viewer API negative test specification
- Shelving/restoration criteria

**Acceptance criteria**

- Activation at 7 s and clearing at 10 s follow the explicit ideal model.
- Acknowledgment is not treated as process recovery.
- Server/API authorisation and source freshness are tested.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0301 · single · calculation**

When does the high alarm first activate in the supplied ideal model?

Synthetic HMI alarm definition: high alarm activates when temperature >30 °C continuously for 3.0 s; clears when temperature <29 °C; equality does neither. The analytical model has instantaneous sampling and timer evaluation. Trace: 0–2 s 31 °C, 2–4 s 29.5 °C, 4–8 s 31 °C, 8–10 s 29.5 °C, after 10 s 28.5 °C. Alarm is initially inactive. Acknowledge occurs at 7.5 s. Source sample timestamp is 12:00:00; gateway repaints at 12:00:20 with unchanged data and quality GOOD. Stale limit is 10 s. Viewer role has no button, but the write API accepts its request. Alarm shelving has no expiry.

1. 7 s.
2. At 3 s, because the initial high samples start a timer that continues through 29.5°C.
3. At 7.5 s, when the operator acknowledges.
4. At 4 s, immediately when the second high interval begins.

**Correct option(s):** 1

- Option 1: The second excursion begins at 4 s and persists for the required three seconds.
- Option 2: The requirement demands continuously above 30°C; the interval from 2 to 4 s breaks continuity.
- Option 3: Acknowledgement is separate from alarm activation; the timing condition is satisfied at 7 s.
- Option 4: The second interval must persist for three seconds before activation.

**GICSP-Q0302 · single · diagnosis**

What is the alarm state at 9 s?

Synthetic HMI alarm definition: high alarm activates when temperature >30 °C continuously for 3.0 s; clears when temperature <29 °C; equality does neither. The analytical model has instantaneous sampling and timer evaluation. Trace: 0–2 s 31 °C, 2–4 s 29.5 °C, 4–8 s 31 °C, 8–10 s 29.5 °C, after 10 s 28.5 °C. Alarm is initially inactive. Acknowledge occurs at 7.5 s. Source sample timestamp is 12:00:00; gateway repaints at 12:00:20 with unchanged data and quality GOOD. Stale limit is 10 s. Viewer role has no button, but the write API accepts its request. Alarm shelving has no expiry.

1. Unacknowledged because any temperature change resets acknowledgment.
2. Active and acknowledged.
3. A protective trip is necessarily reset.
4. Inactive because temperature is below 30 °C.

**Correct option(s):** 2

- Option 1: No such rule is supplied.
- Option 2: It was acknowledged at 7.5 s and 29.5 °C has not crossed the clearing threshold.
- Option 3: Alarm acknowledgment does not establish trip behaviour.
- Option 4: Clearing requires below 29 °C, not merely below activation.

**GICSP-Q0303 · single · calculation**

At what point does the supplied trace clear the alarm?

Synthetic HMI alarm definition: high alarm activates when temperature >30 °C continuously for 3.0 s; clears when temperature <29 °C; equality does neither. The analytical model has instantaneous sampling and timer evaluation. Trace: 0–2 s 31 °C, 2–4 s 29.5 °C, 4–8 s 31 °C, 8–10 s 29.5 °C, after 10 s 28.5 °C. Alarm is initially inactive. Acknowledge occurs at 7.5 s. Source sample timestamp is 12:00:00; gateway repaints at 12:00:20 with unchanged data and quality GOOD. Stale limit is 10 s. Viewer role has no button, but the write API accepts its request. Alarm shelving has no expiry.

1. 8 s at 29.5 °C.
2. Only after a controller restart.
3. 10 s when temperature becomes 28.5 °C.
4. 7.5 s at acknowledgment.

**Correct option(s):** 3

- Option 1: That lies within the hysteresis band.
- Option 2: No restart requirement is specified.
- Option 3: That crosses below the 29 °C clearing threshold in the ideal model.
- Option 4: Acknowledgment does not remove the active condition.

**GICSP-Q0304 · single · diagnosis**

Why is the gateway's GOOD indication at 12:00:20 misleading?

Synthetic HMI alarm definition: high alarm activates when temperature >30 °C continuously for 3.0 s; clears when temperature <29 °C; equality does neither. The analytical model has instantaneous sampling and timer evaluation. Trace: 0–2 s 31 °C, 2–4 s 29.5 °C, 4–8 s 31 °C, 8–10 s 29.5 °C, after 10 s 28.5 °C. Alarm is initially inactive. Acknowledge occurs at 7.5 s. Source sample timestamp is 12:00:00; gateway repaints at 12:00:20 with unchanged data and quality GOOD. Stale limit is 10 s. Viewer role has no button, but the write API accepts its request. Alarm shelving has no expiry.

1. The screen has displayed the same number twice.
2. The source sample is twenty seconds old despite a fresh repaint.
3. The source value is definitely physically wrong.
4. Every gateway timestamp is inherently invalid.

**Correct option(s):** 2

- Option 1: Repetition alone is not a fault if observations are fresh.
- Option 2: Source age exceeds the ten-second stale limit.
- Option 3: Staleness creates uncertainty, not proof of a particular current value.
- Option 4: Timestamps can be useful when their meaning is explicit.

**GICSP-Q0305 · single · diagnosis**

What is the viewer-role security defect?

Synthetic HMI alarm definition: high alarm activates when temperature >30 °C continuously for 3.0 s; clears when temperature <29 °C; equality does neither. The analytical model has instantaneous sampling and timer evaluation. Trace: 0–2 s 31 °C, 2–4 s 29.5 °C, 4–8 s 31 °C, 8–10 s 29.5 °C, after 10 s 28.5 °C. Alarm is initially inactive. Acknowledge occurs at 7.5 s. Source sample timestamp is 12:00:00; gateway repaints at 12:00:20 with unchanged data and quality GOOD. Stale limit is 10 s. Viewer role has no button, but the write API accepts its request. Alarm shelving has no expiry.

1. The trusted write API accepts an action the role should not perform.
2. The API write is acceptable because the viewer cannot discover it through the normal screen.
3. The API uses a network connection.
4. The viewer cannot see the button.

**Correct option(s):** 1

- Option 1: Hiding a button is not server-side authorisation.
- Option 2: Hidden presentation does not enforce the viewer’s operation restriction.
- Option 3: Connectivity is not itself the role defect.
- Option 4: That is consistent with a read-only interface but insufficient alone.

**GICSP-Q0306 · single · mechanism**

What does the one-degree hysteresis primarily reduce?

Synthetic HMI alarm definition: high alarm activates when temperature >30 °C continuously for 3.0 s; clears when temperature <29 °C; equality does neither. The analytical model has instantaneous sampling and timer evaluation. Trace: 0–2 s 31 °C, 2–4 s 29.5 °C, 4–8 s 31 °C, 8–10 s 29.5 °C, after 10 s 28.5 °C. Alarm is initially inactive. Acknowledge occurs at 7.5 s. Source sample timestamp is 12:00:00; gateway repaints at 12:00:20 with unchanged data and quality GOOD. Stale limit is 10 s. Viewer role has no button, but the write API accepts its request. Alarm shelving has no expiry.

1. All delays in operator response.
2. The need to preserve data quality.
3. Every possible false measurement.
4. Repeated activation/clearing near the threshold.

**Correct option(s):** 4

- Option 1: Hysteresis does not remove human or system latency.
- Option 2: Stale or invalid input remains a separate issue.
- Option 3: Hysteresis does not calibrate the sensor.
- Option 4: Separate activation and clearing boundaries reduce chatter.

**GICSP-Q0307 · single · mechanism**

What is the operational tradeoff of increasing the on-delay?

Synthetic HMI alarm definition: high alarm activates when temperature >30 °C continuously for 3.0 s; clears when temperature <29 °C; equality does neither. The analytical model has instantaneous sampling and timer evaluation. Trace: 0–2 s 31 °C, 2–4 s 29.5 °C, 4–8 s 31 °C, 8–10 s 29.5 °C, after 10 s 28.5 °C. Alarm is initially inactive. Acknowledge occurs at 7.5 s. Source sample timestamp is 12:00:00; gateway repaints at 12:00:20 with unchanged data and quality GOOD. Stale limit is 10 s. Viewer role has no button, but the write API accepts its request. Alarm shelving has no expiry.

1. Fewer short transient alarms but later indication of sustained abnormal conditions.
2. Automatic increase in alarm priority.
3. Guaranteed elimination of all nuisance alarms.
4. Higher measurement accuracy with no timing effect.

**Correct option(s):** 1

- Option 1: Delay filters duration and consumes response time.
- Option 2: Priority is a rationalised consequence decision.
- Option 3: Other causes such as bad quality or incorrect thresholds remain.
- Option 4: A timer does not improve sensor accuracy and does add latency.

**GICSP-Q0308 · multi · design**

Which fields support a bounded shelving record? Select all that apply.

Synthetic HMI alarm definition: high alarm activates when temperature >30 °C continuously for 3.0 s; clears when temperature <29 °C; equality does neither. The analytical model has instantaneous sampling and timer evaluation. Trace: 0–2 s 31 °C, 2–4 s 29.5 °C, 4–8 s 31 °C, 8–10 s 29.5 °C, after 10 s 28.5 °C. Alarm is initially inactive. Acknowledge occurs at 7.5 s. Source sample timestamp is 12:00:00; gateway repaints at 12:00:20 with unchanged data and quality GOOD. Stale limit is 10 s. Viewer role has no button, but the write API accepts its request. Alarm shelving has no expiry.

1. The affected alarm and operational compensating action.
2. A permanent blanket suppression for every alarm.
3. Authorised identity, reason and expiry/restoration condition.
4. Only a hidden Boolean flag.

**Correct option(s):** 1, 3

- Option 1: Operators need to know the missing response function.
- Option 2: That removes meaningful abnormal-condition indication.
- Option 3: These make suppression accountable and temporary.
- Option 4: It omits authority and restoration context.

**GICSP-Q0309 · single · design**

How should command success be represented?

Synthetic HMI alarm definition: high alarm activates when temperature >30 °C continuously for 3.0 s; clears when temperature <29 °C; equality does neither. The analytical model has instantaneous sampling and timer evaluation. Trace: 0–2 s 31 °C, 2–4 s 29.5 °C, 4–8 s 31 °C, 8–10 s 29.5 °C, after 10 s 28.5 °C. Alarm is initially inactive. Acknowledge occurs at 7.5 s. Source sample timestamp is 12:00:00; gateway repaints at 12:00:20 with unchanged data and quality GOOD. Stale limit is 10 s. Viewer role has no button, but the write API accepts its request. Alarm shelving has no expiry.

1. Distinguish request acceptance from device feedback and delivered process function.
2. Suppress feedback when it disagrees with the request.
3. Mark the device running when the HMI accepts the click, before checking command and feedback stages.
4. Use only the HTTP status code to claim physical completion.

**Correct option(s):** 1

- Option 1: These are separate stages with different failure modes.
- Option 2: That hides the very mismatch operators need to see.
- Option 3: UI acceptance is not controller acceptance or physical operation.
- Option 4: API success may mean only receipt or acceptance.

**GICSP-Q0310 · single · operations**

What should determine alarm priority?

Synthetic HMI alarm definition: high alarm activates when temperature >30 °C continuously for 3.0 s; clears when temperature <29 °C; equality does neither. The analytical model has instantaneous sampling and timer evaluation. Trace: 0–2 s 31 °C, 2–4 s 29.5 °C, 4–8 s 31 °C, 8–10 s 29.5 °C, after 10 s 28.5 °C. Alarm is initially inactive. Acknowledge occurs at 7.5 s. Source sample timestamp is 12:00:00; gateway repaints at 12:00:20 with unchanged data and quality GOOD. Stale limit is 10 s. Viewer role has no button, but the write API accepts its request. Alarm shelving has no expiry.

1. The tag’s position in the historian report.
2. The order in which alarms were added to the HMI configuration.
3. Consequence and the available time for the required operator response.
4. The order in which tags were imported.

**Correct option(s):** 3

- Option 1: Report ordering does not establish consequence or required response time.
- Option 2: Configuration chronology does not define operational priority.
- Option 3: Priority should support operational decisions.
- Option 4: Import sequence has no operational meaning.

#### Recall

**Acknowledged versus cleared?**

Acknowledgment records recognition; clearing follows the defined process-condition logic. Neither necessarily resets a protective trip.

**Why preserve source time?**

A freshly received or repainted old sample can otherwise appear current even though the underlying observation is stale.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

### GICSP-L032 — Historians, data integrity and database authority

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L031

A historian stores process observations with context. A useful record identifies the point, source timestamp, ingestion timestamp, value, units and quality. Some systems add sequence numbers, source identity, version and correction status. Source time describes when the observation was made; ingestion time describes when it arrived. Late delivery, backfill, clock corrections and retransmission can make these orders differ. Preserve both meanings rather than overwriting source time with arrival time to make a chart look continuous.

Compression and interpolation change what a query returns. A historian may retain values only when they change beyond a threshold, or return interpolated values at requested intervals. An interpolated point is an estimate derived from stored observations, not a new measurement. A simple arithmetic mean of irregularly spaced samples weights each sample equally, while a time-weighted mean weights the represented duration. The correct aggregation depends on the question and the system's documented treatment of gaps and quality. Never infer a precise energy total or compliance result from an undocumented averaging mode.

Quality must survive storage, retrieval and reporting. Excluding bad-quality rows can be appropriate for an analysis, but the excluded duration and consequence should remain visible. Replacing invalid values with zero can distort minima, averages and control decisions. Repeated packets need a deduplication rule based on a suitable source/event identity; identical values at different valid observation times are not necessarily duplicates. Corrections should retain an audit trail instead of silently rewriting history. A later corrected value and the original operator-visible value can both matter in an incident investigation.

Database permissions should reflect the application role. A reporting account normally needs access to approved views or queries, not schema changes, arbitrary stored procedures or user administration. Separate ingestion, reporting, maintenance and backup identities where practical. Use parameterised queries for untrusted values so input is treated as data rather than executable SQL structure. Parameters do not automatically authorise access: the server still needs role and object controls. Avoid embedding broad database credentials in client-side dashboards where every viewer can recover them.

A historian replica in a DMZ can reduce direct enterprise access to the operational database, but replication direction and management paths need examination. A read replica may still have privileged administration or a reverse synchronisation channel. Account for authentication, time, storage and backup dependencies. A full disk can stop ingestion while a cached dashboard remains responsive; service availability must include freshness and completeness, not merely the ability to load a web page.

Recovery requires a consistent database state and compatible application/schema versions. File copying while a database writes can produce an unusable or inconsistent image unless the supported backup mechanism coordinates it. Transaction logs and point-in-time recovery may help meet a recovery-point objective, but validate the complete chain and keys. After restore, check permissions, point mappings, quality semantics, timestamps, backfill rules and representative queries. Recovered data is not sufficient if the reporting account has regained obsolete write privileges or if the latest observations are presented as current despite a recovery gap.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic historian rows (source UTC, arrival UTC, value, quality, event_id):
10:00:00,10:00:01,40,GOOD,a1
10:00:10,10:00:11,80,BAD,a2
10:00:20,10:00:21,60,GOOD,a3
10:00:00,10:00:25,40,GOOD,a1  [retransmission]
Dashboard orders by arrival and calls the last row current. Report computes AVG(value) over all four rows. Reporting account report_u has SELECT, UPDATE and ALTER on the production database. Application builds `SELECT ... WHERE tag='` + user_input + `'` as text. Backup is an uncoordinated copy of open database files; no restore test exists.

**Reasoning:** The last arrival is a retransmitted old event, not the newest source observation. Deduplicate a1 by event identity and preserve the late-arrival record for transport analysis if needed. The all-row arithmetic mean is (40+80+60+40)/4=55, but it includes bad data and a duplicate; the mean of unique GOOD observations is (40+60)/2=50, still not a time-weighted process average. Restrict reporting privileges and parameterise the tag value. The file copy lacks demonstrated consistency and recovery usability.

#### Guided practice

Write a query specification for the latest valid source observation without pretending it is current forever.

**Hint:** Filter quality, deduplicate event identity, order source time and compare age with a requirement.

**Worked solution:** Use the latest unique GOOD source observation, a3 at 10:00:20 with value 60; retain source/arrival times and calculate source age at query time. Mark stale when the approved freshness bound is exceeded rather than selecting the latest arrival.

#### Independent task

Environment: analytical

Create a historian integrity and recovery acceptance plan.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L032.json

**Evidence to produce**

- Corrected record interpretation
- Aggregation assumptions
- Reporting-role permission changes
- Consistent restore checks

**Acceptance criteria**

- Duplicate and BAD rows are handled explicitly.
- Source time and arrival time retain distinct meanings.
- A successful web page is not equated with fresh complete data.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0311 · single · diagnosis**

Which row is the newest unique GOOD source observation?

Synthetic historian rows (source UTC, arrival UTC, value, quality, event_id):
10:00:00,10:00:01,40,GOOD,a1
10:00:10,10:00:11,80,BAD,a2
10:00:20,10:00:21,60,GOOD,a3
10:00:00,10:00:25,40,GOOD,a1  [retransmission]
Dashboard orders by arrival and calls the last row current. Report computes AVG(value) over all four rows. Reporting account report_u has SELECT, UPDATE and ALTER on the production database. Application builds `SELECT ... WHERE tag='` + user_input + `'` as text. Backup is an uncoordinated copy of open database files; no restore test exists.

1. a3 at 10:00:20 with value 60.
2. The first row because it arrived first.
3. a2 with value 80.
4. The a1 retransmission arriving at 10:00:25.

**Correct option(s):** 1

- Option 1: Source time, quality and event identity establish the requested result.
- Option 2: Arrival order does not identify the latest source observation.
- Option 3: It is marked BAD and is earlier than a3.
- Option 4: Its source observation is still 10:00:00.

**GICSP-Q0312 · single · diagnosis**

What does the dashboard's arrival-time ordering get wrong?

Synthetic historian rows (source UTC, arrival UTC, value, quality, event_id):
10:00:00,10:00:01,40,GOOD,a1
10:00:10,10:00:11,80,BAD,a2
10:00:20,10:00:21,60,GOOD,a3
10:00:00,10:00:25,40,GOOD,a1  [retransmission]
Dashboard orders by arrival and calls the last row current. Report computes AVG(value) over all four rows. Reporting account report_u has SELECT, UPDATE and ALTER on the production database. Application builds `SELECT ... WHERE tag='` + user_input + `'` as text. Backup is an uncoordinated copy of open database files; no restore test exists.

1. It prevents any data from being stored.
2. It makes every repeated value a duplicate.
3. It proves the controller clock is maliciously altered.
4. It can present a retransmitted old observation as the current process value.

**Correct option(s):** 4

- Option 1: Ordering affects interpretation, not necessarily storage.
- Option 2: Duplicate identity, not value equality alone, matters.
- Option 3: Retransmission explains the supplied ordering without that claim.
- Option 4: Fresh transport arrival is not fresh measurement.

**GICSP-Q0313 · single · calculation**

What is the arithmetic mean of all four supplied values?

Synthetic historian rows (source UTC, arrival UTC, value, quality, event_id):
10:00:00,10:00:01,40,GOOD,a1
10:00:10,10:00:11,80,BAD,a2
10:00:20,10:00:21,60,GOOD,a3
10:00:00,10:00:25,40,GOOD,a1  [retransmission]
Dashboard orders by arrival and calls the last row current. Report computes AVG(value) over all four rows. Reporting account report_u has SELECT, UPDATE and ALTER on the production database. Application builds `SELECT ... WHERE tag='` + user_input + `'` as text. Backup is an uncoordinated copy of open database files; no restore test exists.

1. 55.
2. 73.3.
3. 50.
4. 60.

**Correct option(s):** 1

- Option 1: The sum is 220 and there are four rows.
- Option 2: That does not follow from the supplied row set.
- Option 3: That is the mean of unique GOOD observations.
- Option 4: That is the latest GOOD value, not the four-row mean.

**GICSP-Q0314 · single · calculation**

What is the mean of the unique GOOD observations?

Synthetic historian rows (source UTC, arrival UTC, value, quality, event_id):
10:00:00,10:00:01,40,GOOD,a1
10:00:10,10:00:11,80,BAD,a2
10:00:20,10:00:21,60,GOOD,a3
10:00:00,10:00:25,40,GOOD,a1  [retransmission]
Dashboard orders by arrival and calls the last row current. Report computes AVG(value) over all four rows. Reporting account report_u has SELECT, UPDATE and ALTER on the production database. Application builds `SELECT ... WHERE tag='` + user_input + `'` as text. Backup is an uncoordinated copy of open database files; no restore test exists.

1. 55.
2. 40.
3. 60.
4. 50.

**Correct option(s):** 4

- Option 1: That retains the invalid and duplicate rows.
- Option 2: That discards valid a3 without a stated reason.
- Option 3: Selecting the newest value is not averaging the two observations.
- Option 4: Values 40 and 60 remain after excluding BAD a2 and duplicate a1.

**GICSP-Q0315 · single · diagnosis**

Why is the result 50 not automatically a time-weighted process average?

Synthetic historian rows (source UTC, arrival UTC, value, quality, event_id):
10:00:00,10:00:01,40,GOOD,a1
10:00:10,10:00:11,80,BAD,a2
10:00:20,10:00:21,60,GOOD,a3
10:00:00,10:00:25,40,GOOD,a1  [retransmission]
Dashboard orders by arrival and calls the last row current. Report computes AVG(value) over all four rows. Reporting account report_u has SELECT, UPDATE and ALTER on the production database. Application builds `SELECT ... WHERE tag='` + user_input + `'` as text. Backup is an uncoordinated copy of open database files; no restore test exists.

1. Arithmetic means are never useful.
2. GOOD quality guarantees uniform sampling intervals forever.
3. Deduplication changes every source timestamp.
4. The calculation weights observations equally and supplies no duration/interpolation model.

**Correct option(s):** 4

- Option 1: They answer a defined sample-based question.
- Option 2: Quality does not define sampling cadence.
- Option 3: It removes repeated event identity, not the meaning of the remaining times.
- Option 4: Irregular sample timing and gaps need explicit treatment.

**GICSP-Q0316 · single · diagnosis**

Which reporting-account privileges exceed the described read/report role?

Synthetic historian rows (source UTC, arrival UTC, value, quality, event_id):
10:00:00,10:00:01,40,GOOD,a1
10:00:10,10:00:11,80,BAD,a2
10:00:20,10:00:21,60,GOOD,a3
10:00:00,10:00:25,40,GOOD,a1  [retransmission]
Dashboard orders by arrival and calls the last row current. Report computes AVG(value) over all four rows. Reporting account report_u has SELECT, UPDATE and ALTER on the production database. Application builds `SELECT ... WHERE tag='` + user_input + `'` as text. Backup is an uncoordinated copy of open database files; no restore test exists.

1. The account having a unique name.
2. The use of a database view.
3. SELECT alone.
4. UPDATE and ALTER.

**Correct option(s):** 4

- Option 1: Named identity supports accountability.
- Option 2: A restricted view can narrow access appropriately.
- Option 3: Reading approved data is the role's required function, subject to scope.
- Option 4: They permit data or schema changes beyond reporting.

**GICSP-Q0317 · single · mechanism**

What does parameterising the tag value primarily prevent?

Synthetic historian rows (source UTC, arrival UTC, value, quality, event_id):
10:00:00,10:00:01,40,GOOD,a1
10:00:10,10:00:11,80,BAD,a2
10:00:20,10:00:21,60,GOOD,a3
10:00:00,10:00:25,40,GOOD,a1  [retransmission]
Dashboard orders by arrival and calls the last row current. Report computes AVG(value) over all four rows. Reporting account report_u has SELECT, UPDATE and ALTER on the production database. Application builds `SELECT ... WHERE tag='` + user_input + `'` as text. Backup is an uncoordinated copy of open database files; no restore test exists.

1. It makes the newest-arriving historian row a fresh source observation.
2. It enforces report_u’s read-only database permissions even though UPDATE and ALTER remain granted.
3. Interpreting supplied tag text as SQL command structure.
4. It guarantees a consistent restore from the uncoordinated open-file backup.

**Correct option(s):** 3

- Option 1: Parameterisation does not correct event-time ordering or source age.
- Option 2: Parameterisation addresses query/data separation, not excessive database privileges.
- Option 3: The value is bound as data instead of concatenated into executable syntax.
- Option 4: Database backup consistency is a separate mechanism.

**GICSP-Q0318 · single · diagnosis**

Which backup evidence is missing?

Synthetic historian rows (source UTC, arrival UTC, value, quality, event_id):
10:00:00,10:00:01,40,GOOD,a1
10:00:10,10:00:11,80,BAD,a2
10:00:20,10:00:21,60,GOOD,a3
10:00:00,10:00:25,40,GOOD,a1  [retransmission]
Dashboard orders by arrival and calls the last row current. Report computes AVG(value) over all four rows. Reporting account report_u has SELECT, UPDATE and ALTER on the production database. Application builds `SELECT ... WHERE tag='` + user_input + `'` as text. Backup is an uncoordinated copy of open database files; no restore test exists.

1. A rule that databases must always be shut down for every backup.
2. Only a successful completion message from the file-copy utility.
3. A supported consistency method and a successful representative restore.
4. Only a matching checksum between two uncoordinated copies of the open files.

**Correct option(s):** 3

- Option 1: Supported online backup mechanisms may provide consistency.
- Option 2: Copy completion does not show that the live database files form a supported recoverable state.
- Option 3: Copying open files alone does not establish a usable database state.
- Option 4: Byte equality between inconsistent copies would not establish database transaction consistency or restore usability.

**GICSP-Q0319 · multi · design**

Which fields should survive a corrected historian record? Select all that apply.

Synthetic historian rows (source UTC, arrival UTC, value, quality, event_id):
10:00:00,10:00:01,40,GOOD,a1
10:00:10,10:00:11,80,BAD,a2
10:00:20,10:00:21,60,GOOD,a3
10:00:00,10:00:25,40,GOOD,a1  [retransmission]
Dashboard orders by arrival and calls the last row current. Report computes AVG(value) over all four rows. Reporting account report_u has SELECT, UPDATE and ALTER on the production database. Application builds `SELECT ... WHERE tag='` + user_input + `'` as text. Backup is an uncoordinated copy of open database files; no restore test exists.

1. Only the newest numeric value with no history.
2. Only the dashboard refresh time.
3. Quality and the correction authority/reason.
4. Original source/arrival timing and correction provenance.

**Correct option(s):** 3, 4

- Option 1: That erases evidence about prior operator-visible state.
- Option 2: That is not the original observation time.
- Option 3: These support interpretation and accountability.
- Option 4: They preserve what was observed and later changed.

**GICSP-Q0320 · single · recovery**

What should be verified after restoring the historian besides data readability?

Synthetic historian rows (source UTC, arrival UTC, value, quality, event_id):
10:00:00,10:00:01,40,GOOD,a1
10:00:10,10:00:11,80,BAD,a2
10:00:20,10:00:21,60,GOOD,a3
10:00:00,10:00:25,40,GOOD,a1  [retransmission]
Dashboard orders by arrival and calls the last row current. Report computes AVG(value) over all four rows. Reporting account report_u has SELECT, UPDATE and ALTER on the production database. Application builds `SELECT ... WHERE tag='` + user_input + `'` as text. Backup is an uncoordinated copy of open database files; no restore test exists.

1. Only that the database process has a PID.
2. Permissions, point mapping, quality/freshness semantics and representative application behaviour.
3. Only that old reporting credentials still have UPDATE rights.
4. Only that the login page loads.

**Correct option(s):** 2

- Option 1: A running process may serve wrong or stale data.
- Option 2: Recovery must restore the intended authorised service.
- Option 3: Reinstating excessive authority would preserve the defect.
- Option 4: That does not test data integrity or authority.

#### Recall

**Source time versus ingestion time?**

Source time describes observation; ingestion time describes arrival. Late or repeated delivery can reorder them.

**Why does parameterisation not replace authorisation?**

It separates data from SQL syntax; object and role permissions still determine which data/actions are allowed.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

### GICSP-L033 — Engineering workstation custody and reproducible deployment

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L032

The engineering workstation is a high-trust bridge between human decisions and controller behaviour. It often holds project source, device credentials, programming tools, libraries and connection profiles. Its compromise can alter future deployments even if the controller network is segmented. Treat it as an engineering asset with a defined baseline, role and maintenance process rather than a general browsing computer. Separate everyday office activity where practical, and control transient laptops that cross between supplier, enterprise and operational environments.

Toolchain integrity spans installation source, signatures, dependencies, plugins and project search paths. A legitimate compiler can load an untrusted library from a writable directory. A signed main executable does not authenticate every script or plugin it launches. Record which paths are executable or loadable and who can modify them. Prefer approved packages and restricted write permissions, with supported updates and verification. Do not indiscriminately delete files from a running engineering installation: identify the dependency and plan a supported correction.

A reproducible build aims to obtain the expected output from a defined source and toolchain. Some vendor projects include timestamps, random identifiers or protected components that prevent byte-identical output; document those limitations and use supported semantic/signature comparisons. The goal is traceability, not claiming a hash must always match across every environment. Preserve source revision, library versions, compiler settings, target firmware, build logs and approval evidence. A successful compile proves syntactic and tool-level acceptance, not correct physical control behaviour.

Deployment separates preparation, approval, transfer and acceptance. The approved source must correspond to the built artefact actually transferred. A file copied after review can break that chain. Use a controlled release location and identify the exact artefact in the work order. Verify the target identity and current state before an authorised deployment, then perform the specified functional and negative tests. Independent review should examine consequential differences, not merely confirm that a file exists with the expected name.

Credentials and project secrets need controlled storage. Connection profiles may embed passwords, certificates or private keys; exporting a project for review can therefore expose more than logic. Redact or use an approved protected review environment without destroying the recovery copy's necessary contents. Supplier tools may require licences, activation or dongles; these are recovery dependencies that should be documented and lawfully available. A spare laptop with the wrong licence, unsupported OS or missing driver is not a demonstrated replacement engineering station.

A trusted recovery station should be prepared from known sources and verified before it connects to the operational environment. Reusing a possibly compromised workstation to rebuild controllers can reintroduce the unwanted change or stolen credential. Restore the toolchain, then inspect source and dependencies, verify identity material and test in an isolated target where available. Preserve evidence from the original system under the incident plan. This chapter's manifest comparison is offline; it does not claim that a proprietary compiler or controller deployment was executed.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic release manifest: approved source revision R8; required compiler 5.2, library PumpLib 3.1 and target firmware 10.4. Workstation W has compiler 5.2, but library search order loads a user-writable `Projects/Lib/PumpLib` before the approved protected directory. Local library reports version 3.1 but its digest differs from the approved manifest. Build B17 succeeds. Reviewer approved artefact hash H17; transfer log identifies H18 under the same filename. Spare workstation S has compiler 5.2 but no activation entitlement or target USB driver. Project export includes a private client key.

**Reasoning:** A version string is not sufficient to establish the library bytes or origin. The writable earlier search path can replace the approved dependency. Successful B17 compilation does not resolve that trust problem. H18 differs from the reviewed H17, breaking release traceability even if filenames match. S has unresolved operational recovery dependencies. Protect the exported private key and plan credential replacement if exposure occurred; do not publish the unredacted project as portfolio evidence.

#### Guided practice

List the evidence required to rebuild and review B17 in an isolated environment.

**Hint:** Bind source, dependency identity, compiler settings and target assumptions.

**Worked solution:** Use R8, approved PumpLib bytes/provenance, compiler 5.2 configuration and target 10.4 assumptions; record the actual load paths and build log; compare supported semantics/output, review differences, and bind the accepted artefact to the transfer record.

#### Independent task

Environment: analytical

Produce a toolchain custody and release-traceability report.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L033.json

**Evidence to produce**

- Dependency search-path finding
- Approved build manifest
- H17/H18 discrepancy record
- Spare-station recovery checklist
- Secret-handling decision

**Acceptance criteria**

- Version labels are not accepted as byte/provenance proof.
- The transferred artefact must match the approved release identity.
- The spare station is not called ready without lawful activation and required drivers.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0321 · single · diagnosis**

What is the concrete dependency-integrity risk on W?

Synthetic release manifest: approved source revision R8; required compiler 5.2, library PumpLib 3.1 and target firmware 10.4. Workstation W has compiler 5.2, but library search order loads a user-writable `Projects/Lib/PumpLib` before the approved protected directory. Local library reports version 3.1 but its digest differs from the approved manifest. Build B17 succeeds. Reviewer approved artefact hash H17; transfer log identifies H18 under the same filename. Spare workstation S has compiler 5.2 but no activation entitlement or target USB driver. Project export includes a private client key.

1. A matching PumpLib 3.1 version string is sufficient even when its digest differs.
2. The protected approved library wins because protected directories take precedence over project search paths.
3. A user-writable library path takes precedence over the approved protected path.
4. Compiler 5.2 is the wrong version because the target firmware is numbered 10.4.

**Correct option(s):** 3

- Option 1: The version label does not identify the actual bytes loaded from the writable directory.
- Option 2: The exhibit explicitly gives the user-writable project directory earlier search precedence.
- Option 3: The compiler can load altered dependency bytes despite a legitimate main executable.
- Option 4: Compiler and firmware use different version schemes; the supplied manifest explicitly pairs them.

**GICSP-Q0322 · single · diagnosis**

Why does the local version string 3.1 not close the library finding?

Synthetic release manifest: approved source revision R8; required compiler 5.2, library PumpLib 3.1 and target firmware 10.4. Workstation W has compiler 5.2, but library search order loads a user-writable `Projects/Lib/PumpLib` before the approved protected directory. Local library reports version 3.1 but its digest differs from the approved manifest. Build B17 succeeds. Reviewer approved artefact hash H17; transfer log identifies H18 under the same filename. Spare workstation S has compiler 5.2 but no activation entitlement or target USB driver. Project export includes a private client key.

1. The version string is invalid because it has only two components.
2. A digest match, if obtained, would prove the library’s physical control behaviour is correct.
3. Its digest differs from the approved manifest.
4. The compiler uses only the version label and cannot be influenced by library bytes.

**Correct option(s):** 3

- Option 1: No required component count is supplied; the problem is differing library content under the same label.
- Option 2: Content identity supports provenance comparison, not complete process correctness.
- Option 3: A label can remain unchanged while bytes differ.
- Option 4: The actual library contents affect the build and must match the approved manifest.

**GICSP-Q0323 · single · diagnosis**

What does successful compilation of B17 establish?

Synthetic release manifest: approved source revision R8; required compiler 5.2, library PumpLib 3.1 and target firmware 10.4. Workstation W has compiler 5.2, but library search order loads a user-writable `Projects/Lib/PumpLib` before the approved protected directory. Local library reports version 3.1 but its digest differs from the approved manifest. Build B17 succeeds. Reviewer approved artefact hash H17; transfer log identifies H18 under the same filename. Spare workstation S has compiler 5.2 but no activation entitlement or target USB driver. Project export includes a private client key.

1. The approved library was necessarily used.
2. H17 and H18 are identical.
3. The selected toolchain accepted the supplied source and dependencies sufficiently to produce output.
4. The controller will meet every safety requirement.

**Correct option(s):** 3

- Option 1: Search-path evidence contradicts that assumption.
- Option 2: Compilation success does not equate different artefact hashes.
- Option 3: It does not establish provenance or required process behaviour.
- Option 4: Functional acceptance needs relevant tests and authority.

**GICSP-Q0324 · single · diagnosis**

What is the significance of H17 in approval and H18 in the transfer log?

Synthetic release manifest: approved source revision R8; required compiler 5.2, library PumpLib 3.1 and target firmware 10.4. Workstation W has compiler 5.2, but library search order loads a user-writable `Projects/Lib/PumpLib` before the approved protected directory. Local library reports version 3.1 but its digest differs from the approved manifest. Build B17 succeeds. Reviewer approved artefact hash H17; transfer log identifies H18 under the same filename. Spare workstation S has compiler 5.2 but no activation entitlement or target USB driver. Project export includes a private client key.

1. Review is unnecessary for compiled files.
2. The transferred artefact is not shown to be the reviewed artefact.
3. The change is automatically harmless because names match.
4. The target controller is necessarily destroyed.

**Correct option(s):** 2

- Option 1: Consequential deployed artefacts require traceability.
- Option 2: Exact release identity is broken despite a shared filename.
- Option 3: Filenames are weak identity evidence.
- Option 4: The discrepancy does not establish physical outcome.

**GICSP-Q0325 · multi · recovery**

Which issues prevent S from being a demonstrated recovery workstation? Select all that apply.

Synthetic release manifest: approved source revision R8; required compiler 5.2, library PumpLib 3.1 and target firmware 10.4. Workstation W has compiler 5.2, but library search order loads a user-writable `Projects/Lib/PumpLib` before the approved protected directory. Local library reports version 3.1 but its digest differs from the approved manifest. Build B17 succeeds. Reviewer approved artefact hash H17; transfer log identifies H18 under the same filename. Spare workstation S has compiler 5.2 but no activation entitlement or target USB driver. Project export includes a private client key.

1. Missing lawful activation capability.
2. Missing target USB driver.
3. The compiler version matches 5.2.
4. The station is separate from W.

**Correct option(s):** 1, 2

- Option 1: The tool may not operate when needed.
- Option 2: Required connectivity may fail even with the compiler installed.
- Option 3: That supports the manifest rather than blocking readiness.
- Option 4: Separation can support trusted recovery; its actual configuration matters.

**GICSP-Q0326 · single · operations**

How should the project export containing a private key be handled for portfolio review?

Synthetic release manifest: approved source revision R8; required compiler 5.2, library PumpLib 3.1 and target firmware 10.4. Workstation W has compiler 5.2, but library search order loads a user-writable `Projects/Lib/PumpLib` before the approved protected directory. Local library reports version 3.1 but its digest differs from the approved manifest. Build B17 succeeds. Reviewer approved artefact hash H17; transfer log identifies H18 under the same filename. Spare workstation S has compiler 5.2 but no activation entitlement or target USB driver. Project export includes a private client key.

1. Use an approved protected or redacted review artefact while preserving the controlled recovery copy.
2. Rename the key file and treat it as nonsecret.
3. Publish it unchanged because source code is educational.
4. Delete every backup immediately.

**Correct option(s):** 1

- Option 1: Review evidence should not expose reusable secrets.
- Option 2: Renaming does not remove credential value.
- Option 3: The key can grant real authority and is not needed for public explanation.
- Option 4: That may destroy recovery capability without addressing existing exposure.

**GICSP-Q0327 · single · mechanism**

What is a reasonable limitation on byte-identical build claims?

Synthetic release manifest: approved source revision R8; required compiler 5.2, library PumpLib 3.1 and target firmware 10.4. Workstation W has compiler 5.2, but library search order loads a user-writable `Projects/Lib/PumpLib` before the approved protected directory. Local library reports version 3.1 but its digest differs from the approved manifest. Build B17 succeeds. Reviewer approved artefact hash H17; transfer log identifies H18 under the same filename. Spare workstation S has compiler 5.2 but no activation entitlement or target USB driver. Project export includes a private client key.

1. Identical filenames prove identical output.
2. Some supported toolchains embed variable metadata or protected components, requiring documented alternative comparisons.
3. No build can ever be traced.
4. A changing timestamp proves malicious logic.

**Correct option(s):** 2

- Option 1: Content identity requires stronger evidence.
- Option 2: Reproducibility must match actual platform behaviour.
- Option 3: Manifests, logs and supported comparisons still provide evidence.
- Option 4: Metadata changes can be benign.

**GICSP-Q0328 · single · recovery**

Why might rebuilding controllers from a suspected compromised W reintroduce the problem?

Synthetic release manifest: approved source revision R8; required compiler 5.2, library PumpLib 3.1 and target firmware 10.4. Workstation W has compiler 5.2, but library search order loads a user-writable `Projects/Lib/PumpLib` before the approved protected directory. Local library reports version 3.1 but its digest differs from the approved manifest. Build B17 succeeds. Reviewer approved artefact hash H17; transfer log identifies H18 under the same filename. Spare workstation S has compiler 5.2 but no activation entitlement or target USB driver. Project export includes a private client key.

1. A controller can be rebuilt only from its original physical workstation.
2. Altered source, libraries or credentials on W can affect the new deployment.
3. Network segmentation proves the project files on W have approved content.
4. The clean target controller will validate and repair the workstation’s untrusted library automatically.

**Correct option(s):** 2

- Option 1: An approved compatible trusted environment can be used; the issue is W’s suspect toolchain.
- Option 2: The engineering station is part of the trust chain.
- Option 3: Segmentation does not authenticate local libraries or release artefacts.
- Option 4: Target cleanliness does not establish or repair build-source integrity.

**GICSP-Q0329 · single · implementation**

Which evidence binds a release to its intended target?

Synthetic release manifest: approved source revision R8; required compiler 5.2, library PumpLib 3.1 and target firmware 10.4. Workstation W has compiler 5.2, but library search order loads a user-writable `Projects/Lib/PumpLib` before the approved protected directory. Local library reports version 3.1 but its digest differs from the approved manifest. Build B17 succeeds. Reviewer approved artefact hash H17; transfer log identifies H18 under the same filename. Spare workstation S has compiler 5.2 but no activation entitlement or target USB driver. Project export includes a private client key.

1. Only the date of the workstation purchase.
2. Approved artefact identity, target hardware/firmware identity and transfer/acceptance records.
3. Only a screenshot of an empty error list.
4. Only the engineer's preferred file naming convention.

**Correct option(s):** 2

- Option 1: Hardware age does not identify the release target.
- Option 2: These connect preparation to the actual deployed system.
- Option 3: Tool-level success omits target and acceptance context.
- Option 4: Names can be reused or copied.

**GICSP-Q0330 · single · design**

What should independent review focus on for this change?

Synthetic release manifest: approved source revision R8; required compiler 5.2, library PumpLib 3.1 and target firmware 10.4. Workstation W has compiler 5.2, but library search order loads a user-writable `Projects/Lib/PumpLib` before the approved protected directory. Local library reports version 3.1 but its digest differs from the approved manifest. Build B17 succeeds. Reviewer approved artefact hash H17; transfer log identifies H18 under the same filename. Spare workstation S has compiler 5.2 but no activation entitlement or target USB driver. Project export includes a private client key.

1. Consequential source/dependency differences and evidence that the approved artefact is the one deployed.
2. Only the source revision label, ignoring the H17/H18 transfer discrepancy.
3. Whether the transferred file retains the approved human-readable filename.
4. Only the compiler success message, without examining which library bytes were loaded.

**Correct option(s):** 1

- Option 1: This addresses the actual trust and behaviour risks.
- Option 2: An approved source label does not prove that the reviewed artefact was the one transferred.
- Option 3: The H17/H18 discrepancy shows why filename continuity is insufficient.
- Option 4: The supplied dependency search-path risk can survive successful compilation.

#### Recall

**Why include library search paths in a baseline?**

A trusted compiler can load untrusted dependencies from a writable earlier path.

**Compile success versus release acceptance?**

Compilation proves tool acceptance of selected inputs; release acceptance requires approved identity, target compatibility and demonstrated required behaviour.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

### GICSP-L034 — Directory, DNS, time and certificate dependencies

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L033

Shared infrastructure often determines whether an OT application can operate or recover. Directory authentication, DNS, time synchronisation and certificate validation may be invisible during normal service but become critical during a boundary outage. Map which components need each service at startup, during existing sessions, at renewal and during recovery. A cached login may work while a new service authentication fails; that is not necessarily inconsistent behaviour. Understand the mechanism rather than treating the entire site as simply “directory dependent.”

Authentication establishes an identity under a mechanism; authorisation decides what that identity may do. Group memberships, local application roles and token lifetimes can make the two diverge. Disabling an account may stop new token issuance while existing tokens remain usable until expiry or revocation handling. A service running under a broadly privileged domain identity can spread the consequence of its compromise. Constrain service rights and administrative tiers, and avoid using one identity for unrelated ingestion, backup and interactive engineering functions.

Name resolution is another trust input. An application configured for `hist.example.test` asks a resolver for an address, then uses that result to connect. A correct DNS answer does not authenticate the application server; TLS identity validation provides a separate check when used correctly. Conversely, a valid certificate does not guarantee that every returned data value is correct. DNSSEC, where properly deployed, authenticates DNS data integrity/origin in its trust model; it does not encrypt queries or replace application authorisation. Keep these assurances distinct.

Certificate validation checks more than a validity date. The client needs an acceptable chain to a trusted authority, the intended peer identity, appropriate key usage/policy and the required revocation handling. A certificate for one hostname should not be accepted for another merely because the issuer is trusted. Private keys need protection and rotation procedures. A self-signed certificate is not automatically useless, but it requires an explicit secure trust-distribution model; clicking through an unexpected warning abandons the intended authentication without establishing a replacement.

Time affects certificate validity, event ordering and time-sensitive authentication. Protocols and products have their own permitted skew and recovery behaviour; do not invent a universal tolerance. Maintain reliable approved time sources and monitor offset and source changes. A sudden clock step can reorder logs or move scheduled tasks, while gradual correction has different effects. Preserve the clock state and uncertainty during incident analysis. An observed certificate failure after a clock jump may be a time error rather than an expired certificate, but verify the actual reason and chain before concluding.

Design degraded operation deliberately. If certificate revocation information is unreachable, the product may fail closed, use a cached response or follow a configured soft-fail policy. Each choice has availability and trust implications that need an approved requirement. A recovery plan should include reachable trust anchors, protected keys, time, name resolution and identity services without circular dependence. Test startup and renewal during the relevant outage, not only an already-running session. Never disable all certificate validation as an unbounded fix for a dependency outage; identify the failing check and use a supported, authorised recovery method.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic service failure: historian client connects to hist.example.test at 192.0.2.20. Server certificate is valid for archive.example.test, signed by an approved CA, date-valid through next year. Client clock is 12 minutes fast; the supplied authentication policy permits at most 5 minutes skew for service tickets. DNS resolves the intended address correctly. Revocation endpoint is unreachable; client policy requires current status and has no unexpired cached response. Existing application session continues, but a new connection fails. Engineer proposes disabling hostname, time and revocation checks permanently.

**Reasoning:** There are multiple independent failed prerequisites: hostname mismatch, excessive ticket-clock skew and unavailable required revocation status. Correct DNS and issuer trust do not repair them. An existing session can continue under its existing state while new validation fails. Diagnose each check, restore the intended identity/time/revocation services or use an approved bounded alternative, and test new connections and renewal. Permanent blanket validation disablement would remove the security properties rather than restore them.

#### Guided practice

Create a failure matrix for DNS, certificate name, time and revocation.

**Hint:** Mark what is observed healthy, failed or untested separately.

**Worked solution:** DNS returns the supplied intended address; certificate peer-name check fails; 12-minute skew exceeds the supplied five-minute ticket policy; required fresh revocation evidence is absent. Other checks such as key custody and role permissions remain outside these observations.

#### Independent task

Environment: analytical

Write a dependency-aware service restoration plan.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L034.json

**Evidence to produce**

- Validation-failure matrix
- Ordered dependency restoration
- New-session and renewal tests
- Bounded fallback decision if needed

**Acceptance criteria**

- Approved CA trust does not override hostname mismatch.
- The five-minute limit is identified as the supplied policy, not a universal value.
- Existing-session success is not treated as proof that new authentication works.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0331 · single · diagnosis**

Why does the certificate fail peer-name validation?

Synthetic service failure: historian client connects to hist.example.test at 192.0.2.20. Server certificate is valid for archive.example.test, signed by an approved CA, date-valid through next year. Client clock is 12 minutes fast; the supplied authentication policy permits at most 5 minutes skew for service tickets. DNS resolves the intended address correctly. Revocation endpoint is unreachable; client policy requires current status and has no unexpired cached response. Existing application session continues, but a new connection fails. Engineer proposes disabling hostname, time and revocation checks permanently.

1. The continuing existing session proves new-session certificate validation must also pass.
2. Correct DNS resolution automatically repairs the certificate identity mismatch.
3. The approved CA and date-valid certificate are sufficient despite the different service name.
4. It identifies archive.example.test rather than hist.example.test.

**Correct option(s):** 4

- Option 1: Existing sessions can continue while a new connection fails its validation checks.
- Option 2: Address resolution and certificate name validation are separate checks.
- Option 3: Peer-name validation must also match the intended historian service.
- Option 4: Trusted issuance does not make every hostname interchangeable.

**GICSP-Q0332 · single · diagnosis**

How does the 12-minute clock error compare with the supplied ticket policy?

Synthetic service failure: historian client connects to hist.example.test at 192.0.2.20. Server certificate is valid for archive.example.test, signed by an approved CA, date-valid through next year. Client clock is 12 minutes fast; the supplied authentication policy permits at most 5 minutes skew for service tickets. DNS resolves the intended address correctly. Revocation endpoint is unreachable; client policy requires current status and has no unexpired cached response. Existing application session continues, but a new connection fails. Engineer proposes disabling hostname, time and revocation checks permanently.

1. It is irrelevant to every authentication mechanism.
2. It passes because all authentication protocols allow fifteen minutes.
3. It exceeds the five-minute tolerance.
4. It proves the CA private key was stolen.

**Correct option(s):** 3

- Option 1: The supplied ticket mechanism explicitly depends on time.
- Option 2: No universal fifteen-minute tolerance exists.
- Option 3: The policy's permitted skew is smaller than the observed error.
- Option 4: Clock skew does not establish key compromise.

**GICSP-Q0333 · single · diagnosis**

What does correct DNS resolution establish here?

Synthetic service failure: historian client connects to hist.example.test at 192.0.2.20. Server certificate is valid for archive.example.test, signed by an approved CA, date-valid through next year. Client clock is 12 minutes fast; the supplied authentication policy permits at most 5 minutes skew for service tickets. DNS resolves the intended address correctly. Revocation endpoint is unreachable; client policy requires current status and has no unexpired cached response. Existing application session continues, but a new connection fails. Engineer proposes disabling hostname, time and revocation checks permanently.

1. The configured name resolves to the intended supplied address.
2. The server's certificate name automatically matches.
3. The client's clock is synchronised.
4. The server's process data is guaranteed correct.

**Correct option(s):** 1

- Option 1: Application identity and authorisation still require separate checks.
- Option 2: The certificate contains a different name.
- Option 3: DNS resolution does not establish time accuracy.
- Option 4: Naming does not validate data semantics.

**GICSP-Q0334 · single · diagnosis**

Why can an existing session work while a new connection fails?

Synthetic service failure: historian client connects to hist.example.test at 192.0.2.20. Server certificate is valid for archive.example.test, signed by an approved CA, date-valid through next year. Client clock is 12 minutes fast; the supplied authentication policy permits at most 5 minutes skew for service tickets. DNS resolves the intended address correctly. Revocation endpoint is unreachable; client policy requires current status and has no unexpired cached response. Existing application session continues, but a new connection fails. Engineer proposes disabling hostname, time and revocation checks permanently.

1. The failure report must be fabricated.
2. All certificate checks run on every individual byte.
3. Existing state may remain usable while new authentication/validation prerequisites fail.
4. The server cannot support more than one connection by definition.

**Correct option(s):** 3

- Option 1: The two observations are compatible.
- Option 2: Validation frequency depends on protocol/session behaviour.
- Option 3: Session lifecycle checks differ from initial establishment.
- Option 4: No such limit is supplied.

**GICSP-Q0335 · single · diagnosis**

What follows from the configured revocation policy and missing current response?

Synthetic service failure: historian client connects to hist.example.test at 192.0.2.20. Server certificate is valid for archive.example.test, signed by an approved CA, date-valid through next year. Client clock is 12 minutes fast; the supplied authentication policy permits at most 5 minutes skew for service tickets. DNS resolves the intended address correctly. Revocation endpoint is unreachable; client policy requires current status and has no unexpired cached response. Existing application session continues, but a new connection fails. Engineer proposes disabling hostname, time and revocation checks permanently.

1. Hostname validation can replace revocation checking.
2. New validation lacks a required prerequisite unless an approved policy-specific fallback exists.
3. The certificate is definitely revoked.
4. The certificate is definitely not revoked.

**Correct option(s):** 2

- Option 1: They address different trust questions.
- Option 2: No valid cached response is supplied.
- Option 3: Unreachable status is not a positive revocation result.
- Option 4: Absence of a response cannot prove that either.

**GICSP-Q0336 · single · mechanism**

Which property does DNSSEC provide in its intended trust model?

Synthetic service failure: historian client connects to hist.example.test at 192.0.2.20. Server certificate is valid for archive.example.test, signed by an approved CA, date-valid through next year. Client clock is 12 minutes fast; the supplied authentication policy permits at most 5 minutes skew for service tickets. DNS resolves the intended address correctly. Revocation endpoint is unreachable; client policy requires current status and has no unexpired cached response. Existing application session continues, but a new connection fails. Engineer proposes disabling hostname, time and revocation checks permanently.

1. Authentication of DNS data origin and integrity.
2. Authorisation to write controller settings.
3. Confidentiality of every DNS query.
4. Proof that the resolved application has no vulnerabilities.

**Correct option(s):** 1

- Option 1: It validates signed DNS data rather than encrypting transport by itself.
- Option 2: Application permissions are separate.
- Option 3: DNSSEC does not itself encrypt queries.
- Option 4: DNS data validation does not assess server software.

**GICSP-Q0337 · multi · design**

Which certificate checks remain distinct? Select all that apply.

Synthetic service failure: historian client connects to hist.example.test at 192.0.2.20. Server certificate is valid for archive.example.test, signed by an approved CA, date-valid through next year. Client clock is 12 minutes fast; the supplied authentication policy permits at most 5 minutes skew for service tickets. DNS resolves the intended address correctly. Revocation endpoint is unreachable; client policy requires current status and has no unexpired cached response. Existing application session continues, but a new connection fails. Engineer proposes disabling hostname, time and revocation checks permanently.

1. Trusted chain and intended peer identity.
2. Only the visual appearance of the certificate dialog.
3. Validity/revocation policy and permitted usage.
4. Only whether the certificate file can be opened as text.

**Correct option(s):** 1, 3

- Option 1: A trusted issuer can issue certificates for many different peers.
- Option 2: Presentation is not validation.
- Option 3: Each constrains acceptance for a different reason.
- Option 4: Parseability does not establish trust or intended use.

**GICSP-Q0338 · single · diagnosis**

What is the problem with the proposed permanent blanket bypass?

Synthetic service failure: historian client connects to hist.example.test at 192.0.2.20. Server certificate is valid for archive.example.test, signed by an approved CA, date-valid through next year. Client clock is 12 minutes fast; the supplied authentication policy permits at most 5 minutes skew for service tickets. DNS resolves the intended address correctly. Revocation endpoint is unreachable; client policy requires current status and has no unexpired cached response. Existing application session continues, but a new connection fails. Engineer proposes disabling hostname, time and revocation checks permanently.

1. It guarantees revocation data becomes reachable.
2. It is equivalent to renewing the certificate correctly.
3. It removes several authentication assurances instead of repairing their failed prerequisites.
4. It necessarily improves both identity assurance and time accuracy.

**Correct option(s):** 3

- Option 1: Bypass does not restore the endpoint.
- Option 2: Renewal with correct identity/trust is a different operation.
- Option 3: Availability would be gained by abandoning the specified trust checks.
- Option 4: Disabling checks does neither.

**GICSP-Q0339 · single · implementation**

What should a dependency recovery test include beyond an already-running session?

Synthetic service failure: historian client connects to hist.example.test at 192.0.2.20. Server certificate is valid for archive.example.test, signed by an approved CA, date-valid through next year. Client clock is 12 minutes fast; the supplied authentication policy permits at most 5 minutes skew for service tickets. DNS resolves the intended address correctly. Revocation endpoint is unreachable; client policy requires current status and has no unexpired cached response. Existing application session continues, but a new connection fails. Engineer proposes disabling hostname, time and revocation checks permanently.

1. Only checking the certificate expiry date while leaving peer-name and revocation dependencies untested.
2. Only pinging the DNS server.
3. New authentication, service restart, certificate renewal/status retrieval and required name/time services.
4. Only refreshing the existing dashboard tab.

**Correct option(s):** 3

- Option 1: Several independent checks fail in the supplied case; date validity alone does not restore the chain.
- Option 2: Reachability alone does not test the application chain.
- Option 3: These expose dependencies that cached state can hide.
- Option 4: That may reuse a surviving session and cached data.

**GICSP-Q0340 · single · mechanism**

What is a circular recovery dependency?

Synthetic service failure: historian client connects to hist.example.test at 192.0.2.20. Server certificate is valid for archive.example.test, signed by an approved CA, date-valid through next year. Client clock is 12 minutes fast; the supplied authentication policy permits at most 5 minutes skew for service tickets. DNS resolves the intended address correctly. Revocation endpoint is unreachable; client policy requires current status and has no unexpired cached response. Existing application session continues, but a new connection fails. Engineer proposes disabling hostname, time and revocation checks permanently.

1. The service needed to recover an identity system itself requires that unavailable identity system to start.
2. A certificate containing more than one permitted name.
3. A resolver with a documented backup server.
4. Two services using different hostnames.

**Correct option(s):** 1

- Option 1: The recovery path depends on the failed component it must restore.
- Option 2: That is not a recovery dependency by itself.
- Option 3: A backup can reduce dependence if its own prerequisites work.
- Option 4: Different names do not create a cycle.

#### Recall

**Does trusted issuer mean correct peer?**

No. Chain trust and the intended server identity are separate validation checks.

**Why test new sessions during outages?**

Existing tokens, sessions and caches can hide failed startup, renewal, identity, time or revocation dependencies.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [RFC 5905: NTPv4](https://www.rfc-editor.org/rfc/rfc5905)

### GICSP-L035 — Virtualisation, storage and supervisory-service resilience

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L034

Virtualisation separates workloads logically while sharing physical resources and administration. Two virtual machines on one host are not independent against host failure; two hosts using one storage array may share a storage failure; separate racks can still depend on one management credential, upstream power source or network service. Draw the service dependency graph through compute, memory, storage, network, identity, backup and physical support. Redundancy is meaningful only relative to specified failures and demonstrated capacity after those failures.

A hypervisor management plane can control guest power, consoles, virtual disks and network attachments. A role that cannot log into the guest may still read its disk or inject media through the platform. Constrain management roles, use separate named administrative identities and protect the out-of-band/BMC path. A VLAN inside the virtual switch does not prevent a sufficiently privileged hypervisor administrator from changing virtual connectivity. Explain this authority boundary rather than claiming guest firewall rules constrain every underlying administrator.

Snapshots capture a point in a virtual machine's state, but their consistency and independence vary. A crash-consistent disk snapshot resembles an abrupt stop from the application's perspective; an application-consistent backup coordinates the application's write state using supported mechanisms. A snapshot on the same array is not an independent copy against array failure. Snapshot chains can consume space and affect performance; monitor their supported use and consolidation requirements. Do not treat indefinite snapshots as a substitute for a protected, tested backup system.

Resource contention can affect timing even when average utilisation looks acceptable. CPU scheduling delay, memory pressure, storage latency and oversubscribed uplinks can delay a historian or alarm server. A virtual-machine CPU count does not guarantee dedicated physical execution capacity. Reserve or size resources according to supported application requirements and verify worst-case workload behaviour. After failover, the surviving host needs enough capacity for the required service set, not merely enough memory to power on the guests.

High availability commonly restarts a failed guest on another host; it does not always preserve an uninterrupted application session. Application clustering or replication has its own state, quorum and consistency rules. If two isolated nodes both believe they are active, split-brain can cause conflicting writes unless fencing/quorum design prevents it. A heartbeat path and a client-service path can fail differently. Test the specific failure scenarios, observe application interruption and data consistency, and compare them with the requirement rather than accepting a generic “HA enabled” checkbox.

Recovery must restore the service stack in a workable order: platform access, storage, networking, identity/time/name services, application data and the application itself, according to actual dependencies. Avoid circular dependence on a directory VM whose hypervisor administration requires that same unavailable directory without a tested emergency route. After recovery, verify current data, roles, certificates, alarms and downstream communication. The synthetic capacity calculation in this chapter is an engineering exercise; it does not establish measured performance on a particular hypervisor or vendor cluster.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic platform: hosts H1 and H2 each provide 12 usable CPU capacity units under the supplied sizing model. Required services use 7 units on H1 and 8 on H2. Both hosts use array A and one storage switch S. “Backup” is a snapshot on A. HA can restart a failed VM on the surviving host, but measured application restart plus validation is 140 s; service requirement is ≤90 s. Directory VM D runs on the cluster; all hypervisor login paths require D, with no tested emergency path. A datastore alert shows 96% used; a long-lived snapshot continues growing.

**Reasoning:** After one host fails, 15 required units exceed the surviving 12 by three, so the model does not support full service capacity. A and S are shared failure domains. The same-array snapshot does not protect against loss of A. The measured accepted-service interruption 140 s exceeds the 90 s criterion. Directory-dependent management creates a recovery access cycle. Datastore growth is an immediate capacity issue needing supported remediation and preserved recovery evidence, not an arbitrary deletion of virtual disks.

#### Guided practice

Propose two ways to meet the one-host-loss capacity requirement and state the validation needed.

**Hint:** Change available capacity or the explicitly required degraded service set.

**Worked solution:** Add sufficient supported surviving capacity with margin, or obtain approval for a reduced degraded service set that fits 12 units. Validate the workload model, actual application performance and recovery timing under the specified failure; do not silently drop required services.

#### Independent task

Environment: analytical

Write a platform resilience finding and remediation acceptance plan.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L035.json

**Evidence to produce**

- Capacity calculation
- Shared-dependency diagram
- Independent backup design
- Recovery timing/access tests
- Storage-space treatment plan

**Acceptance criteria**

- Fifteen required units do not fit twelve surviving units.
- Snapshots on A are not independent of A.
- HA restart capability is distinguished from accepted-service recovery time.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0341 · single · calculation**

What is the capacity shortfall after either host is lost under the supplied model?

Synthetic platform: hosts H1 and H2 each provide 12 usable CPU capacity units under the supplied sizing model. Required services use 7 units on H1 and 8 on H2. Both hosts use array A and one storage switch S. “Backup” is a snapshot on A. HA can restart a failed VM on the surviving host, but measured application restart plus validation is 140 s; service requirement is ≤90 s. Directory VM D runs on the cluster; all hypervisor login paths require D, with no tested emergency path. A datastore alert shows 96% used; a long-lived snapshot continues growing.

1. 3 units.
2. Eight units, because H2’s normal load is the entire failover deficit.
3. No shortfall, because the cluster has 24 units before the fault.
4. One unit, because the two normal host loads differ by one.

**Correct option(s):** 1

- Option 1: Required load is 7+8=15 and surviving capacity is 12.
- Option 2: Some load can fit on the survivor; the deficit is 15 minus 12, or three units.
- Option 3: After one host is lost only 12 usable units remain against 15 required.
- Option 4: The relevant comparison is combined required load against surviving capacity.

**GICSP-Q0342 · multi · design**

Which failures can affect both hosts' storage access? Select all that apply.

Synthetic platform: hosts H1 and H2 each provide 12 usable CPU capacity units under the supplied sizing model. Required services use 7 units on H1 and 8 on H2. Both hosts use array A and one storage switch S. “Backup” is a snapshot on A. HA can restart a failed VM on the surviving host, but measured application restart plus validation is 140 s; service requirement is ≤90 s. Directory VM D runs on the cluster; all hypervisor login paths require D, with no tested emergency path. A datastore alert shows 96% used; a long-lived snapshot continues growing.

1. Loss of H1 alone while H2 remains healthy.
2. Loss of array A.
3. Loss of storage switch S.
4. Failure of one guest operating system while both hosts and shared storage remain healthy.

**Correct option(s):** 2, 3

- Option 1: That removes one host, not the shared storage by itself.
- Option 2: Both hosts depend on the same array.
- Option 3: Both storage paths share that switch.
- Option 4: A guest failure does not itself remove the shared array or switch from both hosts.

**GICSP-Q0343 · single · diagnosis**

Why is the snapshot not an independent backup against array loss?

Synthetic platform: hosts H1 and H2 each provide 12 usable CPU capacity units under the supplied sizing model. Required services use 7 units on H1 and 8 on H2. Both hosts use array A and one storage switch S. “Backup” is a snapshot on A. HA can restart a failed VM on the surviving host, but measured application restart plus validation is 140 s; service requirement is ≤90 s. Directory VM D runs on the cluster; all hypervisor login paths require D, with no tested emergency path. A datastore alert shows 96% used; a long-lived snapshot continues growing.

1. It resides on the same array A.
2. It was created by a hypervisor.
3. The snapshot has no recovery value in any failure because it resides on A.
4. The snapshot should be treated as independent because it is catalogued under a separate backup job.

**Correct option(s):** 1

- Option 1: The same failure can remove the live data and snapshot.
- Option 2: The decisive issue here is shared storage, not the creator's name.
- Option 3: It may help with some logical failures, but does not survive the specified array loss independently.
- Option 4: Its storage remains array A, so array loss affects both source and snapshot.

**GICSP-Q0344 · single · calculation**

Does the 140 s recovery meet the supplied service requirement?

Synthetic platform: hosts H1 and H2 each provide 12 usable CPU capacity units under the supplied sizing model. Required services use 7 units on H1 and 8 on H2. Both hosts use array A and one storage switch S. “Backup” is a snapshot on A. HA can restart a failed VM on the surviving host, but measured application restart plus validation is 140 s; service requirement is ≤90 s. Directory VM D runs on the cluster; all hypervisor login paths require D, with no tested emergency path. A datastore alert shows 96% used; a long-lived snapshot continues growing.

1. Fail because the 90-second requirement means no restart time is permitted.
2. No; it exceeds the 90 s accepted-service limit by 50 s.
3. Yes if validation time is silently excluded.
4. Yes; HA is enabled.

**Correct option(s):** 2

- Option 1: The criterion allows up to 90 seconds; the measured 140-second accepted recovery is the actual failure.
- Option 2: Restart and mandatory validation are included in the measured recovery.
- Option 3: The requirement is accepted service, not merely boot completion.
- Option 4: A feature setting does not override the measured result.

**GICSP-Q0345 · single · diagnosis**

What is the directory-related recovery defect?

Synthetic platform: hosts H1 and H2 each provide 12 usable CPU capacity units under the supplied sizing model. Required services use 7 units on H1 and 8 on H2. Both hosts use array A and one storage switch S. “Backup” is a snapshot on A. HA can restart a failed VM on the surviving host, but measured application restart plus validation is 140 s; service requirement is ≤90 s. Directory VM D runs on the cluster; all hypervisor login paths require D, with no tested emergency path. A datastore alert shows 96% used; a long-lived snapshot continues growing.

1. A directory VM cannot be hosted on a virtual platform under any design.
2. Using authentication for hypervisor access is itself wrong.
3. Management access requires D even when D may need platform recovery.
4. The directory has a short hostname.

**Correct option(s):** 3

- Option 1: The concrete issue is circular recovery dependence without a tested emergency path.
- Option 2: Authentication is needed; its outage dependencies must be handled.
- Option 3: No tested independent access route breaks the cycle.
- Option 4: Name length does not determine recovery access.

**GICSP-Q0346 · single · mechanism**

What can a powerful hypervisor administrator do despite lacking a guest login?

Synthetic platform: hosts H1 and H2 each provide 12 usable CPU capacity units under the supplied sizing model. Required services use 7 units on H1 and 8 on H2. Both hosts use array A and one storage switch S. “Backup” is a snapshot on A. HA can restart a failed VM on the surviving host, but measured application restart plus validation is 140 s; service requirement is ≤90 s. Directory VM D runs on the cluster; all hypervisor login paths require D, with no tested emergency path. A datastore alert shows 96% used; a long-lived snapshot continues growing.

1. Nothing affecting the guest under any circumstances.
2. Hypervisor access records automatically satisfy every application-level audit requirement.
3. Potentially access virtual disks or consoles and change virtual connectivity.
4. The hypervisor administrator can affect only the guest’s DNS record without guest credentials.

**Correct option(s):** 3

- Option 1: The hypervisor controls underlying resources.
- Option 2: Infrastructure and application actions have different identities and evidence needs.
- Option 3: Platform authority can bypass assumptions about guest-only access.
- Option 4: Hypervisor authority can affect disks, memory, snapshots and availability outside guest login.

**GICSP-Q0347 · single · mechanism**

What distinguishes application-consistent backup from an uncoordinated crash-consistent snapshot?

Synthetic platform: hosts H1 and H2 each provide 12 usable CPU capacity units under the supplied sizing model. Required services use 7 units on H1 and 8 on H2. Both hosts use array A and one storage switch S. “Backup” is a snapshot on A. HA can restart a failed VM on the surviving host, but measured application restart plus validation is 140 s; service requirement is ≤90 s. Directory VM D runs on the cluster; all hypervisor login paths require D, with no tested emergency path. A datastore alert shows 96% used; a long-lived snapshot continues growing.

1. Supported coordination of the application's write state.
2. Crash-consistent snapshots are independent of the source array by definition.
3. A successful hypervisor snapshot task without any application coordination.
4. Application-consistent status removes the need to test restoration and service acceptance.

**Correct option(s):** 1

- Option 1: This can preserve a defined recoverable transaction state.
- Option 2: Consistency semantics do not determine physical storage independence.
- Option 3: Task success can produce only the supported snapshot consistency level; it does not imply coordinated application state.
- Option 4: Consistency is one property; recoverability and operational behaviour still need validation.

**GICSP-Q0348 · single · mechanism**

What is split-brain in a redundant application context?

Synthetic platform: hosts H1 and H2 each provide 12 usable CPU capacity units under the supplied sizing model. Required services use 7 units on H1 and 8 on H2. Both hosts use array A and one storage switch S. “Backup” is a snapshot on A. HA can restart a failed VM on the surviving host, but measured application restart plus validation is 140 s; service requirement is ≤90 s. Directory VM D runs on the cluster; all hypervisor login paths require D, with no tested emergency path. A datastore alert shows 96% used; a long-lived snapshot continues growing.

1. A guest with two virtual CPUs.
2. A host with separate management and storage NICs.
3. Separated nodes both act as active owners and may issue conflicting writes.
4. A snapshot with two restore points.

**Correct option(s):** 3

- Option 1: CPU count is unrelated to ownership conflict.
- Option 2: Interface separation does not define application ownership.
- Option 3: Quorum/fencing design constrains ownership during partitions.
- Option 4: Multiple copies are not themselves split-brain.

**GICSP-Q0349 · single · operations**

What should be done with the 96%-full datastore and growing snapshot?

Synthetic platform: hosts H1 and H2 each provide 12 usable CPU capacity units under the supplied sizing model. Required services use 7 units on H1 and 8 on H2. Both hosts use array A and one storage switch S. “Backup” is a snapshot on A. HA can restart a failed VM on the surviving host, but measured application restart plus validation is 140 s; service requirement is ≤90 s. Directory VM D runs on the cluster; all hypervisor login paths require D, with no tested emergency path. A datastore alert shows 96% used; a long-lived snapshot continues growing.

1. Ignore it because CPU capacity is the only relevant resource.
2. Delete arbitrary virtual-disk files immediately.
3. Use the supported capacity/remediation procedure, preserving required evidence and validating service impact.
4. Assume a snapshot never grows.

**Correct option(s):** 3

- Option 1: Storage exhaustion can stop or corrupt service.
- Option 2: That can destroy active data and recovery chains.
- Option 3: Space exhaustion and snapshot handling need a controlled response.
- Option 4: Copy-on-write behaviour can consume additional space.

**GICSP-Q0350 · single · implementation**

Which evidence is required after adding a larger host to address the modelled deficit?

Synthetic platform: hosts H1 and H2 each provide 12 usable CPU capacity units under the supplied sizing model. Required services use 7 units on H1 and 8 on H2. Both hosts use array A and one storage switch S. “Backup” is a snapshot on A. HA can restart a failed VM on the surviving host, but measured application restart plus validation is 140 s; service requirement is ≤90 s. Directory VM D runs on the cluster; all hypervisor login paths require D, with no tested emergency path. A datastore alert shows 96% used; a long-lived snapshot continues growing.

1. Only a successful empty-VM boot.
2. Failure-case application performance, capacity margin and accepted recovery timing.
3. Only the new host datasheet showing more CPU units than the old host.
4. Only the number of virtual CPUs configured.

**Correct option(s):** 2

- Option 1: The required service set and dependencies are untested.
- Option 2: Hardware capacity alone does not demonstrate the required service.
- Option 3: A specification supports sizing but does not measure the actual failure-case workload or accepted recovery time.
- Option 4: Virtual allocation does not guarantee physical scheduling or application performance.

#### Recall

**What does HA enabled fail to prove?**

Sufficient surviving capacity, uninterrupted sessions, consistent data and recovery within the accepted-service requirement.

**Snapshot independence versus consistency?**

Independence concerns shared failure domains; consistency concerns recoverable application state. A copy needs both properties as required.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

## GICSP-M08 — Industrial communications and cryptographic protection

### GICSP-L036 — Modbus transactions, register maps and defensive interpretation

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L035

Modbus separates a compact application operation from its transport framing. Common function codes include 03 for reading holding registers, 04 for reading input registers, 06 for writing one holding register and hexadecimal 10 for writing multiple registers. Coils and discrete inputs represent bits; holding and input registers represent sixteen-bit values. The device's register map supplies meaning, access, units, scaling and multi-register layout. A register named temperature in a spreadsheet is not proven correct until the actual address convention and device revision are reconciled.

A Modbus TCP application data unit starts with the MBAP header: two-byte transaction identifier, two-byte protocol identifier, two-byte length and one-byte unit identifier. The length counts the bytes after the length field, including the unit identifier and application PDU. Protocol identifier zero denotes the Modbus convention. The transaction identifier helps correlate a response with a request on the relevant connection; it is not an authenticated user identity or a globally unique event number. A TCP stream may split or combine application messages, so real capture analysis requires reassembly and length-aware parsing.

Protocol addresses in a PDU are zero-based offsets. Human documentation may use labels such as 40001 for the first holding register, or may already show the raw offset. Do not subtract one twice or transmit the literal human reference without checking the convention. A read beginning at offset 100 for quantity two accesses offsets 100 and 101. Each register is transmitted high byte first, while the arrangement of several registers into a thirty-two-bit integer or floating value is defined by the device mapping and may vary between products.

A normal read response includes a byte count and the returned register bytes. For two registers, four data bytes are expected. An exception response sets the high bit of the requested function code and returns an exception code. For example, 86 identifies an exception to function 06, and exception 02 indicates an illegal data address under the protocol. That is an application response, not a transport timeout. A normal write echo acknowledges the protocol operation; the physical process effect still requires appropriate feedback and context.

Traditional Modbus TCP/RTU does not inherently provide authenticated per-user command authority or encryption. A TCP 502 allow rule permits the service path and may allow both reads and writes. A function-aware gateway can constrain operations only if its implementation and complete path are verified; device roles, network boundaries and engineering access remain relevant. Modbus Security is a distinct specified security approach, not a property automatically gained by calling ordinary Modbus traffic secure. Serial RTU uses its own framing and CRC; the CRC detects transmission errors, not malicious-source authenticity.

Analyse passively supplied records before considering any authorised live test. Correlate connection, transaction, unit, function, address, response and approved work context. Preserve unknowns: a missing response may reflect capture loss, timeout or device failure; it does not prove a successful write. Use the exact device register map for engineering interpretation, and test parsers against truncation and malformed lengths in an offline fixture. The official specification index is current; full document download access may require the publisher's licence process, and no paid or gated text is reproduced here.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic complete Modbus TCP ADUs, one per line (hex):
R1 request: 00 2a 00 00 00 06 01 03 00 64 00 02
R1 response: 00 2a 00 00 00 07 01 03 04 00 fa 01 04
W1 request: 00 2b 00 00 00 06 01 06 00 64 01 2c
W1 response: 00 2b 00 00 00 03 01 86 02
Supplied device map: holding offsets 100 and 101 are unsigned temperature observations scaled 0.1 °C and are read-only through this service. Human reference labels are 40101 and 40102, with 40001 corresponding to offset 0. Firewall permits TCP 502 from HMI H. No per-user field exists in these ADUs. Capture is complete for these four ADUs only.

**Reasoning:** R1 transaction 0x002a reads unit 1, function 03, offsets100–101. Response length7 counts unit 1+function 1+byte-count1+four data bytes. Values0x00fa=250 and 0x0104=260 become25.0 and 26.0 °C. W1 requests function 06 at offset 100 with value300, but 0x86/02 is an illegal-address exception, not a successful write. The firewall service permission does not establish read-only authority or identify a human. Interpret only the supplied complete records, not all site traffic.

#### Guided practice

Decode the address, quantity and engineering values without using the human reference as a raw offset.

**Hint:** Break the MBAP and PDU fields before applying scaling.

**Worked solution:** Raw offset 0x0064=100 corresponds to human40101; quantity0x0002=2. Response bytes divide into00fa and 0104; multiply250 and 260 by0.1 to obtain25.0 and 26.0 °C.

Run the supplied offline protocol_lab.py decoder and self-check from the project README to compare your field interpretation with the synthetic PCAP. The generator and decoder were executed during authoring; this is synthetic software validation, not a live-device test.

#### Independent task

Environment: analytical

Produce a transaction table and offline parser acceptance cases.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L036.json
- course_labs/GICSP/protocol_lab.py
- course_labs/GICSP/modbus_synthetic.pcap
- course_labs/GICSP/README.md

**Evidence to produce**

- Field-by-field decode
- Request/response correlation
- Read/write authority finding
- Truncation and length-mismatch cases

**Acceptance criteria**

- MBAP length includes unit identifier and PDU.
- The write exception is not reported as a successful process change.
- Register meaning uses the supplied map and scaling.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0351 · single · calculation**

Which offsets does R1 request?

Synthetic complete Modbus TCP ADUs, one per line (hex):
R1 request: 00 2a 00 00 00 06 01 03 00 64 00 02
R1 response: 00 2a 00 00 00 07 01 03 04 00 fa 01 04
W1 request: 00 2b 00 00 00 06 01 06 00 64 01 2c
W1 response: 00 2b 00 00 00 03 01 86 02
Supplied device map: holding offsets 100 and 101 are unsigned temperature observations scaled 0.1 °C and are read-only through this service. Human reference labels are 40101 and 40102, with 40001 corresponding to offset 0. Firewall permits TCP 502 from HMI H. No per-user field exists in these ADUs. Capture is complete for these four ADUs only.

1. 100 and 102.
2. 100 and 101.
3. 40101 and 40102.
4. 99 and 100.

**Correct option(s):** 2

- Option 1: A quantity of two selects consecutive offsets 100 and 101, not a skipped register.
- Option 2: Starting offset 0x0064 is 100 and quantity0x0002 is two.
- Option 3: Those are the supplied human reference labels; the ADU carries offsets 100 and 101.
- Option 4: That incorrectly subtracts one from the already zero-based protocol offset.

**GICSP-Q0352 · single · calculation**

What engineering values are returned by R1?

Synthetic complete Modbus TCP ADUs, one per line (hex):
R1 request: 00 2a 00 00 00 06 01 03 00 64 00 02
R1 response: 00 2a 00 00 00 07 01 03 04 00 fa 01 04
W1 request: 00 2b 00 00 00 06 01 06 00 64 01 2c
W1 response: 00 2b 00 00 00 03 01 86 02
Supplied device map: holding offsets 100 and 101 are unsigned temperature observations scaled 0.1 °C and are read-only through this service. Human reference labels are 40101 and 40102, with 40001 corresponding to offset 0. Firewall permits TCP 502 from HMI H. No per-user field exists in these ADUs. Capture is complete for these four ADUs only.

1. 64.0 °C and 102.5 °C.
2. 250 °C and 260 °C.
3. 25.0 °C and 26.0 °C.
4. 30.0 °C and 25.0 °C.

**Correct option(s):** 3

- Option 1: This reflects an unjustified byte-order interpretation.
- Option 2: That omits the map's scale factor.
- Option 3: 0x00fa=250 and 0x0104=260, each scaled by0.1.
- Option 4: The300 value belongs to the separate write request.

**GICSP-Q0353 · single · mechanism**

What does MBAP length 0007 count in the response?

Synthetic complete Modbus TCP ADUs, one per line (hex):
R1 request: 00 2a 00 00 00 06 01 03 00 64 00 02
R1 response: 00 2a 00 00 00 07 01 03 04 00 fa 01 04
W1 request: 00 2b 00 00 00 06 01 06 00 64 01 2c
W1 response: 00 2b 00 00 00 03 01 86 02
Supplied device map: holding offsets 100 and 101 are unsigned temperature observations scaled 0.1 °C and are read-only through this service. Human reference labels are 40101 and 40102, with 40001 corresponding to offset 0. Firewall permits TCP 502 from HMI H. No per-user field exists in these ADUs. Capture is complete for these four ADUs only.

1. Unit identifier plus the six PDU bytes.
2. Only the four register-data bytes.
3. Seven registers.
4. The entire thirteen-byte ADU.

**Correct option(s):** 1

- Option 1: One unit byte, function, byte count and four data bytes total seven.
- Option 2: The length also includes unit and PDU control fields.
- Option 3: The field counts bytes, not register quantity.
- Option 4: The preceding transaction/protocol/length fields are excluded.

**GICSP-Q0354 · single · diagnosis**

What is the supplied W1 outcome?

Synthetic complete Modbus TCP ADUs, one per line (hex):
R1 request: 00 2a 00 00 00 06 01 03 00 64 00 02
R1 response: 00 2a 00 00 00 07 01 03 04 00 fa 01 04
W1 request: 00 2b 00 00 00 06 01 06 00 64 01 2c
W1 response: 00 2b 00 00 00 03 01 86 02
Supplied device map: holding offsets 100 and 101 are unsigned temperature observations scaled 0.1 °C and are read-only through this service. Human reference labels are 40101 and 40102, with 40001 corresponding to offset 0. Firewall permits TCP 502 from HMI H. No per-user field exists in these ADUs. Capture is complete for these four ADUs only.

1. A read of six registers.
2. An exception to function 06 with illegal data address code02.
3. A normal echo confirming value300 was written.
4. A TCP connection timeout.

**Correct option(s):** 2

- Option 1: Function06 is a write-single-register operation.
- Option 2: 0x86 sets the exception bit on 06 and 02 gives the exception reason.
- Option 3: A normal06 response would echo address/value, not86/02.
- Option 4: An application response was supplied.

**GICSP-Q0355 · single · mechanism**

What does transaction identifier 002a provide?

Synthetic complete Modbus TCP ADUs, one per line (hex):
R1 request: 00 2a 00 00 00 06 01 03 00 64 00 02
R1 response: 00 2a 00 00 00 07 01 03 04 00 fa 01 04
W1 request: 00 2b 00 00 00 06 01 06 00 64 01 2c
W1 response: 00 2b 00 00 00 03 01 86 02
Supplied device map: holding offsets 100 and 101 are unsigned temperature observations scaled 0.1 °C and are read-only through this service. Human reference labels are 40101 and 40102, with 40001 corresponding to offset 0. Firewall permits TCP 502 from HMI H. No per-user field exists in these ADUs. Capture is complete for these four ADUs only.

1. A globally unique incident identifier.
2. Proof that the register map is current.
3. A correlation field for the request and response on the relevant connection.
4. The authenticated engineer's employee number.

**Correct option(s):** 3

- Option 1: Transaction values can be reused across time/connections.
- Option 2: Map provenance is separate.
- Option 3: It is not an identity credential.
- Option 4: No such user field exists in the supplied ADU.

**GICSP-Q0356 · single · diagnosis**

Why does permitting TCP 502 not establish read-only access?

Synthetic complete Modbus TCP ADUs, one per line (hex):
R1 request: 00 2a 00 00 00 06 01 03 00 64 00 02
R1 response: 00 2a 00 00 00 07 01 03 04 00 fa 01 04
W1 request: 00 2b 00 00 00 06 01 06 00 64 01 2c
W1 response: 00 2b 00 00 00 03 01 86 02
Supplied device map: holding offsets 100 and 101 are unsigned temperature observations scaled 0.1 °C and are read-only through this service. Human reference labels are 40101 and 40102, with 40001 corresponding to offset 0. Firewall permits TCP 502 from HMI H. No per-user field exists in these ADUs. Capture is complete for these four ADUs only.

1. A unit identifier of 1 automatically disables writes.
2. Read and write functions can use the same service connection.
3. TCP 502 is reserved only for writes.
4. TCP encryption inherently blocks writes.

**Correct option(s):** 2

- Option 1: Unit identity is not a permission model.
- Option 2: A port rule does not distinguish function 03 from 06.
- Option 3: It commonly carries multiple Modbus functions.
- Option 4: Encryption is not operation-specific authorisation.

**GICSP-Q0357 · single · implementation**

Which rule applies to a two-register 32-bit value not otherwise defined here?

Synthetic complete Modbus TCP ADUs, one per line (hex):
R1 request: 00 2a 00 00 00 06 01 03 00 64 00 02
R1 response: 00 2a 00 00 00 07 01 03 04 00 fa 01 04
W1 request: 00 2b 00 00 00 06 01 06 00 64 01 2c
W1 response: 00 2b 00 00 00 03 01 86 02
Supplied device map: holding offsets 100 and 101 are unsigned temperature observations scaled 0.1 °C and are read-only through this service. Human reference labels are 40101 and 40102, with 40001 corresponding to offset 0. Firewall permits TCP 502 from HMI H. No per-user field exists in these ADUs. Capture is complete for these four ADUs only.

1. Reverse all message bytes, including the MBAP header, to decode a multi-register value.
2. Consult the device map for register/word order and representation.
3. Use one universal 32-bit float word order whenever two Modbus registers are present.
4. Use the transaction identifier as part of the 32-bit process value.

**Correct option(s):** 2

- Option 1: Endianness interpretation applies to the documented data representation, not indiscriminate message reversal.
- Option 2: High-byte order inside a register does not uniquely define every multi-register layout.
- Option 3: The device map must define type, scaling and word/byte order.
- Option 4: The transaction identifier is MBAP correlation context, not register payload data.

**GICSP-Q0358 · single · mechanism**

What does an RTU CRC establish when it verifies?

Synthetic complete Modbus TCP ADUs, one per line (hex):
R1 request: 00 2a 00 00 00 06 01 03 00 64 00 02
R1 response: 00 2a 00 00 00 07 01 03 04 00 fa 01 04
W1 request: 00 2b 00 00 00 06 01 06 00 64 01 2c
W1 response: 00 2b 00 00 00 03 01 86 02
Supplied device map: holding offsets 100 and 101 are unsigned temperature observations scaled 0.1 °C and are read-only through this service. Human reference labels are 40101 and 40102, with 40001 corresponding to offset 0. Firewall permits TCP 502 from HMI H. No per-user field exists in these ADUs. Capture is complete for these four ADUs only.

1. Consistency with the transmission-error checksum for those bytes.
2. The requested operation is safe for the process.
3. The human sender was authorised.
4. The device firmware is genuine.

**Correct option(s):** 1

- Option 1: It is not cryptographic source authentication.
- Option 2: Protocol integrity does not assess consequence.
- Option 3: CRC has no per-user identity mechanism.
- Option 4: Firmware provenance is unrelated to a frame CRC.

**GICSP-Q0359 · multi · design**

What must a real TCP capture parser handle beyond these one-ADU lines? Select all that apply.

Synthetic complete Modbus TCP ADUs, one per line (hex):
R1 request: 00 2a 00 00 00 06 01 03 00 64 00 02
R1 response: 00 2a 00 00 00 07 01 03 04 00 fa 01 04
W1 request: 00 2b 00 00 00 06 01 06 00 64 01 2c
W1 response: 00 2b 00 00 00 03 01 86 02
Supplied device map: holding offsets 100 and 101 are unsigned temperature observations scaled 0.1 °C and are read-only through this service. Human reference labels are 40101 and 40102, with 40001 corresponding to offset 0. Firewall permits TCP 502 from HMI H. No per-user field exists in these ADUs. Capture is complete for these four ADUs only.

1. Assume every Ethernet frame is exactly one Modbus request.
2. Multiple application messages within a stream segment.
3. Infer successful writes whenever a response is missing.
4. Application messages split across TCP segments.

**Correct option(s):** 2, 4

- Option 1: That assumption fails normal stream segmentation/coalescing.
- Option 2: Length-aware parsing may find more than one ADU.
- Option 3: Missing evidence is not success.
- Option 4: TCP does not preserve application message boundaries.

**GICSP-Q0360 · single · diagnosis**

What can be concluded about all site writes from these four ADUs?

Synthetic complete Modbus TCP ADUs, one per line (hex):
R1 request: 00 2a 00 00 00 06 01 03 00 64 00 02
R1 response: 00 2a 00 00 00 07 01 03 04 00 fa 01 04
W1 request: 00 2b 00 00 00 06 01 06 00 64 01 2c
W1 response: 00 2b 00 00 00 03 01 86 02
Supplied device map: holding offsets 100 and 101 are unsigned temperature observations scaled 0.1 °C and are read-only through this service. Human reference labels are 40101 and 40102, with 40001 corresponding to offset 0. Firewall permits TCP 502 from HMI H. No per-user field exists in these ADUs. Capture is complete for these four ADUs only.

1. Every HMI write succeeded because the firewall allowed502.
2. No write has ever succeeded anywhere on the site.
3. The site has implemented Modbus Security automatically.
4. Only W1's supplied exception is established; other traffic is outside the capture scope.

**Correct option(s):** 4

- Option 1: Application outcome contradicts that for W1.
- Option 2: Four records cannot prove that universal claim.
- Option 3: Traditional ADUs and a port allow do not establish that distinct protection.
- Option 4: The fixture is explicitly bounded.

#### Recall

**How is Modbus TCP length interpreted?**

MBAP length counts the following unit identifier plus PDU, not the entire ADU or the number of registers.

**What does function|0x80 mean in a response?**

An exception response; inspect the exception code and do not confuse it with successful operation or a transport timeout.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [Modbus Organization: current specifications and implementation guides](https://www.modbus.org/modbus-specifications)
- [Modbus Application Protocol Specification V1.1b3](https://www.modbus.org/file/secure/modbusprotocolspecification.pdf)
- [Modbus Messaging on TCP/IP Implementation Guide V1.0b](https://www.modbus.org/file/secure/messagingimplementationguide.pdf)

### GICSP-L037 — BACnet objects, command priority and routed discovery

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L036

BACnet represents building-automation information as objects with properties and services. An object identifier combines an object type with an instance number; the enclosing device has its own device instance. An analog-input instance7 on device 1001 is not necessarily the same point as analog-input7 on device 1002. Preserve the device, object, property, units and quality/state context in mappings. Friendly names can change or collide, so they are not sufficient as the only stable identity.

ReadProperty obtains a property value, while WriteProperty requests a change subject to object support and authorisation. A commandable Present_Value commonly uses a sixteen-slot priority array. Lower priority numbers have greater precedence; the highest-priority non-NULL entry determines the effective value. Releasing a command means writing NULL to Present_Value at that command's priority through the supported service, not overwriting every other owner's slot. If all slots are NULL, Relinquish_Default supplies the effective value for the commandable object. Product-specific reserved priorities and capabilities still need checking.

A successful lower-priority write can be stored without changing the effective output because a higher-priority entry remains active. This is not necessarily a failed write. Inspect the priority array and effective value together. A forgotten manual override can outlive the work that created it, and a low-priority automation command may suddenly become effective when the override is released. Plan the transition and validate the intended fallback. Priority is an arbitration mechanism; it is not, by itself, authentication of the person or application issuing the command.

Discovery and routing require network context. Who-Is and I-Am support device discovery, but an I-Am announcement is not a cryptographic identity proof. Conventional BACnet/IP uses UDP and broadcast-related mechanisms; IP routers do not ordinarily forward local broadcasts as if all subnets were one segment. A BACnet Broadcast Management Device distributes relevant broadcasts across configured peers, and foreign-device registration supports specified remote participants. Incorrect distribution tables or exposed registration can expand discovery and traffic beyond the intended boundary. A BBMD is not an application firewall.

BACnet MS/TP uses token-managed access on a serial medium; duplicate addresses, incorrect timing and wiring can disrupt it. A router between BACnet/IP and MS/TP is a dependency for many downstream objects, so preserve per-device status and avoid equating router reachability with point freshness. BACnet Secure Connect provides a different secured transport architecture using certificates and TLS-based connections; it does not retroactively secure an unprotected legacy segment behind a router. Verify the complete route and administrative paths.

Change-of-value subscriptions can reduce polling, but their lifetimes, renewal, loss handling and notification quality must be understood. A quiet subscription may indicate stable values or a failed subscription, so use health and freshness evidence. Test identity mapping, priority release, role restrictions, discovery scope, subscription renewal and degraded communications with synthetic or isolated records. Do not broadcast discovery or issue writes on a live building network merely to complete this lesson. The examples specify their own command model and do not claim conformance testing of a vendor product.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic BACnet commandable analog-output AO3 on device 1001: priority 4=70%, priority 8=50%, priority 16=40%, all other slots NULL; Relinquish_Default=30%. Effective Present_Value=70%. Automation writes55% at priority 16 and receives success. Maintenance wants to release only its priority 4 override. A second device 1002 also has AO3. BBMD distribution table includes an unapproved external peer. A COV subscription expires at 14:00 with no renewal; last source update is 13:58 but the dashboard shows GOOD at 14:20. Conventional BACnet/IP is used on the field side; no application authentication evidence is supplied.

**Reasoning:** The priority 16 write can succeed while70% remains effective because priority 4 wins. Releasing priority 4 with NULL leaves priority 8=50% effective; it does not jump directly to 55% or the 30% default. Device identity distinguishes the two AO3 objects. The unapproved BBMD peer expands broadcast distribution and needs review. After subscription expiry, silence does not prove unchanged process state; show the freshness/collection gap. A successful service response and priority number do not identify an authorised human.

#### Guided practice

Predict values after releasing priority 4, then priority 8, then priority 16.

**Hint:** At each step choose the lowest-numbered non-NULL slot; use default only when none remain.

**Worked solution:** After priority 4 release:50%. After priority 8 release:55%, including the stored automation update. After priority 16 release:30% Relinquish_Default.

#### Independent task

Environment: analytical

Build a command-priority and discovery-boundary acceptance table.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L037.json

**Evidence to produce**

- Priority transition trace
- Device/object identity map
- BBMD peer review
- COV expiry/freshness test

**Acceptance criteria**

- NULL release targets the intended priority without erasing other owners.
- Write success is distinguished from effective output change.
- Legacy field-side traffic is not claimed secured merely by another transport elsewhere.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0361 · single · diagnosis**

What is the effective value immediately after the successful priority 16 write of 55%?

Synthetic BACnet commandable analog-output AO3 on device 1001: priority 4=70%, priority 8=50%, priority 16=40%, all other slots NULL; Relinquish_Default=30%. Effective Present_Value=70%. Automation writes55% at priority 16 and receives success. Maintenance wants to release only its priority 4 override. A second device 1002 also has AO3. BBMD distribution table includes an unapproved external peer. A COV subscription expires at 14:00 with no renewal; last source update is 13:58 but the dashboard shows GOOD at 14:20. Conventional BACnet/IP is used on the field side; no application authentication evidence is supplied.

1. 55%, because the latest successful write always determines Present_Value.
2. 70%.
3. 30%, because writing a lower priority invokes Relinquish_Default.
4. 50%, because automation at priority 8 outranks maintenance priority 4.

**Correct option(s):** 2

- Option 1: Priority4 remains active and outranks the updated priority 16 entry.
- Option 2: Priority4 remains the highest-precedence non-NULL entry.
- Option 3: The default is used only when no priority entry remains active.
- Option 4: Lower numeric priority has higher precedence, so priority 4 still wins.

**GICSP-Q0362 · single · diagnosis**

What happens after maintenance releases only priority 4?

Synthetic BACnet commandable analog-output AO3 on device 1001: priority 4=70%, priority 8=50%, priority 16=40%, all other slots NULL; Relinquish_Default=30%. Effective Present_Value=70%. Automation writes55% at priority 16 and receives success. Maintenance wants to release only its priority 4 override. A second device 1002 also has AO3. BBMD distribution table includes an unapproved external peer. A COV subscription expires at 14:00 with no renewal; last source update is 13:58 but the dashboard shows GOOD at 14:20. Conventional BACnet/IP is used on the field side; no application authentication evidence is supplied.

1. Priority8's50% becomes effective.
2. The object becomes permanently unavailable.
3. All priority slots are automatically cleared.
4. Priority16's55% becomes effective immediately.

**Correct option(s):** 1

- Option 1: It is then the highest-precedence remaining entry.
- Option 2: Releasing a command permits lower-priority/default arbitration.
- Option 3: A targeted release affects only the specified slot.
- Option 4: Priority8 still outranks16.

**GICSP-Q0363 · single · implementation**

How is a command at a specified priority normally relinquished in this model?

Synthetic BACnet commandable analog-output AO3 on device 1001: priority 4=70%, priority 8=50%, priority 16=40%, all other slots NULL; Relinquish_Default=30%. Effective Present_Value=70%. Automation writes55% at priority 16 and receives success. Maintenance wants to release only its priority 4 override. A second device 1002 also has AO3. BBMD distribution table includes an unapproved external peer. A COV subscription expires at 14:00 with no renewal; last source update is 13:58 but the dashboard shows GOOD at 14:20. Conventional BACnet/IP is used on the field side; no application authentication evidence is supplied.

1. Change Relinquish_Default to the old command value.
2. Delete the Device object.
3. Write zero to every priority slot.
4. Write NULL to Present_Value at that priority through the supported service.

**Correct option(s):** 4

- Option 1: That does not release an active higher-priority slot.
- Option 2: Device removal is not command relinquishment.
- Option 3: Zero is a commanded value, not NULL, and changes unrelated authority.
- Option 4: This releases that command without replacing other owners' entries.

**GICSP-Q0364 · single · diagnosis**

When does30% become effective in the supplied object?

Synthetic BACnet commandable analog-output AO3 on device 1001: priority 4=70%, priority 8=50%, priority 16=40%, all other slots NULL; Relinquish_Default=30%. Effective Present_Value=70%. Automation writes55% at priority 16 and receives success. Maintenance wants to release only its priority 4 override. A second device 1002 also has AO3. BBMD distribution table includes an unapproved external peer. A COV subscription expires at 14:00 with no renewal; last source update is 13:58 but the dashboard shows GOOD at 14:20. Conventional BACnet/IP is used on the field side; no application authentication evidence is supplied.

1. Whenever priority 16 receives a new value.
2. Whenever any write fails.
3. When the network port is UDP.
4. When all priority entries are NULL.

**Correct option(s):** 4

- Option 1: A non-NULL command supersedes the default.
- Option 2: An error does not necessarily clear existing commands.
- Option 3: Transport type does not choose the default.
- Option 4: Then Relinquish_Default supplies the value.

**GICSP-Q0365 · single · diagnosis**

Why must the point map include device identity as well as AO3?

Synthetic BACnet commandable analog-output AO3 on device 1001: priority 4=70%, priority 8=50%, priority 16=40%, all other slots NULL; Relinquish_Default=30%. Effective Present_Value=70%. Automation writes55% at priority 16 and receives success. Maintenance wants to release only its priority 4 override. A second device 1002 also has AO3. BBMD distribution table includes an unapproved external peer. A COV subscription expires at 14:00 with no renewal; last source update is 13:58 but the dashboard shows GOOD at 14:20. Conventional BACnet/IP is used on the field side; no application authentication evidence is supplied.

1. AO3 is always globally unique across every BACnet network.
2. The priority array identifies the building uniquely.
3. Friendly names cannot ever be changed.
4. Both device 1001 and 1002 contain an AO3 object.

**Correct option(s):** 4

- Option 1: The supplied devices demonstrate the collision.
- Option 2: Priority values are not global device identifiers.
- Option 3: Names may change or collide.
- Option 4: Object instance/type is scoped within its device context.

**GICSP-Q0366 · single · diagnosis**

What is the security concern with the BBMD table entry?

Synthetic BACnet commandable analog-output AO3 on device 1001: priority 4=70%, priority 8=50%, priority 16=40%, all other slots NULL; Relinquish_Default=30%. Effective Present_Value=70%. Automation writes55% at priority 16 and receives success. Maintenance wants to release only its priority 4 override. A second device 1002 also has AO3. BBMD distribution table includes an unapproved external peer. A COV subscription expires at 14:00 with no renewal; last source update is 13:58 but the dashboard shows GOOD at 14:20. Conventional BACnet/IP is used on the field side; no application authentication evidence is supplied.

1. It distributes relevant broadcasts to an unapproved peer.
2. It converts all BACnet messages into read-only requests.
3. It guarantees every application write is authenticated.
4. It removes the need for IP routing.

**Correct option(s):** 1

- Option 1: The configured boundary exceeds the authorised design.
- Option 2: Broadcast management is not operation authorisation.
- Option 3: BBMD forwarding does not establish that assurance.
- Option 4: BACnet/IP still depends on the underlying network.

**GICSP-Q0367 · single · mechanism**

What can an I-Am announcement establish by itself?

Synthetic BACnet commandable analog-output AO3 on device 1001: priority 4=70%, priority 8=50%, priority 16=40%, all other slots NULL; Relinquish_Default=30%. Effective Present_Value=70%. Automation writes55% at priority 16 and receives success. Maintenance wants to release only its priority 4 override. A second device 1002 also has AO3. BBMD distribution table includes an unapproved external peer. A COV subscription expires at 14:00 with no renewal; last source update is 13:58 but the dashboard shows GOOD at 14:20. Conventional BACnet/IP is used on the field side; no application authentication evidence is supplied.

1. The process values are currently accurate.
2. The sender is the approved physical controller with verified firmware.
3. All its properties are writable by this operator.
4. A device is claiming the advertised BACnet identity/capabilities in that observation.

**Correct option(s):** 4

- Option 1: Identity advertisement does not validate sensor state.
- Option 2: Additional inventory and trust evidence are needed.
- Option 3: Discovery does not grant permissions.
- Option 4: Traditional discovery is not cryptographic peer proof.

**GICSP-Q0368 · single · diagnosis**

How should the 14:20 display be interpreted after the unrenewed14:00 subscription expiry?

Synthetic BACnet commandable analog-output AO3 on device 1001: priority 4=70%, priority 8=50%, priority 16=40%, all other slots NULL; Relinquish_Default=30%. Effective Present_Value=70%. Automation writes55% at priority 16 and receives success. Maintenance wants to release only its priority 4 override. A second device 1002 also has AO3. BBMD distribution table includes an unapproved external peer. A COV subscription expires at 14:00 with no renewal; last source update is 13:58 but the dashboard shows GOOD at 14:20. Conventional BACnet/IP is used on the field side; no application authentication evidence is supplied.

1. The13:58 value is definitely still current.
2. COV guarantees permanent delivery after one subscription.
3. The controller necessarily stopped at 14:00.
4. Freshness is unverified; absence of notifications is not proof of an unchanged value.

**Correct option(s):** 4

- Option 1: No continuing observation supports that claim.
- Option 2: The supplied lifetime requires renewal.
- Option 3: Subscription expiry does not imply process stop.
- Option 4: The collection mechanism has expired.

**GICSP-Q0369 · multi · design**

Which tests are relevant to commandable-object acceptance? Select all that apply.

Synthetic BACnet commandable analog-output AO3 on device 1001: priority 4=70%, priority 8=50%, priority 16=40%, all other slots NULL; Relinquish_Default=30%. Effective Present_Value=70%. Automation writes55% at priority 16 and receives success. Maintenance wants to release only its priority 4 override. A second device 1002 also has AO3. BBMD distribution table includes an unapproved external peer. A COV subscription expires at 14:00 with no renewal; last source update is 13:58 but the dashboard shows GOOD at 14:20. Conventional BACnet/IP is used on the field side; no application authentication evidence is supplied.

1. Targeted relinquishment and the resulting fallback value.
2. Only pinging the IP router.
3. Lower-priority writes under an active higher-priority command.
4. Only checking that every object has a friendly name.

**Correct option(s):** 1, 3

- Option 1: Release can cause a consequential transition.
- Option 2: Network reachability does not test command arbitration.
- Option 3: This verifies stored versus effective value semantics.
- Option 4: Naming does not establish authority or priority behaviour.

**GICSP-Q0370 · single · mechanism**

What does adding BACnet Secure Connect on one upstream segment not establish?

Synthetic BACnet commandable analog-output AO3 on device 1001: priority 4=70%, priority 8=50%, priority 16=40%, all other slots NULL; Relinquish_Default=30%. Effective Present_Value=70%. Automation writes55% at priority 16 and receives success. Maintenance wants to release only its priority 4 override. A second device 1002 also has AO3. BBMD distribution table includes an unapproved external peer. A COV subscription expires at 14:00 with no renewal; last source update is 13:58 but the dashboard shows GOOD at 14:20. Conventional BACnet/IP is used on the field side; no application authentication evidence is supplied.

1. Security of an unprotected legacy field segment and its management paths.
2. That interoperability testing remains necessary.
3. That certificate lifecycle must be considered on the secured segment.
4. That transport design differs from conventional UDP BACnet/IP.

**Correct option(s):** 1

- Option 1: Protection scope must cover the complete route.
- Option 2: It remains necessary after transport changes.
- Option 3: It still must be considered.
- Option 4: The architectures do differ.

#### Recall

**How does BACnet priority arbitration work?**

The lowest-numbered non-NULL command wins; releasing one slot reveals the next active command, then the default if none remain.

**What does a BBMD not do?**

It does not by itself authenticate application users, restrict writes or prove device identity; it manages broadcast distribution.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [BACnet Committee: standard and technical resources](https://bacnet.org/)
- [BACnet stack implementer explanation of objects, services and MS/TP](https://sourceforge.net/p/bacnet/support-requests/68/)

### GICSP-L038 — DNP3 and IEC 61850 evidence at the protection interface

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L037

Industrial protocols express different information models and communication patterns. DNP3 commonly connects a controlling station with outstations that expose typed points and events. Object groups and variations specify the kind and representation of data; point index, flags, timestamp and device profile give the value its meaning. A current static value and a time-stamped event answer different questions. A communication outage may be followed by buffered events, so arrival order is not necessarily process-event order. Event-buffer overflow can create an evidence gap that a later current-value poll cannot reconstruct.

An outstation may send unsolicited responses when configured to report changes without waiting for a particular poll. Unsolicited does not mean unauthorised or malicious. Interpret the session, device configuration, confirmation requirements and source identity. A repeated event can be a retransmission awaiting confirmation rather than a second physical transition. Preserve event sequence and timestamps while distinguishing protocol delivery from the occurrence of the underlying event.

DNP3 control methods can include select-before-operate and direct operate. In a select-before-operate arrangement, selection checks the proposed control before a corresponding operation within the supported conditions and timeout. This reduces some accidental or mismatched operations; it is not automatically cryptographic authentication. Inspect returned status and the device profile. Even a successful operation response must be correlated with output feedback and process state. Secure-authentication capabilities and deployed versions are separate matters from whether a conventional select/operate exchange is present.

IEC 61850 provides structured data models and services rather than one interchangeable packet type. MMS-based client/server exchanges and reports commonly carry supervisory information. Conventional GOOSE uses Ethernet publisher/subscriber multicast for configured datasets, while Sampled Values serves another purpose. Do not assume a TCP-only sensor sees conventional layer-two GOOSE. Routable variants and secured profiles require their own explicit architecture; the lesson's fixture uses conventional Ethernet GOOSE only.

GOOSE repeatedly publishes state so subscribers can receive the current dataset despite occasional packet loss. In the simplified normal sequence here, a dataset change increments the state number and starts a new sequence number progression; repeated transmissions of the same state increment the sequence number. The advertised time-allowed-to-live supports subscriber supervision. A sequence anomaly or timeout warrants investigation, but may reflect loss, restart, capture position, configuration change or malicious activity. Dataset reference, configuration revision, source, quality, test/simulation indicators and timing all affect interpretation. Never infer a physical trip solely from a multicast frame.

The engineering boundary is critical. An EPMS integration may read protection status and event records while the protection specialist owns setting coordination, trip logic and safe test arrangements. Network security can preserve access boundaries, multicast paths, time and evidence without authorising live protection operations. Test protocol parsers on supplied captures, compare device configuration with the approved SCL/project baseline, and correlate communication findings with independent device/process records. Vendor manuals describe particular products and revisions; do not generalise one product's timing or configuration limits to every implementation.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic protocol evidence. DNP3 outstation O buffers events: e1 source 10:00:01 statusOPEN, e2 source 10:00:03 statusCLOSED; both arrive10:05:00 after an outage. An overflow flag is set. SELECT output5 CLOSE succeeds at 12:00:00; the supplied profile requires OPERATE within 2.0 s, but matching OPERATE arrives12:00:03 and returns TIMEOUT. No output feedback is supplied.
Conventional Ethernet GOOSE capture for one publisher/dataset: stNum 8/sqNum 10 stateFALSE; stNum 8/sqNum 11 stateFALSE; stNum 9/sqNum 0 stateTRUE; stNum 9/sqNum 1 stateTRUE. Last frame's timeAllowedToLive=1000 ms; no later frame is observed for 1500 ms at a capture point confirmed healthy. Dataset configuration revision is 2, while the subscriber's approved configuration expects1. Frames are synthetic and no live protection action occurred.

**Reasoning:** The two DNP events retain source-time order, but overflow means the complete event history is not established. OPERATE exceeded the supplied two-second window and returned timeout; no successful close is shown. GOOSE records show one state change followed by a repeat, then a supervision gap exceeding the advertised lifetime at the observed point. Revision mismatch can prevent correct subscription/interpretation and needs configuration review. Neither the TRUE dataset bit nor the select success proves a physical breaker action.

#### Guided practice

Separate observed communication facts from physical-state conclusions.

**Hint:** Use response status, source time, sequence semantics and missing feedback.

**Worked solution:** Observed: two buffered DNP events, overflow, timed-out operation, one GOOSE dataset change and later observed timeout/revision mismatch. Not established: complete historical transitions, a successful CLOSE, actor identity or the physical meaning/outcome of TRUE without the approved dataset mapping and device feedback.

#### Independent task

Environment: analytical

Write an evidence interpretation and specialist handoff report.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L038.json

**Evidence to produce**

- Event chronology with overflow limitation
- Select/operate timing assessment
- GOOSE state/retransmission table
- Configuration and physical-feedback requests

**Acceptance criteria**

- Unsolicited/buffered delivery is not automatically labelled malicious.
- A timed-out operate is not called successful.
- Network analysis does not claim authority to change protection settings.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0371 · single · diagnosis**

What ordering is supported for e1 and e2 by their supplied source timestamps?

Synthetic protocol evidence. DNP3 outstation O buffers events: e1 source 10:00:01 statusOPEN, e2 source 10:00:03 statusCLOSED; both arrive10:05:00 after an outage. An overflow flag is set. SELECT output5 CLOSE succeeds at 12:00:00; the supplied profile requires OPERATE within 2.0 s, but matching OPERATE arrives12:00:03 and returns TIMEOUT. No output feedback is supplied.
Conventional Ethernet GOOSE capture for one publisher/dataset: stNum 8/sqNum 10 stateFALSE; stNum 8/sqNum 11 stateFALSE; stNum 9/sqNum 0 stateTRUE; stNum 9/sqNum 1 stateTRUE. Last frame's timeAllowedToLive=1000 ms; no later frame is observed for 1500 ms at a capture point confirmed healthy. Dataset configuration revision is 2, while the subscriber's approved configuration expects1. Frames are synthetic and no live protection action occurred.

1. OPEN and CLOSED both occurred at 10:05:00.
2. The source timestamps show CLOSED before OPEN because CLOSED arrived in the same batch.
3. OPEN at 10:00:01 precedes CLOSED at 10:00:03.
4. CLOSED at 10:00:01 precedes OPEN at 10:00:03.

**Correct option(s):** 3

- Option 1: 10:05 is their common arrival time after buffering, not their reported source event time.
- Option 2: Batch delivery does not reverse the explicit source-time order.
- Option 3: Their common arrival time does not erase source-time order.
- Option 4: That reverses the states attached to the supplied source timestamps.

**GICSP-Q0372 · single · diagnosis**

What does the overflow flag prevent claiming?

Synthetic protocol evidence. DNP3 outstation O buffers events: e1 source 10:00:01 statusOPEN, e2 source 10:00:03 statusCLOSED; both arrive10:05:00 after an outage. An overflow flag is set. SELECT output5 CLOSE succeeds at 12:00:00; the supplied profile requires OPERATE within 2.0 s, but matching OPERATE arrives12:00:03 and returns TIMEOUT. No output feedback is supplied.
Conventional Ethernet GOOSE capture for one publisher/dataset: stNum 8/sqNum 10 stateFALSE; stNum 8/sqNum 11 stateFALSE; stNum 9/sqNum 0 stateTRUE; stNum 9/sqNum 1 stateTRUE. Last frame's timeAllowedToLive=1000 ms; no later frame is observed for 1500 ms at a capture point confirmed healthy. Dataset configuration revision is 2, while the subscriber's approved configuration expects1. Frames are synthetic and no live protection action occurred.

1. That e1 and e2 were received.
2. That the current connection can carry data.
3. That the outstation has any static points.
4. A complete event history through the outage.

**Correct option(s):** 4

- Option 1: The records are explicitly present.
- Option 2: Data arrived after the outage.
- Option 3: Overflow does not establish point-model absence.
- Option 4: Some buffered events may have been lost.

**GICSP-Q0373 · single · calculation**

Why did the supplied OPERATE return TIMEOUT?

Synthetic protocol evidence. DNP3 outstation O buffers events: e1 source 10:00:01 statusOPEN, e2 source 10:00:03 statusCLOSED; both arrive10:05:00 after an outage. An overflow flag is set. SELECT output5 CLOSE succeeds at 12:00:00; the supplied profile requires OPERATE within 2.0 s, but matching OPERATE arrives12:00:03 and returns TIMEOUT. No output feedback is supplied.
Conventional Ethernet GOOSE capture for one publisher/dataset: stNum 8/sqNum 10 stateFALSE; stNum 8/sqNum 11 stateFALSE; stNum 9/sqNum 0 stateTRUE; stNum 9/sqNum 1 stateTRUE. Last frame's timeAllowedToLive=1000 ms; no later frame is observed for 1500 ms at a capture point confirmed healthy. Dataset configuration revision is 2, while the subscriber's approved configuration expects1. Frames are synthetic and no live protection action occurred.

1. The output index changed from 5 to 6.
2. The command fails because every DNP3 point uses a one-millisecond selection timeout.
3. The successful SELECT means CLOSE already occurred, so the late OPERATE is irrelevant.
4. It arrived3 s after SELECT, exceeding the profile's2 s window.

**Correct option(s):** 4

- Option 1: The supplied operation matches output5.
- Option 2: The supplied profile uses two seconds; no universal one-millisecond rule is asserted.
- Option 3: The configured select-before-operate exchange requires the matching timely operate; physical feedback is separate.
- Option 4: The matching operation missed the stated timing condition.

**GICSP-Q0374 · single · mechanism**

What security property does select-before-operate not inherently provide?

Synthetic protocol evidence. DNP3 outstation O buffers events: e1 source 10:00:01 statusOPEN, e2 source 10:00:03 statusCLOSED; both arrive10:05:00 after an outage. An overflow flag is set. SELECT output5 CLOSE succeeds at 12:00:00; the supplied profile requires OPERATE within 2.0 s, but matching OPERATE arrives12:00:03 and returns TIMEOUT. No output feedback is supplied.
Conventional Ethernet GOOSE capture for one publisher/dataset: stNum 8/sqNum 10 stateFALSE; stNum 8/sqNum 11 stateFALSE; stNum 9/sqNum 0 stateTRUE; stNum 9/sqNum 1 stateTRUE. Last frame's timeAllowedToLive=1000 ms; no later frame is observed for 1500 ms at a capture point confirmed healthy. Dataset configuration revision is 2, while the subscriber's approved configuration expects1. Frames are synthetic and no live protection action occurred.

1. A possibility of rejecting an expired operation.
2. A returned application status.
3. A defined relationship between selection and operation.
4. Cryptographic authentication of the human or device issuer.

**Correct option(s):** 4

- Option 1: The case demonstrates that rejection.
- Option 2: The supplied exchange includes status results.
- Option 3: That is part of the described control method.
- Option 4: Sequencing checks are distinct from secure authentication.

**GICSP-Q0375 · single · calculation**

How many dataset state changes are shown in the four GOOSE records?

Synthetic protocol evidence. DNP3 outstation O buffers events: e1 source 10:00:01 statusOPEN, e2 source 10:00:03 statusCLOSED; both arrive10:05:00 after an outage. An overflow flag is set. SELECT output5 CLOSE succeeds at 12:00:00; the supplied profile requires OPERATE within 2.0 s, but matching OPERATE arrives12:00:03 and returns TIMEOUT. No output feedback is supplied.
Conventional Ethernet GOOSE capture for one publisher/dataset: stNum 8/sqNum 10 stateFALSE; stNum 8/sqNum 11 stateFALSE; stNum 9/sqNum 0 stateTRUE; stNum 9/sqNum 1 stateTRUE. Last frame's timeAllowedToLive=1000 ms; no later frame is observed for 1500 ms at a capture point confirmed healthy. Dataset configuration revision is 2, while the subscriber's approved configuration expects1. Frames are synthetic and no live protection action occurred.

1. Zero because the Ethernet destination is multicast.
2. One.
3. Two because sqNum increases twice.
4. Four.

**Correct option(s):** 2

- Option 1: Multicast can carry a genuine dataset change.
- Option 2: stNum changes from 8 to 9 and the value changes once fromFALSE toTRUE.
- Option 3: Sequence increments can represent retransmissions of unchanged state.
- Option 4: Repeated publications are not four distinct state transitions.

**GICSP-Q0376 · single · mechanism**

What does stNum 9/sqNum 1 following stNum 9/sqNum 0 normally represent in the supplied model?

Synthetic protocol evidence. DNP3 outstation O buffers events: e1 source 10:00:01 statusOPEN, e2 source 10:00:03 statusCLOSED; both arrive10:05:00 after an outage. An overflow flag is set. SELECT output5 CLOSE succeeds at 12:00:00; the supplied profile requires OPERATE within 2.0 s, but matching OPERATE arrives12:00:03 and returns TIMEOUT. No output feedback is supplied.
Conventional Ethernet GOOSE capture for one publisher/dataset: stNum 8/sqNum 10 stateFALSE; stNum 8/sqNum 11 stateFALSE; stNum 9/sqNum 0 stateTRUE; stNum 9/sqNum 1 stateTRUE. Last frame's timeAllowedToLive=1000 ms; no later frame is observed for 1500 ms at a capture point confirmed healthy. Dataset configuration revision is 2, while the subscriber's approved configuration expects1. Frames are synthetic and no live protection action occurred.

1. A new dataset configuration revision.
2. A repeat publication of the same state.
3. A TCP retransmission flag.
4. A second independent physical trip.

**Correct option(s):** 2

- Option 1: confRev is a different field.
- Option 2: State number is unchanged while sequence advances.
- Option 3: These are GOOSE application fields in conventional Ethernet frames.
- Option 4: The dataset remains the same and physical meaning is not supplied.

**GICSP-Q0377 · single · diagnosis**

What is established by1500 ms without a frame after a1000 ms lifetime at a healthy capture point?

Synthetic protocol evidence. DNP3 outstation O buffers events: e1 source 10:00:01 statusOPEN, e2 source 10:00:03 statusCLOSED; both arrive10:05:00 after an outage. An overflow flag is set. SELECT output5 CLOSE succeeds at 12:00:00; the supplied profile requires OPERATE within 2.0 s, but matching OPERATE arrives12:00:03 and returns TIMEOUT. No output feedback is supplied.
Conventional Ethernet GOOSE capture for one publisher/dataset: stNum 8/sqNum 10 stateFALSE; stNum 8/sqNum 11 stateFALSE; stNum 9/sqNum 0 stateTRUE; stNum 9/sqNum 1 stateTRUE. Last frame's timeAllowedToLive=1000 ms; no later frame is observed for 1500 ms at a capture point confirmed healthy. Dataset configuration revision is 2, while the subscriber's approved configuration expects1. Frames are synthetic and no live protection action occurred.

1. The exact attacker identity.
2. The observed stream exceeded the advertised supervision interval.
3. A guaranteed physical breaker trip.
4. A normal TCP session close.

**Correct option(s):** 2

- Option 1: Timeout gives no attribution.
- Option 2: This supports a communication-availability finding at that point.
- Option 3: Subscriber and process response need separate evidence.
- Option 4: The fixture is conventional Ethernet GOOSE, not TCP.

**GICSP-Q0378 · single · diagnosis**

Why might a TCP-only monitoring filter miss the supplied GOOSE traffic?

Synthetic protocol evidence. DNP3 outstation O buffers events: e1 source 10:00:01 statusOPEN, e2 source 10:00:03 statusCLOSED; both arrive10:05:00 after an outage. An overflow flag is set. SELECT output5 CLOSE succeeds at 12:00:00; the supplied profile requires OPERATE within 2.0 s, but matching OPERATE arrives12:00:03 and returns TIMEOUT. No output feedback is supplied.
Conventional Ethernet GOOSE capture for one publisher/dataset: stNum 8/sqNum 10 stateFALSE; stNum 8/sqNum 11 stateFALSE; stNum 9/sqNum 0 stateTRUE; stNum 9/sqNum 1 stateTRUE. Last frame's timeAllowedToLive=1000 ms; no later frame is observed for 1500 ms at a capture point confirmed healthy. Dataset configuration revision is 2, while the subscriber's approved configuration expects1. Frames are synthetic and no live protection action occurred.

1. The GOOSE frames should appear in a TCP 502 filter because they carry industrial data.
2. Multicast frames are inherently unavailable to a correctly placed capture sensor.
3. The sequence field makes the payload encrypted and therefore invisible to the filter.
4. Conventional GOOSE is carried directly over Ethernet rather than TCP.

**Correct option(s):** 4

- Option 1: This conventional profile is Ethernet-layer traffic, not Modbus/TCP.
- Option 2: Suitable Ethernet visibility can capture them; the TCP-only filter is the limitation.
- Option 3: Sequence numbering is not encryption; the transport/filter mismatch explains the omission.
- Option 4: The filter excludes the relevant layer-two frames.

**GICSP-Q0379 · multi · design**

Which findings need review before trusting the subscriber's interpretation? Select all that apply.

Synthetic protocol evidence. DNP3 outstation O buffers events: e1 source 10:00:01 statusOPEN, e2 source 10:00:03 statusCLOSED; both arrive10:05:00 after an outage. An overflow flag is set. SELECT output5 CLOSE succeeds at 12:00:00; the supplied profile requires OPERATE within 2.0 s, but matching OPERATE arrives12:00:03 and returns TIMEOUT. No output feedback is supplied.
Conventional Ethernet GOOSE capture for one publisher/dataset: stNum 8/sqNum 10 stateFALSE; stNum 8/sqNum 11 stateFALSE; stNum 9/sqNum 0 stateTRUE; stNum 9/sqNum 1 stateTRUE. Last frame's timeAllowedToLive=1000 ms; no later frame is observed for 1500 ms at a capture point confirmed healthy. Dataset configuration revision is 2, while the subscriber's approved configuration expects1. Frames are synthetic and no live protection action occurred.

1. Approved dataset meaning and quality/test state.
2. Publisher configuration revision2 versus expected1.
3. Only the fact that two frames have equal values.
4. Only the presence of a normal retransmission with unchanged stNum and increasing sqNum.

**Correct option(s):** 1, 2

- Option 1: A TRUE bit has no safe physical interpretation without context.
- Option 2: Dataset configuration mismatch can invalidate mapping assumptions.
- Option 3: Repeated state is normal in the supplied model.
- Option 4: That pattern is expected in the supplied model and does not by itself identify a configuration or semantic mismatch.

**GICSP-Q0380 · single · implementation**

What would support a claim that output5 physically closed?

Synthetic protocol evidence. DNP3 outstation O buffers events: e1 source 10:00:01 statusOPEN, e2 source 10:00:03 statusCLOSED; both arrive10:05:00 after an outage. An overflow flag is set. SELECT output5 CLOSE succeeds at 12:00:00; the supplied profile requires OPERATE within 2.0 s, but matching OPERATE arrives12:00:03 and returns TIMEOUT. No output feedback is supplied.
Conventional Ethernet GOOSE capture for one publisher/dataset: stNum 8/sqNum 10 stateFALSE; stNum 8/sqNum 11 stateFALSE; stNum 9/sqNum 0 stateTRUE; stNum 9/sqNum 1 stateTRUE. Last frame's timeAllowedToLive=1000 ms; no later frame is observed for 1500 ms at a capture point confirmed healthy. Dataset configuration revision is 2, while the subscriber's approved configuration expects1. Frames are synthetic and no live protection action occurred.

1. The timed-out OPERATE response.
2. Any TRUE value from any GOOSE dataset.
3. Appropriate device feedback and process evidence correlated with an accepted authorised operation.
4. The SELECT response alone.

**Correct option(s):** 3

- Option 1: It does not demonstrate successful execution.
- Option 2: Meaning and association must be established.
- Option 3: Protocol selection or a dataset bit alone is insufficient.
- Option 4: It only confirms the selection step.

#### Recall

**Does unsolicited DNP3 mean malicious?**

No. It can be an authorised event-reporting mode; interpret configuration, identity, timing and confirmation context.

**GOOSE state number versus sequence number?**

State number identifies dataset changes in the normal model; sequence progression supports repeated publication of the same state.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [DNP Users Group: public DNP3 protocol primer](https://www.dnp.org/Portals/0/AboutUs/DNP3%20Primer%20Rev%20A.pdf)
- [ABB 615 series IEC 61850 Engineering Guide, public historical implementation reference](https://library.e.abb.com/public/63c98d28e525f279c1257b2f0054c237/RE_615_IEC61850eng_756475_ENg.pdf)

### GICSP-L039 — OPC UA and MQTT: trust, quality and message lifecycle

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L038

OPC UA provides a structured information model and services for reading, writing, methods and subscriptions. A NodeId identifies a node within a namespace context; a numeric namespace index is a session/server mapping aid, while the namespace URI carries the stable namespace identity. If a server's NamespaceArray changes after restart, blindly reusing an old numeric index can target a different namespace. Resolve and verify the intended URI and node identity rather than treating an exported string as universally stable.

OPC UA security has several layers. A secure channel protects communication according to the selected security policy and message mode, application certificates establish application trust, and a session's user identity is subject to server authorisation. Trusting a client certificate does not mean every user in that application may write every node. Sign and SignAndEncrypt provide different confidentiality properties. An endpoint offering None needs deliberate assessment; clients should not silently fall back to it when the approved secure endpoint fails. Certificate expiry, trust-list changes and renewal are operational dependencies.

A DataValue can include value, status and timestamps. Preserve the status code and source timestamp through gateways and displays. A subscription publishing interval is not necessarily the same as the monitored item's sampling interval, and queue size/discard policy affect what a slow client receives. A queue overflow or lost sequence can mean intermediate changes were missed even if the newest value arrives. Reconnect and republish features have finite retention and implementation constraints; they are not an unlimited historian.

MQTT uses publishers, a broker and subscribers connected by topic names and filters. The broker should authorise publish and subscribe separately for each identity. A client allowed to subscribe to telemetry should not automatically publish command topics. Wildcard filters can broaden access: a multi-level wildcard can include unexpected subtopics if naming changes. Broker authentication identifies the connecting client under the configured mechanism; the payload may need additional provenance and application validation when it is forwarded through other systems.

MQTT delivery quality describes message delivery semantics within the protocol exchange, not exactly-once physical actuation. QoS0 allows loss; QoS1 can produce duplicates; QoS2 uses an exchange to provide its defined exactly-once delivery behaviour. Application retries, multiple bridges, process restarts and command execution still need idempotency and explicit outcome handling. A retained message can be delivered to a new subscriber long after its original publication. Include source time, quality and appropriate expiry so an old retained command or measurement is not treated as fresh merely because it arrived now.

Design reconnect behaviour as part of the control interface. Session state, retained data, message expiry, Last Will and subscription renewal can interact with an outage. A Last Will indicates the broker's connection-lifecycle observation under its configured timing; it does not directly prove that the physical device stopped. Test duplicate commands, stale retained values, certificate failure, changed namespace mapping, queue overflow and broker recovery in isolated fixtures. Keep command authority, message freshness and process feedback explicit even when the transport is authenticated and encrypted.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic integration: OPC UA client stores NodeId ns=2;i=500 for URI urn:site:plant. After server restart NamespaceArray[2]=urn:site:diagnostics and plant moves to index 3. Client certificate is trusted, but user viewer has read-only role. DataValue=24.0, StatusCode=BadSensorFailure, source time11:00; dashboard at 11:20 drops status and calls it current. MQTT broker grants sensorA publish site/# and subscribe site/#. New command subscriber receives retained payload {command_id:17, action:"start", source_time:"10:00"} at 12:00. Application executes every QoS1 delivery; command17 is delivered twice. OPC subscription queue reports overflow.

**Reasoning:** Resolve plant URI to index 3 before using i500 and verify the node semantics. Application certificate trust does not override viewer's read-only role. BadSensorFailure and old source time must survive display mapping. Narrow sensorA's publish/subscribe authority to its required topics. The retained command is old, and duplicate QoS1 delivery must not cause repeated non-idempotent actuation; require freshness/authority and command-outcome handling. Queue overflow means intermediate OPC changes may be absent.

#### Guided practice

Specify a safe analytical acceptance rule for command17 without sending it anywhere.

**Hint:** Check authority, intended target, age/expiry and idempotent command identity before physical execution would be considered.

**Worked solution:** The offline evaluator should reject the two-hour-old retained command under a supplied freshness limit and record duplicate command_id17 without a second action. Actual actuation still requires the approved process permission and feedback path.

#### Independent task

Environment: analytical

Create an interface schema and reconnect test matrix.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L039.json

**Evidence to produce**

- Namespace URI resolution rule
- OPC status/time propagation
- MQTT topic permissions
- Duplicate/retained command handling
- Queue-overflow indication

**Acceptance criteria**

- Certificate trust and user write authority remain separate.
- QoS is not claimed to guarantee exactly-once physical action.
- Bad and stale data is not presented as a valid current reading.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0381 · single · diagnosis**

Which NodeId mapping should the client use for the intended plant namespace after restart?

Synthetic integration: OPC UA client stores NodeId ns=2;i=500 for URI urn:site:plant. After server restart NamespaceArray[2]=urn:site:diagnostics and plant moves to index 3. Client certificate is trusted, but user viewer has read-only role. DataValue=24.0, StatusCode=BadSensorFailure, source time11:00; dashboard at 11:20 drops status and calls it current. MQTT broker grants sensorA publish site/# and subscribe site/#. New command subscriber receives retained payload {command_id:17, action:"start", source_time:"10:00"} at 12:00. Application executes every QoS1 delivery; command17 is delivered twice. OPC subscription queue reports overflow.

1. Resolve urn:site:plant to index 3, then verify node i500 in that namespace.
2. Choose index 2 because it appeared in the approved pre-restart configuration.
3. Continue ns=2;i=500 because the node identifier is numeric and therefore server-global.
4. Change only i=500 while retaining namespace index 2.

**Correct option(s):** 1

- Option 1: The old numeric index now names a different namespace.
- Option 2: The client must resolve the intended URI in the current NamespaceArray, where plant is index 3.
- Option 3: The namespace index is part of the identity and now maps to diagnostics.
- Option 4: The supplied change concerns the namespace URI’s index, not the identifier within the plant namespace.

**GICSP-Q0382 · single · diagnosis**

Does the trusted OPC application certificate grant viewer write authority?

Synthetic integration: OPC UA client stores NodeId ns=2;i=500 for URI urn:site:plant. After server restart NamespaceArray[2]=urn:site:diagnostics and plant moves to index 3. Client certificate is trusted, but user viewer has read-only role. DataValue=24.0, StatusCode=BadSensorFailure, source time11:00; dashboard at 11:20 drops status and calls it current. MQTT broker grants sensorA publish site/# and subscribe site/#. New command subscriber receives retained payload {command_id:17, action:"start", source_time:"10:00"} at 12:00. Application executes every QoS1 delivery; command17 is delivered twice. OPC subscription queue reports overflow.

1. Viewer may write when the target value is numeric rather than textual.
2. Using a subscription grants write access to the subscribed node.
3. No; user/session authorisation still applies.
4. The trusted application certificate promotes viewer to an administrator automatically.

**Correct option(s):** 3

- Option 1: Data type does not override the supplied read-only role.
- Option 2: Subscription delivery does not confer command authority.
- Option 3: Application trust and user permissions are separate layers.
- Option 4: Application trust and user-role authorisation are separate.

**GICSP-Q0383 · single · diagnosis**

What is wrong with displaying24.0 as current and good?

Synthetic integration: OPC UA client stores NodeId ns=2;i=500 for URI urn:site:plant. After server restart NamespaceArray[2]=urn:site:diagnostics and plant moves to index 3. Client certificate is trusted, but user viewer has read-only role. DataValue=24.0, StatusCode=BadSensorFailure, source time11:00; dashboard at 11:20 drops status and calls it current. MQTT broker grants sensorA publish site/# and subscribe site/#. New command subscriber receives retained payload {command_id:17, action:"start", source_time:"10:00"} at 12:00. Application executes every QoS1 delivery; command17 is delivered twice. OPC subscription queue reports overflow.

1. A dashboard cannot display uncertain values in any form.
2. BadSensorFailure and the old source timestamp were discarded.
3. OPC UA never supports source timestamps.
4. Every24.0 value is invalid by definition.

**Correct option(s):** 2

- Option 1: It can show them clearly with quality and age context.
- Option 2: The numeric payload does not override quality and age.
- Option 3: The supplied DataValue includes one.
- Option 4: No universal numeric prohibition exists.

**GICSP-Q0384 · single · diagnosis**

Which MQTT permission is broader than sensorA's presumed telemetry-publisher need?

Synthetic integration: OPC UA client stores NodeId ns=2;i=500 for URI urn:site:plant. After server restart NamespaceArray[2]=urn:site:diagnostics and plant moves to index 3. Client certificate is trusted, but user viewer has read-only role. DataValue=24.0, StatusCode=BadSensorFailure, source time11:00; dashboard at 11:20 drops status and calls it current. MQTT broker grants sensorA publish site/# and subscribe site/#. New command subscriber receives retained payload {command_id:17, action:"start", source_time:"10:00"} at 12:00. Application executes every QoS1 delivery; command17 is delivered twice. OPC subscription queue reports overflow.

1. Publish site/#, including command subtopics.
2. A narrowly scoped publish permission for its own telemetry.
3. A named broker identity.
4. A separate explicit deny for command topics.

**Correct option(s):** 1

- Option 1: The wildcard permits more than the sensor's specific telemetry.
- Option 2: That would match the required function.
- Option 3: Identity supports attribution but still needs scoped permissions.
- Option 4: That can constrain unintended authority.

**GICSP-Q0385 · single · diagnosis**

What is the risk of the retained command arriving at 12:00?

Synthetic integration: OPC UA client stores NodeId ns=2;i=500 for URI urn:site:plant. After server restart NamespaceArray[2]=urn:site:diagnostics and plant moves to index 3. Client certificate is trusted, but user viewer has read-only role. DataValue=24.0, StatusCode=BadSensorFailure, source time11:00; dashboard at 11:20 drops status and calls it current. MQTT broker grants sensorA publish site/# and subscribe site/#. New command subscriber receives retained payload {command_id:17, action:"start", source_time:"10:00"} at 12:00. Application executes every QoS1 delivery; command17 is delivered twice. OPC subscription queue reports overflow.

1. Arrival time can make an old10:00 command look newly issued.
2. The broker necessarily executes the physical start itself.
3. A retained payload cannot carry source time or command identity.
4. The retained message is necessarily forged because it was stored at the broker.

**Correct option(s):** 1

- Option 1: Retention preserves a message for later subscribers.
- Option 2: The application performs the supplied action.
- Option 3: The supplied payload carries both; the application must use them appropriately.
- Option 4: Retained delivery can be legitimate; the risk is stale command execution and missing context.

**GICSP-Q0386 · single · implementation**

What should the application do with duplicate QoS1 command deliveries?

Synthetic integration: OPC UA client stores NodeId ns=2;i=500 for URI urn:site:plant. After server restart NamespaceArray[2]=urn:site:diagnostics and plant moves to index 3. Client certificate is trusted, but user viewer has read-only role. DataValue=24.0, StatusCode=BadSensorFailure, source time11:00; dashboard at 11:20 drops status and calls it current. MQTT broker grants sensorA publish site/# and subscribe site/#. New command subscriber receives retained payload {command_id:17, action:"start", source_time:"10:00"} at 12:00. Application executes every QoS1 delivery; command17 is delivered twice. OPC subscription queue reports overflow.

1. Assume QoS1 guarantees one physical execution.
2. Use command identity and defined idempotent/outcome handling to avoid unintended repeated action.
3. Delete all command logging to reduce duplication.
4. Change the duplicate's command_id and execute it as new.

**Correct option(s):** 2

- Option 1: Protocol delivery semantics do not provide that guarantee.
- Option 2: QoS1 permits duplicates.
- Option 3: Logging supports, rather than prevents, correct correlation.
- Option 4: That defeats deduplication and changes intent.

**GICSP-Q0387 · single · diagnosis**

What does OPC subscription queue overflow imply?

Synthetic integration: OPC UA client stores NodeId ns=2;i=500 for URI urn:site:plant. After server restart NamespaceArray[2]=urn:site:diagnostics and plant moves to index 3. Client certificate is trusted, but user viewer has read-only role. DataValue=24.0, StatusCode=BadSensorFailure, source time11:00; dashboard at 11:20 drops status and calls it current. MQTT broker grants sensorA publish site/# and subscribe site/#. New command subscriber receives retained payload {command_id:17, action:"start", source_time:"10:00"} at 12:00. Application executes every QoS1 delivery; command17 is delivered twice. OPC subscription queue reports overflow.

1. The server has stored an unlimited history.
2. The client's user role becomes administrator.
3. The latest value is necessarily malicious.
4. Intermediate changes may have been missed even if the latest value is available.

**Correct option(s):** 4

- Option 1: A subscription queue is finite and not an unlimited historian.
- Option 2: Queue state does not alter authorisation.
- Option 3: Overflow does not establish intent or content falsity.
- Option 4: Finite queues can lose history.

**GICSP-Q0388 · single · mechanism**

Which distinction between OPC message modes is relevant?

Synthetic integration: OPC UA client stores NodeId ns=2;i=500 for URI urn:site:plant. After server restart NamespaceArray[2]=urn:site:diagnostics and plant moves to index 3. Client certificate is trusted, but user viewer has read-only role. DataValue=24.0, StatusCode=BadSensorFailure, source time11:00; dashboard at 11:20 drops status and calls it current. MQTT broker grants sensorA publish site/# and subscribe site/#. New command subscriber receives retained payload {command_id:17, action:"start", source_time:"10:00"} at 12:00. Application executes every QoS1 delivery; command17 is delivered twice. OPC subscription queue reports overflow.

1. Encryption automatically validates the physical sensor.
2. Signing provides integrity/authenticity properties without necessarily providing payload confidentiality; SignAndEncrypt adds encryption.
3. None is always as protective as SignAndEncrypt on any network.
4. Sign and SignAndEncrypt are identical names for the same mode.

**Correct option(s):** 2

- Option 1: Transport protection does not prove source measurement accuracy.
- Option 2: Mode selection affects protection scope.
- Option 3: It omits those channel protections.
- Option 4: Their confidentiality behaviour differs.

**GICSP-Q0389 · single · mechanism**

What does an MQTT Last Will most directly reflect?

Synthetic integration: OPC UA client stores NodeId ns=2;i=500 for URI urn:site:plant. After server restart NamespaceArray[2]=urn:site:diagnostics and plant moves to index 3. Client certificate is trusted, but user viewer has read-only role. DataValue=24.0, StatusCode=BadSensorFailure, source time11:00; dashboard at 11:20 drops status and calls it current. MQTT broker grants sensorA publish site/# and subscribe site/#. New command subscriber receives retained payload {command_id:17, action:"start", source_time:"10:00"} at 12:00. Application executes every QoS1 delivery; command17 is delivered twice. OPC subscription queue reports overflow.

1. Proof that every retained message is fresh.
2. Successful execution of the last command.
3. The broker's configured connection-lifecycle condition.
4. Guaranteed mechanical stoppage at the exact disconnect instant.

**Correct option(s):** 3

- Option 1: Retention/freshness are separate concerns.
- Option 2: A Will is not an actuator acknowledgment.
- Option 3: It is not direct physical-state feedback from the process.
- Option 4: Connection loss and physical operation can diverge.

**GICSP-Q0390 · multi · design**

Which reconnect tests are necessary for this interface? Select all that apply.

Synthetic integration: OPC UA client stores NodeId ns=2;i=500 for URI urn:site:plant. After server restart NamespaceArray[2]=urn:site:diagnostics and plant moves to index 3. Client certificate is trusted, but user viewer has read-only role. DataValue=24.0, StatusCode=BadSensorFailure, source time11:00; dashboard at 11:20 drops status and calls it current. MQTT broker grants sensorA publish site/# and subscribe site/#. New command subscriber receives retained payload {command_id:17, action:"start", source_time:"10:00"} at 12:00. Application executes every QoS1 delivery; command17 is delivered twice. OPC subscription queue reports overflow.

1. Only a TCP connection success.
2. Changed namespace mapping and missing/interrupted subscription history.
3. Only successful broker login, with retained messages and command execution ignored.
4. Stale retained messages and duplicate command delivery.

**Correct option(s):** 2, 4

- Option 1: Transport establishment does not test application semantics.
- Option 2: Reconnect can alter mapping and continuity assumptions.
- Option 3: Authentication does not test replayed content, source age or duplicate action handling.
- Option 4: Broker state can replay old or repeated content.

#### Recall

**OPC application trust versus user authority?**

A trusted application/channel does not grant its users every operation; server-side session roles still constrain reads, writes and methods.

**Does MQTT QoS equal exactly-once physical action?**

No. Delivery semantics, retries, retained data and application execution need separate idempotency, freshness and outcome design.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [OPC UA specifications](https://reference.opcfoundation.org/)
- [OASIS MQTT 5.0 specification](https://docs.oasis-open.org/mqtt/mqtt/v5.0/mqtt-v5.0.html)

### GICSP-L040 — Cryptographic assurance and its operational boundaries

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L039

Cryptographic primitives answer different questions. A hash maps bytes to a digest and supports integrity comparison when the expected digest is obtained through a trusted path. A keyed message authentication code adds shared-secret origin/integrity assurance; every party holding the key can generally create a valid code. A digital signature uses a private signing key and a corresponding verification key, supporting a different trust and attribution model. None of these operations alone makes a sensor reading physically correct or an operator action authorised. Identify the assurance required before selecting the mechanism.

Encryption protects confidentiality within its scope. Authenticated encryption also detects unauthorised modification under its key and nonce requirements. A nonce is not necessarily secret, but algorithms such as GCM require that the relevant nonce not be reused with the same key. Reusing a key/nonce pair can undermine confidentiality and integrity; changing the filename or adding a timestamp elsewhere does not repair that cryptographic misuse. Use supported implementations and key-management mechanisms rather than designing a custom encryption scheme for an OT project.

TLS establishes a protected channel between endpoints using negotiated parameters and authenticated peer identity according to the application profile. Mutual authentication is separate from whether the channel encrypts data. The current TLS 1.3 specification is RFC9846, which updates the earlier RFC8446 while retaining version1.3. Application protocols still need correct peer-identity interpretation, trust configuration and authorisation. A tunnel ending at a gateway protects only that segment; traffic and credentials beyond the gateway may remain exposed or governed by a different trust model.

Forward secrecy limits the effect of later long-term key compromise for appropriately established sessions; it does not protect an endpoint while it is compromised or erase plaintext logs. Session resumption and early-data mechanisms have their own properties. In particular, early data requires careful replay treatment; do not send a non-idempotent physical command through an early-data path and assume the transport guarantees unique actuation. Application command identifiers, freshness, authorised state transitions and outcome checks remain necessary.

IPsec protects selected IP traffic according to its security policy and associations. Tunnel and transport modes have different encapsulation scope; selectors determine which flows are protected, bypassed or discarded. A working tunnel does not mean every subnet or protocol uses it. Verify actual policy, routes, peer identity, rekey behaviour and failure handling. Fail-open fallback to unprotected traffic can defeat the intended requirement, while fail-closed behaviour can affect service availability. The approved architecture must address both protection and operational continuity.

Key lifecycle includes generation, custody, distribution, rotation, revocation, backup/recovery and destruction. Shared keys can expand the impact of one endpoint compromise; private keys embedded in exported project files can escape their intended boundary. Rotation must account for overlapping trust, cached sessions and dependent devices without leaving old authority active indefinitely. Test expiry, revoked peers, wrong names, interrupted rekey and recovery from protected backups. Monitoring encrypted traffic may rely on endpoint/application logs and flow metadata; lack of visible payload is a visibility limitation, not evidence that the traffic is harmless.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic security review: telemetry uses TLS from sensor gateway G to broker B, but field devices F→G use plaintext legacy traffic. Both endpoints validate the server chain/name, but B does not request client certificates; application login is still required. A custom file encryptor records key_id=K7, nonce=0001 for two different plaintext exports under AES-GCM. An IPsec policy protects192.0.2.0/24→198.51.100.0/24 but bypasses IPv6. A command API accepts non-idempotent “increment setpoint” in TLS early data with no command ID. Vendor backup contains G's private key. IDS sees tunnel metadata only.

**Reasoning:** TLS protects G→B, not the plaintext field segment. Server authentication does not imply mutual client-certificate authentication, and application authority remains separate. Reusing K7/0001 violates the nonce requirement and needs a supported cryptographic redesign plus exposure assessment. IPv6 bypass is outside the protected selector set. Early-data replay can repeat a non-idempotent increment without application safeguards. Protect the backup key and plan its lifecycle; the IDS cannot inspect hidden application payload from metadata alone.

#### Guided practice

Create a protection-scope table for each mechanism.

**Hint:** Name endpoints, covered data, identity, remaining authority and failure behaviour.

**Worked solution:** TLS: G/B channel with server authentication; F/G remains plaintext. IPsec: stated IPv4 selectors only. AES-GCM: intended file confidentiality/integrity invalidated by nonce reuse. API: encrypted transport but unresolved replay/action authority. Backup: private-key custody dependency.

#### Independent task

Environment: analytical

Write a cryptographic design correction and negative-test plan.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L040.json

**Evidence to produce**

- Protection-scope diagram
- Nonce/key lifecycle correction
- Replay-safe command requirements
- IPv4/IPv6 policy checks
- Encrypted-traffic evidence strategy

**Acceptance criteria**

- Encryption is not equated with physical truth or user authority.
- The same key/nonce pair is not reused in the corrected supported design.
- Tunnel selectors and plaintext segments remain explicit.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0391 · single · diagnosis**

Which traffic is protected by the supplied TLS channel?

Synthetic security review: telemetry uses TLS from sensor gateway G to broker B, but field devices F→G use plaintext legacy traffic. Both endpoints validate the server chain/name, but B does not request client certificates; application login is still required. A custom file encryptor records key_id=K7, nonce=0001 for two different plaintext exports under AES-GCM. An IPsec policy protects192.0.2.0/24→198.51.100.0/24 but bypasses IPv6. A command API accepts non-idempotent “increment setpoint” in TLS early data with no command ID. Vendor backup contains G's private key. IDS sees tunnel metadata only.

1. The TLS channel proves each sensor has authenticated separately to the broker.
2. The field-device-to-gateway segment is also encrypted because the gateway terminates TLS.
3. The broker’s stored telemetry is protected indefinitely by the transit session.
4. G→B traffic within that channel's endpoints.

**Correct option(s):** 4

- Option 1: The gateway is the TLS peer; field-device identity needs its own evidence.
- Option 2: The fixture explicitly leaves F→G plaintext; TLS protects only its own endpoints.
- Option 3: Transport encryption does not establish at-rest protection after termination.
- Option 4: The F→G legacy segment remains outside it.

**GICSP-Q0392 · single · diagnosis**

Does the supplied TLS configuration use client-certificate mutual authentication?

Synthetic security review: telemetry uses TLS from sensor gateway G to broker B, but field devices F→G use plaintext legacy traffic. Both endpoints validate the server chain/name, but B does not request client certificates; application login is still required. A custom file encryptor records key_id=K7, nonce=0001 for two different plaintext exports under AES-GCM. An IPsec policy protects192.0.2.0/24→198.51.100.0/24 but bypasses IPv6. A command API accepts non-idempotent “increment setpoint” in TLS early data with no command ID. Vendor backup contains G's private key. IDS sees tunnel metadata only.

1. No authentication of any kind can occur.
2. Yes; any encrypted channel is mutually certificate-authenticated.
3. No; B does not request a client certificate.
4. Yes because F has a serial address.

**Correct option(s):** 3

- Option 1: Server authentication and application login are explicitly supplied.
- Option 2: Encryption does not imply that authentication method.
- Option 3: Server validation and application login are different from mutual certificate authentication.
- Option 4: A field address is unrelated to a TLS client certificate.

**GICSP-Q0393 · single · diagnosis**

What is the AES-GCM defect?

Synthetic security review: telemetry uses TLS from sensor gateway G to broker B, but field devices F→G use plaintext legacy traffic. Both endpoints validate the server chain/name, but B does not request client certificates; application login is still required. A custom file encryptor records key_id=K7, nonce=0001 for two different plaintext exports under AES-GCM. An IPsec policy protects192.0.2.0/24→198.51.100.0/24 but bypasses IPv6. A command API accepts non-idempotent “increment setpoint” in TLS early data with no command ID. Vendor backup contains G's private key. IDS sees tunnel metadata only.

1. Two different plaintexts reuse nonce0001 with keyK7.
2. The exports have different filenames.
3. The key has an identifier.
4. The nonce is visible in the record.

**Correct option(s):** 1

- Option 1: Nonce uniqueness is required for that key's safe use.
- Option 2: Filename difference neither causes nor repairs the nonce requirement.
- Option 3: Identifiers can support lifecycle management.
- Option 4: Nonces generally need uniqueness, not secrecy.

**GICSP-Q0394 · single · diagnosis**

Which traffic bypasses the supplied IPsec protection policy?

Synthetic security review: telemetry uses TLS from sensor gateway G to broker B, but field devices F→G use plaintext legacy traffic. Both endpoints validate the server chain/name, but B does not request client certificates; application login is still required. A custom file encryptor records key_id=K7, nonce=0001 for two different plaintext exports under AES-GCM. An IPsec policy protects192.0.2.0/24→198.51.100.0/24 but bypasses IPv6. A command API accepts non-idempotent “increment setpoint” in TLS early data with no command ID. Vendor backup contains G's private key. IDS sees tunnel metadata only.

1. All192.0.2.0/24→198.51.100.0/24 traffic by definition.
2. IPv6 traffic.
3. Only packets with a valid source address.
4. Only traffic whose payload is encrypted by TLS.

**Correct option(s):** 2

- Option 1: That is the stated protected selector.
- Option 2: The exhibit explicitly states an IPv6 bypass.
- Option 3: Validity is not the supplied selector distinction.
- Option 4: Nested encryption does not inherently bypass IPsec selectors.

**GICSP-Q0395 · single · diagnosis**

Why is “increment setpoint” risky in the described early-data API?

Synthetic security review: telemetry uses TLS from sensor gateway G to broker B, but field devices F→G use plaintext legacy traffic. Both endpoints validate the server chain/name, but B does not request client certificates; application login is still required. A custom file encryptor records key_id=K7, nonce=0001 for two different plaintext exports under AES-GCM. An IPsec policy protects192.0.2.0/24→198.51.100.0/24 but bypasses IPv6. A command API accepts non-idempotent “increment setpoint” in TLS early data with no command ID. Vendor backup contains G's private key. IDS sees tunnel metadata only.

1. A valid server certificate alone prevents repeated application execution.
2. Early data corrupts the command value in transit, which is why increment is unsafe.
3. A replay can repeat a non-idempotent change without a command identity/outcome safeguard.
4. An increment operation can never be authorised even with replay-safe application design.

**Correct option(s):** 3

- Option 1: Peer authentication does not supply command-level replay handling.
- Option 2: The concern is replay of a non-idempotent operation, not inevitable bit corruption.
- Option 3: Transport early-data properties do not guarantee unique physical action.
- Option 4: It can be legitimate, but the described early-data API lacks deduplication and safe replay semantics.

**GICSP-Q0396 · single · mechanism**

Which assurance differs between a shared-key MAC and a digital signature?

Synthetic security review: telemetry uses TLS from sensor gateway G to broker B, but field devices F→G use plaintext legacy traffic. Both endpoints validate the server chain/name, but B does not request client certificates; application login is still required. A custom file encryptor records key_id=K7, nonce=0001 for two different plaintext exports under AES-GCM. An IPsec policy protects192.0.2.0/24→198.51.100.0/24 but bypasses IPv6. A command API accepts non-idempotent “increment setpoint” in TLS early data with no command ID. Vendor backup contains G's private key. IDS sees tunnel metadata only.

1. All MAC-key holders can generally create valid MACs, while signature creation depends on the private signing key.
2. A MAC always encrypts the message.
3. A signature proves the signed process value is physically correct.
4. A hash without a trusted expected value identifies the authorised signer.

**Correct option(s):** 1

- Option 1: The trust and attribution models differ.
- Option 2: Authentication codes do not inherently provide confidentiality.
- Option 3: It authenticates a claim's origin/integrity, not sensor truth.
- Option 4: A bare digest carries no signer identity.

**GICSP-Q0397 · single · mechanism**

What does forward secrecy not protect against?

Synthetic security review: telemetry uses TLS from sensor gateway G to broker B, but field devices F→G use plaintext legacy traffic. Both endpoints validate the server chain/name, but B does not request client certificates; application login is still required. A custom file encryptor records key_id=K7, nonce=0001 for two different plaintext exports under AES-GCM. An IPsec policy protects192.0.2.0/24→198.51.100.0/24 but bypasses IPv6. A command API accepts non-idempotent “increment setpoint” in TLS early data with no command ID. Vendor backup contains G's private key. IDS sees tunnel metadata only.

1. Use of separate ephemeral session keying material.
2. Some later compromise of a long-term authentication key for appropriately established past sessions.
3. The need to evaluate session-establishment assumptions.
4. Plaintext access on an endpoint while that endpoint is compromised.

**Correct option(s):** 4

- Option 1: That can support forward secrecy.
- Option 2: Limiting that retrospective exposure is its intended property.
- Option 3: Those assumptions remain part of the claim.
- Option 4: Channel key properties cannot hide data from its legitimate processing endpoint.

**GICSP-Q0398 · single · diagnosis**

What is the consequence of G's private key appearing in a vendor backup?

Synthetic security review: telemetry uses TLS from sensor gateway G to broker B, but field devices F→G use plaintext legacy traffic. Both endpoints validate the server chain/name, but B does not request client certificates; application login is still required. A custom file encryptor records key_id=K7, nonce=0001 for two different plaintext exports under AES-GCM. An IPsec policy protects192.0.2.0/24→198.51.100.0/24 but bypasses IPv6. A command API accepts non-idempotent “increment setpoint” in TLS early data with no command ID. Vendor backup contains G's private key. IDS sees tunnel metadata only.

1. The key stops being private merely because the file extension changes.
2. The backup’s encryption setting alone, without reviewing who can decrypt it.
3. Every copy is automatically revoked by TLS.
4. The backup becomes part of the credential trust boundary and exposure assessment.

**Correct option(s):** 4

- Option 1: Naming does not determine custody or exposure.
- Option 2: Key exposure depends on custody and access to the private-key copy, not compression or an encryption label alone.
- Option 3: Revocation requires a lifecycle action and enforcement.
- Option 4: Key holders may gain the associated identity capability.

**GICSP-Q0399 · multi · design**

Which negative tests support the channel design? Select all that apply.

Synthetic security review: telemetry uses TLS from sensor gateway G to broker B, but field devices F→G use plaintext legacy traffic. Both endpoints validate the server chain/name, but B does not request client certificates; application login is still required. A custom file encryptor records key_id=K7, nonce=0001 for two different plaintext exports under AES-GCM. An IPsec policy protects192.0.2.0/24→198.51.100.0/24 but bypasses IPv6. A command API accepts non-idempotent “increment setpoint” in TLS early data with no command ID. Vendor backup contains G's private key. IDS sees tunnel metadata only.

1. Only a normal encrypted transfer, without wrong-peer or outage cases.
2. Protected-selector failure and attempted unprotected fallback.
3. Wrong peer identity, expired/revoked credential and interrupted rekey.
4. Only a successful connection with all checks disabled.

**Correct option(s):** 2, 3

- Option 1: A positive transfer does not exercise the required negative trust and fallback behaviours.
- Option 2: These test whether the intended boundary holds under outage.
- Option 3: These exercise trust and lifecycle failures.
- Option 4: That bypasses the properties being tested.

**GICSP-Q0400 · single · diagnosis**

What can the IDS infer from tunnel metadata alone?

Synthetic security review: telemetry uses TLS from sensor gateway G to broker B, but field devices F→G use plaintext legacy traffic. Both endpoints validate the server chain/name, but B does not request client certificates; application login is still required. A custom file encryptor records key_id=K7, nonce=0001 for two different plaintext exports under AES-GCM. An IPsec policy protects192.0.2.0/24→198.51.100.0/24 but bypasses IPv6. A command API accepts non-idempotent “increment setpoint” in TLS early data with no command ID. Vendor backup contains G's private key. IDS sees tunnel metadata only.

1. The exact setpoint value inside every packet.
2. Visible endpoints, timing and volume within its observation scope, not the hidden command content.
3. The human user identity with certainty.
4. Every encrypted command is harmless.

**Correct option(s):** 2

- Option 1: That content is not visible in the supplied observation.
- Option 2: Payload confidentiality limits semantic inspection.
- Option 3: Tunnel peers and users are not necessarily one-to-one.
- Option 4: Encryption does not establish authorised intent.

#### Recall

**What does encryption not establish?**

Correct physical data, permitted application actions, complete protection beyond its endpoints or exactly-once process execution.

**Why does nonce reuse matter?**

Some authenticated-encryption modes, including GCM, rely on nonce uniqueness under a key; reuse can break their intended assurances.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [RFC 9846: TLS 1.3, current 2026 specification](https://www.rfc-editor.org/info/rfc9846/)
- [RFC 4301: IPsec architecture](https://www.rfc-editor.org/rfc/rfc4301)
- [RFC 4106: AES-GCM in IPsec ESP](https://www.rfc-editor.org/rfc/rfc4106)

## GICSP-M09 — Wireless engineering and defensive assessment

### GICSP-L041 — Radio propagation, interference and airtime budgets

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L040

Wireless links share a physical medium whose behaviour depends on distance, antennas, obstructions, reflections, interference and receiver capabilities. A network diagram showing a radio line does not establish a reliable control path. Measure or model the required coverage under relevant operating conditions, including closed doors, moving machinery and equipment that emits interference. A metal rack added after commissioning can change propagation even when every network setting remains unchanged. Record the physical configuration as part of the baseline.

Decibels express ratios; dBm expresses power relative to one milliwatt. A ten-decibel increase represents a tenfold power ratio, while approximately three decibels represents a doubling. Received signal strength alone is insufficient: signal-to-noise ratio compares signal and noise levels at the receiver. If signal is −62 dBm and noise is −92 dBm, SNR is 30 dB. If noise rises to−67 dBm while signal stays−62, SNR falls to 5 dB. The unchanged signal does not imply an unchanged usable link.

A link budget combines transmitter power, antenna gains, cable losses and propagation loss using consistent units. Fade margin compares the expected received level with the receiver sensitivity for the required modulation/rate and error performance. Sensitivity varies with the selected rate and hardware, so do not use one universal value. More transmit power does not always solve a link: the return direction may remain weak, interference to other systems may increase, and regulatory or equipment limits apply. Physical measurements and authorised radio design must confirm the model.

Airtime is the shared resource. Payload bits divided by nominal rate gives only the ideal payload transmission time; framing, contention, acknowledgments, retries and other stations add overhead. A low-rate client can occupy substantial airtime even with modest throughput. Do not add advertised access-point rates and call that guaranteed application capacity. For scheduled industrial radios, slot allocation and retransmission paths determine timing; for contention-based WLANs, competing traffic and retries affect latency distributions. The application freshness budget must account for the actual mechanism.

Loss and interference need careful diagnosis. Elevated noise, retries or missed packets can result from accidental interference, obstructions, equipment faults, channel overlap, congestion or deliberate jamming. A spectrum observation may show energy without identifying its source or intent. Correlate time, location, channel, device logs and physical changes. Avoid active disruption tests on operational spectrum; an authorised survey can begin with passive measurements and records. The distinction between a security event and an RF engineering fault affects response and evidence, but both may impair the required service.

Wireless coverage is not a trust boundary. Signals can extend outside the intended room, and a low-power setting does not authenticate clients. Use appropriate network authentication, encryption, segmentation and application authority while engineering RF availability. Test both link directions, required roaming locations, degraded channels and recovery after a radio outage. Report measured confidence and exclusions. The calculations here use supplied idealised values; they are not a site survey, regulatory approval or proof of field performance.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic RF/airtime model: receiver sees signal−62 dBm, noise−92 dBm; required-rate sensitivity−82 dBm. After a nearby device starts, noise becomes−67 dBm while signal stays−62. Payload per transaction3200 bits at 1,000,000 bit/s; supplied fixed framing/ack overhead1.8 ms;100 transactions/s; no retries included in that model. Measured operation later shows20% retransmissions, with each retransmission consuming another complete5 ms transaction-equivalent airtime for this exercise. A steel cabinet was also installed near the antenna. No evidence identifies deliberate interference.

**Reasoning:** Initial SNR is 30 dB and fade margin relative to the supplied sensitivity is 20 dB. New SNR is 5 dB despite unchanged signal. Ideal transaction airtime is 3.2+1.8=5 ms, so100/s consumes500 ms/s or50%. With20 additional retransmission-equivalent transactions per second, airtime becomes 600 ms/s or60%, before other omitted contention. The noise and cabinet changes support competing RF hypotheses, not attribution of jamming. Reassess both directions and the required application timing.

#### Guided practice

Calculate the effect of doubling transaction rate while keeping the same20% retransmission ratio.

**Hint:** Apply the supplied per-transaction model, then compare with one second of airtime.

**Worked solution:** 200 original plus40 retransmission-equivalent transactions consume240×5=1200 ms/s, or120% of available airtime. That offered load cannot be served within this simple one-channel model and needs redesign or reduced load.

#### Independent task

Environment: analytical

Prepare a radio diagnosis and application-capacity report.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L041.json

**Evidence to produce**

- SNR/fade-margin calculation
- Airtime model with exclusions
- Competing interference/obstruction hypotheses
- Passive survey and acceptance plan

**Acceptance criteria**

- Power, noise and signal-to-noise are distinguished.
- The airtime result includes the supplied overhead and retries.
- No deliberate attacker is claimed from RF degradation alone.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0401 · single · calculation**

What is the initial SNR?

Synthetic RF/airtime model: receiver sees signal−62 dBm, noise−92 dBm; required-rate sensitivity−82 dBm. After a nearby device starts, noise becomes−67 dBm while signal stays−62. Payload per transaction3200 bits at 1,000,000 bit/s; supplied fixed framing/ack overhead1.8 ms;100 transactions/s; no retries included in that model. Measured operation later shows20% retransmissions, with each retransmission consuming another complete5 ms transaction-equivalent airtime for this exercise. A steel cabinet was also installed near the antenna. No evidence identifies deliberate interference.

1. 30 dB.
2. −154 dB.
3. 5 dB.
4. 20 dB.

**Correct option(s):** 1

- Option 1: −62−(−92)=30.
- Option 2: Adding the two absolute levels does not compute their ratio.
- Option 3: That is the later signal-to-noise ratio.
- Option 4: That is the supplied signal-to-sensitivity margin.

**GICSP-Q0402 · single · calculation**

What is the new SNR after noise rises to−67 dBm?

Synthetic RF/airtime model: receiver sees signal−62 dBm, noise−92 dBm; required-rate sensitivity−82 dBm. After a nearby device starts, noise becomes−67 dBm while signal stays−62. Payload per transaction3200 bits at 1,000,000 bit/s; supplied fixed framing/ack overhead1.8 ms;100 transactions/s; no retries included in that model. Measured operation later shows20% retransmissions, with each retransmission consuming another complete5 ms transaction-equivalent airtime for this exercise. A steel cabinet was also installed near the antenna. No evidence identifies deliberate interference.

1. 5 dB.
2. 20 dB because sensitivity is unchanged.
3. −129 dBm.
4. 30 dB because signal is unchanged.

**Correct option(s):** 1

- Option 1: −62−(−67)=5.
- Option 2: Sensitivity margin and SNR are different comparisons.
- Option 3: SNR is a difference in dB, not a sum in dBm.
- Option 4: Noise changed and therefore the ratio changed.

**GICSP-Q0403 · single · calculation**

What is the supplied fade margin relative to−82 dBm sensitivity?

Synthetic RF/airtime model: receiver sees signal−62 dBm, noise−92 dBm; required-rate sensitivity−82 dBm. After a nearby device starts, noise becomes−67 dBm while signal stays−62. Payload per transaction3200 bits at 1,000,000 bit/s; supplied fixed framing/ack overhead1.8 ms;100 transactions/s; no retries included in that model. Measured operation later shows20% retransmissions, with each retransmission consuming another complete5 ms transaction-equivalent airtime for this exercise. A steel cabinet was also installed near the antenna. No evidence identifies deliberate interference.

1. 20 dB.
2. 30 dB.
3. −20 dBm.
4. 82 dB.

**Correct option(s):** 1

- Option 1: −62−(−82)=20.
- Option 2: That compares signal with the original noise floor.
- Option 3: Margin is a ratio in dB and is positive here.
- Option 4: Receiver sensitivity alone is not a margin.

**GICSP-Q0404 · single · calculation**

What is one transaction's modelled airtime before retries?

Synthetic RF/airtime model: receiver sees signal−62 dBm, noise−92 dBm; required-rate sensitivity−82 dBm. After a nearby device starts, noise becomes−67 dBm while signal stays−62. Payload per transaction3200 bits at 1,000,000 bit/s; supplied fixed framing/ack overhead1.8 ms;100 transactions/s; no retries included in that model. Measured operation later shows20% retransmissions, with each retransmission consuming another complete5 ms transaction-equivalent airtime for this exercise. A steel cabinet was also installed near the antenna. No evidence identifies deliberate interference.

1. 3.2 ms.
2. 1.8 ms.
3. 5 ms.
4. 3200 ms.

**Correct option(s):** 3

- Option 1: That omits the explicitly supplied overhead.
- Option 2: That omits payload transmission.
- Option 3: 3200/1,000,000 s=3.2 ms, plus1.8 ms overhead.
- Option 4: That confuses bits with milliseconds and ignores the rate.

**GICSP-Q0405 · single · calculation**

What is modelled airtime use at 100 original transactions/s with 20% retransmission-equivalent load?

Synthetic RF/airtime model: receiver sees signal−62 dBm, noise−92 dBm; required-rate sensitivity−82 dBm. After a nearby device starts, noise becomes−67 dBm while signal stays−62. Payload per transaction3200 bits at 1,000,000 bit/s; supplied fixed framing/ack overhead1.8 ms;100 transactions/s; no retries included in that model. Measured operation later shows20% retransmissions, with each retransmission consuming another complete5 ms transaction-equivalent airtime for this exercise. A steel cabinet was also installed near the antenna. No evidence identifies deliberate interference.

1. 60%.
2. 50%.
3. 70%.
4. 120%.

**Correct option(s):** 1

- Option 1: 120×5 ms=600 ms in each second.
- Option 2: That excludes retries.
- Option 3: Adding twenty percentage points is not the stated retransmission calculation.
- Option 4: That is the doubled-rate guided case, not this rate.

**GICSP-Q0406 · single · mechanism**

Why is raising only the access point's transmit power not a complete solution?

Synthetic RF/airtime model: receiver sees signal−62 dBm, noise−92 dBm; required-rate sensitivity−82 dBm. After a nearby device starts, noise becomes−67 dBm while signal stays−62. Payload per transaction3200 bits at 1,000,000 bit/s; supplied fixed framing/ack overhead1.8 ms;100 transactions/s; no retries included in that model. Measured operation later shows20% retransmissions, with each retransmission consuming another complete5 ms transaction-equivalent airtime for this exercise. A steel cabinet was also installed near the antenna. No evidence identifies deliberate interference.

1. The client return link, interference and permitted operating limits may still constrain service.
2. Higher radio power removes the need to validate client identity and role.
3. Increasing AP transmit power leaves the downlink signal unchanged by definition.
4. Higher AP power corrects the client’s uplink transmit power and receiver sensitivity.

**Correct option(s):** 1

- Option 1: Wireless communication is bidirectional and shared.
- Option 2: RF link margin and access authority are separate controls.
- Option 3: It can affect downlink reception, but does not automatically fix uplink or interference constraints.
- Option 4: The client-to-AP direction has its own power and sensitivity constraints.

**GICSP-Q0407 · multi · diagnosis**

Which explanations remain plausible from the supplied observations? Select all that apply.

Synthetic RF/airtime model: receiver sees signal−62 dBm, noise−92 dBm; required-rate sensitivity−82 dBm. After a nearby device starts, noise becomes−67 dBm while signal stays−62. Payload per transaction3200 bits at 1,000,000 bit/s; supplied fixed framing/ack overhead1.8 ms;100 transactions/s; no retries included in that model. Measured operation later shows20% retransmissions, with each retransmission consuming another complete5 ms transaction-equivalent airtime for this exercise. A steel cabinet was also installed near the antenna. No evidence identifies deliberate interference.

1. Propagation change caused by the steel cabinet.
2. Confirmed deliberate jamming by a named actor.
3. Interference associated with the newly active nearby device.
4. Guaranteed certificate expiry.

**Correct option(s):** 1, 3

- Option 1: A metal obstruction can alter signal paths.
- Option 2: No intent or attribution evidence is supplied.
- Option 3: The noise change correlates with its operation, subject to verification.
- Option 4: The RF observations do not establish an authentication expiry.

**GICSP-Q0408 · single · mechanism**

What does an approximately3 dB power increase represent?

Synthetic RF/airtime model: receiver sees signal−62 dBm, noise−92 dBm; required-rate sensitivity−82 dBm. After a nearby device starts, noise becomes−67 dBm while signal stays−62. Payload per transaction3200 bits at 1,000,000 bit/s; supplied fixed framing/ack overhead1.8 ms;100 transactions/s; no retries included in that model. Measured operation later shows20% retransmissions, with each retransmission consuming another complete5 ms transaction-equivalent airtime for this exercise. A steel cabinet was also installed near the antenna. No evidence identifies deliberate interference.

1. Approximately twice the power.
2. Exactly twice the application throughput.
3. Three times the physical distance in all environments.
4. Three additional authenticated users.

**Correct option(s):** 1

- Option 1: Decibels describe a logarithmic power ratio.
- Option 2: Throughput depends on modulation, airtime, loss and protocol overhead.
- Option 3: Propagation does not follow that universal rule.
- Option 4: Power ratio is unrelated to identity count.

**GICSP-Q0409 · single · design**

Why is a low transmit-power setting not an access-control boundary?

Synthetic RF/airtime model: receiver sees signal−62 dBm, noise−92 dBm; required-rate sensitivity−82 dBm. After a nearby device starts, noise becomes−67 dBm while signal stays−62. Payload per transaction3200 bits at 1,000,000 bit/s; supplied fixed framing/ack overhead1.8 ms;100 transactions/s; no retries included in that model. Measured operation later shows20% retransmissions, with each retransmission consuming another complete5 ms transaction-equivalent airtime for this exercise. A steel cabinet was also installed near the antenna. No evidence identifies deliberate interference.

1. The surveyed receiver’s antenna sensitivity defines what every possible receiver can hear.
2. A low-power signal cannot support the configured link encryption.
3. Receivable signals can extend beyond the intended area and do not authenticate a client.
4. The new cabinet proves all radio energy is contained inside the room.

**Correct option(s):** 3

- Option 1: Different antennas and placement can receive beyond that observation.
- Option 2: Power level and cryptographic access control are separate properties.
- Option 3: RF footprint and identity enforcement are different controls.
- Option 4: Attenuation is environment-dependent and does not create a reliable identity boundary.

**GICSP-Q0410 · single · implementation**

What should a survey report retain for later comparison?

Synthetic RF/airtime model: receiver sees signal−62 dBm, noise−92 dBm; required-rate sensitivity−82 dBm. After a nearby device starts, noise becomes−67 dBm while signal stays−62. Payload per transaction3200 bits at 1,000,000 bit/s; supplied fixed framing/ack overhead1.8 ms;100 transactions/s; no retries included in that model. Measured operation later shows20% retransmissions, with each retransmission consuming another complete5 ms transaction-equivalent airtime for this exercise. A steel cabinet was also installed near the antenna. No evidence identifies deliberate interference.

1. Location, channel, physical conditions, signal/noise, load and measurement limitations.
2. Only the SSID string.
3. Only the advertised maximum radio rate.
4. Only a single successful packet.

**Correct option(s):** 1

- Option 1: These explain the observed RF/application behaviour.
- Option 2: A name does not describe propagation or airtime.
- Option 3: Nominal rate does not establish usable service.
- Option 4: One packet cannot characterise coverage, load or failure behaviour.

#### Recall

**SNR versus fade margin?**

SNR compares signal with noise; fade margin compares received level with the sensitivity required for the chosen operating mode.

**Why calculate airtime rather than payload rate alone?**

Overhead, contention, low-rate transmissions and retries consume the shared medium and affect latency/capacity.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [NIST SP 800-153: WLAN security](https://csrc.nist.gov/pubs/sp/800/153/final)

### GICSP-L042 — Enterprise WLAN authentication and access policy

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L041

Enterprise WLAN access involves several roles. The supplicant is the client seeking access, the authenticator is commonly the access point or controller enforcing the port state, and the authentication server evaluates the EAP exchange, often carried through RADIUS. These roles can be physically combined or distributed, but their trust and failure dependencies remain. Successful radio association does not mean enterprise authentication succeeded, and authentication success does not prove that the client received the intended VLAN, address or application permissions.

EAP-TLS uses certificates and TLS within EAP for mutual authentication under the configured trust model. Clients must validate the intended authentication server, not merely accept any certificate from a broad public trust store. Without the intended identity check, an impersonating service may be accepted under an unintended trust relationship. Server-side validation must also establish the client's certificate identity, trust, validity and permitted role. Possession of a certificate should map to a controlled device/user identity and lifecycle, not an unrestricted network role by default.

WPA security protects the wireless link according to the negotiated suite and configuration. It does not automatically encrypt traffic after it leaves the access point toward a legacy application. A shared pre-shared key gives every holder the same basic credential knowledge and complicates individual revocation; enterprise authentication can provide individual identity control but adds directory, certificate and authentication-server dependencies. Evaluate the actual deployment, including fallback SSIDs and cached credentials, rather than assuming a marketing generation label proves secure configuration.

Authorisation follows authentication. The server/controller may assign a VLAN or policy role; DHCP supplies addressing; routing and firewalls determine reachability; applications enforce their own operations. A successful EAP exchange followed by an address from the guest subnet may indicate role mapping or VLAN handling, not an incorrect client certificate. A client reaching a PLC after authentication still needs appropriate application authority; network admission is not permission to perform every control action. Test the required flow matrix for each role.

Roaming and reauthentication have timing and state implications. A client moving between access points may use supported key-caching or fast-transition mechanisms, while a full authentication requires available back-end services. Measure the interruption experienced by the application rather than equating a radio reassociation timestamp with restored alarm delivery. Certificate renewal, revocation, clock error and authentication-server outage need explicit behaviour. A fallback shared-key SSID that grants broader access can undermine the enterprise boundary during the very outage it was meant to handle.

Protect management access to access points, controllers and authentication servers, and monitor configuration changes and failed/successful authentication with useful identity context. Keep privacy and retention obligations appropriate to the records. An authorised isolated test should include wrong-server identity, revoked client, wrong-role mapping, back-end outage, roaming under load and application recovery. The supplied log exercise does not involve collecting real users' credentials or impersonating a live WLAN; it teaches how to diagnose and verify the intended defensive design.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic WLAN logs: client C associates with SSID OT-ENG. EAP-TLS succeeds with certificate identity engineer-laptop-7. RADIUS result assigns role REPORT and VLAN 210; approved mapping requires ENGINEER and VLAN 220. DHCP gives198.51.100.27 on VLAN 210. Client validation configuration trusts CA-A but has no expected authentication-server identity restriction. During RADIUS outage, fallback SSID OT-RESCUE uses one shared PSK and bridges directly to controller VLAN 60. Roaming radio reassociation takes 80 ms, but measured application telemetry resumes after 2.4 s; freshness requirement is 1.0 s. Field-side Modbus remains plaintext.

**Reasoning:** The immediate access mismatch is authorisation mapping, not failed EAP authentication: REPORT/VLAN 210 differs from the approved role. Constrain server identity as well as CA trust. The fallback SSID expands shared-credential access to the controller segment and needs redesign. The application interruption2.4 s fails the 1.0 s requirement despite80 ms radio reassociation. Wireless encryption does not protect the plaintext field-side segment after termination.

#### Guided practice

Create a layered diagnosis for C without changing its certificate blindly.

**Hint:** Follow association, EAP, role, VLAN/address, reachability and application authority.

**Worked solution:** Association and EAP succeeded; the returned role/VLAN is wrong for the approved mapping, producing the corresponding address. Correct and verify the role policy, then test intended network/application permissions. Separately fix server validation and fallback/roaming defects.

#### Independent task

Environment: analytical

Write a WLAN admission and failure-mode acceptance plan.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L042.json

**Evidence to produce**

- Authentication/authorisation trace
- Server-identity validation requirement
- Fallback boundary correction
- Application roaming measurement

**Acceptance criteria**

- EAP success is not confused with correct VLAN assignment.
- Shared fallback authority is explicitly bounded.
- The application freshness result determines the timing finding.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0411 · single · diagnosis**

At which layer is C's immediate assigned-role defect shown?

Synthetic WLAN logs: client C associates with SSID OT-ENG. EAP-TLS succeeds with certificate identity engineer-laptop-7. RADIUS result assigns role REPORT and VLAN 210; approved mapping requires ENGINEER and VLAN 220. DHCP gives198.51.100.27 on VLAN 210. Client validation configuration trusts CA-A but has no expected authentication-server identity restriction. During RADIUS outage, fallback SSID OT-RESCUE uses one shared PSK and bridges directly to controller VLAN 60. Roaming radio reassociation takes 80 ms, but measured application telemetry resumes after 2.4 s; freshness requirement is 1.0 s. Field-side Modbus remains plaintext.

1. DHCP address allocation independent of the RADIUS role.
2. Radio association before EAP-TLS authentication.
3. Authorisation mapping after successful EAP-TLS.
4. Controller application command permission after reaching VLAN 220.

**Correct option(s):** 3

- Option 1: DHCP supplies an address on the already selected VLAN 210; the wrong selection is visible in RADIUS authorisation.
- Option 2: The client associates and authenticates successfully; the supplied wrong role/VLAN is assigned afterwards.
- Option 3: RADIUS returned REPORT/VLAN 210 instead of the approved ENGINEER/VLAN 220.
- Option 4: The fixture never assigns the required VLAN 220; the immediate defect occurs earlier in role mapping.

**GICSP-Q0412 · single · diagnosis**

What is missing from the client's server-validation configuration?

Synthetic WLAN logs: client C associates with SSID OT-ENG. EAP-TLS succeeds with certificate identity engineer-laptop-7. RADIUS result assigns role REPORT and VLAN 210; approved mapping requires ENGINEER and VLAN 220. DHCP gives198.51.100.27 on VLAN 210. Client validation configuration trusts CA-A but has no expected authentication-server identity restriction. During RADIUS outage, fallback SSID OT-RESCUE uses one shared PSK and bridges directly to controller VLAN 60. Roaming radio reassociation takes 80 ms, but measured application telemetry resumes after 2.4 s; freshness requirement is 1.0 s. Field-side Modbus remains plaintext.

1. Any CA trust at all.
2. Restriction to the intended authentication-server identity.
3. A requirement that the client share its private key with the access point.
4. A rule to accept every certificate warning.

**Correct option(s):** 2

- Option 1: CA-A is already trusted.
- Option 2: Trusting CA-A alone may accept an unintended server certificate.
- Option 3: Private-key disclosure is not the intended mechanism.
- Option 4: That would weaken, not complete, validation.

**GICSP-Q0413 · single · mechanism**

Which role normally enforces the network access state in this802.1X arrangement?

Synthetic WLAN logs: client C associates with SSID OT-ENG. EAP-TLS succeeds with certificate identity engineer-laptop-7. RADIUS result assigns role REPORT and VLAN 210; approved mapping requires ENGINEER and VLAN 220. DHCP gives198.51.100.27 on VLAN 210. Client validation configuration trusts CA-A but has no expected authentication-server identity restriction. During RADIUS outage, fallback SSID OT-RESCUE uses one shared PSK and bridges directly to controller VLAN 60. Roaming radio reassociation takes 80 ms, but measured application telemetry resumes after 2.4 s; freshness requirement is 1.0 s. Field-side Modbus remains plaintext.

1. The RADIUS server independently of any enforcement by the access point/controller.
2. The authenticator, commonly the access point/controller.
3. The supplicant deciding locally that its own certificate is valid.
4. The DHCP server solely because it assigns the client an address.

**Correct option(s):** 2

- Option 1: The server supplies the decision; the authenticator must apply it to the access state.
- Option 2: It mediates access using the authentication result.
- Option 3: The client participates in authentication but cannot grant itself the network access state.
- Option 4: DHCP acts after admission in this path and does not enforce the EAP-controlled access state.

**GICSP-Q0414 · single · diagnosis**

Why is OT-RESCUE a boundary concern?

Synthetic WLAN logs: client C associates with SSID OT-ENG. EAP-TLS succeeds with certificate identity engineer-laptop-7. RADIUS result assigns role REPORT and VLAN 210; approved mapping requires ENGINEER and VLAN 220. DHCP gives198.51.100.27 on VLAN 210. Client validation configuration trusts CA-A but has no expected authentication-server identity restriction. During RADIUS outage, fallback SSID OT-RESCUE uses one shared PSK and bridges directly to controller VLAN 60. Roaming radio reassociation takes 80 ms, but measured application telemetry resumes after 2.4 s; freshness requirement is 1.0 s. Field-side Modbus remains plaintext.

1. A shared fallback credential provides direct controller-VLAN access during back-end outage.
2. Every fallback mechanism is prohibited regardless of design.
3. A PSK automatically authenticates each individual employee uniquely.
4. It preserves the same individual engineer identity and narrow role as EAP-TLS by using a shared PSK.

**Correct option(s):** 1

- Option 1: It bypasses the intended individual-role boundary.
- Option 2: A bounded approved fallback can be engineered.
- Option 3: Shared knowledge does not provide individual identity.
- Option 4: The supplied shared fallback does not preserve individual identity or the original narrow VLAN role.

**GICSP-Q0415 · single · calculation**

Does the measured roaming behaviour meet the supplied freshness requirement?

Synthetic WLAN logs: client C associates with SSID OT-ENG. EAP-TLS succeeds with certificate identity engineer-laptop-7. RADIUS result assigns role REPORT and VLAN 210; approved mapping requires ENGINEER and VLAN 220. DHCP gives198.51.100.27 on VLAN 210. Client validation configuration trusts CA-A but has no expected authentication-server identity restriction. During RADIUS outage, fallback SSID OT-RESCUE uses one shared PSK and bridges directly to controller VLAN 60. Roaming radio reassociation takes 80 ms, but measured application telemetry resumes after 2.4 s; freshness requirement is 1.0 s. Field-side Modbus remains plaintext.

1. Yes because EAP-TLS once succeeded.
2. No; application recovery2.4 s exceeds1.0 s.
3. No because all wireless roaming must be instantaneous.
4. Yes because80 ms is below1.0 s.

**Correct option(s):** 2

- Option 1: Authentication success does not establish ongoing freshness.
- Option 2: The80 ms radio event is only one part of service recovery.
- Option 3: The supplied criterion permits one second.
- Option 4: That ignores the measured application interruption.

**GICSP-Q0416 · single · diagnosis**

Which traffic is not proven encrypted by the WLAN security configuration?

Synthetic WLAN logs: client C associates with SSID OT-ENG. EAP-TLS succeeds with certificate identity engineer-laptop-7. RADIUS result assigns role REPORT and VLAN 210; approved mapping requires ENGINEER and VLAN 220. DHCP gives198.51.100.27 on VLAN 210. Client validation configuration trusts CA-A but has no expected authentication-server identity restriction. During RADIUS outage, fallback SSID OT-RESCUE uses one shared PSK and bridges directly to controller VLAN 60. Roaming radio reassociation takes 80 ms, but measured application telemetry resumes after 2.4 s; freshness requirement is 1.0 s. Field-side Modbus remains plaintext.

1. EAP-TLS certificate messages solely because a CA is used.
2. All traffic is necessarily plaintext if one legacy segment exists.
3. The protected radio link merely because it carries Modbus-derived data.
4. The field-side Modbus segment after wireless-link termination.

**Correct option(s):** 4

- Option 1: That claim does not follow from the fixture.
- Option 2: Protection scope can differ by segment.
- Option 3: Payload origin does not remove negotiated link protection.
- Option 4: It is explicitly plaintext in the case.

**GICSP-Q0417 · single · mechanism**

What is a practical revocation disadvantage of a shared PSK?

Synthetic WLAN logs: client C associates with SSID OT-ENG. EAP-TLS succeeds with certificate identity engineer-laptop-7. RADIUS result assigns role REPORT and VLAN 210; approved mapping requires ENGINEER and VLAN 220. DHCP gives198.51.100.27 on VLAN 210. Client validation configuration trusts CA-A but has no expected authentication-server identity restriction. During RADIUS outage, fallback SSID OT-RESCUE uses one shared PSK and bridges directly to controller VLAN 60. Roaming radio reassociation takes 80 ms, but measured application telemetry resumes after 2.4 s; freshness requirement is 1.0 s. Field-side Modbus remains plaintext.

1. Changing one employee’s directory role necessarily revokes the shared PSK from that device.
2. A new SSID label revokes the old shared key even if the old network remains enabled.
3. Removing one holder may require changing the shared secret for all legitimate holders.
4. A PSK can never encrypt a link.

**Correct option(s):** 3

- Option 1: The device can retain the common wireless secret outside directory role changes.
- Option 2: Renaming one network does not remove an active old credential/path.
- Option 3: The credential is not individually attributable/revocable in the basic model.
- Option 4: It can support link protection under the chosen protocol.

**GICSP-Q0418 · multi · design**

Which negative tests belong in EAP-TLS acceptance? Select all that apply.

Synthetic WLAN logs: client C associates with SSID OT-ENG. EAP-TLS succeeds with certificate identity engineer-laptop-7. RADIUS result assigns role REPORT and VLAN 210; approved mapping requires ENGINEER and VLAN 220. DHCP gives198.51.100.27 on VLAN 210. Client validation configuration trusts CA-A but has no expected authentication-server identity restriction. During RADIUS outage, fallback SSID OT-RESCUE uses one shared PSK and bridges directly to controller VLAN 60. Roaming radio reassociation takes 80 ms, but measured application telemetry resumes after 2.4 s; freshness requirement is 1.0 s. Field-side Modbus remains plaintext.

1. Only the advertised access-point radio rate.
2. An unapproved server identity and a revoked client credential under the configured policy.
3. Authentication-server outage and the approved fallback authority.
4. Only a successful ping after one login.

**Correct option(s):** 2, 3

- Option 1: Throughput capability does not validate authentication policy.
- Option 2: They test both sides of the trust boundary.
- Option 3: Dependency failure can change access behaviour.
- Option 4: It does not test identity rejection or degraded access.

**GICSP-Q0419 · single · implementation**

What should be checked after correcting C's role assignment?

Synthetic WLAN logs: client C associates with SSID OT-ENG. EAP-TLS succeeds with certificate identity engineer-laptop-7. RADIUS result assigns role REPORT and VLAN 210; approved mapping requires ENGINEER and VLAN 220. DHCP gives198.51.100.27 on VLAN 210. Client validation configuration trusts CA-A but has no expected authentication-server identity restriction. During RADIUS outage, fallback SSID OT-RESCUE uses one shared PSK and bridges directly to controller VLAN 60. Roaming radio reassociation takes 80 ms, but measured application telemetry resumes after 2.4 s; freshness requirement is 1.0 s. Field-side Modbus remains plaintext.

1. Required and prohibited network flows plus application operation permissions.
2. Only verify the certificate label, leaving the actual VLAN and permitted controller operations untested.
3. Assume every PLC operation is now authorised.
4. Disable all firewall rules to simplify validation.

**Correct option(s):** 1

- Option 1: Correct admission does not itself prove least privilege end to end.
- Option 2: The correction concerns effective role mapping and required/forbidden behaviour.
- Option 3: Network role and controller authority remain distinct.
- Option 4: That changes the intended boundary and invalidates the test.

**GICSP-Q0420 · single · recovery**

Why retain authentication-server/controller configuration as part of recovery evidence?

Synthetic WLAN logs: client C associates with SSID OT-ENG. EAP-TLS succeeds with certificate identity engineer-laptop-7. RADIUS result assigns role REPORT and VLAN 210; approved mapping requires ENGINEER and VLAN 220. DHCP gives198.51.100.27 on VLAN 210. Client validation configuration trusts CA-A but has no expected authentication-server identity restriction. During RADIUS outage, fallback SSID OT-RESCUE uses one shared PSK and bridges directly to controller VLAN 60. Roaming radio reassociation takes 80 ms, but measured application telemetry resumes after 2.4 s; freshness requirement is 1.0 s. Field-side Modbus remains plaintext.

1. DHCP can reconstruct missing RADIUS role assignments from the client address.
2. Default AP roles are sufficient to recover the approved ENGINEER/REPORT distinction.
3. Wireless recovery needs no credential configuration because association is automatic.
4. Role mapping, trust and fallback policy determine restored access, not just the client certificate.

**Correct option(s):** 4

- Option 1: Address allocation does not restore identity-policy configuration.
- Option 2: The site’s explicit role and VLAN policy must be restored and tested.
- Option 3: Authentication, role mapping and server trust are part of the service dependencies.
- Option 4: Rebuilding only the client omits the authority infrastructure.

#### Recall

**Authentication versus WLAN authorisation?**

EAP establishes identity under its trust model; returned roles/VLANs and later network/application policies determine permitted access.

**What timing matters for roaming acceptance?**

The required application interruption/freshness, including authentication, addressing and reconnection—not only radio reassociation.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [NIST SP 800-153: WLAN security](https://csrc.nist.gov/pubs/sp/800/153/final)
- [RFC 9190: EAP-TLS 1.3](https://www.rfc-editor.org/rfc/rfc9190)

### GICSP-L043 — Industrial wireless mesh, scheduling and shared dependencies

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L042

Industrial wireless meshes can provide alternative routes between field devices and gateways. Technologies such as WirelessHART and ISA100.11a use managed communication mechanisms suited to industrial monitoring, but they are not interchangeable products or universal guarantees of deterministic control. Examine the particular stack, device profile, update schedule, topology and supported application. A mesh can route around one failed neighbour only if a usable alternative, capacity and management state exist. Several radio paths may still terminate at one gateway or share a power and administrative dependency.

Scheduled communication allocates opportunities in time and frequency. Channel hopping can reduce the effect of narrowband interference, while route diversity can reduce dependence on one link. Neither defeats every broadband disturbance, physical obstruction or compromised management function. Timing depends on the schedule, hops, retransmissions, contention rules where present and gateway processing. A theoretical radio-slot duration alone is not an end-to-end measurement freshness bound. Include sensor sampling, queueing, network transfer and application presentation.

Joining establishes that a device is permitted to enter the managed network using the supported commissioning and key process. A network identifier is not normally a secret authentication credential. Join material and operational keys need appropriate custody, distribution and replacement. Some systems distinguish joining, network and session/application keys; verify the actual standard/product version instead of assuming one key serves every purpose. A shared commissioning secret copied into uncontrolled project notes can broaden the effect of a lost laptop or contractor departure.

The network manager and gateway are high-value dependencies. The manager may build schedules and routes, while the gateway translates field data to an IP application. Their roles may be combined in one product or distributed. Protect configuration, identities, updates and recovery materials, and preserve point quality and source timing during translation. A gateway heartbeat confirms one component, not every field device's battery, route or current measurement. Monitor join changes, route health, retry rates, missed updates and key/credential lifecycle.

Battery life and maintenance affect security and availability. More frequent reporting, repeated retries or forwarding traffic can consume additional energy. A low-battery device may miss updates before failing completely, and replacement can disturb trust, calibration or physical placement. Use the vendor's supported battery/service model and site conditions rather than promising a fixed lifetime from a brochure. Plan replacement authority, identity verification, join-material handling and post-replacement signal checks. A replaced sensor with the old tag name is not automatically the same calibrated measurement chain.

Acceptance should test the required update service under credible failure conditions: one route lost, one gateway unavailable, interference within the authorised test setup, a rejected unknown join, exhausted subscription/queue state and recovery after manager restart. Keep safety functions on their approved architecture; adding a wireless status link does not authorise using it as a primary trip path. The numerical exercise here is an explicitly simplified schedule model. Official technology pages may require access controls; detailed product behaviour must be verified in the authorised practical route and current vendor documentation.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic scheduled-mesh model: sensor sampling period1.0 s; worst wait from a new physical change to sample1.0 s. Each of three sequential hops has at most100 ms scheduled wait plus10 ms transmission/processing; gateway/application adds 200 ms. Supplied model has no parallel scheduling and no retries in the base case. One retry on one hop adds 110 ms. Requirement is fresh indication within 1.5 s of physical change. Routes A and B use different relay devices but both terminate at gateway G powered by PSU-P. Join key J is shared in an unprotected contractor spreadsheet; network ID77 is printed on a label. Replacement sensor has the same tag but no calibration record.

**Reasoning:** Base worst-case bound is 1000+3×110+200=1530 ms, already30 ms beyond1.5 s. One retry raises it to 1640 ms. Alternative relays do not remove G or PSU-P as common dependencies. Network ID77 identifies the network but is not the secret; exposed J requires a bounded credential/exposure response. Sensor replacement needs identity, calibration, mapping and quality verification before its measurement is accepted. Do not infer a guaranteed bound for real WirelessHART from this invented schedule.

#### Guided practice

Find one numerical design change that could make the base model fit, then state why that is not yet field acceptance.

**Hint:** Reduce a real budget contribution and preserve all other assumptions.

**Worked solution:** If the authorised sample period becomes 0.8 s, the base bound is 800+330+200=1330 ms and one retry gives1440 ms. Actual device support, energy, schedule capacity and measured behaviour still need validation.

#### Independent task

Environment: analytical

Create a mesh service and commissioning-risk review.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L043.json

**Evidence to produce**

- Timing budget with retry case
- Common-dependency map
- Join-material custody treatment
- Replacement-sensor acceptance criteria

**Acceptance criteria**

- The base bound is 1.53 s and fails the supplied1.5 s limit.
- Route diversity is not claimed to remove shared gateway/power failure.
- The model is not represented as measured product performance.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0421 · single · calculation**

What is the base worst-case indication bound in the supplied model?

Synthetic scheduled-mesh model: sensor sampling period1.0 s; worst wait from a new physical change to sample1.0 s. Each of three sequential hops has at most100 ms scheduled wait plus10 ms transmission/processing; gateway/application adds 200 ms. Supplied model has no parallel scheduling and no retries in the base case. One retry on one hop adds 110 ms. Requirement is fresh indication within 1.5 s of physical change. Routes A and B use different relay devices but both terminate at gateway G powered by PSU-P. Join key J is shared in an unprotected contractor spreadsheet; network ID77 is printed on a label. Replacement sensor has the same tag but no calibration record.

1. 1.53 s.
2. 0.53 s, omitting the worst phase before sensor sampling.
3. 1.50 s, because the requirement is also the modelled result.
4. 1.23 s, counting only the first hop’s scheduled wait.

**Correct option(s):** 1

- Option 1: 1.0+3×0.11+0.2=1.53.
- Option 2: The requirement begins at physical change, so the one-second sampling wait is included.
- Option 3: The specified components total 1.53 s; a target is not a measurement.
- Option 4: The model specifies three sequential hops, each with its own bounded wait and transmission.

**GICSP-Q0422 · single · calculation**

What is the bound with one additional retry as defined?

Synthetic scheduled-mesh model: sensor sampling period1.0 s; worst wait from a new physical change to sample1.0 s. Each of three sequential hops has at most100 ms scheduled wait plus10 ms transmission/processing; gateway/application adds 200 ms. Supplied model has no parallel scheduling and no retries in the base case. One retry on one hop adds 110 ms. Requirement is fresh indication within 1.5 s of physical change. Routes A and B use different relay devices but both terminate at gateway G powered by PSU-P. Join key J is shared in an unprotected contractor spreadsheet; network ID77 is printed on a label. Replacement sensor has the same tag but no calibration record.

1. 1.54 s.
2. 3.06 s.
3. 1.42 s.
4. 1.64 s.

**Correct option(s):** 4

- Option 1: That adds transmission only and omits the retry's scheduled wait.
- Option 2: The model adds one hop opportunity, not a duplicate entire path.
- Option 3: A retry cannot reduce the supplied bound.
- Option 4: Add0.11 s to the 1.53 s base.

**GICSP-Q0423 · single · diagnosis**

Does the base model meet the 1.5 s requirement?

Synthetic scheduled-mesh model: sensor sampling period1.0 s; worst wait from a new physical change to sample1.0 s. Each of three sequential hops has at most100 ms scheduled wait plus10 ms transmission/processing; gateway/application adds 200 ms. Supplied model has no parallel scheduling and no retries in the base case. One retry on one hop adds 110 ms. Requirement is fresh indication within 1.5 s of physical change. Routes A and B use different relay devices but both terminate at gateway G powered by PSU-P. Join key J is shared in an unprotected contractor spreadsheet; network ID77 is printed on a label. Replacement sensor has the same tag but no calibration record.

1. No; it exceeds the limit by30 ms.
2. Yes because the difference is less than one second.
3. Yes because there are two routes.
4. No because all wireless links are prohibited.

**Correct option(s):** 1

- Option 1: A small positive excess still fails the stated criterion.
- Option 2: No such tolerance is supplied.
- Option 3: Route count does not change the specified timing arithmetic.
- Option 4: The criterion is performance-based, not a blanket prohibition.

**GICSP-Q0424 · multi · design**

Which common causes remain despite routes A and B? Select all that apply.

Synthetic scheduled-mesh model: sensor sampling period1.0 s; worst wait from a new physical change to sample1.0 s. Each of three sequential hops has at most100 ms scheduled wait plus10 ms transmission/processing; gateway/application adds 200 ms. Supplied model has no parallel scheduling and no retries in the base case. One retry on one hop adds 110 ms. Requirement is fresh indication within 1.5 s of physical change. Routes A and B use different relay devices but both terminate at gateway G powered by PSU-P. Join key J is shared in an unprotected contractor spreadsheet; network ID77 is printed on a label. Replacement sensor has the same tag but no calibration record.

1. A different network ID printed on an unrelated site label.
2. Loss of only one relay while the other complete path remains healthy.
3. PSU-P failure.
4. Gateway G failure.

**Correct option(s):** 3, 4

- Option 1: That is not a supplied shared dependency.
- Option 2: Route diversity may address that specific failure, subject to capacity.
- Option 3: The gateway's power source is shared.
- Option 4: Both routes terminate there.

**GICSP-Q0425 · single · diagnosis**

Which item is sensitive joining material in the exhibit?

Synthetic scheduled-mesh model: sensor sampling period1.0 s; worst wait from a new physical change to sample1.0 s. Each of three sequential hops has at most100 ms scheduled wait plus10 ms transmission/processing; gateway/application adds 200 ms. Supplied model has no parallel scheduling and no retries in the base case. One retry on one hop adds 110 ms. Requirement is fresh indication within 1.5 s of physical change. Routes A and B use different relay devices but both terminate at gateway G powered by PSU-P. Join key J is shared in an unprotected contractor spreadsheet; network ID77 is printed on a label. Replacement sensor has the same tag but no calibration record.

1. Join key J.
2. Network ID77 solely because it is numeric.
3. The one-second sample period.
4. The sensor's temperature unit.

**Correct option(s):** 1

- Option 1: It is the supplied credential for admission and is exposed in the spreadsheet.
- Option 2: The identifier is not automatically a secret credential.
- Option 3: Timing configuration is not the supplied authentication secret.
- Option 4: Units support interpretation, not joining authority.

**GICSP-Q0426 · single · mechanism**

What can channel hopping help reduce?

Synthetic scheduled-mesh model: sensor sampling period1.0 s; worst wait from a new physical change to sample1.0 s. Each of three sequential hops has at most100 ms scheduled wait plus10 ms transmission/processing; gateway/application adds 200 ms. Supplied model has no parallel scheduling and no retries in the base case. One retry on one hop adds 110 ms. Requirement is fresh indication within 1.5 s of physical change. Routes A and B use different relay devices but both terminate at gateway G powered by PSU-P. Join key J is shared in an unprotected contractor spreadsheet; network ID77 is printed on a label. Replacement sensor has the same tag but no calibration record.

1. Dependence on one persistently impaired narrow frequency channel.
2. Every possible broadband jammer or gateway compromise.
3. All sensor calibration error.
4. The need to authenticate joining devices.

**Correct option(s):** 1

- Option 1: Frequency diversity can avoid some narrowband interference.
- Option 2: Those can affect more than one channel or another dependency.
- Option 3: Communication scheduling does not calibrate measurement.
- Option 4: RF diversity does not establish identity.

**GICSP-Q0427 · single · mechanism**

Why can increased retries affect battery-maintenance planning?

Synthetic scheduled-mesh model: sensor sampling period1.0 s; worst wait from a new physical change to sample1.0 s. Each of three sequential hops has at most100 ms scheduled wait plus10 ms transmission/processing; gateway/application adds 200 ms. Supplied model has no parallel scheduling and no retries in the base case. One retry on one hop adds 110 ms. Requirement is fresh indication within 1.5 s of physical change. Routes A and B use different relay devices but both terminate at gateway G powered by PSU-P. Join key J is shared in an unprotected contractor spreadsheet; network ID77 is printed on a label. Replacement sensor has the same tag but no calibration record.

1. Retries consume airtime but no additional radio energy.
2. The original battery interval can be retained without reviewing changed retry duty cycle.
3. Additional radio activity can consume more energy.
4. A retry count directly measures remaining battery capacity.

**Correct option(s):** 3

- Option 1: Additional transmit/receive activity affects energy use under the actual device model.
- Option 2: Higher duty cycle can change maintenance needs even when the device model is unchanged.
- Option 3: Transmission/reception work changes the energy budget.
- Option 4: Retries indicate extra activity, not a calibrated state-of-charge measurement.

**GICSP-Q0428 · single · diagnosis**

What remains unresolved for the replacement sensor?

Synthetic scheduled-mesh model: sensor sampling period1.0 s; worst wait from a new physical change to sample1.0 s. Each of three sequential hops has at most100 ms scheduled wait plus10 ms transmission/processing; gateway/application adds 200 ms. Supplied model has no parallel scheduling and no retries in the base case. One retry on one hop adds 110 ms. Requirement is fresh indication within 1.5 s of physical change. Routes A and B use different relay devices but both terminate at gateway G powered by PSU-P. Join key J is shared in an unprotected contractor spreadsheet; network ID77 is printed on a label. Replacement sensor has the same tag but no calibration record.

1. Whether the network ID should be treated as a private key.
2. Whether the old tag string can be typed.
3. Whether the mesh supports any device at all.
4. Calibration, identity and correct mapping/quality after replacement.

**Correct option(s):** 4

- Option 1: That confuses identification with authentication.
- Option 2: The case already says it was reused.
- Option 3: Existing operation is supplied.
- Option 4: Reusing the tag name does not establish measurement equivalence.

**GICSP-Q0429 · single · diagnosis**

What would the gateway heartbeat alone fail to establish?

Synthetic scheduled-mesh model: sensor sampling period1.0 s; worst wait from a new physical change to sample1.0 s. Each of three sequential hops has at most100 ms scheduled wait plus10 ms transmission/processing; gateway/application adds 200 ms. Supplied model has no parallel scheduling and no retries in the base case. One retry on one hop adds 110 ms. Requirement is fresh indication within 1.5 s of physical change. Routes A and B use different relay devices but both terminate at gateway G powered by PSU-P. Join key J is shared in an unprotected contractor spreadsheet; network ID77 is printed on a label. Replacement sensor has the same tag but no calibration record.

1. That IP monitoring is technically possible.
2. That the gateway sent a heartbeat.
3. That there is a configured gateway.
4. Fresh healthy measurements from every downstream sensor.

**Correct option(s):** 4

- Option 1: Receipt shows an observed monitoring path.
- Option 2: The heartbeat itself establishes that bounded observation.
- Option 3: The device is explicitly present.
- Option 4: The gateway can be alive while individual routes or devices fail.

**GICSP-Q0430 · single · implementation**

What must be checked before adopting the 0.8 s sampling improvement from guided practice?

Synthetic scheduled-mesh model: sensor sampling period1.0 s; worst wait from a new physical change to sample1.0 s. Each of three sequential hops has at most100 ms scheduled wait plus10 ms transmission/processing; gateway/application adds 200 ms. Supplied model has no parallel scheduling and no retries in the base case. One retry on one hop adds 110 ms. Requirement is fresh indication within 1.5 s of physical change. Routes A and B use different relay devices but both terminate at gateway G powered by PSU-P. Join key J is shared in an unprotected contractor spreadsheet; network ID77 is printed on a label. Replacement sensor has the same tag but no calibration record.

1. Only whether0.8 is numerically less than1.0.
2. Only the number of antennas in the brochure.
3. Assume the same battery lifetime without evaluation.
4. Supported device operation, schedule capacity, energy impact and measured end-to-end behaviour.

**Correct option(s):** 4

- Option 1: That does not establish product support or field performance.
- Option 2: Antenna count does not verify the changed service.
- Option 3: Increased activity may change energy consumption.
- Option 4: Arithmetic feasibility is not implementation acceptance.

#### Recall

**Does mesh mean no single point of failure?**

No. Alternative radio paths can still share a gateway, manager, power, keys or upstream service.

**What belongs in wireless freshness?**

Sampling delay, schedule/queue waits, hops, retries, gateway processing and presentation—not just radio transmission time.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [FieldComm Group: WirelessHART](https://www.fieldcommgroup.org/technologies/wirelesshart)

### GICSP-L044 — Bluetooth, Zigbee and commissioning trust

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L043

Short-range radio is a convenience and an access path. A device near a cabinet may expose commissioning or diagnostic functions through Bluetooth Low Energy while its normal telemetry uses another network. Proximity does not establish that the operator is authorised, and practical radio range depends on antennas and environment rather than a universal room boundary. Inventory secondary radios, their enabled modes, pairing windows and administrative applications. A forgotten commissioning interface can bypass assumptions based only on the wired network map.

Bluetooth pairing establishes security material and capabilities according to the selected method; bonding stores material for later use. They are related but different lifecycle actions. LE Secure Connections improves the cryptographic exchange, but the association method still determines protection against an active intermediary. A Just Works association does not provide the same man-in-the-middle authentication as an appropriately verified numeric comparison or other authenticated method. User-interface constraints can limit choices, so the product needs a deliberate commissioning model rather than a claim that encryption alone authenticates the intended peer.

After pairing, application permissions still matter. A GATT characteristic may expose a diagnostic read, configuration write or firmware-related action. Link encryption does not automatically enforce which bonded peer may invoke each operation. Apply the supported security and application-authority requirements to sensitive characteristics. Notifications and indications have different delivery behaviours, but neither by itself proves that a physical adjustment occurred. Preserve explicit command acceptance, bounds and feedback where a configuration can affect operation.

Bond removal and device replacement need verification. Deleting a phone application may leave its bond on the controller. Resetting the controller may or may not erase keys depending on the supported reset type. A device handed to another contractor can retain authority from a previous assignment. Record both sides' trust state and confirm that revoked peers can no longer reconnect or perform sensitive actions. Keep recovery/commissioning credentials controlled and avoid a permanent open pairing mode merely because occasional maintenance is expected.

Zigbee provides mesh and application-layer capabilities under specified versions and profiles; the case here concerns a supplied legacy-compatible deployment and does not assume every newer feature. Admission, network keys and trust-centre behaviour depend on that deployment. A permitted joining window should be bounded, and commissioning material should be protected. A shared network key means compromise of one participating device can have broader implications than a single point's data, while application/link keys and supported replacement procedures may provide additional separation. Verify the actual implementation rather than transferring Bluetooth terminology directly to Zigbee.

Gateways translate radio identities and data into IP services. The gateway's northbound credentials, topic permissions and management plane can expose many downstream devices at once. Keep an authenticated radio link from becoming an unrestricted command proxy. Test denied commissioning, old bonds, expired join windows, gateway role boundaries and truthful data quality in an isolated setup. These are defensive acceptance tasks; the lesson does not instruct learners to pair with, probe or manipulate an unknown operational device. Physical access, radio use and consequential writes remain subject to the site's authorised engineering process.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic commissioning review: BLE sensor S uses LE Secure Connections with Just Works because it has no display. Controller stores bonds for contractor phone A and service tablet B. A's app was deleted after the contract, but S's bond list still contains A. Sensitive calibration GATT write requires only an encrypted link, with no application role check. Pairing mode is permanently open. A separate Zigbee deployment uses a shared network key and leaves permit-join enabled; its gateway publishes telemetry and accepts commands using one unrestricted northbound account. No physical calibration change is executed in this fixture.

**Reasoning:** Secure Connections does not make Just Works an authenticated human/peer-verification method against an active intermediary. Deleted app state does not remove S's stored bond. Encrypted-link-only access can grant every accepted bonded peer the calibration write, so add the supported role/commissioning boundary. Close or bound pairing/join windows and verify revocation on the devices. Restrict gateway northbound authority and assess the shared-key scope if a participant or commissioning record is exposed.

#### Guided practice

Write a contractor-offboarding test using only an isolated authorised replica.

**Hint:** Check device-side trust and the sensitive operation, not only the phone application.

**Worked solution:** Record approved bond inventory; revoke A through the supported process on relevant endpoints; verify A cannot reconnect or calibrate; verify B retains only its required authorised role; close commissioning mode and retain evidence. No live sensor is touched by this analytical exercise.

#### Independent task

Environment: analytical

Create a radio commissioning and offboarding specification.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L044.json

**Evidence to produce**

- Pairing/bonding trust model
- Calibration-write permission rule
- Join-window/key custody plan
- Gateway authority matrix

**Acceptance criteria**

- Just Works is not claimed to provide authenticated comparison.
- Deleting an app is not treated as device-side bond revocation.
- Radio encryption and application authorisation remain separate.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0431 · single · mechanism**

What protection should not be inferred from Just Works in the supplied BLE association?

Synthetic commissioning review: BLE sensor S uses LE Secure Connections with Just Works because it has no display. Controller stores bonds for contractor phone A and service tablet B. A's app was deleted after the contract, but S's bond list still contains A. Sensitive calibration GATT write requires only an encrypted link, with no application role check. Pairing mode is permanently open. A separate Zigbee deployment uses a shared network key and leaves permit-join enabled; its gateway publishes telemetry and accepts commands using one unrestricted northbound account. No physical calibration change is executed in this fixture.

1. Use of the LE Secure Connections key-establishment mechanism.
2. Passive-eavesdropping resistance of the properly implemented Secure Connections key exchange under its cryptographic assumptions.
3. Authenticated protection against an active intermediary equivalent to verified numeric comparison.
4. Link confidentiality from the negotiated encrypted connection, within the declared Bluetooth profile.

**Correct option(s):** 3

- Option 1: That mechanism is explicitly supplied; it does not by itself add a user-verifiable authenticated association.
- Option 2: The missing assurance concerns active intermediary authentication, not absence of all cryptographic protection.
- Option 3: The association method lacks that peer-verification step.
- Option 4: Just Works can establish encrypted communication; its key limitation here is authenticated resistance to an active intermediary.

**GICSP-Q0432 · single · mechanism**

What is the difference between pairing and bonding?

Synthetic commissioning review: BLE sensor S uses LE Secure Connections with Just Works because it has no display. Controller stores bonds for contractor phone A and service tablet B. A's app was deleted after the contract, but S's bond list still contains A. Sensitive calibration GATT write requires only an encrypted link, with no application role check. Pairing mode is permanently open. A separate Zigbee deployment uses a shared network key and leaves permit-join enabled; its gateway publishes telemetry and accepts commands using one unrestricted northbound account. No physical calibration change is executed in this fixture.

1. Pairing establishes security material; bonding stores it for later use.
2. Pairing authorises every application write, while bonding only authorises reads.
3. Pairing is only radio discovery, while bonding performs the first cryptographic exchange.
4. Bonding always means a fresh pairing exchange is required on every reconnection.

**Correct option(s):** 1

- Option 1: They describe related but distinct lifecycle actions.
- Option 2: Application permissions are separate from whether pairing material is stored.
- Option 3: Discovery precedes or supports connection; pairing is the security-material establishment process.
- Option 4: Storing trust material supports later reconnection without necessarily repeating the full original pairing process.

**GICSP-Q0433 · single · diagnosis**

Why is deleting A's app insufficient evidence of revocation?

Synthetic commissioning review: BLE sensor S uses LE Secure Connections with Just Works because it has no display. Controller stores bonds for contractor phone A and service tablet B. A's app was deleted after the contract, but S's bond list still contains A. Sensitive calibration GATT write requires only an encrypted link, with no application role check. Pairing mode is permanently open. A separate Zigbee deployment uses a shared network key and leaves permit-join enabled; its gateway publishes telemetry and accepts commands using one unrestricted northbound account. No physical calibration change is executed in this fixture.

1. Removing A’s phone application also deletes A’s bond from S.
2. The stored bond is irrelevant because no new pairing is required.
3. S still retains A's bond and may accept the corresponding credentials.
4. Deleting the application revokes the northbound gateway account as well.

**Correct option(s):** 3

- Option 1: The fixture explicitly retains the peer’s bond record.
- Option 2: Stored bonding credentials can support reconnection without a new pairing ceremony.
- Option 3: Trust state exists on the device as well as the phone.
- Option 4: The gateway identity is a separate authority boundary.

**GICSP-Q0434 · single · diagnosis**

What authority defect exists on the calibration characteristic?

Synthetic commissioning review: BLE sensor S uses LE Secure Connections with Just Works because it has no display. Controller stores bonds for contractor phone A and service tablet B. A's app was deleted after the contract, but S's bond list still contains A. Sensitive calibration GATT write requires only an encrypted link, with no application role check. Pairing mode is permanently open. A separate Zigbee deployment uses a shared network key and leaves permit-join enabled; its gateway publishes telemetry and accepts commands using one unrestricted northbound account. No physical calibration change is executed in this fixture.

1. The characteristic has a numeric identifier.
2. Only unencrypted peers can ever perform writes.
3. Any peer meeting the encrypted-link condition may write without the needed application-role restriction.
4. Encryption makes all calibration values correct.

**Correct option(s):** 3

- Option 1: Identifiers are normal and do not define permissions.
- Option 2: The supplied rule requires encryption.
- Option 3: Channel protection alone does not establish calibration authority.
- Option 4: It protects transport, not measurement validity or intent.

**GICSP-Q0435 · single · diagnosis**

What is the concern with permanently open pairing mode?

Synthetic commissioning review: BLE sensor S uses LE Secure Connections with Just Works because it has no display. Controller stores bonds for contractor phone A and service tablet B. A's app was deleted after the contract, but S's bond list still contains A. Sensitive calibration GATT write requires only an encrypted link, with no application role check. Pairing mode is permanently open. A separate Zigbee deployment uses a shared network key and leaves permit-join enabled; its gateway publishes telemetry and accepts commands using one unrestricted northbound account. No physical calibration change is executed in this fixture.

1. It disables every existing bond automatically.
2. It guarantees zero radio interference.
3. It leaves an ongoing commissioning/admission opportunity beyond a bounded maintenance need.
4. It proves an unauthorised peer has already paired.

**Correct option(s):** 3

- Option 1: No such behaviour is supplied.
- Option 2: Pairing policy does not control the RF environment.
- Option 3: The exposure should match authorised use and supported controls.
- Option 4: Opportunity is not evidence of actual admission.

**GICSP-Q0436 · single · design**

What should happen to permit-join in the supplied Zigbee commissioning design?

Synthetic commissioning review: BLE sensor S uses LE Secure Connections with Just Works because it has no display. Controller stores bonds for contractor phone A and service tablet B. A's app was deleted after the contract, but S's bond list still contains A. Sensitive calibration GATT write requires only an encrypted link, with no application role check. Pairing mode is permanently open. A separate Zigbee deployment uses a shared network key and leaves permit-join enabled; its gateway publishes telemetry and accepts commands using one unrestricted northbound account. No physical calibration change is executed in this fixture.

1. Bound it to the approved commissioning process and verify closure.
2. Assume newer Zigbee marketing features apply to this legacy deployment automatically.
3. Treat it as identical to a BLE numeric-comparison screen.
4. Leave it open because the network ID is secret.

**Correct option(s):** 1

- Option 1: Admission availability should not remain unintentionally open.
- Option 2: Version/profile capabilities must be verified.
- Option 3: Different protocols have different joining mechanisms.
- Option 4: Identifiers are not a substitute for controlled admission.

**GICSP-Q0437 · single · mechanism**

What can a shared network key broaden after one participant is compromised?

Synthetic commissioning review: BLE sensor S uses LE Secure Connections with Just Works because it has no display. Controller stores bonds for contractor phone A and service tablet B. A's app was deleted after the contract, but S's bond list still contains A. Sensitive calibration GATT write requires only an encrypted link, with no application role check. Pairing mode is permanently open. A separate Zigbee deployment uses a shared network key and leaves permit-join enabled; its gateway publishes telemetry and accepts commands using one unrestricted northbound account. No physical calibration change is executed in this fixture.

1. Nothing, because shared secrets are public by definition.
2. The site's legal authority to operate radios.
3. The scope of affected network trust beyond that participant's individual measurement.
4. Only the compromised participant’s friendly name becomes visible to other nodes.

**Correct option(s):** 3

- Option 1: Shared among members does not mean intended public disclosure.
- Option 2: Credential exposure does not grant regulatory authority.
- Option 3: Shared key material can be relevant to other members' protection.
- Option 4: Shared key exposure can affect wider traffic or membership trust depending on the deployed profile.

**GICSP-Q0438 · single · design**

Which gateway design change addresses the northbound authority problem?

Synthetic commissioning review: BLE sensor S uses LE Secure Connections with Just Works because it has no display. Controller stores bonds for contractor phone A and service tablet B. A's app was deleted after the contract, but S's bond list still contains A. Sensitive calibration GATT write requires only an encrypted link, with no application role check. Pairing mode is permanently open. A separate Zigbee deployment uses a shared network key and leaves permit-join enabled; its gateway publishes telemetry and accepts commands using one unrestricted northbound account. No physical calibration change is executed in this fixture.

1. Keep the account unrestricted but rename it readonly.
2. Remove all quality fields to simplify commands.
3. Encrypt the radio link and ignore the IP account.
4. Separate and constrain telemetry publishing and command permissions for named identities.

**Correct option(s):** 4

- Option 1: A name does not enforce permissions.
- Option 2: That reduces trustworthy context rather than authority.
- Option 3: The northbound boundary remains exposed.
- Option 4: The unrestricted account currently bridges too much authority.

**GICSP-Q0439 · multi · implementation**

Which evidence should close A's offboarding? Select all that apply.

Synthetic commissioning review: BLE sensor S uses LE Secure Connections with Just Works because it has no display. Controller stores bonds for contractor phone A and service tablet B. A's app was deleted after the contract, but S's bond list still contains A. Sensitive calibration GATT write requires only an encrypted link, with no application role check. Pairing mode is permanently open. A separate Zigbee deployment uses a shared network key and leaves permit-join enabled; its gateway publishes telemetry and accepts commands using one unrestricted northbound account. No physical calibration change is executed in this fixture.

1. Continued correct restricted operation for B.
2. Only confirm the app was deleted while leaving S’s stored bond and write capability untested.
3. Only the contractor's verbal statement that the phone is unused.
4. Device-side trust removal and denied reconnection/sensitive operations in the authorised test.

**Correct option(s):** 1, 4

- Option 1: Legitimate maintenance must retain its intended function.
- Option 2: Peer-side credentials can survive the app removal.
- Option 3: That is not a technical revocation result.
- Option 4: These establish effective revocation.

**GICSP-Q0440 · single · mechanism**

What does radio proximity fail to establish?

Synthetic commissioning review: BLE sensor S uses LE Secure Connections with Just Works because it has no display. Controller stores bonds for contractor phone A and service tablet B. A's app was deleted after the contract, but S's bond list still contains A. Sensitive calibration GATT write requires only an encrypted link, with no application role check. Pairing mode is permanently open. A separate Zigbee deployment uses a shared network key and leaves permit-join enabled; its gateway publishes telemetry and accepts commands using one unrestricted northbound account. No physical calibration change is executed in this fixture.

1. The person's authority to commission or calibrate the device.
2. That a radio signal may be received nearby.
3. That batteries may require maintenance.
4. That the device has a physical location.

**Correct option(s):** 1

- Option 1: Physical closeness is not an identity/role decision.
- Option 2: Proximity can affect reception, but that is a different claim.
- Option 3: Battery maintenance is separate from authorisation.
- Option 4: Location is not the disputed security property.

#### Recall

**Why distinguish encrypted from authorised?**

An encrypted link can still carry a command from a peer that should not have permission for that operation.

**Where must bond revocation be verified?**

At the relevant device/peer trust stores and effective reconnect/action behaviour, not only by deleting an app.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [Bluetooth SIG: security](https://www.bluetooth.com/learn-about-bluetooth/key-attributes/bluetooth-security/)
- [Connectivity Standards Alliance: Zigbee technology and security resources](https://csa-iot.org/all-solutions/zigbee/)

### GICSP-L045 — Wireless surveys, unknown access points and bounded response

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L044

A wireless assessment needs an explicit scope before collection. Identify the site, frequencies, devices, time window, permitted passive or active methods, operational contacts, data handling and stop conditions. A survey for coverage differs from a security test for admission or rogue infrastructure. Start with existing inventory, controller configuration, switch records and passive observations where those answer the question. Active association, scanning or deauthentication can affect operational clients and needs separate authority; possession of a radio adapter is not permission to use every feature.

An SSID is a network name, not a unique authenticated identity. Multiple legitimate access points can advertise the same SSID for roaming, and an unapproved device can copy it. A BSSID identifies a radio interface in the observed frame context, but MAC addresses can be changed or spoofed. Correlate the observation with controller inventory, certificates, wired attachment, physical location and approved work. An unfamiliar BSSID in a stale inventory is a finding to resolve, not automatic proof of a malicious access point.

RF location estimates are uncertain. Signal strength changes with orientation, reflections, obstacles and transmitter power. The loudest observation point can guide a physical search but does not prove the device is directly beside the receiver. Document measurement position, antenna, channel, time and uncertainty. Avoid collecting unnecessary client identifiers or payloads when management metadata and infrastructure records are sufficient. Preserve original observations, clock context and collection-tool settings so another analyst can evaluate the conclusion.

A suspected rogue access point can create several different risks: an unapproved wireless entry to the operational LAN, a client attracted to an impersonated network, an unauthorised bridge between zones, or simply RF interference from an unrelated device. Determine which relationship is evidenced. A switch MAC table can identify a wired attachment for a corresponding interface, but radio and Ethernet MACs may differ and mappings need verification. DHCP/ARP records, switch port descriptions and physical tracing can corroborate the path without assuming address equality.

Response should break the verified unauthorised path with an approved bounded action. Administratively disabling a confirmed rogue device's switch port may be appropriate when its dependencies and ownership are established; disabling an entire trunk because a radio name looks suspicious can remove legitimate alarms and control services. Coordinate with operations, preserve evidence and define rollback/stop conditions. Do not jam or transmit deauthentication against unknown nearby networks as a default response. Such actions can affect others and do not establish the device's wired authority path.

Acceptance after treatment includes the intended security outcome and retained operational service. Confirm the unapproved attachment is removed or corrected, legitimate clients still authenticate to the intended infrastructure, required telemetry meets freshness limits, and inventory/monitoring reflect the new state. Record false leads and the evidence that resolved them. A good survey report distinguishes observed facts, supported inference, unverified hypotheses and actual performed actions. The exercise here is a record analysis; it does not claim a radio survey or physical port shutdown occurred.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic survey packet: approved controller inventory lists AP1 BSSID aa:00:00:00:00:01; inventory export is 90 days old. Passive observation finds the same SSID OT-ENG from BSSID aa:00:00:00:00:02. Change ticket CH9 approved a replacement AP last week, but its serial/BSSID record is absent. Switch port Gi1/0/8 carries an engineering-room trunk with three approved services; Gi1/0/12 is an access port with an undocumented small bridge, physically confirmed by authorised staff. That bridge advertises SSID OT-FREE and connects unauthenticated clients to VLAN 60. At one location OT-ENG/02 is strongest, but no authenticated server check was recorded. No radio transmission or switch change has been performed in the exercise.

**Reasoning:** OT-ENG/02 could be the approved replacement; reconcile CH9, serial/controller data and authentication identity before attribution. Strong signal is not proof of precise location or legitimacy. The physically confirmed OT-FREE bridge creates an evidenced unauthenticated VLAN 60 path and needs an operations-approved targeted response on Gi1/0/12. Gi1/0/8 is a shared trunk and is not the supplied rogue attachment. Preserve records, verify legitimate service after any authorised treatment and update the inventory.

#### Guided practice

Separate the two AP findings into fact, inference and next evidence.

**Hint:** One has an unresolved replacement explanation; the other has a confirmed attachment and authority defect.

**Worked solution:** OT-ENG/02: observed identity claim plus stale inventory and plausible CH9 replacement, requiring reconciliation. OT-FREE: confirmed bridge onGi1/0/12 and unauthenticated VLAN 60 access, requiring bounded containment with service checks. Neither observation identifies a malicious actor.

#### Independent task

Environment: analytical

Prepare a passive-survey finding and targeted-response proposal.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L045.json

**Evidence to produce**

- Evidence/uncertainty table
- CH9 reconciliation request
- Confirmed bridge containment plan
- Post-treatment service and inventory checks

**Acceptance criteria**

- Unknown BSSID is not automatically malicious.
- The confirmed access port is distinguished from the shared trunk.
- No unperformed physical/radio action is claimed.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0441 · single · diagnosis**

What is the most defensible interpretation of OT-ENG/02 initially?

Synthetic survey packet: approved controller inventory lists AP1 BSSID aa:00:00:00:00:01; inventory export is 90 days old. Passive observation finds the same SSID OT-ENG from BSSID aa:00:00:00:00:02. Change ticket CH9 approved a replacement AP last week, but its serial/BSSID record is absent. Switch port Gi1/0/8 carries an engineering-room trunk with three approved services; Gi1/0/12 is an access port with an undocumented small bridge, physically confirmed by authorised staff. That bridge advertises SSID OT-FREE and connects unauthenticated clients to VLAN 60. At one location OT-ENG/02 is strongest, but no authenticated server check was recorded. No radio transmission or switch change has been performed in the exercise.

1. The new BSSID is confirmed rogue because it is absent from the old inventory export.
2. An unresolved inventory discrepancy with an approved-replacement hypothesis.
3. The replacement ticket proves this exact observed BSSID is authorised without serial reconciliation.
4. The strongest received signal proves OT-ENG/02 is the nearest approved AP.

**Correct option(s):** 2

- Option 1: The inventory is 90 days old and a replacement ticket provides a legitimate alternative.
- Option 2: CH9 and the stale export require reconciliation.
- Option 3: The ticket lacks the actual replacement identity record.
- Option 4: Signal strength neither authenticates the AP nor resolves its approved identity.

**GICSP-Q0442 · single · diagnosis**

Which observation establishes the concrete unauthorised network path?

Synthetic survey packet: approved controller inventory lists AP1 BSSID aa:00:00:00:00:01; inventory export is 90 days old. Passive observation finds the same SSID OT-ENG from BSSID aa:00:00:00:00:02. Change ticket CH9 approved a replacement AP last week, but its serial/BSSID record is absent. Switch port Gi1/0/8 carries an engineering-room trunk with three approved services; Gi1/0/12 is an access port with an undocumented small bridge, physically confirmed by authorised staff. That bridge advertises SSID OT-FREE and connects unauthenticated clients to VLAN 60. At one location OT-ENG/02 is strongest, but no authenticated server check was recorded. No radio transmission or switch change has been performed in the exercise.

1. The existence of a replacement ticket.
2. The confirmed OT-FREE bridge onGi1/0/12 allowing unauthenticated VLAN 60 access.
3. The90-day age of the inventory alone.
4. OT-ENG/02 having the strongest signal at one point.

**Correct option(s):** 2

- Option 1: Approval of another device does not authorise this bridge.
- Option 2: Physical attachment and effective access are supplied.
- Option 3: Staleness creates uncertainty, not a specific access path.
- Option 4: Signal strength does not establish network authority.

**GICSP-Q0443 · single · diagnosis**

Why should Gi1/0/8 not be disabled based on this packet?

Synthetic survey packet: approved controller inventory lists AP1 BSSID aa:00:00:00:00:01; inventory export is 90 days old. Passive observation finds the same SSID OT-ENG from BSSID aa:00:00:00:00:02. Change ticket CH9 approved a replacement AP last week, but its serial/BSSID record is absent. Switch port Gi1/0/8 carries an engineering-room trunk with three approved services; Gi1/0/12 is an access port with an undocumented small bridge, physically confirmed by authorised staff. That bridge advertises SSID OT-FREE and connects unauthenticated clients to VLAN 60. At one location OT-ENG/02 is strongest, but no authenticated server check was recorded. No radio transmission or switch change has been performed in the exercise.

1. The access port is safe because it is not a trunk.
2. It is a shared approved-services trunk and is not the confirmed bridge attachment.
3. Wait for the radio vendor to decide the site’s switch-change authority.
4. The trunk can be disabled without service review because unauthorised wireless traffic is suspected nearby.

**Correct option(s):** 2

- Option 1: The confirmed undocumented bridge on that port exposes VLAN 60.
- Option 2: Disabling it would affect unrelated dependencies without addressing the evidenced port.
- Option 3: The responsible site authority governs the bounded network change with vendor input as needed.
- Option 4: It carries three approved services and is not the physically confirmed bridge port.

**GICSP-Q0444 · single · diagnosis**

What does the strongest received signal at one location establish?

Synthetic survey packet: approved controller inventory lists AP1 BSSID aa:00:00:00:00:01; inventory export is 90 days old. Passive observation finds the same SSID OT-ENG from BSSID aa:00:00:00:00:02. Change ticket CH9 approved a replacement AP last week, but its serial/BSSID record is absent. Switch port Gi1/0/8 carries an engineering-room trunk with three approved services; Gi1/0/12 is an access port with an undocumented small bridge, physically confirmed by authorised staff. That bridge advertises SSID OT-FREE and connects unauthenticated clients to VLAN 60. At one location OT-ENG/02 is strongest, but no authenticated server check was recorded. No radio transmission or switch change has been performed in the exercise.

1. Only a relative RF observation under those conditions.
2. The exact physical distance to the transmitter.
3. That its authentication server is trusted.
4. The AP's administrative owner.

**Correct option(s):** 1

- Option 1: Reflections, antennas and transmit power limit precise location inference.
- Option 2: RSSI alone lacks a unique distance mapping.
- Option 3: No server-identity validation was recorded.
- Option 4: RF strength does not identify ownership.

**GICSP-Q0445 · single · implementation**

What evidence would help reconcile OT-ENG/02 with CH9?

Synthetic survey packet: approved controller inventory lists AP1 BSSID aa:00:00:00:00:01; inventory export is 90 days old. Passive observation finds the same SSID OT-ENG from BSSID aa:00:00:00:00:02. Change ticket CH9 approved a replacement AP last week, but its serial/BSSID record is absent. Switch port Gi1/0/8 carries an engineering-room trunk with three approved services; Gi1/0/12 is an access port with an undocumented small bridge, physically confirmed by authorised staff. That bridge advertises SSID OT-FREE and connects unauthenticated clients to VLAN 60. At one location OT-ENG/02 is strongest, but no authenticated server check was recorded. No radio transmission or switch change has been performed in the exercise.

1. Only a repeated SSID string.
2. Only the absence of malware alerts on an unrelated server.
3. Approved replacement serial/controller records and verified infrastructure identity.
4. Only the AP's signal being stronger than AP1.

**Correct option(s):** 3

- Option 1: It is not unique authenticated identity.
- Option 2: That does not identify the AP.
- Option 3: These connect the observed radio to the authorised change.
- Option 4: RF level does not establish approval.

**GICSP-Q0446 · single · operations**

Which collection action requires separate operational authorisation beyond the supplied passive exercise?

Synthetic survey packet: approved controller inventory lists AP1 BSSID aa:00:00:00:00:01; inventory export is 90 days old. Passive observation finds the same SSID OT-ENG from BSSID aa:00:00:00:00:02. Change ticket CH9 approved a replacement AP last week, but its serial/BSSID record is absent. Switch port Gi1/0/8 carries an engineering-room trunk with three approved services; Gi1/0/12 is an access port with an undocumented small bridge, physically confirmed by authorised staff. That bridge advertises SSID OT-FREE and connects unauthenticated clients to VLAN 60. At one location OT-ENG/02 is strongest, but no authenticated server check was recorded. No radio transmission or switch change has been performed in the exercise.

1. Reading the supplied synthetic packet.
2. Comparing CH9 with the inventory export.
3. Active association or disruptive deauthentication testing.
4. Recording the uncertainty in the stale inventory.

**Correct option(s):** 3

- Option 1: The exercise already authorises offline analysis.
- Option 2: This is a read-only evidence reconciliation.
- Option 3: These transmit and can affect clients or service.
- Option 4: Documentation is part of the analysis.

**GICSP-Q0447 · single · mechanism**

Why is a BSSID alone not conclusive device identity?

Synthetic survey packet: approved controller inventory lists AP1 BSSID aa:00:00:00:00:01; inventory export is 90 days old. Passive observation finds the same SSID OT-ENG from BSSID aa:00:00:00:00:02. Change ticket CH9 approved a replacement AP last week, but its serial/BSSID record is absent. Switch port Gi1/0/8 carries an engineering-room trunk with three approved services; Gi1/0/12 is an access port with an undocumented small bridge, physically confirmed by authorised staff. That bridge advertises SSID OT-FREE and connects unauthenticated clients to VLAN 60. At one location OT-ENG/02 is strongest, but no authenticated server check was recorded. No radio transmission or switch change has been performed in the exercise.

1. MAC identifiers can change or be spoofed and need corroboration.
2. Every AP must share one universal BSSID.
3. BSSID is the same thing as the user's password.
4. BSSIDs never appear in wireless frames.

**Correct option(s):** 1

- Option 1: The frame identifier is not a cryptographic ownership proof.
- Option 2: Devices/interfaces can have distinct identifiers.
- Option 3: It is an identifier, not a secret credential.
- Option 4: They are part of the observation context.

**GICSP-Q0448 · multi · design**

Which records should accompany passive RF observations? Select all that apply.

Synthetic survey packet: approved controller inventory lists AP1 BSSID aa:00:00:00:00:01; inventory export is 90 days old. Passive observation finds the same SSID OT-ENG from BSSID aa:00:00:00:00:02. Change ticket CH9 approved a replacement AP last week, but its serial/BSSID record is absent. Switch port Gi1/0/8 carries an engineering-room trunk with three approved services; Gi1/0/12 is an access port with an undocumented small bridge, physically confirmed by authorised staff. That bridge advertises SSID OT-FREE and connects unauthenticated clients to VLAN 60. At one location OT-ENG/02 is strongest, but no authenticated server check was recorded. No radio transmission or switch change has been performed in the exercise.

1. Only a claim that the radio was nearby.
2. Time, location, channel and collection settings.
3. Known limitations and links to corroborating infrastructure evidence.
4. Only a screenshot with no timestamp.

**Correct option(s):** 2, 3

- Option 1: That omits measurement basis and uncertainty.
- Option 2: These allow the observation to be interpreted and reproduced appropriately.
- Option 3: They separate facts from uncertain inference.
- Option 4: It lacks essential context.

**GICSP-Q0449 · single · implementation**

What is an appropriate post-treatment test for the confirmed bridge finding?

Synthetic survey packet: approved controller inventory lists AP1 BSSID aa:00:00:00:00:01; inventory export is 90 days old. Passive observation finds the same SSID OT-ENG from BSSID aa:00:00:00:00:02. Change ticket CH9 approved a replacement AP last week, but its serial/BSSID record is absent. Switch port Gi1/0/8 carries an engineering-room trunk with three approved services; Gi1/0/12 is an access port with an undocumented small bridge, physically confirmed by authorised staff. That bridge advertises SSID OT-FREE and connects unauthenticated clients to VLAN 60. At one location OT-ENG/02 is strongest, but no authenticated server check was recorded. No radio transmission or switch change has been performed in the exercise.

1. Verify the unapproved access path is gone and legitimate telemetry/authentication still meets requirements.
2. Assume all legitimate clients recovered because the switch is powered.
3. Only check that the SSID string disappears once.
4. Delete the original evidence to avoid confusion.

**Correct option(s):** 1

- Option 1: Security and operational acceptance both matter.
- Option 2: Power does not establish application service.
- Option 3: That may not prove the wired path is removed or service preserved.
- Option 4: The evidence supports accountability and learning.

**GICSP-Q0450 · single · diagnosis**

Which report statement would be false for this exercise?

Synthetic survey packet: approved controller inventory lists AP1 BSSID aa:00:00:00:00:01; inventory export is 90 days old. Passive observation finds the same SSID OT-ENG from BSSID aa:00:00:00:00:02. Change ticket CH9 approved a replacement AP last week, but its serial/BSSID record is absent. Switch port Gi1/0/8 carries an engineering-room trunk with three approved services; Gi1/0/12 is an access port with an undocumented small bridge, physically confirmed by authorised staff. That bridge advertises SSID OT-FREE and connects unauthenticated clients to VLAN 60. At one location OT-ENG/02 is strongest, but no authenticated server check was recorded. No radio transmission or switch change has been performed in the exercise.

1. “The packet is synthetic and the response is a proposal.”
2. “We shut down the physical rogue port and measured live recovery.”
3. “The supplied records identifyGi1/0/12 as the confirmed bridge attachment.”
4. “OT-ENG/02 remains unresolved pending CH9 reconciliation.”

**Correct option(s):** 2

- Option 1: That accurately states the exercise fidelity.
- Option 2: No physical switch change or live test was performed.
- Option 3: That fact is explicitly provided.
- Option 4: That is a supported bounded conclusion.

#### Recall

**SSID, BSSID and authenticated identity?**

A network name and radio identifier support discovery; neither alone proves ownership or authorised server identity.

**What makes wireless containment bounded?**

A verified path, identified dependencies, authorised targeted action, preserved evidence and security plus service acceptance checks.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [NIST SP 800-153: WLAN security](https://csrc.nist.gov/pubs/sp/800/153/final)
- [NIST SP 800-61 Rev. 3: incident response](https://csrc.nist.gov/pubs/sp/800/61/r3/final)

## GICSP-M10 — Risk-based response, continuity and trusted recovery

### GICSP-L046 — Business impact, recovery objectives and dependency timing

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L045

Risk-based continuity starts with the service and its consequence over time. Identify which process functions must continue, which can degrade, which must stop through an approved transition and which information operators need to make that decision. A business impact analysis connects disruption duration to operational, safety, contractual and business consequences. Do not substitute the purchase price of a server for the consequence of losing the alarms it hosts. Operations and process specialists define acceptable modes and limits; security and infrastructure engineers supply dependency and recovery evidence.

Recovery time objective is the targeted interval to restore the required usable service under the stated definition. Include mandatory validation and authority checks when they are required before the service is accepted for use. Booting an application before its point map and permissions are verified is not necessarily the RTO endpoint. Maximum tolerable disruption describes the outer business tolerance; the margin between it and RTO is contingency or wider business-recovery margin, not permission to omit required validation. Define when the clock starts and stops so teams measure the same claim.

Recovery point objective limits the acceptable data loss measured back from the relevant disruption point. Backup completion time is not always the newest durable source-data time. A job completed at 10:15 may contain records only through 10:02 because ingestion was delayed. The application's recoverable state, transaction-log chain and replication lag determine the actual recovery point. A fifteen-minute RPO cannot be claimed merely because a scheduler launches a job every fifteen minutes. Verify the data boundary and consistency of the recovery copy.

Dependency timing uses a critical path. Independent tasks may run in parallel if resources and procedures truly permit it; dependent tasks must wait for their prerequisites. Add only sequential durations along the longest feasible path, and include shared personnel, media and approval constraints. A plan that assumes one engineer performs two simultaneous hands-on tasks is not actually parallel. Keep uncertainty and margin visible rather than presenting an optimistic estimate as a measured guarantee.

Recovery priority is service-based. Identity, time, DNS, storage and network services may need to precede the visible historian or HMI. A backup key stored only in the unavailable directory creates a recovery deadlock. A spare controller may still require correct firmware, licences, project and calibration data. Document the recovery materials and responsible people, then exercise the sequence under representative failure conditions. A paper estimate can guide design, but actual execution and acceptance evidence are needed to establish practical capability.

Continuity can include a bounded degraded mode, but it must have its own authority, duration, staffing, measurement and stop criteria. A manual watch may compensate for a monitoring outage only if the process owner approves it and the required observations are feasible. Record which normal functions remain unavailable and how transition back will be accepted. The curriculum's near-term D4–D7 scope includes this integration and lifecycle judgment; it does not make the learner the owner of primary electrical protection or later D2/D3 specialist engineering simply because the incident affects cooling or power.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic recovery contract: disruption starts10:20. RTO120 min to accepted historian/alarm service; maximum tolerable disruption180 min; RPO15 min. Last backup completed10:15 but contains durable source records only through 10:02. Recovery tasks: platform restore30 min and independent protected-key retrieval20 min can run in parallel with separate authorised staff; database restore35 min waits for both; application configuration10 min follows database; mandatory functional/authority validation25 min follows configuration. No other dependencies or delays exist in this model. A proposal reports RTO as75 min by omitting validation and counting key retrieval as zero.

**Reasoning:** The critical path is max(30,20)+35+10+25=100 min, within 120 with 20 min target margin. The maximum-disruption margin relative to RTO is 60 min, but validation remains inside recovery. Data loss is 18 min from 10:02 to 10:20, failing the 15 min RPO by3 min despite the 10:15 job completion. The75 min claim omits required validation; key retrieval is legitimately parallel here, not absent. Real readiness still needs measured execution and dependency checks.

#### Guided practice

Recalculate if key retrieval takes 50 min while the other assumptions remain.

**Hint:** The parallel prerequisite stage ends when both tasks finish.

**Worked solution:** max(30,50)+35+10+25=120 min, exactly the RTO with no modelled margin. Any omitted delay or longer validation would exceed the target; the 18-minute recovery-point gap remains unchanged.

#### Independent task

Environment: analytical

Produce a service continuity and recovery calculation sheet.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L046.json

**Evidence to produce**

- Critical-path timeline
- RPO data-boundary assessment
- Degraded-mode authority/limits
- Exercise acceptance criteria

**Acceptance criteria**

- Mandatory validation remains inside accepted-service recovery.
- RPO uses durable source-data time rather than backup completion.
- Parallelism is supported by separate resources and explicit dependencies.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0451 · single · calculation**

What is the modelled accepted-service recovery duration?

Synthetic recovery contract: disruption starts10:20. RTO120 min to accepted historian/alarm service; maximum tolerable disruption180 min; RPO15 min. Last backup completed10:15 but contains durable source records only through 10:02. Recovery tasks: platform restore30 min and independent protected-key retrieval20 min can run in parallel with separate authorised staff; database restore35 min waits for both; application configuration10 min follows database; mandatory functional/authority validation25 min follows configuration. No other dependencies or delays exist in this model. A proposal reports RTO as75 min by omitting validation and counting key retrieval as zero.

1. 100 min.
2. 75 min.
3. 120 min.
4. 150 min.

**Correct option(s):** 1

- Option 1: max(30,20)+35+10+25=100.
- Option 2: That omits the required25-minute validation.
- Option 3: That is the objective, not the supplied base duration.
- Option 4: It incorrectly adds or duplicates parallel/dependent durations.

**GICSP-Q0452 · single · calculation**

What is the actual recoverable-data gap at disruption?

Synthetic recovery contract: disruption starts10:20. RTO120 min to accepted historian/alarm service; maximum tolerable disruption180 min; RPO15 min. Last backup completed10:15 but contains durable source records only through 10:02. Recovery tasks: platform restore30 min and independent protected-key retrieval20 min can run in parallel with separate authorised staff; database restore35 min waits for both; application configuration10 min follows database; mandatory functional/authority validation25 min follows configuration. No other dependencies or delays exist in this model. A proposal reports RTO as75 min by omitting validation and counting key retrieval as zero.

1. 15 min.
2. 18 min.
3. 0 min.
4. 5 min.

**Correct option(s):** 2

- Option 1: That is the objective, not the observed gap.
- Option 2: 10:20 minus the newest durable source record at 10:02.
- Option 3: No synchronous zero-loss recovery evidence is supplied.
- Option 4: That uses backup completion10:15 instead of data content.

**GICSP-Q0453 · single · diagnosis**

Does the backup meet the supplied RPO?

Synthetic recovery contract: disruption starts10:20. RTO120 min to accepted historian/alarm service; maximum tolerable disruption180 min; RPO15 min. Last backup completed10:15 but contains durable source records only through 10:02. Recovery tasks: platform restore30 min and independent protected-key retrieval20 min can run in parallel with separate authorised staff; database restore35 min waits for both; application configuration10 min follows database; mandatory functional/authority validation25 min follows configuration. No other dependencies or delays exist in this model. A proposal reports RTO as75 min by omitting validation and counting key retrieval as zero.

1. No;18 min exceeds15 min by3 min.
2. Yes because recovery duration is below RTO.
3. No because all backups must be continuous.
4. Yes because the backup completed five minutes before disruption.

**Correct option(s):** 1

- Option 1: The recovered data boundary is too old.
- Option 2: RTO and RPO assess different properties.
- Option 3: The requirement permits up to fifteen minutes of data loss.
- Option 4: Completion time does not identify its latest source data.

**GICSP-Q0454 · single · mechanism**

Why can platform restore and key retrieval overlap in this model?

Synthetic recovery contract: disruption starts10:20. RTO120 min to accepted historian/alarm service; maximum tolerable disruption180 min; RPO15 min. Last backup completed10:15 but contains durable source records only through 10:02. Recovery tasks: platform restore30 min and independent protected-key retrieval20 min can run in parallel with separate authorised staff; database restore35 min waits for both; application configuration10 min follows database; mandatory functional/authority validation25 min follows configuration. No other dependencies or delays exist in this model. A proposal reports RTO as75 min by omitting validation and counting key retrieval as zero.

1. Every recovery task always runs in parallel.
2. Key retrieval is unnecessary for encrypted backups.
3. The shorter task can be deleted from the plan.
4. They are independent tasks with separate authorised staff and no shared blocking dependency.

**Correct option(s):** 4

- Option 1: Later tasks have stated prerequisites.
- Option 2: The database restore waits for the protected key.
- Option 3: It still must finish even when off the critical path.
- Option 4: The exhibit explicitly supports parallel execution.

**GICSP-Q0455 · single · calculation**

What happens if key retrieval takes 50 min?

Synthetic recovery contract: disruption starts10:20. RTO120 min to accepted historian/alarm service; maximum tolerable disruption180 min; RPO15 min. Last backup completed10:15 but contains durable source records only through 10:02. Recovery tasks: platform restore30 min and independent protected-key retrieval20 min can run in parallel with separate authorised staff; database restore35 min waits for both; application configuration10 min follows database; mandatory functional/authority validation25 min follows configuration. No other dependencies or delays exist in this model. A proposal reports RTO as75 min by omitting validation and counting key retrieval as zero.

1. Recovery remains 100 minutes because platform restore is the only preparation dependency.
2. The total becomes 170 min because all tasks must be sequential.
3. Total accepted-service recovery becomes 120 min with no modelled RTO margin.
4. The longer key retrieval improves the recovery point because more time has elapsed.

**Correct option(s):** 3

- Option 1: Database restore waits for both platform and key retrieval; a 50-minute key path becomes critical.
- Option 2: Platform restore still overlaps retrieval under the supplied assumptions.
- Option 3: The prerequisite stage becomes 50 min, followed by35+10+25.
- Option 4: Waiting does not create newer recoverable source records.

**GICSP-Q0456 · single · diagnosis**

What belongs inside the RTO endpoint in this contract?

Synthetic recovery contract: disruption starts10:20. RTO120 min to accepted historian/alarm service; maximum tolerable disruption180 min; RPO15 min. Last backup completed10:15 but contains durable source records only through 10:02. Recovery tasks: platform restore30 min and independent protected-key retrieval20 min can run in parallel with separate authorised staff; database restore35 min waits for both; application configuration10 min follows database; mandatory functional/authority validation25 min follows configuration. No other dependencies or delays exist in this model. A proposal reports RTO as75 min by omitting validation and counting key retrieval as zero.

1. Only the first powered-on server.
2. All validation may be postponed beyond maximum tolerable disruption.
3. The mandatory functional and authority validation before service acceptance.
4. Only the database file copy.

**Correct option(s):** 3

- Option 1: Platform power is not the required application service.
- Option 2: That would contradict the accepted-service definition.
- Option 3: The contract defines recovery as accepted usable service.
- Option 4: Configuration and validation remain necessary.

**GICSP-Q0457 · single · mechanism**

What does the 60 min difference between maximum tolerable disruption and RTO represent?

Synthetic recovery contract: disruption starts10:20. RTO120 min to accepted historian/alarm service; maximum tolerable disruption180 min; RPO15 min. Last backup completed10:15 but contains durable source records only through 10:02. Recovery tasks: platform restore30 min and independent protected-key retrieval20 min can run in parallel with separate authorised staff; database restore35 min waits for both; application configuration10 min follows database; mandatory functional/authority validation25 min follows configuration. No other dependencies or delays exist in this model. A proposal reports RTO as75 min by omitting validation and counting key retrieval as zero.

1. A guarantee that the process can operate safely without any monitoring.
2. An additional allowable60 min of data loss.
3. Permission to exclude validation from every measurement.
4. Contingency or wider business-recovery margin under the defined plan.

**Correct option(s):** 4

- Option 1: Mode safety needs separate process authority.
- Option 2: That confuses time-to-recover with recovery point.
- Option 3: Validation remains required for accepted service.
- Option 4: It does not remove mandatory acceptance work from RTO.

**GICSP-Q0458 · single · mechanism**

Which condition can create a recovery deadlock?

Synthetic recovery contract: disruption starts10:20. RTO120 min to accepted historian/alarm service; maximum tolerable disruption180 min; RPO15 min. Last backup completed10:15 but contains durable source records only through 10:02. Recovery tasks: platform restore30 min and independent protected-key retrieval20 min can run in parallel with separate authorised staff; database restore35 min waits for both; application configuration10 min follows database; mandatory functional/authority validation25 min follows configuration. No other dependencies or delays exist in this model. A proposal reports RTO as75 min by omitting validation and counting key retrieval as zero.

1. The only backup-decryption key is stored in the unavailable identity system that needs that backup to recover.
2. Two independent staff retrieve separate materials.
3. A restore test with a recorded result.
4. A documented offline protected key escrow.

**Correct option(s):** 1

- Option 1: Each recovery path depends on the other failed prerequisite.
- Option 2: That can enable parallelism rather than deadlock.
- Option 3: Testing exposes dependencies rather than creating them.
- Option 4: Properly designed escrow can break the dependency.

**GICSP-Q0459 · multi · design**

Which properties must a degraded manual-watch mode define? Select all that apply.

Synthetic recovery contract: disruption starts10:20. RTO120 min to accepted historian/alarm service; maximum tolerable disruption180 min; RPO15 min. Last backup completed10:15 but contains durable source records only through 10:02. Recovery tasks: platform restore30 min and independent protected-key retrieval20 min can run in parallel with separate authorised staff; database restore35 min waits for both; application configuration10 min follows database; mandatory functional/authority validation25 min follows configuration. No other dependencies or delays exist in this model. A proposal reports RTO as75 min by omitting validation and counting key retrieval as zero.

1. A claim that all missing alarms are automatically unnecessary.
2. Authority, duration, staffing and feasible observations.
3. Only the phrase “operators will cope.”
4. Stop criteria and transition-back acceptance.

**Correct option(s):** 2, 4

- Option 1: Their consequences must be assessed explicitly.
- Option 2: These determine whether the temporary mode can be operated responsibly.
- Option 3: That supplies no executable or reviewable arrangement.
- Option 4: The mode needs limits and a controlled return.

**GICSP-Q0460 · single · implementation**

What is still needed beyond the 100-minute analytical estimate?

Synthetic recovery contract: disruption starts10:20. RTO120 min to accepted historian/alarm service; maximum tolerable disruption180 min; RPO15 min. Last backup completed10:15 but contains durable source records only through 10:02. Recovery tasks: platform restore30 min and independent protected-key retrieval20 min can run in parallel with separate authorised staff; database restore35 min waits for both; application configuration10 min follows database; mandatory functional/authority validation25 min follows configuration. No other dependencies or delays exist in this model. A proposal reports RTO as75 min by omitting validation and counting key retrieval as zero.

1. A backup labelled earlier without verifying its durable source-record endpoint.
2. Representative executed recovery and acceptance evidence with actual dependencies and resource constraints.
3. A more detailed estimate using the same untested task-duration assumptions.
4. A successful database copy without the mandatory authority and alarm checks.

**Correct option(s):** 2

- Option 1: RPO depends on contained recoverable data, not merely the file label.
- Option 2: A paper critical path is not field performance proof.
- Option 3: Refining the narrative does not replace a measured representative recovery exercise.
- Option 4: Accepted service includes the full declared recovery endpoint.

#### Recall

**RTO versus RPO?**

RTO concerns time to accepted usable service; RPO concerns the recoverable-data gap. They need different evidence.

**Why use a critical path?**

Parallel tasks overlap only when actual dependencies and resources permit; mandatory acceptance remains in the service-restoration path.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [NIST SP 800-61 Rev. 3: incident response](https://csrc.nist.gov/pubs/sp/800/61/r3/final)

### GICSP-L047 — Incident readiness, triage and evidence preservation

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L046

Incident response starts before an incident. Define roles, contacts, authority, escalation thresholds, communication methods, evidence handling and technical access. Include operations, control engineering, network/hardware support, security, suppliers and the organisation's legal/communications functions as relevant. A current contact list must remain available when the primary directory or messaging service fails. Exercises should test whether people can reach the required authority and obtain the necessary evidence, not merely whether a document exists.

Triage asks what function is affected, what is known, what could happen next and what action is justified now. A suspicious login and an alarm delay may be related or independent. Establish process state through trusted operational observations while the security team assesses the access and system evidence. Do not delay an authorised action needed to stabilise an immediate physical consequence solely to obtain a perfect disk image. Conversely, do not reboot every system reflexively when a bounded collection or isolation action can preserve service and evidence.

Evidence varies in volatility and collection impact. Memory, active connections, sessions, process lists and ephemeral buffers can disappear on restart; logs and disk artefacts may persist but can roll over or be modified. Collection itself can change the system or load a constrained device. Choose supported methods, competent collectors and a recorded sequence suited to the platform and consequence. An endpoint tool acceptable on a Windows engineering workstation may be inappropriate on a controller. Where direct collection is unsafe or unsupported, use passive network records, management exports and specialist-assisted acquisition.

Preserve originals and work from controlled copies where feasible. Record source, collector, authority, time, tool/version, method, system state, file identifiers, hashes and custody transfers. A hash demonstrates that the compared bytes have not changed relative to a trusted recorded digest; it does not prove the original system was truthful, the collector was authorised or the capture was complete. Keep clock offsets and time-zone meanings so later correlation does not manufacture a false event order. Protect evidence containing credentials, personal information or sensitive process details.

Incident classification and severity should reflect consequence, scope, confidence and urgency. A policy violation can require action without being a confirmed intrusion. A confirmed intrusion can initially have uncertain process impact. State those dimensions separately. Use a working hypothesis log with supporting and contradicting evidence, collection requests and decisions. Avoid attributing intent or a named actor from a single address or tool. The purpose is to guide safe response and preserve a defensible record, not to force uncertainty into a premature narrative.

Communications should give decision makers actionable facts: affected services, current operating mode, immediate risks, actions taken, pending authority decisions and next update time. External notification obligations depend on the organisation and jurisdiction and must be checked by the responsible function; this course invents no universal deadline. Retain an incident timeline that distinguishes observed events, inferred events, collection times and analyst actions. This structured readiness supports both recovery and later root-cause learning without claiming that an analytical exercise constitutes a real incident investigation.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic incident packet: at 09:10 an unknown-source remote login is accepted on engineering host E. At09:12 alarm delivery exceeds its5 s requirement, but operations confirms local control remains stable within the approved current mode. E clock is 2 min slow relative to verified UTC; gateway logs are UTC within 1 s. E's event log retains only30 min at current volume. A full disk image would take90 min and requires taking E offline; an approved lightweight session/process export takes 2 min with tested low impact. A vendor suggests immediate reboot, which would erase active-session state. The incident authority has approved bounded evidence collection while operations monitors the stated mode. No physical stability guarantee beyond that mode is supplied.

**Reasoning:** Record the clock correction and collect the approved low-impact volatile/session and near-rollover log evidence promptly while operations watches the defined mode. Preserve originals, hashes and method/custody records. Do not assume the login caused the alarm delay; correlate gateway, host and process evidence. The90-minute offline image has a different impact and needs a specific decision. Reboot would erase useful state and should follow a justified response plan, not a reflex. Escalate immediately if the approved operating-mode limits are approached.

#### Guided practice

Correct an E event stamped09:08 to the verified UTC timeline and describe its uncertainty.

**Hint:** The host clock is two minutes slow, so add two minutes; retain the basis.

**Worked solution:** Map09:08 E time to approximately09:10 UTC, with the stated offset-measurement uncertainty recorded. Do not erase the original timestamp; keep source time, normalised time and correction evidence.

#### Independent task

Environment: analytical

Produce a triage brief and proportionate evidence-collection plan.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L047.json

**Evidence to produce**

- Process-state/authority record
- Volatility and rollover priorities
- Normalised timeline with original times
- Hash/custody manifest
- Communication update

**Acceptance criteria**

- Collection choices account for operational impact and evidence loss.
- Hash integrity is not overstated as truth or completeness.
- Login/alarm correlation is a hypothesis until corroborated.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0461 · single · diagnosis**

Which collection has the strongest supplied immediate justification under the approved mode?

Synthetic incident packet: at 09:10 an unknown-source remote login is accepted on engineering host E. At09:12 alarm delivery exceeds its5 s requirement, but operations confirms local control remains stable within the approved current mode. E clock is 2 min slow relative to verified UTC; gateway logs are UTC within 1 s. E's event log retains only30 min at current volume. A full disk image would take90 min and requires taking E offline; an approved lightweight session/process export takes 2 min with tested low impact. A vendor suggests immediate reboot, which would erase active-session state. The incident authority has approved bounded evidence collection while operations monitors the stated mode. No physical stability guarantee beyond that mode is supplied.

1. Take E offline for 90 minutes without further authority.
2. Wait an hour before collecting the 30-minute event log.
3. The tested two-minute lightweight export plus near-rollover logs.
4. Reboot E before recording sessions.

**Correct option(s):** 3

- Option 1: That changes operational impact beyond the stated bounded collection.
- Option 2: Relevant records may roll over.
- Option 3: It preserves volatile/expiring evidence with approved low impact.
- Option 4: It would erase the active-state evidence identified in the packet.

**GICSP-Q0462 · single · calculation**

What UTC time corresponds to an E event stamped09:08 under the supplied offset?

Synthetic incident packet: at 09:10 an unknown-source remote login is accepted on engineering host E. At09:12 alarm delivery exceeds its5 s requirement, but operations confirms local control remains stable within the approved current mode. E clock is 2 min slow relative to verified UTC; gateway logs are UTC within 1 s. E's event log retains only30 min at current volume. A full disk image would take90 min and requires taking E offline; an approved lightweight session/process export takes 2 min with tested low impact. A vendor suggests immediate reboot, which would erase active-session state. The incident authority has approved bounded evidence collection while operations monitors the stated mode. No physical stability guarantee beyond that mode is supplied.

1. 09:06 UTC.
2. Exactly09:12 UTC.
3. Approximately09:10 UTC.
4. 09:08 UTC with no qualification.

**Correct option(s):** 3

- Option 1: That applies the correction in the wrong direction.
- Option 2: That adds four minutes rather than two.
- Option 3: A clock two minutes slow must be advanced by two minutes for correlation.
- Option 4: It ignores the measured clock offset.

**GICSP-Q0463 · single · mechanism**

What does a recorded file hash establish when later verification matches?

Synthetic incident packet: at 09:10 an unknown-source remote login is accepted on engineering host E. At09:12 alarm delivery exceeds its5 s requirement, but operations confirms local control remains stable within the approved current mode. E clock is 2 min slow relative to verified UTC; gateway logs are UTC within 1 s. E's event log retains only30 min at current volume. A full disk image would take90 min and requires taking E offline; an approved lightweight session/process export takes 2 min with tested low impact. A vendor suggests immediate reboot, which would erase active-session state. The incident authority has approved bounded evidence collection while operations monitors the stated mode. No physical stability guarantee beyond that mode is supplied.

1. The compared bytes match the recorded digest under the hash method.
2. The capture includes every relevant event.
3. The collector had legal and operational authority.
4. The original host's data was necessarily truthful.

**Correct option(s):** 1

- Option 1: It supports integrity of that copy relative to the manifest.
- Option 2: Completeness requires separate collection-scope evidence.
- Option 3: Authority is a procedural fact, not a hash property.
- Option 4: A compromised source can produce misleading but consistently hashed data.

**GICSP-Q0464 · single · diagnosis**

What is lost by the proposed immediate reboot?

Synthetic incident packet: at 09:10 an unknown-source remote login is accepted on engineering host E. At09:12 alarm delivery exceeds its5 s requirement, but operations confirms local control remains stable within the approved current mode. E clock is 2 min slow relative to verified UTC; gateway logs are UTC within 1 s. E's event log retains only30 min at current volume. A full disk image would take90 min and requires taking E offline; an approved lightweight session/process export takes 2 min with tested low impact. A vendor suggests immediate reboot, which would erase active-session state. The incident authority has approved bounded evidence collection while operations monitors the stated mode. No physical stability guarantee beyond that mode is supplied.

1. The reboot erases every historical record, including remote retained logs.
2. Active-session and other volatile state identified in the packet.
3. The reboot automatically removes approved design documents from independent storage.
4. The ability to ever recover service.

**Correct option(s):** 2

- Option 1: It primarily loses volatile local state; independent retained evidence can survive.
- Option 2: Restart changes or removes that evidence.
- Option 3: No such deletion is supplied; the material loss is active-session and other volatile state.
- Option 4: Reboot can support recovery in some plans, but its timing needs justification.

**GICSP-Q0465 · single · diagnosis**

What can be concluded about the relationship between the accepted login and alarm delay?

Synthetic incident packet: at 09:10 an unknown-source remote login is accepted on engineering host E. At09:12 alarm delivery exceeds its5 s requirement, but operations confirms local control remains stable within the approved current mode. E clock is 2 min slow relative to verified UTC; gateway logs are UTC within 1 s. E's event log retains only30 min at current volume. A full disk image would take90 min and requires taking E offline; an approved lightweight session/process export takes 2 min with tested low impact. A vendor suggests immediate reboot, which would erase active-session state. The incident authority has approved bounded evidence collection while operations monitors the stated mode. No physical stability guarantee beyond that mode is supplied.

1. The delay proves the login was authorised.
2. The login definitely caused the delay.
3. They cannot be related because local control is stable.
4. They are temporally relevant observations requiring correlation, with causality unproven.

**Correct option(s):** 4

- Option 1: Performance does not establish access authority.
- Option 2: Temporal proximity alone is insufficient.
- Option 3: Supervisory disruption can coexist with stable local control.
- Option 4: The packet provides sequence but not the causal mechanism.

**GICSP-Q0466 · single · operations**

When should the current bounded collection plan be reconsidered immediately?

Synthetic incident packet: at 09:10 an unknown-source remote login is accepted on engineering host E. At09:12 alarm delivery exceeds its5 s requirement, but operations confirms local control remains stable within the approved current mode. E clock is 2 min slow relative to verified UTC; gateway logs are UTC within 1 s. E's event log retains only30 min at current volume. A full disk image would take90 min and requires taking E offline; an approved lightweight session/process export takes 2 min with tested low impact. A vendor suggests immediate reboot, which would erase active-session state. The incident authority has approved bounded evidence collection while operations monitors the stated mode. No physical stability guarantee beyond that mode is supplied.

1. Reassess only after the remote source can be named personally.
2. When the approved operating-mode limits or process stability assumptions change.
3. Wait until the full imaging plan ends before responding to a change in the approved process mode.
4. Keep collecting under the original approval even if its stability assumptions fail.

**Correct option(s):** 2

- Option 1: Operational risk does not require completed individual attribution.
- Option 2: Physical consequence can alter response priorities.
- Option 3: Operational consequence can require immediate reassessment of collection.
- Option 4: Approval is bounded by the current conditions stated by operations.

**GICSP-Q0467 · multi · design**

Which fields belong in an evidence custody/collection record? Select all that apply.

Synthetic incident packet: at 09:10 an unknown-source remote login is accepted on engineering host E. At09:12 alarm delivery exceeds its5 s requirement, but operations confirms local control remains stable within the approved current mode. E clock is 2 min slow relative to verified UTC; gateway logs are UTC within 1 s. E's event log retains only30 min at current volume. A full disk image would take90 min and requires taking E offline; an approved lightweight session/process export takes 2 min with tested low impact. A vendor suggests immediate reboot, which would erase active-session state. The incident authority has approved bounded evidence collection while operations monitors the stated mode. No physical stability guarantee beyond that mode is supplied.

1. Only an analyst's final conclusion.
2. Original times, clock context, hashes and transfers.
3. Only preserve the renamed working file without source, collector or transfer history.
4. Source, collector, authority, method and tool/version.

**Correct option(s):** 2, 4

- Option 1: The underlying evidence path would be missing.
- Option 2: These support integrity and later correlation.
- Option 3: Custody and provenance require the original source and handling context.
- Option 4: These establish provenance and the collection process.

**GICSP-Q0468 · single · mechanism**

Why might a normal endpoint acquisition tool be unsuitable for a controller?

Synthetic incident packet: at 09:10 an unknown-source remote login is accepted on engineering host E. At09:12 alarm delivery exceeds its5 s requirement, but operations confirms local control remains stable within the approved current mode. E clock is 2 min slow relative to verified UTC; gateway logs are UTC within 1 s. E's event log retains only30 min at current volume. A full disk image would take90 min and requires taking E offline; an approved lightweight session/process export takes 2 min with tested low impact. A vendor suggests immediate reboot, which would erase active-session state. The incident authority has approved bounded evidence collection while operations monitors the stated mode. No physical stability guarantee beyond that mode is supplied.

1. Its load, compatibility and effect may be unsupported for the constrained control platform.
2. Controller evidence is irrelevant because the endpoint tool cannot run there.
3. A Windows acquisition executable is suitable for C because an engineering workstation uses Windows.
4. A matching file extension is enough to establish controller/tool compatibility.

**Correct option(s):** 1

- Option 1: Collection methods must match the system and consequence.
- Option 2: The tool may be unsuitable while controller-side evidence remains essential through supported methods.
- Option 3: The controller’s architecture and supported methods differ from the workstation.
- Option 4: Platform, resource and supported-interface constraints determine safe acquisition.

**GICSP-Q0469 · single · operations**

Which communication best supports the incident authority now?

Synthetic incident packet: at 09:10 an unknown-source remote login is accepted on engineering host E. At09:12 alarm delivery exceeds its5 s requirement, but operations confirms local control remains stable within the approved current mode. E clock is 2 min slow relative to verified UTC; gateway logs are UTC within 1 s. E's event log retains only30 min at current volume. A full disk image would take90 min and requires taking E offline; an approved lightweight session/process export takes 2 min with tested low impact. A vendor suggests immediate reboot, which would erase active-session state. The incident authority has approved bounded evidence collection while operations monitors the stated mode. No physical stability guarantee beyond that mode is supplied.

1. Only the number of log files collected.
2. Only a speculative actor name.
3. A claim that the entire site is safe indefinitely.
4. Affected alarm service, current approved process mode, evidence limits, proposed actions and next update time.

**Correct option(s):** 4

- Option 1: Volume does not explain consequence or decisions.
- Option 2: Attribution does not describe immediate service and authority needs.
- Option 3: Stability is only established within the stated mode and observation.
- Option 4: It connects facts and uncertainty to decisions.

**GICSP-Q0470 · single · operations**

How should external reporting deadlines be handled?

Synthetic incident packet: at 09:10 an unknown-source remote login is accepted on engineering host E. At09:12 alarm delivery exceeds its5 s requirement, but operations confirms local control remains stable within the approved current mode. E clock is 2 min slow relative to verified UTC; gateway logs are UTC within 1 s. E's event log retains only30 min at current volume. A full disk image would take90 min and requires taking E offline; an approved lightweight session/process export takes 2 min with tested low impact. A vendor suggests immediate reboot, which would erase active-session state. The incident authority has approved bounded evidence collection while operations monitors the stated mode. No physical stability guarantee beyond that mode is supplied.

1. The responsible function verifies applicable organisational and jurisdictional obligations.
2. Never report an OT incident externally.
3. Always report within an invented fixed72-hour rule for every site.
4. Let the first analyst publish raw evidence publicly.

**Correct option(s):** 1

- Option 1: No universal deadline is supplied by this exercise.
- Option 2: Some obligations or agreements may require it.
- Option 3: Obligations differ and require current verification.
- Option 4: Disclosure requires authority and appropriate handling.

#### Recall

**What does a hash not prove?**

Truthfulness of the source, completeness of collection or the collector’s authority; it supports byte-integrity comparison.

**What governs evidence priority in OT?**

Operational consequence, volatility, rollover, collection impact, authority and available trustworthy alternatives.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [NIST SP 800-61 Rev. 3: incident response](https://csrc.nist.gov/pubs/sp/800/61/r3/final)
- [NIST SP 800-86: forensic techniques](https://csrc.nist.gov/pubs/sp/800/86/final)

### GICSP-L048 — Containment that preserves required control and visibility

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L047

Containment limits an incident's spread or harmful capability while the organisation manages operational consequences. The right boundary depends on what the suspected system does. Isolating an office laptop and isolating the only alarm gateway are different decisions. Map the affected host's control, monitoring, identity, storage and management connections before choosing an action. Keep the current process mode and available independent observations explicit. A network action that removes the attack path but also blinds operators may need an approved alternative mode before it is acceptable.

Containment can target an account, active session, application operation, host route, switch port, firewall flow or physical component. Choose the smallest boundary that reliably addresses the evidenced risk under the authority available; “smallest” does not mean weak or symbolic. If an attacker has multiple credentials or an alternate management path, disabling one username may be insufficient. Conversely, a whole-zone disconnect may be excessive when a verified supplier session can be terminated without affecting local control. State which paths the action covers and which remain under investigation.

Existing state matters. Firewall policy changes may apply differently to established sessions, cached authorisation or application channels. Disabling account login may not terminate an existing remote desktop, token or tunnel. Verify the effect on the actual active path, then test that new unauthorised sessions cannot be established. Preserve evidence before termination when safe and authorised, but do not let collection become an excuse to allow imminent harmful action. The incident authority balances these priorities with operations using the stated consequence.

Allowlisted continuity paths require precise semantics. A gateway permitted only to read telemetry should not retain a write-capable protocol path merely because both use the same port. If application-aware enforcement is unavailable or unvalidated, the residual capability must remain visible. Alternative monitoring may use independent local instrumentation or a separate approved collector, but it must be shown available, fresh and usable by the responsible operators. A stale duplicate of the same compromised source is not an independent fallback.

Define an observation and rollback plan before making the change when conditions permit. Monitor required control stability, alarm latency, data quality, blocked-path behaviour and unexpected side effects. A rollback trigger should describe a specific unacceptable consequence and an authorised alternative, not automatically reopen a known harmful path. Sometimes the next step is a controlled process transition or another isolation boundary. Record the choice, authority, time, commands or configuration identity actually applied, and measured results. Do not fabricate execution evidence from a proposed rule.

Containment is not eradication or recovery. A disconnected compromised host can retain altered software, stolen credentials and evidence; reconnecting it after a quiet interval does not restore trust. Use the containment period to establish scope, preserve evidence, prepare trusted replacements and plan acceptance. Communicate the temporary limitations and review triggers to the next shift. A successful action has two separately tested outcomes: the unwanted capability is constrained as intended, and the authorised operational service or approved degraded mode remains within its requirements.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic containment decision: supplier session V on jump host J is observed issuing unauthorised controller-project requests to engineering host E. Local controller C continues its approved autonomous loop. Alarm collector A shares switch trunk T with J and E; cutting T removes the only current central alarm path. Independent local panel L is available but its operator watch has not yet been authorised. Rule option R blocks J→E remote-console services and explicitly terminates matching established sessions; it does not affect A→C telemetry. A separate E BMC path from management host M remains unreviewed. Approved requirement: preserve central alarm latency≤5 s while stopping V's remote-console capability. Baseline alarm latency2 s.

**Reasoning:** R directly addresses the evidenced console path while preserving the supplied telemetry flow, subject to verification. Cutting T fails the current alarm requirement unless an authorised alternative operating mode is established. Terminate and test existing as well as new V sessions. Review M→BMC as a residual path rather than claiming complete containment. Observe alarm latency/quality and controller mode after the change. Containment of V is not proof E is clean or ready for unrestricted reconnection.

#### Guided practice

Define positive and negative tests for R without executing a live change.

**Hint:** Test the prohibited capability and the required service separately.

**Worked solution:** Negative: V cannot use existing or new console sessions to E across every specified service. Positive: A→C telemetry and alarm delivery remain fresh and≤5 s in the approved mode. Review BMC access, record implementation identity/time and define an authority-led response if alarm service degrades.

#### Independent task

Environment: analytical

Prepare a containment decision record with evidence and review triggers.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L048.json

**Evidence to produce**

- Path/dependency map
- Targeted action and established-session handling
- Retained-service tests
- Residual BMC scope
- Reconnection gate

**Acceptance criteria**

- The shared trunk is not cut without an approved monitoring alternative.
- Existing-session revocation is explicitly verified.
- Containment is not represented as eradication or trusted recovery.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0471 · single · diagnosis**

Which option best matches the supplied immediate containment requirement?

Synthetic containment decision: supplier session V on jump host J is observed issuing unauthorised controller-project requests to engineering host E. Local controller C continues its approved autonomous loop. Alarm collector A shares switch trunk T with J and E; cutting T removes the only current central alarm path. Independent local panel L is available but its operator watch has not yet been authorised. Rule option R blocks J→E remote-console services and explicitly terminates matching established sessions; it does not affect A→C telemetry. A separate E BMC path from management host M remains unreviewed. Approved requirement: preserve central alarm latency≤5 s while stopping V's remote-console capability. Baseline alarm latency2 s.

1. Block the BMC path alone and leave J→E unchanged.
2. R, followed by verification of console denial and alarm service.
3. Disable future V logins and leave established sessions until their normal timeout.
4. Cut trunk T because it removes the remote session with fewer rules.

**Correct option(s):** 2

- Option 1: The observed unauthorised remote-console capability uses J→E; BMC is an additional unresolved path.
- Option 2: It targets the evidenced path without the stated telemetry disruption.
- Option 3: The requirement is to stop V’s current capability; the active session remains usable.
- Option 4: It also removes the required central alarm path, violating the stated constraint.

**GICSP-Q0472 · single · diagnosis**

Why is cutting T operationally different from applying R?

Synthetic containment decision: supplier session V on jump host J is observed issuing unauthorised controller-project requests to engineering host E. Local controller C continues its approved autonomous loop. Alarm collector A shares switch trunk T with J and E; cutting T removes the only current central alarm path. Independent local panel L is available but its operator watch has not yet been authorised. Rule option R blocks J→E remote-console services and explicitly terminates matching established sessions; it does not affect A→C telemetry. A separate E BMC path from management host M remains unreviewed. Approved requirement: preserve central alarm latency≤5 s while stopping V's remote-console capability. Baseline alarm latency2 s.

1. R automatically rebuilds E's firmware.
2. T also carries the only current central alarm path.
3. A trunk can never carry remote-console traffic.
4. Cutting T proves the BMC is clean.

**Correct option(s):** 2

- Option 1: A network rule does not eradicate host compromise.
- Option 2: Its isolation removes a required service dependency.
- Option 3: It can carry several approved or unwanted flows.
- Option 4: Disconnection provides no firmware-integrity evidence.

**GICSP-Q0473 · single · implementation**

What must be verified about V after R is applied in an authorised exercise?

Synthetic containment decision: supplier session V on jump host J is observed issuing unauthorised controller-project requests to engineering host E. Local controller C continues its approved autonomous loop. Alarm collector A shares switch trunk T with J and E; cutting T removes the only current central alarm path. Independent local panel L is available but its operator watch has not yet been authorised. Rule option R blocks J→E remote-console services and explicitly terminates matching established sessions; it does not affect A→C telemetry. A separate E BMC path from management host M remains unreviewed. Approved requirement: preserve central alarm latency≤5 s while stopping V's remote-console capability. Baseline alarm latency2 s.

1. Only that V's display name disappears from a dashboard.
2. Only that the firewall rule description contains V.
3. Only that J still responds to ping.
4. Both its established sessions and new console attempts are denied as specified.

**Correct option(s):** 4

- Option 1: Presentation does not establish session termination.
- Option 2: Rule text is not runtime enforcement evidence.
- Option 3: Host reachability does not test console capability.
- Option 4: New-login denial alone can leave active authority.

**GICSP-Q0474 · single · diagnosis**

How should the M→BMC path be represented?

Synthetic containment decision: supplier session V on jump host J is observed issuing unauthorised controller-project requests to engineering host E. Local controller C continues its approved autonomous loop. Alarm collector A shares switch trunk T with J and E; cutting T removes the only current central alarm path. Independent local panel L is available but its operator watch has not yet been authorised. Rule option R blocks J→E remote-console services and explicitly terminates matching established sessions; it does not affect A→C telemetry. A separate E BMC path from management host M remains unreviewed. Approved requirement: preserve central alarm latency≤5 s while stopping V's remote-console capability. Baseline alarm latency2 s.

1. Automatically blocked because J→E is blocked.
2. Irrelevant because the guest OS is the only trust layer.
3. An unreviewed residual authority path requiring scope investigation.
4. Automatically malicious because it uses BMC.

**Correct option(s):** 3

- Option 1: It is a separate supplied management route.
- Option 2: BMC authority can affect the platform independently.
- Option 3: The chosen rule does not address it.
- Option 4: Management access can be legitimate; its state and authority need evidence.

**GICSP-Q0475 · single · diagnosis**

Can panel L immediately replace central alarms under the current evidence?

Synthetic containment decision: supplier session V on jump host J is observed issuing unauthorised controller-project requests to engineering host E. Local controller C continues its approved autonomous loop. Alarm collector A shares switch trunk T with J and E; cutting T removes the only current central alarm path. Independent local panel L is available but its operator watch has not yet been authorised. Rule option R blocks J→E remote-console services and explicitly terminates matching established sessions; it does not affect A→C telemetry. A separate E BMC path from management host M remains unreviewed. Approved requirement: preserve central alarm latency≤5 s while stopping V's remote-console capability. Baseline alarm latency2 s.

1. Yes; any local display is automatically equivalent to the central alarm service.
2. No local panel can ever support continuity.
3. Only if the supplier session approves it.
4. Not as an accepted operating mode until the required watch and authority are established.

**Correct option(s):** 4

- Option 1: Coverage, staffing and response differ.
- Option 2: It may support an approved bounded alternative.
- Option 3: Operational authority is not delegated to the suspect remote session.
- Option 4: Availability of a panel does not itself approve the staffing/response arrangement.

**GICSP-Q0476 · single · operations**

What does a post-change alarm latency of 6 s mean under the supplied requirement?

Synthetic containment decision: supplier session V on jump host J is observed issuing unauthorised controller-project requests to engineering host E. Local controller C continues its approved autonomous loop. Alarm collector A shares switch trunk T with J and E; cutting T removes the only current central alarm path. Independent local panel L is available but its operator watch has not yet been authorised. Rule option R blocks J→E remote-console services and explicitly terminates matching established sessions; it does not affect A→C telemetry. A separate E BMC path from management host M remains unreviewed. Approved requirement: preserve central alarm latency≤5 s while stopping V's remote-console capability. Baseline alarm latency2 s.

1. The rule must be removed instantly regardless of the active threat.
2. Containment is fully accepted because console traffic is blocked.
3. The retained-service criterion fails and requires the predefined authority-led response.
4. The original2 s baseline no longer matters at all.

**Correct option(s):** 3

- Option 1: The response may require a safer alternative, not automatic reopening.
- Option 2: Security and operational outcomes are separate criteria.
- Option 3: Six seconds exceeds the five-second limit.
- Option 4: It remains useful comparison evidence though the criterion is five seconds.

**GICSP-Q0477 · single · mechanism**

Why is a read/write protocol port allow insufficient evidence of telemetry-only continuity?

Synthetic containment decision: supplier session V on jump host J is observed issuing unauthorised controller-project requests to engineering host E. Local controller C continues its approved autonomous loop. Alarm collector A shares switch trunk T with J and E; cutting T removes the only current central alarm path. Independent local panel L is available but its operator watch has not yet been authorised. Rule option R blocks J→E remote-console services and explicitly terminates matching established sessions; it does not affect A→C telemetry. A separate E BMC path from management host M remains unreviewed. Approved requirement: preserve central alarm latency≤5 s while stopping V's remote-console capability. Baseline alarm latency2 s.

1. Encrypting the shared service makes its write operations read-only to the application.
2. Telemetry-only continuity requires a data diode in every possible architecture.
3. The same transport service may carry consequential writes.
4. A transport firewall provides no useful boundary at all.

**Correct option(s):** 3

- Option 1: Encryption protects transport data; it does not change operation semantics.
- Option 2: The requirement can be met by a validated design; the issue is proving operation restriction on this shared service.
- Option 3: Operation-level enforcement or an explicit residual capability is needed.
- Option 4: It can restrict paths while lacking the application semantics needed for this particular read/write claim.

**GICSP-Q0478 · multi · design**

Which observations belong in the containment log? Select all that apply.

Synthetic containment decision: supplier session V on jump host J is observed issuing unauthorised controller-project requests to engineering host E. Local controller C continues its approved autonomous loop. Alarm collector A shares switch trunk T with J and E; cutting T removes the only current central alarm path. Independent local panel L is available but its operator watch has not yet been authorised. Rule option R blocks J→E remote-console services and explicitly terminates matching established sessions; it does not affect A→C telemetry. A separate E BMC path from management host M remains unreviewed. Approved requirement: preserve central alarm latency≤5 s while stopping V's remote-console capability. Baseline alarm latency2 s.

1. Authority, exact action identity/time and verified blocked capability.
2. Required-service performance, quality and remaining limitations.
3. Only the analyst's belief that the attacker left.
4. A claim that proposed commands were executed when they were only drafted.

**Correct option(s):** 1, 2

- Option 1: These establish what was done and its effect.
- Option 2: They support operational acceptance and handover.
- Option 3: Belief is not a tested outcome.
- Option 4: That would fabricate evidence.

**GICSP-Q0479 · single · recovery**

What is required before E returns to unrestricted service?

Synthetic containment decision: supplier session V on jump host J is observed issuing unauthorised controller-project requests to engineering host E. Local controller C continues its approved autonomous loop. Alarm collector A shares switch trunk T with J and E; cutting T removes the only current central alarm path. Independent local panel L is available but its operator watch has not yet been authorised. Rule option R blocks J→E remote-console services and explicitly terminates matching established sessions; it does not affect A→C telemetry. A separate E BMC path from management host M remains unreviewed. Approved requirement: preserve central alarm latency≤5 s while stopping V's remote-console capability. Baseline alarm latency2 s.

1. Only a successful ping from J.
2. An updated endpoint hostname without resolving project, credential and management-plane trust.
3. A quiet ten-minute period with no alerts.
4. The defined trusted-recovery and acceptance gate, including scope and credential/platform checks.

**Correct option(s):** 4

- Option 1: Connectivity does not establish trust.
- Option 2: Renaming does not establish trusted return to service.
- Option 3: Quiet can result from containment or lost visibility.
- Option 4: Isolation alone does not remove persistence or stolen authority.

**GICSP-Q0480 · single · design**

What should a rollback trigger do in an incident containment plan?

Synthetic containment decision: supplier session V on jump host J is observed issuing unauthorised controller-project requests to engineering host E. Local controller C continues its approved autonomous loop. Alarm collector A shares switch trunk T with J and E; cutting T removes the only current central alarm path. Independent local panel L is available but its operator watch has not yet been authorised. Rule option R blocks J→E remote-console services and explicitly terminates matching established sessions; it does not affect A→C telemetry. A separate E BMC path from management host M remains unreviewed. Approved requirement: preserve central alarm latency≤5 s while stopping V's remote-console capability. Baseline alarm latency2 s.

1. Erase the evidence so the original state is easier to reproduce.
2. Guarantee that all process modes have identical consequences.
3. Identify unacceptable side effects and an authorised safe alternative response.
4. Automatically restore every previous connection whenever any alarm appears.

**Correct option(s):** 3

- Option 1: Evidence preservation remains necessary.
- Option 2: Consequences depend on the current approved mode.
- Option 3: It should not blindly reopen a harmful path.
- Option 4: That can re-enable the evidenced threat without assessment.

#### Recall

**Containment versus eradication?**

Containment limits capability/spread; eradication removes the cause/persistence. Neither alone proves accepted trusted recovery.

**Why test existing sessions?**

Account or policy changes can block new access while cached tokens, tunnels or established sessions remain active.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [NIST SP 800-61 Rev. 3: incident response](https://csrc.nist.gov/pubs/sp/800/61/r3/final)

### GICSP-L049 — Trusted rebuild, credential renewal and return to service

Estimated study time: 50 minutes before independent work. Prerequisite chapters: GICSP-L048

Trusted recovery rebuilds a justified basis for operation. Restoring availability alone can reintroduce the same persistence, credential exposure or unauthorised project. Start with incident scope and the trust layers that may be affected: hardware/BMC, firmware, boot chain, operating system, application/toolchain, controller logic, runtime state, identity, certificates and backups. Evidence may exclude some layers, but an unsupported assumption should not. The recovery authority decides the required assurance and residual uncertainty using the consequence and available methods.

Choose recovery materials with provenance and compatibility. A backup made after the suspected modification may faithfully restore the unwanted state. A known-good earlier project may require a particular firmware, library, licence or schema. Verify signatures/hashes against trusted references, retain the acquisition path and test compatibility in an isolated environment where possible. Secure boot or a valid image signature supports specified integrity properties but does not prove correct configuration, absence of every firmware compromise or appropriate process behaviour.

Credential treatment follows exposure and authority. Rebuilding a host does not revoke a stolen password, client certificate, API token or BMC account. Renew or revoke affected secrets through the supported mechanisms, terminate existing sessions as required and verify that old credentials fail on every relevant path. Avoid restoring a directory or application database that re-enables departed users or obsolete supplier roles. A recovery copy's identity state must be reconciled with the current approved authority baseline.

Restore in dependency order. Trusted platform access and storage/network services may precede identity/time/name services, which in turn support applications and controller engineering tools. Use an isolated recovery network and controlled data transfer where the plan requires it. Validate each layer before granting it the authority to restore the next. This order is not universally identical across systems; document the actual prerequisites and a supported emergency route that avoids circular dependencies. Preserve forensic originals separately from the recovery build.

Controller recovery includes more than the approved programme. Verify hardware configuration, firmware compatibility, task settings, communication parameters, retained values, recipes, calibration/scaling, forces, bypasses, time and local/remote modes. A restored source file cannot establish that a physical valve is aligned or an interlock is intact. Coordinate functional tests with operations and relevant specialists, preserving independent protection. Negative permission tests and degraded/recovery cases are part of acceptance alongside nominal values.

Return to service is an explicit decision with evidence. Define the required functional performance, data freshness, alarm behaviour, authority, monitoring, backup capability and remaining restrictions. Have an independent competent reviewer assess consequential results and deviations. Stage reconnection if that reduces consequence and supports observation. Record the accepted baseline and monitor for recurrence under a defined period and thresholds; a quiet screen without healthy telemetry is not evidence of restored trust. Unfinished checks remain open, and a conditional operating mode must state its owner, limits and expiry rather than silently becoming permanent.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic recovery packet: incident scope includes engineering host E and possible exposure of its service token and BMC password. Backup B-new was created after the unauthorised project change; B-old predates it and has trusted provenance, but requires firmware10.4/tool5.2/library3.1. Replacement host has a clean OS but BMC still contains unknown admin temp9. Directory restore from B-old reintroduces departed supplier account V. Controller project matches the approved source, yet force table holds input pressure_ok=TRUE and retained setpoint is outside the current approved range. Recovery checklist marks “OS boots” as full acceptance. Independent protection remains outside the experimental authority.

**Reasoning:** B-new is not a known-good source merely because it is recent. Validate B-old's compatibility and the current authority changes it lacks. Clean OS does not close temp9 or stolen token/BMC credentials; investigate and remediate those trust layers through supported methods, revoke old authority and verify denial. Project equality does not close the force or retained-setpoint defects. Full acceptance needs functional, authority, monitoring and process-state evidence with independent review, while preserving protection boundaries.

#### Guided practice

Define a minimum return-to-service gate for this packet.

**Hint:** Include every supplied unresolved trust/state layer and required operation.

**Worked solution:** Trusted compatible platform/toolchain; resolved BMC identity and credential exposure; current directory roles with V denied; approved controller logic plus cleared/authorised forces and in-range retained state; verified alarms/freshness, negative permissions, recovery materials and independent acceptance. Any missing evidence remains a stated hold or bounded exception.

#### Independent task

Environment: analytical

Produce a trusted-recovery plan and accept/hold decision record.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L049.json

**Evidence to produce**

- Recovery-source provenance/compatibility table
- Credential and session revocation matrix
- Controller runtime-state checks
- Functional/security acceptance evidence
- Independent decision and residual gaps

**Acceptance criteria**

- Clean OS is not treated as complete platform trust.
- Restored historical identity state is reconciled with current authority.
- Project equality does not substitute for force/retained-state and physical checks.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0481 · single · recovery**

Why is B-new unsuitable as an automatically trusted recovery source?

Synthetic recovery packet: incident scope includes engineering host E and possible exposure of its service token and BMC password. Backup B-new was created after the unauthorised project change; B-old predates it and has trusted provenance, but requires firmware10.4/tool5.2/library3.1. Replacement host has a clean OS but BMC still contains unknown admin temp9. Directory restore from B-old reintroduces departed supplier account V. Controller project matches the approved source, yet force table holds input pressure_ok=TRUE and retained setpoint is outside the current approved range. Recovery checklist marks “OS boots” as full acceptance. Independent protection remains outside the experimental authority.

1. It was captured after the unauthorised project change.
2. B-new is trusted because it is the most recent successful backup.
3. Both backups are equivalent because their filenames refer to the same host.
4. B-old is automatically usable without checking firmware, tool and library dependencies.

**Correct option(s):** 1

- Option 1: It may preserve the unwanted modification.
- Option 2: It was created after the unauthorised change and may preserve that state.
- Option 3: Creation time, provenance and content can differ despite a common host label.
- Option 4: The supplied trusted backup has explicit compatibility requirements.

**GICSP-Q0482 · single · diagnosis**

What remains unresolved despite the replacement host's clean OS?

Synthetic recovery packet: incident scope includes engineering host E and possible exposure of its service token and BMC password. Backup B-new was created after the unauthorised project change; B-old predates it and has trusted provenance, but requires firmware10.4/tool5.2/library3.1. Replacement host has a clean OS but BMC still contains unknown admin temp9. Directory restore from B-old reintroduces departed supplier account V. Controller project matches the approved source, yet force table holds input pressure_ok=TRUE and retained setpoint is outside the current approved range. Recovery checklist marks “OS boots” as full acceptance. Independent protection remains outside the experimental authority.

1. Whether the controller has a project.
2. Whether any recovery materials exist.
3. BMC account temp9 and the exposed token/password authority.
4. Whether the OS booted at all.

**Correct option(s):** 3

- Option 1: It has a matching source project but problematic runtime state.
- Option 2: B-old is supplied, though not fully validated.
- Option 3: These trust paths survive an OS-only rebuild.
- Option 4: The supplied checklist confirms boot.

**GICSP-Q0483 · single · diagnosis**

What is the risk of restoring directory state from B-old unchanged?

Synthetic recovery packet: incident scope includes engineering host E and possible exposure of its service token and BMC password. Backup B-new was created after the unauthorised project change; B-old predates it and has trusted provenance, but requires firmware10.4/tool5.2/library3.1. Replacement host has a clean OS but BMC still contains unknown admin temp9. Directory restore from B-old reintroduces departed supplier account V. Controller project matches the approved source, yet force table holds input pressure_ok=TRUE and retained setpoint is outside the current approved range. Recovery checklist marks “OS boots” as full acceptance. Independent protection remains outside the experimental authority.

1. It automatically rotates every exposed token.
2. It re-enables departed supplier V's authority.
3. It necessarily improves revocation because older is always safer.
4. It makes BMC accounts irrelevant.

**Correct option(s):** 2

- Option 1: A restore may reinstate the same secrets instead.
- Option 2: Historical identity state may not match current approved access.
- Option 3: Age does not preserve later deprovisioning decisions.
- Option 4: The BMC is a separate authority layer.

**GICSP-Q0484 · single · diagnosis**

Why is project-source equality insufficient for controller acceptance?

Synthetic recovery packet: incident scope includes engineering host E and possible exposure of its service token and BMC password. Backup B-new was created after the unauthorised project change; B-old predates it and has trusted provenance, but requires firmware10.4/tool5.2/library3.1. Replacement host has a clean OS but BMC still contains unknown admin temp9. Directory restore from B-old reintroduces departed supplier account V. Controller project matches the approved source, yet force table holds input pressure_ok=TRUE and retained setpoint is outside the current approved range. Recovery checklist marks “OS boots” as full acceptance. Independent protection remains outside the experimental authority.

1. Retained setpoints cannot affect equipment because they are not executable code.
2. Source comparison is irrelevant once the controller runs.
3. Forces and retained setpoints can alter runtime behaviour outside the source comparison.
4. Restoring source removes every force automatically on the supplied system.

**Correct option(s):** 3

- Option 1: Retained data can change the behaviour of otherwise approved logic.
- Option 2: It is useful but incomplete without forces, retained state and other runtime evidence.
- Option 3: The supplied active-state defects remain.
- Option 4: The fixture explicitly retains pressure_ok=TRUE as a separate runtime condition.

**GICSP-Q0485 · single · implementation**

Which verification addresses stolen service-token exposure?

Synthetic recovery packet: incident scope includes engineering host E and possible exposure of its service token and BMC password. Backup B-new was created after the unauthorised project change; B-old predates it and has trusted provenance, but requires firmware10.4/tool5.2/library3.1. Replacement host has a clean OS but BMC still contains unknown admin temp9. Directory restore from B-old reintroduces departed supplier account V. Controller project matches the approved source, yet force table holds input pressure_ok=TRUE and retained setpoint is outside the current approved range. Recovery checklist marks “OS boots” as full acceptance. Independent protection remains outside the experimental authority.

1. Rename the token file without changing the credential.
2. Only reboot the replacement host.
3. Revoke/renew through the supported mechanism and confirm the old token and relevant sessions no longer work.
4. Changing the application display settings while retaining the exposed token.

**Correct option(s):** 3

- Option 1: Its authority remains.
- Option 2: Remote services may still accept the stolen token.
- Option 3: Rebuilding files does not remove external credential authority.
- Option 4: Presentation changes do not remove the credential’s authority.

**GICSP-Q0486 · single · recovery**

What must be established before using B-old with the replacement environment?

Synthetic recovery packet: incident scope includes engineering host E and possible exposure of its service token and BMC password. Backup B-new was created after the unauthorised project change; B-old predates it and has trusted provenance, but requires firmware10.4/tool5.2/library3.1. Replacement host has a clean OS but BMC still contains unknown admin temp9. Directory restore from B-old reintroduces departed supplier account V. Controller project matches the approved source, yet force table holds input pressure_ok=TRUE and retained setpoint is outside the current approved range. Recovery checklist marks “OS boots” as full acceptance. Independent protection remains outside the experimental authority.

1. Assume the newer recovery tool produces identical behaviour without checking the required compiler and library.
2. Accept B-old because its name sorts before the incident backup.
3. Compatibility with firmware10.4, tool5.2, library3.1 and required recovery dependencies.
4. Only that the archive can be decompressed.

**Correct option(s):** 3

- Option 1: The recovery packet specifies exact dependencies that need verification.
- Option 2: Ordering by name does not verify provenance, compatibility or recoverable state.
- Option 3: Trusted provenance alone does not make a build executable on any platform.
- Option 4: Extracted files may still require unavailable tools or schemas.

**GICSP-Q0487 · single · diagnosis**

Which outcome is a justified acceptance hold?

Synthetic recovery packet: incident scope includes engineering host E and possible exposure of its service token and BMC password. Backup B-new was created after the unauthorised project change; B-old predates it and has trusted provenance, but requires firmware10.4/tool5.2/library3.1. Replacement host has a clean OS but BMC still contains unknown admin temp9. Directory restore from B-old reintroduces departed supplier account V. Controller project matches the approved source, yet force table holds input pressure_ok=TRUE and retained setpoint is outside the current approved range. Recovery checklist marks “OS boots” as full acceptance. Independent protection remains outside the experimental authority.

1. Unknown BMC administration, unrevoked exposed credentials or unresolved force/setpoint state.
2. A documented current role baseline with V denied.
3. A verified compatible toolchain with protected provenance.
4. A fully tested approved alarm response within criterion.

**Correct option(s):** 1

- Option 1: Each leaves a concrete trust or behaviour gap.
- Option 2: That supports authority restoration.
- Option 3: That supports recovery trust.
- Option 4: That is positive evidence, not itself a hold.

**GICSP-Q0488 · multi · design**

Which checks belong in return-to-service acceptance? Select all that apply.

Synthetic recovery packet: incident scope includes engineering host E and possible exposure of its service token and BMC password. Backup B-new was created after the unauthorised project change; B-old predates it and has trusted provenance, but requires firmware10.4/tool5.2/library3.1. Replacement host has a clean OS but BMC still contains unknown admin temp9. Directory restore from B-old reintroduces departed supplier account V. Controller project matches the approved source, yet force table holds input pressure_ok=TRUE and retained setpoint is outside the current approved range. Recovery checklist marks “OS boots” as full acceptance. Independent protection remains outside the experimental authority.

1. Monitoring health, recovery capability and independent review of consequential results.
2. Only a quiet dashboard with no sensor-health check.
3. Only OS boot completion.
4. Functional freshness/alarms and denied obsolete authority.

**Correct option(s):** 1, 4

- Option 1: These support sustained operation and accountable acceptance.
- Option 2: Silence can reflect lost visibility.
- Option 3: It omits application, identity, controller and physical-state requirements.
- Option 4: Usable service and security boundaries both need evidence.

**GICSP-Q0489 · order · implementation**

For this simplified recovery plan, each step explicitly requires the preceding step to pass. Order the steps.

Synthetic recovery packet: incident scope includes engineering host E and possible exposure of its service token and BMC password. Backup B-new was created after the unauthorised project change; B-old predates it and has trusted provenance, but requires firmware10.4/tool5.2/library3.1. Replacement host has a clean OS but BMC still contains unknown admin temp9. Directory restore from B-old reintroduces departed supplier account V. Controller project matches the approved source, yet force table holds input pressure_ok=TRUE and retained setpoint is outside the current approved range. Recovery checklist marks “OS boots” as full acceptance. Independent protection remains outside the experimental authority.

1. Establish verified recovery materials and supported platform access
2. Restore the application/controller baseline and reconcile runtime/identity state
3. Independently review functional, negative-authority and monitoring results
4. Validate required storage/network and identity/time prerequisites
5. Authorise staged return to the required operating mode

**Correct sequence:** 1, 4, 2, 3, 5

- Option 1: Materials and trusted access are the first stated prerequisite.
- Option 2: Baseline restoration depends on the verified underlying services.
- Option 3: Review follows implementation and its acceptance tests.
- Option 4: These services must work before the dependent application restore.
- Option 5: Return follows the independent review and authorised decision.

**GICSP-Q0490 · single · operations**

What should a conditional operating acceptance state?

Synthetic recovery packet: incident scope includes engineering host E and possible exposure of its service token and BMC password. Backup B-new was created after the unauthorised project change; B-old predates it and has trusted provenance, but requires firmware10.4/tool5.2/library3.1. Replacement host has a clean OS but BMC still contains unknown admin temp9. Directory restore from B-old reintroduces departed supplier account V. Controller project matches the approved source, yet force table holds input pressure_ok=TRUE and retained setpoint is outside the current approved range. Recovery checklist marks “OS boots” as full acceptance. Independent protection remains outside the experimental authority.

1. Only “accepted” with every unfinished check deleted.
2. Owner, permitted mode, remaining gaps, monitoring, limits and expiry/review trigger.
3. A guarantee of all future incident-free operation.
4. That D2/D3 protection engineering is now authorised by an OS rebuild.

**Correct option(s):** 2

- Option 1: That hides the actual assurance boundary.
- Option 2: A bounded exception must remain visible and controlled.
- Option 3: The evidence cannot establish that universal claim.
- Option 4: The recovery task does not expand specialist authority.

#### Recall

**Why reconcile identities after restoring old backups?**

The backup may predate account removal, role changes or credential revocation and can reintroduce obsolete authority.

**What is trusted return to service?**

Verified platform, configuration, runtime state, authority and required process function, with monitoring/recovery evidence and an accountable acceptance decision.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [NIST SP 800-61 Rev. 3: incident response](https://csrc.nist.gov/pubs/sp/800/61/r3/final)
- [NIST SP 800-193: firmware resiliency](https://csrc.nist.gov/pubs/sp/800/193/final)

### GICSP-L050 — Integrated lifecycle exercise and defensible competence claims

Estimated study time: 90 minutes before independent work. Prerequisite chapters: GICSP-L049

A capstone should test a connected service under change and failure, not merely combine screenshots from unrelated labs. Define the service boundary, required functions, authority, dependencies and acceptance criteria. For this programme the near-term ownership target is D4–D7: networks, mandatory integral IT hardware, OT/control systems and cybersecurity. Power and cooling knowledge supports integration and safe interfaces; later D2/D3 specialist engineering requires additional teaching and practical evidence. D1 civil, structural and architectural engineering remains excluded. A cybersecurity course cannot erase these scope boundaries by using a power-related example.

The charter requires the same nine lifecycle responsibilities throughout development: design, implementation, commissioning, day-to-day operations, maintenance, optimisation, troubleshooting, incident response and recovery. Link a meaningful personal evidence item to each. Design should explain the alternatives and consequences behind the chosen architecture. Implementation should identify the actual baseline and personal work. Commissioning should test positive, negative, degraded and recovery requirements. Operations needs sustained observations and handover, while maintenance needs supported methods and post-work checks. Optimisation must show measured benefit without sacrificing required authority, freshness or reliability.

Troubleshooting begins with competing hypotheses and discriminating evidence. A slow display could result from polling schedule, serial retries, database lag, stale timestamps or a compromised gateway. Changing several settings at once can make a symptom disappear without identifying the cause. Preserve the as-found state, choose a bounded test, record what changed and compare the result with the hypothesis. Root cause and contributing conditions should explain the mechanism rather than blame the last person who touched the system. Recheck the remedy under the original and relevant degraded conditions.

Incident response adds adversarial scope and trust questions to operational diagnosis. An unauthorised session or project change requires evidence preservation, containment authority and an assessment of persistence and credential exposure. Recovery restores an accepted service with justified platform, logic, identity and process-state trust. Keep routine fault repair and incident recovery related but distinct: replacing a failed disk does not automatically resolve stolen BMC credentials, while an incident hypothesis does not justify ignoring an ordinary serial wiring fault.

Evidence has levels. Reading a lesson supports knowledge; answering unseen questions supports analytical assessment; executing an offline fixture supports only its modelled function; a vendor emulator supports its declared fidelity; a supervised physical lab adds actual equipment behaviour; production evidence adds operating conditions and responsibility under formal authority. Do not relabel one level as another. Personal competence, permission to act and a firm's contracted delivery capability are separate claims. The certificate examination is an external assessment governed by GIAC, and this original course is neither an official SANS replacement nor a guarantee of passing it.

The final review should state accept, hold or reject against each criterion, with the evidence and limitations. A conditional release needs its owner, permitted mode, expiry and closure test. Reuse one well-designed installation across several outcomes when it truly demonstrates them, but do not count the same screenshot as proof of every responsibility. Preserve source versions, raw results, independent review, decisions and remaining gaps in the portfolio. The next development action should follow an observed gap: more theory for a misunderstood mechanism, isolated practice for an unperformed task, or supervised field access for a capability that cannot be established analytically.

#### Worked demonstrations

**Evidence walkthrough**

Synthetic capstone release R5: requirement alarm age≤5 s; viewer cannot write; restore accepted service≤60 min; tolerate loss of one collection host. Nominal alarm age2 s. During host-loss test, alternate collector starts in4 s but its first accepted fresh alarm arrives at 8 s. Viewer UI hides write controls; API negative test is absent. Restore takes 45 min to start the application plus20 min mandatory validation. Proposed polling optimisation changes interval1 s→0.5 s; measured normal alarm age improves2→1.5 s, but log generation rises from 40 GB/day to 80 GB/day. Dedicated usable log capacity400 GB; required retention7 days; no compression assumed. Exercise used offline fixtures and one emulator; no physical device or production work occurred. Evidence includes architecture rationale and build records but only one hour of operating history; independent reviewer has not signed acceptance.

**Reasoning:** Hold the release against the supplied criteria: host-loss accepted freshness8 s exceeds5; UI hiding lacks API denial evidence; recovery totals65 min and exceeds60;400/80=5 days log retention after optimisation falls below7, although nominal age improves. One hour and an emulator do not establish sustained operations or physical/production competence. Retain the valid design/build and analytical results, identify each open lifecycle evidence item, and obtain the required independent review and practical route without overstating the certificate or scope.

#### Guided practice

Propose a bounded optimisation acceptance condition using the supplied storage arithmetic.

**Hint:** Preserve both freshness and retention requirements; do not silently change either.

**Worked solution:** At80 GB/day, seven days require560 GB usable dedicated capacity before any required margin. Alternatively reduce/structure logging only if required evidence and tested retention remain intact. Revalidate failover freshness, API authority and 65-minute recovery separately; more log storage does not resolve those gaps.

#### Independent task

Environment: analytical

Complete an integrated accept/hold/reject portfolio review for R5.

**Packaged starter material**

- course_labs/GICSP/cases/GICSP-L050.json

**Evidence to produce**

- Requirement-to-evidence matrix
- Nine-lifecycle responsibility map
- Optimisation tradeoff calculation
- Practical-access and independent-review gaps
- Precisely scoped competence statement

**Acceptance criteria**

- Failover freshness uses accepted source data, not collector start time.
- Recovery includes mandatory validation and retention uses actual measured generation.
- Offline/emulator evidence is not represented as physical or production execution.
- D4–D7, later D2/D3 and excluded D1 boundaries remain explicit.

The provided records are synthetic and offline. State every inference and missing observation. Device-specific implementation, physical measurements and sustained field performance need the separately authorised practical route.

#### Chapter practice

**GICSP-Q0491 · single · diagnosis**

Does the host-loss test meet the alarm-age requirement?

Synthetic capstone release R5: requirement alarm age≤5 s; viewer cannot write; restore accepted service≤60 min; tolerate loss of one collection host. Nominal alarm age2 s. During host-loss test, alternate collector starts in4 s but its first accepted fresh alarm arrives at 8 s. Viewer UI hides write controls; API negative test is absent. Restore takes 45 min to start the application plus20 min mandatory validation. Proposed polling optimisation changes interval1 s→0.5 s; measured normal alarm age improves2→1.5 s, but log generation rises from 40 GB/day to 80 GB/day. Dedicated usable log capacity400 GB; required retention7 days; no compression assumed. Exercise used offline fixtures and one emulator; no physical device or production work occurred. Evidence includes architecture rationale and build records but only one hour of operating history; independent reviewer has not signed acceptance.

1. Yes; nominal two-second operation is sufficient evidence for host-loss mode.
2. Yes; alternate collector startup in four seconds meets the five-second service criterion.
3. No; the eight-second result proves both collectors are on the same host.
4. No; accepted fresh alarm arrives at 8 s, beyond the 5 s limit.

**Correct option(s):** 4

- Option 1: The requirement explicitly includes the fault condition and must be measured there.
- Option 2: The criterion concerns accepted fresh alarm data, which arrives at eight seconds.
- Option 3: The result fails freshness but does not by itself identify that particular topology cause.
- Option 4: Collector start at 4 s is not the service acceptance endpoint.

**GICSP-Q0492 · single · diagnosis**

What is the viewer-authority acceptance status?

Synthetic capstone release R5: requirement alarm age≤5 s; viewer cannot write; restore accepted service≤60 min; tolerate loss of one collection host. Nominal alarm age2 s. During host-loss test, alternate collector starts in4 s but its first accepted fresh alarm arrives at 8 s. Viewer UI hides write controls; API negative test is absent. Restore takes 45 min to start the application plus20 min mandatory validation. Proposed polling optimisation changes interval1 s→0.5 s; measured normal alarm age improves2→1.5 s, but log generation rises from 40 GB/day to 80 GB/day. Dedicated usable log capacity400 GB; required retention7 days; no compression assumed. Exercise used offline fixtures and one emulator; no physical device or production work occurred. Evidence includes architecture rationale and build records but only one hour of operating history; independent reviewer has not signed acceptance.

1. Unverified because the trusted API negative test is absent.
2. Irrelevant because the alarm is read-only in name.
3. Failed with proven exploitation.
4. Passed because the button is hidden.

**Correct option(s):** 1

- Option 1: Hidden UI controls do not establish server-side denial.
- Option 2: Actual authority requires verification.
- Option 3: The absence of a test is not evidence of a successful write.
- Option 4: Alternate request paths may remain.

**GICSP-Q0493 · single · calculation**

What is the accepted-service restore time?

Synthetic capstone release R5: requirement alarm age≤5 s; viewer cannot write; restore accepted service≤60 min; tolerate loss of one collection host. Nominal alarm age2 s. During host-loss test, alternate collector starts in4 s but its first accepted fresh alarm arrives at 8 s. Viewer UI hides write controls; API negative test is absent. Restore takes 45 min to start the application plus20 min mandatory validation. Proposed polling optimisation changes interval1 s→0.5 s; measured normal alarm age improves2→1.5 s, but log generation rises from 40 GB/day to 80 GB/day. Dedicated usable log capacity400 GB; required retention7 days; no compression assumed. Exercise used offline fixtures and one emulator; no physical device or production work occurred. Evidence includes architecture rationale and build records but only one hour of operating history; independent reviewer has not signed acceptance.

1. 20 min.
2. 60 min.
3. 65 min.
4. 45 min.

**Correct option(s):** 3

- Option 1: Validation alone is not the whole restore.
- Option 2: That is the target, not the measured total.
- Option 3: 45 min startup plus20 min mandatory validation.
- Option 4: That excludes required acceptance work.

**GICSP-Q0494 · single · calculation**

What retention does400 GB provide at 80 GB/day without compression?

Synthetic capstone release R5: requirement alarm age≤5 s; viewer cannot write; restore accepted service≤60 min; tolerate loss of one collection host. Nominal alarm age2 s. During host-loss test, alternate collector starts in4 s but its first accepted fresh alarm arrives at 8 s. Viewer UI hides write controls; API negative test is absent. Restore takes 45 min to start the application plus20 min mandatory validation. Proposed polling optimisation changes interval1 s→0.5 s; measured normal alarm age improves2→1.5 s, but log generation rises from 40 GB/day to 80 GB/day. Dedicated usable log capacity400 GB; required retention7 days; no compression assumed. Exercise used offline fixtures and one emulator; no physical device or production work occurred. Evidence includes architecture rationale and build records but only one hour of operating history; independent reviewer has not signed acceptance.

1. 7 days.
2. 200 days.
3. 5 days.
4. 10 days.

**Correct option(s):** 3

- Option 1: That is the requirement, not available retention.
- Option 2: That divides by the alarm-age number rather than log generation.
- Option 3: 400/80=5.
- Option 4: That uses the old40 GB/day rate.

**GICSP-Q0495 · single · calculation**

What minimum usable capacity covers seven days at the new measured rate, before additional margin?

Synthetic capstone release R5: requirement alarm age≤5 s; viewer cannot write; restore accepted service≤60 min; tolerate loss of one collection host. Nominal alarm age2 s. During host-loss test, alternate collector starts in4 s but its first accepted fresh alarm arrives at 8 s. Viewer UI hides write controls; API negative test is absent. Restore takes 45 min to start the application plus20 min mandatory validation. Proposed polling optimisation changes interval1 s→0.5 s; measured normal alarm age improves2→1.5 s, but log generation rises from 40 GB/day to 80 GB/day. Dedicated usable log capacity400 GB; required retention7 days; no compression assumed. Exercise used offline fixtures and one emulator; no physical device or production work occurred. Evidence includes architecture rationale and build records but only one hour of operating history; independent reviewer has not signed acceptance.

1. 800 GB exactly by protocol mandate.
2. 560 GB.
3. 400 GB.
4. 280 GB.

**Correct option(s):** 2

- Option 1: No such mandate is supplied; the arithmetic minimum is 560.
- Option 2: 7×80=560.
- Option 3: That covers only five days.
- Option 4: That uses the pre-optimisation40 GB/day rate.

**GICSP-Q0496 · single · diagnosis**

Which conclusion about the polling optimisation is justified?

Synthetic capstone release R5: requirement alarm age≤5 s; viewer cannot write; restore accepted service≤60 min; tolerate loss of one collection host. Nominal alarm age2 s. During host-loss test, alternate collector starts in4 s but its first accepted fresh alarm arrives at 8 s. Viewer UI hides write controls; API negative test is absent. Restore takes 45 min to start the application plus20 min mandatory validation. Proposed polling optimisation changes interval1 s→0.5 s; measured normal alarm age improves2→1.5 s, but log generation rises from 40 GB/day to 80 GB/day. Dedicated usable log capacity400 GB; required retention7 days; no compression assumed. Exercise used offline fixtures and one emulator; no physical device or production work occurred. Evidence includes architecture rationale and build records but only one hour of operating history; independent reviewer has not signed acceptance.

1. It should be judged only by polling interval, not outcomes.
2. It necessarily indicates malicious traffic.
3. It improves nominal freshness but fails retention with current storage and does not resolve the other release gaps.
4. It is fully accepted because one metric improved.

**Correct option(s):** 3

- Option 1: Required application and evidence outcomes are the acceptance basis.
- Option 2: Increased logging follows the supplied workload change.
- Option 3: Optimisation must preserve all required service properties.
- Option 4: Retention and failure/recovery criteria remain unmet.

**GICSP-Q0497 · single · diagnosis**

Which competence claim matches the exercise fidelity?

Synthetic capstone release R5: requirement alarm age≤5 s; viewer cannot write; restore accepted service≤60 min; tolerate loss of one collection host. Nominal alarm age2 s. During host-loss test, alternate collector starts in4 s but its first accepted fresh alarm arrives at 8 s. Viewer UI hides write controls; API negative test is absent. Restore takes 45 min to start the application plus20 min mandatory validation. Proposed polling optimisation changes interval1 s→0.5 s; measured normal alarm age improves2→1.5 s, but log generation rises from 40 GB/day to 80 GB/day. Dedicated usable log capacity400 GB; required retention7 days; no compression assumed. Exercise used offline fixtures and one emulator; no physical device or production work occurred. Evidence includes architecture rationale and build records but only one hour of operating history; independent reviewer has not signed acceptance.

1. No learning or implementation evidence of any kind.
2. Analytical and emulator evidence for the stated functions, with physical/production work still open.
3. Independent production engineering competence across all domains.
4. A completed long-term electrical-protection specialisation.

**Correct option(s):** 2

- Option 1: The offline/emulator work has valid bounded value.
- Option 2: No actual device or production activity occurred.
- Option 3: That exceeds the supplied evidence and authority.
- Option 4: D2/D3 specialist practice is not demonstrated here.

**GICSP-Q0498 · single · diagnosis**

Which lifecycle evidence is particularly weak in the supplied R5 packet?

Synthetic capstone release R5: requirement alarm age≤5 s; viewer cannot write; restore accepted service≤60 min; tolerate loss of one collection host. Nominal alarm age2 s. During host-loss test, alternate collector starts in4 s but its first accepted fresh alarm arrives at 8 s. Viewer UI hides write controls; API negative test is absent. Restore takes 45 min to start the application plus20 min mandatory validation. Proposed polling optimisation changes interval1 s→0.5 s; measured normal alarm age improves2→1.5 s, but log generation rises from 40 GB/day to 80 GB/day. Dedicated usable log capacity400 GB; required retention7 days; no compression assumed. Exercise used offline fixtures and one emulator; no physical device or production work occurred. Evidence includes architecture rationale and build records but only one hour of operating history; independent reviewer has not signed acceptance.

1. Sustained day-to-day operations and independent final acceptance.
2. Any build record.
3. Any nominal measurement.
4. Any architecture rationale.

**Correct option(s):** 1

- Option 1: Only one hour of history and no reviewer sign-off are supplied.
- Option 2: Build records are explicitly present.
- Option 3: Nominal2 s and later1.5 s results are supplied.
- Option 4: A rationale is explicitly present.

**GICSP-Q0499 · multi · design**

Which scope statements follow the user's charter? Select all that apply.

Synthetic capstone release R5: requirement alarm age≤5 s; viewer cannot write; restore accepted service≤60 min; tolerate loss of one collection host. Nominal alarm age2 s. During host-loss test, alternate collector starts in4 s but its first accepted fresh alarm arrives at 8 s. Viewer UI hides write controls; API negative test is absent. Restore takes 45 min to start the application plus20 min mandatory validation. Proposed polling optimisation changes interval1 s→0.5 s; measured normal alarm age improves2→1.5 s, but log generation rises from 40 GB/day to 80 GB/day. Dedicated usable log capacity400 GB; required retention7 days; no compression assumed. Exercise used offline fixtures and one emulator; no physical device or production work occurred. Evidence includes architecture rationale and build records but only one hour of operating history; independent reviewer has not signed acceptance.

1. Near-term D4–D7 includes mandatory integral hardware and all nine lifecycle duties.
2. Later D2/D3 engineering requires separate specialist teaching/practical evidence, while D1 remains excluded.
3. Passing this bank automatically grants authority to change primary protection.
4. D5 hardware can be omitted because cybersecurity is the principal focus.

**Correct option(s):** 1, 2

- Option 1: The charter does not postpone operations or recovery to a later horizon.
- Option 2: Integration foundations do not establish that later ownership.
- Option 3: Study assessment does not confer operational or professional authority.
- Option 4: D5 remains mandatory and integral despite unequal emphasis.

**GICSP-Q0500 · single · operations**

What should the final reviewer do with R5 now?

Synthetic capstone release R5: requirement alarm age≤5 s; viewer cannot write; restore accepted service≤60 min; tolerate loss of one collection host. Nominal alarm age2 s. During host-loss test, alternate collector starts in4 s but its first accepted fresh alarm arrives at 8 s. Viewer UI hides write controls; API negative test is absent. Restore takes 45 min to start the application plus20 min mandatory validation. Proposed polling optimisation changes interval1 s→0.5 s; measured normal alarm age improves2→1.5 s, but log generation rises from 40 GB/day to 80 GB/day. Dedicated usable log capacity400 GB; required retention7 days; no compression assumed. Exercise used offline fixtures and one emulator; no physical device or production work occurred. Evidence includes architecture rationale and build records but only one hour of operating history; independent reviewer has not signed acceptance.

1. Retain valid evidence, hold unmet/unverified criteria and assign specific closure tests and practical gaps.
2. Mark every criterion passed because the course bank is complete.
3. Delete failed results to make the portfolio concise.
4. Claim GIAC certification from the app score alone.

**Correct option(s):** 1

- Option 1: This preserves learning without falsely accepting the release.
- Option 2: Question count does not override release evidence.
- Option 3: Failure evidence is needed for traceability and improvement.
- Option 4: GIAC controls its external examination and award.

#### Recall

**What are the nine lifecycle duties?**

Design, implementation, commissioning, day-to-day operations, maintenance, optimisation, troubleshooting, incident response and recovery.

**What does course completion establish?**

Only the learning/assessment evidence actually produced. Practical competence, formal authority, GIAC award and firm delivery capability require their separate gates.

**How should an optimisation be accepted?**

Demonstrate its benefit while preserving every required security, operational, reliability and evidence-retention criterion.

#### References

- [NIST SP 800-82 Rev. 3: OT security](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [NIST SP 800-61 Rev. 3: incident response](https://csrc.nist.gov/pubs/sp/800/61/r3/final)
