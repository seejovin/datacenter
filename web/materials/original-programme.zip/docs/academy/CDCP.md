# CDCP — CDCP — Facility integration, infrastructure and acceptance

Original independent instruction and practice. Read the teaching, work the demonstrations and guided exercise, then attempt questions before reading their explanations. Independent tasks require your own evidence.

Source baseline: [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4) · Public scope checked 2026-09-19; author-defined chapter identifiers · checked 2026-09-19

Original instruction mapped to public subject areas. Public information is not an item-level examination specification; no claim of provider endorsement or actual examination replication.

## Scope and external requirements

- Detailed examination weighting and proprietary learning materials are not publicly verified.

- National requirements and equipment-specific limits must be supplied for actual installation.

- This author-reviewed bank has not been psychometrically calibrated or independently certified as equivalent to the provider examination.

- Complete the current provider learning and examination requirements; this independently authored course does not award a credential.

- Electrical switching, fire-system intervention and mechanical installation require approved site procedures, appropriate competence and authorization.

- D1 building content is interface and examination literacy only. Power and cooling are integrated facility dependencies in the near-term programme; complete specialist engineering is a later development horizon.

## Preparation

Prior courses: DCCA

- Basic arithmetic, unit conversion and proportional reasoning.

## CDCP-M01 — Business continuity and facility requirements

### CDCP-L01 — Business continuity and facility requirements

Estimated study time: 55 minutes before independent work. Prerequisite chapters: Use the course prerequisites.

Begin a facility design review with the business function and its tolerable disruption. Recovery time objective is the intended maximum time to restore a specified service after the defined event. Recovery point objective expresses tolerable data loss in time terms. Neither is the same as an availability percentage, and neither is automatically achieved by buying redundant equipment. A service can have high monthly availability but fail its one-hour recovery objective during a rare event.

Translate business impact into infrastructure requirements. Identify minimum useful service, peak load, dependent applications, personnel, communications and upstream utilities. Map which losses require immediate continuity and which permit a controlled degraded state. A generator supports energy continuity but does not restore corrupted data. A replicated database may protect data while both sites share the same identity outage. The facility requirement must connect these layers.

Measure availability at the agreed service boundary. Union overlapping outages rather than summing them twice. Distinguish a complete outage from degraded performance, and state how the agreement counts each. Planned maintenance exclusions can be contractually valid, but they must be visible. Component availability and application availability have different denominators and event definitions.

A useful requirements record includes identifier, source, owner, condition, measurable limit, verification method and acceptance authority. Avoid unbounded phrases such as no downtime or future proof. Convert them into named fault sets, growth scenarios and operating conditions. An infeasible combination is a decision to resolve, not an invitation to omit a difficult constraint.

Facility type also changes responsibility. Enterprise ownership, colocation and cloud consumption can move the demarcation between customer and provider, but the service still depends on physical infrastructure. Define who supplies rack feeds, who manages cabling, who receives alarms, who can authorize work and who verifies the delivered service. Service boundaries and escalation contacts should be tested before an incident.

### Convert an impact statement into an acceptance case
A business owner says that a monitoring outage longer than fifteen minutes prevents safe operating decisions. Convert that statement into a named service, required sample freshness, maximum restoration interval, acceptable data gap and fallback method. The RTO might be fifteen minutes while the RPO is one minute; those are different requirements and can require different mechanisms.

A local buffer could preserve samples through a communications outage, satisfying the data-loss objective, while operators still lack live visibility. A redundant display could preserve visibility while both displays depend on one database that loses records. Review both outcomes explicitly. During acceptance, measure transaction or sample behavior at the user boundary rather than declaring success from infrastructure LEDs.

For availability reporting, create an event timeline and compute the union of intervals in which the defined service is unusable. Keep component repair time in a separate record. This avoids both double-counting simultaneous causes and hiding reduced redundancy when service continues. Assign each accepted exclusion to the agreed reporting policy so a favorable percentage does not obscure the actual operating experience.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A service is down from 10:00–10:12 due to power and 10:08–10:20 due to cooling. The reporting period is 1440 minutes.

**Reasoning:** The union is 20 minutes, not 24. Observed availability is 1420/1440 = 98.6111%. The overlap must not be double counted for the same service boundary.

#### Guided practice

A backup runs every six hours, but the business accepts at most one hour of lost data. Identify the unresolved requirement.

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** The backup interval alone does not support the one-hour RPO. Replication, logging or a different protection schedule is needed, and restoration must be tested.

#### Independent task

Environment: analytical

Write five measurable facility requirements for a synthetic colocation controls service.

**Packaged starter material**

- course_labs/CDCP/README.md
- course_labs/CDCP/proposal.json
- course_labs/CDCP/answers-template.json

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Separate RTO, RPO and availability.
- Assign provider/customer responsibility for every interface.
- Use event unions and explicit reporting boundaries.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0001 · single · diagnosis**

Power interruption lasts 10:00–10:12 and cooling interruption 10:08–10:20 for the same service. What downtime is counted?

Synthetic educational evidence; not field measurements.

Power outage: 10:00–10:12
Cooling outage: 10:08–10:20
Same service boundary; overlapping minutes count once.

1. 12 minutes
2. 24 minutes
3. 4 minutes
4. 20 minutes

**Correct option(s):** 4

- Option 1: Incorrect. This omits the final eight minutes.
- Option 2: Incorrect. This double-counts the four-minute overlap.
- Option 3: Incorrect. That is only the overlap.
- Option 4: Correct. The overlapping intervals form one 20-minute union.

**CDCP-Q0002 · single · mechanism**

A business permits one hour of data loss. Which target expresses this?

1. MTTR
2. RPO
3. PUE
4. RTO

**Correct option(s):** 2

- Option 1: Incorrect. Mean repair time is an observed or modeled maintenance metric.
- Option 2: Correct. Recovery point objective concerns tolerable data loss.
- Option 3: Incorrect. PUE is a facility energy ratio.
- Option 4: Incorrect. Recovery time objective concerns restoration duration.

**CDCP-Q0003 · single · mechanism**

A service must be restored within two hours after the defined event. Which objective is stated?

1. RPO
2. RTO
3. Annual availability alone
4. Power factor

**Correct option(s):** 2

- Option 1: Incorrect. That would define acceptable lost-data interval.
- Option 2: Correct. It defines the intended recovery duration.
- Option 3: Incorrect. A percentage does not define this event-specific duration.
- Option 4: Incorrect. That is an electrical ratio.

**CDCP-Q0004 · single · diagnosis**

A daily backup is the only protection and one-hour RPO is required. What conclusion follows?

Synthetic educational evidence; not field measurements.

Only data protection: one backup every 24 h
Required RPO: 1 h

1. The stated protection does not establish the RPO
2. Availability must be exactly 99.9%
3. RPO is met because a backup exists
4. RTO is necessarily one day

**Correct option(s):** 1

- Option 1: Correct. A daily interval can lose more than one hour.
- Option 2: Incorrect. No such percentage follows.
- Option 3: Incorrect. Existence alone does not satisfy the interval.
- Option 4: Incorrect. Restore duration has not been provided.

**CDCP-Q0005 · single · mechanism**

Which requirement is most verifiable?

1. Cooling should be excellent
2. Either rack feed may be lost at 8 kW while transactions remain within the specified limit
3. The rack must be future proof
4. The site must use premium equipment

**Correct option(s):** 2

- Option 1: Incorrect. No measurable limit is supplied.
- Option 2: Correct. It names stimulus, load and service outcome.
- Option 3: Incorrect. The phrase has no bounded acceptance.
- Option 4: Incorrect. Brand class does not define behavior.

**CDCP-Q0006 · single · mechanism**

What does colocation change most directly in requirements analysis?

1. The need for cooling
2. The existence of physical access risk
3. Responsibility and demarcation between provider and customer
4. The laws of electrical power

**Correct option(s):** 3

- Option 1: Incorrect. IT still dissipates heat.
- Option 2: Incorrect. Shared facilities still need access controls.
- Option 3: Correct. Physical dependencies remain but ownership differs.
- Option 4: Incorrect. Those remain the same.

**CDCP-Q0007 · single · diagnosis**

A facility has high monthly availability but one recovery took ten hours against a two-hour target. What is true?

Synthetic educational evidence; not field measurements.

Monthly availability target: met
Required event recovery: 2 h
Observed event recovery: 10 h

1. RPO must also be ten hours
2. The recovery objective was missed
3. No incident occurred if the month passed
4. The high average automatically waives RTO

**Correct option(s):** 2

- Option 1: Incorrect. Data loss is not given.
- Option 2: Correct. An aggregate percentage does not erase the event-specific failure.
- Option 3: Incorrect. The event still matters.
- Option 4: Incorrect. The requirements are separate.

**CDCP-Q0008 · single · mechanism**

Which requirement field identifies who can accept the result?

1. Acceptance authority
2. Cable category
3. Sensor resolution
4. Verification method

**Correct option(s):** 1

- Option 1: Correct. Evidence needs an accountable decision owner.
- Option 2: Incorrect. That describes transmission performance.
- Option 3: Incorrect. That describes measurement granularity.
- Option 4: Incorrect. The method describes how evidence is produced, not who may accept it.

**CDCP-Q0009 · single · mechanism**

Why define minimum useful degraded service?

1. Every workload can stop indefinitely
2. It removes the need for recovery
3. Some failures may permit a bounded reduced function
4. Degradation always equals full compliance

**Correct option(s):** 3

- Option 1: Incorrect. Business needs differ.
- Option 2: Incorrect. Normal service still needs restoration.
- Option 3: Correct. Continuity need not mean every normal feature remains.
- Option 4: Incorrect. The permitted limits must be explicit.

**CDCP-Q0010 · single · mechanism**

Two replicated sites share one identity provider. Which claim remains unproven?

1. Ability to measure power
2. Independence from identity-service failure
3. Existence of two data copies
4. Different physical locations

**Correct option(s):** 2

- Option 1: Incorrect. That is unrelated.
- Option 2: Correct. Data replication does not remove the shared dependency.
- Option 3: Incorrect. That may still be true.
- Option 4: Incorrect. That may still be true.

**CDCP-Q0011 · single · mechanism**

What is the correct treatment of approved maintenance exclusions?

1. Hide them to improve comparability
2. Assume every contract uses identical exclusions
3. State them with the availability boundary and denominator
4. Count them twice

**Correct option(s):** 3

- Option 1: Incorrect. Hidden exclusions mislead readers.
- Option 2: Incorrect. Agreements differ.
- Option 3: Correct. The figure must be interpretable.
- Option 4: Incorrect. That distorts the result.

**CDCP-Q0012 · single · mechanism**

Why identify personnel dependencies in continuity planning?

1. Personnel replace every automatic protection
2. Staff availability is unrelated to recovery
3. Required actions may need competent authorized responders
4. More staff automatically creates fault tolerance

**Correct option(s):** 3

- Option 1: Incorrect. Automation remains necessary.
- Option 2: Incorrect. Response and repair often depend on it.
- Option 3: Correct. Equipment cannot perform every recovery task alone.
- Option 4: Incorrect. Skills, authority and procedures matter.

**CDCP-Q0013 · single · mechanism**

A generator is installed but backup restoration is untested. Which capability is not established?

1. The existence of fuel consumption
2. The need for a power path
3. Recovery of required data and application state
4. Availability of some generation equipment

**Correct option(s):** 3

- Option 1: Incorrect. An operating generator uses fuel.
- Option 2: Incorrect. That remains clear.
- Option 3: Correct. Energy supply does not demonstrate data restoration.
- Option 4: Incorrect. The installation supports that narrow fact.

**CDCP-Q0014 · single · mechanism**

What does an infeasible requirement combination require?

1. Marking all requirements passed
2. Deleting the most expensive requirement
3. Replacing measurements with optimism
4. Explicit tradeoff or redesign with accountable acceptance

**Correct option(s):** 4

- Option 1: Incorrect. That misstates evidence.
- Option 2: Incorrect. That changes scope without agreement.
- Option 3: Incorrect. Confidence does not create capability.
- Option 4: Correct. Mandatory constraints cannot be silently dropped.

**CDCP-Q0015 · single · mechanism**

Why test provider escalation contacts?

1. Only the customer can ever detect faults
2. Contact tests replace equipment maintenance
3. A documented contact may not be reachable or responsible during an event
4. A contract automatically answers every call

**Correct option(s):** 3

- Option 1: Incorrect. Providers can also observe events.
- Option 2: Incorrect. They cover a different dependency.
- Option 3: Correct. Operational readiness needs verification.
- Option 4: Incorrect. The response path can fail.

**CDCP-Q0016 · single · mechanism**

Which observation measures service rather than component availability?

1. A maintenance ticket open
2. A redundant fan remaining failed
3. Successful required transactions at the agreed boundary
4. A spare UPS module under repair

**Correct option(s):** 3

- Option 1: Incorrect. Administrative state is not service state.
- Option 2: Incorrect. The service may continue.
- Option 3: Correct. It represents delivered function.
- Option 4: Incorrect. The load may still be supported.

**CDCP-Q0017 · single · diagnosis**

A 1440-minute day includes a 20-minute service outage. What availability is observed?

Synthetic educational evidence; not field measurements.

Scheduled interval: 1440 min
Service outage union: 20 min

1. 97.2222%
2. 100%
3. 99.9861%
4. 98.6111%

**Correct option(s):** 4

- Option 1: Incorrect. That would count 40 minutes.
- Option 2: Incorrect. The interruption is part of the stated period.
- Option 3: Incorrect. This uses an incorrect scale.
- Option 4: Correct. 1420 divided by 1440 gives the result.

**CDCP-Q0018 · single · mechanism**

What is the purpose of a verification method in a requirement?

1. Guarantee the test will pass
2. Replace the measurable limit
3. Define how compliance will be demonstrated
4. Transfer all risk to the technician

**Correct option(s):** 3

- Option 1: Incorrect. Methods can reveal failure.
- Option 2: Incorrect. Both method and limit are needed.
- Option 3: Correct. A requirement needs an evidence route.
- Option 4: Incorrect. Acceptance authority remains defined.

**CDCP-Q0019 · single · mechanism**

Why separate data loss from service interruption?

1. They always have identical durations
2. Service interruption never affects business
3. A service can return with missing data or retain data while unavailable
4. Data loss is measured only in kW

**Correct option(s):** 3

- Option 1: Incorrect. They need not.
- Option 2: Incorrect. Its impact drives requirements.
- Option 3: Correct. The two outcomes differ.
- Option 4: Incorrect. It concerns information state.

**CDCP-Q0020 · single · mechanism**

Which boundary statement is most useful for a colocation feed?

1. The customer has no physical dependencies
2. Provider supplies the defined outlet characteristics; customer verifies its equipment connection and failover
3. Everyone owns everything
4. The provider guarantees every application transaction

**Correct option(s):** 2

- Option 1: Incorrect. The service still relies on the facility.
- Option 2: Correct. It assigns interface responsibilities.
- Option 3: Incorrect. That obscures authority.
- Option 4: Incorrect. That may exceed the service contract.

#### Recall

**Power interruption lasts 10:00–10:12 and cooling interruption 10:08–10:20 for the same service. What downtime is counted?**

20 minutes Correct. The overlapping intervals form one 20-minute union.

**A business permits one hour of data loss. Which target expresses this?**

RPO Correct. Recovery point objective concerns tolerable data loss.

**A service must be restored within two hours after the defined event. Which objective is stated?**

RTO Correct. It defines the intended recovery duration.

**A daily backup is the only protection and one-hour RPO is required. What conclusion follows?**

The stated protection does not establish the RPO Correct. A daily interval can lose more than one hour.

**Which requirement is most verifiable?**

Either rack feed may be lost at 8 kW while transactions remain within the specified limit Correct. It names stimulus, load and service outcome.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)
- [NIST SP 800-82 Revision 3 — final OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

## CDCP-M02 — Standards, evidence and interface governance

### CDCP-L02 — Standards, evidence and interface governance

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L01

Standards define terminology, requirements or test methods within a stated scope and edition. A guideline may recommend practices without creating the same obligations as an adopted code or contract. National law, local authority requirements, equipment instructions and project specifications can all apply simultaneously. Establish the governing hierarchy with the responsible specialists instead of assuming one international document overrides every local requirement.

A compliance matrix maps each applicable requirement to design evidence, installed evidence and acceptance result. Record edition, clause, interpretation owner and exceptions. A certificate can apply to a product, management system, design or constructed facility; its boundary must be read. A certified component does not automatically certify the assembled system or the operator's processes.

Availability classifications and facility rating systems are not interchangeable labels. They can use different definitions, scope and assessment processes. Do not translate one rating into another without an explicit supported basis. Similarly, a topology sketch with redundant units is not an official rating assessment. Use precise claims: the design supports the specified maintenance state, demonstrated by the named test, rather than inventing a broader certification.

Interface control is essential where the programme does not own a specialty. Building structure, fire engineering, electrical protection and water chemistry have specialist responsibilities. The data-center engineer should state loads, operating conditions, access needs, failure consequences and required evidence, then coordinate qualified review. This preserves the user's D1 exclusion while still handling building dependencies intelligently.

Document control prevents obsolete instructions from governing live work. Approve a baseline, identify revisions, distribute the effective version and archive superseded versions so history remains available without confusing execution. Field deviations require a controlled disposition: accept with justification, correct, or hold. A drawing marked as-built should reflect verified installation, not simply the latest design file renamed at handover.

### Build an evidence matrix that can survive review
Take a requirement such as: a specified branch may be isolated while the named rack service continues at its required load. The matrix should reference the current design drawing, protection and capacity evidence, installed source-tracing record, approved procedure and observed functional result. Each artifact answers a different question. A diagram establishes intent; an as-built survey establishes configuration; a test establishes behavior under its conditions.

Record the governing source's edition and the project's interpretation. If a supplier submits a certificate, read whether it covers a product model, a design, an installed facility or a management process. Do not expand its scope through a convenient label. Where a national or local requirement applies, the responsible specialist resolves it with the project requirements rather than assuming an international title is automatically superior.

When evidence is missing, use hold and name the missing item. When the design violates a mandatory constraint, reject or require an explicit authorized redesign. An exception must identify its consequence and owner. This disciplined distinction prevents an attractive document pack from being treated as verified compliance.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A vendor submits a product certificate for one UPS module and claims the entire dual-path facility is certified to the same availability level.

**Reasoning:** The certificate boundary does not establish the assembled facility rating. Review the actual certificate scope and obtain the appropriate system-level assessment or restrict the claim.

#### Guided practice

A work instruction references an older drawing than the approved as-built. What should happen before work?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** Hold the affected action, reconcile the versions and issue a controlled instruction based on verified effective state.

#### Independent task

Environment: analytical

Create a requirements-and-evidence matrix for five facility interfaces.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Record source edition and scope.
- Keep product, design and facility certification claims separate.
- Assign specialist review and document-control responsibility.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0021 · single · mechanism**

What must be checked before relying on a certificate?

1. Only the supplier's revenue
2. Only the certificate title
3. Only the paper size
4. Its scope, edition, subject and validity

**Correct option(s):** 4

- Option 1: Incorrect. Company size does not define certification.
- Option 2: Incorrect. A title without scope, edition and validity can support an overbroad claim.
- Option 3: Incorrect. Format is not technical evidence.
- Option 4: Correct. The claim applies only within its stated boundary.

**CDCP-Q0022 · single · diagnosis**

A certified UPS module is installed in an unassessed system. What is established?

Synthetic educational evidence; not field measurements.

Submitted certificate: one UPS product model
Claimed scope: whole installed facility

1. All upstream sources are independent
2. The product's stated certification boundary
3. All operators are authorized
4. Every facility process is certified

**Correct option(s):** 2

- Option 1: Incorrect. Product certification does not prove topology.
- Option 2: Correct. The whole installation is not automatically certified.
- Option 3: Incorrect. Personnel authority is separate.
- Option 4: Incorrect. The certificate does not cover that scope.

**CDCP-Q0023 · single · mechanism**

Why record a standard's edition?

1. Requirements and terminology can change between editions
2. An edition replaces the requirement clause
3. Newer editions always apply retroactively without review
4. Editions are purely decorative

**Correct option(s):** 1

- Option 1: Correct. A bare title leaves ambiguity.
- Option 2: Incorrect. Both can be needed.
- Option 3: Incorrect. Applicability must be established.
- Option 4: Incorrect. They identify the applicable text.

**CDCP-Q0024 · single · mechanism**

What is a compliance matrix useful for?

1. Concealing exceptions
2. Replacing every technical test
3. Awarding automatic certification
4. Linking applicable requirements to evidence and disposition

**Correct option(s):** 4

- Option 1: Incorrect. Exceptions should be explicit.
- Option 2: Incorrect. The matrix references rather than substitutes for evidence.
- Option 3: Incorrect. An assessor or authority may still be required.
- Option 4: Correct. It makes gaps visible.

**CDCP-Q0025 · single · mechanism**

What is the proper treatment of conflicting requirements?

1. Apply both even if physically contradictory without noting it
2. Resolve applicability with accountable specialists and authorities
3. Ignore local requirements in favor of any international title
4. Choose whichever is cheaper without review

**Correct option(s):** 2

- Option 1: Incorrect. Infeasibility must be exposed.
- Option 2: Correct. The hierarchy cannot be guessed casually.
- Option 3: Incorrect. Local adoption and law can govern.
- Option 4: Incorrect. Cost does not determine compliance.

**CDCP-Q0026 · single · mechanism**

Why avoid equating different facility rating systems?

1. All rating systems measure nothing
2. Every system uses identical tests
3. Ratings depend only on UPS count
4. Definitions, scope and assessment methods can differ

**Correct option(s):** 4

- Option 1: Incorrect. They can provide useful scoped assessments.
- Option 2: Incorrect. That cannot be assumed.
- Option 3: Incorrect. Facility scope is broader.
- Option 4: Correct. Similar labels need not mean equivalent requirements.

**CDCP-Q0027 · single · mechanism**

What should an as-built drawing represent?

1. Verified installed arrangement
2. The earliest concept only
3. A preferred future arrangement
4. Only the supplier's standard diagram

**Correct option(s):** 1

- Option 1: Correct. Renaming a design file does not establish reality.
- Option 2: Incorrect. Installation can differ.
- Option 3: Incorrect. That is a proposal.
- Option 4: Incorrect. The site configuration may differ.

**CDCP-Q0028 · single · mechanism**

A field deviation is discovered. Which disposition is appropriate?

1. Delete the original requirement
2. Mark every related test passed
3. Hide it if service currently runs
4. Correct, hold or explicitly accept through the controlled process

**Correct option(s):** 4

- Option 1: Incorrect. That silently changes scope.
- Option 2: Incorrect. Evidence must reflect reality.
- Option 3: Incorrect. It can affect future safety or resilience.
- Option 4: Correct. The deviation needs accountable resolution.

**CDCP-Q0029 · single · mechanism**

Which action respects the D1 exclusion while managing dependencies?

1. State equipment loads and obtain qualified structural confirmation
2. Ignore floor capacity entirely
3. Treat a rack rating as a floor rating
4. Personally certify the slab from rack count alone

**Correct option(s):** 1

- Option 1: Correct. The interface is managed without claiming structural design ownership.
- Option 2: Incorrect. The equipment still depends on the building.
- Option 3: Incorrect. They concern different structures.
- Option 4: Incorrect. That exceeds both evidence and scope.

**CDCP-Q0030 · single · mechanism**

Why archive superseded documents?

1. Prove every old instruction is still valid
2. Preserve history while preventing obsolete execution
3. Ensure old versions remain the default work instructions
4. Eliminate the need for revision identifiers

**Correct option(s):** 2

- Option 1: Incorrect. Supersession means applicability changed.
- Option 2: Correct. Both traceability and current control matter.
- Option 3: Incorrect. That creates confusion.
- Option 4: Incorrect. History requires identification.

**CDCP-Q0031 · single · mechanism**

What distinguishes a guideline from an adopted mandatory requirement?

1. Mandatory requirements never need interpretation
2. Guidelines contain no useful information
3. Any guideline overrides legislation
4. Its authority and applicability in the project context

**Correct option(s):** 4

- Option 1: Incorrect. Scope and applicability still matter.
- Option 2: Incorrect. They can be valuable.
- Option 3: Incorrect. That is not a valid general hierarchy.
- Option 4: Correct. Recommendations and obligations are not automatically identical.

**CDCP-Q0032 · single · mechanism**

What should an exception record include?

1. A claim of full compliance without qualification
2. Only the word waived
3. Only the contractor's initials
4. Requirement, rationale, impact, owner and acceptance

**Correct option(s):** 4

- Option 1: Incorrect. That contradicts the exception.
- Option 2: Incorrect. That lacks scope and authority.
- Option 3: Incorrect. The impact and accountable acceptance remain needed.
- Option 4: Correct. An exception changes the assurance case.

**CDCP-Q0033 · single · diagnosis**

A work instruction uses an obsolete diagram. What is the correct immediate response?

Synthetic educational evidence; not field measurements.

Work instruction drawing: superseded revision
Approved as-built: newer revision

1. Assume the technician remembers changes
2. Remove all diagram references
3. Hold affected work and reconcile the baseline
4. Continue because older drawings are simpler

**Correct option(s):** 3

- Option 1: Incorrect. Memory is not controlled documentation.
- Option 2: Incorrect. That weakens the procedure.
- Option 3: Correct. The actual path may differ from the instruction.
- Option 4: Incorrect. Simplicity does not establish correctness.

**CDCP-Q0034 · single · mechanism**

Why identify an interpretation owner?

1. Ownership proves every interpretation correct
2. Interpretations never affect testing
3. One owner can ignore every specialist
4. Ambiguous requirements need accountable technical resolution

**Correct option(s):** 4

- Option 1: Incorrect. Evidence and review are still needed.
- Option 2: Incorrect. They can change acceptance conditions.
- Option 3: Incorrect. The owner coordinates appropriate expertise.
- Option 4: Correct. Different teams should not silently apply incompatible meanings.

**CDCP-Q0035 · single · mechanism**

What is a defensible claim after a scoped maintenance test?

1. No future maintenance is required
2. Every rating has been awarded
3. The specified service survived the tested maintenance state
4. The facility survives every possible event

**Correct option(s):** 3

- Option 1: Incorrect. The lifecycle continues.
- Option 2: Incorrect. A test is not the entire certification process.
- Option 3: Correct. The claim matches the evidence.
- Option 4: Incorrect. The test does not cover all events.

**CDCP-Q0036 · single · mechanism**

Why include equipment instructions in the governing set?

1. Instructions replace commissioning
2. Product instructions are always identical
3. Ratings and supported installation conditions constrain use
4. Instructions automatically override all law

**Correct option(s):** 3

- Option 1: Incorrect. Installed behavior still needs verification.
- Option 2: Incorrect. Equipment differs.
- Option 3: Correct. Standards alone may not specify every product detail.
- Option 4: Incorrect. The full hierarchy still applies.

**CDCP-Q0037 · single · mechanism**

What does a test-method standard primarily support?

1. A substitute for asset identity
2. A guarantee of lifetime reliability
3. A defined way to measure or verify a property
4. Automatic proof that every tested item passes

**Correct option(s):** 3

- Option 1: Incorrect. The tested item must still be identified.
- Option 2: Incorrect. A test has bounded conditions.
- Option 3: Correct. It makes results comparable within scope.
- Option 4: Incorrect. Items can fail the method's limits.

**CDCP-Q0038 · single · mechanism**

Which evidence boundary is narrowest?

1. One component's specified test result
2. An enterprise-wide management system
3. A multi-system acceptance campaign
4. All facility lifecycle operations

**Correct option(s):** 1

- Option 1: Correct. It concerns less scope than a complete facility assessment.
- Option 2: Incorrect. That has a different broad organizational scope.
- Option 3: Incorrect. That covers more interfaces.
- Option 4: Incorrect. That is broad.

**CDCP-Q0039 · single · mechanism**

Why retain raw results behind a compliance status?

1. Raw results remove the need for interpretation
2. Reviewers need to verify how the status was reached
3. A pass status eliminates the need to retain measurements
4. A pass label contains every measurement

**Correct option(s):** 2

- Option 1: Incorrect. Context and limits remain necessary.
- Option 2: Correct. A green cell alone is not the underlying evidence.
- Option 3: Incorrect. Reviewers need the underlying evidence to verify the conclusion.
- Option 4: Incorrect. It usually does not.

**CDCP-Q0040 · single · mechanism**

What should happen when a governing source changes?

1. Ignore it indefinitely
2. Assess applicability and controlled updates
3. Assume all existing equipment is automatically invalid
4. Rewrite all records without preserving history

**Correct option(s):** 2

- Option 1: Incorrect. Applicability needs review.
- Option 2: Correct. A new edition may affect requirements, training or evidence.
- Option 3: Incorrect. Transition rules and scope must be examined.
- Option 4: Incorrect. That destroys traceability.

#### Recall

**What must be checked before relying on a certificate?**

Its scope, edition, subject and validity Correct. The claim applies only within its stated boundary.

**A certified UPS module is installed in an unassessed system. What is established?**

The product's stated certification boundary Correct. The whole installation is not automatically certified.

**Why record a standard's edition?**

Requirements and terminology can change between editions Correct. A bare title leaves ambiguity.

**What is a compliance matrix useful for?**

Linking applicable requirements to evidence and disposition Correct. It makes gaps visible.

**What is the proper treatment of conflicting requirements?**

Resolve applicability with accountable specialists and authorities Correct. The hierarchy cannot be guessed casually.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## CDCP-M03 — Site, building and support-facility interfaces

### CDCP-L03 — Site, building and support-facility interfaces

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L02

Site selection is a dependency and risk problem. Evaluate utility capacity and diversity, telecommunications routes, flood and weather exposure, nearby hazards, access, security, water, environmental constraints and expansion. The relevant unit is the actual shared failure domain, not the number of commercial contracts. Two utilities may share a substation; two carriers may share one bridge or duct.

Building suitability includes structural loading, equipment delivery routes, floor-to-ceiling clearances, fire compartments, water exposure and service access. This course teaches what information to request and how to evaluate an interface package; it does not grant civil or structural design authority. D1 remains outside the intended owned engineering scope. Qualified specialists must establish slab, anchorage, seismic, envelope and fire-resistance suitability.

Support spaces are part of the service. Receiving, staging, storage, workshops, battery areas, generator yards, fuel systems and maintenance corridors need appropriate access and environmental arrangements. A large spare part is of little value if it cannot be moved to the failed equipment. Replacement routes must account for dimensions, weight, turning space, lifts and active services.

Water is both a resource and a hazard. Identify supply dependence, drainage, leak paths, overhead piping and local flood mechanisms. An upper-floor data hall may avoid one flood scenario while still being exposed to roof leakage or internal pipe failure. A site risk review should distinguish likelihood, consequence, existing controls and residual uncertainty rather than using one simplistic ranking.

Document assumptions and interfaces in a basis of design. Require evidence for claims such as independent feeds, maintainable replacement access and supported future load. Revisit the basis when equipment density, external hazards or neighboring infrastructure changes. A technically suitable site can still be infeasible because of delivery schedule, permit constraints or lifecycle cost; those conflicts must be made explicit.

### Review a site as a set of shared dependencies
Suppose two utility services enter from opposite sides of a plot but both originate at one substation. Two carriers enter separately but use one river crossing. A water supply has a backup tank but its transfer pumps use only the normal utility. The site has several duplicated interfaces without independence against the relevant common causes.

Make a table with initiating event, affected functions, available fallback, duration and evidence. A substation outage may be bridged by generation; a regional fuel-delivery disruption may limit that bridge; a failed water pump may shorten cooling continuity before fuel is exhausted. The governing autonomy is the earliest binding dependency, not the largest tank.

Review replacement geometry as well. A transformer that fits its room may require a route through a wall or active corridor for replacement. Record dimensions, mass, turning clearance and the specialist-approved load path. These are building interfaces that the data-center engineer must coordinate while retaining the programme's exclusion of owned D1 structural engineering.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. Two proposed sites each have two carriers. Site A routes both through one bridge; Site B has verified separated entry routes but only one utility source.

**Reasoning:** Neither count alone establishes overall resilience. Compare required failure scenarios across telecommunications and power, including backup generation and actual shared domains.

#### Guided practice

A replacement chiller fits its final pad but cannot pass through the only access route. What requirement is unmet?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** Maintainable replacement access. Installed footprint is only one part of the lifecycle geometry.

#### Independent task

Environment: analytical

Prepare a site-interface risk register for a synthetic data hall.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Keep D1 specialist evidence separate from owned engineering claims.
- Trace shared utility and carrier dependencies.
- Check replacement access, water hazards and expansion constraints.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0041 · single · diagnosis**

Two utility contracts share one substation. What remains common?

Synthetic educational evidence; not field measurements.

Utility contracts: two
Common upstream substation: one

1. Every downstream breaker
2. Every billing account
3. The server operating system
4. The substation failure domain

**Correct option(s):** 4

- Option 1: Incorrect. Those may differ.
- Option 2: Incorrect. Contracts can still be commercially separate.
- Option 3: Incorrect. That is unrelated to the source topology.
- Option 4: Correct. Commercial separation does not prove physical independence.

**CDCP-Q0042 · single · mechanism**

Why review equipment replacement routes?

1. Route width changes electrical efficiency
2. Equipment never needs replacement
3. Lifecycle service may require moving large failed components
4. Delivery routes automatically remain clear forever

**Correct option(s):** 3

- Option 1: Incorrect. The main issue is maintainable access.
- Option 2: Incorrect. Wear and failures occur.
- Option 3: Correct. Final installation space alone is insufficient.
- Option 4: Incorrect. Changes can obstruct them.

**CDCP-Q0043 · single · mechanism**

What is the correct structural-interface role for this programme?

1. Provide loads and requirements, then obtain qualified structural evidence
2. Substitute the cabinet rating for building approval
3. Ignore rack weight
4. Certify the slab from a photograph

**Correct option(s):** 1

- Option 1: Correct. D1 design remains outside owned scope.
- Option 2: Incorrect. They are different boundaries.
- Option 3: Incorrect. The building is a real dependency.
- Option 4: Incorrect. That is insufficient evidence and authority.

**CDCP-Q0044 · single · mechanism**

An upper-floor hall avoids ground flooding. Which hazard can remain?

1. Guaranteed utility independence
2. Internal pipe or roof leakage
3. No water exposure of any kind
4. Automatic fire compartment integrity

**Correct option(s):** 2

- Option 1: Incorrect. Floor level does not establish supply diversity.
- Option 2: Correct. Elevation does not remove every water source.
- Option 3: Incorrect. That overstates the protection.
- Option 4: Incorrect. That requires its own design and evidence.

**CDCP-Q0045 · single · mechanism**

Why inspect carrier routes beyond the building entry?

1. Different carriers never share infrastructure
2. Shared upstream structures can defeat local diversity
3. Entry labels prove the entire route
4. Route information has no effect on resilience

**Correct option(s):** 2

- Option 1: Incorrect. They can.
- Option 2: Correct. Separate doors can still lead to one bridge or duct.
- Option 3: Incorrect. They show only a local boundary.
- Option 4: Incorrect. Common causes depend on it.

**CDCP-Q0046 · single · mechanism**

What should a basis of design retain?

1. Requirements, assumptions and governing interface decisions
2. Only an architectural rendering
3. Only the selected product specifications
4. Only the final purchase list

**Correct option(s):** 1

- Option 1: Correct. It explains why the design is suitable.
- Option 2: Incorrect. Appearance does not define service requirements.
- Option 3: Incorrect. Product data alone omit business requirements, assumptions and interface rationale.
- Option 4: Incorrect. That omits rationale and constraints.

**CDCP-Q0047 · single · diagnosis**

A spare pump cannot pass through the maintenance corridor. What is compromised?

Synthetic educational evidence; not field measurements.

Spare pump: available
Approved maintenance route: too narrow for replacement

1. Recoverability and maintainability
2. The number of UPS modules
3. Every sensor's calibration
4. Nominal pump output necessarily

**Correct option(s):** 1

- Option 1: Correct. Replacement cannot follow the assumed path.
- Option 2: Incorrect. That does not resolve access.
- Option 3: Incorrect. That is unrelated.
- Option 4: Incorrect. The pump may still meet hydraulic ratings.

**CDCP-Q0048 · single · mechanism**

Why assess nearby industrial hazards?

1. Only internal equipment can fail
2. External events can create common exposure for the site
3. Nearby hazards determine all application logic
4. A fence eliminates all external consequences

**Correct option(s):** 2

- Option 1: Incorrect. External hazards can interrupt utilities or access.
- Option 2: Correct. The boundary extends beyond the fence.
- Option 3: Incorrect. They affect risk, not every software function.
- Option 4: Incorrect. It does not stop every hazard.

**CDCP-Q0049 · single · mechanism**

Which site claim needs physical evidence?

1. The existence of two invoices
2. Independent telecommunications routes
3. The facility's street address
4. The project owner's name

**Correct option(s):** 2

- Option 1: Incorrect. Invoices directly show commercial records.
- Option 2: Correct. Supplier names alone are insufficient.
- Option 3: Incorrect. That can be documented separately.
- Option 4: Incorrect. That is organizational information.

**CDCP-Q0050 · single · mechanism**

Why include receiving and staging areas?

1. They replace the data hall
2. Equipment must be checked and prepared before controlled installation
3. They need no access control
4. They eliminate every installation error

**Correct option(s):** 2

- Option 1: Incorrect. They serve supporting roles.
- Option 2: Correct. These functions support security and quality.
- Option 3: Incorrect. Incoming goods can introduce risks.
- Option 4: Incorrect. Inspection reduces but does not remove all error.

**CDCP-Q0051 · single · mechanism**

What should a water-dependency review include?

1. Only the PUE target
2. Only the number of sinks
3. Only annual rainfall
4. Supply, treatment, storage, delivery and permitted operating limits

**Correct option(s):** 4

- Option 1: Incorrect. PUE does not define water resilience.
- Option 2: Incorrect. That does not establish cooling water support.
- Option 3: Incorrect. Local supply systems and demand matter.
- Option 4: Correct. A pipe connection alone is insufficient.

**CDCP-Q0052 · single · mechanism**

Why revisit site assumptions after a density increase?

1. Original approvals always cover unlimited growth
2. Only the number of racks matters, regardless of per-rack load
3. Power, cooling, loading and access demands can change
4. Higher density automatically improves every constraint

**Correct option(s):** 3

- Option 1: Incorrect. They have defined limits.
- Option 2: Incorrect. Density changes can alter local and aggregate physical demand.
- Option 3: Correct. The old envelope may no longer apply.
- Option 4: Incorrect. It can tighten several constraints.

**CDCP-Q0053 · single · mechanism**

What distinguishes risk likelihood from consequence?

1. Likelihood measures UPS efficiency
2. Likelihood concerns occurrence; consequence concerns impact
3. Consequence means only repair price
4. They are always identical numbers

**Correct option(s):** 2

- Option 1: Incorrect. That is unrelated.
- Option 2: Correct. Both are needed for evaluation.
- Option 3: Incorrect. Safety and service effects can matter.
- Option 4: Incorrect. They describe different dimensions.

**CDCP-Q0054 · single · diagnosis**

A site has adequate technical capacity but approval lead time exceeds the service deadline. What is true?

Synthetic educational evidence; not field measurements.

Technical capacity: adequate
Approval/delivery time: later than required service date

1. The schedule constraint makes the current proposal infeasible
2. The deadline can be silently dropped
3. More capacity removes approval time
4. The design is automatically acceptable

**Correct option(s):** 1

- Option 1: Correct. Technical capability alone is insufficient.
- Option 2: Incorrect. Requirements must be resolved explicitly.
- Option 3: Incorrect. It does not necessarily change the process.
- Option 4: Incorrect. All required constraints matter.

**CDCP-Q0055 · single · mechanism**

Why assess turning space on a delivery route?

1. A load can fit a doorway yet fail to negotiate a corner
2. Turning space changes cable attenuation
3. Lifts eliminate every turning constraint
4. Equipment dimensions matter only at final placement

**Correct option(s):** 1

- Option 1: Correct. Geometry includes movement, not just one opening.
- Option 2: Incorrect. That is not the main interface.
- Option 3: Incorrect. Access geometry still exists.
- Option 4: Incorrect. They matter along the route.

**CDCP-Q0056 · single · mechanism**

Which evidence best supports expansion suitability?

1. Verified reserve in utilities, space, routes and approvals
2. An assumption that all neighboring capacity is available
3. An uncommitted utility-capacity estimate with no delivery date
4. A statement that land is nearby

**Correct option(s):** 1

- Option 1: Correct. Growth depends on multiple resources.
- Option 2: Incorrect. Availability must be verified.
- Option 3: Incorrect. Future reserve must be available and usable within the required schedule.
- Option 4: Incorrect. Land alone does not provide services or permits.

**CDCP-Q0057 · single · mechanism**

Why distinguish internal drainage from external flood protection?

1. Drainage prevents every fire
2. They address different water sources and paths
3. Both are the same component
4. Flood protection guarantees no condensation

**Correct option(s):** 2

- Option 1: Incorrect. That is not its purpose.
- Option 2: Correct. A barrier outside does not remove an internal leak.
- Option 3: Incorrect. Their mechanisms differ.
- Option 4: Incorrect. Moisture physics remains separate.

**CDCP-Q0058 · single · mechanism**

What should an unresolved site-interface risk record contain?

1. Only a red cell
2. A guaranteed pass status
3. No record until an incident occurs
4. Scope, impact, owner and required further evidence or acceptance

**Correct option(s):** 4

- Option 1: Incorrect. Color lacks the needed decision context.
- Option 2: Incorrect. That would misrepresent uncertainty.
- Option 3: Incorrect. The purpose is anticipatory control.
- Option 4: Correct. Uncertainty must remain visible.

**CDCP-Q0059 · single · mechanism**

Why include service access around equipment?

1. Remote monitoring replaces every physical task
2. Access space is always wasted capacity
3. Inspection and maintenance require safe physical reach
4. More alarms create physical clearance

**Correct option(s):** 3

- Option 1: Incorrect. Components still need hands-on service.
- Option 2: Incorrect. It supports lifecycle operation.
- Option 3: Correct. A packed layout can make required work impractical.
- Option 4: Incorrect. They do not.

**CDCP-Q0060 · single · mechanism**

Which site-selection statement is most defensible?

1. The coldest climate is always optimal
2. The lowest purchase price guarantees lowest lifetime cost
3. The site with the most carriers always wins
4. Suitability depends on the stated service, hazards and lifecycle constraints

**Correct option(s):** 4

- Option 1: Incorrect. Water, power, access and workload also matter.
- Option 2: Incorrect. Operating and risk costs can differ.
- Option 3: Incorrect. Other constraints and route sharing matter.
- Option 4: Correct. There is no universally best site independent of requirements.

#### Recall

**Two utility contracts share one substation. What remains common?**

The substation failure domain Correct. Commercial separation does not prove physical independence.

**Why review equipment replacement routes?**

Lifecycle service may require moving large failed components Correct. Final installation space alone is insufficient.

**What is the correct structural-interface role for this programme?**

Provide loads and requirements, then obtain qualified structural evidence Correct. D1 design remains outside owned scope.

**An upper-floor hall avoids ground flooding. Which hazard can remain?**

Internal pipe or roof leakage Correct. Elevation does not remove every water source.

**Why inspect carrier routes beyond the building entry?**

Shared upstream structures can defeat local diversity Correct. Separate doors can still lead to one bridge or duct.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## CDCP-M04 — Raised floors, suspended ceilings and load interfaces

### CDCP-L04 — Raised floors, suspended ceilings and load interfaces

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L03

A raised access floor creates a service void that may carry air, cables or other approved systems. Its suitability depends on panel and pedestal ratings, installation quality, loading pattern, grounding/bonding arrangements and the intended airflow. Concentrated, distributed, rolling and ultimate load descriptions are not interchangeable. A cabinet foot can impose a local load that is hidden by an average kilograms-per-square-meter calculation.

Panels need correct support, level and fit. Missing stringers, damaged pedestals, poorly seated panels or unapproved cutouts can reduce capacity or create trip hazards. Removing panels for work can weaken adjacent support or create an open fall hazard; the approved procedure controls the work area and restoration. Do not use a generic loading example as structural approval.

When the void is an air plenum, obstructions and leakage affect pressure and delivery. Cable piles, blocked tiles and unsealed openings can redirect flow. A perforated tile's nominal open area is not a guarantee of delivered airflow because pressure and local resistance matter. Floor work must therefore preserve both mechanical integrity and thermal function.

Suspended ceilings can form return plenums or support selected devices, but they are not automatically rated to carry arbitrary equipment or people. Coordinate hanging loads, detector locations, access panels, fire interfaces and seismic restraint with the responsible specialists. A cable tray or containment roof can change both access and airflow, and its loads need a defined support path.

Acceptance evidence should connect the approved design to installation: component identity, support spacing, load assumptions, leveling, bonding, approved penetrations, cleanliness and airflow measurements. Maintain drawings of concealed services and inspect before closing the void. Future moves must revisit local and route loading rather than assuming initial acceptance permits every later rack arrangement.

### Separate load definitions with a worked review
A cabinet's 1200 kg mass distributed across a 0.72 m² footprint gives an average mass-per-area of about 1667 kg/m². That arithmetic is not a structural approval. The actual feet transfer concentrated forces to particular panels and pedestals, and a rolling move can impose different local and dynamic conditions. A floor's distributed-load rating cannot simply be substituted for its point- or rolling-load rating.

Ask the specialist package to show the applicable load definitions, panel support arrangement, route and any cutouts. Then inspect whether the installation matches that package: correct supports, level panels, secure fittings and approved penetrations. A clean top surface can hide missing support below.

If the void supplies air, add a thermal check. Moving cable bundles may improve access while blocking a pressure path. Removing a tile during maintenance can create bypass and reduce delivery to nearby racks. Restore both mechanical integrity and airflow, and record the final concealed services before closure. The two acceptance functions are connected but require different evidence.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A 1000 kg rack stands on four equal feet in an ideal static model. Each foot contacts a small local area.

**Reasoning:** The average vertical load is 250 kg-equivalent per foot before unequal distribution, dynamic effects and the actual support geometry. A room-average floor load does not establish that each panel and pedestal supports the local condition.

#### Guided practice

A tile has large open area but low measured airflow. What other information is needed?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** Plenum pressure, underfloor obstructions, leakage and the tile flow characteristic. Open area alone does not determine flow.

#### Independent task

Environment: analytical

Review a synthetic raised-floor installation package and list required evidence.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Separate local, distributed and rolling loads.
- Identify airflow and fire interfaces.
- Require qualified structural confirmation rather than infer it from this exercise.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0061 · single · mechanism**

Why can room-average floor loading conceal a problem?

1. Average load is always larger than every local load
2. Rack mass is spread through air
3. Every floor has uniform point capacity
4. Rack feet impose concentrated local loads

**Correct option(s):** 4

- Option 1: Incorrect. Concentrated loads can be much higher.
- Option 2: Incorrect. It transfers through supports.
- Option 3: Incorrect. Local behavior depends on construction.
- Option 4: Correct. The local support may see more than the average suggests.

**CDCP-Q0062 · single · diagnosis**

A 1000 kg rack is ideally balanced on four feet. What average mass-equivalent load is on each?

Synthetic educational evidence; not field measurements.

Rack mass: 1000 kg
Feet: four
Assumption: equal ideal static sharing

1. 25 kg
2. 1000 kg
3. 4000 kg
4. 250 kg

**Correct option(s):** 4

- Option 1: Incorrect. That loses a factor of ten.
- Option 2: Incorrect. That assigns the full mass to every foot.
- Option 3: Incorrect. That multiplies instead of divides.
- Option 4: Correct. The ideal equal distribution divides by four.

**CDCP-Q0063 · single · mechanism**

What must be checked before moving a loaded cabinet across access-floor panels?

1. Only the cabinet static-load rating
2. Rolling-load limits and the approved route
3. Only the final rack position
4. Only server power consumption

**Correct option(s):** 2

- Option 1: Incorrect. Rolling and route conditions can have different limits.
- Option 2: Correct. Static acceptance does not establish moving-load suitability.
- Option 3: Incorrect. The route also carries the load.
- Option 4: Incorrect. Electrical load is not mechanical rolling load.

**CDCP-Q0064 · single · mechanism**

Why can an unapproved panel cutout be significant?

1. It always improves every floor property
2. It can affect support, airflow and fire interfaces
3. It automatically creates a rated access opening
4. It changes only the label

**Correct option(s):** 2

- Option 1: Incorrect. It can weaken or leak.
- Option 2: Correct. A cutout changes the installed boundary.
- Option 3: Incorrect. Approval and detailing are required.
- Option 4: Incorrect. The physical component is altered.

**CDCP-Q0065 · single · diagnosis**

A perforated tile has high open area but low flow. What could explain it?

Synthetic educational evidence; not field measurements.

Perforated tile: high open area
Measured flow: low
Plenum pressure: not yet checked

1. Insufficient local plenum pressure
2. The tile must be generating heat
3. The room has too many IP addresses
4. Open area alone guarantees a fixed flow

**Correct option(s):** 1

- Option 1: Correct. Flow depends on pressure as well as opening geometry.
- Option 2: Incorrect. That is not the implied cause.
- Option 3: Incorrect. That is unrelated.
- Option 4: Incorrect. It does not.

**CDCP-Q0066 · single · mechanism**

What should be controlled when panels are removed?

1. Only the network VLAN name
2. Only the room's average humidity
3. Only the work-order title
4. Open hazards, support effects and airflow disruption

**Correct option(s):** 4

- Option 1: Incorrect. That is unrelated.
- Option 2: Incorrect. That does not address the opening.
- Option 3: Incorrect. Physical controls are needed.
- Option 4: Correct. The work changes several conditions.

**CDCP-Q0067 · single · mechanism**

Why inspect beneath a floor before closing it?

1. Concealed defects become harder to observe and correct
2. Closing panels automatically fixes all defects
3. Underfloor conditions cannot affect cooling
4. Concealed cables require no labels

**Correct option(s):** 1

- Option 1: Correct. Hidden services need acceptance evidence.
- Option 2: Incorrect. It does not.
- Option 3: Incorrect. They can change plenum behavior.
- Option 4: Incorrect. Traceability remains important.

**CDCP-Q0068 · single · mechanism**

What is the proper role of a suspended ceiling in load planning?

1. Assume it can carry any cable tray
2. Ignore all hanging loads
3. Use its approved support and load limits
4. Assume every ceiling tile can support a person

**Correct option(s):** 3

- Option 1: Incorrect. Loads need engineered support.
- Option 2: Incorrect. They affect the structure and installation.
- Option 3: Correct. It is not a general-purpose equipment support.
- Option 4: Incorrect. That is unsafe without specific design.

**CDCP-Q0069 · single · mechanism**

Which factor can reduce underfloor air delivery?

1. A calibrated inlet sensor
2. Correctly documented endpoints
3. Cable congestion blocking the intended path
4. A verified clean plenum

**Correct option(s):** 3

- Option 1: Incorrect. It observes rather than blocks flow.
- Option 2: Incorrect. Documentation does not obstruct air.
- Option 3: Correct. Obstructions alter pressure and flow.
- Option 4: Incorrect. That generally supports flow.

**CDCP-Q0070 · single · mechanism**

Why distinguish panel capacity from slab capacity?

1. The slab carries no rack load
2. They are different parts of the load path
3. Only total floor area matters
4. Panel labels always certify the building

**Correct option(s):** 2

- Option 1: Incorrect. Loads ultimately reach the building structure.
- Option 2: Correct. One acceptable component does not approve the entire structure.
- Option 3: Incorrect. Support details and local loads matter.
- Option 4: Incorrect. They do not.

**CDCP-Q0071 · single · mechanism**

What should happen after a rack is moved to a new panel arrangement?

1. Assume all positions are identical
2. Erase the previous record
3. Use power draw as the only acceptance
4. Reassess local loading and affected services

**Correct option(s):** 4

- Option 1: Incorrect. Supports and concealed services can differ.
- Option 2: Incorrect. History should remain traceable.
- Option 3: Incorrect. Mechanical and thermal conditions also matter.
- Option 4: Correct. The original position's evidence may not transfer.

**CDCP-Q0072 · single · mechanism**

Why keep access-floor panels level and seated?

1. Leveling changes application throughput directly
2. Only appearance is affected
3. A level panel needs no support
4. Uneven or unstable panels create loading and trip problems

**Correct option(s):** 4

- Option 1: Incorrect. The primary effect is mechanical.
- Option 2: Incorrect. Stability and movement can be affected.
- Option 3: Incorrect. Pedestals and structure remain necessary.
- Option 4: Correct. Installation quality affects safety and use.

**CDCP-Q0073 · single · mechanism**

What can an unsealed cable penetration cause in an air plenum?

1. Automatic fire-rating improvement
2. Increased electrical stored energy
3. Guaranteed higher flow to every rack
4. Unintended leakage and altered delivery

**Correct option(s):** 4

- Option 1: Incorrect. Openings need approved treatment.
- Option 2: Incorrect. That is unrelated.
- Option 3: Incorrect. Redistribution can reduce useful delivery.
- Option 4: Correct. Supply air can bypass intended outlets.

**CDCP-Q0074 · single · mechanism**

Which evidence supports installed floor acceptance?

1. Only a supplier claim of premium quality
2. Only the number of floor tiles
3. Component identity, support layout and verified installation against approved design
4. Only a clean photograph

**Correct option(s):** 3

- Option 1: Incorrect. That is not installed evidence.
- Option 2: Incorrect. Count does not establish load path integrity.
- Option 3: Correct. A brochure alone does not show the site.
- Option 4: Incorrect. It may hide support defects.

**CDCP-Q0075 · single · mechanism**

Why coordinate ceiling-mounted detectors with new containment?

1. Detectors work identically in every geometry
2. More containment always removes the need for detectors
3. The new geometry can change sensing and access conditions
4. A cooler room automatically preserves detector response

**Correct option(s):** 3

- Option 1: Incorrect. Transport and obstruction matter.
- Option 2: Incorrect. Protection requirements remain.
- Option 3: Correct. Fire interfaces may be affected.
- Option 4: Incorrect. Changed geometry and airflow can alter smoke transport despite lower temperature.

**CDCP-Q0076 · single · mechanism**

What is a point-load assessment concerned with?

1. Total annual energy per room
2. The highest recorded room temperature
3. Number of network endpoints
4. A concentrated force over a local contact

**Correct option(s):** 4

- Option 1: Incorrect. That is an energy metric.
- Option 2: Incorrect. That is thermal data.
- Option 3: Incorrect. That is a connectivity count.
- Option 4: Correct. It differs from a distributed average.

**CDCP-Q0077 · single · mechanism**

Why document concealed service routes?

1. Routes remain unchanged automatically
2. Hidden services cannot be affected by maintenance
3. Documentation makes physical tracing unnecessary in every case
4. Future work can otherwise damage unknown cables or pipes

**Correct option(s):** 4

- Option 1: Incorrect. Moves and additions can alter them.
- Option 2: Incorrect. Work can reach or disturb them.
- Option 3: Incorrect. Verification may still be required.
- Option 4: Correct. Visibility is lost after closure.

**CDCP-Q0078 · single · mechanism**

Which statement about seismic restraint is appropriate here?

1. Obtain the applicable specialist design and installation evidence
2. Rack weight alone eliminates seismic risk
3. Seismic requirements are identical everywhere
4. Any extra bolt guarantees compliance

**Correct option(s):** 1

- Option 1: Correct. This course provides interface literacy rather than structural certification.
- Option 2: Incorrect. Dynamic behavior matters.
- Option 3: Incorrect. Location and governing rules differ.
- Option 4: Incorrect. Restraint must match the engineered requirement.

**CDCP-Q0079 · single · mechanism**

What can a damaged pedestal affect?

1. Only the panel's printed category
2. The local floor support path
3. The optical wavelength
4. Every server certificate

**Correct option(s):** 2

- Option 1: Incorrect. Physical integrity is affected.
- Option 2: Correct. Panel performance depends on its supports.
- Option 3: Incorrect. That is unrelated.
- Option 4: Incorrect. That is unrelated.

**CDCP-Q0080 · single · mechanism**

Why keep thermal and mechanical acceptance separate but connected?

1. Structural approval proves inlet temperatures
2. A floor can satisfy one function while failing the other
3. Airflow determines all structural capacity
4. One passing result proves every function

**Correct option(s):** 2

- Option 1: Incorrect. Thermal testing remains necessary.
- Option 2: Correct. Both load support and air delivery may be required.
- Option 3: Incorrect. It does not.
- Option 4: Incorrect. Different mechanisms need different evidence.

#### Recall

**Why can room-average floor loading conceal a problem?**

Rack feet impose concentrated local loads Correct. The local support may see more than the average suggests.

**A 1000 kg rack is ideally balanced on four feet. What average mass-equivalent load is on each?**

250 kg Correct. The ideal equal distribution divides by four.

**What must be checked before moving a loaded cabinet across access-floor panels?**

Rolling-load limits and the approved route Correct. Static acceptance does not establish moving-load suitability.

**Why can an unapproved panel cutout be significant?**

It can affect support, airflow and fire interfaces Correct. A cutout changes the installed boundary.

**A perforated tile has high open area but low flow. What could explain it?**

Insufficient local plenum pressure Correct. Flow depends on pressure as well as opening geometry.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## CDCP-M05 — Lighting, emergency visibility and maintenance

### CDCP-L05 — Lighting, emergency visibility and maintenance

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L04

Lighting supports safe movement, identification and accurate work. Illuminance is luminous flux incident on an area, measured in lux; luminance concerns the apparent brightness of a surface in a direction. A fixture's lumen rating does not directly establish illuminance at a work surface because geometry, distance, beam distribution, obstructions and surface reflectance affect delivery.

Define tasks before selecting lighting. Reading labels inside a rack, inspecting a floor opening, moving equipment through a corridor and evacuating after power loss have different needs. Avoid glare and deep shadows at the actual work position. A bright aisle can still leave the rear of a cabinet unreadable. Measurements should use representative operating conditions and an appropriate meter, with the relevant plane and locations recorded.

Normal lighting and emergency lighting have different continuity requirements. Emergency arrangements need an approved source, duration, location and test regime suitable to the jurisdiction and site. A lamp that works on normal supply has not demonstrated operation during loss of that supply. Battery-backed luminaires and central systems have different maintenance and failure domains.

Controls can reduce unnecessary energy through occupancy or scheduling, but they must not leave technicians in darkness during quiet or stationary work. Emergency functions must remain available under the approved control and power-loss conditions. Coordinate lighting with cameras, access routes, suspended ceilings and maintenance clearances.

Acceptance includes visual tasks, measured illumination where required, control behavior, source-loss response and restoration. Record failed lamps, battery condition, obstructed fixtures and changes caused by new racks or containment. Efficiency improvements should compare delivered usable light and operating hours, not simply substitute a lower-wattage lamp without checking the task.

### Measure useful illumination instead of installed wattage
A rack technician must read small outlet identifiers at the rear of a cabinet. A meter placed in the open aisle reports a high illuminance, but the cabinet frame and cables cast a shadow on the labels. The aisle result does not answer the task requirement. Define the measurement plane and representative viewing positions, then assess glare, shadows and the actual label task.

A retrofit can lower input power while preserving useful light through better distribution, or it can simply make the task harder. Record both energy and task performance. For a 600 W lighting circuit operating ten hours daily, energy is 6 kWh/day; reducing operation to seven hours saves 1.8 kWh/day only if the control still supports required work.

Test stationary occupancy, manual override and emergency operation separately. A motion sensor can time out while a technician works quietly inside a rack. A lamp that works on normal supply may have a failed backup battery. The accepted system must preserve the required behavior in each defined state, with current maintenance records and accessible fixtures.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. Ten 40 W fixtures operate for 12 hours per day. A proposed controlled arrangement uses the same fixtures for 8 hours while preserving required task and emergency functions.

**Reasoning:** Daily energy falls from 4.8 kWh to 3.2 kWh, an estimated 1.6 kWh reduction. The control change must still be tested for occupied work and emergency operation.

#### Guided practice

A camera view becomes unusable after a lower-power lighting retrofit. What acceptance interface was missed?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** Lighting for surveillance identification. Energy reduction alone did not preserve the required observation task.

#### Independent task

Environment: analytical

Prepare a lighting test sheet for rack work and emergency egress.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- State task locations and measurement plane.
- Test control behavior during stationary work.
- Verify emergency source-loss response through approved methods.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0081 · single · mechanism**

What is illuminance measured in?

1. Watts
2. Lux
3. Amperes
4. Lumens only

**Correct option(s):** 2

- Option 1: Incorrect. Watts measure power.
- Option 2: Correct. Lux describes luminous flux per unit area.
- Option 3: Incorrect. Amperes measure current.
- Option 4: Incorrect. Lumens describe luminous flux, not its distribution over area.

**CDCP-Q0082 · single · mechanism**

Why does a fixture's lumen rating not prove task illumination?

1. Lumens have no relation to light
2. Geometry and distribution determine light reaching the task
3. Every surface receives identical light
4. Electrical voltage alone sets all illuminance

**Correct option(s):** 2

- Option 1: Incorrect. They measure luminous flux.
- Option 2: Correct. The same flux can produce different local illuminance.
- Option 3: Incorrect. Obstructions and distance create differences.
- Option 4: Incorrect. Fixture and geometry matter.

**CDCP-Q0083 · single · diagnosis**

Ten 40 W lamps run for 12 hours. What daily energy is used?

Synthetic educational evidence; not field measurements.

Fixtures: 10
Power per fixture: 40 W
Daily operating time: 12 h

1. 4800 kWh
2. 4.8 kWh
3. 48 kWh
4. 0.4 kWh

**Correct option(s):** 2

- Option 1: Incorrect. That fails the Wh-to-kWh conversion.
- Option 2: Correct. 400 W times 12 hours equals 4800 Wh.
- Option 3: Incorrect. That introduces a tenfold error.
- Option 4: Incorrect. That omits the duration.

**CDCP-Q0084 · single · diagnosis**

The same 400 W lighting load runs 8 instead of 12 hours. What daily saving results?

Synthetic educational evidence; not field measurements.

Lighting power: 400 W
Old duration: 12 h/day
New duration: 8 h/day

1. 0.4 kWh
2. 4.8 kWh
3. 3.2 kWh
4. 1.6 kWh

**Correct option(s):** 4

- Option 1: Incorrect. That is one hour of consumption.
- Option 2: Incorrect. That is the old daily consumption.
- Option 3: Incorrect. That is the new daily consumption.
- Option 4: Correct. Four avoided hours times 0.4 kW equals 1.6.

**CDCP-Q0085 · single · mechanism**

What must be tested separately from normal lamp operation?

1. Emergency operation after the defined supply loss
2. The network link speed
3. The printed fixture model
4. The room's rack count

**Correct option(s):** 1

- Option 1: Correct. Normal power does not prove backup function.
- Option 2: Incorrect. It is unrelated to light continuity.
- Option 3: Incorrect. That is identification, not a separate function.
- Option 4: Incorrect. It does not demonstrate emergency lighting.

**CDCP-Q0086 · single · mechanism**

Why can occupancy controls cause an operational problem?

1. Emergency lighting can always be disabled when motion stops
2. Stationary technicians may not trigger the sensor
3. Every occupied person moves continuously
4. Controls always know the work permit state

**Correct option(s):** 2

- Option 1: Incorrect. Its requirements are separate.
- Option 2: Correct. The task can continue while detected motion stops.
- Option 3: Incorrect. That is not a safe assumption.
- Option 4: Incorrect. Integration must be designed.

**CDCP-Q0087 · single · mechanism**

What can glare reduce?

1. The need for emergency lighting
2. The number of fixtures physically installed
3. Visibility of the task despite high total light
4. Electrical energy consumption automatically

**Correct option(s):** 3

- Option 1: Incorrect. Continuity requirements remain.
- Option 2: Incorrect. Glare does not change count.
- Option 3: Correct. Excess brightness contrast can impair observation.
- Option 4: Incorrect. Glare is an optical usability issue.

**CDCP-Q0088 · single · mechanism**

Why measure at the actual work plane?

1. Meter location affects only the file name
2. Illumination varies with position and orientation
3. All planes have identical lux
4. A ceiling measurement always proves floor visibility

**Correct option(s):** 2

- Option 1: Incorrect. It affects the measured quantity.
- Option 2: Correct. An aisle measurement may not represent a rack interior.
- Option 3: Incorrect. Geometry changes incident light.
- Option 4: Incorrect. It does not.

**CDCP-Q0089 · single · mechanism**

A lower-wattage retrofit makes labels unreadable. What failed?

1. The rack's power redundancy
2. Required task performance
3. Every lamp's electrical input necessarily
4. The principle of energy conservation

**Correct option(s):** 2

- Option 1: Incorrect. That is unrelated.
- Option 2: Correct. Energy savings did not preserve useful illumination.
- Option 3: Incorrect. They may draw the intended lower power.
- Option 4: Incorrect. The issue is delivered lighting adequacy.

**CDCP-Q0090 · single · mechanism**

Why coordinate lighting with surveillance?

1. Only camera cable length matters
2. Image identification depends on target lighting conditions
3. Lighting cannot affect motion blur
4. Cameras create all required light themselves

**Correct option(s):** 2

- Option 1: Incorrect. Optical conditions are also important.
- Option 2: Correct. Camera performance can change after a retrofit.
- Option 3: Incorrect. Exposure behavior can depend on available light.
- Option 4: Incorrect. Not every arrangement does.

**CDCP-Q0091 · single · mechanism**

Which record supports a lighting acceptance measurement?

1. Only one lux number without location
2. Location, plane, conditions, instrument and result
3. Only the installer's opinion
4. Only the lamp invoice

**Correct option(s):** 2

- Option 1: Incorrect. It cannot be interpreted reliably.
- Option 2: Correct. The value needs a reproducible context.
- Option 3: Incorrect. Measurement and task evidence are stronger.
- Option 4: Incorrect. It does not show delivered light.

**CDCP-Q0092 · single · mechanism**

What is a possible common cause in central emergency lighting?

1. Separate room labels
2. Different lamp serial numbers
3. Shared supply or distribution failure
4. Independent test records

**Correct option(s):** 3

- Option 1: Incorrect. Labels do not define electrical dependency.
- Option 2: Incorrect. That does not create a common source.
- Option 3: Correct. Multiple luminaires can depend on one path.
- Option 4: Incorrect. Records are not a power path.

**CDCP-Q0093 · single · mechanism**

Why retain battery condition checks for self-contained emergency lights?

1. Battery age determines all normal illuminance
2. A bright normal lamp proves full runtime
3. Backup duration depends on stored energy health
4. Batteries never age

**Correct option(s):** 3

- Option 1: Incorrect. Normal driver and lamp conditions also matter.
- Option 2: Incorrect. The backup path may differ.
- Option 3: Correct. A normal-supply test can hide battery weakness.
- Option 4: Incorrect. Condition changes over time.

**CDCP-Q0094 · single · mechanism**

What does luminance concern?

1. Apparent surface brightness in a direction
2. Electrical apparent power
3. Airflow through a rack
4. Total diesel fuel volume

**Correct option(s):** 1

- Option 1: Correct. It differs from incident illuminance.
- Option 2: Incorrect. That is kVA.
- Option 3: Incorrect. That is a cooling quantity.
- Option 4: Incorrect. That is unrelated.

**CDCP-Q0095 · single · mechanism**

Why review lighting after adding containment?

1. Containment affects only cooling
2. New surfaces and obstructions can change light distribution
3. Every containment roof improves emergency visibility
4. Previous lux values remain universally valid

**Correct option(s):** 2

- Option 1: Incorrect. It also changes physical geometry.
- Option 2: Correct. The old measurements may no longer represent tasks.
- Option 3: Incorrect. That must be tested.
- Option 4: Incorrect. Conditions have changed.

**CDCP-Q0096 · single · mechanism**

Which comparison supports a fair lighting-efficiency decision?

1. Purchase price alone
2. Energy use for the same required usable illumination and hours
3. Fixture count alone
4. Wattage alone regardless of visibility

**Correct option(s):** 2

- Option 1: Incorrect. Operating and maintenance costs matter.
- Option 2: Correct. Service equivalence matters.
- Option 3: Incorrect. Different fixtures deliver different light.
- Option 4: Incorrect. Lower input can fail the task.

**CDCP-Q0097 · single · mechanism**

What should an emergency lighting test avoid assuming?

1. That successful normal illumination proves backup duration
2. That task visibility matters
3. That lamps consume power
4. That the fixture has a physical location

**Correct option(s):** 1

- Option 1: Correct. The alternate energy path must be verified.
- Option 2: Incorrect. It is a valid requirement.
- Option 3: Incorrect. They do.
- Option 4: Incorrect. Location can be documented.

**CDCP-Q0098 · single · mechanism**

Why include maintenance access for light fixtures?

1. A remote switch repairs every defect
2. Higher mounting always eliminates maintenance
3. Lamps and drivers may need safe inspection or replacement
4. Fixtures never fail after commissioning

**Correct option(s):** 3

- Option 1: Incorrect. Control cannot fix all hardware faults.
- Option 2: Incorrect. It can make maintenance harder.
- Option 3: Correct. Installation must remain serviceable.
- Option 4: Incorrect. They can degrade or fail.

**CDCP-Q0099 · single · mechanism**

A corridor light is bright but casts a dark area at a step. What is the issue?

1. Too much UPS runtime
2. Guaranteed camera failure everywhere
3. Insufficient fixture nameplate voltage necessarily
4. Local visibility and distribution

**Correct option(s):** 4

- Option 1: Incorrect. That is unrelated.
- Option 2: Incorrect. The evidence is local.
- Option 3: Incorrect. The cause can be geometry.
- Option 4: Correct. Average brightness can hide a movement hazard.

**CDCP-Q0100 · single · mechanism**

What belongs in post-retrofit acceptance?

1. Only normal operation at midday
2. Task visibility, controls, emergency function and relevant camera views
3. Only the lower utility estimate
4. Only the number of old lamps removed

**Correct option(s):** 2

- Option 1: Incorrect. Other required conditions remain untested.
- Option 2: Correct. The change affects several interfaces.
- Option 3: Incorrect. Savings alone do not demonstrate suitability.
- Option 4: Incorrect. Removal count is not the required function.

#### Recall

**What is illuminance measured in?**

Lux Correct. Lux describes luminous flux per unit area.

**Why does a fixture's lumen rating not prove task illumination?**

Geometry and distribution determine light reaching the task Correct. The same flux can produce different local illuminance.

**Ten 40 W lamps run for 12 hours. What daily energy is used?**

4.8 kWh Correct. 400 W times 12 hours equals 4800 Wh.

**The same 400 W lighting load runs 8 instead of 12 hours. What daily saving results?**

1.6 kWh Correct. Four avoided hours times 0.4 kW equals 1.6.

**What must be tested separately from normal lamp operation?**

Emergency operation after the defined supply loss Correct. Normal power does not prove backup function.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## CDCP-M06 — Power sizing and distribution acceptance

### CDCP-L06 — Power sizing and distribution acceptance

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L05

Power sizing converts a load envelope into a supported path. For balanced three-phase AC, real power is sqrt(3) times line-to-line voltage times line current times true power factor. Calculate current from required real power only after confirming voltage, phase arrangement and power factor. Then apply the actual equipment and installation limits; a classroom current calculation is not conductor or breaker selection.

Treat every series element as a possible bottleneck: source, switchboard, transformer, UPS, distribution branch, connector, rack PDU and device inlet. Ratings can depend on ambient temperature, altitude, installation method and load duration. Use the governing design and OEM data rather than a universal percentage. A rack feed with adequate kW may still fail a connector-current or phase limit.

Dual-cord equipment often shares normal load between supplies but can transfer most or all demand to the surviving feed. Size and verify the required failure state. If A and B each carry 4 kW normally, loss of A may leave B carrying 8 kW; whether this occurs depends on the device behavior and load. Measure or obtain supported evidence for that behavior instead of assuming equal sharing always persists.

Distribution design also addresses prospective fault current, protective coordination, bonding, voltage drop and service isolation. Normal load current and fault current are different quantities. An assembly with an adequate continuous rating can still be unsuitable for the available fault duty. Protective-device selection requires the qualified electrical design; the data-center reviewer checks that the evidence exists and matches the installed equipment.

Acceptance follows the path from calculations to effective state. Reconcile the approved schedule with measured phases, labels, source mapping and failover response. Record which loads are measured, estimated or nameplate-derived. Hold a new installation when a mandatory constraint is missing rather than inferring approval from a spare outlet.

### Calculate the surviving rack-feed demand
A rack has twelve servers, each drawing 600 W at the required workload. Total real demand is 7.2 kW. If the supplies share equally, each normal feed carries about 3.6 kW. Under the specified full-transfer behavior, one surviving feed must carry 7.2 kW. At 230 V and PF 0.95, that is about 32.95 A before other design constraints. A path approved for 32 A cannot be accepted from the normal-state current alone.

Do not solve this by silently assuming lower workload or perfect diversity. Either change the supported load, distribution design or required service through accountable review. Check every series element, including connector and PDU branches, and obtain the applicable installation and protection evidence from the qualified electrical design.

During commissioning, measure each phase and feed with representative demand, then execute the permitted failure test. Confirm both service behavior and surviving-path current. Restore normal sharing afterward and update the load schedule. An accepted rack is a maintained resource allocation, not a permanent right to add arbitrary future servers.

### Enclosure ingress protection is a scoped rating
An IP code describes protection provided by an enclosure against specified access/solid-object and water-ingress conditions. The first characteristic digit concerns access and solid ingress; the second concerns water. An X means that the particular characteristic is not specified in that code, not a claim of the maximum level. Read the actual standard and product test conditions rather than translating the code into the unbounded word waterproof.

The installed enclosure must preserve the rated arrangement. Cable glands, unused openings, doors, seals and mounting orientation can change the effective protection. A highly rated empty box can lose its intended performance after an unapproved hole is cut. Ingress rating also does not establish fire resistance, fault-current withstand, corrosion suitability or thermal capacity. A tightly sealed enclosure may require additional thermal review because reducing ventilation can increase internal temperature.

In a proposal review, identify the actual exposure, select the applicable required protection through the qualified design, and verify the complete installed assembly. Do not assume that passing one water test proves every other water exposure or indefinite immersion. Keep the current product documentation and installation conditions with the acceptance record.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A balanced 400 V load requires 60 kW at PF 0.9.

**Reasoning:** Line current is 60,000/(1.732×400×0.9)=96.23 A. This is the calculated demand before design margins, installation limits and protection selection.

#### Guided practice

A dual-cord rack draws 4 kW per feed normally. The surviving path supports only 6 kW. Can an 8 kW full-transfer requirement be accepted?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** No. The remaining path is 2 kW short under the stated failover behavior.

#### Independent task

Environment: analytical

Build a rack power schedule for normal and each feed-loss state.

**Packaged starter material**

- course_labs/CDCP/README.md
- course_labs/CDCP/proposal.json
- course_labs/CDCP/answers-template.json

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Check current, kW, kVA and all series path ratings.
- Keep fault-duty evidence distinct from continuous capacity.
- Use measured or supported device failover behavior.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0101 · single · calculation**

A balanced 400 V load is 60 kW at PF 0.9. What line current is approximately required?

Synthetic educational evidence; not field measurements.

Balanced three-phase demand: 60 kW
Line-to-line voltage: 400 V
True PF: 0.90

1. 96 A
2. 86.6 A
3. 260 A
4. 150 A

**Correct option(s):** 1

- Option 1: Correct. P divided by square root of three, voltage and PF gives about 96.2 A.
- Option 2: Incorrect. That assumes unity power factor.
- Option 3: Incorrect. That applies an incorrect phase relationship.
- Option 4: Incorrect. This omits phase and power-factor treatment.

**CDCP-Q0102 · single · calculation**

A rack draws 4 kW on each feed and transfers fully to the survivor. What must each surviving path support?

Synthetic educational evidence; not field measurements.

Normal A demand: 4 kW
Normal B demand: 4 kW
Specified failure behavior: full transfer to surviving feed

1. 4 kW
2. 8 kW
3. 2 kW
4. 16 kW

**Correct option(s):** 2

- Option 1: Incorrect. That is only the normal shared portion.
- Option 2: Correct. The total rack demand remains after one feed fails.
- Option 3: Incorrect. Loss of a feed does not halve the required service load.
- Option 4: Incorrect. The load is not doubled beyond its total demand.

**CDCP-Q0103 · single · mechanism**

Which rating addresses available short-circuit duty?

1. Annual kWh
2. Appropriate fault withstand or interrupting rating
3. Continuous current alone
4. Rack U capacity

**Correct option(s):** 2

- Option 1: Incorrect. Energy consumption does not define short-circuit duty.
- Option 2: Correct. Fault energy is distinct from normal load current.
- Option 3: Incorrect. That does not establish fault capability.
- Option 4: Incorrect. Mechanical height is unrelated.

**CDCP-Q0104 · single · mechanism**

Why is a spare outlet insufficient approval for a new load?

1. Upstream and failure-state capacity may be exhausted
2. Empty outlets always carry zero voltage
3. Connector fit guarantees all path ratings
4. Every outlet has a separate source

**Correct option(s):** 1

- Option 1: Correct. Outlet availability is only one condition.
- Option 2: Incorrect. They may be energized.
- Option 3: Incorrect. It does not.
- Option 4: Incorrect. Several can share a branch.

**CDCP-Q0105 · single · diagnosis**

A path has 32 A connectors but a 25 A approved branch limit. Which governs that constraint?

Synthetic educational evidence; not field measurements.

Connector rating: 32 A
Applicable feeding-branch limit: 25 A

1. 32 A
2. 57 A
3. 7 A
4. 25 A

**Correct option(s):** 4

- Option 1: Incorrect. The connector rating does not raise the branch allowance.
- Option 2: Incorrect. Series ratings do not add.
- Option 3: Incorrect. The difference is not the supported current.
- Option 4: Correct. The series path cannot exceed the smaller applicable limit.

**CDCP-Q0106 · single · mechanism**

Why state whether demand is measured or nameplate-derived?

1. Measurements always cover future peaks
2. The evidence basis and uncertainty differ
3. Nameplates are never useful
4. Both are identical by definition

**Correct option(s):** 2

- Option 1: Incorrect. The observed window can miss later demand.
- Option 2: Correct. A rating is not an observed workload.
- Option 3: Incorrect. They define supported limits.
- Option 4: Incorrect. They describe different evidence.

**CDCP-Q0107 · single · calculation**

What can make phase current the binding limit despite acceptable total kW?

1. An extra rack label
2. A lower total load automatically
3. Uneven load allocation
4. Equal phase loading

**Correct option(s):** 3

- Option 1: Incorrect. Labels do not redistribute current.
- Option 2: Incorrect. A low total does not prove every phase is safe.
- Option 3: Correct. One phase can exceed its rating while aggregate power remains below allocation.
- Option 4: Incorrect. That reduces this particular imbalance.

**CDCP-Q0108 · single · mechanism**

Which input is required for the balanced three-phase current formula?

1. Only battery Ah
2. Line-to-line voltage and true power factor
3. Only line-to-neutral voltage with no conversion
4. Only total annual energy

**Correct option(s):** 2

- Option 1: Incorrect. That does not define the AC load.
- Option 2: Correct. The formula assumes the specified phase relationship.
- Option 3: Incorrect. That would use the wrong form.
- Option 4: Incorrect. A current demand requires a power state.

**CDCP-Q0109 · single · mechanism**

Why review ambient and installation conditions against ratings?

1. Ambient affects only appearance
2. Installation method never affects conductors
3. Ratings are universal at every temperature
4. Supported capacity may depend on those conditions

**Correct option(s):** 4

- Option 1: Incorrect. Thermal limits affect electrical suitability.
- Option 2: Incorrect. Heat dissipation can differ.
- Option 3: Incorrect. Equipment can be derated.
- Option 4: Correct. Nameplate use is bounded.

**CDCP-Q0110 · single · mechanism**

What is a voltage-drop review concerned with?

1. Only the source's invoice
2. Battery chemistry alone
3. Whether the delivered voltage remains within required limits
4. Only the number of sockets

**Correct option(s):** 3

- Option 1: Incorrect. Billing does not establish terminal voltage.
- Option 2: Incorrect. The AC distribution path needs its own assessment.
- Option 3: Correct. The path impedance creates a load-dependent drop.
- Option 4: Incorrect. Length, current and impedance also matter.

**CDCP-Q0111 · single · calculation**

A 70 kW load at PF 0.7 is proposed for a 90 kVA UPS. What is the apparent demand?

Synthetic educational evidence; not field measurements.

Real demand: 70 kW
True PF: 0.70
UPS apparent limit: 90 kVA

1. 49 kVA
2. 70 kVA
3. 100 kVA
4. 90 kVA

**Correct option(s):** 3

- Option 1: Incorrect. Multiplying gives the wrong relationship.
- Option 2: Incorrect. That assumes unity PF.
- Option 3: Correct. 70 divided by 0.7 exceeds the UPS apparent-power limit.
- Option 4: Incorrect. That is the device limit, not the calculated demand.

**CDCP-Q0112 · single · mechanism**

Why verify device behavior during one-feed loss?

1. Power supplies may change sharing and current demand
2. Dual cords always preserve equal sharing after one is lost
3. The cord labels define the internal supply mode
4. Feed loss necessarily halves computation

**Correct option(s):** 1

- Option 1: Correct. The surviving path must support actual behavior.
- Option 2: Incorrect. Only one path remains.
- Option 3: Incorrect. They do not.
- Option 4: Incorrect. That depends on design and controls.

**CDCP-Q0113 · single · mechanism**

What should a power acceptance record connect?

1. Only the UPS screen during no load
2. Only purchase price and serial number
3. Only a successful ping
4. Approved schedule, installed path and measured response

**Correct option(s):** 4

- Option 1: Incorrect. The required load state matters.
- Option 2: Incorrect. Those do not demonstrate electrical behavior.
- Option 3: Incorrect. That is not power-path acceptance.
- Option 4: Correct. Design intent must match effective state.

**CDCP-Q0114 · single · mechanism**

Which activity requires qualified electrical design beyond the simple load calculation?

1. Listing the required service
2. Recording the asset identifier
3. Comparing two supplied kW values
4. Protective-device selection and coordination

**Correct option(s):** 4

- Option 1: Incorrect. That is requirements work.
- Option 2: Incorrect. That is a documentation task.
- Option 3: Incorrect. That is basic analysis.
- Option 4: Correct. Fault behavior and installation rules require specialist analysis.

**CDCP-Q0115 · single · mechanism**

Why can connector type matter even below the nominal branch current?

1. Connector types affect only aesthetics
2. Lower load removes all compatibility requirements
3. Any adapter is acceptable if it fits
4. Mechanical and electrical compatibility are required

**Correct option(s):** 4

- Option 1: Incorrect. They define physical electrical interfaces.
- Option 2: Incorrect. It does not.
- Option 3: Incorrect. Adapters can violate ratings or approvals.
- Option 4: Correct. A rating alone does not establish a supported connection.

**CDCP-Q0116 · single · mechanism**

A normal-state power test passes at half the design load. What remains unproven?

1. Performance at the required full and failure-state loads
2. The existence of a power source
3. That any current flowed
4. Every label necessarily

**Correct option(s):** 1

- Option 1: Correct. The test covered a narrower demand.
- Option 2: Incorrect. That was exercised.
- Option 3: Incorrect. The test can establish that narrow fact.
- Option 4: Incorrect. Labeling is a separate check.

**CDCP-Q0117 · single · mechanism**

What should happen if fault-duty documentation is absent?

1. Replace the missing document with a photograph
2. Assume the largest breaker is sufficient
3. Approve because the breaker has not tripped
4. Hold the unresolved acceptance item and obtain the required evidence

**Correct option(s):** 4

- Option 1: Incorrect. Appearance does not establish the calculation.
- Option 2: Incorrect. Size alone is not fault rating.
- Option 3: Incorrect. Past operation does not prove fault suitability.
- Option 4: Correct. Continuous-load success does not fill the gap.

**CDCP-Q0118 · single · mechanism**

Which value is a load envelope rather than a single operating point?

1. Normal, peak, startup and failover demand with assumptions
2. One idle reading
3. A monthly average alone
4. One supply nameplate

**Correct option(s):** 1

- Option 1: Correct. It covers relevant states.
- Option 2: Incorrect. That is one state only.
- Option 3: Incorrect. It can hide peaks.
- Option 4: Incorrect. It is a rating rather than a complete demand model.

**CDCP-Q0119 · single · mechanism**

Why trace both rack feeds upstream?

1. Two PDUs always provide 2N facility power
2. Different outlets may converge on one failure domain
3. Source tracing matters only after an outage
4. Different rack PDUs guarantee separate upstream sources

**Correct option(s):** 2

- Option 1: Incorrect. Upstream paths can be shared.
- Option 2: Correct. Local separation does not prove independence.
- Option 3: Incorrect. It is needed before acceptance and work.
- Option 4: Incorrect. Both PDUs can converge on one branch or source.

**CDCP-Q0120 · single · diagnosis**

An enclosure is marked IP followed by two characteristic digits. What does the second digit describe?

1. Specified protection against water ingress
2. The degree of fire resistance
3. The available short-circuit current
4. The maximum continuous load current

**Correct option(s):** 1

- Option 1: Correct. The second characteristic digit addresses water under defined test conditions.
- Option 2: Incorrect. Fire resistance is a separate property and assessment.
- Option 3: Incorrect. Fault-duty ratings are separate from IP ingress codes.
- Option 4: Incorrect. Current capacity is not encoded by the water-ingress digit.

#### Recall

**A balanced 400 V load is 60 kW at PF 0.9. What line current is approximately required?**

96 A Correct. P divided by square root of three, voltage and PF gives about 96.2 A.

**A rack draws 4 kW on each feed and transfers fully to the survivor. What must each surviving path support?**

8 kW Correct. The total rack demand remains after one feed fails.

**Which rating addresses available short-circuit duty?**

Appropriate fault withstand or interrupting rating Correct. Fault energy is distinct from normal load current.

**Why is a spare outlet insufficient approval for a new load?**

Upstream and failure-state capacity may be exhausted Correct. Outlet availability is only one condition.

**A path has 32 A connectors but a 25 A approved branch limit. Which governs that constraint?**

25 A Correct. The series path cannot exceed the smaller applicable limit.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## CDCP-M07 — Power quality, harmonics and measurement

### CDCP-L07 — Power quality, harmonics and measurement

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L06

Power quality describes whether voltage and current characteristics remain suitable for the connected equipment. Disturbances include sags, swells, interruptions, transients, frequency deviations, imbalance and waveform distortion. Duration and magnitude matter: a short transient is not the same event as a sustained undervoltage, and different loads have different ride-through behavior.

Nonlinear loads draw current that is not a sinusoidal scaled copy of voltage. Harmonic components occur at integer multiples of the fundamental frequency. Current distortion can create additional heating and interact with system impedance to distort voltage. Triplen harmonics in certain three-phase four-wire arrangements can add in the neutral rather than cancel; therefore a low fundamental imbalance does not automatically prove low neutral current.

True RMS describes the heating-equivalent magnitude of a waveform. An average-responding instrument calibrated for sine waves can misread distorted signals. True power factor includes distortion effects as well as phase displacement. Measurement equipment must suit the waveform, category, bandwidth, event duration and safety requirements; a monthly kWh meter is not necessarily an adequate transient recorder.

Mitigation follows diagnosis. Loose connections, overloaded paths, incompatible load steps, source impedance and nonlinear demand require different remedies. Filters, source changes or UPS operating modes can help in suitable designs but may introduce interactions. Do not install a harmonic filter from a headline THD number alone; qualified analysis should consider the network and operating states.

Collect synchronized evidence at useful boundaries. Compare upstream and downstream events with load transitions and service symptoms. Correlation helps locate the source but does not alone prove causation. Retain waveform or event records where needed, and verify that a corrective change improves the intended parameter without violating protection, efficiency or capacity requirements.

### Distinguish disturbance hypotheses using evidence
Servers reset during a large motor start. Three hypotheses are plausible: a source-voltage sag, conducted interference through shared impedance, or an unrelated server defect. Place suitable synchronized instruments at the relevant electrical boundaries under an authorized measurement plan. Record the motor event, voltage behavior and server symptom with enough time resolution to capture the suspected duration.

If the upstream voltage stays within its accepted envelope while a downstream connection shows a drop and heating, investigate that local path. If both boundaries show the disturbance, the source or load-step interaction may be broader. A coincident event alone is not proof of one cause; combine timing with a physically credible mechanism and repeatable or corroborating observations.

For nonlinear loads, retain waveform and harmonic information rather than relying only on fundamental current. True RMS supports heating assessment, while THD characterizes distortion relative to its reference. Neither replaces all the other. A correction should be retested under comparable load and checked for protection, capacity and efficiency side effects.

### Interpret thermography as a measurement, not a colored verdict
A thermal imager observes infrared radiation and estimates surface temperature using assumptions about emissivity, reflected radiation, viewing geometry and atmospheric path. A shiny surface can reflect a nearby warm object and appear hot without having that same physical temperature. Compare suitable like-for-like components under known load and use the instrument's supported method. A bright image region is a diagnostic lead, not automatically a proven loose connection.

Load matters because resistive heating follows current squared times resistance. A connection inspected at light load can look unremarkable yet heat excessively under the required demand. Record current or load, ambient conditions, surface/material assumptions, location and image metadata. Temperature comparisons across unlike materials can be misleading without appropriate correction.

Electrical enclosures introduce access and energy hazards. Thermographic work follows the authorized inspection method and applicable safe-work controls; this course does not provide a live-panel opening procedure. If an anomaly is found, assess it through the approved severity and response process, investigate the cause and verify the correction under comparable conditions. The thermal image complements electrical and physical evidence rather than replacing all of it.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A three-phase panel has similar fundamental phase currents but unexpectedly high neutral current. Nonlinear single-phase loads are connected.

**Reasoning:** Harmonic content, especially relevant zero-sequence components, is a plausible contributor. Measure the waveform and neutral current with suitable equipment rather than concluding that balanced fundamental currents guarantee neutral cancellation.

#### Guided practice

A meter logs one-minute averages while servers reset during a millisecond event. What evidence limitation exists?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** The sampling and recording scheme may miss the disturbance. Use appropriate event capture coordinated with authorized electrical work.

#### Independent task

Environment: analytical

Prepare a power-quality investigation plan for intermittent resets.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Classify disturbance by magnitude and duration.
- Choose instruments and capture windows suited to the hypothesis.
- Correlate electrical events with service symptoms without claiming causation prematurely.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0121 · single · mechanism**

Why distinguish a sag from an interruption?

1. Their remaining voltage and duration characteristics differ
2. Both always mean exactly zero volts
3. An interruption is always harmless below one hour
4. A sag is only a current increase

**Correct option(s):** 1

- Option 1: Correct. Loads may respond differently to each event.
- Option 2: Incorrect. A sag retains reduced voltage.
- Option 3: Incorrect. Load tolerance can be much shorter.
- Option 4: Incorrect. It concerns voltage reduction.

**CDCP-Q0122 · single · mechanism**

What is a harmonic relative to the fundamental?

1. The difference between two rack heights
2. The average monthly energy
3. An integer-multiple frequency component
4. Any unrelated radio signal only

**Correct option(s):** 3

- Option 1: Incorrect. That is unrelated.
- Option 2: Incorrect. That is not a waveform component.
- Option 3: Correct. It describes waveform spectral content.
- Option 4: Incorrect. Harmonics have a defined frequency relationship.

**CDCP-Q0123 · single · diagnosis**

Why can neutral current remain high with balanced fundamental phase currents?

Synthetic educational evidence; not field measurements.

Fundamental phase currents: similar
Neutral RMS current: unexpectedly high
Loads: nonlinear single-phase equipment

1. Every harmonic always cancels perfectly
2. Equal phase labels prove zero current
3. Certain harmonic components can add in the neutral
4. The neutral never carries current

**Correct option(s):** 3

- Option 1: Incorrect. That is not true for all components.
- Option 2: Incorrect. Labels do not establish waveform behavior.
- Option 3: Correct. Fundamental balance does not ensure harmonic cancellation.
- Option 4: Incorrect. It can carry imbalance and harmonic current.

**CDCP-Q0124 · single · mechanism**

What does true RMS represent?

1. Peak value multiplied by any fixed factor for all waveforms
2. Frequency alone
3. Heating-equivalent waveform magnitude
4. Only the average signed AC voltage

**Correct option(s):** 3

- Option 1: Incorrect. The sine-wave relationship is not universal.
- Option 2: Incorrect. RMS is a magnitude measure.
- Option 3: Correct. It accounts for the actual waveform within instrument limits.
- Option 4: Incorrect. That can approach zero for a symmetric waveform.

**CDCP-Q0125 · single · diagnosis**

Why may a one-minute average miss a server-reset cause?

Synthetic educational evidence; not field measurements.

Meter record: one-minute average
Suspected disturbance: millisecond duration

1. Average meters always store full waveforms
2. A short disturbance can be averaged away
3. The server must be defective
4. Short events cannot affect equipment

**Correct option(s):** 2

- Option 1: Incorrect. That feature cannot be assumed.
- Option 2: Correct. The recording interval may not capture the event.
- Option 3: Incorrect. Electrical evidence is still incomplete.
- Option 4: Incorrect. Ride-through limits can be brief.

**CDCP-Q0126 · single · mechanism**

What distinguishes true power factor from displacement factor?

1. Displacement factor measures only cable length
2. Both measure annual energy price
3. True PF is always one
4. True PF includes waveform distortion effects

**Correct option(s):** 4

- Option 1: Incorrect. It describes phase relation.
- Option 2: Incorrect. They are electrical ratios.
- Option 3: Incorrect. It depends on the load and waveform.
- Option 4: Correct. Phase shift alone is incomplete for nonlinear current.

**CDCP-Q0127 · single · mechanism**

Which approach is best before selecting a harmonic filter?

1. Characterize the system, loads and operating states
2. Choose from THD alone with no boundary
3. Assume every reset is harmonic-related
4. Use the largest filter available without analysis

**Correct option(s):** 1

- Option 1: Correct. Mitigation can interact with the network.
- Option 2: Incorrect. One number omits important conditions.
- Option 3: Incorrect. Other disturbances can cause symptoms.
- Option 4: Incorrect. That can be unsuitable.

**CDCP-Q0128 · single · mechanism**

What can system impedance do with harmonic current?

1. Produce harmonic voltage distortion
2. Guarantee neutral current is zero
3. Convert every harmonic into useful IT work
4. Eliminate all waveform effects automatically

**Correct option(s):** 1

- Option 1: Correct. Current flowing through impedance creates voltage components.
- Option 2: Incorrect. Neutral behavior depends on components and topology.
- Option 3: Incorrect. That is not the mechanism.
- Option 4: Incorrect. Impedance can transmit or amplify effects.

**CDCP-Q0129 · single · mechanism**

Why synchronize power-quality and server event records?

1. It improves temporal correlation
2. It proves causation by itself
3. It removes every logging delay
4. It changes the electrical waveform

**Correct option(s):** 1

- Option 1: Correct. Related observations need a common time basis.
- Option 2: Incorrect. Coincidence still needs mechanism and further evidence.
- Option 3: Incorrect. Instrument behavior still needs understanding.
- Option 4: Incorrect. Synchronization is observational.

**CDCP-Q0130 · single · mechanism**

A voltage swell differs from a sag in what basic way?

1. A sag is always longer than a swell
2. A swell is only a battery event
3. A swell always changes frequency only
4. Voltage rises rather than falls relative to the reference

**Correct option(s):** 4

- Option 1: Incorrect. Duration classification is separate.
- Option 2: Incorrect. It can occur in AC distribution.
- Option 3: Incorrect. It is a voltage-magnitude event.
- Option 4: Correct. Magnitude direction differs.

**CDCP-Q0131 · single · mechanism**

What should guide instrument selection for a transient investigation?

1. Only its purchase price
2. Event bandwidth, duration, range and safety suitability
3. Only whether it measures kWh
4. Only the number of display digits

**Correct option(s):** 2

- Option 1: Incorrect. Cost does not establish capability.
- Option 2: Correct. The instrument must capture the relevant phenomenon safely.
- Option 3: Incorrect. Energy measurement may miss transients.
- Option 4: Incorrect. Resolution alone is insufficient.

**CDCP-Q0132 · single · mechanism**

Why can nonlinear current create additional heating?

1. Harmonics carry no current
2. Every harmonic cools the conductor
3. RMS current and harmonic losses can increase
4. Heating depends only on the fundamental frequency label

**Correct option(s):** 3

- Option 1: Incorrect. They are current components.
- Option 2: Incorrect. That is not the loss mechanism.
- Option 3: Correct. Heating depends on the actual waveform and equipment.
- Option 4: Incorrect. Current and material behavior matter.

**CDCP-Q0133 · single · mechanism**

What does a successful corrective change require?

1. Only fewer complaints
2. Improved target behavior without unacceptable side effects
3. Only a lower single metric
4. Only installing the recommended product

**Correct option(s):** 2

- Option 1: Incorrect. Observation may be incomplete.
- Option 2: Correct. Mitigation must preserve other constraints.
- Option 3: Incorrect. Other ratings or protection can be affected.
- Option 4: Incorrect. Implementation is not demonstrated improvement.

**CDCP-Q0134 · single · diagnosis**

A disturbance appears downstream but not at a synchronized upstream recorder. What is a reasonable next step?

Synthetic educational evidence; not field measurements.

Upstream synchronized recorder: no event
Downstream recorder: disturbance captured

1. Replace every UPS immediately
2. Investigate local loads and connections within the measurement limits
3. Assume no electrical event occurred
4. Declare the utility responsible

**Correct option(s):** 2

- Option 1: Incorrect. Diagnosis should guide the intervention.
- Option 2: Correct. The evidence narrows, but does not perfectly prove, the source region.
- Option 3: Incorrect. The downstream recorder observed one.
- Option 4: Incorrect. The upstream evidence does not support that directly.

**CDCP-Q0135 · single · mechanism**

Why distinguish voltage THD from current THD?

1. Both are always numerically identical
2. Voltage THD is a physical cable length
3. They describe different quantities at a defined boundary
4. Current THD measures only energy use

**Correct option(s):** 3

- Option 1: Incorrect. System impedance and loads affect their relationship.
- Option 2: Incorrect. It is a waveform ratio.
- Option 3: Correct. One does not automatically equal the other.
- Option 4: Incorrect. It describes distortion.

**CDCP-Q0136 · single · mechanism**

Which disturbance description is most useful?

1. Magnitude, duration, location and operating context
2. A monthly energy total only
3. The supplier's brand only
4. Bad power

**Correct option(s):** 1

- Option 1: Correct. These support load-tolerance and cause analysis.
- Option 2: Incorrect. That does not characterize a transient.
- Option 3: Incorrect. Brand does not identify the event.
- Option 4: Incorrect. The phrase is too vague.

**CDCP-Q0137 · single · mechanism**

Why not assume a UPS removes every power-quality problem?

1. Topology, mode and limits determine its behavior
2. Batteries eliminate downstream wiring faults
3. UPS equipment never conditions power
4. Every mode is electrically identical

**Correct option(s):** 1

- Option 1: Correct. Bypass and overload states can change protection.
- Option 2: Incorrect. They do not repair distribution defects.
- Option 3: Incorrect. Many designs do.
- Option 4: Incorrect. The load path can change.

**CDCP-Q0138 · single · mechanism**

What can a loose connection contribute to?

1. Additional battery capacity
2. Local voltage drop, heating and intermittent disturbance
3. Guaranteed lower resistance
4. Perfect waveform filtering

**Correct option(s):** 2

- Option 1: Incorrect. That is unrelated.
- Option 2: Correct. Contact condition affects the current path.
- Option 3: Incorrect. Loose or degraded contact can increase resistance.
- Option 4: Incorrect. It is not an engineered filter.

**CDCP-Q0139 · single · mechanism**

Why retain raw waveform evidence where possible?

1. Summary statistics can hide event shape and timing
2. Every waveform proves an attack
3. A screenshot always captures the complete record
4. Waveforms eliminate the need for context

**Correct option(s):** 1

- Option 1: Correct. Detailed traces support diagnosis.
- Option 2: Incorrect. Most disturbances have multiple possible causes.
- Option 3: Incorrect. It may omit samples and metadata.
- Option 4: Incorrect. Load and location still matter.

**CDCP-Q0140 · single · diagnosis**

A thermal survey is performed at 15% of the required electrical load. What limitation should the report state?

Synthetic educational evidence.

Thermographic inspection load: 15% of required demand
No full-load comparison supplied.

1. Temperature is independent of current
2. The observation may not reveal heating at the required load
3. A thermal camera directly measures contact resistance
4. The image proves every full-load connection is acceptable

**Correct option(s):** 2

- Option 1: Incorrect. Current through resistance creates heat.
- Option 2: Correct. Resistive heating depends on current squared, so load context is material.
- Option 3: Incorrect. It estimates surface temperature, not resistance directly.
- Option 4: Incorrect. The tested demand is much lower than the required state.

#### Recall

**Why distinguish a sag from an interruption?**

Their remaining voltage and duration characteristics differ Correct. Loads may respond differently to each event.

**What is a harmonic relative to the fundamental?**

An integer-multiple frequency component Correct. It describes waveform spectral content.

**Why can neutral current remain high with balanced fundamental phase currents?**

Certain harmonic components can add in the neutral Correct. Fundamental balance does not ensure harmonic cancellation.

**What does true RMS represent?**

Heating-equivalent waveform magnitude Correct. It accounts for the actual waveform within instrument limits.

**Why may a one-minute average miss a server-reset cause?**

A short disturbance can be averaged away Correct. The recording interval may not capture the event.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## CDCP-M08 — Transformers, microgrids and alternate energy sources

### CDCP-L08 — Transformers, microgrids and alternate energy sources

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L07

A transformer transfers AC energy through magnetic coupling and changes voltage according to winding arrangement. Its losses include components that occur when energized and components that grow with loading. Selection considers voltage, phase, impedance, thermal limits, fault behavior, installation environment and the intended grounding scheme. An isolation transformer can separate circuits galvanically in the specified arrangement, but it does not create energy or guarantee independent upstream sources.

A microgrid combines loads and distributed energy resources within a controlled electrical boundary. Depending on design and permissions, it may operate connected to the utility or in an islanded state. Islanding is a control and protection transition, not merely disconnecting a breaker. The system must maintain acceptable voltage and frequency, balance generation and demand, manage protection and support reconnection under the approved scheme.

Solar generation, batteries, fuel cells and engines have different energy, power and dynamic properties. A battery can provide rapid power but finite stored energy. Solar output depends on resource and conversion availability. A fuel cell depends on fuel supply and its own support systems. Evaluate each source against mission duration, response, maintainability, emissions and common dependencies rather than treating a low-carbon label as a continuity guarantee.

The energy balance is explicit: generation plus discharge must cover load plus losses and any charging. Storage state of charge constrains how long it can support a deficit. Reserve dedicated to resilience cannot be spent for tariff optimization without a controlled decision. A dispatch plan that empties the battery before an outage can meet a cost objective while violating the service reserve requirement.

Acceptance must cover transitions, not just steady states. Verify source availability, controller failure behavior, load shedding priorities, black-start assumptions where applicable, synchronization and return to grid. Actual grid interconnection and protection work belongs to qualified specialists and the relevant authority. The facility engineer integrates requirements and evidence across those interfaces.

### Balance an islanded interval with reserve
A microgrid has a 900 kW critical load, 500 kW firm local generation and 1000 kWh usable battery energy. The initial deficit is 400 kW. If 200 kWh must remain reserved, only 800 kWh is available for the modeled interval, giving two hours before reaching reserve, ignoring losses. Quoting 2.5 hours from the full stored quantity would violate the reserve policy.

Now add 150 kW of noncritical load. Keeping it would reduce the same interval to 800/550=1.45 hours. A load-shedding decision should follow the defined minimum service and safety priorities, not whichever circuit is easiest to disconnect. The controller's authority and fallback behavior must be explicit.

The energy model still does not prove islanding. The system must establish voltage and frequency, manage source limits and protection, and reconnect under the approved interconnection scheme. Test or simulate those mechanisms at the appropriate fidelity and record what remains dependent on qualified electrical design and physical validation.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A site load is 1 MW. Local generation supplies 700 kW and a battery has 600 kWh usable energy for discharge. Ignore losses for this first model.

**Reasoning:** The deficit is 300 kW, so the battery can bridge two hours at that deficit. If reserve or losses apply, the usable duration is lower.

#### Guided practice

A tariff optimizer uses the battery down to 10% while the continuity plan assumes 60% minimum reserve. What conflict exists?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** Economic dispatch has violated the approved resilience reserve. The control objectives and authority need reconciliation.

#### Independent task

Environment: analytical

Create a microgrid operating-state and dependency table.

**Packaged starter material**

- course_labs/CDCP/README.md
- course_labs/CDCP/proposal.json
- course_labs/CDCP/answers-template.json

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Separate power from energy and resource availability.
- Include reserve and islanding constraints.
- Assign qualified protection and interconnection review.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0141 · single · calculation**

A 1 MW load has 700 kW local generation. What storage discharge is needed before losses?

Synthetic educational evidence; not field measurements.

Critical demand: 1000 kW
Firm local generation: 700 kW

1. 300 kW
2. 700 kW
3. 1000 kW
4. 1700 kW

**Correct option(s):** 1

- Option 1: Correct. The source deficit is load minus generation.
- Option 2: Incorrect. That is existing generation.
- Option 3: Incorrect. That ignores local generation.
- Option 4: Incorrect. Adding source and load is incorrect.

**CDCP-Q0142 · single · calculation**

With 600 kWh usable storage and a 300 kW deficit, what ideal duration is available?

Synthetic educational evidence; not field measurements.

Usable storage: 600 kWh
Power deficit: 300 kW
Ignore losses for this first calculation.

1. 0.5 hours
2. 180000 hours
3. 2 hours
4. 600 hours

**Correct option(s):** 3

- Option 1: Incorrect. The ratio is reversed.
- Option 2: Incorrect. Multiplication is dimensionally wrong.
- Option 3: Correct. Energy divided by deficit power gives duration.
- Option 4: Incorrect. That ignores the discharge power.

**CDCP-Q0143 · single · mechanism**

What is islanding in a microgrid context?

1. Running every load from solar at night
2. Opening any breaker without further control
3. Installing a second billing meter
4. Operating a defined local electrical system separated from the utility

**Correct option(s):** 4

- Option 1: Incorrect. Source availability must be considered.
- Option 2: Incorrect. The transition needs engineered behavior.
- Option 3: Incorrect. That does not create islanded capability.
- Option 4: Correct. The local system must maintain its own balance and quality.

**CDCP-Q0144 · single · mechanism**

Why is a battery's high power rating insufficient for long autonomy?

1. Runtime depends only on maximum inverter current
2. Energy is measured only in amperes
3. High power always means infinite energy
4. Stored usable energy limits duration

**Correct option(s):** 4

- Option 1: Incorrect. Power-delivery capacity does not specify stored usable energy.
- Option 2: Incorrect. It is commonly measured in kWh.
- Option 3: Incorrect. It does not.
- Option 4: Correct. Power and energy are separate constraints.

**CDCP-Q0145 · single · mechanism**

What can tariff optimization conflict with?

1. The existence of battery terminals
2. The definition of frequency
3. Required resilience state-of-charge reserve
4. The rack mounting width

**Correct option(s):** 3

- Option 1: Incorrect. The issue is operating policy.
- Option 2: Incorrect. The conflict concerns energy reserve.
- Option 3: Correct. Economic discharge can consume continuity margin.
- Option 4: Incorrect. That is unrelated.

**CDCP-Q0146 · single · mechanism**

Which transformer property affects fault-current behavior?

1. Impedance
2. Room name
3. Only the no-load energy loss
4. Asset-tag length

**Correct option(s):** 1

- Option 1: Correct. It influences current under fault conditions.
- Option 2: Incorrect. Naming does not establish fault behavior.
- Option 3: Incorrect. Fault behavior depends on impedance and the network, not solely the no-load loss figure.
- Option 4: Incorrect. Identity text is unrelated.

**CDCP-Q0147 · single · mechanism**

What is a correct energy-balance statement?

1. Nameplate capacities add directly to stored energy
2. Sources and discharge must cover loads, losses and charging
3. Charging creates energy without input
4. Losses can be ignored in every final design

**Correct option(s):** 2

- Option 1: Incorrect. Power and energy are different.
- Option 2: Correct. All flows must be included.
- Option 3: Incorrect. It consumes source energy.
- Option 4: Incorrect. They affect capacity and autonomy.

**CDCP-Q0148 · single · mechanism**

Why review solar resource for continuity claims?

1. Solar always produces full output
2. Resource affects only purchase price
3. Output depends on time, weather and equipment availability
4. Solar generation cannot support any load

**Correct option(s):** 3

- Option 1: Incorrect. Resource varies.
- Option 2: Incorrect. It affects delivered energy.
- Option 3: Correct. Nameplate capacity is not continuous assured power.
- Option 4: Incorrect. It can contribute within its envelope.

**CDCP-Q0149 · single · mechanism**

What does galvanic isolation not establish by itself?

1. A need for thermal limits
2. Electrical separation under the specified design
3. Independent upstream energy supply
4. A winding arrangement

**Correct option(s):** 3

- Option 1: Incorrect. Those remain applicable.
- Option 2: Incorrect. That can be its purpose.
- Option 3: Correct. Isolation can still use one common source.
- Option 4: Incorrect. The transformer still has one.

**CDCP-Q0150 · single · mechanism**

Why is microgrid reconnection a controlled transition?

1. Any closed breaker automatically synchronizes sources
2. Reconnection changes only accounting
3. Sources must satisfy the approved synchronization and protection conditions
4. Loads must always be zero for every design

**Correct option(s):** 3

- Option 1: Incorrect. It does not.
- Option 2: Incorrect. It changes the electrical relationship.
- Option 3: Correct. Uncontrolled paralleling can be unsuitable or hazardous.
- Option 4: Incorrect. Requirements depend on the engineered arrangement.

**CDCP-Q0151 · single · mechanism**

What should load-shedding priorities reflect?

1. The newest equipment first
2. Minimum useful service and safety constraints
3. Alphabetical asset order
4. Whichever breaker is easiest to reach

**Correct option(s):** 2

- Option 1: Incorrect. Age alone is not the service priority.
- Option 2: Correct. Not every load has equal consequence.
- Option 3: Incorrect. Names do not define criticality.
- Option 4: Incorrect. Convenience does not define importance.

**CDCP-Q0152 · single · calculation**

A fuel cell has adequate kW but no assured fuel supply. What remains unresolved?

1. Mission-duration energy availability
2. The existence of electrical conversion
3. The meaning of its nameplate
4. Every downstream load identity

**Correct option(s):** 1

- Option 1: Correct. Power capability does not guarantee sustained fuel.
- Option 2: Incorrect. The equipment may perform it when fueled.
- Option 3: Incorrect. The rating can still be valid.
- Option 4: Incorrect. That is a separate issue.

**CDCP-Q0153 · single · mechanism**

Why consider transformer losses at actual loading?

1. Fixed and load-dependent losses affect efficiency differently
2. Loading changes only the asset number
3. Every transformer has identical loss curves
4. Losses are always exactly zero

**Correct option(s):** 1

- Option 1: Correct. Oversizing can change operating efficiency.
- Option 2: Incorrect. It affects electrical operation.
- Option 3: Incorrect. Designs differ.
- Option 4: Incorrect. Real transformers dissipate energy.

**CDCP-Q0154 · single · mechanism**

What is a black-start assumption?

1. A guarantee that every load starts simultaneously
2. A restart that depends on the already energized utility
3. The ability and prerequisites to energize a system without an external live source
4. Any normal grid-connected startup

**Correct option(s):** 3

- Option 1: Incorrect. Sequencing may be required.
- Option 2: Incorrect. Black start specifically examines operation without that external live source.
- Option 3: Correct. Auxiliaries and sequence matter.
- Option 4: Incorrect. That uses an available external source.

**CDCP-Q0155 · single · mechanism**

Why include controller failure in microgrid testing?

1. More sources eliminate all control dependencies
2. Controllers never fail
3. Dispatch and transition behavior can depend on it
4. Controller failure affects only reporting

**Correct option(s):** 3

- Option 1: Incorrect. Shared logic can remain.
- Option 2: Incorrect. Hardware, software and communications can fail.
- Option 3: Correct. Multiple sources can share control authority.
- Option 4: Incorrect. It can affect actual source coordination.

**CDCP-Q0156 · single · mechanism**

Which decision requires qualified interconnection review?

1. Calculating a simple energy deficit
2. Naming a study worksheet
3. Listing the service objective
4. Utility paralleling and protection arrangements

**Correct option(s):** 4

- Option 1: Incorrect. That is analytical preparation.
- Option 2: Incorrect. That is not interconnection engineering.
- Option 3: Incorrect. That is requirements work.
- Option 4: Correct. The electrical and regulatory interface is consequential.

**CDCP-Q0157 · single · calculation**

A battery reserve is 60%, but dispatch allows 10%. What must be resolved?

Synthetic educational evidence; not field measurements.

Continuity reserve policy: minimum 60%
Economic dispatch floor: 10%

1. Every tariff calculation is invalid
2. The battery must be physically empty already
3. Conflicting control objectives and authority
4. Only the displayed state-of-charge decimal precision

**Correct option(s):** 3

- Option 1: Incorrect. The financial calculation can be correct while unsuitable.
- Option 2: Incorrect. The settings indicate risk, not necessarily current state.
- Option 3: Correct. The economic policy undermines the continuity requirement.
- Option 4: Incorrect. The conflict is between actual reserve policy and dispatch authority.

**CDCP-Q0158 · single · mechanism**

Why compare alternate sources over the lifecycle?

1. New technology removes all maintenance
2. Fuel, maintenance, emissions, response and recovery differ
3. Lowest purchase cost always means lowest ownership cost
4. Every low-carbon source is equally firm

**Correct option(s):** 2

- Option 1: Incorrect. Support systems remain.
- Option 2: Correct. No single label captures suitability.
- Option 3: Incorrect. Recurring and risk costs can differ.
- Option 4: Incorrect. Availability and duration differ.

**CDCP-Q0159 · single · mechanism**

What does a steady grid-connected test fail to prove?

1. That energy can be measured
2. Islanded transition and sustained local operation
3. That the utility connection exists
4. That any load was supplied

**Correct option(s):** 2

- Option 1: Incorrect. That is a separate capability.
- Option 2: Correct. Different states impose different requirements.
- Option 3: Incorrect. It was used.
- Option 4: Incorrect. The test can show that narrow fact.

**CDCP-Q0160 · single · mechanism**

Why include charging load in generator or microgrid sizing?

1. Restoring storage consumes additional source capacity
2. Only IT racks consume power
3. Storage recharges without energy input
4. Charging always reduces total demand

**Correct option(s):** 1

- Option 1: Correct. The source must support simultaneous demands.
- Option 2: Incorrect. Auxiliaries and storage also consume it.
- Option 3: Incorrect. That violates conservation.
- Option 4: Incorrect. It adds demand before future discharge.

#### Recall

**A 1 MW load has 700 kW local generation. What storage discharge is needed before losses?**

300 kW Correct. The source deficit is load minus generation.

**With 600 kWh usable storage and a 300 kW deficit, what ideal duration is available?**

2 hours Correct. Energy divided by deficit power gives duration.

**What is islanding in a microgrid context?**

Operating a defined local electrical system separated from the utility Correct. The local system must maintain its own balance and quality.

**Why is a battery's high power rating insufficient for long autonomy?**

Stored usable energy limits duration Correct. Power and energy are separate constraints.

**What can tariff optimization conflict with?**

Required resilience state-of-charge reserve Correct. Economic discharge can consume continuity margin.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## CDCP-M09 — Transfer systems and generator acceptance

### CDCP-L09 — Transfer systems and generator acceptance

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L08

Transfer equipment connects a load to an acceptable source under a defined sequence. An ATS commonly operates electromechanical switching between normal and alternate supplies; an STS uses semiconductor devices for a fast transfer application. Selection depends on load tolerance, source characteristics, synchronization, fault behavior and maintenance access. The terms do not alone specify every interruption time or operating constraint.

A generator-support sequence includes outage detection, start delay, cranking, voltage/frequency stabilization, transfer permission, load acceptance and later retransfer. The UPS must bridge the required interval, including a credible failed-start or delayed-transfer scenario if that is part of the specification. Record timing from the service boundary rather than adding nominal brochure times without checking overlap and conditions.

Generator capacity must address step loads, motor starting, nonlinear loads, auxiliaries and battery recharge as well as steady IT kW. Site temperature, altitude and fuel conditions can affect available output. Fuel autonomy requires usable quantity and a consumption curve at the intended load; bulk storage, day tanks, transfer pumps, filters and delivery logistics all contribute to the actual energy path.

Paralleled generation adds load-sharing and protective requirements. One unit's start success does not establish stable parallel operation or selective fault clearing. Maintenance bypasses and manual modes must be represented in the state model because they can change independence and automatic response.

Acceptance should record source waveforms or suitable electrical quantities, switch states, load behavior, alarms, fuel delivery and restoration. Use authorized procedures and clear abort criteria. A load-bank test can prove electrical source performance under its test conditions, while an integrated test adds actual downstream transfer and thermal dependencies. Neither should be described as the other.

### Build a sequence with timing and load checkpoints
Start with the required service and proven UPS support at its load. Write each transition: source unacceptable, start permitted, engine running, voltage and frequency accepted, transfer permitted, load connected, downstream cooling and controls stable. Associate each with an observed timestamp and an abort condition. Some stages can overlap; do not add overlapping durations as though all were sequential.

Suppose the first start attempt fails after eight seconds, a retry delay is five seconds, the second start needs ten seconds and transfer needs two. The total after the initial start command is 25 seconds. A design that demonstrated only the ideal twelve-second path has not established this retry scenario. Either provide supported bridge capacity or define and accept a different contingency.

After transfer, account for load steps and recharge. The generator may see IT load, cooling restart and battery charging together. A resistive load bank at steady kW does not reproduce every motor or nonlinear transient. Use each test for the claim it supports and retain the integrated service result separately.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A defined sequence takes 5 s detection, 10 s start/stabilization and 3 s transfer after readiness. Proven UPS support at test load is 25 s.

**Reasoning:** The modeled sequence totals 18 s, leaving 7 s before the proven support duration ends. That margin does not cover an unmodeled failed start, and actual timing must be validated.

#### Guided practice

A generator passes a resistive load-bank test but trips during simultaneous motor restart. What gap remains?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** The tested load profile did not represent the required transient and reactive/nonlinear behavior. Evaluate the actual step and equipment limits.

#### Independent task

Environment: analytical

Write an acceptance sequence for normal-source loss and controlled return.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Include all timing and load assumptions.
- Differentiate load-bank and integrated service evidence.
- Verify fuel and auxiliary dependencies.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0161 · single · diagnosis**

Detection takes 5 s, start/stabilization 10 s and transfer 3 s sequentially. What modeled bridge time is needed?

Synthetic educational evidence; not field measurements.

Sequential intervals: detection 5 s; start/stabilize 10 s; transfer 3 s

1. 18 s
2. 15 s
3. 10 s
4. 8 s

**Correct option(s):** 1

- Option 1: Correct. The sequential intervals add.
- Option 2: Incorrect. That omits transfer.
- Option 3: Incorrect. That counts only the largest stage.
- Option 4: Incorrect. That omits start and stabilization.

**CDCP-Q0162 · single · diagnosis**

Proven UPS support is 25 s and modeled transfer is 18 s. What nominal time margin remains?

Synthetic educational evidence; not field measurements.

Proven support: 25 s
Modeled sequential transfer: 18 s

1. 7 s
2. 25 s
3. 43 s
4. 18 s

**Correct option(s):** 1

- Option 1: Correct. Twenty-five minus eighteen gives seven.
- Option 2: Incorrect. That ignores the transfer interval.
- Option 3: Incorrect. Adding support and demand is not margin.
- Option 4: Incorrect. That is the demand duration.

**CDCP-Q0163 · single · diagnosis**

Why does a resistive load-bank pass not prove motor-start acceptance?

Synthetic educational evidence; not field measurements.

Load-bank test: steady resistive load passes
Actual motor restart: generator trips

1. Motors draw no starting current
2. The transient and power-factor demands can differ
3. Every load is electrically identical at equal kW
4. Load banks cannot test any generator property

**Correct option(s):** 2

- Option 1: Incorrect. Starting can create a substantial demand.
- Option 2: Correct. The actual load profile may stress the source differently.
- Option 3: Incorrect. Dynamic and reactive behavior differ.
- Option 4: Incorrect. They provide useful scoped evidence.

**CDCP-Q0164 · single · mechanism**

What should guide ATS versus STS selection?

1. Load tolerance, source conditions and required transfer behavior
2. Only cabinet width
3. The assumption that all transfer devices have zero interruption
4. The shortest acronym

**Correct option(s):** 1

- Option 1: Correct. Technology must fit the application.
- Option 2: Incorrect. Mechanical fit is not the full requirement.
- Option 3: Incorrect. They have different characteristics.
- Option 4: Incorrect. Naming is irrelevant.

**CDCP-Q0165 · single · mechanism**

Why include generator auxiliaries in capacity review?

1. Auxiliaries are always external and unlimited
2. Auxiliary demand is already zero by definition
3. Cooling, fuel delivery and controls consume or depend on power
4. Only IT kW matters

**Correct option(s):** 3

- Option 1: Incorrect. Their supply can be a dependency.
- Option 2: Incorrect. It is not.
- Option 3: Correct. The source needs its support systems.
- Option 4: Incorrect. Other loads can constrain the source.

**CDCP-Q0166 · single · mechanism**

A full bulk tank is available but the day-tank pump fails. What can limit runtime?

1. Fuel delivery to the engine
2. The number of rack outlets
3. The bulk tank gross volume alone
4. The invoice date only

**Correct option(s):** 1

- Option 1: Correct. Stored quantity alone is insufficient.
- Option 2: Incorrect. That does not restore fuel transfer.
- Option 3: Incorrect. Fuel cannot support the engine if the delivery path is unavailable.
- Option 4: Incorrect. The physical delivery path matters.

**CDCP-Q0167 · single · mechanism**

Why assess altitude and ambient temperature?

1. These affect only operator comfort
2. A larger tank eliminates environmental effects
3. Every generator has identical derating
4. Generator output can be condition-dependent

**Correct option(s):** 4

- Option 1: Incorrect. They can affect combustion and cooling.
- Option 2: Incorrect. Fuel quantity does not remove thermal limits.
- Option 3: Incorrect. Product data differ.
- Option 4: Correct. Nameplate performance has specified conditions.

**CDCP-Q0168 · single · mechanism**

What is the acceptance meaning of a generator start command?

1. The load is certainly transferred
2. Voltage and frequency are guaranteed stable
3. An instruction was issued, not proof of delivered power
4. Fuel autonomy is demonstrated

**Correct option(s):** 3

- Option 1: Incorrect. The remaining sequence may fail.
- Option 2: Incorrect. They require measurement or validated status.
- Option 3: Correct. Response must be observed.
- Option 4: Incorrect. Starting does not prove duration.

**CDCP-Q0169 · single · mechanism**

Why test retransfer to normal supply?

1. The return transition can also disturb service
2. Only outages can create transients
3. Retransfer is always instantaneous and harmless
4. A successful start proves every return state

**Correct option(s):** 1

- Option 1: Correct. Recovery is part of the required sequence.
- Option 2: Incorrect. Switching back can also matter.
- Option 3: Incorrect. Equipment behavior must be verified.
- Option 4: Incorrect. It does not.

**CDCP-Q0170 · single · mechanism**

What should be checked in a manual generator mode?

1. That all switches become independent
2. That fuel consumption becomes zero
3. Only the running engine speed
4. Whether automatic outage response is inhibited

**Correct option(s):** 4

- Option 1: Incorrect. Mode does not remove shared paths.
- Option 2: Incorrect. Running still uses fuel.
- Option 3: Incorrect. A manual-mode engine can run while automatic outage response remains inhibited.
- Option 4: Correct. Mode changes can reduce readiness.

**CDCP-Q0171 · single · mechanism**

Why use actual consumption at relevant load for fuel planning?

1. Consumption is measured in kVA only
2. Tank volume alone determines duration
3. Every engine burns the same rate
4. Burn rate changes with load and operating conditions

**Correct option(s):** 4

- Option 1: Incorrect. Fuel rate uses volume or mass per time.
- Option 2: Incorrect. Consumption is also needed.
- Option 3: Incorrect. Models and loads differ.
- Option 4: Correct. A generic rate can misstate autonomy.

**CDCP-Q0172 · single · mechanism**

What does generator paralleling additionally require?

1. No consideration of fault current
2. Synchronization, load sharing and coordinated protection
3. Only matching nominal frequency labels
4. Automatic elimination of all single points

**Correct option(s):** 2

- Option 1: Incorrect. Parallel sources can affect fault duty.
- Option 2: Correct. Multiple sources interact electrically.
- Option 3: Incorrect. Actual synchronization, sharing and protection are still required.
- Option 4: Incorrect. Shared control and buses can remain.

**CDCP-Q0173 · single · mechanism**

Why separate nominal brochure timing from measured acceptance?

1. Timing never varies
2. A stopwatch estimate replaces all load measurements
3. Brochures are always false
4. Installed settings and conditions affect the actual sequence

**Correct option(s):** 4

- Option 1: Incorrect. Conditions and configuration matter.
- Option 2: Incorrect. The service response must also be observed.
- Option 3: Incorrect. They can provide valid product data within scope.
- Option 4: Correct. The site result needs evidence.

**CDCP-Q0174 · single · mechanism**

A generator starts but voltage is outside the permitted transfer window. What should the logic do?

1. Follow the approved inhibit or contingency sequence
2. Ignore the voltage limit permanently
3. Assume the UPS has unlimited support
4. Transfer solely because the engine runs

**Correct option(s):** 1

- Option 1: Correct. An unacceptable source should not be treated as ready.
- Option 2: Incorrect. That drops a requirement.
- Option 3: Incorrect. Stored energy is finite.
- Option 4: Incorrect. Mechanical operation does not establish electrical suitability.

**CDCP-Q0175 · single · mechanism**

What is a credible failed-start scenario used for?

1. Assessing reserve and contingency beyond the ideal sequence
2. Justifying unlimited outage claims
3. Proving every possible engine failure
4. Replacing all routine maintenance

**Correct option(s):** 1

- Option 1: Correct. The required fault set must be explicit.
- Option 2: Incorrect. Energy and other dependencies remain finite.
- Option 3: Incorrect. One scenario has bounded scope.
- Option 4: Incorrect. Readiness still needs maintenance.

**CDCP-Q0176 · single · mechanism**

Why record load during generator acceptance?

1. The test duration alone establishes kW
2. Performance and fuel use depend on demand
3. The generator model determines every site's demand
4. Load is only a billing concern

**Correct option(s):** 2

- Option 1: Incorrect. Power must be known separately.
- Option 2: Correct. A light-load pass does not prove full-load behavior.
- Option 3: Incorrect. Loads differ.
- Option 4: Incorrect. It affects voltage, frequency and temperature.

**CDCP-Q0177 · single · mechanism**

Which condition can invalidate an STS transfer assumption?

1. A complete inventory record
2. Sources outside the device's acceptable relationship or limits
3. A different rack label
4. An approved maintenance plan

**Correct option(s):** 2

- Option 1: Incorrect. That supports management.
- Option 2: Correct. Transfer behavior depends on source conditions.
- Option 3: Incorrect. That does not affect the waveform.
- Option 4: Incorrect. The plan itself does not invalidate electrical conditions.

**CDCP-Q0178 · single · mechanism**

Why include protective coordination in source-transfer review?

1. Transfer devices replace every breaker
2. Fault current is identical for every source
3. Alternate sources can change available fault current
4. Coordination concerns only network routing

**Correct option(s):** 3

- Option 1: Incorrect. Fault protection remains necessary.
- Option 2: Incorrect. Utility and generator contributions can differ.
- Option 3: Correct. Protection must work in the actual operating states.
- Option 4: Incorrect. Here it concerns electrical protection.

**CDCP-Q0179 · single · mechanism**

What is the strongest evidence of complete alternate-source acceptance?

1. A fuel purchase receipt
2. Required load function, electrical limits, alarms and restoration observed through the sequence
3. Engine audio alone
4. The ATS screen says automatic

**Correct option(s):** 2

- Option 1: Incorrect. It does not show transfer or load behavior.
- Option 2: Correct. It covers the defined service chain.
- Option 3: Incorrect. Sound does not establish delivered power.
- Option 4: Incorrect. Mode is only a prerequisite.

**CDCP-Q0180 · single · mechanism**

Why retain abort criteria for transfer testing?

1. Tests should always finish regardless of consequences
2. A signed procedure prevents all unexpected states
3. The test can expose unsafe or service-threatening states
4. Abort criteria make every test fail

**Correct option(s):** 3

- Option 1: Incorrect. That violates controlled execution.
- Option 2: Incorrect. It cannot guarantee that.
- Option 3: Correct. The team needs predefined stop conditions.
- Option 4: Incorrect. They protect the boundary.

#### Recall

**Detection takes 5 s, start/stabilization 10 s and transfer 3 s sequentially. What modeled bridge time is needed?**

18 s Correct. The sequential intervals add.

**Proven UPS support is 25 s and modeled transfer is 18 s. What nominal time margin remains?**

7 s Correct. Twenty-five minus eighteen gives seven.

**Why does a resistive load-bank pass not prove motor-start acceptance?**

The transient and power-factor demands can differ Correct. The actual load profile may stress the source differently.

**What should guide ATS versus STS selection?**

Load tolerance, source conditions and required transfer behavior Correct. Technology must fit the application.

**Why include generator auxiliaries in capacity review?**

Cooling, fuel delivery and controls consume or depend on power Correct. The source needs its support systems.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## CDCP-M10 — UPS selection, modes and battery acceptance

### CDCP-L10 — UPS selection, modes and battery acceptance

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L09

Select a UPS against the complete service envelope: real and apparent power, overload behavior, input range, output quality, transfer modes, maintainability, stored-energy duration and recharge. Redundant modules can share a common frame, controller or bypass, so the unit count must be reconciled with the required fault boundary. A modular system can provide useful serviceability without being independent against every common failure.

Double-conversion operation normally routes energy through rectifier and inverter stages. Static bypass and maintenance bypass change that route and can change the protection available to the load. A maintenance plan must identify which equipment is isolated, whether battery support remains, and what source and protection now carry the service. An illuminated UPS display is not a mode acceptance test.

Battery sizing starts with required load energy, then uses the correct discharge characteristics, efficiency, aging and environmental factors from the design and manufacturer. A simple Wh calculation is a first-order check rather than a replacement for the discharge table. Series and parallel arrangements alter voltage, capacity and fault paths differently. Battery management estimates are useful but do not replace every capacity or condition test.

Battery technologies also introduce different ventilation, thermal, fire-response and handling interfaces. BESS installations can have broader energy and grid-interaction roles than a conventional UPS battery cabinet. Review the actual product and approved hazard strategy; never assume that one chemistry's response procedure applies to another.

Acceptance includes load-step and source-loss behavior, mode transitions, alarms, battery support at the defined load, recharge and restoration of redundancy. A test may intentionally stop before full discharge to protect service; its claim must then reflect the demonstrated interval rather than infer unlimited runtime. Track aging and measured trends so the commissioned envelope remains valid throughout operation.

### Review a UPS proposal with independent constraints
A supplier offers three 80 kW modules for a 150 kW load. With one unavailable, 160 kW nominal capacity remains, giving 10 kW headroom. That passes only the simple real-power check. If the load power factor creates an apparent demand beyond the surviving kVA limit, or if environmental derating removes more than 10 kW, the proposal fails the stated state.

Next review the common frame, controller, output bus and bypass. Module redundancy can support repair of one module while retaining shared failure domains. The supplier's maintenance sequence should identify which components can actually be isolated without affecting the service and what protection remains during each step.

For storage, convert load and duration to energy, then use the discharge table and approved factors. Record the battery's age and state during acceptance. A five-minute test at 100 kW cannot be relabeled as ten minutes at 150 kW. Preserve the measured envelope, recharge requirement and sustaining tests that keep the claim valid over time.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A UPS is rated 100 kVA and 90 kW. The proposed load is 80 kW at PF 0.75.

**Reasoning:** Apparent demand is 106.67 kVA, exceeding the UPS kVA limit despite remaining below 90 kW. Both limits must pass.

#### Guided practice

A 30 kW load needs 20 minutes at 90% delivery efficiency. What minimum source energy is indicated before other design factors?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** Load energy is 10 kWh; source energy is 11.11 kWh. Supplier discharge behavior, aging and conditions remain necessary.

#### Independent task

Environment: analytical

Compare two UPS proposals against a fixed load and maintenance requirement.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Check both power ratings and all required modes.
- Use supported battery discharge data for final sizing.
- Identify common bypass and control dependencies.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0181 · single · calculation**

An 80 kW load at PF 0.75 is proposed for a 100 kVA/90 kW UPS. Which limit fails?

Synthetic educational evidence; not field measurements.

UPS: 100 kVA / 90 kW
Proposed load: 80 kW at PF 0.75

1. Both necessarily
2. Neither
3. Real power
4. Apparent power

**Correct option(s):** 4

- Option 1: Incorrect. Only the supplied apparent-power limit is exceeded.
- Option 2: Incorrect. The kVA calculation exceeds the rating.
- Option 3: Incorrect. 80 kW is below 90 kW.
- Option 4: Correct. The demand is about 106.7 kVA.

**CDCP-Q0182 · single · calculation**

A 30 kW load needs 20 minutes. What load-side energy is required?

Synthetic educational evidence; not field measurements.

Load: 30 kW
Required duration: 20 min

1. 10 kWh
2. 30 kWh
3. 600 kWh
4. 1.5 kWh

**Correct option(s):** 1

- Option 1: Correct. One-third hour times 30 kW equals ten.
- Option 2: Incorrect. That corresponds to one hour.
- Option 3: Incorrect. Minutes must be converted to hours.
- Option 4: Incorrect. That uses an incorrect time relationship.

**CDCP-Q0183 · single · calculation**

Delivering 10 kWh at 90% efficiency needs what source energy before other factors?

Synthetic educational evidence; not field measurements.

Output energy: 10 kWh
Delivery efficiency: 90%

1. 9 kWh
2. 19 kWh
3. 11.11 kWh
4. 10 kWh

**Correct option(s):** 3

- Option 1: Incorrect. Multiplication understates input.
- Option 2: Incorrect. Efficiency is not additive energy.
- Option 3: Correct. Divide output energy by efficiency.
- Option 4: Incorrect. That ignores losses.

**CDCP-Q0184 · single · mechanism**

Why review common controls in a modular UPS?

1. Multiple modules may share one failure cause
2. Shared controls always make the design unusable
3. A spare module removes bypass faults
4. Every module necessarily has a separate building

**Correct option(s):** 1

- Option 1: Correct. Module count alone does not prove independence.
- Option 2: Incorrect. Suitability depends on requirements and behavior.
- Option 3: Incorrect. The bypass can remain common.
- Option 4: Incorrect. That cannot be assumed.

**CDCP-Q0185 · single · mechanism**

What must a maintenance-bypass plan identify?

1. Only the cabinet door to open
2. A claim that all normal protection remains automatically
3. Only the battery serial number
4. The actual load path and protection remaining during work

**Correct option(s):** 4

- Option 1: Incorrect. The electrical sequence matters.
- Option 2: Incorrect. That may be false.
- Option 3: Incorrect. That does not define the bypass path.
- Option 4: Correct. Mode changes alter the service envelope.

**CDCP-Q0186 · single · mechanism**

Why is a battery Wh estimate only a first-order check?

1. Discharge rate, cutoff, age and temperature affect delivered energy
2. All batteries deliver their nameplate energy at every rate
3. Energy calculations have no value
4. The UPS efficiency is always exactly one

**Correct option(s):** 1

- Option 1: Correct. Nominal energy does not guarantee runtime.
- Option 2: Incorrect. They do not.
- Option 3: Incorrect. They are useful screening and consistency checks.
- Option 4: Incorrect. Losses exist.

**CDCP-Q0187 · single · mechanism**

What can a UPS test stopped after five minutes legitimately establish?

1. Every aging condition
2. Full rated runtime regardless of load
3. Behavior during the demonstrated five-minute conditions
4. Unlimited source independence

**Correct option(s):** 3

- Option 1: Incorrect. The battery state was specific.
- Option 2: Incorrect. The test did not demonstrate it.
- Option 3: Correct. Longer duration remains untested.
- Option 4: Incorrect. Stored energy is finite.

**CDCP-Q0188 · single · mechanism**

Why monitor recharge after a discharge test?

1. The system may remain below its required reserve
2. Test completion removes all resilience obligations
3. A normal input source proves full state of charge
4. Charging has no thermal or power impact

**Correct option(s):** 1

- Option 1: Correct. Service restoration does not instantly restore energy.
- Option 2: Incorrect. The normal reserve must be restored.
- Option 3: Incorrect. Time and charging conditions matter.
- Option 4: Incorrect. It consumes power and can generate heat.

**CDCP-Q0189 · single · mechanism**

Which property changes when cells are added in series?

1. Ah necessarily multiplies
2. Nominal voltage
3. Every cell's chemistry changes
4. Frequency automatically doubles

**Correct option(s):** 2

- Option 1: Incorrect. That is not the series capacity relationship.
- Option 2: Correct. Series cell voltages add while Ah remains that of the string.
- Option 3: Incorrect. Connection does not alter chemistry.
- Option 4: Incorrect. DC cells do not set AC frequency directly.

**CDCP-Q0190 · single · mechanism**

Which property ideally increases when identical strings are paralleled?

1. Every string becomes immune to faults
2. Nominal Ah capacity
3. Nominal voltage doubles
4. The need for current sharing disappears

**Correct option(s):** 2

- Option 1: Incorrect. Protection and balancing still matter.
- Option 2: Correct. Parallel strings add charge capacity before practical constraints.
- Option 3: Incorrect. That is series behavior.
- Option 4: Incorrect. Parallel operation requires appropriate design.

**CDCP-Q0191 · single · mechanism**

Why should battery chemistry be explicit in emergency planning?

1. All chemistries have identical failure behavior
2. Hazards and approved responses differ
3. A BMS eliminates all chemical hazards
4. Chemistry affects only the label

**Correct option(s):** 2

- Option 1: Incorrect. They do not.
- Option 2: Correct. One generic procedure may be unsuitable.
- Option 3: Incorrect. Monitoring does not remove every hazard.
- Option 4: Incorrect. It affects physical behavior.

**CDCP-Q0192 · single · mechanism**

What does BESS add to the review beyond a simple UPS label?

1. Automatic certification of the room
2. A guarantee of uninterrupted AC output
3. The actual energy role, control interfaces and hazard strategy
4. No need for operational reserve

**Correct option(s):** 3

- Option 1: Incorrect. Installation has separate requirements.
- Option 2: Incorrect. That depends on the complete system.
- Option 3: Correct. Storage may serve grid or dispatch functions as well as continuity.
- Option 4: Incorrect. Reserve still matters when continuity is required.

**CDCP-Q0193 · single · mechanism**

Why test UPS overload behavior at a defined duration?

1. A larger battery removes every inverter limit
2. Overload ratings always apply indefinitely
3. Overload support is bounded by magnitude and time
4. Duration only affects the report length

**Correct option(s):** 3

- Option 1: Incorrect. Power conversion has its own constraints.
- Option 2: Incorrect. They do not.
- Option 3: Correct. Temporary ratings are not continuous capacity.
- Option 4: Incorrect. It affects thermal and protective behavior.

**CDCP-Q0194 · single · mechanism**

What does a healthy battery-management estimate fail to prove alone?

1. That the management system reports a value
2. Actual delivered capacity under every required condition
3. That battery information can be useful
4. That all cells must already have failed

**Correct option(s):** 2

- Option 1: Incorrect. It does show that narrow fact.
- Option 2: Correct. The estimate is model-based and scoped.
- Option 3: Incorrect. It remains useful with validation.
- Option 4: Incorrect. No such conclusion follows.

**CDCP-Q0195 · single · mechanism**

Why compare efficiency curves at the expected operating load?

1. All proposals use identical curves
2. UPS losses vary with load and mode
3. Only full load is ever possible
4. Efficiency is unrelated to loading

**Correct option(s):** 2

- Option 1: Incorrect. Products differ.
- Option 2: Correct. A headline point may not represent the site.
- Option 3: Incorrect. Facilities operate across a range.
- Option 4: Incorrect. It often changes.

**CDCP-Q0196 · single · mechanism**

Which evidence best confirms a UPS mode transition?

1. Load-side electrical response, mode state and required service behavior
2. Display illumination only
3. A maintenance signature alone
4. A battery invoice

**Correct option(s):** 1

- Option 1: Correct. The full functional consequence matters.
- Option 2: Incorrect. The screen can be on in multiple states.
- Option 3: Incorrect. It records action but not behavior.
- Option 4: Incorrect. It does not test transfer.

**CDCP-Q0197 · single · mechanism**

What should trigger reconsideration of a battery-runtime claim?

1. A copied report with no physical change
2. Increased load or degraded battery condition
3. A report reformat with unchanged load and battery condition
4. A renamed dashboard page

**Correct option(s):** 2

- Option 1: Incorrect. Copying does not change performance, though provenance still matters.
- Option 2: Correct. The original test envelope has changed.
- Option 3: Incorrect. Formatting alone does not change the physical runtime envelope.
- Option 4: Incorrect. That alone does not change energy.

**CDCP-Q0198 · single · mechanism**

Why review the bypass source's quality?

1. The inverter always conditions bypass power
2. Battery age determines bypass frequency
3. The load may be exposed to it during bypass
4. Bypass has no source connection

**Correct option(s):** 3

- Option 1: Incorrect. That is not generally the path.
- Option 2: Incorrect. The source determines its electrical characteristics.
- Option 3: Correct. Normal inverter conditioning may be absent.
- Option 4: Incorrect. It is a real power path.

**CDCP-Q0199 · single · mechanism**

Which acceptance condition tests maintainability rather than only normal operation?

1. The supplier provides a brochure
2. The UPS fits through the doorway
3. All modules run normally
4. Required service continues through the approved equipment-isolation sequence

**Correct option(s):** 4

- Option 1: Incorrect. That is source information.
- Option 2: Incorrect. That is installation access.
- Option 3: Incorrect. That does not demonstrate isolation.
- Option 4: Correct. It exercises the maintenance state.

**CDCP-Q0200 · single · mechanism**

What should be retained after UPS acceptance?

1. Only a pass sticker
2. No records because the equipment is new
3. Only the initial quotation
4. Baseline settings, test conditions, results and sustaining maintenance requirements

**Correct option(s):** 4

- Option 1: Incorrect. That omits the evidence and envelope.
- Option 2: Incorrect. New equipment still needs traceability.
- Option 3: Incorrect. Commercial terms do not capture installed behavior.
- Option 4: Correct. Capability must be maintained.

#### Recall

**An 80 kW load at PF 0.75 is proposed for a 100 kVA/90 kW UPS. Which limit fails?**

Apparent power Correct. The demand is about 106.7 kVA.

**A 30 kW load needs 20 minutes. What load-side energy is required?**

10 kWh Correct. One-third hour times 30 kW equals ten.

**Delivering 10 kWh at 90% efficiency needs what source energy before other factors?**

11.11 kWh Correct. Divide output energy by efficiency.

**Why review common controls in a modular UPS?**

Multiple modules may share one failure cause Correct. Module count alone does not prove independence.

**What must a maintenance-bypass plan identify?**

The actual load path and protection remaining during work Correct. Mode changes alter the service envelope.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## CDCP-M11 — EMF, interference and grounding interfaces

### CDCP-L11 — EMF, interference and grounding interfaces

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L10

Electromagnetic phenomena can affect people, equipment and signal integrity through different mechanisms. Distinguish low-frequency electric and magnetic fields from higher-frequency interference, and distinguish exposure assessment from equipment compatibility. A field measurement relevant to one question may not answer another. Units and frequency range must be recorded with the measurement.

Current produces magnetic fields; voltage differences produce electric fields. Geometry matters. Closely grouped conductors carrying balanced currents can reduce the external field through partial cancellation, while separated return paths can create larger loop areas. A shield's effectiveness depends on field type, frequency, material, continuity and installation. A thin conductive screen that helps with an electric field is not automatically an effective low-frequency magnetic shield.

Interference can couple conductively through shared impedance or radiatively through space. Good routing, appropriate separation, pair balance, bonding and enclosure design help manage it. Optical fiber avoids electrical signal conduction along its glass path, but the transceivers and power supplies remain electrical equipment with their own susceptibility and grounding interfaces.

Measurement should be hypothesis-led. Identify source, frequency, distance, orientation, operating load and the affected function. A meter outside its calibrated range can produce a plausible but unsuitable number. Do not invent one universal safe distance: applicable exposure requirements, source geometry and equipment instructions govern the actual assessment. Qualified specialists handle exposure and mitigation decisions where needed.

Acceptance compares the required function with conditions before and after a controlled mitigation. Retain both field observations and service evidence, such as error counts or instrument behavior. Correlation between a motor start and a communication error is a useful lead, not proof that magnetic coupling is the sole cause; power disturbance, bonding and routing may also contribute.

### Separate field exposure, coupling and symptoms
An engineer measures a low-frequency magnetic field near a bus route and also observes packet errors in a nearby control cable. These are two observations, not yet one proven causal chain. The field measurement needs frequency, location, orientation, source current and instrument suitability. The communication fault needs timestamps, error type, topology and operating context.

Inspect possible conductive paths and power disturbances as well as radiated coupling. Pair imbalance, poor termination or a shared reference path can make one cable vulnerable while another is unaffected. A route correction can be a useful experiment only when performed through controlled change and evaluated under comparable source load.

Shielding should be specified for the actual field and frequency. Electric-field shielding, high-frequency electromagnetic shielding and low-frequency magnetic attenuation can require different materials and geometry. Do not infer effectiveness from a metal enclosure's appearance. Qualified exposure review and applicable requirements remain separate from proving that the equipment performs its communication task.

### Keep field quantities and units distinct
Electric field strength is expressed in volts per metre (V/m). Magnetic field strength H is expressed in amperes per metre (A/m), while magnetic flux density B is expressed in tesla (T), often with microtesla or millitesla prefixes. Gauss is another flux-density unit; one tesla equals 10,000 gauss. A reading in microtesla cannot be compared numerically with a limit in A/m without the appropriate physical relationship and assumptions.

Record frequency with the quantity. A 50 Hz measurement and a high-frequency radio measurement address different source conditions, instruments and assessment methods. The applicable exposure framework distinguishes the relevant quantities and limits; this course does not invent a universal safe distance or health threshold. Equipment-interference acceptance also remains a separate question from human exposure assessment.

For a simple unit check, 200 microtesla is 0.2 millitesla or 0.0002 tesla, which is 2 gauss. Prefix errors can create thousandfold mistakes. Before interpreting a field survey, check the unit, range, calibration, orientation and source operating state, then obtain the appropriate specialist review for the actual assessment purpose.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A communication fault appears when a nearby motor starts. Both a cable-route issue and a supply-voltage dip are plausible.

**Reasoning:** Measure relevant electrical events and inspect routing/bonding under an approved plan. A coincident motor event does not distinguish radiated interference from conducted power disturbance by itself.

#### Guided practice

A shield is specified for high-frequency interference. Can its rating be assumed to solve low-frequency magnetic exposure?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** No. Shield effectiveness depends on field type and frequency; evaluate the actual source and approved mitigation.

#### Independent task

Environment: analytical

Create an interference investigation plan for a synthetic control cable route.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- State units, frequency range, geometry and operating state.
- Separate human exposure from equipment compatibility.
- Verify the affected function after mitigation.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0201 · single · mechanism**

Why distinguish exposure assessment from equipment immunity?

1. Both always use identical criteria
2. Human exposure is measured only by packet errors
3. Equipment immunity determines every human limit
4. They concern different limits and consequences

**Correct option(s):** 4

- Option 1: Incorrect. Their standards and purposes differ.
- Option 2: Incorrect. That is not the physical assessment.
- Option 3: Incorrect. That is not a valid substitution.
- Option 4: Correct. A safe exposure result does not prove a signal will work.

**CDCP-Q0202 · single · diagnosis**

Which unit measures magnetic flux density?

1. Watts per square metre in every low-frequency assessment
2. Tesla
3. Amperes per metre
4. Volts per metre

**Correct option(s):** 2

- Option 1: Incorrect. Power density is a different quantity and cannot be substituted universally.
- Option 2: Correct. B is expressed in tesla, with prefixes such as microtesla.
- Option 3: Incorrect. That is magnetic field strength H rather than flux density B.
- Option 4: Incorrect. That is electric field strength.

**CDCP-Q0203 · single · mechanism**

Why keep supply and return conductors appropriately grouped?

1. Separation always eliminates every field
2. Grouping guarantees zero fault current
3. Grouping replaces protective bonding
4. Their fields can partially cancel and loop area can be reduced

**Correct option(s):** 4

- Option 1: Incorrect. Larger loops can increase coupling.
- Option 2: Incorrect. It does not.
- Option 3: Incorrect. The protective scheme remains necessary.
- Option 4: Correct. Geometry affects external coupling.

**CDCP-Q0204 · single · mechanism**

Why is one universal safe distance not defensible for every EMF source?

1. Every source has identical field geometry
2. Frequency, geometry, current and governing limits differ
3. A data-center label sets the field strength
4. Distance never affects fields

**Correct option(s):** 2

- Option 1: Incorrect. They do not.
- Option 2: Correct. Assessment must match the source and purpose.
- Option 3: Incorrect. It does not.
- Option 4: Incorrect. It can strongly affect them.

**CDCP-Q0205 · single · mechanism**

A high-frequency shield is proposed for a low-frequency magnetic problem. What is needed?

1. Ignore source geometry
2. Assume all shields are interchangeable
3. Verify effectiveness for the actual field and frequency
4. Judge only by shield thickness without material or frequency data

**Correct option(s):** 3

- Option 1: Incorrect. Geometry affects the problem.
- Option 2: Incorrect. They are not.
- Option 3: Correct. Shield mechanisms differ.
- Option 4: Incorrect. Thickness is not sufficient to establish the relevant attenuation.

**CDCP-Q0206 · single · mechanism**

What does conducted interference use as a path?

1. Only visual light
2. Only mechanical labels
3. Electrical connections or shared impedance
4. Only free-space radiation

**Correct option(s):** 3

- Option 1: Incorrect. That is not the general mechanism.
- Option 2: Incorrect. Labels are not a conductive circuit.
- Option 3: Correct. The disturbance travels through conductive paths.
- Option 4: Incorrect. That is radiated coupling.

**CDCP-Q0207 · single · mechanism**

Why can fiber reduce one interference path?

1. Fiber guarantees correct application data
2. Fiber removes all power-quality problems
3. Its glass signal path is not an electrical conductor
4. Every fiber transceiver is non-electrical

**Correct option(s):** 3

- Option 1: Incorrect. Other faults can still occur.
- Option 2: Incorrect. Equipment supplies remain vulnerable.
- Option 3: Correct. It avoids electrical signal coupling along that path.
- Option 4: Incorrect. Transceivers still use electronics and power.

**CDCP-Q0208 · single · mechanism**

What should accompany a field measurement?

1. Only the highest observed value without measurement geometry
2. Only the highest displayed digit
3. Only a rack count
4. Frequency range, location, orientation and source operating state

**Correct option(s):** 4

- Option 1: Incorrect. Location, orientation and operating state are needed to interpret the result.
- Option 2: Incorrect. That is not interpretable alone.
- Option 3: Incorrect. That does not describe the field geometry.
- Option 4: Correct. The number needs a physical context.

**CDCP-Q0209 · single · diagnosis**

Why can a motor-start correlation be inconclusive?

Synthetic educational evidence; not field measurements.

Motor start timestamp matches communication errors
Voltage waveform and cable-coupling evidence: not yet collected

1. Every motor event proves malicious interference
2. The network must always be healthy
3. Correlation has no diagnostic value
4. Power dips and coupling can produce similar timing

**Correct option(s):** 4

- Option 1: Incorrect. That is unsupported.
- Option 2: Incorrect. Actual errors need investigation.
- Option 3: Incorrect. It helps narrow hypotheses.
- Option 4: Correct. Several mechanisms share the event.

**CDCP-Q0210 · single · mechanism**

What is a shield continuity defect likely to affect?

1. The room's total floor area
2. The nominal server memory size
3. The intended shielding performance
4. Only the asset database

**Correct option(s):** 3

- Option 1: Incorrect. That is unrelated.
- Option 2: Incorrect. That is unrelated.
- Option 3: Correct. Gaps and poor connections can change attenuation.
- Option 4: Incorrect. The physical protection is altered.

**CDCP-Q0211 · single · mechanism**

Which mitigation should follow a confirmed routing-coupling issue?

1. An approved route or separation correction with retesting
2. Increase all alarm thresholds
3. Replace every application password
4. Delete error counters

**Correct option(s):** 1

- Option 1: Correct. It targets the mechanism and verifies the result.
- Option 2: Incorrect. That hides symptoms.
- Option 3: Incorrect. That does not address physical coupling.
- Option 4: Incorrect. That removes evidence.

**CDCP-Q0212 · single · mechanism**

Why review instrument frequency capability?

1. Every meter measures every frequency
2. A meter may not measure the relevant field accurately
3. Frequency affects only display refresh
4. A digital display guarantees universal accuracy

**Correct option(s):** 2

- Option 1: Incorrect. Instruments have limits.
- Option 2: Correct. Calibration and bandwidth constrain the result.
- Option 3: Incorrect. It affects the physical signal.
- Option 4: Incorrect. It does not.

**CDCP-Q0213 · single · mechanism**

What can shared impedance create?

1. Unlimited cooling capacity
2. A path for one circuit's current to disturb another
3. Guaranteed galvanic isolation
4. Zero voltage difference under all currents

**Correct option(s):** 2

- Option 1: Incorrect. That is unrelated.
- Option 2: Correct. Voltage develops across common impedance.
- Option 3: Incorrect. The path is shared.
- Option 4: Incorrect. Nonzero impedance can create voltage.

**CDCP-Q0214 · single · mechanism**

Why can balanced twisted pairs improve interference behavior?

1. Pair symmetry and twist support rejection of common disturbances
2. They carry no current
3. They are equivalent to a fire barrier
4. They eliminate every installation requirement

**Correct option(s):** 1

- Option 1: Correct. The receiver responds to the differential signal.
- Option 2: Incorrect. They carry signal currents and sometimes power.
- Option 3: Incorrect. That is a different function.
- Option 4: Incorrect. Termination and geometry still matter.

**CDCP-Q0215 · single · mechanism**

Which evidence best supports successful interference mitigation?

1. Only a quieter alarm list
2. Only a contractor's verbal assurance
3. Only a new cable invoice
4. Relevant field or electrical measurements plus restored service behavior

**Correct option(s):** 4

- Option 1: Incorrect. Suppression can hide the problem.
- Option 2: Incorrect. Measured function is stronger evidence.
- Option 3: Incorrect. Purchase is not acceptance.
- Option 4: Correct. Both mechanism and outcome should improve.

**CDCP-Q0216 · single · mechanism**

What must be separated when reviewing grounding claims?

1. Protective safety function and signal-integrity considerations
2. Treat protective bonding and signal reference as interchangeable in every design
3. All grounding from local rules
4. Every ground conductor from every design requirement

**Correct option(s):** 1

- Option 1: Correct. They interact but are not interchangeable.
- Option 2: Incorrect. Their purposes differ even where the engineered arrangement connects them.
- Option 3: Incorrect. Applicable requirements govern it.
- Option 4: Incorrect. The protective scheme must remain coherent.

**CDCP-Q0217 · single · mechanism**

Why can a field vary with equipment load?

1. Only cable length matters
2. Current changes with operating demand
3. Fields are fixed once a cable is installed
4. Labels determine instantaneous current

**Correct option(s):** 2

- Option 1: Incorrect. Geometry and current both matter.
- Option 2: Correct. The source condition affects the field.
- Option 3: Incorrect. Current can vary.
- Option 4: Incorrect. They do not.

**CDCP-Q0218 · single · mechanism**

Which statement about conductive shielding is sound?

1. Effectiveness depends on material, installation and frequency
2. Shields remove the need for measurement
3. Any metal sheet blocks every magnetic field
4. Shielding guarantees correct bonding automatically

**Correct option(s):** 1

- Option 1: Correct. No universal performance follows from the word shield.
- Option 2: Incorrect. Verification remains necessary.
- Option 3: Incorrect. That is not generally true.
- Option 4: Incorrect. Installation must establish it.

**CDCP-Q0219 · single · mechanism**

What is the correct response to a measurement outside the instrument's specified range?

1. Assume digital instruments extrapolate perfectly
2. Round it to make it credible
3. Treat the result as unsuitable for the claim and obtain appropriate measurement
4. Use it as final compliance proof

**Correct option(s):** 3

- Option 1: Incorrect. That is unsupported.
- Option 2: Incorrect. Rounding does not fix capability.
- Option 3: Correct. A plausible number can still be invalid.
- Option 4: Incorrect. The measurement boundary is wrong.

**CDCP-Q0220 · single · diagnosis**

A flux-density reading is 200 microtesla. What is the same value in gauss?

1. 20,000 G
2. 2 G
3. 200 G
4. 0.02 G

**Correct option(s):** 2

- Option 1: Incorrect. This treats the microtesla value as a much larger tesla quantity.
- Option 2: Correct. 200 microtesla is 0.0002 T, and one tesla is 10,000 G.
- Option 3: Incorrect. This omits the correct prefix conversion.
- Option 4: Incorrect. This is a hundredfold low result.

#### Recall

**Why distinguish exposure assessment from equipment immunity?**

They concern different limits and consequences Correct. A safe exposure result does not prove a signal will work.

**Which unit measures magnetic flux density?**

Tesla Correct. B is expressed in tesla, with prefixes such as microtesla.

**Why keep supply and return conductors appropriately grouped?**

Their fields can partially cancel and loop area can be reduced Correct. Geometry affects external coupling.

**Why is one universal safe distance not defensible for every EMF source?**

Frequency, geometry, current and governing limits differ Correct. Assessment must match the source and purpose.

**A high-frequency shield is proposed for a low-frequency magnetic problem. What is needed?**

Verify effectiveness for the actual field and frequency Correct. Shield mechanisms differ.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)
- [ICNIRP — low-frequency field quantities and assessment context](https://www.icnirp.org/en/frequencies/low-frequency/index.html)

## CDCP-M12 — Rack density, connectors and serviceability

### CDCP-L12 — Rack density, connectors and serviceability

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L11

High-density racks concentrate several constraints in one footprint. U-space, mass, power, coolant flow, residual air heat, network ports and service access all need simultaneous checks. A rack can meet its average kW allocation while exceeding an outlet, phase, connector or local cooling limit. Design at the equipment interface and in the required failure state rather than relying only on room averages.

Rack form factors must support depth, rail kits, doors, cables and any liquid connections. A rear-door exchanger adds weight, pressure interfaces and maintenance clearance; direct-to-chip equipment adds hose and manifold requirements. A cabinet's static rating does not approve rolling it loaded, nor does it approve the floor beneath it. Keep specialist building evidence distinct from rack compatibility.

Connector choice is an engineering interface. Voltage, current, phase arrangement, retention, supported environment and device instructions must match. A physically fitting adapter can create an unsupported path. Intelligent rack PDUs may meter at inlet, branch or outlet level; the measurement boundary determines which overloads can be detected. Outlet-level data can help find stranded or uneven capacity, but calibration and polling freshness still matter.

Serviceability includes replacing a power supply, fan, drive, network optic or coolant connector without disturbing unrelated paths. Cable routing should permit those actions while preserving bend limits, strain relief and airflow. Labels should identify the actual source and destination, and OOB access should remain usable when the primary network is impaired.

Acceptance combines a rack elevation, load schedule, interface matrix and executed checks. Verify mounting, stability, source diversity, airflow or liquid delivery, monitoring and recovery access. A successful boot is only one item; it does not demonstrate failover, thermal steady state or safe maintenance clearance.

### Review a high-density rack from source to service
A rack consumes 90 kW, transfers 70 kW to liquid and leaves 20 kW in air. It uses multiple electrical branches and several network uplinks. A room allocation of 90 kW power and 90 kW total cooling is still too vague: the design needs the right power at each connector, the right liquid flow and temperature at the manifold, and enough air delivery at every residual-air-cooled component.

Draw an interface table for each resource with normal, failed-path and maintenance states. For a rear-door exchanger, include added mass and opening clearance. For dual power supplies, include surviving-feed current. For OOB management, include independence from the primary network and protected credentials.

Then perform a serviceability walk-through. Can a failed supply or optic be replaced without moving a coolant hose or disconnecting an unrelated feed? Can the heaviest module follow the approved lifting path? Can labels be read after all cables are installed? These concrete checks turn a dense rack from a collection of compatible parts into a maintainable installation.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A 60 kW rack transfers 45 kW to liquid and 15 kW to room air. The room plan assumes every liquid-cooled rack has zero air demand.

**Reasoning:** The room cooling model is short by 15 kW for this rack. Liquid capture fraction must be measured or supported, and residual heat included.

#### Guided practice

A rack has a 1000 kg static rating but a rear-door exchanger raises loaded mass above the approved moving limit. What changes?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** The installation or relocation method must be revised under the actual dynamic and route constraints.

#### Independent task

Environment: analytical

Review a synthetic high-density rack installation package.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Check every interface and normal/failure state.
- Calculate residual air load.
- Demonstrate service access without disturbing unrelated equipment.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0221 · single · calculation**

A 60 kW rack sends 45 kW to liquid. What air heat remains?

Synthetic educational evidence; not field measurements.

Rack heat: 60 kW
Liquid capture: 45 kW

1. 0 kW
2. 60 kW
3. 45 kW
4. 15 kW

**Correct option(s):** 4

- Option 1: Incorrect. Liquid cooling does not imply complete capture.
- Option 2: Incorrect. That ignores liquid transfer.
- Option 3: Incorrect. That is the liquid portion.
- Option 4: Correct. Total heat minus liquid capture gives the residual.

**CDCP-Q0222 · single · mechanism**

Why can average rack power hide an overload?

1. One outlet, branch or phase can exceed its limit
2. Average power is always greater than every local value
3. Every outlet shares current equally automatically
4. A low average proves every connector is suitable

**Correct option(s):** 1

- Option 1: Correct. Aggregate values can conceal local constraints.
- Option 2: Incorrect. That is not how distribution works.
- Option 3: Incorrect. Loads and wiring differ.
- Option 4: Incorrect. Compatibility and local ratings remain separate.

**CDCP-Q0223 · single · mechanism**

What should be reviewed when adding a rear-door exchanger?

1. Only the Ethernet VLAN
2. Weight, service clearance, liquid connections and airflow
3. Only the rack name
4. Only the nominal heat-exchanger kW

**Correct option(s):** 2

- Option 1: Incorrect. That is not the mechanical or thermal interface.
- Option 2: Correct. It changes multiple rack interfaces.
- Option 3: Incorrect. Naming does not establish suitability.
- Option 4: Incorrect. Mechanical load, interfaces and service access also change.

**CDCP-Q0224 · single · mechanism**

Why can an adapter be unsuitable despite fitting?

1. Every fitting connector has identical voltage and current ratings
2. Electrical rating and approved interface requirements may differ
3. Lower workload removes every installation rule
4. Adapters automatically add branch capacity

**Correct option(s):** 2

- Option 1: Incorrect. It does not.
- Option 2: Correct. Mechanical fit is not complete compatibility.
- Option 3: Incorrect. It does not.
- Option 4: Incorrect. They cannot create source capacity.

**CDCP-Q0225 · single · mechanism**

What does outlet-level metering add over inlet-only metering?

1. Visibility of individual connected loads
2. Guaranteed upstream source independence
3. Elimination of all branch protection
4. Automatic sensor calibration

**Correct option(s):** 1

- Option 1: Correct. It can locate uneven or unexpected demand.
- Option 2: Incorrect. Meter granularity does not prove topology.
- Option 3: Incorrect. Protection remains required.
- Option 4: Incorrect. Accuracy still needs evidence.

**CDCP-Q0226 · single · mechanism**

A server boots successfully after installation. What remains unproven?

1. That some code executed
2. That any electrical power reached it
3. Failover and sustained thermal performance
4. That the device exists physically

**Correct option(s):** 3

- Option 1: Incorrect. That is inherent in booting.
- Option 2: Incorrect. Booting supports that narrow fact.
- Option 3: Correct. Booting exercises only part of the required envelope.
- Option 4: Incorrect. That is evident from installation.

**CDCP-Q0227 · single · mechanism**

Why plan service access around a rack?

1. More equipment always improves maintainability
2. Only initial delivery matters
3. Components must be replaceable without unacceptable disturbance
4. All repairs can be done through a dashboard

**Correct option(s):** 3

- Option 1: Incorrect. Crowding can obstruct work.
- Option 2: Incorrect. Maintenance continues throughout life.
- Option 3: Correct. Lifecycle operation needs physical reach.
- Option 4: Incorrect. Hardware replacement still requires access.

**CDCP-Q0228 · single · mechanism**

What does a static rack-load rating not establish?

1. Safe movement at the same loaded mass
2. The existence of a mass limit
3. The need to follow installation instructions
4. A supported stationary load under its conditions

**Correct option(s):** 1

- Option 1: Correct. Dynamic conditions can have different limits.
- Option 2: Incorrect. The rating states one.
- Option 3: Incorrect. Those remain applicable.
- Option 4: Incorrect. That is its intended boundary.

**CDCP-Q0229 · single · mechanism**

Why preserve an out-of-band management path?

1. OOB automatically removes all cybersecurity risk
2. OOB replaces every local console requirement
3. OOB proves cooling redundancy
4. Recovery may need access when the production path fails

**Correct option(s):** 4

- Option 1: Incorrect. It still needs protection.
- Option 2: Incorrect. Some failures may still need physical access.
- Option 3: Incorrect. It is a communication function.
- Option 4: Correct. It can support independent administration.

**CDCP-Q0230 · single · mechanism**

Which document best connects rack equipment to electrical allocation?

1. A server hostname list alone
2. A front-view photograph only
3. A purchase-price list
4. A load and outlet schedule with source mapping

**Correct option(s):** 4

- Option 1: Incorrect. Names do not establish electrical supply.
- Option 2: Incorrect. It may not show outlets or upstream paths.
- Option 3: Incorrect. Cost does not identify power connections.
- Option 4: Correct. It records the effective supply relationship.

**CDCP-Q0231 · single · mechanism**

Why evaluate liquid hoses during a rack serviceability review?

1. Hoses never need maintenance
2. Matching connector size proves fluid and seal compatibility
3. All coolant connectors can be disconnected under any pressure
4. They can constrain movement, bend and disconnection procedures

**Correct option(s):** 4

- Option 1: Incorrect. They can age or be replaced.
- Option 2: Incorrect. Mechanical dimensions do not establish chemical suitability.
- Option 3: Incorrect. Product and procedure limits apply.
- Option 4: Correct. Liquid interfaces add physical requirements.

**CDCP-Q0232 · single · diagnosis**

A PDU inlet is below rating but one branch trips. What should be investigated?

Synthetic educational evidence; not field measurements.

PDU inlet: below rating
One branch: protective trip

1. The conclusion that no overload is possible
2. The assumption that every branch is identical
3. Only total room floor area
4. Branch load and its protection limits

**Correct option(s):** 4

- Option 1: Incorrect. Local constraints can bind.
- Option 2: Incorrect. Ratings and loads may differ.
- Option 3: Incorrect. That does not diagnose branch current.
- Option 4: Correct. Aggregate inlet margin does not rule out a branch issue.

**CDCP-Q0233 · single · mechanism**

Why include strain relief in cable acceptance?

1. It replaces bend-radius limits
2. It increases optical transmitter power
3. It guarantees all labels are correct
4. Mechanical loads should not be carried improperly by connectors

**Correct option(s):** 4

- Option 1: Incorrect. Both remain relevant.
- Option 2: Incorrect. It is mechanical support.
- Option 3: Incorrect. Identification needs separate checks.
- Option 4: Correct. Movement and tension can damage interfaces.

**CDCP-Q0234 · single · mechanism**

What is a useful rack interface matrix?

1. Only a thermal image
2. Only a list of U positions
3. Only a network diagram
4. A record of mechanical, power, cooling, network and management requirements

**Correct option(s):** 4

- Option 1: Incorrect. That is one observation.
- Option 2: Incorrect. That is narrower than the full interface set.
- Option 3: Incorrect. It omits other physical constraints.
- Option 4: Correct. It prevents one-dimensional acceptance.

**CDCP-Q0235 · single · mechanism**

Why test source loss at the rack boundary?

1. Actual device sharing and surviving-path loading must be verified
2. Two cords guarantee every failure state
3. A normal current reading proves failover demand
4. A source-loss test proves every cooling state

**Correct option(s):** 1

- Option 1: Correct. Upstream ratings alone do not show device response.
- Option 2: Incorrect. They can share sources or have unsuitable behavior.
- Option 3: Incorrect. Demand can change after loss.
- Option 4: Incorrect. Thermal dependencies need their own evidence.

**CDCP-Q0236 · single · mechanism**

What can high-density deployment do to maintenance logistics?

1. Guarantee shorter repair time
2. Eliminate physical handling
3. Remove the need for OEM procedures
4. Increase lifting, spares and replacement-route demands

**Correct option(s):** 4

- Option 1: Incorrect. Access and complexity can lengthen it.
- Option 2: Incorrect. Hardware still needs movement.
- Option 3: Incorrect. Product-specific methods remain important.
- Option 4: Correct. Concentrated equipment can be heavy and complex.

**CDCP-Q0237 · single · mechanism**

Why verify residual heat with the OEM or measurements?

1. Every liquid rack has exactly the same fraction
2. Electrical input no longer becomes heat
3. The capture fraction varies by equipment and operating state
4. Room cooling is never needed once liquid is installed

**Correct option(s):** 3

- Option 1: Incorrect. Designs differ.
- Option 2: Incorrect. Energy still must be rejected.
- Option 3: Correct. A generic liquid label is insufficient.
- Option 4: Incorrect. Residual loads can remain.

**CDCP-Q0238 · single · mechanism**

Which acceptance criterion addresses service isolation?

1. A component can be serviced without interrupting the specified unrelated loads
2. The cabinet has spare U-space only
3. The rack looks tidy
4. The device is expensive

**Correct option(s):** 1

- Option 1: Correct. The boundary and allowed impact are explicit.
- Option 2: Incorrect. Access and dependencies also matter.
- Option 3: Incorrect. Neatness alone does not prove isolation.
- Option 4: Incorrect. Cost does not establish maintainability.

**CDCP-Q0239 · single · mechanism**

What should happen when an undocumented cord is found during rack work?

1. Assume it is unused because no label exists
2. Unplug it to discover its purpose
3. Resolve its identity and impact before disturbing it
4. Cut it to improve airflow immediately

**Correct option(s):** 3

- Option 1: Incorrect. Missing documentation is not proof of nonuse.
- Option 2: Incorrect. That can cause an avoidable outage.
- Option 3: Correct. Unknown connections can carry required service.
- Option 4: Incorrect. That is uncontrolled intervention.

**CDCP-Q0240 · single · mechanism**

Why review rack changes against the room design?

1. More cabinets automatically create more plant capacity
2. Local additions can consume shared power and cooling reserve
3. Rack boundaries isolate every resource
4. A room average always approves any local density

**Correct option(s):** 2

- Option 1: Incorrect. They do not.
- Option 2: Correct. A rack is part of a larger system.
- Option 3: Incorrect. Upstream systems are shared.
- Option 4: Incorrect. Delivery constraints can be local.

#### Recall

**A 60 kW rack sends 45 kW to liquid. What air heat remains?**

15 kW Correct. Total heat minus liquid capture gives the residual.

**Why can average rack power hide an overload?**

One outlet, branch or phase can exceed its limit Correct. Aggregate values can conceal local constraints.

**What should be reviewed when adding a rear-door exchanger?**

Weight, service clearance, liquid connections and airflow Correct. It changes multiple rack interfaces.

**Why can an adapter be unsuitable despite fitting?**

Electrical rating and approved interface requirements may differ Correct. Mechanical fit is not complete compatibility.

**What does outlet-level metering add over inlet-only metering?**

Visibility of individual connected loads Correct. It can locate uneven or unexpected demand.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## CDCP-M13 — Cooling capacity, heat transport and failure states

### CDCP-L13 — Cooling capacity, heat transport and failure states

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L12

Cooling design starts with heat sources and transport paths. IT electrical input is a major heat source, but UPS losses, lighting, people and envelope gains can also matter within the selected boundary. Avoid double counting: if a meter already includes a loss in total facility energy, do not add it again to the same total. For room sensible load, identify where each loss is physically released.

The sensible balance Q = mass flow × specific heat × temperature difference connects load to flow. For air, use density to convert volumetric flow to mass flow; for water, use appropriate density and heat capacity. Unit consistency is essential. A temperature difference in kelvin has the same numerical size as a difference in Celsius, but an absolute Celsius temperature cannot be substituted for a rise.

Capacity ratings are conditional. A cooling unit's total capacity includes sensible and latent portions at a specified entering condition. Available capacity can change with supply-water temperature, ambient conditions, airflow and fouling. The usable design capacity is the capacity delivered under the required operating conditions, not simply the sum of brochure maxima.

Redundancy must be checked at the load and delivery boundary. If one of three 100 kW units is unavailable, 200 kW nominal capacity remains; a 220 kW load cannot be supported under that simple model. Even a passing sum needs verification of pumps, valves, power, controls and distribution. Thermal inertia can bridge a short interruption, but its duration depends on actual heat capacity and load, and should not be invented from room size alone.

Acceptance measures representative inlets, supply/return conditions, flow, control stability and service behavior at stated load. Include failure and maintenance states, and confirm the final heat sink remains available. A cold supply temperature with no flow is not evidence of adequate heat transport.

### Check both a steady balance and a transient limit
A 100 kW load heats water flowing at 2.5 kg/s with cp 4.18 kJ/(kg·K). The ideal rise is 100/(2.5×4.18)=9.57 K. If flow falls to 1.5 kg/s while load remains, the ideal rise becomes 15.95 K. The calculation explains why flow loss matters even if the supply sensor initially stays cold.

For a simplified transient, suppose a thermal mass has effective heat capacity of 20 MJ/K and net unrejected heat is 100 kW, or 0.1 MJ/s. Its ideal temperature-rise rate is 0.005 K/s, or 0.3 K/min. This lumped model can illustrate limited ride-through, but real equipment temperatures and airflow are not uniform. It must not become a universal shutdown timer without validation.

Use measurements to locate the binding stage: IT inlet, air path, coil, liquid flow, exchanger or final sink. A larger chiller does not fix a blocked rack inlet; a higher fan command does not restore a failed water supply. The acceptance plan should distinguish these mechanisms through appropriate observables.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. Air density is 1.2 kg/m³, heat capacity 1.005 kJ/kg·K, load 30 kW and allowed rise 12 K.

**Reasoning:** Required ideal volume flow is 30/(1.2×1.005×12)=2.073 m³/s. Convert to 7463 m³/h by multiplying by 3600. Actual fan and pressure-path performance must be verified.

#### Guided practice

Three 100 kW units support 220 kW. What happens in the one-unit-unavailable model?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** Only 200 kW remains, so the stated N+1 requirement fails by 20 kW before derating.

#### Independent task

Environment: analytical

Build a cooling capacity schedule with normal and maintenance states.

**Packaged starter material**

- course_labs/CDCP/README.md
- course_labs/CDCP/proposal.json
- course_labs/CDCP/answers-template.json

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Use appropriate sensible capacity and conditions.
- Show units through every heat-balance step.
- Check delivery dependencies as well as nameplate sums.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0241 · single · calculation**

Using density 1.2 kg/m³, heat capacity 1.005 kJ/kg·K and rise 12 K, what airflow removes 30 kW?

Synthetic educational evidence; not field measurements.

Heat: 30 kW
Air density: 1.2 kg/m³
Air cp: 1.005 kJ/(kg·K)
Rise: 12 K

1. About 0.17 m³/s
2. About 36.2 m³/s
3. About 2.07 m³/s
4. About 24.9 m³/s

**Correct option(s):** 3

- Option 1: Incorrect. This divides by the rise twice.
- Option 2: Incorrect. That uses the denominator as a multiplier.
- Option 3: Correct. Divide load by density, heat capacity and rise.
- Option 4: Incorrect. This omits the temperature-rise divisor.

**CDCP-Q0242 · single · diagnosis**

How many m³/h correspond to 2 m³/s?

Synthetic educational evidence; not field measurements.

Volume flow: 2 m³/s
Convert to m³/h.

1. 7200 m³/h
2. 0.000556 m³/h
3. 3600 m³/h
4. 120 m³/h

**Correct option(s):** 1

- Option 1: Correct. Multiply by 3600 seconds per hour.
- Option 2: Incorrect. The conversion direction is reversed.
- Option 3: Incorrect. That corresponds to one m³/s.
- Option 4: Incorrect. That uses minutes rather than hours.

**CDCP-Q0243 · single · calculation**

Three 100 kW units serve 220 kW. With one unavailable, what shortfall remains?

Synthetic educational evidence; not field measurements.

Units: 3 × 100 kW sensible
Load: 220 kW
Unavailable: 1

1. 80 kW
2. 120 kW
3. 20 kW
4. Zero

**Correct option(s):** 3

- Option 1: Incorrect. That is normal spare capacity.
- Option 2: Incorrect. That would assume only one unit remains.
- Option 3: Correct. Two units provide 200 kW.
- Option 4: Incorrect. Installed total is not available total.

**CDCP-Q0244 · single · mechanism**

Why use sensible rather than total capacity for a mostly sensible IT load?

1. Total capacity is always smaller than sensible
2. Latent capacity may not be available for sensible heat removal
3. IT heat is entirely latent
4. Sensible capacity is measured only in liters

**Correct option(s):** 2

- Option 1: Incorrect. Total includes sensible plus latent.
- Option 2: Correct. The rating components differ.
- Option 3: Incorrect. Most equipment heat is sensible.
- Option 4: Incorrect. It is a heat rate.

**CDCP-Q0245 · single · mechanism**

What must be stated with a cooling rating?

1. Only the purchase year
2. The operating conditions at which it applies
3. Only the cabinet height
4. Only the model name

**Correct option(s):** 2

- Option 1: Incorrect. Age alone does not define rated conditions.
- Option 2: Correct. Capacity can change with air, water and ambient conditions.
- Option 3: Incorrect. Geometry is insufficient.
- Option 4: Incorrect. The rating point is still needed.

**CDCP-Q0246 · single · calculation**

Why is a 10°C temperature rise numerically 10 K?

1. Temperature differences have the same scale increment
2. Celsius differences must always be multiplied by 273
3. Absolute Celsius and kelvin values are identical
4. Kelvin cannot describe differences

**Correct option(s):** 1

- Option 1: Correct. The zero offset cancels in a difference.
- Option 2: Incorrect. That is incorrect.
- Option 3: Incorrect. They differ by an offset.
- Option 4: Incorrect. It can.

**CDCP-Q0247 · single · mechanism**

Which value belongs in Q = m cp ΔT?

1. Room setpoint alone
2. The supply-to-return temperature difference
3. Return temperature alone
4. Dew point alone

**Correct option(s):** 2

- Option 1: Incorrect. It may not equal the stream difference.
- Option 2: Correct. The equation uses change, not one absolute temperature.
- Option 3: Incorrect. That omits the inlet reference.
- Option 4: Incorrect. That is a moisture-related temperature.

**CDCP-Q0248 · single · mechanism**

Why can fouling reduce delivered cooling?

1. Fouling always increases surface performance
2. Nameplate capacity increases with age automatically
3. It can impair heat transfer or flow
4. Only visual appearance changes

**Correct option(s):** 3

- Option 1: Incorrect. Deposits can add resistance.
- Option 2: Incorrect. Condition can degrade.
- Option 3: Correct. The effective thermal path changes.
- Option 4: Incorrect. Physical transfer can be affected.

**CDCP-Q0249 · single · mechanism**

What does thermal inertia provide?

1. A guaranteed fixed ride-through for every room
2. Additional electrical generation
3. A finite transient buffer determined by heat capacity and load
4. Permanent heat rejection without a sink

**Correct option(s):** 3

- Option 1: Incorrect. Conditions differ.
- Option 2: Incorrect. It is a thermal property.
- Option 3: Correct. It is not unlimited cooling.
- Option 4: Incorrect. Stored heat eventually raises temperature.

**CDCP-Q0250 · single · mechanism**

A chilled-water supply sensor is cold but flow is zero. What is unproven?

1. The need for a return path
2. The sensor's displayed value
3. Actual heat transport to the sink
4. The existence of water

**Correct option(s):** 3

- Option 1: Incorrect. That remains part of the design.
- Option 2: Incorrect. It can still report a local temperature.
- Option 3: Correct. Temperature alone does not establish energy transfer.
- Option 4: Incorrect. Some water may be present.

**CDCP-Q0251 · single · mechanism**

Why avoid adding a UPS loss twice in a heat estimate?

1. All meters exclude losses automatically
2. Double counting always improves accuracy
3. UPS losses never become heat
4. Boundary accounting can otherwise overstate the load

**Correct option(s):** 4

- Option 1: Incorrect. Meter boundaries differ.
- Option 2: Incorrect. It introduces error.
- Option 3: Incorrect. They generally do at their location.
- Option 4: Correct. The same energy should not be counted twice.

**CDCP-Q0252 · single · mechanism**

Which dependency can defeat a passing cooling-capacity sum?

1. A verified independent supply
2. A correct arithmetic calculation
3. A complete label record
4. A shared pump or control failure

**Correct option(s):** 4

- Option 1: Incorrect. That reduces one common cause.
- Option 2: Incorrect. Arithmetic is necessary but not sufficient.
- Option 3: Incorrect. That supports operation.
- Option 4: Correct. Nominal units may not receive flow or commands.

**CDCP-Q0253 · single · mechanism**

What is the role of air density in cooling calculations?

1. Measure relative humidity directly
2. Convert kW directly to volts
3. Convert volume flow to mass flow
4. Define the server's allowable temperature alone

**Correct option(s):** 3

- Option 1: Incorrect. Density is not RH.
- Option 2: Incorrect. That is unrelated.
- Option 3: Correct. Heat capacity is specified per mass.
- Option 4: Incorrect. Equipment limits have separate sources.

**CDCP-Q0254 · single · mechanism**

Why test at representative heat load?

1. Light-load success may not establish design-load performance
2. Every load produces identical temperature gradients
3. A full room always has full electrical load
4. Cooling tests require no load information

**Correct option(s):** 1

- Option 1: Correct. Thermal response depends on demand.
- Option 2: Incorrect. Distribution changes with heat and flow.
- Option 3: Incorrect. Occupancy does not guarantee demand.
- Option 4: Incorrect. The result needs a demand boundary.

**CDCP-Q0255 · single · mechanism**

What should a cooling failure-state acceptance measure?

1. Only the remaining units' nameplates
2. Only an average outdoor temperature
3. Required inlet conditions and service continuity with the specified unit unavailable
4. Only an operator command

**Correct option(s):** 3

- Option 1: Incorrect. Those are ratings rather than installed response.
- Option 2: Incorrect. Local inlets and system state matter.
- Option 3: Correct. The test must observe delivered function.
- Option 4: Incorrect. Commands need verified effects.

**CDCP-Q0256 · single · calculation**

A 100 kW total-capacity unit has SHR 0.9 at the relevant point. What sensible capacity is available?

Synthetic educational evidence; not field measurements.

Total capacity: 100 kW
Relevant SHR: 0.90

1. 90 kW
2. 100 kW
3. 111.1 kW
4. 10 kW

**Correct option(s):** 1

- Option 1: Correct. Multiply total capacity by SHR.
- Option 2: Incorrect. That assumes SHR equals one.
- Option 3: Incorrect. Dividing reverses the definition.
- Option 4: Incorrect. That is the latent portion.

**CDCP-Q0257 · single · mechanism**

Why include the final heat sink in the diagram?

1. Room-level transfer must ultimately reject heat outside the protected load
2. The sink affects only documentation
3. More sensors replace the sink
4. Heat disappears at the first exchanger

**Correct option(s):** 1

- Option 1: Correct. A working coil alone is insufficient.
- Option 2: Incorrect. Its availability controls sustained cooling.
- Option 3: Incorrect. Observation does not remove heat.
- Option 4: Incorrect. Energy is transferred rather than destroyed.

**CDCP-Q0258 · single · mechanism**

What can a larger liquid ΔT allow at unchanged heat load?

1. Higher flow is always required
2. Elimination of pump pressure requirements
3. Lower ideal mass flow
4. Unlimited component temperature

**Correct option(s):** 3

- Option 1: Incorrect. That reverses the relationship.
- Option 2: Incorrect. The hydraulic path remains.
- Option 3: Correct. The energy balance is inversely proportional to ΔT.
- Option 4: Incorrect. Equipment limits still constrain the design.

**CDCP-Q0259 · single · mechanism**

Why check control stability as well as steady temperature?

1. Stability is only a software naming convention
2. Oscillation can create excursions and wear despite an acceptable average
3. A correct average proves every instant is acceptable
4. Controls cannot affect physical temperature

**Correct option(s):** 2

- Option 1: Incorrect. It describes dynamic response.
- Option 2: Correct. Dynamic behavior matters.
- Option 3: Incorrect. It can hide swings.
- Option 4: Incorrect. They command actuators.

**CDCP-Q0260 · single · calculation**

Which claim matches a calculated airflow requirement?

1. Guaranteed fan performance
2. Measured installed airflow
3. An analytical demand estimate under stated assumptions
4. A complete cooling commissioning result

**Correct option(s):** 3

- Option 1: Incorrect. The fan and resistance path must be assessed.
- Option 2: Incorrect. No field measurement was performed.
- Option 3: Correct. Delivery still requires verification.
- Option 4: Incorrect. Calculation is one part of acceptance.

#### Recall

**Using density 1.2 kg/m³, heat capacity 1.005 kJ/kg·K and rise 12 K, what airflow removes 30 kW?**

About 2.07 m³/s Correct. Divide load by density, heat capacity and rise.

**How many m³/h correspond to 2 m³/s?**

7200 m³/h Correct. Multiply by 3600 seconds per hour.

**Three 100 kW units serve 220 kW. With one unavailable, what shortfall remains?**

20 kW Correct. Two units provide 200 kW.

**Why use sensible rather than total capacity for a mostly sensible IT load?**

Latent capacity may not be available for sensible heat removal Correct. The rating components differ.

**What must be stated with a cooling rating?**

The operating conditions at which it applies Correct. Capacity can change with air, water and ambient conditions.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## CDCP-M14 — Environmental envelopes and psychrometric reasoning

### CDCP-L14 — Environmental envelopes and psychrometric reasoning

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L13

Environmental acceptance needs the actual equipment class, product limits and site operating policy. Recommended conditions are a design target; allowable limits define a broader supported envelope with possible restrictions. Temperature, moisture, altitude, contaminants and rate of change can interact. A single remembered temperature range is not a substitute for the applicable specification.

Relative humidity is temperature-dependent. Sensible heating reduces RH at constant moisture content; cooling raises RH until saturation is reached. Further cooling with condensation removes moisture and creates a latent load. Dew point is a useful way to judge whether a surface will condense water, while dry-bulb temperature describes the ordinary air temperature. A psychrometric chart or validated calculation connects these properties at a stated pressure.

Humidity control should avoid conflicting systems. One unit humidifying while another dehumidifies can waste energy and create unstable conditions. Establish coordinated setpoints, deadbands, sensor locations and control authority. The correct response depends on the physical process and equipment limits; do not simply tighten every threshold in pursuit of apparent precision.

Sensor placement and uncertainty are part of the envelope. Compare rack inlets at representative heights, local cold surfaces and the relevant air path. A biased sensor can drive the entire plant toward an unsuitable state. Calibration, mapping and independent comparison are therefore operational controls, not administrative extras.

Acceptance should include steady conditions, transitions, failure modes and recovery. A short excursion may have a different consequence from sustained exposure, but permitted duration must come from the approved requirement rather than improvisation. Record both the observed environmental values and the workload and cooling state that produced them. Treat condensation, corrosion and electrostatic-discharge controls as related but distinct mechanisms.

### Use moisture reasoning to avoid conflicting control
A room is heated without adding water. Relative humidity falls because saturation vapor pressure rises; the moisture mass did not disappear. If a humidifier then adds water to restore the original RH, a later temperature reduction can bring the air closer to condensation. Independent loops can therefore create unnecessary moisture cycling unless their objectives are coordinated.

Review sensors at comparable locations before concluding that two units disagree. One may measure return air and another supply air, producing different RH even with similar moisture content. Dew point helps compare the moisture condition, while dry-bulb temperature remains necessary for equipment acceptance.

For a cold connector, compare its surface temperature with local dew point and include uncertainty. A nominal 0.5 K positive margin is not robust if each instrument can be wrong by 1 K. The correct response is to improve evidence or operate within the approved margin, not to round both values until they appear safe. Record the product-specific limits and any allowed duration or rate-of-change conditions.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. Two cooling units serve one space. Unit A humidifies below 45% RH while Unit B dehumidifies above 40% RH, measured at comparable conditions.

**Reasoning:** Between 40% and 45%, both actions can be requested, creating opposing control and energy waste. Reconcile the approved operating band and authority rather than letting independent loops fight.

#### Guided practice

A cold surface is 14°C and local dew point is 15°C, with ±1°C uncertainty on each measurement. How should the margin be interpreted?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** The nominal surface is below dew point and uncertainty does not establish a safe positive margin. Investigate and use the approved condensation response.

#### Independent task

Environment: analytical

Create an environmental control and acceptance matrix for two rack types.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Use product-specific envelopes.
- Include sensor uncertainty and local dew-point margins.
- Identify opposing control actions and transition limits.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0261 · single · calculation**

One unit humidifies below 45% RH and another dehumidifies above 40% RH. What occurs between the thresholds?

Synthetic educational evidence; not field measurements.

Unit A humidifies below 45% RH
Unit B dehumidifies above 40% RH
Comparable air conditions.

1. No energy is consumed
2. The air automatically becomes exactly 42.5% RH
3. Opposing actions can operate simultaneously
4. Both must always be off

**Correct option(s):** 3

- Option 1: Incorrect. Both processes can use energy.
- Option 2: Incorrect. Dynamic behavior does not guarantee the midpoint.
- Option 3: Correct. The control bands overlap in conflict.
- Option 4: Incorrect. Each condition can be active.

**CDCP-Q0262 · single · mechanism**

What does sensible heating do at constant moisture content?

1. Removes water mass automatically
2. Necessarily creates condensation
3. Raises dew point by the same amount
4. Reduces relative humidity

**Correct option(s):** 4

- Option 1: Incorrect. Heating alone does not remove moisture.
- Option 2: Incorrect. Heating moves away from saturation.
- Option 3: Incorrect. Moisture content is unchanged.
- Option 4: Correct. Saturation capacity rises with temperature.

**CDCP-Q0263 · single · mechanism**

What happens after moist air is cooled below its dew point?

1. Moisture content must increase
2. Electrical power factor changes by definition
3. Relative humidity becomes irrelevant physically
4. Condensation can remove moisture

**Correct option(s):** 4

- Option 1: Incorrect. Condensation removes vapor.
- Option 2: Incorrect. That is unrelated.
- Option 3: Incorrect. It remains a property of the air.
- Option 4: Correct. Further cooling can create a latent load.

**CDCP-Q0264 · single · mechanism**

Why does a psychrometric calculation need pressure or altitude context?

1. Air-property relationships depend on pressure
2. All charts apply identically at every pressure
3. Pressure is measured in percent RH
4. Altitude changes only rack dimensions

**Correct option(s):** 1

- Option 1: Correct. A standard-pressure chart has a defined basis.
- Option 2: Incorrect. That assumption can be wrong.
- Option 3: Incorrect. They are different quantities.
- Option 4: Incorrect. It affects air properties.

**CDCP-Q0265 · single · mechanism**

What should govern permitted environmental excursion duration?

1. The age of the building only
2. The highest recorded value anywhere
3. The approved equipment and site requirement
4. The operator's preference alone

**Correct option(s):** 3

- Option 1: Incorrect. Equipment and conditions also matter.
- Option 2: Incorrect. A record is not a permitted limit.
- Option 3: Correct. Duration limits cannot be invented during operation.
- Option 4: Incorrect. Consequences and specifications matter.

**CDCP-Q0266 · single · mechanism**

Why can tight independent humidity loops be inefficient?

1. Humidification has no energy cost
2. They can fight each other or chase sensor differences
3. Dehumidification never affects temperature
4. Every narrow band is automatically best

**Correct option(s):** 2

- Option 1: Incorrect. It uses energy and water.
- Option 2: Correct. Precision without coordination can increase energy use.
- Option 3: Incorrect. The process can affect both.
- Option 4: Incorrect. Control quality and process behavior matter.

**CDCP-Q0267 · single · mechanism**

A sensor is accurate but located in supply air instead of the IT inlet. What remains wrong?

1. Measurement representativeness for inlet acceptance
2. Calibration necessarily
3. Every cooling device
4. The definition of temperature

**Correct option(s):** 1

- Option 1: Correct. Correct measurement of the wrong point is insufficient.
- Option 2: Incorrect. The sensor can be calibrated correctly.
- Option 3: Incorrect. The issue is location and interpretation.
- Option 4: Incorrect. The physical quantity is valid.

**CDCP-Q0268 · single · mechanism**

What does a positive dew-point margin mean here?

1. The surface is colder than dew point
2. RH is necessarily zero
3. The surface is warmer than the local dew point
4. No coolant leak can occur

**Correct option(s):** 3

- Option 1: Incorrect. That is a condensation-risk condition.
- Option 2: Incorrect. Moisture can still be present.
- Option 3: Correct. That reduces condensation likelihood under the stated conditions.
- Option 4: Incorrect. Condensation and leakage are different.

**CDCP-Q0269 · single · mechanism**

Why include measurement uncertainty in a narrow margin decision?

1. Rounding removes uncertainty
2. Digital sensors have zero uncertainty
3. Uncertainty always makes the reading unusable
4. The true values may cross the apparent threshold

**Correct option(s):** 4

- Option 1: Incorrect. It only changes display precision.
- Option 2: Incorrect. They do not.
- Option 3: Incorrect. It can be managed in the decision.
- Option 4: Correct. A small nominal margin may not be robust.

**CDCP-Q0270 · single · mechanism**

What does an allowable envelope not automatically mean?

1. Product limits matter
2. Conditions should be documented
3. Every extreme is the preferred continuous operating point
4. The equipment can have a supported range

**Correct option(s):** 3

- Option 1: Incorrect. They remain governing inputs.
- Option 2: Incorrect. They should.
- Option 3: Correct. Recommended operation can be narrower.
- Option 4: Incorrect. That is the purpose of the envelope.

**CDCP-Q0271 · single · mechanism**

Why distinguish condensation from a coolant leak?

1. Every wet surface proves a broken hose
2. A leak detector always identifies the source
3. Condensation can never occur indoors
4. The water sources and corrective actions differ

**Correct option(s):** 4

- Option 1: Incorrect. Moisture can condense from air.
- Option 2: Incorrect. It may detect liquid without identifying origin.
- Option 3: Incorrect. It can occur on cold surfaces.
- Option 4: Correct. Both can wet surfaces but arise through different mechanisms.

**CDCP-Q0272 · single · mechanism**

What can a biased common sensor cause?

1. Every controller independently corrects the bias automatically
2. Multiple units may respond incorrectly to the same false condition
3. Only the graph label changes
4. The bias cancels because many units read it

**Correct option(s):** 2

- Option 1: Incorrect. That cannot be assumed.
- Option 2: Correct. A shared measurement can create a common control error.
- Option 3: Incorrect. Commands can affect physical conditions.
- Option 4: Incorrect. Sharing the same bias does not cancel it.

**CDCP-Q0273 · single · mechanism**

Which data supports an environmental acceptance result?

1. Only the most favorable temperature
2. Values plus workload, location, time and cooling state
3. Only the room name
4. Only the entered setpoint

**Correct option(s):** 2

- Option 1: Incorrect. That hides variation.
- Option 2: Correct. The observation needs a reproducible envelope.
- Option 3: Incorrect. That does not establish conditions.
- Option 4: Incorrect. Commanded and measured states can differ.

**CDCP-Q0274 · single · mechanism**

Why coordinate deadbands?

1. Every wider deadband is acceptable
2. Deadbands create unlimited cooling capacity
3. They define when opposing or repeated actions occur
4. Deadbands replace all alarms

**Correct option(s):** 3

- Option 1: Incorrect. Equipment limits still constrain variation.
- Option 2: Incorrect. They affect control behavior, not nameplate capacity.
- Option 3: Correct. Suitable separation can reduce hunting.
- Option 4: Incorrect. Monitoring still needs appropriate thresholds.

**CDCP-Q0275 · single · mechanism**

What can low humidity contribute to in some conditions?

1. Automatic elimination of ESD
2. Higher optical power by definition
3. Guaranteed corrosion in every device
4. Electrostatic-discharge risk

**Correct option(s):** 4

- Option 1: Incorrect. Dry conditions can increase charge accumulation.
- Option 2: Incorrect. That is unrelated.
- Option 3: Incorrect. Corrosion depends on moisture and contaminants.
- Option 4: Correct. Handling and bonding controls also matter.

**CDCP-Q0276 · single · mechanism**

Why is room-average RH not enough for every cold surface?

1. Local temperature and moisture conditions can differ
2. All surfaces have room-air temperature
3. RH alone directly measures surface temperature
4. Averages are mathematically impossible

**Correct option(s):** 1

- Option 1: Correct. Condensation is assessed at the relevant surface environment.
- Option 2: Incorrect. Cold liquid interfaces can be lower.
- Option 3: Incorrect. It does not.
- Option 4: Incorrect. They can be valid but insufficient.

**CDCP-Q0277 · single · mechanism**

What is a useful independent check before changing plant settings based on one unusual sensor?

1. Deleting the trend
2. A suitable reference measurement at the relevant location
3. Accepting the lowest reading as truth
4. Changing all sensors to match the unusual value

**Correct option(s):** 2

- Option 1: Incorrect. That removes evidence.
- Option 2: Correct. It tests the measurement hypothesis.
- Option 3: Incorrect. Extremes are not automatically accurate.
- Option 4: Incorrect. That assumes the value is correct.

**CDCP-Q0278 · single · mechanism**

Why assess rate of environmental change where specified?

1. Rates cannot be measured
2. Only final temperature ever matters
3. Rapid transitions can have different effects from steady exposure
4. A slower display refresh guarantees a slower process

**Correct option(s):** 3

- Option 1: Incorrect. Time-series data can show them.
- Option 2: Incorrect. Transitions can create stress or condensation.
- Option 3: Correct. The operating envelope can include dynamics.
- Option 4: Incorrect. Display timing does not control physical change.

**CDCP-Q0279 · single · mechanism**

What is the correct interpretation of a chart-based humidity calculation?

1. A guarantee that instruments are calibrated
2. A complete facility certification
3. An analytical relationship under stated assumptions
4. A direct observation of every rack

**Correct option(s):** 3

- Option 1: Incorrect. The chart does not test them.
- Option 2: Incorrect. It is one analysis tool.
- Option 3: Correct. Field values still need suitable measurement.
- Option 4: Incorrect. No sensors were used in that calculation.

**CDCP-Q0280 · single · mechanism**

Why retain contamination considerations with humidity policy?

1. Higher RH always improves every risk
2. Cleanliness never affects electronics
3. Moisture and contaminants can interact in corrosion
4. Humidity policy alone removes every contaminant

**Correct option(s):** 3

- Option 1: Incorrect. Tradeoffs exist.
- Option 2: Incorrect. Contamination can cause problems.
- Option 3: Correct. Environmental suitability is multidimensional.
- Option 4: Incorrect. Filtration and source control remain relevant.

#### Recall

**One unit humidifies below 45% RH and another dehumidifies above 40% RH. What occurs between the thresholds?**

Opposing actions can operate simultaneously Correct. The control bands overlap in conflict.

**What does sensible heating do at constant moisture content?**

Reduces relative humidity Correct. Saturation capacity rises with temperature.

**What happens after moist air is cooled below its dew point?**

Condensation can remove moisture Correct. Further cooling can create a latent load.

**Why does a psychrometric calculation need pressure or altitude context?**

Air-property relationships depend on pressure Correct. A standard-pressure chart has a defined basis.

**What should govern permitted environmental excursion duration?**

The approved equipment and site requirement Correct. Duration limits cannot be invented during operation.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## CDCP-M15 — Cooling arrangements, airflow and containment acceptance

### CDCP-L15 — Cooling arrangements, airflow and containment acceptance

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L14

Cooling arrangements differ in where heat is collected and how air reaches equipment. Room units serve a shared volume; in-row units place cooling nearer the load; rear-door exchangers capture exhaust at the rack. Raised-floor, overhead and hard-floor designs can all work when supply and return paths are engineered. The topology name alone does not establish performance.

Bypass and recirculation waste useful delivery in different ways. Supply air that reaches return without passing through IT is bypass. Exhaust entering an inlet is recirculation. Containment, blanking, sealing and cable management can reduce these paths, but pressure balance and fan behavior must be considered. Excess supply can increase bypass while inadequate local supply promotes recirculation.

A fan's operating point is where its pressure-flow characteristic meets system resistance. Adding a restrictive door, filter or cable obstruction changes the system curve. The fan may not deliver its free-air nameplate flow through the installed path. Multiple fans and control loops can interact; increasing one fan command can redistribute flow rather than simply improve every rack.

Containment also changes interfaces with fire detection, suppression, lighting, access and maintenance. Doors left open for routine work can undermine the expected thermal result. A design should support the actual operating workflow rather than relying on a permanently ideal door state that staff cannot maintain.

Acceptance combines rack inlet maps, airflow or pressure observations, load, fan state and failure conditions. Use a before/after comparison for corrective work, and validate adjacent racks because flow is coupled. Select setpoints within the equipment and moisture envelope, then verify that efficiency gains do not consume required failure-state margin. A lower room-average temperature is not automatically evidence of better air management.

### Treat airflow as a coupled pressure network
A supply fan feeds a plenum with three outlet paths. Opening a large unintended gap adds a low-resistance route. More total air may leave the plenum while less useful air reaches the far rack. This is why increasing open area can worsen a hotspot and why a fan's free-air rating is not the delivered equipment flow.

Use the fan characteristic and system resistance to explain the operating point, then verify it with suitable pressure or flow observations. A filter replacement can change resistance; a blocked rear door can change rack flow; containment doors can change mixing. Each is a physical change that deserves a measured before/after comparison.

For acceptance, map representative inlets under the required load, then repeat the specified cooling-unit-loss state. Confirm that the correction does not simply move hot air to another rack. Include fire and access interfaces in containment changes. Energy optimization follows once required inlets and failure margins are satisfied, and it should compare total relevant fan and plant energy rather than one attractive local reading.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A rack hotspot improves when a containment door is closed, but a neighboring rack inlet rises because its supply path relied on the opening.

**Reasoning:** The intervention changed the shared pressure and mixing paths. Both racks must meet the requirement; redesign or balance the delivery rather than accepting a local improvement that moves the problem.

#### Guided practice

A fan is rated at 2 m³/s free air. The installed door and filter add resistance. Can 2 m³/s be assumed at the rack?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** No. The installed operating point depends on the fan and system curves. Measure or use supported performance at the actual pressure.

#### Independent task

Environment: analytical

Evaluate a synthetic containment change with inlet maps before and after.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Distinguish local improvement from whole-zone acceptance.
- Include fire, access and lighting interfaces.
- Check fan operating conditions and required failure states.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0281 · single · mechanism**

What determines a fan's installed operating point?

1. Intersection of fan characteristic and system resistance
2. Only rack count
3. Only its maximum advertised flow
4. Only the room name

**Correct option(s):** 1

- Option 1: Correct. Free-air flow alone is insufficient.
- Option 2: Incorrect. Geometry and resistance also matter.
- Option 3: Incorrect. Installed resistance changes delivery.
- Option 4: Incorrect. Naming does not define pressure.

**CDCP-Q0282 · single · mechanism**

A restrictive filter is added without fan adjustment. What may happen?

1. Every inlet temperature must fall
2. Delivered flow can fall
3. Heat load becomes zero
4. Flow must always rise

**Correct option(s):** 2

- Option 1: Incorrect. Reduced flow can worsen cooling.
- Option 2: Correct. The system resistance has increased.
- Option 3: Incorrect. The filter does not remove IT demand.
- Option 4: Incorrect. That contradicts the added resistance effect.

**CDCP-Q0283 · single · mechanism**

What is the main difference between bypass and recirculation?

1. Bypass avoids IT; recirculation returns exhaust to inlets
2. Recirculation always improves cooling
3. Bypass is only an electrical term
4. Both always describe the same path

**Correct option(s):** 1

- Option 1: Correct. They are distinct unwanted paths.
- Option 2: Incorrect. Hot exhaust at inlets can raise temperature.
- Option 3: Incorrect. It also describes airflow behavior.
- Option 4: Incorrect. Their source and destination differ.

**CDCP-Q0284 · single · diagnosis**

A containment change cools one rack but overheats its neighbor. What is the acceptance result?

Synthetic educational evidence; not field measurements.

After containment change: rack A improves
Neighbor rack B exceeds its inlet limit

1. The average alone decides regardless of limits
2. The change passes because one rack improved
3. The affected zone has not met all requirements
4. The neighbor must be ignored as unrelated

**Correct option(s):** 3

- Option 1: Incorrect. Local limits still apply.
- Option 2: Incorrect. All mandatory inlets matter.
- Option 3: Correct. A local improvement cannot hide a new violation.
- Option 4: Incorrect. Airflow is coupled.

**CDCP-Q0285 · single · mechanism**

Why test containment with realistic door use?

1. Doors never open after commissioning
2. Open doors always improve every rack
3. Door state affects only security
4. Operational openings can change the intended air separation

**Correct option(s):** 4

- Option 1: Incorrect. Maintenance and access require them.
- Option 2: Incorrect. They can create mixing or pressure loss.
- Option 3: Incorrect. It also affects airflow.
- Option 4: Correct. The design must fit actual workflows.

**CDCP-Q0286 · single · mechanism**

What should be reviewed when installing a containment roof?

1. Only the predicted cooling-energy reduction
2. Only the Ethernet speed
3. Detection, suppression, lighting and access interfaces
4. Only the purchase discount

**Correct option(s):** 3

- Option 1: Incorrect. Thermal benefit does not verify life-safety and access interfaces.
- Option 2: Incorrect. That does not cover physical interfaces.
- Option 3: Correct. The new geometry affects more than temperature.
- Option 4: Incorrect. Cost does not demonstrate suitability.

**CDCP-Q0287 · single · mechanism**

Why is free-air fan flow not the installed rack flow?

1. Fans cannot move air through equipment
2. A rack has no resistance
3. Free-air ratings measure only noise
4. The installed path imposes pressure resistance

**Correct option(s):** 4

- Option 1: Incorrect. They can, at the resulting operating point.
- Option 2: Incorrect. Doors and equipment create resistance.
- Option 3: Incorrect. They describe a flow condition.
- Option 4: Correct. The operating point changes under load.

**CDCP-Q0288 · single · mechanism**

Which evidence best supports airflow correction?

1. Only a fan command increase
2. Only a lower supply setpoint
3. Comparable inlet measurements and operating context before and after
4. Only a photograph of new panels

**Correct option(s):** 3

- Option 1: Incorrect. Command is not delivered flow.
- Option 2: Incorrect. That can mask rather than correct mixing.
- Option 3: Correct. It shows the effect under stated conditions.
- Option 4: Incorrect. Installation does not prove thermal response.

**CDCP-Q0289 · single · mechanism**

Why can excessive supply flow waste energy?

1. Bypass transfers more heat through IT
2. Fan power is independent of flow in every system
3. It can increase fan work and bypass
4. Extra supply automatically lowers every cost

**Correct option(s):** 3

- Option 1: Incorrect. It avoids the load.
- Option 2: Incorrect. Operating demand can change.
- Option 3: Correct. More flow is not always more useful cooling.
- Option 4: Incorrect. It can raise energy use.

**CDCP-Q0290 · single · mechanism**

What does in-row cooling change primarily?

1. The need for a final heat sink
2. The existence of power demand
3. Every maintenance requirement
4. The location of heat collection relative to racks

**Correct option(s):** 4

- Option 1: Incorrect. Heat still must be rejected.
- Option 2: Incorrect. Cooling equipment still consumes energy.
- Option 3: Incorrect. Equipment still needs service.
- Option 4: Correct. It can shorten the air path.

**CDCP-Q0291 · single · mechanism**

Why measure multiple rack inlet positions?

1. Temperature gradients are impossible indoors
2. Every inlet is identical
3. More sensors always make the process stable
4. Local and vertical gradients can be missed by one sensor

**Correct option(s):** 4

- Option 1: Incorrect. They are common in uneven flow.
- Option 2: Incorrect. Air paths can differ.
- Option 3: Incorrect. Observation alone does not control it.
- Option 4: Correct. A single point may be unrepresentative.

**CDCP-Q0292 · single · mechanism**

What can cable congestion behind a rack do?

1. Increase exhaust resistance or redirect hot air
2. Guarantee correct optical polarity
3. Increase UPS energy storage
4. Improve all fan operating points automatically

**Correct option(s):** 1

- Option 1: Correct. Mechanical routing affects cooling.
- Option 2: Incorrect. Cable neatness does not establish lane mapping.
- Option 3: Incorrect. That is unrelated.
- Option 4: Incorrect. It can obstruct flow.

**CDCP-Q0293 · single · mechanism**

Why retain a rollback threshold for a setpoint change?

1. Rollback can be decided only after equipment damage
2. The change may violate inlet or stability limits
3. A signed change guarantees acceptable temperatures
4. Every setpoint change is harmless

**Correct option(s):** 2

- Option 1: Incorrect. Thresholds should act earlier.
- Option 2: Correct. A reversible plan needs a measured trigger.
- Option 3: Incorrect. Measurement is still required.
- Option 4: Incorrect. Physical response can be unfavorable.

**CDCP-Q0294 · single · mechanism**

What does a hard-floor design still need?

1. No heat rejection
2. No airflow planning
3. Only more rack fans
4. Engineered supply and return separation

**Correct option(s):** 4

- Option 1: Incorrect. Heat still must leave the system.
- Option 2: Incorrect. Distribution remains essential.
- Option 3: Incorrect. Room-level paths also matter.
- Option 4: Correct. A raised floor is one method, not the only method.

**CDCP-Q0295 · single · mechanism**

Which observation suggests recirculation near a rack top?

1. Upper inlet temperature rises toward exhaust conditions
2. Lower branch current alone
3. Every inlet equals supply temperature
4. A fiber link error alone

**Correct option(s):** 1

- Option 1: Correct. The pattern supports a mixing hypothesis.
- Option 2: Incorrect. That is not direct airflow evidence.
- Option 3: Incorrect. That suggests good separation under the observed state.
- Option 4: Incorrect. That does not identify recirculation.

**CDCP-Q0296 · single · mechanism**

Why inspect blanking and side seals together?

1. Blanking panels add cooling kW
2. Seals replace every fan
3. Unused U-space and side gaps can both connect air paths
4. Only the front face can leak air

**Correct option(s):** 3

- Option 1: Incorrect. They improve delivery, not refrigeration capacity.
- Option 2: Incorrect. They direct flow rather than generate it.
- Option 3: Correct. One correction may leave another bypass route.
- Option 4: Incorrect. Side and penetration paths also matter.

**CDCP-Q0297 · single · mechanism**

What should a failure-state airflow test include?

1. Only a room drawing
2. Only the warmest outdoor day prediction
3. All units running at no load
4. The specified unavailable equipment and representative load

**Correct option(s):** 4

- Option 1: Incorrect. Design intent is not measured response.
- Option 2: Incorrect. Installed behavior still needs evidence.
- Option 3: Incorrect. That does not exercise the failure state.
- Option 4: Correct. Distribution can change when a unit stops.

**CDCP-Q0298 · single · mechanism**

Why can independently controlled fans fight?

1. Fans have no physical interaction
2. Their pressure and temperature responses interact in one air system
3. Conflicting commands change only the dashboard
4. More controllers guarantee perfect coordination

**Correct option(s):** 2

- Option 1: Incorrect. They share air paths.
- Option 2: Correct. Separate controllers can influence each other's measurements.
- Option 3: Incorrect. They affect actual flow.
- Option 4: Incorrect. Coordination must be designed.

**CDCP-Q0299 · single · mechanism**

What is a suitable acceptance claim for a modeled airflow layout?

1. A guarantee that doors can remain open indefinitely
2. Full fire-system approval
3. Measured performance at every rack
4. A design prediction requiring physical validation

**Correct option(s):** 4

- Option 1: Incorrect. The boundary conditions matter.
- Option 2: Incorrect. Thermal modeling does not assess every fire interface.
- Option 3: Incorrect. No field test is implied.
- Option 4: Correct. The model has assumptions and fidelity limits.

**CDCP-Q0300 · single · mechanism**

Why compare efficiency after verifying thermal limits?

1. Every colder state is more efficient
2. A lower-energy state is useful only if required service remains suitable
3. Thermal checks eliminate the need for energy measurement
4. Energy savings override equipment limits

**Correct option(s):** 2

- Option 1: Incorrect. Lower temperature can increase energy use.
- Option 2: Correct. Constraints apply simultaneously.
- Option 3: Incorrect. Both outcomes matter.
- Option 4: Incorrect. They do not.

#### Recall

**What determines a fan's installed operating point?**

Intersection of fan characteristic and system resistance Correct. Free-air flow alone is insufficient.

**A restrictive filter is added without fan adjustment. What may happen?**

Delivered flow can fall Correct. The system resistance has increased.

**What is the main difference between bypass and recirculation?**

Bypass avoids IT; recirculation returns exhaust to inlets Correct. They are distinct unwanted paths.

**A containment change cools one rack but overheats its neighbor. What is the acceptance result?**

The affected zone has not met all requirements Correct. A local improvement cannot hide a new violation.

**Why test containment with realistic door use?**

Operational openings can change the intended air separation Correct. The design must fit actual workflows.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## CDCP-M16 — Liquid cooling integration and acceptance

### CDCP-L16 — Liquid cooling integration and acceptance

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L15

Liquid cooling requires explicit ownership at each boundary. Identify the IT heat source, cold plate or immersion interface, technology loop, CDU, facility loop and final heat rejection. Direct-to-chip, rear-door and immersion designs differ in heat capture, access, fluid compatibility and residual air demand. A design should state which components remain air cooled rather than assuming a liquid label removes room cooling.

Use a heat balance to check plausibility. For an illustrative water loop, Q = mass flow × 4.18 kJ/(kg·K) × temperature rise. A glycol mixture or dielectric fluid requires its actual properties. Flow capacity, pump head and heat-exchanger approach are separate constraints: a pump can circulate the nominal volume while the exchanger cannot transfer the required heat at the available temperature difference.

A CDU can isolate fluid chemistry and pressure between loops while exchanging heat. Its controls may regulate supply temperature, differential pressure or flow according to the product and design. Shared sensors, power or software can create common failures across otherwise duplicated pumps. State how the system behaves after sensor loss, communication loss, facility-water loss and restart.

Maintenance interfaces include isolation valves, drain and fill points, filtration, leak detection, connector handling and contamination control. Compatible wetted materials and fluid chemistry prevent avoidable degradation. An approved method must define pressure state and electrical/thermal consequences before disconnection. This analytical course does not authorize live fluid-system intervention.

Acceptance measures heat load, flow, supply/return temperatures, pressure, alarm response and residual air conditions. Challenge misleading states: pumps running with blocked flow, low temperature with no transport, and healthy network communication with stale telemetry. Record actual versus simulated faults and verify restoration of normal control and redundancy after every test.

### Distinguish hydraulic success from thermal success
A CDU reports its pump at 70% command and technology-loop flow at the expected value. However, facility-water supply is warmer than the exchanger design assumption. The loop can be hydraulically healthy while unable to reject the required heat. Inspect both stream temperatures and the supported exchanger performance at those conditions rather than declaring success from flow alone.

Conversely, cold facility water does not prove a blocked technology branch receives enough flow. Parallel branch resistance, valves, filters and trapped gas can create uneven delivery. A total-flow reading may conceal one starved cold plate. Define which branch observations or OEM diagnostics demonstrate the required distribution.

During maintenance, preserve fluid compatibility and cleanliness. A substitute hose that fits can still use an unsuitable seal or material. Record the approved part and coolant specification, isolation state and restoration checks. After restart, verify flow, pressure, temperatures, leaks and residual air conditions under load. The accepted claim is the measured system behavior, not simply a successful controller reboot.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A rack dissipates 120 kW, with 90 kW captured by a water loop at 10 K rise.

**Reasoning:** Ideal liquid mass flow is 90/(4.18×10)=2.153 kg/s. Residual IT air heat is 30 kW. Both liquid delivery and room-air capacity must satisfy the requirement.

#### Guided practice

Two CDU pumps share one controller and power feed. What does pump duplication fail to prove?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** Independence from the shared controller or feed. Review those failure states separately.

#### Independent task

Environment: analytical

Build a liquid-cooling interface matrix and test case.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Calculate liquid and residual air heat separately.
- Identify pressure, chemistry and authority boundaries.
- Test loss and restoration of flow through approved analytical or vendor methods.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0301 · single · calculation**

A 120 kW rack transfers 90 kW to liquid. What residual IT air heat remains?

Synthetic educational evidence; not field measurements.

Rack heat: 120 kW
Liquid heat: 90 kW

1. 30 kW
2. 90 kW
3. 0 kW
4. 120 kW

**Correct option(s):** 1

- Option 1: Correct. Subtract liquid capture from total dissipation.
- Option 2: Incorrect. That is the liquid load.
- Option 3: Incorrect. Not all heat is captured.
- Option 4: Incorrect. That ignores liquid capture.

**CDCP-Q0302 · single · calculation**

For water at cp 4.18 kJ/kg·K, what flow removes 90 kW at 10 K rise?

Synthetic educational evidence; not field measurements.

Liquid heat: 90 kW
Water cp: 4.18 kJ/(kg·K)
Rise: 10 K

1. About 21.5 kg/s
2. About 41.8 kg/s
3. About 0.215 kg/s
4. About 2.15 kg/s

**Correct option(s):** 4

- Option 1: Incorrect. The temperature rise was omitted.
- Option 2: Incorrect. That is the denominator, not the result.
- Option 3: Incorrect. That adds an extra factor of ten.
- Option 4: Correct. 90 divided by 41.8 gives the flow.

**CDCP-Q0303 · single · mechanism**

What can a CDU heat exchanger separate?

1. Fluid and pressure conditions between loops
2. All maintenance responsibilities
3. The need for final heat rejection
4. Every failure cause between both loops

**Correct option(s):** 1

- Option 1: Correct. Heat can cross without mixing the fluids.
- Option 2: Incorrect. Interfaces still need assigned ownership.
- Option 3: Incorrect. Heat still must leave the facility.
- Option 4: Incorrect. Shared controls or sinks can remain.

**CDCP-Q0304 · single · mechanism**

Why is pump flow not enough to prove exchanger capacity?

1. Every exchanger transfers infinite heat
2. Pump command directly measures transferred kW
3. Heat transfer is independent of temperature difference
4. Temperature approach and heat-transfer limits also matter

**Correct option(s):** 4

- Option 1: Incorrect. It has finite conductance and conditions.
- Option 2: Incorrect. It does not.
- Option 3: Incorrect. A driving difference is required.
- Option 4: Correct. Hydraulic flow is only part of the thermal function.

**CDCP-Q0305 · single · diagnosis**

Two pumps share one controller. Which fault remains common?

Synthetic educational evidence; not field measurements.

CDU pumps: two
Control authority: one shared controller

1. Different maintenance dates
2. Separate serial numbers
3. Controller failure or erroneous command
4. One pump seal failure necessarily

**Correct option(s):** 3

- Option 1: Incorrect. Dates do not create controller independence.
- Option 2: Incorrect. Those are identities, not a failure.
- Option 3: Correct. Both pumps depend on the shared authority.
- Option 4: Incorrect. That may affect only one unit if isolated.

**CDCP-Q0306 · single · mechanism**

Why use actual coolant properties?

1. Every fluid has the same cp
2. Equal pipe diameter makes all coolants thermally equivalent
3. Pipe labels determine viscosity
4. Heat capacity and viscosity affect thermal and hydraulic performance

**Correct option(s):** 4

- Option 1: Incorrect. They differ.
- Option 2: Incorrect. Material properties remain different at the same pipe size.
- Option 3: Incorrect. Viscosity is a fluid property and condition.
- Option 4: Correct. Water assumptions may not fit a mixture.

**CDCP-Q0307 · single · mechanism**

What should precede disconnecting a coolant interface?

1. Assuming quick disconnect means zero risk
2. Only stopping the circulating pump
3. The approved isolation, pressure and thermal-state procedure
4. Turning off the dashboard

**Correct option(s):** 3

- Option 1: Incorrect. Limits and handling still apply.
- Option 2: Incorrect. Pressure, stored energy and thermal consequences can remain after a stop command.
- Option 3: Correct. The intervention has physical consequences.
- Option 4: Incorrect. Display state does not isolate the loop.

**CDCP-Q0308 · single · mechanism**

What can a pump-running indication fail to prove?

1. That power is available to the indicator
2. Actual required branch flow
3. That a run signal exists
4. That pumps are part of the design

**Correct option(s):** 2

- Option 1: Incorrect. It likely is, but that is not the required function.
- Option 2: Correct. A blocked or bypassed path can still have a running motor.
- Option 3: Incorrect. The indication can show that narrow state.
- Option 4: Incorrect. They are identified.

**CDCP-Q0309 · single · mechanism**

Why include residual air temperature in liquid-system acceptance?

1. Components outside the liquid path still need suitable cooling
2. Room sensors measure liquid chemistry
3. Liquid systems always warm the room by zero watts
4. Air becomes physically irrelevant

**Correct option(s):** 1

- Option 1: Correct. Liquid capture can be partial.
- Option 2: Incorrect. They do not.
- Option 3: Incorrect. Residual load can be substantial.
- Option 4: Incorrect. Some heat and surfaces remain in air.

**CDCP-Q0310 · single · mechanism**

What can incorrect fluid chemistry cause?

1. Elimination of filtration needs
2. Material degradation, deposits or performance problems
3. Guaranteed improved heat transfer
4. Automatic correction by IP networking

**Correct option(s):** 2

- Option 1: Incorrect. Particles and chemistry are distinct concerns.
- Option 2: Correct. Compatibility and cleanliness matter.
- Option 3: Incorrect. Unsuitable chemistry can impair the system.
- Option 4: Incorrect. Digital communication does not change chemistry safely.

**CDCP-Q0311 · single · mechanism**

Why record the boundary of a simulated flow-fault test?

1. Simulation has no instructional value
2. It may test logic without reproducing real hydraulic behavior
3. Simulation proves every physical valve position
4. The boundary is irrelevant if the alarm turns red

**Correct option(s):** 2

- Option 1: Incorrect. It can test selected responses.
- Option 2: Correct. The claim must match the stimulus.
- Option 3: Incorrect. It does not.
- Option 4: Incorrect. Alarm color is a narrow observation.

**CDCP-Q0312 · single · mechanism**

A cold supply reading persists after flow stops. What is the correct concern?

1. The reading can lag while components lose heat transport
2. The IT load must have stopped
3. The sensor is necessarily malicious
4. Cooling must be improving

**Correct option(s):** 1

- Option 1: Correct. Local cold fluid does not prove moving heat.
- Option 2: Incorrect. That is not stated.
- Option 3: Incorrect. Several benign mechanisms can explain it.
- Option 4: Incorrect. No flow can be hazardous.

**CDCP-Q0313 · single · mechanism**

What is a heat-exchanger approach temperature conceptually?

1. A temperature difference limiting how closely one stream can approach the other
2. The total IT temperature rise only
3. A guarantee that both streams leave at identical temperatures
4. The room's walking distance to the CDU

**Correct option(s):** 1

- Option 1: Correct. Finite heat transfer requires a driving difference.
- Option 2: Incorrect. It is a different exchanger relationship.
- Option 3: Incorrect. That is not generally attainable.
- Option 4: Incorrect. That is physical access, not thermal approach.

**CDCP-Q0314 · single · mechanism**

Why assign loop ownership explicitly?

1. Ownership changes fluid density
2. Assigning owners replaces technical tests
3. Maintenance and incident decisions cross IT and facility responsibilities
4. One vendor name automatically owns every interface

**Correct option(s):** 3

- Option 1: Incorrect. It is governance, not material physics.
- Option 2: Incorrect. Evidence is still needed.
- Option 3: Correct. Unclear boundaries delay safe action.
- Option 4: Incorrect. Contracts and design define responsibilities.

**CDCP-Q0315 · single · mechanism**

What should recovery after a CDU alarm verify?

1. Stable flow, temperature, pressure, control state and service
2. Only a controller reboot
3. Only alarm acknowledgment
4. Only a new work-order number

**Correct option(s):** 1

- Option 1: Correct. The whole required function must return.
- Option 2: Incorrect. Configuration and process response still need checks.
- Option 3: Incorrect. That does not restore heat transport.
- Option 4: Incorrect. Administrative state is not physical recovery.

**CDCP-Q0316 · single · mechanism**

Why check service access around manifolds?

1. Access matters only before installation
2. Isolation and replacement require controlled physical reach
3. Manifolds never need intervention
4. More hoses always improve access

**Correct option(s):** 2

- Option 1: Incorrect. Maintenance continues throughout life.
- Option 2: Correct. Dense packaging can obstruct necessary work.
- Option 3: Incorrect. They can require inspection or replacement.
- Option 4: Incorrect. They can congest the space.

**CDCP-Q0317 · single · mechanism**

What does a leak detector's healthy state establish?

1. Every connector is chemically compatible
2. No detected leak under its installed coverage and conditions
3. Correct pressure at every branch
4. No leak anywhere in either loop

**Correct option(s):** 2

- Option 1: Incorrect. That needs separate evidence.
- Option 2: Correct. It does not prove universal absence.
- Option 3: Incorrect. Leak detection is not pressure measurement.
- Option 4: Incorrect. Coverage can be incomplete.

**CDCP-Q0318 · single · mechanism**

Why consider restart sequence after power restoration?

1. Restart is unrelated to cooling
2. Pumps, valves and IT loads may need coordinated recovery
3. A normal power source guarantees valid controller configuration
4. All devices restart instantaneously in the correct order

**Correct option(s):** 2

- Option 1: Incorrect. It determines flow and load return.
- Option 2: Correct. Uncontrolled restart can create unsuitable states.
- Option 3: Incorrect. Configuration can still be wrong.
- Option 4: Incorrect. That cannot be assumed.

**CDCP-Q0319 · single · mechanism**

Which observation supports a heat-balance consistency check?

1. One pump speed value alone
2. One rack-front photograph
3. The number of hoses alone
4. Matched flow and supply/return temperatures at known load

**Correct option(s):** 4

- Option 1: Incorrect. Speed does not establish flow or temperature rise.
- Option 2: Incorrect. It cannot measure heat transfer.
- Option 3: Incorrect. Count does not establish performance.
- Option 4: Correct. The quantities connect to transported heat.

**CDCP-Q0320 · single · mechanism**

What is the proper scope of this chapter's calculation?

1. A complete pressure-vessel approval
2. Production-proven liquid cooling
3. An official OEM compatibility certificate
4. Analytical integration evidence requiring supported design and physical validation

**Correct option(s):** 4

- Option 1: Incorrect. That requires specialist design and authority.
- Option 2: Incorrect. No production test is implied.
- Option 3: Incorrect. The calculation does not award one.
- Option 4: Correct. It does not authorize installation.

#### Recall

**A 120 kW rack transfers 90 kW to liquid. What residual IT air heat remains?**

30 kW Correct. Subtract liquid capture from total dissipation.

**For water at cp 4.18 kJ/kg·K, what flow removes 90 kW at 10 K rise?**

About 2.15 kg/s Correct. 90 divided by 41.8 gives the flow.

**What can a CDU heat exchanger separate?**

Fluid and pressure conditions between loops Correct. Heat can cross without mixing the fluids.

**Why is pump flow not enough to prove exchanger capacity?**

Temperature approach and heat-transfer limits also matter Correct. Hydraulic flow is only part of the thermal function.

**Two pumps share one controller. Which fault remains common?**

Controller failure or erroneous command Correct. Both pumps depend on the shared authority.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## CDCP-M17 — Water supply, heat rejection and seasonal storage

### CDCP-L17 — Water supply, heat rejection and seasonal storage

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L16

Water-dependent cooling needs a complete resource chain: source, treatment, storage, distribution, heat rejection and discharge or reuse. Cooling towers reject heat partly through evaporation, so makeup demand includes evaporation, blowdown and drift under the system's conditions. Dry coolers reduce direct evaporative water use but their performance depends on ambient air and the required approach temperature. A hybrid arrangement trades water, energy and capacity across operating modes.

Water quality affects scaling, corrosion and biological control. Treatment requirements are specific to the system, materials and jurisdiction. A tank with adequate volume can still be unusable because of contamination or failed delivery pumps. Backup-water autonomy should use usable volume and the actual demand during the required operating state, including any restrictions or reserve.

Economizers use favorable environmental conditions to reduce mechanical refrigeration demand. Air-side and water-side methods have different filtration, humidity, contamination and freeze-protection interfaces. Free cooling is not literally zero energy: fans, pumps and controls still consume power, and the operating envelope must remain suitable.

Seasonal thermal storage shifts heat or cold between periods using a designed storage medium or geological interface. Its feasibility depends on storage capacity, losses, temperature levels, resource conditions and permitted construction. This course provides functional and integration literacy; subsurface, structural and detailed thermal design remain specialist work. A large stored-energy quantity is useful only if it can be delivered at the required rate and temperature.

Acceptance should verify mode transitions, water-loss response, flow and temperature delivery, alarms and restoration. Compare efficiency and sustainability using both energy and water boundaries. A design with lower PUE can use more water, so the preferred option depends on local constraints and the required resilience envelope.

### Compare water autonomy and heat-rejection modes
A cooling system needs 8 m³/h of makeup under the defined hot-weather condition. A 100 m³ tank has 15 m³ unavailable and 5 m³ reserved, leaving 80 m³ for a ten-hour model. If the actual demand rises to 12 m³/h, the same usable volume supports only 6.67 hours. The autonomy statement must therefore name the demand condition and delivery assumptions.

An economizer mode may lower compressor energy while raising fan or pump energy. Compare the whole relevant boundary. For example, a 40 kW compressor reduction combined with a 15 kW auxiliary increase gives a net 25 kW reduction under the observed load, not 40 kW. Then check water use and equipment conditions.

Seasonal storage adds a time dimension: energy can be accumulated during favorable conditions and discharged later, but storage losses, temperature grade and discharge power determine usefulness. A large energy inventory at an unsuitable temperature cannot meet a colder supply requirement without further equipment. Keep geological or structural design with the qualified specialty while retaining these integration requirements.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A backup tank has 120 m³, of which 20 m³ is unavailable or reserved. Required makeup demand is 10 m³/h.

**Reasoning:** Usable volume is 100 m³ and calculated autonomy is ten hours, conditional on water quality and functioning delivery.

#### Guided practice

An economizer reduces compressor use but increases pump power. How should savings be assessed?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** Compare total relevant energy at equivalent load and environmental conditions, not compressor power alone.

#### Independent task

Environment: analytical

Compare dry, evaporative and hybrid heat rejection for a synthetic site.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- State water and energy boundaries.
- Calculate usable backup-water duration.
- Include climate, quality, mode transition and delivery dependencies.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0321 · single · calculation**

A tank holds 120 m³ with 20 m³ unavailable. At 10 m³/h demand, what autonomy is calculated?

Synthetic educational evidence; not field measurements.

Gross backup water: 120 m³
Unavailable/reserved: 20 m³
Required rate: 10 m³/h

1. 12 hours
2. 10 hours
3. 1000 hours
4. 2 hours

**Correct option(s):** 2

- Option 1: Incorrect. That uses gross rather than usable volume.
- Option 2: Correct. Usable volume is 100 m³ divided by demand.
- Option 3: Incorrect. That multiplies volume and rate.
- Option 4: Incorrect. That uses only the excluded volume.

**CDCP-Q0322 · single · mechanism**

What contributes to cooling-tower makeup demand?

1. Evaporation, blowdown and drift
2. Only rack count
3. Only the storage tank's height
4. Only IT data traffic

**Correct option(s):** 1

- Option 1: Correct. These remove water from the circulating system.
- Option 2: Incorrect. Count does not determine the full water balance.
- Option 3: Incorrect. Geometry alone is insufficient.
- Option 4: Incorrect. Traffic is not a direct water-loss term.

**CDCP-Q0323 · single · mechanism**

Why is free cooling not literally zero energy?

1. Fans, pumps and controls can still consume power
2. The word free defines the utility tariff
3. It always uses more energy than refrigeration
4. Environmental heat transfer requires no equipment ever

**Correct option(s):** 1

- Option 1: Correct. Reduced refrigeration does not eliminate auxiliaries.
- Option 2: Incorrect. It describes reduced mechanical cooling, not a guaranteed price.
- Option 3: Incorrect. That is not generally true.
- Option 4: Incorrect. Delivery systems are often needed.

**CDCP-Q0324 · single · mechanism**

What can make stored backup water unusable?

1. A verified pump path
2. Quality or delivery failure
3. A complete inventory record
4. A suitable treatment programme

**Correct option(s):** 2

- Option 1: Incorrect. That supports delivery.
- Option 2: Correct. Volume alone does not ensure usable supply.
- Option 3: Incorrect. Documentation supports management.
- Option 4: Incorrect. That supports quality.

**CDCP-Q0325 · single · mechanism**

What is a key dry-cooler constraint?

1. No fan energy in any design
2. No need for a fluid path
3. Unlimited capacity at every outdoor temperature
4. Ambient conditions and required approach temperature

**Correct option(s):** 4

- Option 1: Incorrect. Fans can be required.
- Option 2: Incorrect. Heat must reach the cooler.
- Option 3: Incorrect. The sink condition matters.
- Option 4: Correct. Heat rejection depends on the temperature difference.

**CDCP-Q0326 · single · mechanism**

Why include blowdown in water planning?

1. Blowdown creates unlimited makeup water
2. It eliminates every treatment requirement
3. It is the same as a server shutdown
4. Dissolved-solids control can require removing circulating water

**Correct option(s):** 4

- Option 1: Incorrect. It removes water that must be replaced.
- Option 2: Incorrect. Water chemistry still needs control.
- Option 3: Incorrect. This is a water-system process.
- Option 4: Correct. Evaporation alone does not describe the balance.

**CDCP-Q0327 · single · mechanism**

Which comparison fairly evaluates an economizer?

1. Compressor power alone
2. Only equipment purchase price
3. Total relevant energy at comparable load and conditions
4. Only the coldest hour of the year

**Correct option(s):** 3

- Option 1: Incorrect. Other loads can rise.
- Option 2: Incorrect. Operating performance matters.
- Option 3: Correct. Savings can shift among compressors, pumps and fans.
- Option 4: Incorrect. That may not represent annual behavior.

**CDCP-Q0328 · single · mechanism**

What distinguishes air-side from water-side economizer interfaces?

1. Both eliminate all humidity effects
2. They expose different air, water and contamination paths
3. Both always use identical filtration
4. Neither needs environmental limits

**Correct option(s):** 2

- Option 1: Incorrect. Air-side operation can directly affect moisture.
- Option 2: Correct. Their supporting controls differ.
- Option 3: Incorrect. The media and paths differ.
- Option 4: Incorrect. Equipment conditions still apply.

**CDCP-Q0329 · single · mechanism**

Why is seasonal storage capacity alone insufficient?

1. Storage always has zero losses
2. Every store can discharge infinitely fast
3. Energy quantity never matters
4. Delivery rate, temperature and losses also constrain useful output

**Correct option(s):** 4

- Option 1: Incorrect. Real systems lose energy.
- Option 2: Incorrect. Power limits exist.
- Option 3: Incorrect. It is one necessary dimension.
- Option 4: Correct. Stored energy must be usable when needed.

**CDCP-Q0330 · single · mechanism**

What should govern detailed subsurface thermal-storage design?

1. A generic rack heat spreadsheet alone
2. Qualified specialist design and applicable permissions
3. A marketing claim of seasonal storage
4. The number of cooling fans

**Correct option(s):** 2

- Option 1: Incorrect. That omits geological and construction constraints.
- Option 2: Correct. The integration course does not establish that authority.
- Option 3: Incorrect. The site needs actual engineering evidence.
- Option 4: Incorrect. That is not sufficient.

**CDCP-Q0331 · single · mechanism**

Why can lower PUE conflict with water objectives?

1. An energy-saving mode may consume more water
2. PUE directly includes all water use
3. Water has no local constraints
4. Every low-PUE site is automatically optimal

**Correct option(s):** 1

- Option 1: Correct. The metrics describe different resource impacts.
- Option 2: Incorrect. It is an energy ratio.
- Option 3: Incorrect. Availability and treatment vary.
- Option 4: Incorrect. Other requirements matter.

**CDCP-Q0332 · single · mechanism**

What should be tested after a water-supply interruption?

1. Required degraded operation, alarms and controlled restoration
2. Only the billing meter's serial number
3. Only the tank label
4. Only a pump command

**Correct option(s):** 1

- Option 1: Correct. The service response matters beyond detection.
- Option 2: Incorrect. That is not functional evidence.
- Option 3: Incorrect. It does not show delivery.
- Option 4: Incorrect. Actual flow is needed.

**CDCP-Q0333 · single · mechanism**

Why account for water quality in heat-exchanger performance?

1. Scaling and deposits can reduce heat transfer or flow
2. All treated water has identical properties forever
3. Higher mineral content always improves transfer
4. Chemistry affects only the water's appearance

**Correct option(s):** 1

- Option 1: Correct. The thermal path can degrade.
- Option 2: Incorrect. Condition changes and treatment must be maintained.
- Option 3: Incorrect. Deposits can add resistance.
- Option 4: Incorrect. It can affect materials and performance.

**CDCP-Q0334 · single · mechanism**

What can freeze protection affect in an economizer design?

1. The data-retention policy only
2. The rack's number of U-spaces
3. Only the user-interface language
4. Permitted operating modes, fluid choice and controls

**Correct option(s):** 4

- Option 1: Incorrect. That is unrelated.
- Option 2: Incorrect. That is mechanical layout.
- Option 3: Incorrect. It is a physical constraint.
- Option 4: Correct. Cold conditions can create physical damage risks.

**CDCP-Q0335 · single · mechanism**

Why record backup-water reserve policy?

1. Reserve is measured only in kW
2. Reserve automatically increases tank size
3. Some volume may be unavailable for ordinary consumption
4. Every liter is always available regardless of policy

**Correct option(s):** 3

- Option 1: Incorrect. Water reserve uses volume or mass.
- Option 2: Incorrect. It reallocates existing volume.
- Option 3: Correct. Autonomy must use the permitted usable quantity.
- Option 4: Incorrect. That can violate the continuity plan.

**CDCP-Q0336 · single · diagnosis**

A pump runs but the tower basin remains below required level. What should be checked?

Synthetic educational evidence; not field measurements.

Pump run indication: true
Basin level: below required threshold
Actual delivery: not verified

1. Ignore the alarm until the tank is empty
2. Increase IT load to test faster
3. Actual delivery, valves, level sensing and losses
4. Assume the level is correct because the pump runs

**Correct option(s):** 3

- Option 1: Incorrect. Response should follow defined limits.
- Option 2: Incorrect. That can worsen the shortage.
- Option 3: Correct. Run status alone does not prove the water balance.
- Option 4: Incorrect. That confuses command with effect.

**CDCP-Q0337 · single · mechanism**

What is the function of a hybrid heat-rejection arrangement?

1. Make climate data irrelevant
2. Guarantee zero resource consumption
3. Eliminate every maintenance task
4. Use different modes to balance energy, water and capacity

**Correct option(s):** 4

- Option 1: Incorrect. Mode suitability depends on climate.
- Option 2: Incorrect. Physical heat rejection still needs resources.
- Option 3: Incorrect. Both modes need service.
- Option 4: Correct. The appropriate mode depends on conditions.

**CDCP-Q0338 · single · mechanism**

Why verify mode transitions rather than only steady operation?

1. Stable endpoints guarantee every transition
2. Only annual averages matter
3. Switching can expose control, valve or supply dependencies
4. Transitions never affect temperature

**Correct option(s):** 3

- Option 1: Incorrect. The sequence can be wrong.
- Option 2: Incorrect. Short failures can harm service.
- Option 3: Correct. Transient states may fail even when endpoints work.
- Option 4: Incorrect. They can interrupt delivery.

**CDCP-Q0339 · single · mechanism**

Which evidence category describes a seasonal-storage feasibility model?

1. Analytical prediction under stated assumptions
2. Production operation evidence
3. Complete civil approval
4. An official facility certification

**Correct option(s):** 1

- Option 1: Correct. Physical site performance remains to be demonstrated.
- Option 2: Incorrect. No production observation is implied.
- Option 3: Incorrect. The model does not establish D1 authority.
- Option 4: Incorrect. It is one study artifact.

**CDCP-Q0340 · single · mechanism**

What belongs in a water-loss contingency plan?

1. Only the gross tank volume
2. Only a replenishment contract with no tested delivery assumptions
3. Demand, usable reserve, response timing and delivery dependencies
4. Only a low-water alarm name

**Correct option(s):** 3

- Option 1: Incorrect. Quality and delivery also matter.
- Option 2: Incorrect. A contract does not establish physical delivery during the required disruption.
- Option 3: Correct. The plan needs an executable operating envelope.
- Option 4: Incorrect. The response and duration are missing.

#### Recall

**A tank holds 120 m³ with 20 m³ unavailable. At 10 m³/h demand, what autonomy is calculated?**

10 hours Correct. Usable volume is 100 m³ divided by demand.

**What contributes to cooling-tower makeup demand?**

Evaporation, blowdown and drift Correct. These remove water from the circulating system.

**Why is free cooling not literally zero energy?**

Fans, pumps and controls can still consume power Correct. Reduced refrigeration does not eliminate auxiliaries.

**What can make stored backup water unusable?**

Quality or delivery failure Correct. Volume alone does not ensure usable supply.

**What is a key dry-cooler constraint?**

Ambient conditions and required approach temperature Correct. Heat rejection depends on the temperature difference.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## CDCP-M18 — Network-cabling architecture and scalability

### CDCP-L18 — Network-cabling architecture and scalability

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L17

A scalable cabling system provides stable distribution boundaries and clear administration as equipment changes. Identify entrance facilities, main and intermediate distribution, horizontal or zone distribution and equipment areas according to the applicable design standard. The purpose is predictable connectivity, manageable moves and controlled failure domains; terminology should be applied using the actual current standard rather than copied without context.

Compare top-of-rack and end-of-row designs across ports, oversubscription, cable count, pathway fill, power, cooling, spares and maintenance. Top-of-rack can shorten local copper runs while increasing the number of managed switches. End-of-row can consolidate switching but concentrates failures and increases row cabling. The right answer depends on workload and lifecycle requirements.

Backbone design must account for media type, fiber count, connector and cassette losses, polarity, transceiver reach and future migration. Spare fibers do not guarantee support for every future optic or lane arrangement. Plan patching and cross-connect space so that additions do not force undocumented direct connections or violate bend limits.

Resilience requires route analysis. Distinct ports, switches or carrier contracts can converge on the same tray, riser, entry duct or power source. Define shared-risk groups and verify as-built paths. Site-to-site connectivity also depends on carrier handoffs and operational ownership; a local patch-panel label does not prove the remote path.

Acceptance records should link each circuit to endpoints, route, media, test results and service owner. Verify the intended application and redundancy behavior after physical testing. Changes update both ends and the inventory, and abandoned-cable removal follows positive identification and approval. Scalability is therefore a maintained operating discipline as well as an initial design feature.

### Quantify topology tradeoffs before choosing a label
A rack has 32 server ports at 25 Gbit/s, an aggregate line rate of 800 Gbit/s. Four 100 Gbit/s uplinks provide 400 Gbit/s in the normal state, a 2:1 line-rate ratio. With one uplink unavailable, the ratio becomes 800/300=2.67:1. Whether this meets the service depends on actual traffic and required failure performance, not on a universal acceptable ratio.

A ToR arrangement can localize server cabling but distributes power, software and spare requirements across many switches. EoR can consolidate devices but may enlarge the failure domain and require more pathway capacity. Include replacement access, firmware maintenance and troubleshooting time in the comparison.

For physical resilience, mark each common tray, riser, entry duct and carrier handoff. Two logical paths can remain vulnerable to one cut. During acceptance, verify route records and correct service mapping as well as signal quality. Scalability is maintained by accurate records and controlled patching; unused fibers alone do not guarantee that the next optic, connector or lane arrangement is supported.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. Twelve racks each have 32 server links. A proposed ToR design uses one switch per rack; an EoR design concentrates the 384 links at two row positions.

**Reasoning:** The comparison must include 384 server connections, uplink capacity, cable lengths, pathway volume, switch failure domains and maintenance. Fewer switch locations do not automatically mean lower total lifecycle cost.

#### Guided practice

Two backbone trunks use separate patch panels but one tray. What resilience evidence is missing?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** Physical route independence. Separate terminations do not remove the shared tray failure.

#### Independent task

Environment: analytical

Compare two cabling architectures for a defined rack and port schedule.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Calculate ports and uplink assumptions.
- Trace shared routes and service handoffs.
- Include growth and administration requirements.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0341 · single · diagnosis**

Twelve racks each require 32 server links. How many server connections are needed?

Synthetic educational evidence; not field measurements.

Rack count: 12
Server links per rack: 32

1. 384
2. 44
3. 192
4. 1024

**Correct option(s):** 1

- Option 1: Correct. Multiply racks by links per rack.
- Option 2: Incorrect. Adding the values is incorrect.
- Option 3: Incorrect. That counts only half the requirement.
- Option 4: Incorrect. That squares the link count rather than using rack count.

**CDCP-Q0342 · single · mechanism**

Why can fewer switch locations fail to reduce total lifecycle cost?

1. EoR always has zero maintenance
2. ToR always has no backbone
3. Longer cabling, larger failure domains and service needs can offset consolidation
4. Switch count is the only cost driver

**Correct option(s):** 3

- Option 1: Incorrect. It still uses equipment.
- Option 2: Incorrect. Uplinks remain necessary.
- Option 3: Correct. The whole design must be compared.
- Option 4: Incorrect. Cabling and operations also matter.

**CDCP-Q0343 · single · mechanism**

What does spare fiber count not guarantee?

1. A possible expansion resource
2. A need for records
3. Compatibility with every future optic and lane mapping
4. The existence of unused strands

**Correct option(s):** 3

- Option 1: Incorrect. Spare strands can help.
- Option 2: Incorrect. Administration remains useful.
- Option 3: Correct. Media and application requirements can change.
- Option 4: Incorrect. That can be documented.

**CDCP-Q0344 · single · diagnosis**

Two trunks use different panels but one tray. Which failure remains shared?

Synthetic educational evidence; not field measurements.

Trunk A panel: PA
Trunk B panel: PB
Both physical routes: tray T1

1. Different asset identifiers
2. Damage to the tray route
3. Separate test files
4. One patch-panel port failure necessarily

**Correct option(s):** 2

- Option 1: Incorrect. Those do not define a common physical event.
- Option 2: Correct. Termination separation does not create route independence.
- Option 3: Incorrect. Records are not a shared cable path.
- Option 4: Incorrect. That may affect only one circuit.

**CDCP-Q0345 · single · mechanism**

What is oversubscription in this context?

1. More fibers than labels
2. Every uplink is unused
3. Aggregate access capacity exceeds available uplink capacity
4. A cable longer than its route drawing

**Correct option(s):** 3

- Option 1: Incorrect. That is an administration mismatch.
- Option 2: Incorrect. That is not the definition.
- Option 3: Correct. Workload assumptions determine whether it is suitable.
- Option 4: Incorrect. That is a documentation issue.

**CDCP-Q0346 · single · mechanism**

Why define distribution boundaries?

1. They organize patching, ownership and future changes
2. Every boundary must have identical equipment
3. Boundaries eliminate all signal loss
4. Boundaries automatically encrypt traffic

**Correct option(s):** 1

- Option 1: Correct. Stable structure reduces ad hoc connections.
- Option 2: Incorrect. Roles can differ.
- Option 3: Incorrect. Connectors and cable still attenuate.
- Option 4: Incorrect. Physical organization is not encryption.

**CDCP-Q0347 · single · mechanism**

Which resource can block a cabling expansion despite spare ports?

1. A verified loss budget
2. A complete service-owner record
3. A correct circuit label
4. Pathway or cross-connect capacity

**Correct option(s):** 4

- Option 1: Incorrect. That supports the optical path.
- Option 2: Incorrect. That supports governance.
- Option 3: Incorrect. That supports expansion.
- Option 4: Correct. Connectivity requires a supported physical route.

**CDCP-Q0348 · single · mechanism**

Why compare ToR failure domains with EoR?

1. Topology names alone prove resilience
2. A switch outage can affect a different set of servers
3. Failure domain is only a billing term
4. Both always affect exactly one server

**Correct option(s):** 2

- Option 1: Incorrect. Actual dependencies matter.
- Option 2: Correct. Consolidation changes blast radius.
- Option 3: Incorrect. It describes affected functions.
- Option 4: Incorrect. Many servers can share a switch.

**CDCP-Q0349 · single · mechanism**

What should a site-to-site circuit handoff define?

1. Only the commercial service name
2. Only the invoice currency
3. Only the local rack number
4. Media, service characteristics, responsibility and acceptance boundary

**Correct option(s):** 4

- Option 1: Incorrect. The actual physical and operational interface needs specification.
- Option 2: Incorrect. That is commercial rather than technical.
- Option 3: Incorrect. The end-to-end boundary is broader.
- Option 4: Correct. Both parties need a clear interface.

**CDCP-Q0350 · single · mechanism**

Why retain cassette and connector information in an optical design?

1. Connector count determines every IP route
2. Only fiber length matters
3. Passive parts never affect optics
4. Each contributes loss and lane mapping

**Correct option(s):** 4

- Option 1: Incorrect. Logical routing is separate.
- Option 2: Incorrect. Connections and compatibility also matter.
- Option 3: Incorrect. They can add attenuation or mapping changes.
- Option 4: Correct. The assembled channel must match the application.

**CDCP-Q0351 · single · mechanism**

What is a shared-risk group useful for?

1. Grouping only by logical VLAN
2. Guaranteeing no failures inside the group
3. Identifying paths exposed to one common event
4. Replacing route verification

**Correct option(s):** 3

- Option 1: Incorrect. Logical separation does not identify shared trenches, power or physical exposure.
- Option 2: Incorrect. It identifies common risk rather than eliminating it.
- Option 3: Correct. It supports resilience decisions.
- Option 4: Incorrect. The group must be grounded in real paths.

**CDCP-Q0352 · single · mechanism**

Why include management overhead in topology comparison?

1. Managed switches require no lifecycle work
2. More distributed devices need configuration, monitoring and support
3. Only cable length matters
4. Automation removes all ownership requirements

**Correct option(s):** 2

- Option 1: Incorrect. They need updates, backups and diagnosis.
- Option 2: Correct. Operational burden is part of suitability.
- Option 3: Incorrect. Devices and processes also matter.
- Option 4: Incorrect. Automation itself needs control.

**CDCP-Q0353 · single · mechanism**

A new link passes optical testing but connects the wrong service. What acceptance layer failed?

1. Optical attenuation necessarily
2. Endpoint and application mapping
3. Rack mechanical capacity
4. Fiber cleanliness necessarily

**Correct option(s):** 2

- Option 1: Incorrect. The physical test passed within scope.
- Option 2: Correct. Physical quality does not establish intended connectivity.
- Option 3: Incorrect. That is unrelated.
- Option 4: Incorrect. It may be clean.

**CDCP-Q0354 · single · mechanism**

Why plan cross-connect space for growth?

1. Every future connection can be left loose
2. Growth always uses the same connector forever
3. Future additions need accessible, documented termination capacity
4. Cross-connect space determines cooling kW

**Correct option(s):** 3

- Option 1: Incorrect. That undermines maintainability.
- Option 2: Incorrect. Interfaces can change.
- Option 3: Correct. Unused fiber without termination space may be difficult to use.
- Option 4: Incorrect. It is a connectivity resource.

**CDCP-Q0355 · single · mechanism**

What should happen after a patching change?

1. Update only the requester's email
2. Update both endpoints and verify the intended service
3. Assume link light proves correct service
4. Delete the original path history

**Correct option(s):** 2

- Option 1: Incorrect. Physical records remain wrong.
- Option 2: Correct. Records and function must match.
- Option 3: Incorrect. It proves a narrower condition.
- Option 4: Incorrect. Traceability can be useful.

**CDCP-Q0356 · single · mechanism**

Why compare uplink bandwidth against workload rather than only port count?

1. Port count fully determines traffic
2. Every server always transmits at zero rate
3. Not every port generates the same traffic pattern
4. Uplink capacity is unrelated to performance

**Correct option(s):** 3

- Option 1: Incorrect. Workloads vary.
- Option 2: Incorrect. That is not useful planning.
- Option 3: Correct. Capacity must match aggregate demand and required peaks.
- Option 4: Incorrect. It can be a bottleneck.

**CDCP-Q0357 · single · mechanism**

What does positive identification mean before cable removal?

1. Establish both endpoints, owner and service status
2. Removing every link that is absent from a stale inventory
3. Assuming unlabeled means unused
4. Pulling the cable to see who complains

**Correct option(s):** 1

- Option 1: Correct. Appearance alone is insufficient.
- Option 2: Incorrect. Undocumented links may still carry required service.
- Option 3: Incorrect. Missing labels do not prove nonuse.
- Option 4: Incorrect. That is uncontrolled discovery.

**CDCP-Q0358 · single · mechanism**

Why inspect actual routes during acceptance?

1. Installed paths can differ from drawings
2. Drawings always update themselves
3. Only the shortest route is acceptable
4. Route differences never matter if traffic works

**Correct option(s):** 1

- Option 1: Correct. Resilience depends on effective state.
- Option 2: Incorrect. They require controlled updates.
- Option 3: Incorrect. Requirements include diversity and access.
- Option 4: Incorrect. Common-cause risk can remain hidden.

**CDCP-Q0359 · single · mechanism**

Which artifact best supports scalable operations?

1. A maintained circuit inventory tied to tests and routes
2. A vendor catalog alone
3. A one-time rendering without identifiers
4. A list of purchased cable reels

**Correct option(s):** 1

- Option 1: Correct. Growth needs reliable knowledge of the installed system.
- Option 2: Incorrect. It does not show the site.
- Option 3: Incorrect. It is difficult to use for changes.
- Option 4: Incorrect. It does not identify installed circuits.

**CDCP-Q0360 · single · mechanism**

What should a topology recommendation state?

1. Assumptions, constraints, tradeoffs and acceptance evidence
2. Only that another site uses it
3. A guarantee that no future change is needed
4. Only that it is modern

**Correct option(s):** 1

- Option 1: Correct. The choice should be justified for the actual service.
- Option 2: Incorrect. Context can differ.
- Option 3: Incorrect. Growth and technology can alter requirements.
- Option 4: Incorrect. Novelty is not suitability.

#### Recall

**Twelve racks each require 32 server links. How many server connections are needed?**

384 Correct. Multiply racks by links per rack.

**Why can fewer switch locations fail to reduce total lifecycle cost?**

Longer cabling, larger failure domains and service needs can offset consolidation Correct. The whole design must be compared.

**What does spare fiber count not guarantee?**

Compatibility with every future optic and lane mapping Correct. Media and application requirements can change.

**Two trunks use different panels but one tray. Which failure remains shared?**

Damage to the tray route Correct. Termination separation does not create route independence.

**What is oversubscription in this context?**

Aggregate access capacity exceeds available uplink capacity Correct. Workload assumptions determine whether it is suitable.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## CDCP-M19 — Copper and optical testing as an acceptance chain

### CDCP-L19 — Copper and optical testing as an acceptance chain

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L18

Physical cabling acceptance is layered. First verify identity and installation: correct media, connector, route, bend limits, strain relief, fire interfaces and labels. Then test transmission properties against the intended standard and application. Finally verify the correct service path under representative traffic and failure conditions. Passing one layer does not prove all others.

For copper, wiremap checks connectivity and pair relationships; certification also evaluates performance such as insertion loss, return loss and crosstalk. The selected permanent-link or channel boundary must match the report. Patch cords added later can change the channel. PoE adds electrical loading and thermal considerations beyond data continuity.

For fiber, verify type, wavelength, polarity and clean end faces. The optical budget uses minimum transmitter output, receiver sensitivity, path loss and required margin, while receiver overload is checked separately. OTDR traces help locate events, and end-to-end loss testing measures attenuation under a defined reference. Launch and receive arrangements, wavelengths and instrument limitations affect interpretation.

A useful test report records unique path identity, equipment, calibration status, limit set, reference method, date, raw results and disposition. A pass screenshot with no endpoints cannot be tied reliably to the installed service. Failed results should remain in history with corrective action and successful retest rather than being silently overwritten.

Application acceptance checks what the circuit must deliver: correct endpoint, expected rate, error behavior, redundancy and management visibility. A link that negotiates at a lower rate can mask inadequate performance for the specified rate. A link that passes all physical tests but lands in the wrong security zone is still an unacceptable installation.

### Reconcile three different cabling results
A copper path has a passing wiremap, a failing certification margin and a working application at a lower negotiated rate. None of those results is inherently contradictory. Wiremap proves a limited connectivity property, certification tests the selected transmission limits, and the application may have fallen back to a less demanding rate. Acceptance must use the required rate and correct test boundary.

For fiber, a low-loss result can coexist with wrong polarity. An OTDR can locate a connector event while an end-to-end loss test quantifies the complete path. Preserve wavelength, reference setup, launch/receive arrangement and raw results so another reviewer can interpret the evidence.

After correction, retest the changed path and verify the intended service. Keep the failed result with the corrective action rather than overwriting history. A physically healthy link connected to the wrong security zone remains a failed installation. The final dossier should connect identity, installation, transmission and application behavior, each with its own evidence.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. An optic launches at least −2 dBm, receiver sensitivity is −9 dBm, path loss is 5 dB and required margin is 3 dB.

**Reasoning:** The available budget is 7 dB, while path plus margin needs 8 dB. The design is short by 1 dB even though nominal received power might exceed sensitivity without the required reserve.

#### Guided practice

A copper permanent link passes, but a replacement patch cord causes errors. Which evidence should be refreshed?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** The assembled channel and required application behavior after the component change.

#### Independent task

Environment: analytical

Build a test dossier for one copper and one fiber circuit.

**Packaged starter material**

- course_labs/CDCP/README.md
- course_labs/CDCP/proposal.json
- course_labs/CDCP/answers-template.json

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Define permanent-link or channel boundaries.
- Retain optical sensitivity, overload and polarity checks.
- Verify correct service and preserve failed/retest history.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0361 · single · diagnosis**

Minimum launch is −2 dBm and sensitivity −9 dBm. What loss budget is available?

Synthetic educational evidence; not field measurements.

Minimum launch: −2 dBm
Receiver sensitivity: −9 dBm

1. 7 dB
2. −11 dB
3. 2 dB
4. 11 dB

**Correct option(s):** 1

- Option 1: Correct. Subtract receiver sensitivity from minimum launch.
- Option 2: Incorrect. Adding signed powers is not the budget.
- Option 3: Incorrect. That ignores sensitivity.
- Option 4: Incorrect. That adds magnitudes incorrectly.

**CDCP-Q0362 · single · diagnosis**

A 7 dB budget must cover 5 dB path loss and 3 dB margin. What is the result?

Synthetic educational evidence; not field measurements.

Available budget: 7 dB
Path loss: 5 dB
Required margin: 3 dB

1. A 2 dB surplus
2. A 1 dB shortfall
3. A 1 dB surplus
4. Exactly compliant

**Correct option(s):** 2

- Option 1: Incorrect. That ignores the required margin.
- Option 2: Correct. Eight dB is required.
- Option 3: Incorrect. The sign is reversed.
- Option 4: Incorrect. The required total exceeds the budget.

**CDCP-Q0363 · single · mechanism**

Why can a lower negotiated link rate mask an installation defect?

1. All rates use identical channel requirements
2. A lower rate proves the cable is disconnected
3. Negotiation always selects the specified maximum
4. The lower-rate application may tolerate a channel that fails the specified rate

**Correct option(s):** 4

- Option 1: Incorrect. They can differ.
- Option 2: Incorrect. The link is operating, but below requirement.
- Option 3: Incorrect. It may fall back.
- Option 4: Correct. Connectivity alone is not target-rate acceptance.

**CDCP-Q0364 · single · mechanism**

What should a cable-test report identify?

1. Only the installer's initials
2. Only a green pass icon
3. Only the tester brand
4. Exact endpoints, path and selected test boundary

**Correct option(s):** 4

- Option 1: Incorrect. Identity of the circuit remains missing.
- Option 2: Incorrect. The evidence lacks scope.
- Option 3: Incorrect. That does not identify the path.
- Option 4: Correct. The result must map to the installed circuit.

**CDCP-Q0365 · single · mechanism**

What does a copper wiremap pass fail to establish?

1. That conductors have some end-to-end relationship
2. All required transmission-performance parameters
3. That pair mapping can matter
4. That a cable exists

**Correct option(s):** 2

- Option 1: Incorrect. That is what wiremap assesses.
- Option 2: Correct. Continuity is narrower than certification.
- Option 3: Incorrect. It is central to the test.
- Option 4: Incorrect. The test uses one.

**CDCP-Q0366 · single · mechanism**

Why inspect-clean-inspect fiber connectors?

1. Every dust cap certifies cleanliness
2. Inspection increases optical power
3. Cleaning corrects every polarity error
4. Cleaning may not remove every contaminant and can introduce residue

**Correct option(s):** 4

- Option 1: Incorrect. Caps can be contaminated.
- Option 2: Incorrect. It observes the surface.
- Option 3: Incorrect. Mapping is a separate issue.
- Option 4: Correct. The result needs verification.

**CDCP-Q0367 · single · mechanism**

What should be checked independently of receiver sensitivity?

1. Only the transmitter's brand
2. Only the rack U count
3. Receiver maximum input or overload limit
4. Only whether the connector fits mechanically

**Correct option(s):** 3

- Option 1: Incorrect. The actual receiver rating matters.
- Option 2: Incorrect. That is mechanical.
- Option 3: Correct. Too much power can also be unsuitable.
- Option 4: Incorrect. Mechanical fit does not establish the receiver upper optical-power limit.

**CDCP-Q0368 · single · mechanism**

Why retain an original failed test after repair?

1. Only passing tests are real measurements
2. History has no operational value
3. It preserves diagnosis, corrective action and traceability
4. Failed evidence automatically invalidates every later pass

**Correct option(s):** 3

- Option 1: Incorrect. Failures are also evidence.
- Option 2: Incorrect. Recurring patterns can be useful.
- Option 3: Correct. History explains how acceptance was achieved.
- Option 4: Incorrect. A verified correction can resolve the issue.

**CDCP-Q0369 · single · mechanism**

What does OTDR event distance help with?

1. Assigning an IP route
2. Locating a reflection or loss feature along the fiber
3. Measuring every application transaction
4. Proving end-face cleanliness at all connectors

**Correct option(s):** 2

- Option 1: Incorrect. That is a logical function.
- Option 2: Correct. It supports physical diagnosis.
- Option 3: Incorrect. The trace is optical.
- Option 4: Incorrect. Interpretation and inspection remain needed.

**CDCP-Q0370 · single · mechanism**

Why record the optical reference method?

1. Loss results depend on the defined measurement setup
2. Reference setting replaces calibration
3. Every reference method yields identical boundaries
4. The method changes only the file name

**Correct option(s):** 1

- Option 1: Correct. Comparability requires knowing the reference.
- Option 2: Incorrect. Both matter.
- Option 3: Incorrect. Methods can include or exclude different connections.
- Option 4: Incorrect. It affects the measured result.

**CDCP-Q0371 · single · diagnosis**

A link passes physical tests but lands in the wrong security zone. What is the result?

Synthetic educational evidence; not field measurements.

Physical transmission: passes
Actual destination: wrong security zone

1. It passes because photons arrive
2. Accept it physically and leave the security-zone mismatch unresolved
3. All physical tests must be false
4. Installation acceptance fails the intended service mapping

**Correct option(s):** 4

- Option 1: Incorrect. The required function includes correct destination.
- Option 2: Incorrect. The intended service boundary is part of installation acceptance.
- Option 3: Incorrect. They can be valid within their scope.
- Option 4: Correct. Physical quality is not correct authorization boundary.

**CDCP-Q0372 · single · mechanism**

What should follow a patch-cord substitution?

1. Delete the path identifier
2. Replace the entire building cabling automatically
3. Verify the changed channel and application
4. Assume the original permanent-link report covers every cord

**Correct option(s):** 3

- Option 1: Incorrect. Identity should remain traceable.
- Option 2: Incorrect. The scope may be local.
- Option 3: Correct. The assembled path has changed.
- Option 4: Incorrect. It does not.

**CDCP-Q0373 · single · mechanism**

Why include PoE conditions in copper acceptance?

1. PoE changes fiber polarity
2. PoE carries no current
3. Power delivery and bundle heating can constrain use
4. A data pass guarantees every power class

**Correct option(s):** 3

- Option 1: Incorrect. It is a copper power mechanism.
- Option 2: Incorrect. It supplies electrical power.
- Option 3: Correct. Data performance alone is incomplete.
- Option 4: Incorrect. Additional ratings apply.

**CDCP-Q0374 · single · mechanism**

What can an incorrect limit set do?

1. Eliminate all uncertainty
2. Produce a pass that does not match the required application
3. Automatically improve the cable
4. Make endpoints unnecessary

**Correct option(s):** 2

- Option 1: Incorrect. Measurement conditions still matter.
- Option 2: Correct. Test configuration is part of validity.
- Option 3: Incorrect. Changing limits changes judgment, not the physical path.
- Option 4: Incorrect. Identity remains required.

**CDCP-Q0375 · single · mechanism**

Why verify optical polarity separately from loss?

1. Polarity is corrected by any dust cap
2. A low-loss path can connect the wrong transmit/receive lanes
3. Polarity only affects electrical mains
4. Good loss always proves lane order

**Correct option(s):** 2

- Option 1: Incorrect. Caps are protective, not mapping devices.
- Option 2: Correct. Attenuation and mapping are different properties.
- Option 3: Incorrect. It also describes optical lane relationships.
- Option 4: Incorrect. It does not.

**CDCP-Q0376 · single · mechanism**

What should raw test data support?

1. Removal of all test context
2. Automatic approval of every future change
3. A guarantee of lifetime reliability
4. Independent review of the reported pass or failure

**Correct option(s):** 4

- Option 1: Incorrect. Context is essential.
- Option 2: Incorrect. New changes can alter the path.
- Option 3: Incorrect. Tests cover specified conditions and time.
- Option 4: Correct. Summaries should be auditable.

**CDCP-Q0377 · single · mechanism**

Why check installation bend limits even if a link currently works?

1. Bend limits are only decorative guidance
2. Tighter bends always improve optical coupling
3. Mechanical stress can affect margin and future integrity
4. A working link proves no physical stress

**Correct option(s):** 3

- Option 1: Incorrect. They are product constraints.
- Option 2: Incorrect. They can increase loss or damage.
- Option 3: Correct. Current operation does not waive installation requirements.
- Option 4: Incorrect. It does not.

**CDCP-Q0378 · single · mechanism**

Which test best addresses correct application delivery?

1. Representative traffic and required transaction behavior on the intended path
2. Only wiremap
3. Only cable length
4. Only optical power

**Correct option(s):** 1

- Option 1: Correct. It goes beyond physical link status.
- Option 2: Incorrect. That checks conductor relationships.
- Option 3: Incorrect. Length alone does not establish service.
- Option 4: Incorrect. That is a physical-layer measure.

**CDCP-Q0379 · single · mechanism**

What is a proper interpretation of an unlabelled pass screenshot?

1. Guaranteed fabrication
2. Proof that every cable passes
3. Insufficient traceability to a specific installed path
4. Complete facility acceptance

**Correct option(s):** 3

- Option 1: Incorrect. Lack of traceability does not prove it was invented.
- Option 2: Incorrect. One unidentified image cannot establish that.
- Option 3: Correct. The result may be real but cannot support a precise claim.
- Option 4: Incorrect. Its scope is unknown.

**CDCP-Q0380 · single · mechanism**

Why test redundancy after physical circuit acceptance?

1. Physical tests are useless
2. The alternate path and service failover may still be incorrect
3. Different port labels prove independent operation
4. Failover requires no application observation

**Correct option(s):** 2

- Option 1: Incorrect. They establish necessary properties.
- Option 2: Correct. Two healthy links do not guarantee required behavior.
- Option 3: Incorrect. Topology and behavior need evidence.
- Option 4: Incorrect. Service continuity must be measured.

#### Recall

**Minimum launch is −2 dBm and sensitivity −9 dBm. What loss budget is available?**

7 dB Correct. Subtract receiver sensitivity from minimum launch.

**A 7 dB budget must cover 5 dB path loss and 3 dB margin. What is the result?**

A 1 dB shortfall Correct. Eight dB is required.

**Why can a lower negotiated link rate mask an installation defect?**

The lower-rate application may tolerate a channel that fails the specified rate Correct. Connectivity alone is not target-rate acceptance.

**What should a cable-test report identify?**

Exact endpoints, path and selected test boundary Correct. The result must map to the installed circuit.

**What does a copper wiremap pass fail to establish?**

All required transmission-performance parameters Correct. Continuity is narrower than certification.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## CDCP-M20 — Fire prevention, detection and suppression interfaces

### CDCP-L20 — Fire prevention, detection and suppression interfaces

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L19

A facility fire strategy combines ignition prevention, detection, compartmentation, suppression, evacuation and recovery. Data-center review focuses on how these functions interact with racks, cabling, containment, ventilation, power and access. The detailed fire-engineering design and authority approvals remain specialist responsibilities; interface literacy does not confer permission to alter release logic or rated construction.

Prevention includes managing combustible storage, electrical defects, hot work and maintenance housekeeping. Detection must suit the hazard and air movement. Point smoke, air-sampling and heat devices observe different phenomena and have different placement and test needs. A staged alarm may trigger investigation before a later confirmed condition triggers other actions according to the approved cause-and-effect matrix.

Water-based and gas-based systems control fire through different mechanisms and installation requirements. Preaction logic must be understood for the actual arrangement rather than treated as a guarantee against all water release. Gaseous protection depends on agent design, distribution, protected volume and retention; changes to openings or containment can affect the accepted enclosure. Pressure-relief, occupant safety and emergency response need coordinated review.

Testing is planned around consequence. A simulated input can verify logic and notification while leaving physical smoke transport or agent distribution untested. Impairments need authorization, scope, compensating measures, duration and restoration. A detector in trouble or a closed valve can reduce readiness while the IT service remains normal.

Acceptance should trace each stimulus to panel indication, notification, interlocks and required action, then restore the approved normal state. After an actual event, re-entry and restart follow authorized safety assessment, evidence preservation, cause correction and system rearming. Clearing an alarm is not the same as restoring safe and trusted operation.

### Review a row modification through the fire strategy
A new containment roof changes air movement, adds an obstruction and alters the volume above the racks. Before acceptance, identify affected smoke-sampling paths, detector locations, nozzle discharge patterns, lighting and egress. A thermal pass does not approve those interfaces. The fire specialist and authority-controlled design determine the required revision and tests.

Build a matrix with input condition, expected panel state, notifications, interlocks and restoration. Test one output at a time where the approved procedure requires isolation to avoid unintended discharge. Record what was simulated. An injected signal can demonstrate logic but not smoke transport or agent concentration.

During the work, track impairments and compensating measures with an expiry and responsible owner. At handback, verify the actual valves, zones, interlocks and alarms are in their approved normal state. After a real event, do not use an alarm-clear button as the recovery criterion. Re-entry, physical safety, cause correction and rearming require authorized assessment.

### Classify the hazard before interpreting an extinguisher label
Fire classification identifies the burning material and, in some schemes, whether energized electrical equipment is involved. Common distinctions include ordinary solid combustibles, flammable liquids, gases, combustible metals and cooking oils or fats. The class letters and grouping are jurisdiction-specific; do not transfer a letter from one national scheme into another without the applicable approved reference.

The physical mechanism matters more than memorizing one unqualified letter. Water-based agents primarily remove heat, foam can separate suitable liquid fuels from air, some powders interrupt combustion processes, and gaseous agents act through their specified concentration and mechanism. Suitability depends on the actual fuel, energized equipment, people, enclosure and approved product. An agent that controls one hazard can create another, including electrical conduction, oxygen displacement, poor visibility or residue damage.

Portable equipment is therefore selected and located through the site's approved fire-risk and training arrangements. Staff must know whether their role is evacuation, notification or trained initial response; recognizing an extinguisher label is not permission to fight a fire. Preserve an escape route and follow the authorized emergency command. Detailed selection, spacing, discharge design and maintenance remain governed by the applicable authority and qualified specialists.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A containment modification improves rack temperatures but blocks a detector sampling path and alters gaseous-protection volume assumptions.

**Reasoning:** The thermal improvement cannot be accepted as a complete facility change until the fire interfaces are reviewed and the affected functions revalidated.

#### Guided practice

A fire panel test reaches the duty phone but the ventilation interlock is not checked. What remains unverified?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** The specified ventilation response in the cause-and-effect chain. Notification success does not prove every output.

#### Independent task

Environment: analytical

Prepare a fire-interface acceptance matrix for a synthetic rack-row change.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Identify detector, suppression, airflow, access and power interfaces.
- State which tests are simulated and which physical effects remain external.
- Include impairment and restoration controls.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0381 · single · diagnosis**

A containment change blocks a sampling path. What requirement is affected?

Synthetic educational evidence; not field measurements.

New containment: thermal improvement
Detector sampling path: obstructed

1. Only cooling efficiency
2. Every network route necessarily
3. Detection coverage and transport
4. Only the rack's serial number

**Correct option(s):** 3

- Option 1: Incorrect. The change has fire interfaces too.
- Option 2: Incorrect. That cannot be inferred.
- Option 3: Correct. The detector may no longer receive representative air.
- Option 4: Incorrect. Identity is not the issue.

**CDCP-Q0382 · single · mechanism**

Why does normal IT operation not prove fire readiness?

1. Protection impairments can remain latent until an event
2. Every impairment shuts down all servers
3. Fire systems are unnecessary during normal service
4. Uptime is the same as life-safety acceptance

**Correct option(s):** 1

- Option 1: Correct. The service can run while a detector or valve is unavailable.
- Option 2: Incorrect. Many do not.
- Option 3: Incorrect. They must remain ready.
- Option 4: Incorrect. The functions differ.

**CDCP-Q0383 · single · mechanism**

What should govern staged detection responses?

1. A generic assumption that every alarm discharges agent
2. The number of occupied racks alone
3. The approved cause-and-effect matrix
4. The operator's preferred shortcut

**Correct option(s):** 3

- Option 1: Incorrect. That may conflict with the design.
- Option 2: Incorrect. Hazard and system logic are broader.
- Option 3: Correct. Different inputs and stages have defined outputs.
- Option 4: Incorrect. Authority and design control the response.

**CDCP-Q0384 · single · mechanism**

Why review new enclosure openings for gaseous protection?

1. A fire panel automatically seals gaps
2. Cylinder mass alone guarantees performance
3. Openings always improve agent concentration
4. Leakage and protected-volume assumptions can change

**Correct option(s):** 4

- Option 1: Incorrect. It does not.
- Option 2: Incorrect. Distribution and retention also matter.
- Option 3: Incorrect. They can allow loss.
- Option 4: Correct. Retention depends on the actual boundary.

**CDCP-Q0385 · single · mechanism**

What does a successful notification test not prove?

1. That records are useful
2. That a message reached the tested recipient
3. That notification can be tested
4. All physical detection and suppression outputs

**Correct option(s):** 4

- Option 1: Incorrect. They remain useful.
- Option 2: Incorrect. That is what was observed.
- Option 3: Incorrect. It was.
- Option 4: Correct. It covers a selected part of the chain.

**CDCP-Q0386 · single · mechanism**

Why manage hot work through a controlled process?

1. A permit removes the need for precautions
2. Hot work never affects technical rooms
3. It introduces ignition sources and interface risks
4. Only the contractor's tools matter

**Correct option(s):** 3

- Option 1: Incorrect. Execution controls remain necessary.
- Option 2: Incorrect. Sparks and heat can matter.
- Option 3: Correct. The work changes the hazard state.
- Option 4: Incorrect. Location and nearby systems also matter.

**CDCP-Q0387 · single · mechanism**

What should a temporary fire-system impairment include?

1. Permanent deletion of the zone
2. Only a silent dashboard change
3. A claim of unchanged readiness
4. Authority, affected scope, compensating controls, duration and restoration

**Correct option(s):** 4

- Option 1: Incorrect. Temporary work does not justify permanent loss.
- Option 2: Incorrect. That hides the state.
- Option 3: Incorrect. That would misstate the impairment.
- Option 4: Correct. The reduced protection must be managed.

**CDCP-Q0388 · single · mechanism**

Why distinguish point and air-sampling detection?

1. Air sampling needs no pipes or flow
2. Point detectors replace every fire strategy element
3. Both always observe the same volume instantly
4. Their sensing and transport arrangements differ

**Correct option(s):** 4

- Option 1: Incorrect. Its delivery path matters.
- Option 2: Incorrect. Detection is one layer.
- Option 3: Incorrect. Transport times can differ.
- Option 4: Correct. Placement and test methods must match.

**CDCP-Q0389 · single · mechanism**

A closed suppression supply valve is discovered. What is the proper interpretation?

1. Potential suppression impairment requiring defined response
2. A purely cosmetic issue
3. An automatic reason to open it without authorization
4. Proof that a fire is present

**Correct option(s):** 1

- Option 1: Correct. Normal IT load does not make it harmless.
- Option 2: Incorrect. It can block agent delivery.
- Option 3: Incorrect. Restoration must follow the approved procedure.
- Option 4: Incorrect. The valve state is not itself combustion.

**CDCP-Q0390 · single · mechanism**

Why include cable firestopping in a change review?

1. Penetrations can compromise compartmentation
2. More cable always improves sealing
3. Cable transmission tests prove fire resistance
4. Firestops are unrelated to data centers

**Correct option(s):** 1

- Option 1: Correct. Cabling affects the barrier boundary.
- Option 2: Incorrect. Openings need approved treatment.
- Option 3: Incorrect. They measure different properties.
- Option 4: Incorrect. Compartment integrity affects the facility.

**CDCP-Q0391 · single · mechanism**

What should follow a real suppression event before restart?

1. Deleting all event logs
2. Authorized safety assessment, cause correction and rearming
3. Only clearing the display
4. Immediate unrestricted re-entry

**Correct option(s):** 2

- Option 1: Incorrect. They support investigation and recovery.
- Option 2: Correct. Physical and protection states must be restored.
- Option 3: Incorrect. The underlying condition may remain.
- Option 4: Incorrect. Atmosphere and hazards need assessment.

**CDCP-Q0392 · single · mechanism**

Why coordinate ventilation interlocks?

1. Stopping fans guarantees unlimited thermal time
2. Every fan should always run regardless of design
3. Airflow can affect smoke movement, agent retention and equipment heat
4. Ventilation has no fire role

**Correct option(s):** 3

- Option 1: Incorrect. IT heat still accumulates.
- Option 2: Incorrect. The approved strategy determines action.
- Option 3: Correct. The response crosses system boundaries.
- Option 4: Incorrect. It can materially affect the event.

**CDCP-Q0393 · single · mechanism**

What does a simulated detector input leave untested?

1. All panel logic necessarily
2. The ability to record a timestamp
3. Notification delivery necessarily
4. Physical smoke transport and sensor response

**Correct option(s):** 4

- Option 1: Incorrect. It can test selected logic.
- Option 2: Incorrect. That can be tested.
- Option 3: Incorrect. That can be observed.
- Option 4: Correct. It enters downstream of those mechanisms.

**CDCP-Q0394 · single · mechanism**

Which specialist boundary remains external to this course?

1. Mapping service dependencies
2. Detailed fire-system design and authority approval
3. Recording test results
4. Identifying affected rack equipment

**Correct option(s):** 2

- Option 1: Incorrect. That is core integration work.
- Option 2: Correct. The programme manages interfaces and evidence.
- Option 3: Incorrect. That is within the evidence task.
- Option 4: Incorrect. That is part of integration work.

**CDCP-Q0395 · single · mechanism**

Why keep escape routes clear during infrastructure work?

1. Clear routes only matter during scheduled drills
2. Occupant egress remains required during maintenance
3. Redundant UPS systems replace escape routes
4. Only visitors need exits

**Correct option(s):** 2

- Option 1: Incorrect. Emergencies can occur at any time.
- Option 2: Correct. Work does not suspend life safety.
- Option 3: Incorrect. They do not.
- Option 4: Incorrect. All occupants can need them.

**CDCP-Q0396 · single · mechanism**

What can a fire-panel trouble signal represent?

1. Guaranteed successful suppression
2. An event that should always be ignored
3. A complete building evacuation in every case
4. A fault affecting readiness rather than confirmed fire

**Correct option(s):** 4

- Option 1: Incorrect. Trouble can indicate reduced capability.
- Option 2: Incorrect. The system may be impaired.
- Option 3: Incorrect. The approved response depends on meaning.
- Option 4: Correct. It requires interpretation and response.

**CDCP-Q0397 · single · mechanism**

Why retain restoration evidence after a test?

1. A test automatically resets every device
2. The test ends when one alarm appears
3. Records are needed only after failure
4. Test isolations or overrides can remain active

**Correct option(s):** 4

- Option 1: Incorrect. That cannot be assumed.
- Option 2: Incorrect. Response and restoration remain.
- Option 3: Incorrect. Successful restoration also needs evidence.
- Option 4: Correct. The protection must return to its approved state.

**CDCP-Q0398 · single · mechanism**

What should an integrated fire test matrix show?

1. Only a contractor signature
2. Only an evacuation poster
3. Input, expected outputs, observed results and final state
4. Only a list of device prices

**Correct option(s):** 3

- Option 1: Incorrect. The functional results remain needed.
- Option 2: Incorrect. That is one supporting element.
- Option 3: Correct. It connects cause to effect and restoration.
- Option 4: Incorrect. That does not define behavior.

**CDCP-Q0399 · single · diagnosis**

A technician transfers a fire-class letter from a foreign training chart into the site plan without checking the local scheme. What is the defect?

1. All countries use identical fire-class letters by definition
2. The same class letter can have a different jurisdiction-specific meaning
3. The physical fuel changes when the label changes
4. Agent suitability can be decided from letter shape alone

**Correct option(s):** 2

- Option 1: Incorrect. The grouping and letters are not universal.
- Option 2: Correct. Classification must use the applicable scheme and approved hazard assessment.
- Option 3: Incorrect. The label describes rather than changes the hazard.
- Option 4: Incorrect. Fuel, electrical state, people and approved product conditions matter.

**CDCP-Q0400 · single · mechanism**

Which criterion should dominate an improvised conflict between service uptime and immediate life safety?

1. Keeping every server powered regardless of hazard
2. The cheapest recovery option alone
3. Whoever has the highest IT account privilege
4. The approved life-safety response and authorized emergency command

**Correct option(s):** 4

- Option 1: Incorrect. That can violate the emergency strategy.
- Option 2: Incorrect. Cost is not the sole emergency criterion.
- Option 3: Incorrect. Cyber privilege does not establish emergency authority.
- Option 4: Correct. Uptime does not authorize endangering people.

#### Recall

**A containment change blocks a sampling path. What requirement is affected?**

Detection coverage and transport Correct. The detector may no longer receive representative air.

**Why does normal IT operation not prove fire readiness?**

Protection impairments can remain latent until an event Correct. The service can run while a detector or valve is unavailable.

**What should govern staged detection responses?**

The approved cause-and-effect matrix Correct. Different inputs and stages have defined outputs.

**Why review new enclosure openings for gaseous protection?**

Leakage and protected-volume assumptions can change Correct. Retention depends on the actual boundary.

**What does a successful notification test not prove?**

All physical detection and suppression outputs Correct. It covers a selected part of the chain.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## CDCP-M21 — Physical security, safety and access continuity

### CDCP-L21 — Physical security, safety and access continuity

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L20

Physical protection should follow asset value, threat and required work. Define zones from public areas through receiving and technical rooms to sensitive cabinets. Each zone needs an access purpose, authorized population, monitoring and response. More barriers are useful only if they preserve necessary service and emergency access; a locked door without an accountable access process can create both security and recovery problems.

Access decisions have a lifecycle. Approve the role and duration, verify identity, issue the credential, test its permitted scope, review changes and revoke when no longer needed. Contractors may require escorts and work-specific restrictions. Shared credentials weaken attribution, while uncontrolled mechanical keys can bypass electronic revocation. Emergency access needs controlled custody and tested availability.

Door behavior must coordinate security with egress and the approved fire strategy. Fail-safe or fail-secure descriptions alone do not define the whole assembly, free-egress behavior or backup-power requirements. Test loss of central communications and power according to the authorized plan so local fallback behavior is known.

Safety is a parallel requirement, not a subset of cybersecurity. Electrical, mechanical, chemical, thermal and stored-energy hazards need appropriate competence, permits and isolation. A network command that stops a pump does not necessarily isolate electrical energy or stored pressure. The engineer should identify hazards and coordinate authorized specialists rather than infer permission from technical knowledge.

Acceptance includes allowed and denied access, expiration, lost-credential response, emergency functions, surveillance usefulness and incident escalation. Records should distinguish credential use from proven personal identity and preserve appropriate evidence. After an incident, restore security state without obstructing the physical process or life-safety response.

### Exercise an access boundary under failure
Create a test credential for one technical zone and a defined time window. Demonstrate an allowed entry, a denied unrelated-zone entry and expiry. Then evaluate the supported behavior during controller communication loss and power loss through an approved test arrangement. The normal online case alone does not establish the boundary during a disruption.

A central revocation may not immediately remove cached local access. Mechanical keys may bypass the electronic path. Emergency release may intentionally change a door's security state to preserve egress. These are all legitimate design questions that need explicit authority and evidence, not blanket assumptions that every door either opens or locks on failure.

Keep work safety separate from access permission. Being permitted into a plant room does not authorize electrical switching or pressure-system intervention. A BMS stop command can leave stored energy. The operating procedure must identify the energy boundary and qualified roles. During incident response, preserve life safety and controlled service while restoring the intended credential and physical-security state.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A contractor badge is revoked centrally, but a disconnected local controller continues accepting its cached permission.

**Reasoning:** Central revocation did not become effective at the door. The fallback design, synchronization and temporary compensating response must be reviewed and tested.

#### Guided practice

A pump is stopped through the BMS. Is it safe to disconnect its wiring?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** No. A stop command is not verified energy isolation; electrical and stored-energy procedures require authorized personnel.

#### Independent task

Environment: analytical

Create an access-and-safety acceptance matrix for a controls room.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Test both permitted and rejected actions.
- Include controller-offline and power-loss behavior.
- Keep operational commands separate from energy isolation.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0401 · single · diagnosis**

A centrally revoked badge still works at an offline controller. What failed?

Synthetic educational evidence; not field measurements.

Central credential: revoked
Offline local controller: continues accepting cached access

1. The existence of an identity record
2. Effective local revocation or fallback policy
3. Every mechanical lock component
4. The room's cooling capacity

**Correct option(s):** 2

- Option 1: Incorrect. The credential is known.
- Option 2: Correct. Central state did not enforce the intended door decision.
- Option 3: Incorrect. The issue can be cached authorization.
- Option 4: Incorrect. That is unrelated.

**CDCP-Q0402 · single · diagnosis**

Why is a BMS stop command not energy isolation?

Synthetic educational evidence; not field measurements.

BMS pump command: stop
Electrical isolation: not verified
Stored pressure: not verified

1. Power, pressure or stored energy can remain
2. Commands cannot affect equipment at all
3. Cyber privileges automatically authorize electrical work
4. Isolation only means a stopped screen icon

**Correct option(s):** 1

- Option 1: Correct. Stopping function does not prove a safe work state.
- Option 2: Incorrect. They can stop operation without isolating hazards.
- Option 3: Incorrect. Authority and competence are separate.
- Option 4: Incorrect. Physical energy must be addressed.

**CDCP-Q0403 · single · mechanism**

What should a zone-access matrix state?

1. Only the building address
2. Only the credential technology type
3. Only the number of cameras
4. Who may enter, for what purpose, when and under what controls

**Correct option(s):** 4

- Option 1: Incorrect. That does not distinguish zones.
- Option 2: Incorrect. Technology does not define who is authorized for each zone and interval.
- Option 3: Incorrect. Observation is not authorization.
- Option 4: Correct. It connects authorization to required work.

**CDCP-Q0404 · single · mechanism**

Why test denied access as well as permitted access?

1. Successful entry proves every restriction
2. Excessive privilege is a failure even when valid users can enter
3. Denial tests are unrelated to security
4. Every denied attempt means the system is broken

**Correct option(s):** 2

- Option 1: Incorrect. It does not.
- Option 2: Correct. Negative tests verify boundaries.
- Option 3: Incorrect. They assess enforcement.
- Option 4: Incorrect. Some denials are required.

**CDCP-Q0405 · single · mechanism**

What can uncontrolled mechanical keys undermine?

1. Only the camera bitrate
2. The building's utility voltage
3. Electronic access revocation and accountability
4. Every rack's thermal load

**Correct option(s):** 3

- Option 1: Incorrect. That is unrelated.
- Option 2: Incorrect. That is unrelated.
- Option 3: Correct. Keys can provide another entry path.
- Option 4: Incorrect. That is unrelated.

**CDCP-Q0406 · single · mechanism**

Why should emergency access be tested?

1. Security controls should be removed permanently
2. Emergencies always occur during staffed hours
3. The approved path must work during the conditions that require it
4. All administrators automatically have physical authority

**Correct option(s):** 3

- Option 1: Incorrect. Emergency access can remain controlled.
- Option 2: Incorrect. They can occur at any time.
- Option 3: Correct. A sealed plan or key record alone is insufficient.
- Option 4: Incorrect. Roles differ.

**CDCP-Q0407 · single · mechanism**

What must accompany fail-safe or fail-secure terminology?

1. Actual egress, release and power-loss behavior
2. Only a marketing description
3. A rule that every door uses one mode
4. A claim that life safety is irrelevant

**Correct option(s):** 1

- Option 1: Correct. The label is not the full door-system requirement.
- Option 2: Incorrect. Installed behavior needs verification.
- Option 3: Incorrect. Different functions can require different arrangements.
- Option 4: Incorrect. It is a governing interface.

**CDCP-Q0408 · single · mechanism**

Why is shared badge use poor evidence of individual presence?

1. One credential can represent multiple people
2. Shared badges cannot open doors
3. Camera evidence becomes unnecessary
4. Electronic logs always identify the physical person perfectly

**Correct option(s):** 1

- Option 1: Correct. Attribution is weakened.
- Option 2: Incorrect. They can, which creates the issue.
- Option 3: Incorrect. Additional evidence may be needed.
- Option 4: Incorrect. They identify credential use.

**CDCP-Q0409 · single · mechanism**

What is a suitable contractor-access duration?

1. The approved work period with controlled extension if needed
2. No access regardless of task
3. Permanent access by default
4. Until the badge physically wears out

**Correct option(s):** 1

- Option 1: Correct. Temporary work should not create indefinite privilege.
- Option 2: Incorrect. Some tasks require entry.
- Option 3: Incorrect. That exceeds the temporary purpose.
- Option 4: Incorrect. Physical life is not authorization duration.

**CDCP-Q0410 · single · mechanism**

Why separate receiving from sensitive equipment zones?

1. Goods and visitors can be checked before entering protected areas
2. The separation replaces inventory
3. All delivered items are inherently trusted
4. It guarantees no insider threat

**Correct option(s):** 1

- Option 1: Correct. It supports controlled introduction.
- Option 2: Incorrect. Assets still need records.
- Option 3: Incorrect. Supply and handling risks remain.
- Option 4: Incorrect. Internal misuse remains possible.

**CDCP-Q0411 · single · mechanism**

What should be reviewed after an access-role change?

1. Only the badge photograph
2. Only the annual energy report
3. Only the person's email signature
4. Effective permissions and continuing need

**Correct option(s):** 4

- Option 1: Incorrect. Identity is not permission scope.
- Option 2: Incorrect. That is unrelated.
- Option 3: Incorrect. That does not enforce access.
- Option 4: Correct. Old privileges can remain unnecessarily.

**CDCP-Q0412 · single · mechanism**

Which event requires a physical-security incident response rather than silent dismissal?

1. A documented successful revocation test
2. Repeated unexplained forced-door alarms
3. A scheduled permission expiry working correctly
4. A verified escort record

**Correct option(s):** 2

- Option 1: Incorrect. That is acceptance evidence.
- Option 2: Correct. They may indicate intrusion or a defect needing action.
- Option 3: Incorrect. That is expected behavior.
- Option 4: Incorrect. That supports the process.

**CDCP-Q0413 · single · mechanism**

Why coordinate containment during a physical incident?

1. Security can ignore every operating consequence
2. Only one team ever has relevant evidence
3. Facilities should ignore unauthorized entry
4. Actions can affect service, access and life safety

**Correct option(s):** 4

- Option 1: Incorrect. That can create harm.
- Option 2: Incorrect. Different teams observe different systems.
- Option 3: Incorrect. The threat still matters.
- Option 4: Correct. The response crosses disciplines.

**CDCP-Q0414 · single · mechanism**

What does a permit to work provide conceptually?

1. A substitute for all isolation verification
2. Automatic permission to change unrelated systems
3. A guarantee that no hazard exists
4. Controlled authorization with defined scope and conditions

**Correct option(s):** 4

- Option 1: Incorrect. Actual state must be checked.
- Option 2: Incorrect. Scope remains bounded.
- Option 3: Incorrect. Hazards must still be controlled.
- Option 4: Correct. It does not replace competence or physical safeguards.

**CDCP-Q0415 · single · mechanism**

Why preserve surveillance and access timestamps?

1. Only the date matters for fast events
2. Every device clock is naturally exact
3. Time synchronization proves intent
4. Correlation depends on time alignment

**Correct option(s):** 4

- Option 1: Incorrect. Seconds or finer timing can matter.
- Option 2: Incorrect. Clocks can drift.
- Option 3: Incorrect. It only supports sequence analysis.
- Option 4: Correct. Different records need a common chronology.

**CDCP-Q0416 · single · mechanism**

What is a credible response to a lost master key?

1. Delete the key record
2. Assume the finder cannot identify its use
3. Wait until annual inventory
4. Assess affected access, contain exposure and restore controlled custody

**Correct option(s):** 4

- Option 1: Incorrect. That hides the loss.
- Option 2: Incorrect. That is unsupported.
- Option 3: Incorrect. Exposure persists.
- Option 4: Correct. The key can bypass electronic controls.

**CDCP-Q0417 · single · mechanism**

Why distinguish competence from authorization?

1. The distinction matters only for visitors
2. A capable person may still lack permission for the specific action
3. Authorization proves every technical skill
4. Passing a quiz grants every site permission

**Correct option(s):** 2

- Option 1: Incorrect. It applies to staff and contractors too.
- Option 2: Correct. Authority is assigned by the operating system and roles.
- Option 3: Incorrect. Training and evidence remain separate.
- Option 4: Incorrect. It does not.

**CDCP-Q0418 · single · mechanism**

Which acceptance covers credential expiry?

1. Only the printed expiry date
2. Entry works during the approved interval and is rejected afterward
3. Only a successful entry at issue time
4. Only a signed request

**Correct option(s):** 2

- Option 1: Incorrect. Controller enforcement may differ.
- Option 2: Correct. Both sides of the boundary need evidence.
- Option 3: Incorrect. Expiry remains untested.
- Option 4: Incorrect. Intent is not effective state.

**CDCP-Q0419 · single · mechanism**

Why include stored mechanical energy in safety planning?

1. Stored energy is always zero after an alarm
2. Only electricity can cause harm
3. A network disconnect removes every stored force
4. Stopped equipment can still move or release pressure

**Correct option(s):** 4

- Option 1: Incorrect. Alarm state does not establish isolation.
- Option 2: Incorrect. Mechanical and fluid hazards also matter.
- Option 3: Incorrect. It does not.
- Option 4: Correct. Energy can remain after the motor stops.

**CDCP-Q0420 · single · mechanism**

What should incident closure verify for physical access?

1. Only the ticket is archived
2. Correct permissions, logs, emergency function and unresolved-risk disposition
3. Only alarms are muted
4. Only the door is closed

**Correct option(s):** 2

- Option 1: Incorrect. Administrative closure is insufficient.
- Option 2: Correct. The controlled state must be restored.
- Option 3: Incorrect. Silence can hide defects.
- Option 4: Incorrect. Closure does not prove authorization or fallback behavior.

#### Recall

**A centrally revoked badge still works at an offline controller. What failed?**

Effective local revocation or fallback policy Correct. Central state did not enforce the intended door decision.

**Why is a BMS stop command not energy isolation?**

Power, pressure or stored energy can remain Correct. Stopping function does not prove a safe work state.

**What should a zone-access matrix state?**

Who may enter, for what purpose, when and under what controls Correct. It connects authorization to required work.

**Why test denied access as well as permitted access?**

Excessive privilege is a failure even when valid users can enter Correct. Negative tests verify boundaries.

**What can uncontrolled mechanical keys undermine?**

Electronic access revocation and accountability Correct. Keys can provide another entry path.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)
- [NIST SP 800-82 Revision 3 — final OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

## CDCP-M22 — Monitoring architecture, leak detection and notification

### CDCP-L22 — Monitoring architecture, leak detection and notification

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L21

Monitoring design begins with decisions. For each required function, identify which measurement or state reveals normal operation, degradation, failure and recovery. A facilities monitoring matrix connects asset, point, units, source, update interval, quality, threshold, priority, response owner and retention. Collecting many points without defined meaning can create a large dashboard that fails to support action.

BMS, EPMS, environmental monitoring and DCIM have overlapping but distinct roles. BMS supervises building and process functions, EPMS observes electrical behavior, environmental systems measure local conditions, and DCIM relates assets and capacity. Define the authoritative source for each attribute and the permitted control authority. Conflicting duplicate records can create wrong maintenance or capacity decisions.

Sensor chains require physical and semantic validation. Check location, range, scaling, calibration, timestamp and failure indication. Leak detection needs coverage appropriate to likely liquid paths and a tested notification response; a dry cable sensor does not prove a hidden tray elsewhere is dry. Point testing should include wrong or stale values, not only successful transport.

Notification is a service with dependencies: field event, controller or gateway, alarm engine, network, messaging service, recipient and escalation. A sent message is not the same as a received and acted-upon alert. Define acknowledgment expectations and what happens if the primary responder is unavailable. Alarm priorities should follow consequence and response timing rather than supplier defaults alone.

Acceptance tests end to end, then verifies normal restoration. Record simulated versus physical stimuli and any inhibited outputs. Back up supported configurations and test recovery so an unavailable monitoring server does not become an indefinite blind spot. Monitoring proves observation; where control is required, separately test authorized command and physical response.

### Test freshness and notification with a synthetic timeline
A field value is sampled at 12:00:00, reaches a gateway at 12:00:02 and displays at 12:00:03. The browser continues refreshing every second after the gateway stops receiving updates. At 12:05:00 the displayed value may look stable, but it is five minutes old. The freshness rule should use the source timestamp or a meaningful sequence/quality signal rather than screen refresh.

Now inject a permitted test alarm. Record field detection, alarm-engine receipt, message submission, recipient receipt and acknowledgment. If the primary contact does not respond, verify the escalation path within the required interval. A mail-server success code is not the final operational outcome.

Point semantics also need testing. A meter's accumulated energy, instantaneous power and demand interval are different quantities. Wrong units or scale can produce plausible but dangerous values. Maintain the point map and supported backup, and retest relevant mappings after restoration or an asset move. Monitoring is only useful when identity, meaning, freshness and response all remain trustworthy.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A leak-sensor test triggers the local panel and email service, but the duty phone never receives the message because its address is obsolete.

**Reasoning:** The physical sensing and part of the software chain worked, but operational notification failed. Correct the recipient and escalation path, then retest actual receipt.

#### Guided practice

An EPMS value updates every second on screen but its source timestamp is two hours old. Is it fresh?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** No. Display refresh does not establish new field data.

#### Independent task

Environment: analytical

Build a monitoring and notification matrix for a pump, meter and leak zone.

**Packaged starter material**

- course_labs/CDCP/README.md
- course_labs/CDCP/proposal.json
- course_labs/CDCP/answers-template.json

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Include source identity, units, quality and freshness.
- Test recipient receipt and escalation.
- Separate observation from command authority.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0421 · single · diagnosis**

A dashboard refreshes each second but the source sample is two hours old. What is the condition?

Synthetic educational evidence; not field measurements.

Browser refresh: 1 s
Source measurement age: 2 h

1. Stale telemetry presented in a fresh display
2. Current process measurement
3. A successful control command
4. Guaranteed sensor calibration

**Correct option(s):** 1

- Option 1: Correct. Rendering frequency is not measurement freshness.
- Option 2: Incorrect. The source age contradicts that.
- Option 3: Incorrect. No command response is shown.
- Option 4: Incorrect. Freshness and accuracy are separate.

**CDCP-Q0422 · single · mechanism**

What should a monitoring matrix connect to each point?

1. Only a threshold value without units or response
2. Only a room photograph
3. Meaning, source, units, timing, quality and required response
4. Only a supplier name

**Correct option(s):** 3

- Option 1: Incorrect. A number alone cannot define a meaningful actionable point.
- Option 2: Incorrect. That is insufficient for a data chain.
- Option 3: Correct. The value must support a decision.
- Option 4: Incorrect. The actual point and response remain unspecified.

**CDCP-Q0423 · single · mechanism**

Why define an authoritative source for asset attributes?

1. Conflicting records can drive incorrect operational decisions
2. Every platform must be removed except one
3. Duplicate records are always identical
4. Authority automatically calibrates sensors

**Correct option(s):** 1

- Option 1: Correct. One controlled source reduces ambiguity.
- Option 2: Incorrect. Integration can preserve multiple specialized tools.
- Option 3: Incorrect. They can diverge.
- Option 4: Incorrect. Data governance does not repair physical error.

**CDCP-Q0424 · single · diagnosis**

A leak test reaches the mail server but not the duty phone. Which acceptance fails?

Synthetic educational evidence; not field measurements.

Leak panel: test received
Mail server: submitted
Duty phone: no receipt

1. Actual notification delivery
2. Every physical sensor necessarily
3. The concept of leak detection
4. All alarm logic necessarily

**Correct option(s):** 1

- Option 1: Correct. Sending is not the same as receipt.
- Option 2: Incorrect. The local panel received the stimulus.
- Option 3: Incorrect. The specific response path needs correction.
- Option 4: Incorrect. Part of the chain worked.

**CDCP-Q0425 · single · mechanism**

Why test escalation when the primary responder is unavailable?

1. More contact names guarantee delivery
2. Escalation replaces threshold design
3. Every alert is automatically handled by the first recipient
4. The response service depends on people and contact paths

**Correct option(s):** 4

- Option 1: Incorrect. The paths must work.
- Option 2: Incorrect. Both are needed.
- Option 3: Incorrect. That cannot be assumed.
- Option 4: Correct. A single unreachable person can delay action.

**CDCP-Q0426 · single · mechanism**

What does a leak sensor's coverage depend on?

1. Its placement and the likely liquid path
2. Only the total room area
3. Only the dashboard refresh rate
4. Only the asset purchase date

**Correct option(s):** 1

- Option 1: Correct. Detection is local and conditional.
- Option 2: Incorrect. Geometry and paths matter.
- Option 3: Incorrect. That does not determine where liquid reaches the sensor.
- Option 4: Incorrect. That does not establish coverage.

**CDCP-Q0427 · single · mechanism**

Why separate monitoring authority from control authority?

1. Control commands prove sensor accuracy
2. Every dashboard must control every actuator
3. Read-only systems cannot collect any data
4. Observing data should not automatically permit state changes

**Correct option(s):** 4

- Option 1: Incorrect. They test a different function.
- Option 2: Incorrect. That is unnecessary and risky.
- Option 3: Incorrect. They can observe.
- Option 4: Correct. Write access adds consequence and risk.

**CDCP-Q0428 · single · mechanism**

What can wrong engineering units cause?

1. Only a cosmetic issue
2. Misinterpreted capacity or alarm decisions
3. Guaranteed network packet loss
4. Automatic correction by a valid TLS certificate

**Correct option(s):** 2

- Option 1: Incorrect. Units define the quantity.
- Option 2: Correct. A correct number with wrong meaning is operationally wrong.
- Option 3: Incorrect. The transport can work.
- Option 4: Incorrect. Authentication does not fix semantics.

**CDCP-Q0429 · single · mechanism**

Why include sensor-failure quality states?

1. A green dashboard proves all points are valid
2. Every failed sensor reads zero safely
3. Invalid measurements must not masquerade as normal process values
4. Quality flags replace all calibration

**Correct option(s):** 3

- Option 1: Incorrect. Display logic can be wrong.
- Option 2: Incorrect. Failure behavior varies.
- Option 3: Correct. Loss of visibility needs its own response.
- Option 4: Incorrect. Both matter.

**CDCP-Q0430 · single · mechanism**

What should govern alarm priority?

1. Alphabetical tag order
2. The number of characters in the message
3. The vendor default priority without site consequence review
4. Consequence and required response time

**Correct option(s):** 4

- Option 1: Incorrect. Names do not define risk.
- Option 2: Incorrect. Text length is irrelevant.
- Option 3: Incorrect. Defaults may not reflect the site’s response urgency and service impact.
- Option 4: Correct. Priority should guide action.

**CDCP-Q0431 · single · mechanism**

Which test verifies physical-to-digital identity?

1. Count the number of tags
2. Ping the gateway only
3. Stimulate the known field point and confirm the intended tag and asset
4. Open the dashboard homepage

**Correct option(s):** 3

- Option 1: Incorrect. Count does not prove identity.
- Option 2: Incorrect. That checks reachability.
- Option 3: Correct. It checks mapping.
- Option 4: Incorrect. That checks a narrow interface.

**CDCP-Q0432 · single · mechanism**

Why retain update-interval requirements?

1. Every process changes at the same rate
2. Update interval only changes graph smoothness
3. Faster is always better regardless of system load
4. Detection and response timing depend on data age

**Correct option(s):** 4

- Option 1: Incorrect. Timing requirements differ.
- Option 2: Incorrect. It affects observation latency.
- Option 3: Incorrect. Polling can burden devices and networks.
- Option 4: Correct. Slow polling can miss required timing.

**CDCP-Q0433 · single · mechanism**

What does a simulated alarm contact test leave unproven?

1. The ability to record the alarm
2. The value of testing
3. The physical sensor's response to the real condition
4. All notification behavior necessarily

**Correct option(s):** 3

- Option 1: Incorrect. That can be observed.
- Option 2: Incorrect. The test has a useful bounded scope.
- Option 3: Correct. The injected signal bypasses sensing.
- Option 4: Incorrect. That can be tested downstream.

**CDCP-Q0434 · single · mechanism**

Why back up monitoring configuration?

1. Backups eliminate the need for restore tests
2. A screenshot restores every setting
3. Monitoring software never fails
4. Mappings, thresholds and roles may be needed for recovery

**Correct option(s):** 4

- Option 1: Incorrect. Usability still needs verification.
- Option 2: Incorrect. It does not.
- Option 3: Incorrect. Hardware and software can fail.
- Option 4: Correct. A server reinstall alone may not restore function.

**CDCP-Q0435 · single · mechanism**

What should be checked after replacing a sensor?

1. Only whether the value is nonzero
2. Only the purchase order
3. Physical reading, scaling, mapping, alarms and notification
4. Only the new serial number

**Correct option(s):** 3

- Option 1: Incorrect. A wrong value can be nonzero.
- Option 2: Incorrect. Procurement does not prove operation.
- Option 3: Correct. The complete chain may be affected.
- Option 4: Incorrect. Identity alone is insufficient.

**CDCP-Q0436 · single · mechanism**

Why can duplicate alarms be harmful?

1. They consume attention without adding distinct actionable information
2. More alerts guarantee faster response
3. Every duplicate is always a separate physical failure
4. Duplicate alerts reduce all system load

**Correct option(s):** 1

- Option 1: Correct. Alarm floods can hide priority events.
- Option 2: Incorrect. They can overwhelm operators.
- Option 3: Incorrect. Several can report one cause.
- Option 4: Incorrect. They can add traffic and work.

**CDCP-Q0437 · single · mechanism**

Which evidence supports monitoring recovery?

1. Only a login page loads
2. Restored point freshness, semantics, alarms, access and retention
3. Only the server is powered
4. Only all alarms are hidden

**Correct option(s):** 2

- Option 1: Incorrect. That does not test field data.
- Option 2: Correct. The required observation service must return.
- Option 3: Incorrect. The application may be incomplete.
- Option 4: Incorrect. That removes evidence rather than restores function.

**CDCP-Q0438 · single · mechanism**

What should happen to test suppressions after acceptance?

1. Assume a closed ticket resets every controller
2. Remove them and verify the approved normal state
3. Leave them to reduce noise
4. Delete the alarm definitions

**Correct option(s):** 2

- Option 1: Incorrect. It does not.
- Option 2: Correct. Temporary inhibition can otherwise persist.
- Option 3: Incorrect. That can hide real events.
- Option 4: Incorrect. Temporary tests do not justify permanent removal.

**CDCP-Q0439 · single · mechanism**

Why distinguish data completeness from data accuracy?

1. Both terms mean network bandwidth
2. Accuracy guarantees no missing intervals
3. All expected samples can exist but be wrong
4. Completeness guarantees calibration

**Correct option(s):** 3

- Option 1: Incorrect. They describe data quality.
- Option 2: Incorrect. Samples can be accurate when present but incomplete.
- Option 3: Correct. Different quality dimensions need different checks.
- Option 4: Incorrect. It does not.

**CDCP-Q0440 · single · mechanism**

Which monitoring claim is most defensible?

1. The specified points and responses passed the stated tests under recorded conditions
2. Successful ping proves correct process control
3. A large tag count proves complete facility visibility
4. Every future failure will be detected

**Correct option(s):** 1

- Option 1: Correct. The claim matches the evidence.
- Option 2: Incorrect. Transport is not the whole function.
- Option 3: Incorrect. Coverage and meaning matter.
- Option 4: Incorrect. Finite tests cannot prove that.

#### Recall

**A dashboard refreshes each second but the source sample is two hours old. What is the condition?**

Stale telemetry presented in a fresh display Correct. Rendering frequency is not measurement freshness.

**What should a monitoring matrix connect to each point?**

Meaning, source, units, timing, quality and required response Correct. The value must support a decision.

**Why define an authoritative source for asset attributes?**

Conflicting records can drive incorrect operational decisions Correct. One controlled source reduces ambiguity.

**A leak test reaches the mail server but not the duty phone. Which acceptance fails?**

Actual notification delivery Correct. Sending is not the same as receipt.

**Why test escalation when the primary responder is unavailable?**

The response service depends on people and contact paths Correct. A single unreachable person can delay action.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)
- [NIST SP 800-82 Revision 3 — final OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

## CDCP-M23 — Sustainability, PUE and operational economics

### CDCP-L23 — Sustainability, PUE and operational economics

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L22

Facility efficiency should be assessed without confusing reduced overhead with useful computing output. PUE divides total facility energy by IT energy over compatible periods and boundaries. It can improve when IT load rises against fixed overhead, even if the facility uses more total energy. Report absolute energy and workload context alongside the ratio.

Power and cooling improvements interact. Reducing unnecessary IT energy can also reduce cooling demand, while improving airflow can allow efficient plant operation within inlet limits. UPS losses vary with load and mode; lighting controls change operating hours; economizers depend on climate and system conditions. A savings proposal should name the mechanism and quantify its assumptions rather than simply target a fashionable ratio.

Water, carbon and material impacts need separate boundaries. Water consumption can increase in an energy-saving evaporative mode. Carbon results depend on the energy source, timing and accounting method. Reuse or life extension can reduce replacement burden but may retain inefficient or unsupported equipment. Compare alternatives against the same performance, reliability, maintainability and recovery requirements.

Economic review includes capital, energy, maintenance, support, spares, staffing and eventual replacement. Simple payback is initial additional cost divided by annual net savings; it ignores later cash flows and discounting. Sensitivity analysis should vary uncertain energy price, utilization and maintenance assumptions. A precise-looking result is not more reliable than its inputs.

Acceptance verifies savings and constraints together. Use a baseline, suitable meters, comparable workload and weather context, then confirm service, temperatures, alarms and reserve. Label modeled results as estimates and measured results by their observation period. A lower bill can reflect a tariff reduction rather than an engineering improvement.

### Compare ratio, absolute energy and useful output
Before consolidation, IT uses 800 MWh and overhead 400 MWh, giving PUE 1.5 and total 1200 MWh. After consolidation, IT uses 500 MWh and overhead 300 MWh, giving PUE 1.6 and total 800 MWh. Total energy falls by one-third even though PUE worsens. If useful work is unchanged, the project may be valuable; if work falls substantially, productivity needs separate analysis.

Use a matched boundary and period, then add water and carbon information where relevant. A cooling mode that saves 100 MWh but consumes additional water may or may not suit a constrained site. A carbon result needs an explicit source and accounting basis rather than inheriting meaning from PUE.

For the financial case, separate installed cost, recurring cost and risk assumptions. A simple payback of four years can look attractive over ten years but not over a three-year occupancy plan. Vary load, energy price and maintenance cost, and retain the technical acceptance conditions. Savings achieved by removing required reserve are a scope change, not an equivalent efficiency improvement.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. Before a change, facility energy is 1200 MWh and IT energy 800 MWh. Afterward, facility energy is 1300 MWh and IT energy 1000 MWh.

**Reasoning:** PUE improves from 1.5 to 1.3, but total energy rises by 100 MWh. The ratio improvement is real under these boundaries, yet it is not an absolute energy reduction.

#### Guided practice

An upgrade costs 30,000 and saves an estimated 6,000 annually. What is simple payback and what remains outside it?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** Five years. Discounting, later cash flows, uncertainty, maintenance and service equivalence still need review.

#### Independent task

Environment: analytical

Write an efficiency change business case with a measurement plan.

**Packaged starter material**

- course_labs/CDCP/README.md
- course_labs/CDCP/proposal.json
- course_labs/CDCP/answers-template.json

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Show absolute and ratio metrics.
- Preserve service and resilience constraints.
- Separate modeled savings from measured observations.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0441 · single · calculation**

Facility energy changes from 1200 to 1300 MWh while IT changes from 800 to 1000 MWh. What happens?

Synthetic educational evidence; not field measurements.

Before facility/IT energy: 1200/800 MWh
After facility/IT energy: 1300/1000 MWh

1. PUE improves from 1.5 to 1.3 while total energy rises
2. Total energy falls by 100 MWh
3. PUE worsens to 1.625
4. PUE proves computing productivity doubled

**Correct option(s):** 1

- Option 1: Correct. Both statements can be true.
- Option 2: Incorrect. The stated total rises.
- Option 3: Incorrect. That mixes the new numerator with the old denominator.
- Option 4: Incorrect. It does not measure useful work.

**CDCP-Q0442 · single · diagnosis**

A 30,000 upgrade saves 6,000 annually. What is simple payback?

Synthetic educational evidence; not field measurements.

Incremental cost: 30,000
Annual net saving: 6,000

1. 36 years
2. 24 years
3. 0.2 years
4. 5 years

**Correct option(s):** 4

- Option 1: Incorrect. Adding values does not produce duration.
- Option 2: Incorrect. Subtracting values does not produce duration.
- Option 3: Incorrect. The ratio is reversed.
- Option 4: Correct. Cost divided by annual savings gives five.

**CDCP-Q0443 · single · mechanism**

What does a PUE improvement not necessarily establish?

1. Lower absolute energy consumption
2. A useful overhead comparison within scope
3. A changed facility-to-IT ratio
4. The need for boundary disclosure

**Correct option(s):** 1

- Option 1: Correct. The IT denominator can grow.
- Option 2: Incorrect. It can support that.
- Option 3: Incorrect. That is what was calculated.
- Option 4: Incorrect. Disclosure remains important.

**CDCP-Q0444 · single · mechanism**

Why include weather in cooling-savings analysis?

1. Normalization guarantees perfect certainty
2. Weather affects only staff travel
3. Outdoor conditions can change energy independently of the project
4. Every month has identical cooling conditions

**Correct option(s):** 3

- Option 1: Incorrect. It still uses assumptions.
- Option 2: Incorrect. It can affect heat rejection.
- Option 3: Correct. Comparability needs environmental context.
- Option 4: Incorrect. They vary.

**CDCP-Q0445 · single · calculation**

What can a lower electricity bill with unchanged kWh indicate?

1. A tariff or price change rather than energy savings
2. Reduced IT heat necessarily
3. Guaranteed better cooling performance
4. Guaranteed PUE improvement

**Correct option(s):** 1

- Option 1: Correct. Cost and consumption are distinct.
- Option 2: Incorrect. Energy use is unchanged.
- Option 3: Incorrect. No thermal result is stated.
- Option 4: Incorrect. No ratio change is stated.

**CDCP-Q0446 · single · mechanism**

Why evaluate water separately from PUE?

1. PUE already includes treatment chemistry
2. PUE is an energy ratio and does not include water use
3. Water has no environmental significance
4. Every cooling method uses identical water

**Correct option(s):** 2

- Option 1: Incorrect. It does not.
- Option 2: Correct. A low ratio can coexist with high water demand.
- Option 3: Incorrect. Local constraints can be material.
- Option 4: Incorrect. They differ.

**CDCP-Q0447 · single · mechanism**

Which comparison preserves service equivalence?

1. One option disables redundancy without acknowledgment
2. One option excludes half the load from measurement
3. Alternatives meet the same required load, failure and recovery conditions
4. One option ignores temperature limits

**Correct option(s):** 3

- Option 1: Incorrect. That changes the service.
- Option 2: Incorrect. That changes the boundary.
- Option 3: Correct. Savings should not come from dropping requirements.
- Option 4: Incorrect. That violates suitability.

**CDCP-Q0448 · single · mechanism**

Why use sensitivity analysis for a savings case?

1. It makes measured data unnecessary
2. It guarantees the best-case scenario
3. Uncertain prices and utilization can change the result
4. It removes maintenance costs

**Correct option(s):** 3

- Option 1: Incorrect. Measurements still matter.
- Option 2: Incorrect. It explores possibilities rather than guarantees.
- Option 3: Correct. It tests robustness.
- Option 4: Incorrect. Those remain inputs.

**CDCP-Q0449 · single · mechanism**

What is a direct benefit of eliminating a verified unnecessary idle load?

1. Every facility load becomes zero
2. PUE must always decrease
3. All redundancy is automatically preserved
4. Lower IT energy and potentially associated facility energy

**Correct option(s):** 4

- Option 1: Incorrect. Other services remain.
- Option 2: Incorrect. A smaller IT denominator can increase PUE.
- Option 3: Incorrect. The load's role must be confirmed.
- Option 4: Correct. The effect can compound through cooling and losses.

**CDCP-Q0450 · single · mechanism**

Why compare UPS efficiency at actual loading?

1. Only maximum kVA matters
2. Every UPS has a constant loss percentage
3. The battery age fully determines all efficiency
4. Part-load and mode behavior can differ from the headline rating

**Correct option(s):** 4

- Option 1: Incorrect. Energy performance is a separate criterion.
- Option 2: Incorrect. Fixed and variable losses can differ.
- Option 3: Incorrect. Conversion and loading also matter.
- Option 4: Correct. The site may operate away from the best point.

**CDCP-Q0451 · single · mechanism**

What should a carbon claim specify?

1. Only PUE
2. Only the rack count
3. Only the equipment efficiency at one operating point
4. Energy quantity, source and accounting basis

**Correct option(s):** 4

- Option 1: Incorrect. PUE omits emissions intensity.
- Option 2: Incorrect. Count does not establish energy or source.
- Option 3: Incorrect. Emissions also depend on energy quantity and the accounting source or method.
- Option 4: Correct. The result depends on those assumptions.

**CDCP-Q0452 · single · mechanism**

Why can extending equipment life be a tradeoff?

1. New equipment always has zero embodied impact
2. Older equipment is always best
3. It can reduce replacement burden but retain inefficiency or unsupported risk
4. Supportability has no relation to sustainability

**Correct option(s):** 3

- Option 1: Incorrect. Manufacture and deployment have impacts.
- Option 2: Incorrect. Condition and support matter.
- Option 3: Correct. Lifecycle effects compete.
- Option 4: Incorrect. Failure and replacement effects matter.

**CDCP-Q0453 · single · mechanism**

What must a measured-savings report include?

1. Only a rounded percentage
2. Baseline, period, boundary and relevant operating conditions
3. Only the most favorable hour
4. Only a vendor prediction

**Correct option(s):** 2

- Option 1: Incorrect. The underlying quantities are needed.
- Option 2: Correct. The comparison must be interpretable.
- Option 3: Incorrect. That may not represent the required period.
- Option 4: Incorrect. That is estimated rather than measured.

**CDCP-Q0454 · single · mechanism**

Which cost belongs in a lifecycle comparison?

1. Maintenance and replacement as well as purchase and energy
2. Only initial purchase
3. Only this month's bill
4. Only the supplier discount

**Correct option(s):** 1

- Option 1: Correct. Ownership extends beyond installation.
- Option 2: Incorrect. That omits recurring costs.
- Option 3: Incorrect. The study period is broader.
- Option 4: Incorrect. Discount is one commercial term.

**CDCP-Q0455 · single · mechanism**

Why can an airflow fix save energy without adding cooling capacity?

1. Blanking panels generate cold
2. More airflow always consumes zero energy
3. Better delivery can reduce unnecessary fan or refrigeration effort
4. The fix eliminates IT heat

**Correct option(s):** 3

- Option 1: Incorrect. They redirect air.
- Option 2: Incorrect. Fans use power.
- Option 3: Correct. It reduces waste rather than creating heat rejection.
- Option 4: Incorrect. The load still dissipates energy.

**CDCP-Q0456 · single · mechanism**

What is the status of a spreadsheet savings prediction?

1. An official sustainability certification
2. Analytical estimate under stated assumptions
3. Production-proven saving
4. Guaranteed annual cash flow

**Correct option(s):** 2

- Option 1: Incorrect. The spreadsheet does not award one.
- Option 2: Correct. It is not a field measurement.
- Option 3: Incorrect. No observation is implied.
- Option 4: Incorrect. Prices and operation can change.

**CDCP-Q0457 · single · mechanism**

Why retain resilience checks during optimization?

1. Efficiency and resilience can never coexist
2. Efficient normal operation can consume failure-state margin
3. A lower bill overrides every availability target
4. Redundancy is always unnecessary waste

**Correct option(s):** 2

- Option 1: Incorrect. They can be jointly engineered.
- Option 2: Correct. The required degraded states still matter.
- Option 3: Incorrect. Requirements remain simultaneous.
- Option 4: Incorrect. It may be required for service.

**CDCP-Q0458 · single · mechanism**

What does simple payback ignore after the break-even point?

1. The existence of a study period
2. Later cash flows and time-value effects
3. Annual savings
4. Initial capital

**Correct option(s):** 2

- Option 1: Incorrect. A broader analysis should state one.
- Option 2: Correct. It is a limited metric.
- Option 3: Incorrect. That is also part of it.
- Option 4: Incorrect. That is part of the calculation.

**CDCP-Q0459 · single · mechanism**

Why document energy-meter boundaries?

1. All meters automatically share one boundary
2. Boundary changes cannot affect PUE
3. Meter location affects only accessibility
4. Included and excluded loads determine the reported ratio

**Correct option(s):** 4

- Option 1: Incorrect. They measure where installed.
- Option 2: Incorrect. They can.
- Option 3: Incorrect. It affects what is counted.
- Option 4: Correct. Different boundaries can produce different results.

**CDCP-Q0460 · single · mechanism**

Which decision statement is strongest?

1. It has the lowest price, so lifetime value is highest
2. It is newest, so it is best
3. The option meets constraints and improves the measured or modeled objectives within stated uncertainty
4. It has the lowest PUE, so every other factor is irrelevant

**Correct option(s):** 3

- Option 1: Incorrect. Recurring costs and risks can differ.
- Option 2: Incorrect. Novelty is not evidence.
- Option 3: Correct. It connects suitability and evidence.
- Option 4: Incorrect. PUE omits several requirements.

#### Recall

**Facility energy changes from 1200 to 1300 MWh while IT changes from 800 to 1000 MWh. What happens?**

PUE improves from 1.5 to 1.3 while total energy rises Correct. Both statements can be true.

**A 30,000 upgrade saves 6,000 annually. What is simple payback?**

5 years Correct. Cost divided by annual savings gives five.

**What does a PUE improvement not necessarily establish?**

Lower absolute energy consumption Correct. The IT denominator can grow.

**Why include weather in cooling-savings analysis?**

Outdoor conditions can change energy independently of the project Correct. Comparability needs environmental context.

**What can a lower electricity bill with unchanged kWh indicate?**

A tariff or price change rather than energy savings Correct. Cost and consumption are distinct.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## CDCP-M24 — Maintenance readiness, commissioning and change control

### CDCP-L24 — Maintenance readiness, commissioning and change control

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L23

Facility capability decays if maintenance, configuration and records are not sustained. Preventive maintenance acts on a planned basis; condition-based maintenance uses observed condition; corrective maintenance addresses identified defects. The appropriate mix depends on failure consequence, detectability, equipment guidance and service constraints. An overdue task is not automatically an immediate failure, but its risk must be understood and accepted rather than ignored.

A maintenance method identifies the asset, current state, energy and process boundaries, prerequisites, sequence, expected results, hold points and recovery. Verify effective redundancy before isolating equipment. A spare unit that is already failed cannot support the planned maintenance margin. Tools and test instruments must be suitable and within the required calibration state.

Commissioning compares installed behavior with requirements. Pre-functional checks establish installation readiness; functional checks exercise equipment; integrated tests examine cross-system sequences. These categories are not rigid substitutes for the project's actual commissioning plan, but they help prevent a component pass from being mistaken for complete facility acceptance.

Change control protects the known state while enabling improvement. Assess service impact, schedule conflicts, backups, access, rollback feasibility and communication. During execution, stop at unexpected states according to the approved procedure. Afterward, verify the function, remove temporary overrides, update as-built records and monitor for delayed effects.

Handover transfers usable knowledge and responsibility: design basis, settings, diagrams, test results, defects, maintenance requirements, spares, warranties and recovery methods. A thick document pack is not sufficient if operators cannot locate the current procedure or perform the required response. Use demonstrations and independent exercises to establish readiness while preserving the distinction between study, lab performance and authorized field competence.

### Make a maintenance procedure executable
A pump replacement plan should name the exact asset, current duty/standby state, remaining supported capacity, isolation and stored-energy boundaries, approved steps, expected observations and restoration. Before the first action, reconcile the shift log with the plan. If the standby pump is already defective, the work's assumed reserve does not exist.

A hold point is a decision gate: proceed only if a defined observation matches the prerequisite. For example, a commanded valve closure without the required verified isolation evidence is not enough to continue into a hazardous intervention. The relevant specialist procedure determines that evidence; this course teaches the reasoning rather than a universal switching sequence.

After work, verify the physical function, alarms, automatic mode, redundancy and updated records. Retain test-instrument details and measurements rather than only a service-report signature. During handover, have the receiving operator locate the current procedure and explain the degraded-state response. A document pack is useful only when it supports actual controlled operation and recovery.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A cooling-unit maintenance plan assumes three remaining units, but the shift log shows one of them unavailable.

**Reasoning:** The prerequisite is false. Recalculate the effective capacity and risk, then hold or revise the work through the authorized process rather than following the original schedule blindly.

#### Guided practice

A controller update has a backup, but restoring it takes longer than the safe thermal window. Is rollback feasible?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** Not under the stated conditions. The method needs a different recovery path, reduced load, additional reserve or another justified change.

#### Independent task

Environment: analytical

Prepare a maintenance and handover package for one facility subsystem.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Check effective prerequisites and energy boundaries.
- Define timed rollback or recovery and abort criteria.
- Include operator demonstration and current records.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0461 · single · diagnosis**

A maintenance plan assumes three remaining units, but one is already failed. What should happen?

Synthetic educational evidence; not field measurements.

Maintenance plan assumes: three remaining units
Current shift log: one of those units unavailable

1. Reassess and hold or revise the work
2. Ignore the shift log
3. Count the failed unit as reserve
4. Proceed because the document is approved

**Correct option(s):** 1

- Option 1: Correct. The planned prerequisite is false.
- Option 2: Incorrect. It is relevant evidence.
- Option 3: Incorrect. Unavailable equipment cannot deliver capacity.
- Option 4: Incorrect. Approval does not override changed state.

**CDCP-Q0462 · single · mechanism**

What distinguishes condition-based maintenance?

1. It eliminates all scheduled tasks
2. It occurs only after total failure
3. It never uses measurements
4. Action is informed by observed equipment condition

**Correct option(s):** 4

- Option 1: Incorrect. Some tasks may remain time-based.
- Option 2: Incorrect. That is corrective response.
- Option 3: Incorrect. Measurements are central.
- Option 4: Correct. It differs from purely calendar-based scheduling.

**CDCP-Q0463 · single · mechanism**

Why verify test-instrument calibration status?

1. More display digits replace calibration
2. Calibration authorizes every hazardous task
3. Acceptance decisions depend on suitable measurement evidence
4. A recent purchase guarantees accuracy

**Correct option(s):** 3

- Option 1: Incorrect. Resolution is not accuracy.
- Option 2: Incorrect. Competence and authority remain separate.
- Option 3: Correct. An unsuitable instrument can mislead.
- Option 4: Incorrect. New equipment still has specified capability.

**CDCP-Q0464 · single · mechanism**

What does an integrated commissioning test add?

1. A replacement for all installation checks
2. Cross-system behavior under defined sequences
3. Automatic certification of every standard
4. A guarantee of no future maintenance

**Correct option(s):** 2

- Option 1: Incorrect. Those remain necessary.
- Option 2: Correct. Component passes may miss interfaces.
- Option 3: Incorrect. The scope remains bounded.
- Option 4: Incorrect. Capability must be sustained.

**CDCP-Q0465 · single · diagnosis**

A backup restore takes 30 minutes but the safe process window is 10. What is wrong?

Synthetic educational evidence; not field measurements.

Restore procedure: 30 min
Safe process window: 10 min

1. More approvals shorten the restore automatically
2. The proposed recovery is not feasible within the constraint
3. The backup cannot exist
4. The safe window can be omitted

**Correct option(s):** 2

- Option 1: Incorrect. Physical duration remains.
- Option 2: Correct. A backup alone is insufficient.
- Option 3: Incorrect. Existence and usable recovery time differ.
- Option 4: Incorrect. It is a requirement.

**CDCP-Q0466 · single · mechanism**

Why remove temporary overrides after work?

1. Overrides disappear when the ticket closes
2. Every override improves resilience
3. They can alter future automatic behavior
4. Overrides affect only report formatting

**Correct option(s):** 3

- Option 1: Incorrect. They may persist in controllers.
- Option 2: Incorrect. It can bypass intended logic.
- Option 3: Correct. The effective state must return to the approved baseline.
- Option 4: Incorrect. They can control equipment.

**CDCP-Q0467 · single · mechanism**

What should a handover include beyond drawings?

1. Only the purchase order
2. Only the installed equipment catalog
3. Only a large page count
4. Settings, tests, defects, maintenance, spares and recovery information

**Correct option(s):** 4

- Option 1: Incorrect. Procurement is not readiness.
- Option 2: Incorrect. A catalog does not transfer effective settings, defects and recovery methods.
- Option 3: Incorrect. Usability and content matter.
- Option 4: Correct. Operators need an executable lifecycle package.

**CDCP-Q0468 · single · mechanism**

Why perform a post-change observation period?

1. Monitoring replaces rollback planning
2. Delayed thermal or workload effects can emerge
3. A longer observation proves lifetime reliability
4. All effects appear instantly

**Correct option(s):** 2

- Option 1: Incorrect. Both are needed.
- Option 2: Correct. Immediate success may not reveal every issue.
- Option 3: Incorrect. The evidence remains bounded.
- Option 4: Incorrect. Some develop over time.

**CDCP-Q0469 · single · mechanism**

What is a pre-functional readiness check concerned with?

1. Awarding a credential
2. Installation and prerequisites before exercising the function
3. Ignoring documentation until after operation
4. Only final business availability

**Correct option(s):** 2

- Option 1: Incorrect. That is not commissioning.
- Option 2: Correct. It supports safe and meaningful testing.
- Option 3: Incorrect. Records support readiness.
- Option 4: Incorrect. That is a later service outcome.

**CDCP-Q0470 · single · mechanism**

Which change condition should trigger a hold point?

1. The old checklist has many signatures
2. An observed state differs from the defined expected result
3. A manager prefers faster completion
4. The schedule is tight

**Correct option(s):** 2

- Option 1: Incorrect. Current state still matters.
- Option 2: Correct. The next action may rely on an invalid assumption.
- Option 3: Incorrect. Preference does not resolve the discrepancy.
- Option 4: Incorrect. That increases pressure but does not justify blind continuation.

**CDCP-Q0471 · single · mechanism**

Why retain defect lists at handover?

1. Unresolved issues affect readiness and future work
2. Handover means defects no longer exist
3. Only cosmetic defects are worth recording
4. Defects should be hidden to simplify training

**Correct option(s):** 1

- Option 1: Correct. They need owners and dispositions.
- Option 2: Incorrect. Administrative transfer does not repair them.
- Option 3: Incorrect. Functional defects are especially important.
- Option 4: Incorrect. That misleads operators.

**CDCP-Q0472 · single · mechanism**

What is corrective maintenance?

1. A new capacity design only
2. Work addressing an identified fault or defect
3. A forecast without intervention
4. Every periodic inspection

**Correct option(s):** 2

- Option 1: Incorrect. That is expansion engineering.
- Option 2: Correct. It restores or corrects a known condition.
- Option 3: Incorrect. That is planning.
- Option 4: Incorrect. That can be preventive.

**CDCP-Q0473 · single · mechanism**

Why test operator retrieval of the current procedure?

1. Documentation is useful only if the right version can be found and used
2. Any archived version is equally valid
3. Procedures are unnecessary after training
4. Document volume proves competence

**Correct option(s):** 1

- Option 1: Correct. Readiness includes usability.
- Option 2: Incorrect. Superseded instructions can be wrong.
- Option 3: Incorrect. They support controlled execution.
- Option 4: Incorrect. It does not.

**CDCP-Q0474 · single · mechanism**

What should a maintenance report state?

1. Only a generic satisfactory stamp
2. Only the technician's name
3. Work performed, observations, measurements, defects and final state
4. Only hours billed

**Correct option(s):** 3

- Option 1: Incorrect. That lacks detail and boundary.
- Option 2: Incorrect. Identity is not the work evidence.
- Option 3: Correct. It must show what changed and what remains.
- Option 4: Incorrect. Time does not establish technical result.

**CDCP-Q0475 · single · mechanism**

Why check simultaneous work in nearby systems?

1. Scheduling affects only payroll
2. Separate tickets guarantee separate failure domains
3. Combined maintenance can remove assumed independence or reserve
4. More workers always reduce risk

**Correct option(s):** 3

- Option 1: Incorrect. It affects operational risk.
- Option 2: Incorrect. Physical dependencies can overlap.
- Option 3: Correct. Individually acceptable tasks can conflict.
- Option 4: Incorrect. Coordination matters.

**CDCP-Q0476 · single · mechanism**

What is a useful spare-parts criterion?

1. A spare with unknown firmware and provenance
2. Compatibility, condition and availability within the required restoration time
3. Any similar-looking component
4. The largest possible inventory regardless of need

**Correct option(s):** 2

- Option 1: Incorrect. That can complicate recovery.
- Option 2: Correct. A stored item must be usable.
- Option 3: Incorrect. Appearance does not establish compatibility.
- Option 4: Incorrect. Cost and lifecycle fit matter.

**CDCP-Q0477 · single · mechanism**

Which evidence demonstrates independent operational learning beyond watching a demonstration?

1. The learner executes or analyzes a new task against acceptance criteria
2. A completion checkbox alone
3. The instructor performs every action
4. The learner has opened the video page

**Correct option(s):** 1

- Option 1: Correct. It tests transfer of knowledge.
- Option 2: Incorrect. Self-report is weaker than task evidence.
- Option 3: Incorrect. That does not show the learner's performance.
- Option 4: Incorrect. That is access, not demonstrated capability.

**CDCP-Q0478 · single · mechanism**

Why keep study completion separate from field authorization?

1. Study has no value
2. Knowledge assessment does not grant permission for consequential work
3. Authorization guarantees all knowledge
4. Everyone who can read a procedure may operate any system

**Correct option(s):** 2

- Option 1: Incorrect. It builds necessary understanding.
- Option 2: Correct. Site roles and competence requirements remain.
- Option 3: Incorrect. It does not.
- Option 4: Incorrect. That is not a valid authority model.

**CDCP-Q0479 · single · mechanism**

What should follow a successful repair?

1. Functional verification and restoration of required monitoring and redundancy
2. Permanent suppression of related alarms
3. Deletion of the original fault record
4. Immediate closure without testing

**Correct option(s):** 1

- Option 1: Correct. Repair must return the intended service state.
- Option 2: Incorrect. That can hide recurrence.
- Option 3: Incorrect. History supports future diagnosis.
- Option 4: Incorrect. The fault may remain or new issues may exist.

**CDCP-Q0480 · single · mechanism**

Why compare maintenance findings with the design basis?

1. Repeated defects can reveal unsuitable assumptions or interfaces
2. Only purchase cost matters after installation
3. Every defect is unrelated to engineering
4. Designs are never changed after commissioning

**Correct option(s):** 1

- Option 1: Correct. Lifecycle evidence should improve design.
- Option 2: Incorrect. Operation and recovery continue to matter.
- Option 3: Incorrect. Architecture and conditions can contribute.
- Option 4: Incorrect. They can need justified revision.

#### Recall

**A maintenance plan assumes three remaining units, but one is already failed. What should happen?**

Reassess and hold or revise the work Correct. The planned prerequisite is false.

**What distinguishes condition-based maintenance?**

Action is informed by observed equipment condition Correct. It differs from purely calendar-based scheduling.

**Why verify test-instrument calibration status?**

Acceptance decisions depend on suitable measurement evidence Correct. An unsuitable instrument can mislead.

**What does an integrated commissioning test add?**

Cross-system behavior under defined sequences Correct. Component passes may miss interfaces.

**A backup restore takes 30 minutes but the safe process window is 10. What is wrong?**

The proposed recovery is not feasible within the constraint Correct. A backup alone is insufficient.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)
- [NIST SP 800-82 Revision 3 — final OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

## CDCP-M25 — Integrated design review and facility acceptance case

### CDCP-L25 — Integrated design review and facility acceptance case

Estimated study time: 55 minutes before independent work. Prerequisite chapters: CDCP-L24

A professional facility review connects business requirements to physical capability and operating evidence. Begin with the required service, load envelope, failure states and boundaries. Then trace power, cooling, communications, control, safety, security and human response. A design can pass each component's normal test while failing the overall sequence because one interface is missing or a shared dependency was overlooked.

Use a state table to make the design explicit. For each normal, maintenance, failure and recovery state, record active sources, remaining capacity, control authority, monitoring availability and permitted service. Add common-cause scenarios such as a shared controller, fuel pump, room exposure or configuration error. Do not claim tolerance of a combined fault that the requirement or evidence never addressed.

Acceptance evidence has levels. Analytical calculations show feasibility under assumptions. Simulation tests modeled behavior. Vendor tools or emulators exercise supported software functions with limits. Physical tests observe actual equipment. Production observations show service under real operating conditions. These categories reinforce one another but cannot be renamed to imply stronger evidence.

An integrated test plan defines stimulus, expected transitions, measurements, timing, pass limits, abort conditions and restoration. It should include rejected actions and loss of visibility as well as successful transitions. A read-only dashboard may stay green after its source data freezes; a redundant feed may share a breaker; a restored controller may contain the wrong revision. Test effective state rather than relying on intent.

Final acceptance is a reasoned decision. Accept when all mandatory criteria have supported evidence, hold when evidence or prerequisites are missing, and reject when the proposal violates a required constraint without an approved resolution. Record residual risks and owners explicitly. The programme's intended identity grows through sustained design, implementation, commissioning, operation, maintenance, optimisation, troubleshooting, incident response and recovery; this course supplies a facility-integration foundation for that larger capability.

### Write an accept, hold or reject conclusion
A proposal meets normal power and cooling demand, but its required maintenance-plus-fault state leaves a 40 kW cooling deficit. That is a technical failure of the stated requirement, so the proposal cannot be accepted unchanged. If the calculation is absent rather than failing, hold pending evidence is the appropriate distinction. If all mandatory criteria are supported, acceptance can be scoped to the demonstrated envelope.

The evidence chain should link requirement, design decision, installed configuration, test event, raw observation and acceptance authority. A simulation may support the design decision while a physical test supports the installed behavior. Keep both and state their limits. Do not promote a simulated event into a production achievement to make the portfolio look stronger.

For recovery, verify not only that devices run but that the approved configuration, identities, monitoring, redundancy and records are restored. Remove temporary overrides and retain unresolved risks with owners. These habits connect this facility course to the wider network, controls and cybersecurity programme, where the same lifecycle reasoning is applied at much greater technical depth.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A proposal has two UPS units, three cooling units and two carriers. Both UPS units share a bypass bus, all cooling units share one controller, and both carriers share the entry duct.

**Reasoning:** The component counts do not demonstrate independent facility paths. Evaluate each shared dependency against the specified fault and maintenance states, then require topology changes or scoped acceptance of the actual capability.

#### Guided practice

A test report labels a simulated pump-failure scenario as production evidence. What must be corrected?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** The evidence category and resulting claim. The simulation can support design reasoning but is not an observed production failure or recovery.

#### Independent task

Environment: analytical

Complete an accept/hold/reject review of a synthetic data-center proposal.

**Packaged starter material**

- course_labs/CDCP/README.md
- course_labs/CDCP/proposal.json
- course_labs/CDCP/answers-template.json

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Trace every mandatory requirement to evidence.
- Identify common causes and untested states.
- State exact claim boundaries and lifecycle actions still requiring physical or supervised proof.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**CDCP-Q0481 · single · diagnosis**

Two UPS units share one bypass bus. What must be assessed?

Synthetic educational evidence; not field measurements.

UPS-A and UPS-B: separate modules
Maintenance/static bypass: shared bus

1. A guaranteed 2N facility rating
2. The bypass as a common failure and maintenance domain
3. Only the total number of screens
4. Only normal load sharing

**Correct option(s):** 2

- Option 1: Incorrect. The evidence is insufficient for that claim.
- Option 2: Correct. Unit count alone does not establish independence.
- Option 3: Incorrect. Displays do not define power paths.
- Option 4: Incorrect. Other states can use the shared bus.

**CDCP-Q0482 · single · mechanism**

What does a state table add to a component list?

1. It shows behavior and available resources across operating conditions
2. It replaces all drawings
3. It proves every state automatically
4. It only records purchase dates

**Correct option(s):** 1

- Option 1: Correct. Counts alone omit transitions and dependencies.
- Option 2: Incorrect. Topology is still needed.
- Option 3: Incorrect. Evidence must support the entries.
- Option 4: Incorrect. That is an asset inventory function.

**CDCP-Q0483 · single · diagnosis**

A simulation is labeled production evidence. What is wrong?

Synthetic educational evidence; not field measurements.

Actual event environment: simulation
Report label: production evidence

1. The claim exceeds the evidence category
2. Production evidence never needs context
3. Simulations have no value
4. The model must be deleted

**Correct option(s):** 1

- Option 1: Correct. Modeled behavior is not observed production operation.
- Option 2: Incorrect. It also needs scope and conditions.
- Option 3: Incorrect. They can provide useful bounded evidence.
- Option 4: Incorrect. The label and claim should be corrected.

**CDCP-Q0484 · single · mechanism**

When is hold an appropriate design-review decision?

1. A known mandatory limit is violated with no resolution
2. The design uses an unfamiliar but fully verified supported product
3. Every requirement has verified evidence
4. Mandatory evidence or prerequisites are unresolved

**Correct option(s):** 4

- Option 1: Incorrect. That can justify rejection.
- Option 2: Incorrect. Unfamiliarity alone is not an unresolved mandatory requirement.
- Option 3: Incorrect. That supports acceptance.
- Option 4: Correct. The proposal may be viable but not yet acceptable.

**CDCP-Q0485 · single · mechanism**

When is reject appropriate?

1. A mandatory constraint is violated without an approved feasible resolution
2. A document needs a minor typo correction
3. A supplier is unfamiliar
4. One optional preference is different

**Correct option(s):** 1

- Option 1: Correct. The proposal cannot be accepted as stated.
- Option 2: Incorrect. That alone need not invalidate the design.
- Option 3: Incorrect. Unfamiliarity is not evidence of failure.
- Option 4: Incorrect. That may not be a mandatory failure.

**CDCP-Q0486 · single · mechanism**

Why test loss of monitoring visibility?

1. A green display can persist while source data is unavailable
2. Visibility has no operating consequence
3. Monitoring always fails visibly
4. More tags guarantee freshness

**Correct option(s):** 1

- Option 1: Correct. Observation failure can be hidden.
- Option 2: Incorrect. Diagnosis and response can depend on it.
- Option 3: Incorrect. Stale values can look plausible.
- Option 4: Incorrect. Quantity does not establish quality.

**CDCP-Q0487 · single · mechanism**

What should connect every acceptance claim to the requirement?

1. A traceable test or evidence record with scope and result
2. Only a total question-bank score
3. Only a general statement of confidence
4. Only an unexecuted test procedure

**Correct option(s):** 1

- Option 1: Correct. The conclusion must be auditable.
- Option 2: Incorrect. Knowledge assessment is not installed performance.
- Option 3: Incorrect. Confidence is not evidence.
- Option 4: Incorrect. A procedure defines intended verification but does not demonstrate the result.

**CDCP-Q0488 · single · mechanism**

Why include rejected actions in an acceptance plan?

1. Rejected actions cannot affect physical systems
2. Boundaries should prevent unsuitable commands or access
3. Negative tests replace all positive tests
4. Every rejection is a defect

**Correct option(s):** 2

- Option 1: Incorrect. Their prevention can protect the process.
- Option 2: Correct. Successful paths do not prove enforcement.
- Option 3: Incorrect. Both are needed.
- Option 4: Incorrect. Some are required.

**CDCP-Q0489 · single · diagnosis**

A restored controller runs the wrong logic revision. What remains incomplete?

Synthetic educational evidence; not field measurements.

Controller restored and running
Loaded logic revision: not the approved revision

1. The existence of a backup file
2. Basic processor power necessarily
3. Restoration of the approved functional state
4. Every network link necessarily

**Correct option(s):** 3

- Option 1: Incorrect. A file may exist but be unsuitable.
- Option 2: Incorrect. The controller is running.
- Option 3: Correct. Running software is not necessarily the correct software.
- Option 4: Incorrect. Connectivity can work.

**CDCP-Q0490 · single · mechanism**

Why assign owners to residual risks?

1. Remaining exposure needs accountable treatment or acceptance
2. Ownership removes the physical risk automatically
3. A green dashboard assigns authority
4. Risks only matter before procurement

**Correct option(s):** 1

- Option 1: Correct. It should not vanish at handover.
- Option 2: Incorrect. Action or explicit acceptance is still needed.
- Option 3: Incorrect. It does not.
- Option 4: Incorrect. They persist through operation.

**CDCP-Q0491 · single · mechanism**

Which test stimulus best supports a specific claim?

1. A simulated contact for every possible physical effect
2. One that exercises the required mechanism within a stated safe boundary
3. A screenshot without an event
4. Any stimulus with a similar name

**Correct option(s):** 2

- Option 1: Incorrect. That overextends fidelity.
- Option 2: Correct. The claim must match what was actually challenged.
- Option 3: Incorrect. It does not exercise behavior.
- Option 4: Incorrect. Mechanisms can differ.

**CDCP-Q0492 · single · mechanism**

Why include recovery in integrated acceptance?

1. Fault tolerance eliminates recovery needs
2. The first alarm marks test completion
3. Recovery happens automatically in every design
4. A system can survive a fault yet fail to return to the approved state

**Correct option(s):** 4

- Option 1: Incorrect. Degraded resources still need restoration.
- Option 2: Incorrect. Response and restoration remain.
- Option 3: Incorrect. It may need coordinated action.
- Option 4: Correct. Restoration is part of the lifecycle requirement.

**CDCP-Q0493 · single · mechanism**

What is a common-cause configuration failure?

1. One isolated component wears out
2. One erroneous approved or unauthorized change affects multiple paths
3. A spare is stored separately
4. Two devices have different serial numbers

**Correct option(s):** 2

- Option 1: Incorrect. That may be an independent failure.
- Option 2: Correct. Logical separation can share change authority.
- Option 3: Incorrect. That can reduce some common exposure.
- Option 4: Incorrect. Identity is not a cause.

**CDCP-Q0494 · single · mechanism**

Why compare intended and effective state?

1. Effective state can never be measured
2. Intent is always automatically enforced
3. Drawings are useless
4. Configuration, wiring or maintenance can drift from the design

**Correct option(s):** 4

- Option 1: Incorrect. It can be observed and tested.
- Option 2: Incorrect. It is not.
- Option 3: Incorrect. They provide a baseline for comparison.
- Option 4: Correct. Actual behavior governs service.

**CDCP-Q0495 · single · mechanism**

Which evidence is strongest for actual rack-feed failover under the test conditions?

1. A controlled physical loss with load and service measurements
2. A quiz answer
3. A vendor brochure alone
4. A topology calculation alone

**Correct option(s):** 1

- Option 1: Correct. It directly observes the required transition.
- Option 2: Incorrect. It demonstrates knowledge, not the installation.
- Option 3: Incorrect. It describes product capability within scope.
- Option 4: Incorrect. It supports feasibility but not actual behavior.

**CDCP-Q0496 · single · mechanism**

Why include human response in an integrated scenario?

1. A contact list proves successful response
2. Every event needs manual intervention
3. Some restoration and escalation functions require people
4. People replace all interlocks

**Correct option(s):** 3

- Option 1: Incorrect. Receipt and action need verification.
- Option 2: Incorrect. Some functions are automatic.
- Option 3: Correct. Technology alone may not complete the sequence.
- Option 4: Incorrect. Protection still needs engineered mechanisms.

**CDCP-Q0497 · single · mechanism**

A shared cooling controller is unavailable but all pumps have power. What remains uncertain?

1. Whether required control and flow behavior continue
2. Whether the pumps physically exist
3. Whether the room has racks
4. Whether current can be measured

**Correct option(s):** 1

- Option 1: Correct. Electrical power does not prove autonomous operation.
- Option 2: Incorrect. They are identified.
- Option 3: Incorrect. That is not the disputed dependency.
- Option 4: Incorrect. That is a separate function.

**CDCP-Q0498 · single · mechanism**

Why preserve exact test load and environment?

1. Results apply to the tested operating envelope
2. Load affects only billing
3. Environment matters only outdoors
4. A pass applies universally forever

**Correct option(s):** 1

- Option 1: Correct. Different demand or conditions can change outcomes.
- Option 2: Incorrect. It affects power and cooling behavior.
- Option 3: Incorrect. Indoor conditions also affect equipment.
- Option 4: Incorrect. It does not.

**CDCP-Q0499 · single · mechanism**

What does a complete facility-integration foundation still require for the intended identity?

1. Only memorizing certificate names
2. No further operational practice
3. Automatic authority over every specialty
4. Deeper network, controls, security and sustained practical lifecycle evidence

**Correct option(s):** 4

- Option 1: Incorrect. Titles do not establish capability.
- Option 2: Incorrect. Hands-on responsibility needs demonstrated work.
- Option 3: Incorrect. Scope and competence remain bounded.
- Option 4: Correct. A foundation course is one component of the programme.

**CDCP-Q0500 · single · mechanism**

Which final acceptance statement is most defensible?

1. No future defect is possible
2. Every certificate is automatically awarded
3. Named requirements passed with specified evidence, with unresolved items explicitly bounded
4. Everything is fully resilient because counts look redundant

**Correct option(s):** 3

- Option 1: Incorrect. Finite evidence cannot support that guarantee.
- Option 2: Incorrect. Providers have separate requirements.
- Option 3: Correct. It matches the actual assurance case.
- Option 4: Incorrect. Counts omit common causes.

#### Recall

**Two UPS units share one bypass bus. What must be assessed?**

The bypass as a common failure and maintenance domain Correct. Unit count alone does not establish independence.

**What does a state table add to a component list?**

It shows behavior and available resources across operating conditions Correct. Counts alone omit transitions and dependencies.

**A simulation is labeled production evidence. What is wrong?**

The claim exceeds the evidence category Correct. Modeled behavior is not observed production operation.

**When is hold an appropriate design-review decision?**

Mandatory evidence or prerequisites are unresolved Correct. The proposal may be viable but not yet acceptable.

**When is reject appropriate?**

A mandatory constraint is violated without an approved feasible resolution Correct. The proposal cannot be accepted as stated.

#### References

- [EPI CDCP public course syllabus](https://www.epi-ap.com/services/1/3/4)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)
- [NIST SP 800-82 Revision 3 — final OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
