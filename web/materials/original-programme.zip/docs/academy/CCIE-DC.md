# CCIE-DC — CCIE Data Center: expert mechanisms, integration and practical preparation

Original independent instruction and practice. Read the teaching, work the demonstrations and guided exercise, then attempt questions before reading their explanations. Independent tasks require your own evidence.

Source baseline: [CCIE Data Center v3.1 programme and equipment baseline](https://www.cisco.com/site/us/en/learn/training-certifications/certifications/datacenter/ccie-data-center/index.html) · v3.1 programme; equipment publication retrieved 2026-09-19 · checked 2026-09-19

Expert preparation builds on all five CCNP course modules. The programme page and official equipment list were retrieved; the interactive leaf-objective page returned CSS errors. Authored objective IDs below are not represented as official blueprint numbering.

## Scope and external requirements

- Complete official leaf-objective reconciliation remains unresolved because the topic page was inaccessible.

- Original analytical exhibits and independent vendor workbooks do not reproduce the Cisco examination or replace licensed platform practice.

- Current production features beyond the published baseline are identified as extension topics.

- Pass the applicable DCCOR qualifying examination and the provider-administered practical examination under current eligibility rules.

- Obtain lawful APIC/ACI, Nexus, UCS and SAN lab access with compatible software; an ordinary routing emulator cannot reproduce these whole platforms.

- Complete all five assigned CCNP teaching modules before expert preparation; use multiple unfamiliar integrated builds and independent assessment.

- Reconcile every official v3.1 leaf objective once the Cisco Learning Network topic page is accessible before claiming complete exam-blueprint coverage.

## Preparation

Prior courses: CCNP-DC

- CCNA-level dual-stack networking, Linux, Python and packet interpretation; lawful licensed vendor lab access for implementation.

## CCIE-DC-M01 — Underlay recursion, ECMP and packet-size failure

### CCIE-DC-L01 — Underlay recursion, ECMP and packet-size failure

Estimated study time: 180 minutes before independent work. Prerequisite chapters: Use the course prerequisites.

### Separate reachability from deliverability
A VXLAN fabric has at least two forwarding problems. The tenant lookup selects a remote endpoint or gateway; the underlay must then deliver an encapsulated packet to that VTEP. BGP EVPN being Established proves neither problem is solved. Trace the tenant route, encapsulation destination, recursive underlay next hop, adjacency and outgoing interface as separate state. A route reflector can maintain a session through one surviving path while other fabric paths have incompatible MTU or missing advertisements.

Start an underlay build with non-overlapping addressing, stable loopbacks, point-to-point interfaces, a deliberate IGP or eBGP design and explicit multipath policy. Record which address is the BGP update source and which is the tunnel source: they can be different. Advertise the actual tunnel endpoint, not merely the router ID. Verify the RIB and hardware FIB independently after convergence. If equal-cost paths exist, enumerate installed next hops and test enough flow hashes to exercise them; one successful ping may repeatedly select a healthy path.

### Encapsulation accounting
An inner 1500-byte IP packet also has an inner Ethernet header. With ordinary Ethernet VXLAN over outer IPv4, the underlay must carry approximately 1550 bytes at its IP layer when the original inner Ethernet header is included; additional tags and outer IPv6 change the calculation. Frame-size terminology differs between platforms. State whether a number is an IP MTU, payload length or wire frame size. An underlay set to 1500 cannot be assumed sufficient for an inner 1500 packet. Large packets may fail while control traffic survives. Do not turn off path-MTU discovery as a repair.

### Convergence is a sequence
Physical loss, failure detection, routing withdrawal, FIB programming and application retry each contribute delay. BFD can shorten detection but cannot repair a missing route or guarantee application continuity. Graceful restart can preserve stale forwarding while a control plane restarts; it is useful only when the preserved path still works. During maintenance, drain affected traffic, verify remaining capacity and adjacency, then withdraw the path. After restoration, compare forwarding and loss distribution with the baseline rather than just counting neighbors.

### Implementation walkthrough: prove the transport before the overlay
Use a licensed NX-OS 10.x lab whose feature support matches the chosen Nexus platform. The following are read-only command examples to adapt to the installed release; they were not executed on Cisco equipment here.

```text
show ip route 10.255.0.12
show forwarding ipv4 route 10.255.0.12
show interface ethernet1/1
show bgp l2vpn evpn summary
show nve peers
show nve vni
```
Build an evidence table with one row per destination VTEP and one column per eligible spine. Record route source, metric, recursive next hop, outgoing interface, IP MTU and a counter baseline. Do not put only the best-looking path into the record. If the route table selects two next hops but hardware installs one, investigate the installation or platform eligibility before interpreting traffic balance.

For the packet-size experiment, define the exact inner IP size first. Construct the outer-size calculation from inner Ethernet header, inner IP packet, VXLAN header, UDP header and outer IP header. Outer Ethernet framing is a separate accounting boundary. With an ordinary untagged inner Ethernet header and outer IPv4, 1500 bytes of inner IP plus 14 + 8 + 8 + 20 gives 1550 bytes of outer IP packet. An inner VLAN tag adds another 4 bytes; outer IPv6 adds 20 relative to outer IPv4. This arithmetic is a model, not a declaration that every device's configured `mtu` field uses that same boundary.

Send controlled flows with varied source/destination ports so ECMP can select different members. Capture or otherwise establish the actual selected path; do not assume an arbitrary number of probes sampled all hashes. Increase packet size in bounded steps and compare egress drops with the first failing size. A threshold tied to one path strongly supports a size constraint; loss at all sizes on a new spine suggests missing routing or policy instead.

Only after transport is correct should you enable the overlay service. Record a known-good baseline, then withdraw one spine and repeat the maximum-size test. The acceptance result is a table of path, size, loss and recovery time, with the actual load and measurement uncertainty. 'All peers Established' is retained as supporting control evidence, not the final pass criterion.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

**Reasoning:** First hold the tenant policy constant and vary packet size. Failure correlated with the Spine B hash and size implicates an underlay forwarding constraint rather than all tenant routes. An ordinary VXLAN packet carrying a 1500-byte inner IP packet needs an outer IP packet larger than 1500. Confirm the exact platform accounting, inspect per-interface drops, and probe each underlay path using the tunnel source. Raise MTU consistently only within the supported change plan, or lower the supported tenant MTU with endpoint agreement. Validate maximum intended size over each surviving path and repeat with one spine unavailable.

#### Guided practice

Add a third healthy spine but omit the route to Leaf 2’s VTEP on that spine. Predict what changes and propose two observations that distinguish the new defect from the existing MTU defect.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Small and large packets hashed through the third spine fail because recursion eventually lacks the VTEP route; the original Spine B defect remains size-dependent. Inspect the destination route/FIB on each spine and collect size-stratified losses. Increasing MTU on Spine B cannot fix the third-spine route omission.

#### Independent task

Environment: vendor

Build a two-spine underlay, prove tunnel-source reachability and maximum packet size on every path, then diagnose independent routing and MTU faults without flattening the design.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Every VTEP prefix has the intended installed next hops.
- Maximum-sized tenant traffic survives each single-spine maintenance test within an explicitly measured recovery bound.
- No unrelated tenant or management route is leaked.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0001 · single · implementation**

Which fact best explains selective large-flow loss?

SYNTHETIC TEACHING DATA — not captured from equipment.
NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

1. Path B cannot carry the encapsulated size
2. EVPN requires matching router IDs
3. Both tenants need the same route distinguisher

**Correct option(s):** 1

- Option 1: Correct. Outer packets exceed that path's IP MTU.
- Option 2: Incorrect. Router IDs should be unique, not equal.
- Option 3: Incorrect. RD equality does not enlarge packets.

**CCIE-DC-Q0002 · single · implementation**

Which source should an underlay reachability probe use?

SYNTHETIC TEACHING DATA — not captured from equipment.
NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

1. Only the management address
2. Only an arbitrary SVI
3. The tunnel-source address

**Correct option(s):** 3

- Option 1: Incorrect. Management may use a different VRF.
- Option 2: Incorrect. Its route may differ from tunnel recursion.
- Option 3: Correct. This exercises the endpoint actually used for encapsulation.

**CCIE-DC-Q0003 · single · implementation**

What does Established EVPN prove here?

SYNTHETIC TEACHING DATA — not captured from equipment.
NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

1. Every VNI is imported
2. All VXLAN data paths work
3. A BGP transport session exists

**Correct option(s):** 3

- Option 1: Incorrect. Import policy is separate from session state.
- Option 2: Incorrect. Data packets traverse different sizes and hashes.
- Option 3: Correct. It does not establish every data path's MTU.

**CCIE-DC-Q0004 · single · diagnosis**

Why can one large ping pass repeatedly?

SYNTHETIC TEACHING DATA — not captured from equipment.
NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

1. Its hash consistently selects Path A
2. MTU checks occur only on TCP
3. BGP repairs fragmented payloads

**Correct option(s):** 1

- Option 1: Correct. A single flow need not sample every ECMP member.
- Option 2: Incorrect. Forwarding MTU applies to IP packets generally.
- Option 3: Incorrect. BGP carries control information, not payload repair.

**CCIE-DC-Q0005 · single · implementation**

Which table confirms programmed forwarding after the RIB?

SYNTHETIC TEACHING DATA — not captured from equipment.
NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

1. The BGP neighbor description
2. The hardware FIB and adjacency state
3. The ARP timeout configuration alone

**Correct option(s):** 2

- Option 1: Incorrect. Descriptions are not forwarding state.
- Option 2: Correct. Control selection and hardware programming can diverge.
- Option 3: Incorrect. Configured aging does not establish route installation.

**CCIE-DC-Q0006 · single · implementation**

Which measurement isolates the size threshold?

SYNTHETIC TEACHING DATA — not captured from equipment.
NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

1. Controlled packet-size sweep per path
2. Only a daily average throughput
3. Only the neighbor uptime

**Correct option(s):** 1

- Option 1: Correct. Size correlation discriminates MTU from reachability.
- Option 2: Incorrect. Averages hide conditional failure.
- Option 3: Incorrect. Control uptime excludes neither defect.

**CCIE-DC-Q0007 · single · calculation**

What is the principal risk of adding the third spine without its VTEP route?

SYNTHETIC TEACHING DATA — not captured from equipment.
NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

1. Immediate removal of every BGP route
2. Duplicate EVPN router IDs automatically
3. Hash-dependent blackholing

**Correct option(s):** 3

- Option 1: Incorrect. One spine omission does not require total withdrawal.
- Option 2: Incorrect. No router-ID duplication was introduced.
- Option 3: Correct. New next-hop selection can reach an incomplete path.

**CCIE-DC-Q0008 · single · implementation**

Which repair has the narrowest justified scope?

SYNTHETIC TEACHING DATA — not captured from equipment.
NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

1. Align supported underlay MTU end to end
2. Disable all tenant segmentation
3. Clear every host ARP entry

**Correct option(s):** 1

- Option 1: Correct. The observed mismatch is in the transport path.
- Option 2: Incorrect. Segmentation does not impose this size limit.
- Option 3: Incorrect. ARP refresh does not increase MTU.

**CCIE-DC-Q0009 · single · implementation**

What must be stated when comparing vendor MTU numbers?

SYNTHETIC TEACHING DATA — not captured from equipment.
NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

1. Only the BGP autonomous system
2. Only the interface speed
3. Which headers each number includes

**Correct option(s):** 3

- Option 1: Incorrect. AS membership does not define frame size.
- Option 2: Incorrect. Speed does not define MTU accounting.
- Option 3: Correct. IP and frame-size accounting differ.

**CCIE-DC-Q0010 · single · implementation**

Which dependency remains after BFD detects failure?

SYNTHETIC TEACHING DATA — not captured from equipment.
NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

1. The failed fiber becomes usable
2. Route and hardware convergence
3. The application has already recovered

**Correct option(s):** 2

- Option 1: Incorrect. Detection does not repair hardware.
- Option 2: Correct. Detection is only the first stage.
- Option 3: Incorrect. Application recovery requires separate observation.

**CCIE-DC-Q0011 · single · implementation**

When can graceful restart prolong a blackhole?

SYNTHETIC TEACHING DATA — not captured from equipment.
NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

1. Only when every VTEP is down
2. When retained forwarding points to a failed path
3. Whenever a healthy peer sends keep a lives

**Correct option(s):** 2

- Option 1: Incorrect. A single stale path is sufficient.
- Option 2: Correct. Stale routes may survive control recovery.
- Option 3: Incorrect. Healthy keep a lives are not the failure condition.

**CCIE-DC-Q0012 · single · implementation**

Which acceptance condition is missing from small-ping success?

SYNTHETIC TEACHING DATA — not captured from equipment.
NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

1. Identical interface counters
2. Established EVPN sessions on both route reflectors
3. Maximum-sized application delivery

**Correct option(s):** 3

- Option 1: Incorrect. Different traffic volumes naturally produce different counts.
- Option 2: Incorrect. Those sessions can remain healthy while a large data packet exceeds one path MTU.
- Option 3: Correct. Small probes do not exercise encapsulation headroom.

**CCIE-DC-Q0013 · single · implementation**

Which condition can prevent ECMP despite two advertisements?

SYNTHETIC TEACHING DATA — not captured from equipment.
NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

1. Different interface descriptions
2. Unequal eligible metrics or policy
3. Different optic serial numbers

**Correct option(s):** 2

- Option 1: Incorrect. Descriptions do not decide equal-cost eligibility.
- Option 2: Correct. Multipath installation requires eligible paths.
- Option 3: Incorrect. Serial uniqueness is normal.

**CCIE-DC-Q0014 · single · implementation**

What distinguishes BGP update source from NVE source?

SYNTHETIC TEACHING DATA — not captured from equipment.
NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

1. They serve control transport and encapsulation respectively
2. They must always be identical
3. NVE source is the tenant host address

**Correct option(s):** 1

- Option 1: Correct. They can intentionally use different loopbacks.
- Option 2: Incorrect. That is a design choice, not a universal rule.
- Option 3: Incorrect. The VTEP is an infrastructure endpoint.

**CCIE-DC-Q0015 · single · implementation**

What should happen before removing Spine A for maintenance?

SYNTHETIC TEACHING DATA — not captured from equipment.
NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

1. Assume redundancy guarantees independence
2. Delete the tenant routes first
3. Verify Path B's capacity and MTU

**Correct option(s):** 3

- Option 1: Incorrect. Two links do not prove usable failover.
- Option 2: Incorrect. That disrupts service without repairing transport.
- Option 3: Correct. The surviving path is currently defective.

**CCIE-DC-Q0016 · single · implementation**

What does a route in the RIB but absent from the FIB suggest?

SYNTHETIC TEACHING DATA — not captured from equipment.
NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

1. A guaranteed DNS failure
2. Successful end-to-end forwarding
3. A programming or resource problem

**Correct option(s):** 3

- Option 1: Incorrect. DNS does not explain hardware route absence.
- Option 2: Incorrect. RIB presence alone is insufficient.
- Option 3: Correct. Selected control state may not reach hardware.

**CCIE-DC-Q0017 · single · implementation**

Which log correlation strengthens the MTU hypothesis?

SYNTHETIC TEACHING DATA — not captured from equipment.
NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

1. A BGP description change
2. Oversize drops on the selected egress
3. An unrelated login failure

**Correct option(s):** 2

- Option 1: Incorrect. Descriptions do not alter MTU.
- Option 2: Correct. It links size, location and failing traffic.
- Option 3: Incorrect. It has no causal relationship to packet size.

**CCIE-DC-Q0018 · single · implementation**

How should outer IPv6 alter the size calculation?

SYNTHETIC TEACHING DATA — not captured from equipment.
NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

1. Assume IPv6 fragments in every router
2. Subtract the inner Ethernet header
3. Use its larger base header

**Correct option(s):** 3

- Option 1: Incorrect. IPv6 transit routers do not fragment.
- Option 2: Incorrect. That header is still carried inside VXLAN.
- Option 3: Correct. Encapsulation overhead changes with outer protocol.

**CCIE-DC-Q0019 · single · diagnosis**

Which rollback evidence is required after MTU change?

SYNTHETIC TEACHING DATA — not captured from equipment.
NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

1. Only the maintenance ticket number
2. Only a successful save command
3. Restored configuration and repeated traffic tests

**Correct option(s):** 3

- Option 1: Incorrect. Administrative records cannot measure forwarding.
- Option 2: Incorrect. Saved intent does not show actual delivery.
- Option 3: Correct. Config restoration alone does not prove recovery.

**CCIE-DC-Q0020 · single · calculation**

What should a convergence budget include?

SYNTHETIC TEACHING DATA — not captured from equipment.
NX-OS 10.x conceptual lab. Leaf 1 VTEP 10.255.0.11; Leaf 2 VTEP 10.255.0.12. Two underlay next hops, Spine A and Spine B, are installed. Path A IP MTU 9216; Path B IP MTU 1500. Inner IPv4 payload packet length 1500. Small pings pass. Large tenant transfers fail for some flow hashes. EVPN sessions stay Established.

1. Only link negotiation
2. Detection, computation, programming and application recovery
3. Only BGP hold time

**Correct option(s):** 2

- Option 1: Incorrect. The failure may be above the physical layer.
- Option 2: Correct. Each stage can consume the outage budget.
- Option 3: Incorrect. Other stages can dominate.

#### Recall

**Which fact best explains selective large-flow loss?**

Path B cannot carry the encapsulated size Outer packets exceed that path's IP MTU.

**Which table confirms programmed forwarding after the RIB?**

The hardware FIB and adjacency state Control selection and hardware programming can diverge.

**What must be stated when comparing vendor MTU numbers?**

Which headers each number includes IP and frame-size accounting differ.

**Which condition can prevent ECMP despite two advertisements?**

Unequal eligible metrics or policy Multipath installation requires eligible paths.

**Which log correlation strengthens the MTU hypothesis?**

Oversize drops on the selected egress It links size, location and failing traffic.

#### References

- [Cisco Nexus configuration guides](https://www.cisco.com/c/en/us/support/switches/nexus-9000-series-switches/products-installation-and-configuration-guides-list.html)
- [EVPN overlay specification](https://www.rfc-editor.org/rfc/rfc8365.html)

## CCIE-DC-M02 — EVPN route import, symmetric IRB and endpoint movement

### CCIE-DC-L02 — EVPN route import, symmetric IRB and endpoint movement

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L01

### Reconstruct a tenant packet
A VTEP may learn a remote MAC/IP binding yet lack a tenant IP-prefix route, or import an IP prefix into the wrong VRF. Route distinguishers make otherwise identical BGP NLRIs unique; route targets express import/export membership. A unique RD does not authorize connectivity. Treat the L2 VNI, L3 VNI, VRF, bridge domain and route-target policy as a chain of references rather than interchangeable names.

In symmetric integrated routing and bridging, ingress and egress VTEPs both perform routing. The ingress routes into the tenant L3 VNI, encapsulates toward the remote router, and the egress routes toward the destination bridge domain. The receiving side needs the appropriate tenant routing context and router-MAC information. An anycast gateway gives locally attached hosts a consistent first hop, but its address/MAC settings must be coherent across participating leaves. It does not permit accidentally duplicated endpoint IP addresses.

An EVPN MAC/IP route supports endpoint reachability; an IP-prefix route supports prefix advertisement with its own resolution rules. Importing one type does not imply importing all required state. First inspect whether a route exists in the EVPN table, then whether policy imported it into the tenant table, then whether its next hop resolves, and finally whether hardware contains the expected route and adjacency. Troubleshooting in the reverse order wastes time on endpoints when the control-plane policy is already wrong.

### Movement and stale identity
A VM move changes attachment, not the application identity. Mobility sequence information helps receivers prefer the newer location. A higher sequence is not proof that the move was legitimate; repeated oscillation can indicate an actual duplicate, a loop or a misattached workload. Correlate local learning, controller placement and timestamped traffic before clearing state. Clearing all MAC tables may briefly mask the duplicate while destroying useful evidence.

For a migration, prepare the target VLAN/VNI and policy first, test an isolated endpoint, move one workload, observe withdrawal and advertisement, and validate bidirectional application traffic. Include silent hosts, ARP/ND refresh, old-path packets and rollback. Make route-target additions narrow: leaking every tenant prefix may restore one failed service while violating isolation.

### Implementation walkthrough: inspect four different route views
Prepare two VRFs with distinct approved route-target sets. Before configuring them, write a table containing VRF, L2 VNI, L3 VNI, gateway subnet, route distinguisher, import targets and export targets. Add a column for the owner who approved each cross-VRF leak. Empty approval means no leak. This makes a duplicated numeric value visible before it becomes an accidental relationship.

Illustrative NX-OS 10.x read-only observations include:

```text
show bgp l2vpn evpn
show ip route vrf BLUE
show nve vni
show nve peers
show mac address-table
show ip arp vrf BLUE
```
The exact per-route and hardware commands vary by platform/release. Save structured output when available, but preserve the original raw observation alongside parsed fields.

Trace a packet from 10.10.0.10 in BLUE subnet A to 10.20.0.20 in BLUE subnet B. At ingress, the host resolves the local anycast gateway and sends the frame to it. The leaf routes in BLUE, selects the remote route and tenant L3 VNI, and encapsulates toward the remote VTEP. At egress, decapsulation selects the tenant routing context; the egress routes to subnet B and resolves the destination adjacency. Label both inner and outer source/destination identities at every step. A route target controls whether control information joins the VRF; it is not the data-plane VNI carried in the packet.

Now deliberately change only the remote export RT in the isolated lab. Predict which table loses the prefix: it can remain in the global EVPN table while disappearing from BLUE. Restore the approved target, then remove the receiving L3-VNI association as a second independent fault. This time imported control state may look correct while decapsulation lacks its required local context. The two failures can look identical to the application but need different corrections.

For mobility, record old and new attachment, sequence information, local learning and workload-manager ownership. Move one test endpoint and verify withdrawal, new forwarding and negative isolation tests. If both locations continue sourcing the identity, stop migration expansion and investigate duplicate ownership rather than repeatedly clearing tables.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

**Reasoning:** The BLUE prefix is present in the global EVPN control table but its route target does not match BLUE import. Repair the intended export/import policy only after confirming the prefix belongs in BLUE; importing both tenant targets indiscriminately would widen access. Independently, the higher mobility sequence favors Leaf B for the MAC, but does not explain why both leaves continue learning it. Check workload attachment and duplicate-source traffic. Do not combine two unrelated faults into an underlay reset.

#### Guided practice

The prefix imports correctly after a policy repair but traffic still fails. The remote next hop is reachable and the L3 VNI is missing on the receiving leaf. Draw the packet lookup sequence and identify the missing context.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Ingress routing chooses the remote prefix and encapsulates using the tenant L3 VNI. The receiver cannot place that packet into the correct routing context without the required L3-VNI/VRF association. Repair the association, then validate routes, router-MAC resolution and actual traffic. BGP import alone was only one dependency.

#### Independent task

Environment: vendor

Implement two isolated EVPN tenants with symmetric routing, migrate an endpoint and recover a route-target defect while proving that the other tenant remains isolated.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Trace both routing lookups for inter-subnet traffic.
- No unintended route target is imported.
- Endpoint movement converges within a measured bound without duplicate ownership.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0021 · single · diagnosis**

Why is BLUE missing the advertised prefix?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

1. Its RD must equal every remote RD
2. Its import RT does not match
3. The VTEP loop back is unreachable

**Correct option(s):** 2

- Option 1: Incorrect. RDs provide uniqueness, not import membership.
- Option 2: Correct. The route exists but is excluded from this VRF.
- Option 3: Incorrect. The supplied probes explicitly establish reachability.

**CCIE-DC-Q0022 · single · implementation**

Which route property should be checked before importing 50200?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

1. The switch serial number
2. The endpoint's TCP source port
3. The prefix's intended tenant ownership

**Correct option(s):** 3

- Option 1: Incorrect. Hardware identity does not authorize a route leak.
- Option 2: Incorrect. Port choice does not establish routing ownership.
- Option 3: Correct. A broad import can create cross-tenant leakage.

**CCIE-DC-Q0023 · single · implementation**

What does the higher mobility sequence favor?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

1. Leaf B's newer advertisement
2. Both paths as duplicate application masters
3. Whichever leaf has lower latency

**Correct option(s):** 1

- Option 1: Correct. Sequence 9 supersedes sequence 7 for this comparison.
- Option 2: Incorrect. Forwarding preference does not authorize duplicate ownership.
- Option 3: Incorrect. Latency is not the stated mobility comparison.

**CCIE-DC-Q0024 · single · implementation**

Which observation challenges a legitimate one-time VM move?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

1. Continued source learning on both leaves
2. A preserved IP address
3. A single new advertisement

**Correct option(s):** 1

- Option 1: Correct. Persistent dual learning suggests duplicate or looped traffic.
- Option 2: Incorrect. Address preservation is a normal migration objective.
- Option 3: Incorrect. One update is expected during movement.

**CCIE-DC-Q0025 · single · implementation**

Which state distinguishes import failure from resolution failure?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

1. A VLAN description
2. Presence in the tenant RIB
3. A configured NTP server

**Correct option(s):** 2

- Option 1: Incorrect. Descriptions are not route state.
- Option 2: Correct. Absent import differs from an imported unresolved next hop.
- Option 3: Incorrect. Time configuration does not identify import outcome.

**CCIE-DC-Q0026 · single · implementation**

What does symmetric IRB require at the egress?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

1. A tenant routing context for the L3 VNI
2. A shared tenant route target for every tenant
3. Only the ingress leaf to know all destination VLANs

**Correct option(s):** 1

- Option 1: Correct. The egress performs the second routing lookup.
- Option 2: Incorrect. That would undermine separation.
- Option 3: Incorrect. That describes a different dependency model.

**CCIE-DC-Q0027 · single · diagnosis**

Why is anycast gateway consistency important?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

1. It removes the need for an underlay
2. Hosts retain a coherent local first hop
3. It authenticates endpoint ownership

**Correct option(s):** 2

- Option 1: Incorrect. Encapsulated delivery still requires transport.
- Option 2: Correct. Inconsistent gateway identity can break neighbor resolution.
- Option 3: Incorrect. Gateway consistency does not authenticate a VM.

**CCIE-DC-Q0028 · single · calculation**

What is the narrow first repair for the supplied prefix fault?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

1. Disable VRF separation globally
2. Correct the intended RT relationship
3. Restart every host

**Correct option(s):** 2

- Option 1: Incorrect. That discards the requirement.
- Option 2: Correct. The evidence isolates policy membership.
- Option 3: Incorrect. Hosts do not control EVPN import policy.

**CCIE-DC-Q0029 · single · implementation**

Which route normally carries a MAC/IP endpoint advertisement?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

1. EVPN type 3 alone
2. A default route alone
3. EVPN type 2

**Correct option(s):** 3

- Option 1: Incorrect. Type 3 supports inclusive multicast membership.
- Option 2: Incorrect. A default does not express this endpoint binding.
- Option 3: Correct. It advertises endpoint binding information.

**CCIE-DC-Q0030 · single · implementation**

Which route represents an IP prefix in the relevant extension?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

1. An LLDP neighbor entry
2. EVPN type 5
3. A spanning-tree BPDU

**Correct option(s):** 2

- Option 1: Incorrect. LLDP is local adjacency discovery.
- Option 2: Correct. It advertises prefix reachability with resolution requirements.
- Option 3: Incorrect. BPD Us do not advertise tenant IP prefixes.

**CCIE-DC-Q0031 · single · implementation**

What proves a repaired control policy actually forwards?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

1. Only an EVPN peer uptime
2. Only a successful policy commit
3. Tenant application traffic plus hardware state

**Correct option(s):** 3

- Option 1: Incorrect. Session health predates the failure.
- Option 2: Incorrect. Commit confirms accepted intent.
- Option 3: Correct. Imported routes alone are insufficient.

**CCIE-DC-Q0032 · single · diagnosis**

Why preserve old advertisements before clearing them?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

1. They reveal movement and competing ownership
2. They provide the tenant encryption key
3. They permanently prevent convergence

**Correct option(s):** 1

- Option 1: Correct. Sequence and origin support causal diagnosis.
- Option 2: Incorrect. EVPN advertisements are not encryption keys.
- Option 3: Incorrect. Observation does not force stale forwarding.

**CCIE-DC-Q0033 · single · implementation**

Which element identifies VXLAN's forwarding segment?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

1. The BGP neighbor password
2. The VNI
3. The RD alone

**Correct option(s):** 2

- Option 1: Incorrect. Authentication does not label data segments.
- Option 2: Correct. The encapsulation carries segment identity.
- Option 3: Incorrect. RD belongs to control-plane route uniqueness.

**CCIE-DC-Q0034 · single · implementation**

Which migration test covers a silent endpoint?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

1. Only transmit continuously from every VM
2. Only check CPU utilization
3. Observe neighbor refresh and first inbound delivery

**Correct option(s):** 3

- Option 1: Incorrect. Continuous traffic hides silent-host behavior.
- Option 2: Incorrect. CPU does not establish endpoint resolution.
- Option 3: Correct. Silent hosts may not immediately advertise by sending.

**CCIE-DC-Q0035 · single · calculation**

What is the risk of importing all tenant route targets?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

1. Automatically stronger endpoint authentication
2. Unintended cross-tenant reachability
3. Guaranteed elimination of duplicate IPs

**Correct option(s):** 2

- Option 1: Incorrect. Import policy does not authenticate endpoints.
- Option 2: Correct. Route visibility expands beyond the approved matrix.
- Option 3: Incorrect. Routing visibility does not remove duplicates.

**CCIE-DC-Q0036 · single · diagnosis**

Which evidence separates duplicate IP from stale remote MAC state?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

1. Only a single remote route age
2. Local source observations and workload ownership
3. Only the configured gateway address

**Correct option(s):** 2

- Option 1: Incorrect. Age alone cannot prove ownership.
- Option 2: Correct. They establish whether two live origins exist.
- Option 3: Incorrect. Gateway intent does not locate duplicate endpoints.

**CCIE-DC-Q0037 · single · implementation**

What must accompany a type-5 route for forwarding?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

1. An imported prefix without resolved next-hop state
2. An identical RD on all leaves
3. Resolvable next-hop and tenant context

**Correct option(s):** 3

- Option 1: Incorrect. Import is necessary but unresolved forwarding cannot deliver the packet.
- Option 2: Incorrect. RD equality is not a forwarding prerequisite.
- Option 3: Correct. Control presence alone is not a data path.

**CCIE-DC-Q0038 · single · diagnosis**

Why test the return direction separately?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

1. Policy and routing can be asymmetric
2. VXLAN always uses the same physical path both ways
3. TCP A CK s bypass the fabric

**Correct option(s):** 1

- Option 1: Correct. One-way success does not imply reverse reachability.
- Option 2: Incorrect. Hashing and policy can differ.
- Option 3: Incorrect. A CK s still need forwarding.

**CCIE-DC-Q0039 · single · implementation**

What does missing receiving L3-VNI association break?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

1. Every underlay BGP session necessarily
2. Decapsulation into the intended VRF
3. The physical link's optical budget

**Correct option(s):** 2

- Option 1: Incorrect. Underlay control can remain healthy.
- Option 2: Correct. The packet lacks its required local routing context.
- Option 3: Incorrect. Logical mapping does not alter optics.

**CCIE-DC-Q0040 · single · implementation**

Which post-migration acceptance statement is defensible?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic EVPN summary. Tenant BLUE uses L2 VNI 10100, L3 VNI 50100, import RT 65000:50100. Remote prefix 10.20.0.0/24 exists in EVPN with RT 65000:50200. MAC aa:bb:cc:00:00:01 appears on Leaf A sequence 7 and Leaf B sequence 9. Underlay reachability to both VTEPs passes. All records are conceptual, not literal vendor output.

1. All future moves will be lossless
2. Application recovery met the measured bound in tested conditions
3. Sequence growth proves authorized migration

**Correct option(s):** 2

- Option 1: Incorrect. Finite tests cannot establish that universal claim.
- Option 2: Correct. Evidence supports a scoped result.
- Option 3: Incorrect. Sequence values do not establish authorization.

#### Recall

**Why is BLUE missing the advertised prefix?**

Its import RT does not match The route exists but is excluded from this VRF.

**Which state distinguishes import failure from resolution failure?**

Presence in the tenant RIB Absent import differs from an imported unresolved next hop.

**Which route normally carries a MAC/IP endpoint advertisement?**

EVPN type 2 It advertises endpoint binding information.

**Which element identifies VXLAN's forwarding segment?**

The VNI The encapsulation carries segment identity.

**What must accompany a type-5 route for forwarding?**

Resolvable next-hop and tenant context Control presence alone is not a data path.

#### References

- [Cisco Nexus configuration guides](https://www.cisco.com/c/en/us/support/switches/nexus-9000-series-switches/products-installation-and-configuration-guides-list.html)
- [EVPN overlay specification](https://www.rfc-editor.org/rfc/rfc8365.html)

## CCIE-DC-M03 — vPC state transitions and failure containment

### CCIE-DC-L03 — vPC state transitions and failure containment

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L02

A vPC makes two switches appear as one logical LACP peer for selected downstream links, while the switches retain separate control planes. The peer-link exchanges synchronization and carries traffic that requires the other peer; the keep alive independently helps discriminate peer failure from peer-link failure. They serve different purposes. Put keep alive transport on a path whose failure is not identical to the peer-link's failure, and document routing/VRF dependencies.

Build the domain and peer adjacency before attaching production vPC members. Compare global and interface consistency, VLAN availability, port-channel membership, LACP state and spanning-tree behavior. A configuration can exist on both peers but differ in a parameter that causes a member to suspend. The relevant question is whether both the control and hardware states permit this particular VLAN and member.

Failure behavior depends on which peer is primary, whether keep alive remains reachable, the order of losses and configured recovery features. Do not memorize 'vPC survives one failure' as a universal rule. Peer-link failure with a living peer typically makes the secondary suspend affected vPC forwarding to prevent dual-active behavior. Losing keep alive alone while the peer-link remains usable is a different condition. Simultaneous or sequential loss of both paths requires a platform-specific state-machine analysis. Orphan ports are single-attached and can be affected differently from vPC members.

Peer-gateway and related routing features solve particular MAC/routing interactions; they do not turn arbitrary unsupported routed topologies into supported designs. Test peer failure, individual member loss, peer-link loss, keep alive loss and recovery as separate events. Retain console access and application evidence, because management reachability may share the same broken dependency.

### Implementation walkthrough: create a failure-state matrix
Create columns for peer-link, keepalive, peer A power, peer B power, primary/secondary role, vPC member state, orphan state and application outcome. Populate expected behavior from the installed release's vPC guide before injecting faults. Include event order explicitly: losing keepalive then peer-link is not the same observation history as peer-link loss with confirmed peer liveness.

Read-only examples for a supported NX-OS lab are:

```text
show vpc brief
show vpc consistency-parameters global
show vpc consistency-parameters interface port-channel20
show port-channel summary
show interface port-channel1
show spanning-tree vlan 120
```
A sample analytical record might read: `peer-link down; keepalive alive; local role secondary; Po20 suspended; orphan Eth1/20 link up`. That is synthetic state, not captured CLI output. Explain why a physically up orphan port may still lack its intended path when the peer-link is unavailable. Do not infer that every connected endpoint is protected merely because it is cabled to the vPC pair.

Build the peer relationship first, verify consistency, then attach a disposable test server using the agreed LACP behavior. Confirm VLAN 120 on both member paths and on every necessary trunk. Introduce a one-sided VLAN omission and observe the precise consistency/member result before restoring it. The point of the exercise is to learn which state enforces protection, not to suppress the alarm until traffic passes.

For the failure campaign, run a sequence-numbered application stream and collect both loss and duplicate delivery. Test each member cable, keepalive-only loss, peer-link-only loss, full peer loss and restoration. Keep an independent console path. After each event, return to a verified baseline before the next test so failure history does not become an uncontrolled variable.

A successful design report includes the supported configuration, actual transition observations and the workload's interruption bound. If the lab cannot reproduce a dual-failure state safely or faithfully, mark it unexecuted and retain the vendor procedure as a future gate; do not invent a passing result.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

**Reasoning:** There are two defects. VLAN inconsistency can already prevent equivalent forwarding. Peer-link loss with keep alive up then provides evidence that A is alive, so B must avoid dual-active vPC forwarding. The orphan appliance has a separate attachment and cannot be assumed protected by the server vPC. Repair consistency and peer-link transport separately.

#### Guided practice

Draw expected traffic paths for keep alive-only loss, then for peer-link-only loss. Identify what additional evidence is needed if both disappear.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Keep alive-only loss does not itself prove peer failure when the peer-link is healthy. Peer-link-only loss with a reachable primary drives protection on the secondary. If both disappear, order, role and recovery configuration matter; use the documented release state machine and console evidence.

#### Independent task

Environment: vendor

Commission a supported vPC pair and independently test peer-link, keep alive, member, orphan-port and full-peer failure with explicit recovery limits.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- No unintended dual-active forwarding.
- VLAN and port-channel consistency verified.
- Orphan-port dependencies documented and tested.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0041 · single · diagnosis**

Why is keep alive retained separately?

SYNTHETIC TEACHING DATA — not captured from equipment.
Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

1. To replace LACP negotiation
2. To distinguish peer liveness
3. To carry all synchronized VLAN traffic

**Correct option(s):** 2

- Option 1: Incorrect. LACP remains separate.
- Option 2: Correct. Peer-link loss need not mean peer death.
- Option 3: Incorrect. That is not keep alive's role.

**CCIE-DC-Q0042 · single · implementation**

What does B learn from live keep alive?

SYNTHETIC TEACHING DATA — not captured from equipment.
Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

1. Every VLAN is consistent
2. A has lost all forwarding
3. A is still reachable

**Correct option(s):** 3

- Option 1: Incorrect. Live ness is not consistency.
- Option 2: Incorrect. Keep alive alone cannot establish that.
- Option 3: Correct. Dual-active prevention remains necessary.

**CCIE-DC-Q0043 · single · implementation**

Which initial defect affects VLAN 120?

SYNTHETIC TEACHING DATA — not captured from equipment.
Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

1. Asymmetric VLAN membership
2. A different primary and secondary role
3. Identical LACP identity

**Correct option(s):** 1

- Option 1: Correct. B lacks the permitted VLAN.
- Option 2: Incorrect. Different roles are expected; the explicit VLAN omission is the configuration defect.
- Option 3: Incorrect. Shared identity is intentional.

**CCIE-DC-Q0044 · single · calculation**

What is the orphan-port risk?

SYNTHETIC TEACHING DATA — not captured from equipment.
Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

1. Its path lacks the server's dual attachment
2. It has no MAC address
3. It automatically joins Po 20

**Correct option(s):** 1

- Option 1: Correct. Protection cannot be inferred from Po 20.
- Option 2: Incorrect. Single attachment does not remove MACs.
- Option 3: Incorrect. Membership is explicit.

**CCIE-DC-Q0045 · single · implementation**

Which failure test is distinct from peer-link loss?

SYNTHETIC TEACHING DATA — not captured from equipment.
Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

1. Renaming Po 1
2. Keep alive-only loss
3. Changing a ticket number

**Correct option(s):** 2

- Option 1: Incorrect. A description is not a failure.
- Option 2: Correct. The available liveness evidence differs.
- Option 3: Incorrect. No forwarding state changes.

**CCIE-DC-Q0046 · single · implementation**

What should precede host attachment?

SYNTHETIC TEACHING DATA — not captured from equipment.
Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

1. Peer and consistency verification
2. Clearing every server disk
3. Disabling all loop prevention

**Correct option(s):** 1

- Option 1: Correct. A healthy foundation avoids exposing inconsistencies.
- Option 2: Incorrect. Storage content is unrelated.
- Option 3: Incorrect. That creates additional risk.

**CCIE-DC-Q0047 · single · diagnosis**

Why inspect both logical and physical members?

SYNTHETIC TEACHING DATA — not captured from equipment.
Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

1. A logical link proves optical health
2. LACP always ignores members
3. One member can be suspended

**Correct option(s):** 3

- Option 1: Incorrect. It cannot prove every optic.
- Option 2: Incorrect. Members carry actual traffic.
- Option 3: Correct. Port-channel intent may hide member failure.

**CCIE-DC-Q0048 · single · implementation**

Which change improves independence?

SYNTHETIC TEACHING DATA — not captured from equipment.
Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

1. Use identical interface descriptions
2. Separate keep alive failure dependencies
3. Put both paths on one cable bundle

**Correct option(s):** 2

- Option 1: Incorrect. Labels do not create independence.
- Option 2: Correct. Shared transport defeats discrimination.
- Option 3: Incorrect. That adds common cause.

**CCIE-DC-Q0049 · single · implementation**

What does peer-gateway solve?

SYNTHETIC TEACHING DATA — not captured from equipment.
Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

1. Storage multipathing ownership
2. All unsupported L3 designs
3. Specific peer-MAC forwarding behavior

**Correct option(s):** 3

- Option 1: Incorrect. That belongs to host/storage layers.
- Option 2: Incorrect. Support constraints still apply.
- Option 3: Correct. It is a scoped forwarding feature.

**CCIE-DC-Q0050 · single · diagnosis**

Which evidence best proves host continuity?

SYNTHETIC TEACHING DATA — not captured from equipment.
Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

1. Application traffic during each failure
2. Only Po 20 configured up
3. Only switch uptime

**Correct option(s):** 1

- Option 1: Correct. Protocol state alone misses service loss.
- Option 2: Incorrect. Intent is not forwarding.
- Option 3: Incorrect. Uptime excludes neither defect.

**CCIE-DC-Q0051 · single · diagnosis**

Why preserve failure order?

SYNTHETIC TEACHING DATA — not captured from equipment.
Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

1. Order changes Ethernet addresses automatically
2. It replaces software-version checks
3. Recovery decisions depend on observed state

**Correct option(s):** 3

- Option 1: Incorrect. No such general rule exists.
- Option 2: Incorrect. Release behavior still matters.
- Option 3: Correct. Sequential loss differs from isolated loss.

**CCIE-DC-Q0052 · single · implementation**

Which case requires separate testing?

SYNTHETIC TEACHING DATA — not captured from equipment.
Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

1. Only a second identical ping
2. A full peer reboot
3. Changing an interface label

**Correct option(s):** 2

- Option 1: Incorrect. That adds little coverage.
- Option 2: Correct. It differs from losing one inter-peer path.
- Option 3: Incorrect. It is not a forwarding fault.

**CCIE-DC-Q0053 · single · implementation**

What should a consistency alarm trigger?

SYNTHETIC TEACHING DATA — not captured from equipment.
Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

1. Disable the alarm immediately
2. Inspect the specific conflicting parameter
3. Assume a failed transceiver

**Correct option(s):** 2

- Option 1: Incorrect. That hides the cause.
- Option 2: Correct. The category identifies a real dependency.
- Option 3: Incorrect. Configuration mismatch is different.

**CCIE-DC-Q0054 · single · implementation**

What makes vPC logical rather than one chassis?

SYNTHETIC TEACHING DATA — not captured from equipment.
Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

1. Every orphan becomes dual-homed
2. Independent control planes remain
3. One shared CPU executes all protocols

**Correct option(s):** 2

- Option 1: Incorrect. Attachment remains physical.
- Option 2: Correct. Shared LACP presentation does not merge everything.
- Option 3: Incorrect. That is not this architecture.

**CCIE-DC-Q0055 · single · diagnosis**

Why test VLAN 120 specifically?

SYNTHETIC TEACHING DATA — not captured from equipment.
Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

1. A different VLAN may still pass
2. VLAN numbers determine optic power
3. All VLANs share one route target

**Correct option(s):** 1

- Option 1: Correct. Allowed lists are per-VLAN constraints.
- Option 2: Incorrect. No such dependency exists.
- Option 3: Incorrect. vPC VLAN membership is not EVPN import.

**CCIE-DC-Q0056 · single · implementation**

Which rollback asset is critical?

SYNTHETIC TEACHING DATA — not captured from equipment.
Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

1. Only the server LACP configuration
2. Only one peer configuration
3. Known-good peer and member configuration

**Correct option(s):** 3

- Option 1: Incorrect. The peer and switch-side member configuration also determine the restored state.
- Option 2: Incorrect. Both peers participate in consistency and recovery; one side alone is incomplete.
- Option 3: Correct. Both sides participate in consistency.

**CCIE-DC-Q0057 · single · implementation**

What does loss of management over the peer-link imply?

SYNTHETIC TEACHING DATA — not captured from equipment.
Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

1. Both peers must be powered off
2. Server disks are corrupt
3. Out-of-band access may be needed

**Correct option(s):** 3

- Option 1: Incorrect. Management loss does not prove that.
- Option 2: Incorrect. No integrity evidence is supplied.
- Option 3: Correct. The diagnostic path shares the fault.

**CCIE-DC-Q0058 · single · diagnosis**

Why is two links not enough to claim resilience?

SYNTHETIC TEACHING DATA — not captured from equipment.
Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

1. Any two links guarantee no loss
2. They may share failure dependencies
3. LACP forbids multiple links

**Correct option(s):** 2

- Option 1: Incorrect. Convergence can still interrupt service.
- Option 2: Correct. Count does not prove independence.
- Option 3: Incorrect. Aggregation uses multiple links.

**CCIE-DC-Q0059 · single · implementation**

Which maintenance step reduces surprise?

SYNTHETIC TEACHING DATA — not captured from equipment.
Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

1. Reboot both peers together
2. Clear all evidence counters
3. Validate the surviving path first

**Correct option(s):** 3

- Option 1: Incorrect. That removes both paths.
- Option 2: Incorrect. That destroys the baseline.
- Option 3: Correct. A latent defect can surface during withdrawal.

**CCIE-DC-Q0060 · single · implementation**

What should be measured during restoration?

SYNTHETIC TEACHING DATA — not captured from equipment.
Conceptual NX-OS 10.x vPC: A primary, B secondary. Peer-link Po 1 fails at 10:00; keep alive remains reachable. Server uses LACP Po 20 to A/B. Single-attached storage appliance sits on B Ethernet 1/20. VLAN 120 allowed on A Po 20 but absent on B Po 20.

1. Loss, state transitions and duplicate forwarding
2. Only purchase price
3. Only the final green icon

**Correct option(s):** 1

- Option 1: Correct. Recovery can fail even after links return.
- Option 2: Incorrect. Cost does not measure convergence.
- Option 3: Incorrect. Transient errors remain hidden.

#### Recall

**Why is keep alive retained separately?**

To distinguish peer liveness Peer-link loss need not mean peer death.

**Which failure test is distinct from peer-link loss?**

Keep alive-only loss The available liveness evidence differs.

**What does peer-gateway solve?**

Specific peer-MAC forwarding behavior It is a scoped forwarding feature.

**What should a consistency alarm trigger?**

Inspect the specific conflicting parameter The category identifies a real dependency.

**What does loss of management over the peer-link imply?**

Out-of-band access may be needed The diagnostic path shares the fault.

#### References

- [Cisco Nexus vPC and interface guides](https://www.cisco.com/c/en/us/support/switches/nexus-9000-series-switches/products-installation-and-configuration-guides-list.html)

## CCIE-DC-M04 — Multicast, BUM replication and tenant containment

### CCIE-DC-L04 — Multicast, BUM replication and tenant containment

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L03

Broadcast, unknown unicast and multicast traffic require a replication mechanism; known unicast normally uses a specific remote endpoint. Ingress replication places replication work at the source VTEP. Underlay multicast distributes copies through multicast trees. Neither removes the need to constrain membership or size the egress and replication resources. Calculate offered copies at the actual replication point rather than comparing only the original stream rate with one link.

Separate host group membership from underlay multicast membership. IGMP or MLD reports describe interested receivers, while PIM establishes multicast forwarding state between routers. A snooping bridge also needs a coherent querier arrangement so membership does not age unpredictably. An RP is relevant to applicable shared-tree mechanisms, while source-specific multicast uses explicit source/group relationships. Reverse-path checks use the route toward the source; a unicast change can therefore break multicast even when receiver-facing links remain healthy.

In EVPN, inclusive multicast information helps identify remote replication participants. Do not infer that all VNIs should replicate to all VTEPs. An overly broad list wastes bandwidth and can violate intended tenant boundaries. Unknown-unicast flooding also differs from a policy that suppresses or drops unresolved destinations; silent-host behavior must be considered explicitly.

Troubleshoot in sequence: application source and group, receiver membership, snooping state, routed multicast state, RPF interface, replication list and packet counters. Change one layer only after identifying the missing state. A source ping does not establish multicast delivery. Commission joins, leaves, failover and no-receiver behavior, then quantify the rate and burst consequences of a membership storm.

### Implementation walkthrough: follow source, membership and replication separately
Make three maps: application source/group membership, underlay multicast forwarding and EVPN VNI replication participation. Keep them separate until the packet walk shows where they interact. A host joining a group does not itself establish every routed multicast hop, and a VTEP joining a VNI does not authorize every tenant to receive it.

For a supported NX-OS multicast lab, adapt these read-only observations:

```text
show ip igmp groups
show ip igmp snooping groups
show ip mroute
show ip pim neighbor
show ip route <source-address>
show nve vni
```
Record source(S), group(G), incoming interface, outgoing list, receiver count, querier and expected aging. For a wrong-RPF fault, compare the interface on which packets actually arrive with the route toward S. A receiver-facing route is not the RPF lookup. Change the source route in the isolated lab and predict the new incoming-interface expectation before collecting output.

For ingress replication, calculate copies at the source leaf. Eight remote destinations receiving 2 Gbit/s each create 16 Gbit/s of replicated payload demand, before headers and local delivery. For underlay multicast, calculate where the tree branches and which links carry one versus multiple copies. Neither design is automatically superior: the choice depends on supported scale, receiver distribution, underlay complexity and failure requirements.

Remove the only querier in a controlled VLAN and observe membership aging over the configured interval. Do not declare immediate success simply because traffic continues briefly; retained state can outlive the failure. Restore the querier and measure join/recovery behavior. Then test no-receiver state and confirm whether the intended design stops unnecessary traffic.

Acceptance includes source sequence/loss at receivers, forbidden-tenant absence, bounded convergence and replication load under the largest approved membership set. Preserve the rate units and distinction between original application payload and wire traffic so capacity calculations remain reviewable.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

**Reasoning:** Ingress replication produces eight remote copies, nominally 16 Gbit/s before overhead; the stated headroom cannot carry that offered load. Independently, lost queries can age receiver membership, and Router R can fail RPF because the actual ingress differs from the source-facing route. Treat capacity, membership and RPF as separate faults.

#### Guided practice

Keep the 2 Gbit/s source but reduce interested remote VTEPs to three. Then move the unicast route toward the multicast source. Predict both capacity and RPF effects.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Three copies offer roughly 6 Gbit/s before overhead and bursts. RPF may now select a different incoming interface; only a source-facing route consistent with actual arrival supports forwarding. Lower replication load does not fix a wrong RPF interface.

#### Independent task

Environment: vendor

Design and test tenant BUM delivery with bounded replication, membership aging and source-route changes.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Calculate replication at each constrained link.
- Receiver join/leave and querier loss are observed.
- Uninterested tenants receive no copies.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0061 · single · implementation**

How much remote replication is offered?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

1. 16 Gbit/s before overhead
2. 8 Mbit/s
3. 2 Gbit/s total

**Correct option(s):** 1

- Option 1: Correct. Eight copies multiply the 2-Gbit/s source.
- Option 2: Incorrect. Units and multiplication are wrong.
- Option 3: Incorrect. That ignores replicated copies.

**CCIE-DC-Q0062 · single · implementation**

Which limit is immediately exceeded?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

1. The number of VRFs
2. The 10-Gbit/s headroom
3. The source's 2-Gbit/s rate

**Correct option(s):** 2

- Option 1: Incorrect. No VRF limit is supplied.
- Option 2: Correct. Offered copies total 16 Gbit/s.
- Option 3: Incorrect. That is the original rate, not the limit.

**CCIE-DC-Q0063 · single · diagnosis**

Why may snooping entries disappear?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

1. The VNI automatically expires
2. PIM encrypts the reports
3. Queries no longer refresh membership

**Correct option(s):** 3

- Option 1: Incorrect. VNI identity is not timed this way.
- Option 2: Incorrect. PIM does not encrypt IGMP reports.
- Option 3: Correct. Querier removal affects aging.

**CCIE-DC-Q0064 · single · diagnosis**

Why does Router R reject the incoming stream?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

1. The receiver has too many TCP sessions
2. It arrives on the wrong RPF interface
3. Its destination is necessarily unicast

**Correct option(s):** 2

- Option 1: Incorrect. No TCP dependency is supplied.
- Option 2: Correct. Source-route state expects Ethernet 1/1.
- Option 3: Incorrect. The case specifies multicast.

**CCIE-DC-Q0065 · single · implementation**

Which state first identifies interested hosts?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

1. A BGP keep alive
2. An ARP entry alone
3. IGMP or MLD membership

**Correct option(s):** 3

- Option 1: Incorrect. It does not signal host group interest.
- Option 2: Incorrect. ARP resolves unicast neighbors.
- Option 3: Correct. Host interest differs from routed tree state.

**CCIE-DC-Q0066 · single · implementation**

Which mechanism distributes routed multicast trees?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

1. LACP
2. LLDP
3. PIM in the stated design

**Correct option(s):** 3

- Option 1: Incorrect. LACP aggregates links.
- Option 2: Incorrect. LLDP discovers adjacent devices.
- Option 3: Correct. It coordinates routed multicast forwarding.

**CCIE-DC-Q0067 · single · implementation**

What changes under source-specific multicast?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

1. Every tenant becomes one group
2. RPF disappears
3. Receiver state identifies source and group

**Correct option(s):** 3

- Option 1: Incorrect. Tenant separation still matters.
- Option 2: Incorrect. Source-facing validation still matters.
- Option 3: Correct. A shared-tree RP need not serve that flow.

**CCIE-DC-Q0068 · single · implementation**

Which observation tests application delivery?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

1. Only source CPU usage
2. A unicast source ping
3. Receiver sequence and loss counters

**Correct option(s):** 3

- Option 1: Incorrect. It does not locate packet delivery.
- Option 2: Incorrect. It exercises another forwarding mechanism.
- Option 3: Correct. They reveal delivered multicast data.

**CCIE-DC-Q0069 · single · implementation**

What limits ingress replication cost?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

1. The DHCP lease duration
2. Only the number of locally attached receivers
3. The actual remote replication set

**Correct option(s):** 3

- Option 1: Incorrect. It does not determine replication membership.
- Option 2: Incorrect. Remote VTEP copies create the stated ingress-replication load.
- Option 3: Correct. Each destination adds copies.

**CCIE-DC-Q0070 · single · diagnosis**

Why isolate VNIs in replication policy?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

1. To eliminate all broadcasts universally
2. To preserve tenant boundaries
3. To make RPF unnecessary

**Correct option(s):** 2

- Option 1: Incorrect. Some tenant functions still need discovery.
- Option 2: Correct. Unintended participants widen delivery.
- Option 3: Incorrect. RPF belongs to routed multicast behavior.

**CCIE-DC-Q0071 · single · implementation**

Which event can change RPF without link failure?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

1. A unicast route change toward the source
2. Only a receiver IGMP membership refresh
3. A log-retention change

**Correct option(s):** 1

- Option 1: Correct. RPF uses source-facing route information.
- Option 2: Incorrect. Receiver membership affects outgoing interest, not the route toward the source used for RPF.
- Option 3: Incorrect. Storage policy does not route packets.

**CCIE-DC-Q0072 · single · design**

What is required for a silent-host design?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

1. A common administrator password
2. An explicit unresolved-destination policy
3. Continuous transmission from every host

**Correct option(s):** 2

- Option 1: Incorrect. Credentials do not discover hosts.
- Option 2: Correct. Suppression may affect first delivery.
- Option 3: Incorrect. That avoids rather than solves silent-host behavior.

**CCIE-DC-Q0073 · single · implementation**

Which metric detects a membership storm?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

1. Join/leave rates and replication load
2. Only cabinet temperature
3. Only cumulative uptime

**Correct option(s):** 1

- Option 1: Correct. State churn and copies are causal signals.
- Option 2: Incorrect. It does not establish membership churn.
- Option 3: Incorrect. Uptime hides traffic behavior.

**CCIE-DC-Q0074 · single · implementation**

What should leave testing verify?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

1. The source shuts down permanently
2. Every VNI is deleted
3. Unneeded forwarding eventually stops

**Correct option(s):** 3

- Option 1: Incorrect. One receiver leaving need not stop others.
- Option 2: Incorrect. Leaving one group does not delete VNIs.
- Option 3: Correct. Stale copies consume resources.

**CCIE-DC-Q0075 · single · diagnosis**

Why include overhead in capacity acceptance?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

1. Encapsulation and framing consume bandwidth
2. Overhead increases only storage latency
3. Headers carry no bits

**Correct option(s):** 1

- Option 1: Correct. Payload rate understates wire demand.
- Option 2: Incorrect. It consumes network capacity too.
- Option 3: Incorrect. Headers are transmitted data.

**CCIE-DC-Q0076 · single · implementation**

Which probe isolates membership from source generation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

1. Only refresh the dashboard
2. Capture at source and receiver-facing egress
3. Rename the multicast group

**Correct option(s):** 2

- Option 1: Incorrect. A display refresh adds no packet evidence.
- Option 2: Correct. It localizes disappearance across the path.
- Option 3: Incorrect. Names are not protocol addresses.

**CCIE-DC-Q0077 · single · implementation**

What does EVPN inclusive multicast information support?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

1. Host disk replication consistency
2. A universal application authorization list
3. Discovery of replication participants

**Correct option(s):** 3

- Option 1: Incorrect. That is outside EVPN replication state.
- Option 2: Incorrect. Membership is not full application authorization.
- Option 3: Correct. It informs BUM distribution.

**CCIE-DC-Q0078 · single · implementation**

Which repair addresses RPF specifically?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

1. Align source routing and intended ingress
2. Add all VTEPs to the group
3. Increase every IGMP timeout

**Correct option(s):** 1

- Option 1: Correct. It corrects the reverse-path expectation.
- Option 2: Incorrect. More receivers do not repair RPF.
- Option 3: Incorrect. That does not change source-facing routing.

**CCIE-DC-Q0079 · single · diagnosis**

Why test no-receiver behavior?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

1. To prove all hosts are powered off
2. To disable monitoring entirely
3. To detect unnecessary continued replication

**Correct option(s):** 3

- Option 1: Incorrect. No membership does not imply power state.
- Option 2: Incorrect. Monitoring is needed to verify behavior.
- Option 3: Correct. Absence of interest should affect distribution.

**CCIE-DC-Q0080 · single · implementation**

What does three remote copies offer?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic fabric: eight remote VTEPs join VNI 10100. Source emits 2 Gbit/s BUM, ingress replication is configured. Leaf uplink capacity available for this traffic is 10 Gbit/s. Receiver VLAN has IGMP snooping; its only querier was removed. PIM (S, G) on Router R expects source on Ethernet 1/1 but packets arrive Ethernet 1/2.

1. 2 Gbit/s regardless of copies
2. 16 Gbit/s unchanged
3. 6 Gbit/s before overhead

**Correct option(s):** 3

- Option 1: Incorrect. That ignores ingress replication.
- Option 2: Incorrect. The replication set changed.
- Option 3: Correct. Three times 2 Gbit/s is 6 Gbit/s.

#### Recall

**How much remote replication is offered?**

16 Gbit/s before overhead Eight copies multiply the 2-Gbit/s source.

**Which state first identifies interested hosts?**

IGMP or MLD membership Host interest differs from routed tree state.

**What limits ingress replication cost?**

The actual remote replication set Each destination adds copies.

**Which metric detects a membership storm?**

Join/leave rates and replication load State churn and copies are causal signals.

**What does EVPN inclusive multicast information support?**

Discovery of replication participants It informs BUM distribution.

#### References

- [Cisco Nexus multicast guides](https://www.cisco.com/c/en/us/support/switches/nexus-9000-series-switches/products-installation-and-configuration-guides-list.html)
- [EVPN overlay specification](https://www.rfc-editor.org/rfc/rfc8365.html)

## CCIE-DC-M05 — ACI fabric discovery and access-policy dependency chains

### CCIE-DC-L05 — ACI fabric discovery and access-policy dependency chains

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L04

ACI separates fabric infrastructure from tenant service policy. Fabric discovery must establish the supported leaf/spine adjacency, node identity and controller relationship before endpoint policy can be meaningful. Record node IDs, serials, management addressing and controller health. Do not mistake an accessible APIC GUI for a fully commissioned fabric. Controller quorum and fabric forwarding have different failure behavior: existing policy may continue forwarding while management changes are impaired.

An endpoint-facing port is not attached by a single VLAN command. Physical interface selectors reference interface policy groups; these select link behavior and an attachable access entity profile. The AEP associates a domain, and the domain uses an appropriate VLAN pool. An EPG then binds to the physical path with an encapsulation valid for that domain. A correct EPG name with an incomplete access-policy chain can leave traffic unclassified. Follow references from the switch port upward and the tenant EPG downward until they meet.

For vPC attachment, distinguish switch profiles, interface profiles and the vPC policy group. A bundle policy and an individual-port policy are not interchangeable. Confirm LACP mode and downstream expectations, static path type, encapsulation and deployment state. Shared policy objects create useful reuse but also a broad change domain: modifying one VLAN pool or link policy can affect multiple attachments.

Commission one low-risk endpoint before bulk binding. Verify physical state, encapsulation classification, endpoint learning in the intended EPG and permitted/denied traffic. Keep a graph of policy references in the change record so a later deletion can be checked for dependents.

### Implementation walkthrough: make the access-policy graph explicit
Write one complete physical attachment as a graph of named objects: leaf selector → switch profile → interface selector/profile → interface policy group → AEP → physical domain → VLAN pool. Separately write tenant → application profile → EPG → domain association → static path binding. The two chains must agree on the actual leaf/port, domain and encapsulation. Record object distinguished names or exported identifiers so similar display names cannot hide the wrong reference.

Use an APIC 5.x lab with a supported leaf pair. Discover and register nodes using the verified serial-to-node-ID plan. Confirm controller health and fabric adjacency before introducing tenant configuration. Create the VLAN pool/domain and access chain, then bind one EPG to one disposable endpoint. Keep the first test small enough that a missing reference can be located unambiguously.

An illustrative read-only REST query pattern is:

```text
GET /api/node/class/fvCEp.json
GET /api/node/class/fvRsPathAtt.json
GET /api/node/class/infraRsDomP.json
```
These class examples require a validated APIC session, trusted TLS and release-specific query review. They were not executed here. Filter by the intended tenant/path in a real lab rather than exporting an entire production inventory unnecessarily. A returned object proves presence in the model; inspect deployment faults and endpoint learning to establish effective attachment.

For the supplied VLAN 220 mismatch, compare the static-binding encapsulation with the domain's allowed pool. Decide whether the binding is wrong or the approved pool needs expansion. Do not widen the pool solely to make the error disappear. Export dependent references before modifying a shared AEP or policy group, because one object can affect many ports.

Commission the endpoint by checking link negotiation, expected encapsulation, learned EPG identity, permitted application traffic and denied cross-group traffic. Test the vPC attachment separately with its bundle policy and both physical paths. Finally, impair one controller only in an authorized lab and distinguish existing forwarding from management change availability; a healthy GUI and a healthy fabric are different observations.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

**Reasoning:** VLAN 220 lies outside the associated pool, so trace the domain/pool and binding instead of changing IP routing. Expand the pool only if 220 is approved for this domain or correct the binding to the assigned encapsulation. Separately, controller loss affects management availability; continued established forwarding is not proof that new policy commits are safe.

#### Guided practice

PG-Web is reused by ten ports. Propose a change that fixes only the intended attachment and identify the impact of editing the shared AEP.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** First identify whether the fault is the assigned encapsulation or the domain scope. Change the narrow reference where possible; editing a shared AEP can affect all ten ports and every associated domain. Review dependents and test the unaffected attachments.

#### Independent task

Environment: vendor

Build an ACI access-policy chain from node discovery to a physical and vPC endpoint attachment, with explicit reference and failure verification.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Every policy reference resolves.
- The endpoint learns in the intended EPG.
- Management impairment and forwarding behavior are assessed separately.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0081 · single · implementation**

What directly explains the missing endpoint classification?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

1. APIC must carry every data packet
2. The tenant needs another default route
3. VLAN 220 is outside the associated pool

**Correct option(s):** 3

- Option 1: Incorrect. APIC is not the transit data path.
- Option 2: Incorrect. Routing occurs after classification.
- Option 3: Correct. The binding lacks an eligible encapsulation.

**CCIE-DC-Q0082 · single · implementation**

Which reference connects access policy to a domain?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

1. The endpoint's DNS suffix
2. The AEP association
3. The tenant description

**Correct option(s):** 2

- Option 1: Incorrect. DNS does not establish access policy.
- Option 2: Correct. It links attachment policy with domains.
- Option 3: Incorrect. Descriptions do not create references.

**CCIE-DC-Q0083 · single · implementation**

What should precede tenant troubleshooting?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

1. Renumber all endpoint IPs
2. Validate fabric discovery and node health
3. Delete all controllers

**Correct option(s):** 2

- Option 1: Incorrect. The supplied fault is encapsulation membership.
- Option 2: Correct. Tenant policy depends on working fabric infrastructure.
- Option 3: Incorrect. That removes management capability.

**CCIE-DC-Q0084 · single · implementation**

Which observation proves EPG classification?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

1. Only the APIC login succeeds
2. Only eth 1/10 is up
3. Endpoint learning in the expected EPG

**Correct option(s):** 3

- Option 1: Incorrect. GUI access does not classify endpoints.
- Option 2: Incorrect. The link can carry unclassified frames.
- Option 3: Correct. Physical link state alone is weaker evidence.

**CCIE-DC-Q0085 · single · calculation**

What is the risk of changing a shared AEP?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

1. It affects no deployed ports
2. Only the currently tested EPG changes
3. Multiple dependent attachments change

**Correct option(s):** 3

- Option 1: Incorrect. Deployed references can depend on it.
- Option 2: Incorrect. A shared AEP can affect multiple dependent ports and domains.
- Option 3: Correct. Reuse broadens the change domain.

**CCIE-DC-Q0086 · single · implementation**

Which configuration is distinct for vPC attachment?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

1. A different DNS resolver
2. An extra default tenant
3. A vPC bundle policy and path

**Correct option(s):** 3

- Option 1: Incorrect. DNS does not aggregate links.
- Option 2: Incorrect. Tenant count does not form vPC.
- Option 3: Correct. A single-port attachment is not equivalent.

**CCIE-DC-Q0087 · single · diagnosis**

Why inspect downstream LACP settings?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

1. LACP assigns all tenant IPs
2. Both ends must agree on aggregation
3. APIC always disables LACP

**Correct option(s):** 2

- Option 1: Incorrect. It does not assign IP addresses.
- Option 2: Correct. Link-up does not prove a working bundle.
- Option 3: Incorrect. Modes are configurable.

**CCIE-DC-Q0088 · single · implementation**

What can remain during APIC impairment?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

1. Guaranteed ability to commit every change
2. Previously programmed forwarding
3. Automatic factory defaults on every leaf

**Correct option(s):** 2

- Option 1: Incorrect. Quorum impairment can block management.
- Option 2: Correct. Management and forwarding are separate planes.
- Option 3: Incorrect. That is not the stated behavior.

**CCIE-DC-Q0089 · single · implementation**

Which claim does continued traffic not support?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

1. The controller cluster is healthy
2. Some existing paths still forward
3. The tested endpoints communicate

**Correct option(s):** 1

- Option 1: Correct. Existing traffic can outlive management health.
- Option 2: Incorrect. That is directly observed.
- Option 3: Incorrect. That is the observation.

**CCIE-DC-Q0090 · single · calculation**

What is the narrow decision before expanding a pool?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

1. Confirm VLAN 220 belongs in that domain
2. Change every tenant's VRF
3. Assume every VLAN should be allowed

**Correct option(s):** 1

- Option 1: Correct. Expansion changes allowed attachment scope.
- Option 2: Incorrect. The pool issue precedes routing.
- Option 3: Incorrect. That widens scope without justification.

**CCIE-DC-Q0091 · single · implementation**

Which inventory associates a node with intended role?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

1. Node ID and serial mapping
2. Only endpoint DHCP leases
3. Only a browser cookie

**Correct option(s):** 1

- Option 1: Correct. It verifies discovered hardware identity.
- Option 2: Incorrect. Leases do not register fabric nodes.
- Option 3: Incorrect. Cookies identify a session, not a node.

**CCIE-DC-Q0092 · single · implementation**

What should a deletion review examine?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

1. Only yesterday's traffic average
2. All policy-object dependents
3. Only the object being deleted

**Correct option(s):** 2

- Option 1: Incorrect. Low traffic does not prove no dependency.
- Option 2: Correct. References can make deletion disruptive.
- Option 3: Incorrect. Dependent references can remain live even when the target appears unused locally.

**CCIE-DC-Q0093 · single · diagnosis**

Why test a denied endpoint after a repair?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

1. To preserve the classification boundary
2. To increase the VLAN range again
3. To force all contracts off

**Correct option(s):** 1

- Option 1: Correct. Positive reachability alone misses over-permission.
- Option 2: Incorrect. That changes scope without evidence.
- Option 3: Incorrect. That removes policy enforcement.

**CCIE-DC-Q0094 · single · implementation**

Which state separates physical failure from policy failure?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

1. Link and error state versus classification
2. Only the tenant name
3. Only the rack position

**Correct option(s):** 1

- Option 1: Correct. Different layers require different evidence.
- Option 2: Incorrect. Names do not locate the fault.
- Option 3: Incorrect. Location does not establish logical state.

**CCIE-DC-Q0095 · single · implementation**

What must a static binding include consistently?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

1. Only a VLAN-pool definition
2. Path and encapsulation
3. Only a contract name

**Correct option(s):** 2

- Option 1: Incorrect. The binding still needs the intended physical path and specific encapsulation.
- Option 2: Correct. Both define the intended attachment.
- Option 3: Incorrect. Contracts act after classification.

**CCIE-DC-Q0096 · single · diagnosis**

Why commission one endpoint first?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

1. It replaces controller backups
2. It isolates reference-chain errors
3. It proves every future port works

**Correct option(s):** 2

- Option 1: Incorrect. A test is not a backup.
- Option 2: Correct. Bulk deployment multiplies ambiguous failures.
- Option 3: Incorrect. One test cannot establish that.

**CCIE-DC-Q0097 · single · implementation**

What does a domain VLAN pool constrain?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

1. All application TCP ports
2. Eligible encapsulations for attachments
3. The physical optic wavelength

**Correct option(s):** 2

- Option 1: Incorrect. Those belong to service policy.
- Option 2: Correct. It participates in classification scope.
- Option 3: Incorrect. VLAN pools do not select optics.

**CCIE-DC-Q0098 · single · diagnosis**

Which evidence belongs in the as-built record?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

1. Resolved policy-reference graph
2. Only the tenant EPG export
3. Only screenshots of green icons

**Correct option(s):** 1

- Option 1: Correct. It supports dependency-aware maintenance.
- Option 2: Incorrect. Access-policy references and physical attachments must also be documented.
- Option 3: Incorrect. They omit references and versions.

**CCIE-DC-Q0099 · single · implementation**

What should be tested after cluster recovery?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

1. Only server fan speed
2. Management commits and existing forwarding
3. Only the login banner

**Correct option(s):** 2

- Option 1: Incorrect. It does not test APIC management.
- Option 2: Correct. Both planes need verification.
- Option 3: Incorrect. It does not prove cluster operation.

**CCIE-DC-Q0100 · single · implementation**

Which action addresses a wrong binding rather than a correct restricted pool?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x policy graph: leaf 101 eth 1/10 -> PG-Web -> AEP-Servers -> Ph ys Dom-Prod -> VLAN P ool 100-199. Tenant App/EPG-Web static binding uses en cap vlan-220. Link is up; no endpoint appears in EPG-Web. APIC cluster has lost two of three members; existing tested flows continue.

1. Clear all routing protocols
2. Permit every VLAN globally
3. Correct the binding encapsulation

**Correct option(s):** 3

- Option 1: Incorrect. Routing does not repair the binding.
- Option 2: Incorrect. That broadens scope unnecessarily.
- Option 3: Correct. It preserves the approved domain scope.

#### Recall

**What directly explains the missing endpoint classification?**

VLAN 220 is outside the associated pool The binding lacks an eligible encapsulation.

**What is the risk of changing a shared AEP?**

Multiple dependent attachments change Reuse broadens the change domain.

**Which claim does continued traffic not support?**

The controller cluster is healthy Existing traffic can outlive management health.

**Why test a denied endpoint after a repair?**

To preserve the classification boundary Positive reachability alone misses over-permission.

**What does a domain VLAN pool constrain?**

Eligible encapsulations for attachments It participates in classification scope.

#### References

- [APIC configuration guides](https://www.cisco.com/c/en/us/support/cloud-systems-management/application-policy-infrastructure-controller-apic/products-installation-and-configuration-guides-list.html)

## CCIE-DC-M06 — ACI packet walks, contracts and external classification

### CCIE-DC-L06 — ACI packet walks, contracts and external classification

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L05

ACI policy troubleshooting starts by determining how both endpoints are classified. A packet's source and destination policy identities, VRF context, forwarding destination and contract state jointly determine treatment. A bridge domain describes forwarding behavior; an EPG groups endpoints for policy. Sharing a subnet does not imply that two EPGs communicate, and sharing an EPG does not imply every isolation option is disabled.

Construct a policy matrix before building contracts. For each application flow record consumer, provider, protocol, source/destination ports, direction, required return traffic and logging. Stateful application behavior must not be confused with an automatically stateful firewall: verify the actual contract/filter behavior and options on the supported release. Broad permits can hide classification errors. Preferred groups, unenforced VRFs, intra-EPG isolation and security groups alter the policy model and must be deliberately tested.

An L3Out adds another classification and routing boundary. A received route establishes potential reachability; an external EPG and contract establish policy relationships. Subnet flags and route-control policy can govern different purposes. A prefix used to classify external traffic is not necessarily an instruction to redistribute that route. Separate ingress classification, route import, route export and inter-VRF sharing in the design.

Use an actual packet tuple and walk ingress attachment, endpoint learning, route lookup, policy lookup and egress adjacency. If routing exists but policy drops, a routing reset is inappropriate. If policy permits but next-hop resolution fails, another permit is irrelevant. Test allowed and denied directions with counters or captures that locate the enforcement point.

### Implementation walkthrough: derive policy from a packet tuple
Start with three application groups: Web, App and DB. Write requirements as rows: Web→App TCP 443; App→DB TCP 5432; monitoring→each approved health port; every other lateral flow denied unless separately justified. Include source identity, destination identity, source-port expectations, destination service port, return behavior and logging. This table is the acceptance oracle. Do not build a broad contract and attempt to infer the requirement afterward.

For each packet, record ingress interface/encapsulation, learned endpoint group, VRF, destination lookup, destination policy identity, applicable contract/filter and egress adjacency. An ingress misclassification can make a perfectly configured contract irrelevant. A route can be present while policy denies; a permit can be present while forwarding lacks an adjacency. Keep these as separate columns in the troubleshooting record.

APIC 5.x read-only REST class examples include:

```text
GET /api/node/class/fvAEPg.json
GET /api/node/class/vzBrCP.json
GET /api/node/class/vzFilter.json
GET /api/node/class/vzEntry.json
GET /api/node/class/l3extInstP.json
```
Use release-specific filters and a scoped account in a real lab. These examples identify model families, not a complete executable production query. Inspect deployed policy and counters with the supported APIC/leaf troubleshooting tools; a JSON object in the controller is not sufficient evidence that the leaf enforces it.

Create only the Web→App contract first. Confirm that 443 passes and 5432 to DB remains denied. Add the approved App→DB relation, then repeat both positive and negative tests. Vary source group as well as port: an allowed service from an unauthorized group must remain denied. For return traffic, verify the selected filter/contract options on the installed release rather than assuming a universal stateful-firewall model.

For the external path, record separately the prefix used for external classification, the route imported from the neighbor and the export policy. In the supplied case 203.0.113.8 belongs to a learned route but not the configured external EPG classification. Correct only the approved classification and required contract. Do not use an unenforced VRF as the final fix. Close with a policy matrix showing observed permit/deny results and counters for each tuple.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

**Reasoning:** The successful HTTP S flow validates one specific contract, not all application dependencies. Add a narrowly scoped App-to-DB relation after confirming the requirement. The external route exists but the source prefix does not match the intended external classification, so first repair that boundary rather than adding a default route. Validate negative traffic after both changes.

#### Guided practice

An operator proposes an unenforced VRF to restore both failed services. Explain the hidden effects and devise a narrower implementation plan.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Unenforced behavior discards the approved inter-group policy requirement. Establish the missing DB flow contract and correct external classification, retaining explicit source/protocol/destination scope. Test approved flows, forbidden lateral flows and the return direction.

#### Independent task

Environment: vendor

Implement and diagnose a multi-tier ACI application with L3Out connectivity and a positive/negative policy matrix.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Allowed traffic works in both required directions.
- Unapproved lateral and external traffic remains denied.
- Route control and policy classification are documented separately.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0101 · single · diagnosis**

Why does DB 5432 fail?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

1. The required contract is absent
2. The database needs TCP 443 only
3. All routing is necessarily broken

**Correct option(s):** 1

- Option 1: Correct. The HTTP S contract does not authorize this service.
- Option 2: Incorrect. The stated service uses 5432.
- Option 3: Incorrect. One working service disproves that broad claim.

**CCIE-DC-Q0102 · single · diagnosis**

Why does the external source fail despite a route?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

1. Its prefix misses external classification
2. A learned route always bypasses contracts
3. The source is automatically in Web EPG

**Correct option(s):** 1

- Option 1: Correct. Reachability and policy identity differ.
- Option 2: Incorrect. Enforced policy still applies.
- Option 3: Incorrect. External identity requires classification.

**CCIE-DC-Q0103 · single · calculation**

What is the risk of an unenforced VRF?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

1. Loss of intended inter-group enforcement
2. Guaranteed stronger source authentication
3. Elimination of routing dependencies

**Correct option(s):** 1

- Option 1: Correct. It broadens communication beyond the matrix.
- Option 2: Incorrect. It does not authenticate sources.
- Option 3: Incorrect. Routes remain necessary.

**CCIE-DC-Q0104 · single · implementation**

Which artifact defines correct contract scope?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

1. Only subnet utilization
2. Application flow matrix
3. Only controller uptime

**Correct option(s):** 2

- Option 1: Incorrect. Address occupancy does not define service authorization.
- Option 2: Correct. It records required identities and services.
- Option 3: Incorrect. Uptime does not define policy.

**CCIE-DC-Q0105 · single · implementation**

What distinguishes a BD from an EPG?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

1. Forwarding domain versus policy grouping
2. An EPG is only a physical switch
3. Both are identical objects

**Correct option(s):** 1

- Option 1: Correct. They serve related but different purposes.
- Option 2: Incorrect. EPGs can span attachments.
- Option 3: Incorrect. Their roles are distinct.

**CCIE-DC-Q0106 · single · implementation**

What must a packet walk identify first?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

1. Actual endpoint classification
2. Only the intended EPG name
3. Only the HTTP response code

**Correct option(s):** 1

- Option 1: Correct. Policy reasoning depends on identity.
- Option 2: Incorrect. Intent may differ from effective classification.
- Option 3: Incorrect. It does not locate ingress policy.

**CCIE-DC-Q0107 · single · implementation**

Which test exposes an overbroad repair?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

1. A prohibited lateral flow
2. Another copy of the allowed HTTP S test
3. Only a route count

**Correct option(s):** 1

- Option 1: Correct. Positive tests alone miss excess permission.
- Option 2: Incorrect. It repeats existing positive coverage.
- Option 3: Incorrect. Routes do not prove contract scope.

**CCIE-DC-Q0108 · single · implementation**

What does a route-control export change govern?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

1. Which endpoint owns a certificate
2. Which prefixes are advertised
3. Which TCP process listens on a host

**Correct option(s):** 2

- Option 1: Incorrect. PKI ownership is separate.
- Option 2: Correct. It is distinct from packet classification.
- Option 3: Incorrect. Routing policy does not open sockets.

**CCIE-DC-Q0109 · single · diagnosis**

Why inspect return traffic?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

1. Every filter is universally stateful
2. Directional filtering can differ
3. Return traffic bypasses policy

**Correct option(s):** 2

- Option 1: Incorrect. That must not be assumed.
- Option 2: Correct. Forward success does not establish reverse authorization.
- Option 3: Incorrect. It still traverses enforcement.

**CCIE-DC-Q0110 · single · design**

What is a preferred-group design decision?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

1. Which groups communicate without ordinary contracts
2. Which fiber has lower attenuation
3. Which APIC holds every packet

**Correct option(s):** 1

- Option 1: Correct. It changes the enforcement model.
- Option 2: Incorrect. It is logical policy.
- Option 3: Incorrect. APIC is not the transit path.

**CCIE-DC-Q0111 · single · diagnosis**

Which fault does adding a contract not fix?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

1. An absent filter for the service
2. A missing approved policy relation
3. Unresolved egress next hop

**Correct option(s):** 3

- Option 1: Incorrect. A correct contract can supply it.
- Option 2: Incorrect. That is what a contract can address.
- Option 3: Correct. Permission cannot create adjacency.

**CCIE-DC-Q0112 · single · diagnosis**

Which fault does a route reset not fix?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

1. Wrong external EPG classification
2. A withdrawn route after policy correction
3. A genuinely stale route process

**Correct option(s):** 1

- Option 1: Correct. Classification is separate policy state.
- Option 2: Incorrect. Routing changes can affect routes.
- Option 3: Incorrect. A reset might affect that state.

**CCIE-DC-Q0113 · single · diagnosis**

Why specify source and destination ports carefully?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

1. Client ephemeral and service ports differ
2. TCP uses one fixed port both directions
3. Ports select optical wavelengths

**Correct option(s):** 1

- Option 1: Correct. Reversing them can block valid flows.
- Option 2: Incorrect. That is not general TCP behavior.
- Option 3: Incorrect. They are transport identifiers.

**CCIE-DC-Q0114 · single · implementation**

What must intra-EPG isolation testing verify?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

1. Only inter-VRF route advertisements
2. Peer communication within the same group
3. Only DNS recursion

**Correct option(s):** 2

- Option 1: Incorrect. That tests another boundary.
- Option 2: Correct. Same-EPG behavior depends on options.
- Option 3: Incorrect. It does not establish intra-group isolation.

**CCIE-DC-Q0115 · single · implementation**

Which claim is supported by Web-to-App 443 success?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

1. That specific tested flow works
2. Every database dependency is authorized
3. Every external source is trusted

**Correct option(s):** 1

- Option 1: Correct. It does not validate the whole application.
- Option 2: Incorrect. DB 5432 is separately failing.
- Option 3: Incorrect. No external authorization follows.

**CCIE-DC-Q0116 · single · implementation**

What should precede inter-VRF sharing?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

1. Explicit ownership and route/policy requirements
2. Import every prefix first
3. Disable all endpoint learning

**Correct option(s):** 1

- Option 1: Correct. Sharing crosses a tenant boundary.
- Option 2: Incorrect. That creates uncontrolled scope.
- Option 3: Incorrect. That destroys forwarding evidence.

**CCIE-DC-Q0117 · single · implementation**

Which observation locates enforcement drops?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

1. Only aggregate CPU
2. Policy counters tied to the tested tuple
3. Only a physical link LED

**Correct option(s):** 2

- Option 1: Incorrect. It does not identify the blocked tuple.
- Option 2: Correct. They connect the flow with enforcement.
- Option 3: Incorrect. It shows little about policy.

**CCIE-DC-Q0118 · single · diagnosis**

Why retain the enforced VRF during repair?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

1. It guarantees database integrity
2. Enforcement makes routing impossible
3. The isolation requirement still applies

**Correct option(s):** 3

- Option 1: Incorrect. Network permission does not prove data integrity.
- Option 2: Incorrect. Routing and policy coexist.
- Option 3: Correct. Repair should satisfy all constraints.

**CCIE-DC-Q0119 · single · implementation**

What must be distinguished in L3Out subnet settings?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

1. Only the source MAC vendor
2. Only text capitalization
3. Classification, import, export and sharing purposes

**Correct option(s):** 3

- Option 1: Incorrect. Vendor identity does not define route policy.
- Option 2: Incorrect. Display text is not the function.
- Option 3: Correct. Flags can serve different policy functions.

**CCIE-DC-Q0120 · single · diagnosis**

Which closeout evidence is strongest?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x: Web EPG consumes HTTP S contract from App EPG, filter TCP destination 443. App database service is TCP 5432, but no DB contract exists. L3Out learns 203.0.113.0/24; external EPG classifies only 198.51.100.0/24. VRF is enforced. Web-to-App 443 passes; App-to-DB 5432 fails; external 203.0.113.8-to-Web 443 fails.

1. Only the absence of user complaints
2. Only a successful configuration save
3. Effective policy plus positive and negative packet tests

**Correct option(s):** 3

- Option 1: Incorrect. Silent faults can remain.
- Option 2: Incorrect. Saved intent is not behavior.
- Option 3: Correct. It validates both access and restriction.

#### Recall

**Why does DB 5432 fail?**

The required contract is absent The HTTP S contract does not authorize this service.

**What distinguishes a BD from an EPG?**

Forwarding domain versus policy grouping They serve related but different purposes.

**Why inspect return traffic?**

Directional filtering can differ Forward success does not establish reverse authorization.

**Why specify source and destination ports carefully?**

Client ephemeral and service ports differ Reversing them can block valid flows.

**Which observation locates enforcement drops?**

Policy counters tied to the tested tuple They connect the flow with enforcement.

#### References

- [APIC policy and L3Out guides](https://www.cisco.com/c/en/us/support/cloud-systems-management/application-policy-infrastructure-controller-apic/products-installation-and-configuration-guides-list.html)

## CCIE-DC-M07 — ACI VMM integration, endpoint aging and mobility boundaries

### CCIE-DC-L07 — ACI VMM integration, endpoint aging and mobility boundaries

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L06

VMM integration connects the controller's policy model to a hypervisor management domain. It is not permission to assume that every virtual switch port has the intended policy. Track controller credentials, certificate trust, inventory synchronization, virtual-switch mapping, uplink attachment and EPG deployment. A stale inventory can leave an object apparently present while its effective attachment has changed. Separate the management API transaction from the data-plane VLAN and port-group operation.

A VM migration crosses several state machines: the hypervisor moves execution, the virtual switch changes attachment, the physical fabric learns or receives updated endpoint state, and neighbors refresh address resolution. A successful migration task in the virtualization manager does not establish packet delivery at the destination. Local and remote endpoint tables, duplicate-address events and packet captures should agree with the intended owner. A stretched Layer 2 segment can preserve an address while also extending broadcasts, endpoint faults and operational coupling across sites.

Multi-pod and multi-site designs differ in control and failure domains; they cannot be selected merely by distance or a desire for one GUI. Document inter-pod or inter-site transport requirements, controller/orchestrator dependencies, supported feature combinations, addressing and multicast or unicast transport needs for the chosen release. State whether a feature belongs to the published examination baseline or a production extension.

Prepare mobility by validating the target attachment, policy and capacity; move an isolated workload; test application sessions and new connections; then remove obsolete state only after ownership is established. Include controller disconnection and stale inventory as separate drills. Rollback must restore both workload placement and network policy consistency.

### Implementation walkthrough: reconcile hypervisor and fabric state
Create an integration inventory containing the virtualization manager's API endpoint, trusted certificate chain, service identity, assigned privileges, VMM domain, virtual switch, uplinks, physical attachment and EPG-to-port-group mapping. Mark which component owns each change. An APIC policy administrator and a virtualization administrator can otherwise make conflicting changes to the same effective attachment.

Before migration, export a small test VM's current placement, virtual adapter identity, IP/MAC, port group, EPG and physical host uplinks. Record the actual VLAN encapsulation assigned by the supported integration. Verify the destination host can carry that encapsulation before moving execution. A 'migration complete' event only establishes the virtualization manager's task result; it is not a packet test.

Use a timestamped table during the move:

| Stage | Hypervisor fact | Fabric fact | Application fact |
|---|---|---|---|
| Before | VM on host A | Endpoint learned at A | Baseline transaction passes |
| Transition | Task running | Old/new learning observed | Sequence loss and latency recorded |
| After | VM on host B | Single intended owner at B | New and existing sessions tested |

The table is an evidence template, not a prefilled result. Preserve clock uncertainty when comparing events. If the source is powered off but the controller inventory still says source, investigate synchronization and certificate trust rather than treating cached placement as truth.

Inject the supplied target VLAN mismatch in an isolated lab. Verify that execution can move while data delivery fails. Restore the approved uplink/domain mapping and repeat. Then expire a dedicated lab API certificate or use an isolated untrusted certificate test to observe management failure without disabling TLS validation. Restore trust through the supported certificate process and confirm a fresh inventory transaction.

For multi-pod/multi-site extension studies, do not reuse this single-site result as proof. Write the distinct transport, controller, orchestrator, addressing and failure requirements for the installed design. A stretched subnet adds operational coupling, so test the intended inter-site isolation and application recovery independently.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

**Reasoning:** Execution moved, but destination attachment cannot carry the deployed encapsulation. The expired management certificate separately prevents trustworthy synchronization. Validate the intended VLAN/domain mapping, repair the supported trust chain, resynchronize inventory and test endpoint ownership. Do not restore service by disabling certificate validation.

#### Guided practice

After correcting VLAN 311, new TCP sessions work but old sessions reset. Define what has and has not passed.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** New connectivity passes for tested flows; session continuity did not. Compare migration downtime, application timeouts and transport state with the stated requirement. The network must report measured interruption instead of calling the migration lossless.

#### Independent task

Environment: vendor

Integrate VMM policy and validate workload mobility under attachment mismatch and controller-trust failure.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Management trust validates.
- Endpoint ownership is unambiguous.
- Migration meets explicit session and recovery requirements.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0121 · single · implementation**

What explains destination data loss?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

1. The VM kept its IP
2. VLAN 311 is not carried
3. A task-complete message proves forwarding

**Correct option(s):** 2

- Option 1: Incorrect. Address preservation is intentional.
- Option 2: Correct. Execution placement and attachment differ.
- Option 3: Incorrect. It proves only the management task.

**CCIE-DC-Q0122 · single · implementation**

What explains stale inventory?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

1. All packets traverse vCenter
2. Expired API trust blocks synchronization
3. The destination data VLAN is disallowed

**Correct option(s):** 2

- Option 1: Incorrect. vCenter is not the data path.
- Option 2: Correct. Cached objects can outlive live access.
- Option 3: Incorrect. That explains data forwarding failure, while the expired API certificate explains synchronization failure.

**CCIE-DC-Q0123 · single · implementation**

Which repair preserves management trust?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

1. Renew and validate the certificate chain
2. Disable TLS verification permanently
3. Share one root password globally

**Correct option(s):** 1

- Option 1: Correct. It restores authenticated management.
- Option 2: Incorrect. That removes server authentication.
- Option 3: Incorrect. That broadens authority.

**CCIE-DC-Q0124 · single · implementation**

What establishes current endpoint ownership?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

1. Fabric state plus hypervisor placement
2. Only cached inventory
3. Only the old host's label

**Correct option(s):** 1

- Option 1: Correct. Both should identify the same live origin.
- Option 2: Incorrect. It is known stale.
- Option 3: Incorrect. Labels do not prove live ownership.

**CCIE-DC-Q0125 · single · implementation**

What does new-session success prove?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

1. Every future migration is safe
2. All existing sessions survived
3. Tested new connectivity works

**Correct option(s):** 3

- Option 1: Incorrect. One test is bounded evidence.
- Option 2: Incorrect. They explicitly reset.
- Option 3: Correct. It does not prove session continuity.

**CCIE-DC-Q0126 · single · diagnosis**

Why test old sessions separately?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

1. TCP sessions never time out
2. New sessions use no network
3. State continuity has distinct requirements

**Correct option(s):** 3

- Option 1: Incorrect. They do.
- Option 2: Incorrect. They still use forwarding.
- Option 3: Correct. New handshakes can hide interruption.

**CCIE-DC-Q0127 · single · implementation**

What is a risk of stretching Layer 2?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

1. Guaranteed application consistency
2. Extended failure and broadcast domains
3. Elimination of duplicate IPs

**Correct option(s):** 2

- Option 1: Incorrect. Layer 2 does not ensure that.
- Option 2: Correct. Address mobility adds coupling.
- Option 3: Incorrect. Stretching can propagate duplicates.

**CCIE-DC-Q0128 · single · implementation**

Which object is insufficient alone?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

1. A measured application transaction
2. A visible VMM inventory entry
3. A timestamped packet capture

**Correct option(s):** 2

- Option 1: Incorrect. It directly tests service behavior.
- Option 2: Correct. It may be stale or mis bound.
- Option 3: Incorrect. It provides actual traffic evidence.

**CCIE-DC-Q0129 · single · implementation**

What should precede the first move?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

1. Delete the source backups
2. Validate destination policy and uplinks
3. Clear all audit logs

**Correct option(s):** 2

- Option 1: Incorrect. That weakens recovery.
- Option 2: Correct. The target must be ready before execution moves.
- Option 3: Incorrect. That destroys evidence.

**CCIE-DC-Q0130 · single · implementation**

What must rollback restore?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

1. Placement and network-policy consistency
2. Only a DNS display name
3. Only the VM execution location

**Correct option(s):** 1

- Option 1: Correct. Both participate in service recovery.
- Option 2: Incorrect. It does not restore attachment.
- Option 3: Incorrect. Network policy and attachment must agree with the restored placement.

**CCIE-DC-Q0131 · single · diagnosis**

Why compare controller and workload timestamps?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

1. To eliminate all packet captures
2. To reconstruct independent state transitions
3. To prove every clock is perfect

**Correct option(s):** 2

- Option 1: Incorrect. Timing does not replace traffic evidence.
- Option 2: Correct. Management and execution may diverge.
- Option 3: Incorrect. Comparison can reveal error instead.

**CCIE-DC-Q0132 · single · implementation**

Which dependency belongs to management integration?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

1. Only guest disk capacity
2. Only the VM's application port
3. API credentials and certificate trust

**Correct option(s):** 3

- Option 1: Incorrect. It does not authenticate the API.
- Option 2: Incorrect. That is service traffic.
- Option 3: Correct. They authorize and authenticate synchronization.

**CCIE-DC-Q0133 · single · implementation**

What does a destination uplink VLAN test isolate?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

1. Firmware signature validity
2. Database transaction ordering
3. Physical-to-virtual attachment

**Correct option(s):** 3

- Option 1: Incorrect. That is a separate trust check.
- Option 2: Incorrect. That is application state.
- Option 3: Correct. It distinguishes transport from manager status.

**CCIE-DC-Q0134 · single · diagnosis**

Why not clear endpoint tables immediately?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

1. It destroys movement evidence
2. Tables contain no useful location
3. Clearing permanently fixes VLAN mismatch

**Correct option(s):** 1

- Option 1: Correct. First establish the live owner.
- Option 2: Incorrect. They encode endpoint location.
- Option 3: Incorrect. It cannot permit a missing VLAN.

**CCIE-DC-Q0135 · single · implementation**

What must a multi-site choice document?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

1. Only a common management interface
2. Only geographic distance
3. Its distinct control and failure domains

**Correct option(s):** 3

- Option 1: Incorrect. One management view does not establish shared or independent control/failure domains.
- Option 2: Incorrect. Distance alone is insufficient.
- Option 3: Correct. One interface does not mean one failure model.

**CCIE-DC-Q0136 · single · implementation**

Which test exposes stale API access?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

1. A fresh authenticated inventory transaction
2. Pinging an unrelated host
3. Refreshing the same cached page

**Correct option(s):** 1

- Option 1: Correct. Cached display is weaker evidence.
- Option 2: Incorrect. It does not test the management API.
- Option 3: Incorrect. It may show the same stale data.

**CCIE-DC-Q0137 · single · diagnosis**

Why retain version assumptions?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

1. Feature support varies by release
2. Version labels replace testing
3. Versions never affect integration

**Correct option(s):** 1

- Option 1: Correct. Design behavior must match deployed software.
- Option 2: Incorrect. They do not demonstrate operation.
- Option 3: Incorrect. They can change support.

**CCIE-DC-Q0138 · single · implementation**

Which outcome requires an honest failure record?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

1. Session continuity exceeds the allowed interruption
2. Inventory refresh completes
3. A permitted new session succeeds

**Correct option(s):** 1

- Option 1: Correct. New reachability does not satisfy that requirement.
- Option 2: Incorrect. That supports management recovery.
- Option 3: Incorrect. That is a positive result.

**CCIE-DC-Q0139 · single · implementation**

What does powering off the source rule out here?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

1. Every stale fabric entry
2. Continued source-host execution
3. Any duplicate anywhere

**Correct option(s):** 2

- Option 1: Incorrect. Stale entries can persist.
- Option 2: Correct. It does not repair target attachment.
- Option 3: Incorrect. Another duplicate could still exist.

**CCIE-DC-Q0140 · single · implementation**

Which closeout combines both planes?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic APIC 5.x integration: vCenter task says migration complete at 10:01. Destination host uplink allows VLAN 310; EPG deployment uses VLAN 311. VM continues using 10.30.0.50. APIC API certificate expired at 09:55; cached inventory still lists the original host. Source host is powered off.

1. Only controller CPU
2. Only migration task completion
3. Fresh inventory plus bidirectional application tests

**Correct option(s):** 3

- Option 1: Incorrect. That omits both required transactions.
- Option 2: Incorrect. That omits forwarding.
- Option 3: Correct. Management and data behavior are verified.

#### Recall

**What explains destination data loss?**

VLAN 311 is not carried Execution placement and attachment differ.

**What does new-session success prove?**

Tested new connectivity works It does not prove session continuity.

**What should precede the first move?**

Validate destination policy and uplinks The target must be ready before execution moves.

**What does a destination uplink VLAN test isolate?**

Physical-to-virtual attachment It distinguishes transport from manager status.

**Why retain version assumptions?**

Feature support varies by release Design behavior must match deployed software.

#### References

- [APIC virtualisation and multi-site guides](https://www.cisco.com/c/en/us/support/cloud-systems-management/application-policy-infrastructure-controller-apic/products-installation-and-configuration-guides-list.html)

## CCIE-DC-M08 — Fibre Channel login, identity, zoning and active policy

### CCIE-DC-L08 — Fibre Channel login, identity, zoning and active policy

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L07

Fibre Channel commissioning is a chain of permissions and registrations. A physical port must initialize in the correct mode and VSAN; an end device performs fabric login and obtains addressing; name-server registration supports discovery; zoning permits initiator-target communication; the storage system must then present the intended LUN, and the host must discover and use it. A fabric login is not proof of disk access. Keep fabric identity, zoning and array masking separate.

WWPN identifies a port and is commonly used in zoning. FCID is an assigned fabric address whose persistence must not be assumed across every topology event. Alias objects improve readability but can conceal a wrong WWPN or an unactivated change. Distinguish configured zone databases from the active zone set, including distribution and merge state. A change saved in one database may not be enforcing on the traffic path.

Use single-initiator zoning where appropriate to reduce unnecessary peer visibility and scope failures. Separate A and B fabrics to preserve independent paths; two HBAs into one shared switch are not equivalent. NPIV permits multiple virtual port identities on a capable physical connection, while an NPV edge forwards logins toward an upstream fabric rather than acting as a full independent switching domain. The server, edge and upstream roles must be compatible.

Before changing storage access, record the host WWPNs, target ports, VSANs, active zones, LUN identifiers and host multipath state. Introduce one path first in a controlled lab, confirm identity and integrity, then commission the independent path. Remove access only after host quiescence and ownership checks; a broad zoning repair can expose the wrong storage to a valid host.

### Implementation walkthrough: follow FC access from wire to filesystem
Prepare a mapping with host name, HBA port, WWPN, fabric A/B, VSAN, switch port, target WWPN, zone, active zone set, array host group, LUN identifier and host-visible device identity. The same LUN should have a stable identity across redundant paths; two different LUNs must not be mistaken for two paths to one disk. Verify ownership before mounting or writing.

Illustrative MDS read-only commands, subject to installed-release review, include:

```text
show flogi database
show fcns database
show zoneset active
show zone
show interface fc1/1
```
Use the applicable VSAN filters and supported host/array tools in the real lab. Capture the configured and active zoning views separately. An alias resolving to an old WWPN can make the configuration look readable while still granting the wrong identity.

Build the first fabric with one initiator and one disposable target LUN. Verify physical initialization and login, then name-server registration, active zoning and array presentation. At the host, confirm the expected storage identifier and a small integrity-checked read/write workload. Add fabric B only after A is understood; then verify the host recognizes two paths to the same intended device rather than two unrelated disks.

Inject three faults separately: missing active zone, wrong array WWPN mapping and wrong host multipath policy. Before each fault, predict the last stage that should still pass. A missing zone can preserve FLOGI but block target communication; wrong masking can permit target discovery without the LUN; a host policy fault can leave multiple visible paths but fail recovery. This stage model prevents replacing healthy optics to fix an authorization problem.

For removal, stop or safely drain the test workload, confirm the intended surviving path, remove the scoped relationship and verify that unrelated initiators remain unaffected. Restore the baseline and retain both positive access and denied access evidence. Storage integrity is assessed after recovery, not inferred from a port returning online.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

**Reasoning:** Two independent authorization layers fail. Activating the intended zone permits fabric communication but does not correct array masking. Validate the intended initiator identity before changing either layer, then verify host discovery and a test LUN's integrity. Never grant broad wildcard storage access as a diagnostic shortcut.

#### Guided practice

After zoning activation, the host discovers the target but no LUN. Explain the next observation and the dangerous false conclusion.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Target visibility shows progress through fabric access. Inspect array host-group identity and masking for the actual WWPN. Do not conclude that the HBA is defective merely because disk access remains absent.

#### Independent task

Environment: vendor

Provision and diagnose FC storage through login, zoning, array presentation and independent host paths.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Active zoning matches approved initiator-target pairs.
- Only the assigned LUN is visible.
- A and B path failures preserve application I/O integrity.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0141 · single · implementation**

Which first defect blocks fabric authorization?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

1. The WWPN is too long
2. VSAN 10 cannot carry storage
3. The active zoneset omits Z-DB

**Correct option(s):** 3

- Option 1: Incorrect. Its format is not the supplied fault.
- Option 2: Incorrect. VSANs partition FC fabrics.
- Option 3: Correct. Configured policy is not active policy.

**CCIE-DC-Q0142 · single · implementation**

What remains wrong after zone activation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

1. The host no longer needs an HBA
2. Every LUN becomes automatically visible
3. Array masking uses another WWPN

**Correct option(s):** 3

- Option 1: Incorrect. Physical connectivity remains necessary.
- Option 2: Incorrect. Array policy still applies.
- Option 3: Correct. Fabric permission does not present a LUN.

**CCIE-DC-Q0143 · single · implementation**

What does FLOGI establish?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

1. Automatic LUN ownership
2. Fabric login and addressing
3. Guaranteed filesystem integrity

**Correct option(s):** 2

- Option 1: Incorrect. The array controls presentation.
- Option 2: Correct. It is one stage before storage access.
- Option 3: Incorrect. Login cannot verify data.

**CCIE-DC-Q0144 · single · diagnosis**

Why prefer WWPN over transient FCID in this policy?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

1. It expresses the intended port identity
2. FCID never changes
3. WWPN is a TCP port

**Correct option(s):** 1

- Option 1: Correct. FCID can change with fabric events.
- Option 2: Incorrect. Persistence is not universal.
- Option 3: Incorrect. It is an FC identity.

**CCIE-DC-Q0145 · single · implementation**

Which comparison finds an unactivated edit?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

1. Only host free memory
2. Configured versus active zoneset
3. Only the FC name-server registration

**Correct option(s):** 2

- Option 1: Incorrect. It does not show fabric policy.
- Option 2: Correct. Both states matter.
- Option 3: Incorrect. Registration can succeed before the intended zoning change is activated.

**CCIE-DC-Q0146 · single · implementation**

What does target discovery without a LUN suggest?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

1. Inspect array presentation next
2. Disable all VSAN isolation
3. Replace every optic immediately

**Correct option(s):** 1

- Option 1: Correct. Fabric reachability is now partly established.
- Option 2: Incorrect. That broadens unrelated scope.
- Option 3: Incorrect. The evidence points beyond basic connectivity.

**CCIE-DC-Q0147 · single · implementation**

What reduces unintended initiator visibility?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

1. Identical WWPNs on all HBAs
2. Appropriate single-initiator zoning
3. One zone containing all hosts

**Correct option(s):** 2

- Option 1: Incorrect. Duplicate identity is unsafe.
- Option 2: Correct. It limits unnecessary peer relationships.
- Option 3: Incorrect. That widens visibility.

**CCIE-DC-Q0148 · single · implementation**

What does NPIV provide?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

1. Guaranteed disk replication
2. A second physical fabric automatically
3. Multiple virtual port identities on one link

**Correct option(s):** 3

- Option 1: Incorrect. It is a login capability.
- Option 2: Incorrect. Logical identities do not create physical independence.
- Option 3: Correct. Upstream support is required.

**CCIE-DC-Q0149 · single · implementation**

What is an NPV edge's role?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

1. Forward logins toward an upstream fabric
2. Encrypt every FC payload
3. Replace array masking

**Correct option(s):** 1

- Option 1: Correct. It avoids a full independent domain role.
- Option 2: Incorrect. That is not NPV's purpose.
- Option 3: Incorrect. Storage presentation remains separate.

**CCIE-DC-Q0150 · single · implementation**

Which observation proves active host use?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

1. Only a registered target WWPN
2. Only an online switch port
3. Application I/O on the intended LUN

**Correct option(s):** 3

- Option 1: Incorrect. Registration precedes I/O.
- Option 2: Incorrect. Physical state is earlier still.
- Option 3: Correct. Discovery alone is not operation.

**CCIE-DC-Q0151 · single · diagnosis**

Why preserve LUN identifiers?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

1. To avoid mounting the wrong storage
2. To choose the optical wavelength
3. To bypass zoning

**Correct option(s):** 1

- Option 1: Correct. Visibility must match ownership.
- Option 2: Incorrect. LUN IDs do not choose optics.
- Option 3: Incorrect. Identity records do not bypass policy.

**CCIE-DC-Q0152 · single · implementation**

Which topology lacks A/B independence?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

1. Separate arrays with reviewed paths
2. Each HBA uses a separate fabric
3. Both HBAs terminate on one switch

**Correct option(s):** 3

- Option 1: Incorrect. That can support separation.
- Option 2: Incorrect. That improves independence.
- Option 3: Correct. The switch is a shared failure point.

**CCIE-DC-Q0153 · single · implementation**

What should precede removing a live path?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

1. Changing every WWPN
2. Quiescence or verified surviving-path readiness
3. Deleting the host filesystem

**Correct option(s):** 2

- Option 1: Incorrect. That destabilizes identity.
- Option 2: Correct. I/O continuity and ownership matter.
- Option 3: Incorrect. That is destructive and unnecessary.

**CCIE-DC-Q0154 · single · diagnosis**

Why inspect zone aliases?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

1. A readable name can reference the wrong WWPN
2. Aliases always authorize every host
3. Alias spelling changes FC speed

**Correct option(s):** 1

- Option 1: Correct. The effective identity matters.
- Option 2: Incorrect. Their behavior depends on membership.
- Option 3: Incorrect. It does not.

**CCIE-DC-Q0155 · single · implementation**

What must a merge investigation compare?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

1. Fabric and zoning compatibility/state
2. Only application usernames
3. Only disk labels

**Correct option(s):** 1

- Option 1: Correct. Merging can expose inconsistent policy.
- Option 2: Incorrect. Those are another authorization layer.
- Option 3: Incorrect. They do not establish switch merge state.

**CCIE-DC-Q0156 · single · diagnosis**

Which action is too broad for this fault?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

1. Correct the reviewed array host identity
2. Activate the reviewed intended zone
3. Permit every initiator to every target

**Correct option(s):** 3

- Option 1: Incorrect. That addresses the other defect.
- Option 2: Incorrect. That addresses one defect.
- Option 3: Correct. It abandons the access requirement.

**CCIE-DC-Q0157 · single · implementation**

What separates transport recovery from data recovery?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

1. A successful login alone
2. A green port LED alone
3. I/O and integrity verification

**Correct option(s):** 3

- Option 1: Incorrect. Login does not validate integrity.
- Option 2: Incorrect. It proves little about data.
- Option 3: Correct. A path returning does not prove correct data.

**CCIE-DC-Q0158 · single · diagnosis**

Which evidence should be timestamped before change?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

1. Only a purchasing receipt
2. Login, active zoning and host-path state
3. Only a generic SAN diagram

**Correct option(s):** 2

- Option 1: Incorrect. It does not show live state.
- Option 2: Correct. It establishes the dependency baseline.
- Option 3: Incorrect. It lacks effective observations.

**CCIE-DC-Q0159 · single · implementation**

What does a valid WWPN not prove?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

1. That a port identity was supplied
2. Authorization to the requested LUN
3. That policies can refer to it

**Correct option(s):** 2

- Option 1: Incorrect. That is its role.
- Option 2: Correct. Identity and entitlement differ.
- Option 3: Incorrect. They commonly do.

**CCIE-DC-Q0160 · single · implementation**

What closes the provisioning task?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic MDS/UCS 4.x lab: initiator WWPN 20:00:00:00:00:00:00:11 logs into VSAN 10. Target 50:00:00:00:00:00:00:22 registers. Configured zone Z-DB contains both; active zoneset PROD omits Z-DB. Array masking grants LUN 7 to a different initiator ending:12. Host sees no disk.

1. Only detecting any disk
2. Correct access, denied unintended access and failure-tested I/O
3. Only saving a zone database

**Correct option(s):** 2

- Option 1: Incorrect. It might be the wrong LUN.
- Option 2: Correct. All constraints need evidence.
- Option 3: Incorrect. That does not prove activation or storage access.

#### Recall

**Which first defect blocks fabric authorization?**

The active zoneset omits Z-DB Configured policy is not active policy.

**Which comparison finds an unactivated edit?**

Configured versus active zoneset Both states matter.

**What is an NPV edge's role?**

Forward logins toward an upstream fabric It avoids a full independent domain role.

**What should precede removing a live path?**

Quiescence or verified surviving-path readiness I/O continuity and ownership matter.

**What separates transport recovery from data recovery?**

I/O and integrity verification A path returning does not prove correct data.

#### References

- [Cisco MDS configuration guides](https://www.cisco.com/c/en/us/support/storage-networking/mds-9000-nx-os-san-os-software/products-installation-and-configuration-guides-list.html)
- [Cisco UCS Manager guides](https://www.cisco.com/c/en/us/support/servers-unified-computing/ucs-manager/products-installation-and-configuration-guides-list.html)

## CCIE-DC-M09 — FC credits, congestion, slow drain and fabric isolation

### CCIE-DC-L09 — FC credits, congestion, slow drain and fabric isolation

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L08

FC buffer-to-buffer flow control prevents a sender from overrunning the receiver's available buffers on a link. A credit represents permission to send a frame into the next hop's buffering, not end-to-end confirmation that an application committed data. Credits must circulate fast enough for the bandwidth-delay product and frame size. A long link can be throughput-limited even when its nominal line rate is high and no optical errors occur.

Distinguish insufficient credits for distance from a slow-draining endpoint. A slow receiver can withhold credit return, create congestion that propagates upstream and affect unrelated flows sharing resources. More buffers may absorb a burst but cannot indefinitely compensate for a receiver that drains slower than the offered load. Track credit-zero duration, transmit wait, ingress/egress rates, queue behavior and application latency together. Counter names and interpretation depend on the MDS release, port mode and hardware.

A bottleneck can move after a path failure. An ISL that is adequate in normal service may be overloaded when the other fabric path is removed. Load-sharing policies also operate at defined flow granularities; aggregate spare bandwidth does not guarantee that one exchange can use every link. Design for both sustained rate and bursts, and retain independent fabrics so a maintenance action does not collapse every storage path.

Diagnose from the symptom toward the constraining receiver. Compare clean physical counters with congestion indicators, correlate the affected flows and preserve time series before resetting counters. A corrective action might reduce offered workload, repair a receiver, redistribute permitted flows or adjust a documented credit allocation for distance. Each action needs a rollback and an integrity-aware application test.

### Implementation walkthrough: distinguish a window limit from a slow receiver
Create a time-aligned record of offered workload, completed I/O, application latency, interface errors, credit-zero/transmit-wait indicators and receiver drain rate. Collect deltas over known intervals and preserve counter epochs. A single large cumulative wait count without elapsed time does not establish the current severity.

The simplified window model is:

```text
required_frames ≈ usable_bits_per_second × credit_round_trip_seconds
                  / frame_bits
```
For 8 Gbit/s, 200 microseconds and 2048-byte frames, the result is 97.65625 frames; round upward before considering implementation-specific reserves. The model deliberately omits framing details, variable frame sizes and hardware credit allocation rules. It is a reasoning aid, not a ready-to-apply MDS setting. Consult the platform's distance/credit guidance and supported limits before changing a real port.

Now compare a slow-drain case. If a target accepts 1 Gbit/s while offered 3 Gbit/s for 10 seconds, the excess offered data is 20 Gbit before upstream throttling or loss changes the arrival process. Adding 1 GB of buffering cannot absorb that sustained excess indefinitely. The correct investigation follows the constraining receiver and shared queues, not just the farthest link.

In a licensed lab, use supported traffic generation and disposable storage data. First vary distance/delay or the modeled credit window while keeping the receiver healthy. Then hold the transport constant and throttle a test receiver. Compare signatures: the former tracks the bandwidth-delay window; the latter follows endpoint drain behavior and can propagate backpressure. Do not deliberately create uncontrolled slow-drain conditions on a production SAN.

For recovery, apply the narrow supported correction, rerun the same workload and compare tail latency as well as average throughput. Test the remaining path during maintenance. A result that merely shifts congestion to another ISL is not a complete fix. Record the workload, hardware, firmware, frame assumptions and untested scale limits so the conclusion remains bounded.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

**Reasoning:** The simple window requirement is rate × round-trip / frame bits = 8 e 9 ×200 e-6 /(2048×8), about 98 frames, before implementation margins. Eight credits cannot sustain the stated idealized rate over that delay. The separate target bottleneck is sustained oversubscription; increasing buffers only delays congestion. Use release-specific sizing rather than applying this simplified calculation as a production setting.

#### Guided practice

Halve the round-trip delay without changing target T. Explain which limit improves and which remains.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** The credit window needed for the long link halves in the simplified model. Target T still receives 3 Gbit/s and drains 1 Gbit/s, so backlog grows at 2 Gbit/s until finite buffering or upstream flow control constrains it.

#### Independent task

Environment: vendor

Diagnose distance-limited FC throughput separately from slow-drain congestion and validate bounded recovery under path maintenance.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Window calculation includes units and stated simplifications.
- Counters distinguish physical errors from congestion.
- Application I/O integrity and latency recover after the chosen correction.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0161 · single · calculation**

What is the approximate idealized credit window?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

1. 98 frames
2. 8 frames
3. 2048 frames

**Correct option(s):** 1

- Option 1: Correct. Bandwidth-delay product divided by frame bits gives 97.7.
- Option 2: Incorrect. That is the configured value, not the requirement.
- Option 3: Incorrect. Frame bytes are not the window count.

**CCIE-DC-Q0162 · single · implementation**

What does a returned credit signify?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

1. The whole fabric is uncongested
2. Application commit completed
3. Next-hop buffer availability

**Correct option(s):** 3

- Option 1: Incorrect. One link cannot establish that.
- Option 2: Incorrect. That is end-to-end storage semantics.
- Option 3: Correct. It is link-local flow control.

**CCIE-DC-Q0163 · single · diagnosis**

Why can clean optics coexist with low throughput?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

1. FC does not use flow control
2. Clean optics guarantee full line rate
3. Credit availability can limit sending

**Correct option(s):** 3

- Option 1: Incorrect. It does.
- Option 2: Incorrect. Other constraints remain.
- Option 3: Correct. No bit errors are required.

**CCIE-DC-Q0164 · single · implementation**

What is target T's sustained excess arrival rate?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

1. 4 Gbit/s
2. 2 Gbit/s
3. Zero

**Correct option(s):** 2

- Option 1: Incorrect. That adds rather than subtracts.
- Option 2: Correct. Offered 3 minus drained 1 equals 2.
- Option 3: Incorrect. The rates are unequal.

**CCIE-DC-Q0165 · single · diagnosis**

Why does adding finite buffering not solve target T?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

1. Sustained input exceeds output
2. Buffers never store frames
3. Buffering raises disk throughput automatically

**Correct option(s):** 1

- Option 1: Correct. Backlog eventually fills any finite buffer.
- Option 2: Incorrect. They do.
- Option 3: Incorrect. It does not repair the receiver.

**CCIE-DC-Q0166 · single · implementation**

Which counter pattern suggests credit starvation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

1. Growing transmit wait with credit-zero periods
2. Only a DHCP lease renewal
3. Only the FC login count

**Correct option(s):** 1

- Option 1: Correct. The sender lacks permission to transmit.
- Option 2: Incorrect. It is unrelated to FC credits.
- Option 3: Incorrect. Login count does not establish how long a sender waits for buffer credits.

**CCIE-DC-Q0167 · single · implementation**

What should be correlated with SAN counters?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

1. Only certificate issuer
2. Application latency and I/O rate
3. Only configured port speed

**Correct option(s):** 2

- Option 1: Incorrect. It does not quantify storage congestion.
- Option 2: Correct. User impact and offered load contextualize counters.
- Option 3: Incorrect. Nominal speed omits offered workload, useful I/O and application latency.

**CCIE-DC-Q0168 · single · implementation**

What changes if credit round trip halves?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

1. The ideal required window halves
2. Optical wavelength must double
3. Target T doubles its disk rate

**Correct option(s):** 1

- Option 1: Correct. Bandwidth-delay product is proportional to delay.
- Option 2: Incorrect. Delay does not imply that.
- Option 3: Incorrect. The endpoint limit is separate.

**CCIE-DC-Q0169 · single · diagnosis**

Why can congestion affect unrelated flows?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

1. They share constrained buffers or links
2. Zoning encrypts all queues
3. Every flow has fully independent hardware

**Correct option(s):** 1

- Option 1: Correct. Backpressure can propagate through shared resources.
- Option 2: Incorrect. Zoning is access policy.
- Option 3: Incorrect. That cannot be assumed.

**CCIE-DC-Q0170 · single · implementation**

Which correction targets a defective slow receiver?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

1. Only increase every upstream buffer
2. Rename the target alias
3. Repair or constrain that receiver's workload

**Correct option(s):** 3

- Option 1: Incorrect. That masks finite bursts but not sustained mismatch.
- Option 2: Incorrect. Names do not improve draining.
- Option 3: Correct. It addresses the draining bottleneck.

**CCIE-DC-Q0171 · single · implementation**

What must a distance calculation state?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

1. Rate, round-trip delay and frame-size assumptions
2. Only switch uptime
3. Only nominal link bandwidth

**Correct option(s):** 1

- Option 1: Correct. The window depends on all three.
- Option 2: Incorrect. It does not size credits.
- Option 3: Incorrect. Delay and frame size are also required for the window calculation.

**CCIE-DC-Q0172 · single · diagnosis**

Why test a surviving ISL under maintenance?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

1. Storage traffic always halves automatically
2. Traffic may concentrate beyond capacity
3. A removed link adds bandwidth

**Correct option(s):** 2

- Option 1: Incorrect. Workload need not decrease.
- Option 2: Correct. Normal-state adequacy is insufficient.
- Option 3: Incorrect. It removes capacity.

**CCIE-DC-Q0173 · single · implementation**

What does aggregate link capacity not guarantee?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

1. One exchange uses all members
2. All traffic stops during hashing
3. Multiple links have any capacity

**Correct option(s):** 1

- Option 1: Correct. Load sharing has flow granularity.
- Option 2: Incorrect. Hashing selects paths.
- Option 3: Incorrect. They do provide aggregate capacity.

**CCIE-DC-Q0174 · single · diagnosis**

Which first action preserves diagnostic evidence?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

1. Reset every counter immediately
2. Capture timed counter deltas
3. Reboot all targets

**Correct option(s):** 2

- Option 1: Incorrect. That loses history.
- Option 2: Correct. Resets would erase the baseline.
- Option 3: Incorrect. That broadens impact before diagnosis.

**CCIE-DC-Q0175 · single · implementation**

What distinguishes physical impairment?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

1. High latency alone
2. A large LUN number
3. Error or signal evidence tied to the path

**Correct option(s):** 3

- Option 1: Incorrect. Many layers cause latency.
- Option 2: Incorrect. Identifier value is not impairment.
- Option 3: Correct. It differs from clean-link credit waiting.

**CCIE-DC-Q0176 · single · implementation**

Which claim follows from a simplified 98-frame result?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

1. Set every port to 98 immediately
2. Eight credits are inadequate under these assumptions
3. The array is corrupt

**Correct option(s):** 2

- Option 1: Incorrect. Hardware rules and traffic differ.
- Option 2: Correct. Production allocation still needs platform guidance.
- Option 3: Incorrect. The calculation says nothing about integrity.

**CCIE-DC-Q0177 · single · diagnosis**

Why retain A/B fabric separation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

1. To replace backups
2. To limit shared storage failure domains
3. To eliminate all application retries

**Correct option(s):** 2

- Option 1: Incorrect. Path redundancy is not data recovery.
- Option 2: Correct. Two logical paths can otherwise share a fault.
- Option 3: Incorrect. Retries can still occur.

**CCIE-DC-Q0178 · single · implementation**

Which test validates post-repair service?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

1. Sustained I/O plus latency and integrity checks
2. Only a green port icon
3. Only a saved configuration

**Correct option(s):** 1

- Option 1: Correct. Line rate alone is incomplete.
- Option 2: Incorrect. It omits application behavior.
- Option 3: Incorrect. Intent does not prove performance.

**CCIE-DC-Q0179 · single · calculation**

What is the risk of tuning without a baseline?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

1. Creating a deterministic comparison
2. Mis attributing workload changes to the tuning
3. Eliminating all uncertainty

**Correct option(s):** 2

- Option 1: Incorrect. Missing baseline does the opposite.
- Option 2: Correct. Before/after comparability matters.
- Option 3: Incorrect. It increases uncertainty.

**CCIE-DC-Q0180 · single · implementation**

Which delay belongs in the window model?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic FC link model: 8 Gbit/s usable bit rate, 200 microsecond credit round trip, 2048-byte frames. Eight usable credits are configured. Optical error counters remain zero. Separately target T drains at 1 Gbit/s while offered 3 Gbit/s; upstream transmit-wait grows.

1. Only disk rebuild duration
2. Only application think time
3. The credit-return round trip

**Correct option(s):** 3

- Option 1: Incorrect. That is another timescale.
- Option 2: Incorrect. That is not link credit circulation.
- Option 3: Correct. One-way latency understates the circulation time.

#### Recall

**What is the approximate idealized credit window?**

98 frames Bandwidth-delay product divided by frame bits gives 97.7.

**Why does adding finite buffering not solve target T?**

Sustained input exceeds output Backlog eventually fills any finite buffer.

**Why can congestion affect unrelated flows?**

They share constrained buffers or links Backpressure can propagate through shared resources.

**What does aggregate link capacity not guarantee?**

One exchange uses all members Load sharing has flow granularity.

**Why retain A/B fabric separation?**

To limit shared storage failure domains Two logical paths can otherwise share a fault.

#### References

- [MDS congestion and flow-control guides](https://www.cisco.com/c/en/us/support/storage-networking/mds-9000-nx-os-san-os-software/products-installation-and-configuration-guides-list.html)

## CCIE-DC-M10 — FCoE, converged Ethernet and host multipath recovery

### CCIE-DC-L10 — FCoE, converged Ethernet and host multipath recovery

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L09

FCoE carries Fibre Channel frames over a suitable Ethernet environment while retaining FC identities and storage access dependencies. Discovery, VLAN selection, virtual FC bindings, VSAN association and end-to-end fabric policy all matter. Ethernet link-up alone cannot establish FCoE service. Distinguish FCoE discovery/control from FC login and host LUN access so that a fault is investigated at the correct stage.

Converged Ethernet uses traffic classification and queue policy to protect selected traffic classes. Priority flow control can pause an individual priority, but it introduces dependencies: incorrect class mapping can pause the wrong traffic, and persistent congestion can spread upstream. It is not a license to mark every packet as lossless. Link-wide pause, per-priority pause, scheduling and congestion notification solve different parts of the problem. Validate actual host tagging and switch classification, not merely the intended policy name.

Storage multipathing sits above fabric connectivity. The host may discover several paths to one LUN, distinguish optimized and nonoptimized ownership states, choose paths under a policy and retry during transitions. Two visible paths can still share the same failure domain. Path loss detection, retry timers, array ownership and application deadlines must be compatible. An application can fail before a theoretically surviving path is used.

Test a path withdrawal with a disposable verified dataset and monitored I/O. Record errors, latency, path-state transitions and application integrity. Restore the path and observe failback rather than assuming it is harmless; oscillating ownership can create repeated disruption. Production storage changes require the owner's approved procedure and backup/recovery context, not an ad hoc disconnect experiment.

### Implementation walkthrough: bind FCoE and host multipathing deliberately
Draw the complete chain: host adapter/virtual function → Ethernet interface → FCoE discovery and VLAN → virtual FC interface → VSAN → FC fabric services → target zoning/masking → host LUN path. At each arrow, identify the identity or encapsulation that changes. This prevents treating an Ethernet VLAN and a VSAN as interchangeable identifiers.

For a supported NX-OS/UCS/MDS lab, collect the applicable read-only interface, virtual-FC, FCoE, login and host multipath observations. Exact command families depend on platform and release; verify them against the matching guide. Keep the raw output and a normalized table containing physical link state, selected priority, PFC state, vFC binding, VSAN, initiator WWPN, target and host path state.

Commission classification before load. Generate known test traffic, inspect actual priority markings and per-class counters, and verify the class reaches the intended queue. If the host marks 4 but the switch protects 3, a policy name saying 'FCoE' is not evidence of correct treatment. Correct the approved mapping rather than enabling pause indiscriminately on every class.

At the host, record how each visible path maps to fabric A or B and to distinct physical dependencies. Two sessions through one interconnect fail together. Identify the storage controller's ownership/optimization states and the host's supported path-selection policy. Set detection/retry behavior according to the supported host/array combination and the application's deadline; do not independently minimize every timer without understanding interactions.

Run a sequence-numbered, integrity-checked disposable workload. Withdraw one approved path, observe detection, retries, selection and application completion, then restore it and observe failback. The acceptance table should show maximum interruption, errors, latency distribution and checksum outcome. If the measured 12 seconds exceeds the required 5 seconds, report failure even when every path eventually returns green. A longer timeout is a changed requirement that needs explicit owner agreement.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

**Reasoning:** Three design failures are independent: classification mismatch loses the intended treatment; VSAN mismatch prevents the intended FC relationship; shared interconnect defeats path independence. Even after these are corrected,12-second recovery does not satisfy a 5-second application requirement. Acceptance must include all four constraints.

#### Guided practice

An operator enables PFC on every priority and increases application timeout to 30 seconds. Explain why this is not a complete repair.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Global lossless treatment spreads backpressure and does not fix VSAN identity or shared fabric dependency. A longer timeout changes the application requirement rather than meeting the original one. Review whether the requirement can change explicitly; otherwise improve the recovery chain and prove the 5-second bound.

#### Independent task

Environment: vendor

Commission a converged storage path and independent multipathing with measured failover and integrity acceptance.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- FCoE classification and VSAN bindings match.
- Independent path failure is demonstrated.
- Application deadline and integrity constraints both pass.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0181 · single · implementation**

What defeats the intended PFC treatment?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

1. Host priority 4 differs from enabled 3
2. The target LUN number differs
3. The host has an IP address

**Correct option(s):** 1

- Option 1: Correct. Classification must match the protected class.
- Option 2: Incorrect. That is a storage-identity concern, not the supplied priority3/priority4 mismatch.
- Option 3: Incorrect. IP does not cause this mismatch.

**CCIE-DC-Q0182 · single · implementation**

What does VSAN 20 versus 30 explain?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

1. An automatic disk backup
2. The intended FC context does not match
3. Guaranteed congestion control

**Correct option(s):** 2

- Option 1: Incorrect. VSAN mismatch does not back up data.
- Option 2: Correct. Bindings and target fabric membership differ.
- Option 3: Incorrect. VSAN identity is not flow control.

**CCIE-DC-Q0183 · single · diagnosis**

Why are the two host paths not independent?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

1. They reach the same LUN
2. They share one fabric interconnect
3. They use different path names

**Correct option(s):** 2

- Option 1: Incorrect. Shared data identity is expected.
- Option 2: Correct. A single failure can remove both.
- Option 3: Incorrect. Names do not create independence.

**CCIE-DC-Q0184 · single · design**

Does 12-second recovery meet the requirement?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

1. Yes, two paths guarantee compliance
2. Yes, any recovery is sufficient
3. No, the deadline is 5 seconds

**Correct option(s):** 3

- Option 1: Incorrect. Count does not establish timing.
- Option 2: Incorrect. Duration is explicitly constrained.
- Option 3: Correct. Availability must match the application constraint.

**CCIE-DC-Q0185 · single · calculation**

What is the risk of PFC on every priority?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

1. Broad backpressure and coupling
2. Automatic end-to-end data integrity
3. Elimination of finite buffers

**Correct option(s):** 1

- Option 1: Correct. Lossless treatment should be scoped.
- Option 2: Incorrect. PFC does not validate data.
- Option 3: Incorrect. Buffers remain finite.

**CCIE-DC-Q0186 · single · implementation**

Which layer proves LUN access after FCoE link-up?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

1. Only IP default routing
2. FC policy and host storage discovery
3. Only LLDP neighbor presence

**Correct option(s):** 2

- Option 1: Incorrect. FCoE is not ordinary IP forwarding.
- Option 2: Correct. Ethernet state precedes these dependencies.
- Option 3: Incorrect. Discovery is not storage authorization.

**CCIE-DC-Q0187 · single · implementation**

What should host path inventory include?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

1. Only the count of visible paths
2. Ownership state and shared dependencies
3. Only display labels

**Correct option(s):** 2

- Option 1: Incorrect. Two entries can share one interconnect and differ in ownership state.
- Option 2: Correct. Path count alone is insufficient.
- Option 3: Incorrect. Labels omit failure domains.

**CCIE-DC-Q0188 · single · diagnosis**

Why compare retries with application deadlines?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

1. Retries always complete instantly
2. The application can fail before path recovery
3. Applications ignore storage delays

**Correct option(s):** 2

- Option 1: Incorrect. They consume time.
- Option 2: Correct. Lower-layer eventual recovery may be too slow.
- Option 3: Incorrect. They often have deadlines.

**CCIE-DC-Q0189 · single · implementation**

Which test is appropriate before real data exposure?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

1. Unplanned production cable removal
2. Disposable verified data with monitored I/O
3. Deleting the only backup

**Correct option(s):** 2

- Option 1: Incorrect. That lacks approved controls.
- Option 2: Correct. It bounds the integrity risk.
- Option 3: Incorrect. That removes recovery.

**CCIE-DC-Q0190 · single · implementation**

What does failback testing add?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

1. It proves no future failure
2. It duplicates only link-up testing
3. It observes restoration-induced transitions

**Correct option(s):** 3

- Option 1: Incorrect. Tests remain bounded.
- Option 2: Incorrect. Application effects can differ.
- Option 3: Correct. A returning path can cause disruption.

**CCIE-DC-Q0191 · single · implementation**

What distinguishes PFC from link-wide pause?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

1. Link-wide pause encrypts frames
2. PFC changes FC zoning
3. Priority-specific versus whole-link pausing

**Correct option(s):** 3

- Option 1: Incorrect. Pause is flow control.
- Option 2: Incorrect. It does not authorize storage.
- Option 3: Correct. The scope of blocked traffic differs.

**CCIE-DC-Q0192 · single · diagnosis**

Which evidence verifies actual classification?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

1. Packet markings and queue counters
2. Only the host's asset number
3. Only the policy description

**Correct option(s):** 1

- Option 1: Correct. Policy names may not match effective traffic.
- Option 2: Incorrect. It does not show packet treatment.
- Option 3: Incorrect. It records intent.

**CCIE-DC-Q0193 · single · implementation**

What must a vFC binding reference correctly?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

1. Its Ethernet attachment and VSAN
2. Only an application username
3. Only a DNS zone

**Correct option(s):** 1

- Option 1: Correct. Both participate in FCoE connectivity.
- Option 2: Incorrect. That is another identity layer.
- Option 3: Incorrect. DNS is unrelated to vFC binding.

**CCIE-DC-Q0194 · single · diagnosis**

Why not silently increase the deadline?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

1. It fixes all congestion
2. It changes an explicit requirement
3. It repairs physical independence

**Correct option(s):** 2

- Option 1: Incorrect. Timers do not raise drain capacity.
- Option 2: Correct. Trade-offs need owner acceptance.
- Option 3: Incorrect. Timeouts do not change topology.

**CCIE-DC-Q0195 · single · implementation**

What can nonoptimized path state affect?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

1. The number of configured VLANs alone
2. The APIC cluster size
3. Latency and preferred-path selection

**Correct option(s):** 3

- Option 1: Incorrect. Path optimization is host/array ownership behavior, not a VLAN-count property.
- Option 2: Incorrect. It is a different subsystem.
- Option 3: Correct. Array ownership influences path policy.

**CCIE-DC-Q0196 · single · implementation**

Which failure isolates path independence?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

1. Renaming one host path
2. A harmless UI refresh
3. Loss of the shared interconnect

**Correct option(s):** 3

- Option 1: Incorrect. That changes no topology.
- Option 2: Incorrect. It creates no fault.
- Option 3: Correct. It reveals both paths' common dependency.

**CCIE-DC-Q0197 · single · diagnosis**

What should recovery evidence include beyond zero I/O errors?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

1. Latency, ordering and integrity behavior
2. Only a saved config hash
3. Only a larger interface description

**Correct option(s):** 1

- Option 1: Correct. Retries may hide delay or application effects.
- Option 2: Incorrect. It omits workload behavior.
- Option 3: Incorrect. It has no operational evidence.

**CCIE-DC-Q0198 · single · implementation**

Which condition can spread pause upstream?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

1. An offline documentation server
2. A persistently slow protected receiver
3. Only a higher configured link rate upstream

**Correct option(s):** 2

- Option 1: Incorrect. No data-path dependency is supplied.
- Option 2: Correct. Backpressure can propagate through shared queues.
- Option 3: Incorrect. More upstream capacity does not remove a persistently slow protected receiver.

**CCIE-DC-Q0199 · single · diagnosis**

Why separate discovery from login?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

1. They are distinct protocol stages
2. Login replaces all Ethernet needs
3. They always occur as one atomic event

**Correct option(s):** 1

- Option 1: Correct. One may pass while the next fails.
- Option 2: Incorrect. It still requires transport.
- Option 3: Incorrect. Failures can intervene.

**CCIE-DC-Q0200 · single · implementation**

Which final result satisfies the original task?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic lab: FCoE class is intended priority 3; host emits priority 4. Switch enables PFC only on 3. vFC 20 binds to Ethernet 1/20 and VSAN 20; target is in VSAN 30. Host has two paths but both traverse the same fabric interconnect. Application deadline 5 s; measured path recovery 12 s.

1. Only showing two path entries
2. Correct policy, independent paths and recovery below 5 seconds
3. Only changing the dashboard to green

**Correct option(s):** 2

- Option 1: Incorrect. Entries do not prove independence or timing.
- Option 2: Correct. All stated constraints must hold.
- Option 3: Incorrect. Presentation is not service.

#### Recall

**What defeats the intended PFC treatment?**

Host priority 4 differs from enabled 3 Classification must match the protected class.

**What is the risk of PFC on every priority?**

Broad backpressure and coupling Lossless treatment should be scoped.

**Which test is appropriate before real data exposure?**

Disposable verified data with monitored I/O It bounds the integrity risk.

**What must a vFC binding reference correctly?**

Its Ethernet attachment and VSAN Both participate in FCoE connectivity.

**What should recovery evidence include beyond zero I/O errors?**

Latency, ordering and integrity behavior Retries may hide delay or application effects.

#### References

- [Cisco Nexus FCoE guides](https://www.cisco.com/c/en/us/support/switches/nexus-9000-series-switches/products-installation-and-configuration-guides-list.html)
- [Cisco UCS storage guides](https://www.cisco.com/c/en/us/support/servers-unified-computing/ucs-manager/products-installation-and-configuration-guides-list.html)

## CCIE-DC-M11 — UCS service profiles, identities and boot dependency graphs

### CCIE-DC-L11 — UCS service profiles, identities and boot dependency graphs

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L10

UCS separates reusable server intent from physical hardware. A service profile or corresponding supported policy model describes identities, interfaces, boot behavior, firmware and management policies. Association applies that intent to a suitable server. A template can help standardize deployment, but its update semantics determine whether later edits affect existing instances. Treat a template modification as a change with an explicit dependent-server list.

MAC and WWPN pools allocate identity; they do not establish exclusive business ownership by themselves. Avoid overlapping pools and uncontrolled profile duplication. Moving a profile can preserve externally referenced identity, which is useful for network and SAN policy but dangerous if the old instance still operates. Confirm deassociation, power state and identity withdrawal before reusing an identity elsewhere.

Boot is a dependency chain: server discovery and association, compatible firmware, adapter creation, link pinning, VLAN/VSAN connectivity, storage or network service, boot policy order and operating-system loader. An associated profile does not prove a boot device is reachable. SAN boot additionally depends on initiator identity, fabric zoning, target/LUN presentation and path availability. Local boot has different disk-controller and media dependencies.

Keep policies minimal and explicit. Define fabric A/B placement for vNICs and vHBAs, management access, desired MTU and QoS behavior, boot targets and maintenance policy. Before a profile change, determine whether it is disruptive, whether acknowledgement is required and which workload must drain. Validate the resulting hardware inventory and effective adapters, not just a successful wizard completion.

### Implementation walkthrough: provision a profile without losing identity control
Create an identity ledger before a UCS profile: server role, MAC range, WWPN range, management identity, fabric assignment, boot target and storage ownership. Reserve non-overlapping ranges and record which automation or administrator allocates them. A readable service-profile name is not a uniqueness control. Verify actual allocated identities after association.

In a UCS 4.x lab, build policies in dependency order: supported firmware package, adapter policies, VLAN/VSAN connectivity, identity pools, vNIC/vHBA templates where appropriate, boot policy and maintenance policy, then the service-profile template and instance. The exact workflow depends on the supported management mode. Export the effective profile and policy references; do not rely on screenshots of a completed wizard.

Use a boot dependency table:

| Gate | Required evidence | Example failure |
|---|---|---|
| Discovery/association | Correct server and compatible policy | Unsupported hardware |
| Adapter creation | Intended vNIC/vHBA and fabric | Wrong template reference |
| Fabric access | VLAN/VSAN and live path | Missing uplink membership |
| Storage access | Zoning and LUN presentation | Old WWPN masking |
| Boot selection | Correct target and LUN | LUN 0 requested, LUN 7 presented |
| Workload | OS and application integrity | Booted wrong device |

Move through the table using observed state. A passed earlier gate does not imply later gates pass. The supplied LUN mismatch belongs at boot selection/presentation, so changing identity pools is not the narrow first repair.

For relocation, drain and stop the disposable workload, preserve state, deassociate according to the supported procedure and prove the old identity is no longer active. Associate a compatible spare, validate each gate and verify application data. A profile move preserves selected infrastructure identity; it does not by itself transfer running application memory or guarantee zero downtime.

Before editing an updating template, list every dependent profile and classify the proposed change as nondisruptive, disruptive or unknown according to the release. Unknown is a review gate. Apply a canary, inspect actual effects and stop on failed acceptance rather than allowing a twelve-server blast radius to expand automatically.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

**Reasoning:** Association succeeds before storage boot access is established. Boot policy requests LUN 0 while the array grants LUN 7, so reconcile the intended boot device and presentation. Review all 12 template dependents before any update. Separately, duplicate MAC allocation is an identity defect that can affect network learning even if the boot issue is fixed.

#### Guided practice

Plan moving DB 01 to a spare blade without having two active owners. Include management, SAN and application checks.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Drain and shut down the workload, capture profile and path state, deassociate under the approved procedure, confirm the original identity is inactive, associate the compatible spare, validate firmware/adapters/boot paths, then verify application integrity. A profile move is not a live application migration by itself.

#### Independent task

Environment: vendor

Provision and relocate UCS compute using explicit identities, boot dependencies and controlled template updates.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- No duplicate active MAC or WWPN.
- Boot target and LUN match approved presentation.
- Template blast radius and disruptive policy effects are recorded.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0201 · single · diagnosis**

Why can association succeed while boot fails?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

1. A blade cannot boot from SAN
2. Boot storage is a later dependency
3. Association proves every LUN works

**Correct option(s):** 2

- Option 1: Incorrect. Supported SAN boot is possible.
- Option 2: Correct. Profile association is not disk access.
- Option 3: Incorrect. It does not.

**CCIE-DC-Q0202 · single · calculation**

What is the supplied boot mismatch?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

1. VSAN 10 is inherently invalid
2. Policy LUN 0 versus presented LUN 7
3. The profile name contains digits

**Correct option(s):** 2

- Option 1: Incorrect. No such constraint is supplied.
- Option 2: Correct. The requested device differs.
- Option 3: Incorrect. Names do not select LUN s.

**CCIE-DC-Q0203 · single · implementation**

What must be reviewed before editing template T?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

1. Only the newest server
2. All 12 dependent profiles
3. Only the template object itself

**Correct option(s):** 2

- Option 1: Incorrect. Older instances may be affected.
- Option 2: Correct. Update semantics can propagate changes.
- Option 3: Incorrect. Existing dependent profiles may inherit the update and must be reviewed.

**CCIE-DC-Q0204 · single · diagnosis**

Why is duplicated MAC allocation dangerous?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

1. It guarantees live migration
2. It creates ambiguous network ownership
3. It increases available bandwidth

**Correct option(s):** 2

- Option 1: Incorrect. Ownership is not migration orchestration.
- Option 2: Correct. Learning can oscillate or mis deliver.
- Option 3: Incorrect. Identity duplication does not add links.

**CCIE-DC-Q0205 · single · implementation**

What should precede identity reuse?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

1. Confirm the old instance is inactive
2. Copy the profile while both run
3. Delete all SAN records first

**Correct option(s):** 1

- Option 1: Correct. Two active owners must be prevented.
- Option 2: Incorrect. That risks duplicates.
- Option 3: Incorrect. That can remove required access.

**CCIE-DC-Q0206 · single · implementation**

Which policy defines boot-device selection?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

1. Only an administrator role
2. Boot order and target policy
3. Only a syslog destination

**Correct option(s):** 2

- Option 1: Incorrect. RBAC does not select LUN s.
- Option 2: Correct. It selects the intended boot path.
- Option 3: Incorrect. Logging does not select boot media.

**CCIE-DC-Q0207 · single · diagnosis**

Why distinguish template update semantics?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

1. Templates only contain comments
2. Existing profiles may change or remain independent
3. All templates always update instantly

**Correct option(s):** 2

- Option 1: Incorrect. They define functional intent.
- Option 2: Correct. The deployment model controls propagation.
- Option 3: Incorrect. That is not universal.

**CCIE-DC-Q0208 · single · implementation**

What validates effective adapter creation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

1. Only profile display name
2. Only rack temperature
3. Server inventory and vNIC/vHBA state

**Correct option(s):** 3

- Option 1: Incorrect. Names do not prove adapters.
- Option 2: Incorrect. It does not establish adapter state.
- Option 3: Correct. Wizard success alone is weaker.

**CCIE-DC-Q0209 · single · implementation**

What does preserving WWPN during relocation retain?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

1. The same physical blade
2. Guaranteed filesystem consistency
3. External SAN policy references

**Correct option(s):** 3

- Option 1: Incorrect. Relocation changes hardware.
- Option 2: Incorrect. That requires data and shutdown checks.
- Option 3: Correct. Storage identity can remain consistent.

**CCIE-DC-Q0210 · single · implementation**

Which condition can make association unsuitable?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

1. Different asset labels alone
2. A longer profile description
3. Hardware or firmware incompatibility

**Correct option(s):** 3

- Option 1: Incorrect. Labels do not define compatibility.
- Option 2: Incorrect. Description length is not the issue.
- Option 3: Correct. Intent must fit the target server.

**CCIE-DC-Q0211 · single · calculation**

What is the role of maintenance policy?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

1. Eliminate every reboot
2. Control disruptive application of changes
3. Replace application draining

**Correct option(s):** 2

- Option 1: Incorrect. Some changes remain disruptive.
- Option 2: Correct. Acknowledgement and scheduling matter.
- Option 3: Incorrect. Workload preparation still matters.

**CCIE-DC-Q0212 · single · implementation**

Which map proves A/B placement?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

1. Only the number of adapters
2. vNIC/vHBA fabric assignments
3. Only their display order

**Correct option(s):** 2

- Option 1: Incorrect. Counts omit placement.
- Option 2: Correct. Logical interfaces must use intended fabrics.
- Option 3: Incorrect. Order does not establish fabric selection.

**CCIE-DC-Q0213 · single · diagnosis**

Why is a profile move not live migration?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

1. Profiles cannot move
2. The operating system never restarts
3. Hardware identity transfer does not move running state

**Correct option(s):** 3

- Option 1: Incorrect. Supported relocation is possible.
- Option 2: Incorrect. It may restart.
- Option 3: Correct. Application continuity needs separate orchestration.

**CCIE-DC-Q0214 · single · implementation**

What must SAN boot commissioning include?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

1. Zoning, masking and boot-target verification
2. Only a local disk label
3. Only an Ethernet ping

**Correct option(s):** 1

- Option 1: Correct. Each authorizes a different dependency.
- Option 2: Incorrect. The boot is SAN-based.
- Option 3: Incorrect. It does not prove FC boot.

**CCIE-DC-Q0215 · single · implementation**

What should be captured before deassociation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

1. Only the desired template revision
2. Effective policies and current path state
3. Only browser history

**Correct option(s):** 2

- Option 1: Incorrect. Current allocated identities, effective policies and paths may differ from desired template state.
- Option 2: Correct. It supports rollback and comparison.
- Option 3: Incorrect. It is not a configuration backup.

**CCIE-DC-Q0216 · single · implementation**

Which repair targets overlapping pools?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

1. Increase every VLAN MTU
2. Disable syslog
3. Assign non-overlapping identity ranges

**Correct option(s):** 3

- Option 1: Incorrect. MTU does not allocate identity.
- Option 2: Incorrect. That hides evidence.
- Option 3: Correct. It prevents future collisions.

**CCIE-DC-Q0217 · single · calculation**

What is the narrow verification after LUN correction?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

1. Only save the policy
2. Only see the target WWPN
3. Boot from the intended device and validate workload

**Correct option(s):** 3

- Option 1: Incorrect. Intent is not boot success.
- Option 2: Incorrect. Target visibility is earlier in the chain.
- Option 3: Correct. Any boot device is not sufficient.

**CCIE-DC-Q0218 · single · diagnosis**

Why include management access in relocation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

1. Recovery may need independent console control
2. It substitutes for storage redundancy
3. Management carries every storage frame

**Correct option(s):** 1

- Option 1: Correct. The new server must remain operable.
- Option 2: Incorrect. It does not.
- Option 3: Incorrect. It is a separate plane.

**CCIE-DC-Q0219 · single · implementation**

Which claim follows from twelve dependent profiles?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

1. Only one server can change
2. The potential change domain is twelve profiles
3. Exactly twelve outages are inevitable

**Correct option(s):** 2

- Option 1: Incorrect. The dependency list disproves that.
- Option 2: Correct. Actual impact still depends on policy.
- Option 3: Incorrect. Impact is not established merely by dependence.

**CCIE-DC-Q0220 · single · implementation**

What closes a compute relocation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: profile DB 01 associates to blade 3. vHBA-A WWPN ends:11 in VSAN 10; boot policy targets WWPN ending:22 LUN 0. Array presents boot LUN 7. Updating template T affects 12 associated profiles. Another profile manually reuses MAC 00:25:B 5:00:01:10.

1. Correct identity, supported state, boot and application checks
2. Only the server power LED
3. Only profile association

**Correct option(s):** 1

- Option 1: Correct. All dependencies must be re-established.
- Option 2: Incorrect. Power is not workload recovery.
- Option 3: Incorrect. That is an intermediate state.

#### Recall

**Why can association succeed while boot fails?**

Boot storage is a later dependency Profile association is not disk access.

**What should precede identity reuse?**

Confirm the old instance is inactive Two active owners must be prevented.

**What does preserving WWPN during relocation retain?**

External SAN policy references Storage identity can remain consistent.

**Why is a profile move not live migration?**

Hardware identity transfer does not move running state Application continuity needs separate orchestration.

**What is the narrow verification after LUN correction?**

Boot from the intended device and validate workload Any boot device is not sufficient.

#### References

- [UCS Manager configuration guides](https://www.cisco.com/c/en/us/support/servers-unified-computing/ucs-manager/products-installation-and-configuration-guides-list.html)

## CCIE-DC-M12 — UCS forwarding paths, pinning and fabric-interconnect modes

### CCIE-DC-L12 — UCS forwarding paths, pinning and fabric-interconnect modes

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L11

Trace server traffic through guest or host networking, virtual adapter, VIC, fabric extender or chassis interconnect, fabric interconnect, uplink and upstream switch. Each stage can impose a VLAN, VSAN, MTU or policy dependency. A vNIC that appears healthy in the operating system can still be pinned to an unavailable or unsuitable uplink. Link failures, pinning changes and uplink port-channel membership should be examined together.

Fabric-interconnect switching or end-host behavior determines how the UCS domain participates in the surrounding network. Avoid importing assumptions from a standalone Ethernet switch. Supported connectivity, loop avoidance, uplink selection and server-to-server forwarding depend on the chosen mode and release. Ethernet and FC modes also have distinct consequences. Mode changes may be disruptive and require a specific migration procedure; they are not a casual troubleshooting toggle.

For a dual-fabric server, choose whether redundancy is provided by fabric failover, host bonding/multipathing or a documented combination. Duplicate mechanisms can interact badly if their assumptions conflict. A second fabric must have the required VLANs, policies and upstream paths before failover is meaningful. Do not count a configured adapter as an independent usable path until traffic has been tested through it alone.

Diagnose by selecting a concrete packet or I/O flow and comparing intended and effective state at each hop. Use counters to identify the last transmitting and first nonreceiving stage. Preserve the mapping between server adapter, FI interface and upstream port so that an operator can act on the correct physical link during an incident.

### Implementation walkthrough: build a server-to-network path ledger
Select one application packet and identify the guest/host interface, vNIC, VIC function, fabric A/B, chassis or extender link, fabric interconnect uplink, upstream switch port and destination route. Record VLAN, MTU, QoS class and link state at each step. Repeat for the alternate path; do not copy the primary row and assume symmetry.

Use the supported UCS Manager and upstream switch tools to inspect adapter state, uplink port-channel membership and effective VLAN availability. Preserve the distinction between configured and operational state. A vNIC can exist but lack a usable uplink; a host bond can report two links while one upstream path drops the application's VLAN.

In the supplied case, create a controlled test flow on VLAN 210 and capture its counters at the host, FI-A and upstream A. Withdraw A through the approved lab procedure and observe the host's selection of B. If frames reach FI-B but do not exit Po20, compare its effective allowed VLAN set with the requirement. Correct that specific omission, then repeat the flow. Do not use an FI mode change to repair a known VLAN-list defect.

Next exercise packet size. A host configured for 9000 bytes does not establish that every routed hop supports that size. Sweep sizes and locate the first drop point using counters and supported probes. Keep this test separate from the VLAN repair so a successful small packet cannot mask the remaining MTU defect.

Document the chosen FI mode and its supported forwarding assumptions. For a mode migration, create a separate change plan covering all affected servers, upstream topology, expected disruption, backup/recovery and compatibility. A mode toggle can change the architecture; it is not a harmless diagnostic command.

Acceptance requires useful traffic on each isolated path, compatible host/fabric failover behavior, known management recovery and restored baseline after each fault. Report exactly which physical dependencies were removed. If both nominal paths share one upstream switch, retain that common cause in the claim rather than calling the design fully independent.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

**Reasoning:** Host link count hides the fabric B VLAN omission. Test B alone and inspect effective VLAN membership through every hop. The separate routed MTU constraint can affect large packets after VLAN repair. Both normal and failover paths need end-to-end validation.

#### Guided practice

Explain why enabling a different FI mode is not the justified first repair, and state the evidence for the narrow fix.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** The observed defect is missing VLAN 210 on the surviving path; a mode change alters the architecture and may disrupt all servers. Correct reviewed VLAN membership, validate B forwarding, then investigate size-dependent loss separately using controlled packet sizes.

#### Independent task

Environment: vendor

Trace and troubleshoot UCS server traffic through both fabric interconnects and upstream paths under failover.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Every required VLAN/VSAN exists on each intended failover path.
- Host and fabric redundancy mechanisms are compatible.
- Large and small application traffic pass through each isolated path.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0221 · single · diagnosis**

Why does failover to B lose traffic?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

1. The host bond exposes two links
2. B uplink omits VLAN 210
3. Two host links guarantee delivery

**Correct option(s):** 2

- Option 1: Incorrect. That is observed link state, but it does not permit VLAN210 on the alternate uplink.
- Option 2: Correct. Link presence does not permit the VLAN.
- Option 3: Incorrect. They do not prove path policy.

**CCIE-DC-Q0222 · single · implementation**

What does host bonding up prove?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

1. Both fabrics are independent
2. The host sees usable link state
3. Every upstream route exists

**Correct option(s):** 2

- Option 1: Incorrect. Topology must establish that.
- Option 2: Correct. It does not prove upstream VLAN continuity.
- Option 3: Incorrect. That is beyond host link state.

**CCIE-DC-Q0223 · single · implementation**

Which additional defect affects large packets?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

1. The server rack label
2. The VLAN number 210
3. A downstream 1500-MTU hop

**Correct option(s):** 3

- Option 1: Incorrect. It has no packet-size effect.
- Option 2: Incorrect. VLAN ID does not set MTU.
- Option 3: Correct. End-to-end size support is inconsistent.

**CCIE-DC-Q0224 · single · diagnosis**

Why avoid a casual FI mode toggle?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

1. It always repairs downstream MTU
2. It changes supported forwarding architecture
3. It only changes a comment

**Correct option(s):** 2

- Option 1: Incorrect. MTU remains separate.
- Option 2: Correct. The scope is much broader than one VLAN.
- Option 3: Incorrect. Mode affects operation.

**CCIE-DC-Q0225 · single · implementation**

What identifies the correct physical troubleshooting path?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

1. Adapter-to-FI-to-uplink mapping
2. Only server CPU count
3. Only an application username

**Correct option(s):** 1

- Option 1: Correct. Logical and physical identities must be linked.
- Option 2: Incorrect. It does not map forwarding.
- Option 3: Incorrect. It does not locate cables.

**CCIE-DC-Q0226 · single · implementation**

What should be tested before enabling failover?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

1. Only the primary path twice
2. Only controller login
3. The alternate path in isolation

**Correct option(s):** 3

- Option 1: Incorrect. That never exercises B.
- Option 2: Incorrect. It does not test server traffic.
- Option 3: Correct. Latent policy omissions otherwise remain hidden.

**CCIE-DC-Q0227 · single · implementation**

Which state can change after an uplink failure?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

1. Every MAC pool automatically
2. Every disk's data format
3. Traffic pinning or path selection

**Correct option(s):** 3

- Option 1: Incorrect. Identity allocation need not change.
- Option 2: Incorrect. Network failure does not reformat disks.
- Option 3: Correct. The surviving egress may differ.

**CCIE-DC-Q0228 · single · diagnosis**

Why inspect both host and fabric redundancy?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

1. Host redundancy is always irrelevant
2. Their assumptions can interact
3. Fabric redundancy removes OS behavior

**Correct option(s):** 2

- Option 1: Incorrect. It can control failover.
- Option 2: Correct. Two mechanisms do not automatically compose safely.
- Option 3: Incorrect. The OS still selects paths.

**CCIE-DC-Q0229 · single · implementation**

What does a last-transmit/first-missing counter pair provide?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

1. A complete application transaction
2. A narrower fault location
3. Proof of the final root cause alone

**Correct option(s):** 2

- Option 1: Incorrect. Counters do not establish that.
- Option 2: Correct. It brackets where traffic disappears.
- Option 3: Incorrect. Several mechanisms can exist there.

**CCIE-DC-Q0230 · single · implementation**

Which repair directly addresses the observed failover defect?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

1. Permit approved VLAN 210 along B
2. Disable all VLAN filtering
3. Replace every server

**Correct option(s):** 1

- Option 1: Correct. It restores the missing path membership.
- Option 2: Incorrect. That discards segmentation.
- Option 3: Incorrect. The evidence does not justify that.

**CCIE-DC-Q0231 · single · implementation**

What is needed after the VLAN repair?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

1. Assume all requirements now pass
2. Repeat size and failover tests
3. Erase the baseline

**Correct option(s):** 2

- Option 1: Incorrect. Only one defect was fixed.
- Option 2: Correct. The independent MTU fault remains.
- Option 3: Incorrect. It supports comparison.

**CCIE-DC-Q0232 · single · diagnosis**

Why record FI mode in the as-built?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

1. It guarantees every upstream topology is supported
2. Forwarding assumptions depend on it
3. It replaces software-version data

**Correct option(s):** 2

- Option 1: Incorrect. Mode defines forwarding assumptions but does not authorize unsupported combinations.
- Option 2: Correct. A generic switch model may be wrong.
- Option 3: Incorrect. Both are needed.

**CCIE-DC-Q0233 · single · implementation**

Which claim requires actual alternate-path traffic?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

1. That two vNIC objects exist
2. That a policy has a name
3. That B is a usable redundancy path

**Correct option(s):** 3

- Option 1: Incorrect. Inventory can show that.
- Option 2: Incorrect. Configuration can show that.
- Option 3: Correct. Configuration alone cannot establish usability.

**CCIE-DC-Q0234 · single · implementation**

What should a mode migration include?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

1. Only changing interface descriptions
2. Only a quick toggle during peak load
3. Supported procedure and workload impact analysis

**Correct option(s):** 3

- Option 1: Incorrect. That does not migrate mode.
- Option 2: Incorrect. That lacks controlled preparation.
- Option 3: Correct. It can affect the entire domain.

**CCIE-DC-Q0235 · single · implementation**

Which layer can impose a different MTU?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

1. Host, adapter, fabric and routed path
2. Only the syslog server
3. Only the source host setting

**Correct option(s):** 1

- Option 1: Correct. All contribute to the effective limit.
- Option 2: Incorrect. It is not on this data path.
- Option 3: Incorrect. Intermediate adapters, fabric and routed hops can impose lower limits.

**CCIE-DC-Q0236 · single · diagnosis**

Why preserve upstream port identities?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

1. To eliminate backups
2. To guarantee zero latency
3. To operate the intended link during incidents

**Correct option(s):** 3

- Option 1: Incorrect. They are unrelated.
- Option 2: Incorrect. Labels do not alter latency.
- Option 3: Correct. Wrong-port actions can expand impact.

**CCIE-DC-Q0237 · single · implementation**

What does Ethernet end-host behavior not imply?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

1. That servers have connectivity policies
2. That FI acts like every standalone switch
3. That uplink selection matters

**Correct option(s):** 2

- Option 1: Incorrect. They do.
- Option 2: Correct. Supported behavior is mode-specific.
- Option 3: Incorrect. It does.

**CCIE-DC-Q0238 · single · implementation**

What must be checked for FC mode separately?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

1. Its supported fabric/login behavior
2. Only IP DHCP options
3. Only wireless channel width

**Correct option(s):** 1

- Option 1: Correct. Ethernet assumptions do not automatically apply.
- Option 2: Incorrect. FC login differs.
- Option 3: Incorrect. It is unrelated.

**CCIE-DC-Q0239 · single · implementation**

Which result is insufficient for failover acceptance?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

1. Both links show green simultaneously
2. B policies and counters match the flow
3. Application traffic passes with A withdrawn

**Correct option(s):** 1

- Option 1: Correct. Neither alternate-path service nor independence is proven.
- Option 2: Incorrect. That supports the path trace.
- Option 3: Incorrect. That is relevant evidence.

**CCIE-DC-Q0240 · single · implementation**

What should rollback restore after a broad change?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic UCS 4.x: vNIC-App on fabric A uses VLAN 210 and MTU 9000. FI-A uplink Po 10 carries 210; FI-B uplink Po 20 permits only 110. Host bonding reports two links. A NIC failover sends traffic through B and application packets disappear. Upstream switch A has IP MTU 9000; a routed downstream hop has 1500.

1. Only the ticket status
2. Mode, policies and verified traffic behavior
3. Only the dashboard layout

**Correct option(s):** 2

- Option 1: Incorrect. Administrative closure is not recovery.
- Option 2: Correct. Configuration and service both matter.
- Option 3: Incorrect. It does not restore forwarding.

#### Recall

**Why does failover to B lose traffic?**

B uplink omits VLAN 210 Link presence does not permit the VLAN.

**What identifies the correct physical troubleshooting path?**

Adapter-to-FI-to-uplink mapping Logical and physical identities must be linked.

**What does a last-transmit/first-missing counter pair provide?**

A narrower fault location It brackets where traffic disappears.

**Which claim requires actual alternate-path traffic?**

That B is a usable redundancy path Configuration alone cannot establish usability.

**What does Ethernet end-host behavior not imply?**

That FI acts like every standalone switch Supported behavior is mode-specific.

#### References

- [UCS Manager networking guides](https://www.cisco.com/c/en/us/support/servers-unified-computing/ucs-manager/products-installation-and-configuration-guides-list.html)

## CCIE-DC-M13 — Firmware compatibility, maintenance sequencing and rollback boundaries

### CCIE-DC-L13 — Firmware compatibility, maintenance sequencing and rollback boundaries

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L12

Firmware is a compatibility graph, not a collection of independently latest versions. Server BIOS, management controller, adapter firmware, FI software, drivers, operating system and storage support matrices can constrain one another. A signed image establishes origin/integrity under a trust model; it does not prove compatibility with the workload. Record the exact approved bundle, hardware revisions and driver dependencies before scheduling change.

Separate preparatory download from activation. Downloading an image may be non disruptive while activation requires reboot, adapter reset or cluster transition. A rolling plan relies on the other node actually carrying the workload, not simply being powered on. Drain, validate surviving capacity, capture recoverable state, activate one failure domain, test service and only then proceed. Stop when an intermediate gate fails.

Rollback can be constrained by configuration schema migration, bootloader changes, supported downgrade paths and dependent component versions. A configuration backup cannot restore a firmware binary, and an old firmware image may not understand a new configuration. Prove a supported recovery path in a representative lab; if none exists, explicitly treat restoration as a rebuild with its required downtime and data safeguards.

### Implementation walkthrough: turn a version list into a compatibility graph
Construct a matrix with rows for BIOS, management controller, VIC/adapter firmware, FI/UCS software, host driver, hypervisor/OS and storage integration. For each proposed version record its supporting compatibility reference, required neighbors in the graph, activation effect and supported downgrade or recovery path. 'Latest' is not a compatibility reference. A signed image can be authentic while still unsupported with the current driver.

Separate four states in the maintenance record: downloaded, verified, staged and running. Capture the running version before and after activation. A file transfer success cannot prove that a component rebooted into the intended image, and a boot success cannot prove its adapters use the intended driver/firmware pair.

The rolling procedure is conditional. First verify that the surviving node can carry representative load within latency, capacity and storage limits. Drain node1 and prove workload moved; then activate only the approved components. Validate hardware inventory, adapter state, boot paths, management, storage I/O and application behavior. If any gate fails, stop before node2. The remaining maintenance-window time does not override the failed gate.

Use a recovery decision table. If the supported downgrade preserves configuration and dependencies, rehearse it in the representative lab. If schema migration or component dependencies make downgrade unsupported, plan a rebuild from a compatible recovery set with explicit data and downtime consequences. Do not describe an old binary plus a configuration file as a proven rollback until the restore has been exercised.

Record performance before and after under comparable workload. If latency doubles, investigate host driver, path selection, offload and firmware changes before attributing everything to network congestion. Preserve independent console access throughout. At closeout, distinguish installation complete, service validated and recovery demonstrated; they are separate states, and a failed recovery test remains a programme gap even if the new version currently runs.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

**Reasoning:** The proposal violates the verified compatibility chain. Do not activate adapter 6 merely because it is signed. Retain the supported combination or plan the OS/driver transition as a separate validated project.70% surviving utilization leaves nominal 30% headroom but does not establish latency or burst compliance. The unverified downgrade path is an unresolved recovery gate.

#### Guided practice

Prepare an activation plan that stops after the first node if storage latency doubles beyond its limit.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Precheck compatibility and backups; drain node 1; verify node 2 workload and storage limits; activate node 1; validate boot, drivers, paths and application; stop when the latency gate fails. Diagnose or execute the supported rollback before touching node 2.

#### Independent task

Environment: vendor

Execute a compatibility-driven compute maintenance plan with explicit stop points and a tested recovery route.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Every component pair is supported.
- Surviving capacity meets workload limits.
- Recovery procedure is proven within its stated fidelity.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0241 · single · diagnosis**

Why reject adapter 6 now?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

1. Its signature is necessarily invalid
2. Required D 4 is unsupported by the OS
3. FI4.2 cannot run any adapter

**Correct option(s):** 2

- Option 1: Incorrect. No signature fault is supplied.
- Option 2: Correct. The compatibility chain is broken.
- Option 3: Incorrect. The approved matrix includes adapter 5.

**CCIE-DC-Q0242 · single · implementation**

What does a valid signature establish?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

1. A supported downgrade
2. Workload compatibility
3. Image integrity and signer trust

**Correct option(s):** 3

- Option 1: Incorrect. That requires release guidance.
- Option 2: Incorrect. Signing does not test the OS.
- Option 3: Correct. Compatibility remains separate.

**CCIE-DC-Q0243 · single · implementation**

Which step may be disruptive despite successful download?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

1. Reviewing the support matrix
2. Activation
3. Recording the image hash

**Correct option(s):** 2

- Option 1: Incorrect. That changes no device.
- Option 2: Correct. It can reset or reboot hardware.
- Option 3: Incorrect. That is observational.

**CCIE-DC-Q0244 · single · implementation**

What does 70% surviving utilization show?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

1. Nominal 30% capacity headroom
2. A 70% reserve
3. Guaranteed deadline compliance

**Correct option(s):** 1

- Option 1: Correct. Latency and bursts still require testing.
- Option 2: Incorrect. That reverses used and free capacity.
- Option 3: Incorrect. Utilization alone is insufficient.

**CCIE-DC-Q0245 · single · implementation**

When should node 2 maintenance stop?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

1. When node 1 validation fails
2. Never during an approved window
3. Only after both nodes fail

**Correct option(s):** 1

- Option 1: Correct. Proceeding would remove the remaining safe state.
- Option 2: Incorrect. Approval does not override failed acceptance.
- Option 3: Incorrect. That ignores the gate.

**CCIE-DC-Q0246 · single · implementation**

Which artifact cannot alone restore firmware?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

1. A verified recovery image
2. The approved image bundle
3. A configuration backup

**Correct option(s):** 3

- Option 1: Incorrect. It can support recovery.
- Option 2: Incorrect. It supplies binaries, though procedure is still needed.
- Option 3: Correct. It does not contain every required binary.

**CCIE-DC-Q0247 · single · diagnosis**

Why verify downgrade support?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

1. All vendors forbid every downgrade
2. New state may be incompatible with old software
3. Signed images never change schemas

**Correct option(s):** 2

- Option 1: Incorrect. That universal claim is unsupported.
- Option 2: Correct. Image availability is not recoverability.
- Option 3: Incorrect. They can.

**CCIE-DC-Q0248 · single · implementation**

What must draining validate?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

1. Only the command's syntax
2. Workload actually moved and remains healthy
3. Only node power state

**Correct option(s):** 2

- Option 1: Incorrect. That does not show outcome.
- Option 2: Correct. A drain command can fail or be partial.
- Option 3: Incorrect. Power does not locate workload.

**CCIE-DC-Q0249 · single · implementation**

Which risk arises from updating both nodes together?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

1. Loss of the surviving recovery path
2. Automatic driver compatibility
3. Guaranteed twice the throughput

**Correct option(s):** 1

- Option 1: Correct. The change becomes a common cause.
- Option 2: Incorrect. Parallelism does not fix versions.
- Option 3: Incorrect. Maintenance removes service resources.

**CCIE-DC-Q0250 · single · implementation**

What should the prechange inventory capture?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

1. Hardware, firmware, drivers and OS versions
2. Only the target bundle name
3. Only asset purchase dates

**Correct option(s):** 1

- Option 1: Correct. Compatibility spans the stack.
- Option 2: Incorrect. That omits current dependencies.
- Option 3: Incorrect. Dates do not identify software state.

**CCIE-DC-Q0251 · single · diagnosis**

Why test storage after adapter activation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

1. Signed firmware guarantees latency
2. Storage paths are always independent of adapters
3. Adapter and driver changes affect I/O

**Correct option(s):** 3

- Option 1: Incorrect. It does not.
- Option 2: Incorrect. They use them.
- Option 3: Correct. Boot success does not prove storage behavior.

**CCIE-DC-Q0252 · single · calculation**

What is the proper response to no supported downgrade?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

1. Assume old configuration forces rollback
2. Ignore recovery because activation is signed
3. Plan a bounded rebuild/recovery route

**Correct option(s):** 3

- Option 1: Incorrect. It may be unreadable.
- Option 2: Incorrect. Signing does not prevent failure.
- Option 3: Correct. Do not invent reversibility.

**CCIE-DC-Q0253 · single · implementation**

Which observation distinguishes download from activation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

1. Only transfer completion
2. Running versus staged version
3. Only image filename

**Correct option(s):** 2

- Option 1: Incorrect. It confirms staging.
- Option 2: Correct. Stored images need not be executing.
- Option 3: Incorrect. Names do not prove running state.

**CCIE-DC-Q0254 · single · implementation**

What must a canary represent?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

1. Relevant hardware and workload dependencies
2. Only an idle management VM
3. Only the smallest spare

**Correct option(s):** 1

- Option 1: Correct. An unrelated server gives weak evidence.
- Option 2: Incorrect. It may omit adapter behavior.
- Option 3: Incorrect. Size alone does not establish fidelity.

**CCIE-DC-Q0255 · single · diagnosis**

Why retain prechange performance evidence?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

1. To replace recovery testing
2. To evaluate regression under comparable load
3. To prove every difference is caused by firmware

**Correct option(s):** 2

- Option 1: Incorrect. Baseline is not recovery.
- Option 2: Correct. A new number needs context.
- Option 3: Incorrect. Other variables must still be controlled.

**CCIE-DC-Q0256 · single · implementation**

What is a valid stop criterion?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

1. The calendar window has time left
2. Storage latency exceeds the agreed limit
3. An engineer feels the screen is slow

**Correct option(s):** 2

- Option 1: Incorrect. Time remaining does not establish safety.
- Option 2: Correct. It is measurable and service-related.
- Option 3: Incorrect. That is not a defined acceptance measure.

**CCIE-DC-Q0257 · single · implementation**

Which step protects recovery authority?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

1. Maintain independent console and credentials
2. Revoke all recovery access before activation
3. Use only the path being upgraded

**Correct option(s):** 1

- Option 1: Correct. Failed in-band paths may block repair.
- Option 2: Incorrect. That can prevent restoration.
- Option 3: Incorrect. That shares the fault.

**CCIE-DC-Q0258 · single · implementation**

What should change approval include?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

1. Compatibility evidence and failure plan
2. Only the vendor's latest-version label
3. Only the file's size

**Correct option(s):** 1

- Option 1: Correct. Approval needs concrete reviewable content.
- Option 2: Incorrect. Latest is not suitability.
- Option 3: Incorrect. Size does not prove support.

**CCIE-DC-Q0259 · single · diagnosis**

Why repeat workload tests after failback?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

1. Restored topology can change paths and load
2. Failback cannot affect I/O
3. The first node boot test covers every path

**Correct option(s):** 1

- Option 1: Correct. Recovery itself can introduce regression.
- Option 2: Incorrect. It can.
- Option 3: Incorrect. It does not.

**CCIE-DC-Q0260 · single · calculation**

What is the defensible maintenance claim?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic approved matrix: FI 4.2 requires adapter A firmware 5 and driver D 3; proposed server bundle contains adapter A 6 requiring D 4. Production OS supports D 3 only. Two-node workload uses 70% capacity per node after one fails. Activation reboots a node. Rollback image exists, but downgrade support is unverified.

1. All newer bundles are safe
2. The tested stack met specified gates
3. No future upgrade needs testing

**Correct option(s):** 2

- Option 1: Incorrect. That extrapolates beyond evidence.
- Option 2: Correct. Evidence remains configuration-scoped.
- Option 3: Incorrect. Dependencies continue changing.

#### Recall

**Why reject adapter 6 now?**

Required D 4 is unsupported by the OS The compatibility chain is broken.

**When should node 2 maintenance stop?**

When node 1 validation fails Proceeding would remove the remaining safe state.

**Which risk arises from updating both nodes together?**

Loss of the surviving recovery path The change becomes a common cause.

**Which observation distinguishes download from activation?**

Running versus staged version Stored images need not be executing.

**Which step protects recovery authority?**

Maintain independent console and credentials Failed in-band paths may block repair.

#### References

- [UCS firmware and compatibility guidance](https://www.cisco.com/c/en/us/support/servers-unified-computing/ucs-manager/products-installation-and-configuration-guides-list.html)

## CCIE-DC-M14 — Virtual switching, SR-IOV and virtualization fault boundaries

### CCIE-DC-L14 — Virtual switching, SR-IOV and virtualization fault boundaries

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L13

A host's virtual network adds forwarding, policy and resource boundaries. Trace a packet through guest interface, virtual switch or passthrough function, host uplink and physical fabric. VLAN tagging may be performed by the guest, virtual switch or external policy; duplicate or missing tags can result when ownership is ambiguous. A guest ping to its gateway does not establish every uplink, queue or migration path.

SR-IOV exposes virtual functions from a physical adapter to guests. It can reduce software-path overhead but changes where switching, capture and enforcement occur, and can constrain migration or observability. Do not assume a hypervisor virtual-switch capture includes bypassed traffic. NIC firmware, driver, IOMMU isolation, resource allocation and upstream policy become critical dependencies.

Overlay networks inside the hypervisor may add encapsulation on top of a physical overlay. Calculate the complete packet-size budget and identify where each tunnel terminates. Offloads can also make captures misleading: a host capture may show large segments before hardware segmentation or checksum completion. Compare capture location and offload behavior before claiming malformed wire traffic.

Commission with guest-to-guest, guest-to-external and migration tests; include VLAN isolation, anti-spoof policy, uplink loss and resource contention. For passthrough workloads, validate the actual enforcement location and retain a recovery path when device assignment fails.

### Implementation walkthrough: observe the actual virtual packet path
Draw separate paths for a software-switched VM and an SR-IOV-assigned VM. Mark where VLAN tags are added, where security policy is enforced, where encapsulation occurs and where captures can observe packets. For the software path, the hypervisor switch may provide a useful observation point; for the VF path, traffic can bypass it and require adapter or external capture. Do not interpret absence from an inapplicable capture point as absence of traffic.

Create a capture comparison using a disposable TCP transfer. A host-side capture may show large pre-segmentation buffers and checksums awaiting hardware completion. A wire-side capture should show the actual transmitted packets. Compare sequence numbers and payload progression rather than expecting the two captures to have identical packet boundaries. Document offload settings and capture location before declaring malformed traffic.

For nested overlays, make a header stack from the workload outward. Include the guest overlay, its transport, any physical-fabric overlay and the actual outer link framing. Determine which device terminates each layer. A single 50-byte allowance is not enough when two separate VXLAN-like encapsulations are simultaneously present. Verify the actual design; some deployments terminate one overlay before another segment rather than stacking both everywhere.

Test policy on each path. An anti-spoof rule in a software switch may not apply to a VF bypass path; verify the supported adapter/upstream enforcement. Use an unauthorized source identity in the isolated lab and confirm denial without disrupting approved traffic. Then test device assignment loss, host uplink loss and workload placement changes.

Migration support must be checked for the exact passthrough and platform combination. If moving the workload changes it from VF to software switching, repeat performance, isolation and observability tests. Retaining an IP address does not establish equivalent enforcement or latency. Record IOMMU/device-isolation assumptions and the actual recovery procedure for a failed assignment.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

**Reasoning:** Absence from the vSwitch capture does not prove VM-A is silent because its SR-IOV path can bypass that observation point. The host capture reflects offload staging rather than necessarily bad wire frames. Count both overlay layers when validating MTU; one 50-byte allowance is insufficient for double encapsulation.

#### Guided practice

Choose capture and policy-verification points for VM-A and explain what changes if it is migrated to a software-switch path.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Observe at VF/adapter-supported telemetry or the physical uplink and validate upstream policy. A move to software switching changes the observation and enforcement path; recheck performance, policy and packet-size behavior rather than assuming equivalence.

#### Independent task

Environment: vendor

Diagnose virtual and passthrough network paths with accurate capture interpretation and explicit enforcement boundaries.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Capture locations match actual forwarding.
- Nested encapsulation fits the path.
- Isolation survives uplink and workload-placement changes.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0261 · single · diagnosis**

Why is VM-A absent from vSwitch capture?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

1. VM-A necessarily sends no traffic
2. Its VF path may bypass that switch
3. The physical switch drops all A traffic

**Correct option(s):** 2

- Option 1: Incorrect. The capture point is incomplete.
- Option 2: Correct. Observation scope matters.
- Option 3: Incorrect. No such evidence is supplied.

**CCIE-DC-Q0262 · single · implementation**

What explains valid wire checksums after bad host checksums?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

1. TCP accepts all corrupt checksums
2. The wire capture must be forged
3. Checksum offload completes later

**Correct option(s):** 3

- Option 1: Incorrect. That is not the explanation.
- Option 2: Incorrect. No evidence supports that.
- Option 3: Correct. Pre-offload captures differ from wire data.

**CCIE-DC-Q0263 · single · diagnosis**

Why are 64 KB host segments not automatically wire giants?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

1. MTU is irrelevant to TCP
2. Ethernet universally carries 64 KB frames
3. Segmentation offload can split them

**Correct option(s):** 3

- Option 1: Incorrect. Wire packets still face MTU.
- Option 2: Incorrect. It does not.
- Option 3: Correct. Capture occurs before hardware work.

**CCIE-DC-Q0264 · single · calculation**

What must the MTU budget include?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

1. Both overlay encapsulations
2. Only the physical VXLAN overhead
3. Only guest payload

**Correct option(s):** 1

- Option 1: Correct. Nested headers accumulate.
- Option 2: Incorrect. That omits the guest overlay.
- Option 3: Incorrect. That omits all headers.

**CCIE-DC-Q0265 · single · implementation**

What does SR-IOV change besides performance?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

1. Enforcement and observability location
2. Storage data ownership automatically
3. Every upstream route

**Correct option(s):** 1

- Option 1: Correct. Traffic may bypass software functions.
- Option 2: Incorrect. That is separate.
- Option 3: Incorrect. SR-IOV does not replace routing.

**CCIE-DC-Q0266 · single · implementation**

Which control helps device DMA isolation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

1. IOMMU and supported assignment policy
2. Only a VLAN name
3. Only a TCP port filter

**Correct option(s):** 1

- Option 1: Correct. Direct device access needs memory isolation.
- Option 2: Incorrect. It does not constrain DMA.
- Option 3: Incorrect. That does not isolate device memory access.

**CCIE-DC-Q0267 · single · implementation**

Where should actual wire behavior be verified?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

1. Only pre-offload host capture
2. A suitable external or hardware capture point
3. Only a GUI throughput summary

**Correct option(s):** 2

- Option 1: Incorrect. That can show incomplete processing.
- Option 2: Correct. It observes post-offload packets.
- Option 3: Incorrect. It omits packet structure.

**CCIE-DC-Q0268 · single · implementation**

What can constrain live migration of passthrough guests?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

1. The guest's display name
2. The existence of any IP address
3. Device assignment and platform support

**Correct option(s):** 3

- Option 1: Incorrect. Names are not the key dependency.
- Option 2: Incorrect. Addresses alone do not prevent migration.
- Option 3: Correct. Direct hardware state is not always portable.

**CCIE-DC-Q0269 · single · diagnosis**

Why define VLAN-tagging ownership?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

1. To avoid missing or duplicate tags
2. To choose CPU frequency
3. To eliminate all VLAN policy

**Correct option(s):** 1

- Option 1: Correct. Multiple layers can modify encapsulation.
- Option 2: Incorrect. Tagging does not determine clock speed.
- Option 3: Incorrect. Ownership clarifies rather than removes policy.

**CCIE-DC-Q0270 · single · implementation**

Which test covers VF isolation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

1. Attempt prohibited traffic through the VF path
2. Only test VM-B
3. Only inspectv Switch counters

**Correct option(s):** 1

- Option 1: Correct. Software-switch tests may not exercise it.
- Option 2: Incorrect. VM-B uses another path.
- Option 3: Incorrect. A's traffic may bypass them.

**CCIE-DC-Q0271 · single · implementation**

What does guest gateway ping omit?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

1. The guest's source address
2. Other paths, sizes and service policy
3. All evidence of any forwarding

**Correct option(s):** 2

- Option 1: Incorrect. The probe includes one.
- Option 2: Correct. It is a narrow reachability test.
- Option 3: Incorrect. It does show some forwarding.

**CCIE-DC-Q0272 · single · implementation**

What should be revalidated after switching A to software forwarding?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

1. Only VM-A's name
2. Nothing because its IP is unchanged
3. Policy, performance and capture assumptions

**Correct option(s):** 3

- Option 1: Incorrect. That does not test behavior.
- Option 2: Incorrect. Identity persistence is not path equivalence.
- Option 3: Correct. The path changed.

**CCIE-DC-Q0273 · single · implementation**

Which resource can limit many VFs?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

1. Adapter queues and supported allocation
2. Only DNS cache entries
3. Only switch documentation pages

**Correct option(s):** 1

- Option 1: Correct. Virtual functions share finite hardware.
- Option 2: Incorrect. They do not allocate VFs.
- Option 3: Incorrect. They are not resources.

**CCIE-DC-Q0274 · single · implementation**

What identifies double encapsulation directly?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

1. Only a service ticket title
2. Headers at appropriate tunnel boundaries
3. Only a VLAN description

**Correct option(s):** 2

- Option 1: Incorrect. It does not show packets.
- Option 2: Correct. A single endpoint counter is insufficient.
- Option 3: Incorrect. It does not show tunnels.

**CCIE-DC-Q0275 · single · diagnosis**

Why compare guest and wire captures?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

1. To avoid checking timestamps
2. To locate transformations and offloads
3. To require byte-identical captures always

**Correct option(s):** 2

- Option 1: Incorrect. Correlation needs timing.
- Option 2: Correct. Different points reveal different stages.
- Option 3: Incorrect. Offloads can make them differ legitimately.

**CCIE-DC-Q0276 · single · implementation**

What should anti-spoof validation exercise?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

1. Only a guest reboot
2. Unauthorized source identity on the real path
3. Only allowed source traffic

**Correct option(s):** 2

- Option 1: Incorrect. It does not test source filtering.
- Option 2: Correct. Configured intent may not enforce there.
- Option 3: Incorrect. That omits the negative case.

**CCIE-DC-Q0277 · single · implementation**

What is a risk of assuming vSwitch firewall coverage?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

1. Every VF is necessarily malicious
2. VF traffic may bypass enforcement
3. All physical policies disappear

**Correct option(s):** 2

- Option 1: Incorrect. Path architecture is not intent.
- Option 2: Correct. The effective boundary differs.
- Option 3: Incorrect. Upstream controls can still apply.

**CCIE-DC-Q0278 · single · implementation**

Which failure test evaluates recovery access?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

1. Only a browser reload
2. Only log rotation
3. Loss of assigned device or host uplink

**Correct option(s):** 3

- Option 1: Incorrect. It creates no data-path failure.
- Option 2: Incorrect. It does not test assignment recovery.
- Option 3: Correct. The management route must remain usable.

**CCIE-DC-Q0279 · single · implementation**

What does an unchanged IP after migration prove?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

1. Every offload setting is identical
2. Address identity was retained
3. All latency requirements pass

**Correct option(s):** 2

- Option 1: Incorrect. Hardware may differ.
- Option 2: Correct. It does not prove policy equivalence.
- Option 3: Incorrect. Measurement is still needed.

**CCIE-DC-Q0280 · single · diagnosis**

Which closeout evidence is strongest in virtual switching, sr-iov and virtualization fault boundaries?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic host: VM-A uses SR-IOV VF 2; VM-B uses software vSwitch. vSwitch capture sees B but not A. Guest overlay adds 50 bytes over a physical VXLAN path. Host capture reports 64 KB TCP segments with unfinished checksums; wire capture reports ordinary segmented packets with valid checksums.

1. Path-specific policy tests and post-offload traffic evidence
2. Only the advertised NIC speed
3. Only successful VM creation

**Correct option(s):** 1

- Option 1: Correct. It validates effective forwarding.
- Option 2: Incorrect. Speed is not delivered service.
- Option 3: Incorrect. Creation precedes network commissioning.

#### Recall

**Why is VM-A absent from vSwitch capture?**

Its VF path may bypass that switch Observation scope matters.

**What does SR-IOV change besides performance?**

Enforcement and observability location Traffic may bypass software functions.

**Why define VLAN-tagging ownership?**

To avoid missing or duplicate tags Multiple layers can modify encapsulation.

**Which resource can limit many VFs?**

Adapter queues and supported allocation Virtual functions share finite hardware.

**What is a risk of assuming vSwitch firewall coverage?**

VF traffic may bypass enforcement The effective boundary differs.

#### References

- [Cisco UCS virtual-adapter guides](https://www.cisco.com/c/en/us/support/servers-unified-computing/ucs-manager/products-installation-and-configuration-guides-list.html)
- [Cisco Nexus virtual networking guides](https://www.cisco.com/c/en/us/support/switches/nexus-9000-series-switches/products-installation-and-configuration-guides-list.html)

## CCIE-DC-M15 — APIC and NX-API transactions, object models and safe retries

### CCIE-DC-L15 — APIC and NX-API transactions, object models and safe retries

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L14

An HTTP success code describes a protocol transaction, not necessarily the requested network outcome. A controller can accept intent before asynchronous deployment completes, and some APIs return structured errors inside an otherwise successful HTTP response. Parse status, body and task state, then verify the managed object and actual service. Keep request IDs and timestamps so a retry can be correlated with the original operation.

APIC's managed-object model represents configuration as objects with distinguished names, attributes and relationships. A relationship references another object; a syntactically accepted target can still be absent or operationally unsuitable. NX-API exposes platform operations through supported interfaces, but CLI-like and model-driven workflows have different parsing and idempotence properties. Pin schemas and product versions instead of assuming one response structure across releases.

Retries require knowledge of the operation. A read is usually safe to repeat, while a creation, allocation or non-idempotent action can duplicate state. If a timeout occurs after the server applied a write, blindly repeating it can be wrong. Read the effective state or task identity, reconcile against the desired state and retry only the missing operation. Bound retries, backoff and total time; stop on authorization or validation failures rather than hammering the controller.

Use least-privilege service identities, validated TLS, protected secrets and redacted logs. A powerful API token is execution authority. A read-only analysis assistant must not silently inherit a write token. Separate proposed changes, approval and execution, and store enough evidence to reconstruct what was actually applied.

### Implementation walkthrough: implement a semantic API state machine
Use a disposable controller or a local HTTP fixture for code development. A production token is unnecessary for learning request parsing. Represent each response as transport status, structured body, operation/task identity and observed effective state. Keep secrets out of both the fixture and logs.

A safe write workflow can be expressed as:

```python
plan = validate_desired_state(input_data)
pre = read_current_state(scoped_identity)
assert pre.matches_required_preconditions(plan)
result = send_supported_operation(plan)
if result.has_validation_or_authorization_error:
    stop_with_evidence(result)
elif result.transport_outcome_is_ambiguous:
    actual = read_current_state(scoped_identity)
    reconcile_without_duplicate_creation(plan, actual)
else:
    wait_for_bounded_deployment_completion(result.task_id)
verify_effective_state_and_service(plan)
```
This is explanatory pseudocode, not an implemented vendor client. The local workbook provides a runnable data-validation model; actual API calls require the installed schema, authentication method and supported operation semantics.

Test four independent fixtures: HTTP 200 with a structured error; a timeout after successful creation; a timeout before any creation; and an accepted asynchronous task that later fails deployment. The correct handling differs. A single `raise_for_status()` check misses the first and fourth. A blind retry risks duplicating the second. An infinite retry loop can amplify an outage in all cases.

For APIC objects, compare distinguished names, required attributes and relationship targets. For NX-API, distinguish command execution output from a structured configuration model and validate the applicable response body. Pin the schema/version and keep raw evidence alongside normalized fields so parser mistakes can be audited.

Finally, test authority. A read-only identity must fail a write attempt in the isolated fixture or vendor lab; the deployment identity must be limited to the intended scope. Rotate any token accidentally exposed in logs. A successful operation is closed only after effective state and required positive/negative service tests pass, not when an HTTP response arrives.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

**Reasoning:** The first transaction is a failure despite HTTP 200. The second is an ambiguous transport result resolved by reading actual state:object X already exists as intended, so another creation is unnecessary. Stop secret logging and rotate any exposed token under the credential procedure. These are different failure classes and should not share one blind retry policy.

#### Guided practice

Write a decision table for success, structured validation failure, transport timeout with matching state, and transport timeout with absent state.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Success still needs deployment verification. Validation failure stops for correction. Timeout with matching state records successful reconciliation without another write. Timeout with absent state permits a bounded retry only if the operation's semantics make that safe.

#### Independent task

Environment: vendor

Implement a version-pinned API workflow with semantic validation, bounded retries and read-after-write reconciliation.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Structured errors fail the workflow.
- Ambiguous writes do not duplicate objects.
- No secret appears in logs or evidence exports.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0281 · single · implementation**

How should HTTP 200 with error 103 be classified?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

1. Complete deployment success
2. Semantic failure
3. A DNS failure

**Correct option(s):** 2

- Option 1: Incorrect. HTTP status alone is insufficient.
- Option 2: Correct. The body explicitly rejects the operation.
- Option 3: Incorrect. The server returned a structured response.

**CCIE-DC-Q0282 · single · implementation**

What resolves the timed-out creation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

1. Always repeat the POST
2. Read object X and compare desired state
3. Delete every object first

**Correct option(s):** 2

- Option 1: Incorrect. That can duplicate non-idempotent work.
- Option 2: Correct. The write may already have succeeded.
- Option 3: Incorrect. That expands impact unnecessarily.

**CCIE-DC-Q0283 · single · implementation**

What should happen to a logged bearer token?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

1. Keep it because TLS was used
2. Treat it as exposed and rotate appropriately
3. Only rename the log file

**Correct option(s):** 2

- Option 1: Incorrect. TLS does not protect stored logs.
- Option 2: Correct. Logs can disclose execution authority.
- Option 3: Incorrect. The secret remains exposed.

**CCIE-DC-Q0284 · single · implementation**

What does an APIC relationship reference?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

1. Another managed object
2. Only an HTTP status
3. Only a local Python variable

**Correct option(s):** 1

- Option 1: Correct. Reference existence and suitability matter.
- Option 2: Incorrect. That is transport metadata.
- Option 3: Incorrect. The relationship exists in controller state.

**CCIE-DC-Q0285 · single · implementation**

Which error should not receive blind retries?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

1. A transient read timeout
2. A temporary connection reset before a read
3. Authorization or validation rejection

**Correct option(s):** 3

- Option 1: Incorrect. A bounded read retry can be reasonable.
- Option 2: Incorrect. That can be retryable.
- Option 3: Correct. Repetition does not correct authority or schema.

**CCIE-DC-Q0286 · single · diagnosis**

Why record request IDs?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

1. To correlate attempts and tasks
2. To grant automatic authorization
3. To replace state verification

**Correct option(s):** 1

- Option 1: Correct. They help resolve ambiguous results.
- Option 2: Incorrect. IDs do not grant privileges.
- Option 3: Incorrect. Correlation is not deployment proof.

**CCIE-DC-Q0287 · single · implementation**

What makes idempotence relevant?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

1. Repeated application should not add unintended change
2. It means every API is read-only
3. It guarantees atomicity across devices

**Correct option(s):** 1

- Option 1: Correct. Retries depend on semantics.
- Option 2: Incorrect. Writes can be idempotent.
- Option 3: Incorrect. Those are different properties.

**CCIE-DC-Q0288 · single · implementation**

Which verification follows object creation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

1. Deployment and service-state checks
2. Only response-size comparison
3. Only a successful JSON parse

**Correct option(s):** 1

- Option 1: Correct. Accepted intent can remain undeployed.
- Option 2: Incorrect. Size is not correctness.
- Option 3: Incorrect. Parsing does not establish network behavior.

**CCIE-DC-Q0289 · single · diagnosis**

Why pin an API schema?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

1. Pinning automatically updates firmware
2. Schemas eliminate all runtime failures
3. Attributes and behavior vary by release

**Correct option(s):** 3

- Option 1: Incorrect. It changes no device version.
- Option 2: Incorrect. They do not.
- Option 3: Correct. Assumed structures can break silently.

**CCIE-DC-Q0290 · single · implementation**

What should a read-only assistant possess?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

1. No audit identity
2. Read-only scoped credentials
3. The production write token

**Correct option(s):** 2

- Option 1: Incorrect. Actions should remain attributable.
- Option 2: Correct. Analysis authority should not imply execution.
- Option 3: Incorrect. That violates the stated boundary.

**CCIE-DC-Q0291 · single · implementation**

Which timeout result justifies no additional creation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

1. GET fails authentication
2. GET matches the complete desired object
3. GET returns an unrelated object

**Correct option(s):** 2

- Option 1: Incorrect. The state remains unknown.
- Option 2: Correct. The intended state already exists.
- Option 3: Incorrect. That does not reconcile the write.

**CCIE-DC-Q0292 · single · implementation**

What should bounded retry logic include?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

1. Attempt and total-time limits with backoff
2. Only a tight infinite loop
3. Only a fixed success message

**Correct option(s):** 1

- Option 1: Correct. Unbounded retries can amplify failures.
- Option 2: Incorrect. That can overload the service.
- Option 3: Incorrect. That hides outcome.

**CCIE-DC-Q0293 · single · implementation**

Which check catches a dangling relationship?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

1. Resolve the referenced target
2. Count HTTP headers
3. Check only brace balance

**Correct option(s):** 1

- Option 1: Correct. Syntax alone cannot establish existence.
- Option 2: Incorrect. That does not inspect the model.
- Option 3: Incorrect. That validates JSON syntax only.

**CCIE-DC-Q0294 · single · diagnosis**

Why separate approval from execution?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

1. Approval makes all scripts correct
2. Execution logs replace approval
3. A proposed change is not authorization

**Correct option(s):** 3

- Option 1: Incorrect. Validation remains necessary.
- Option 2: Incorrect. They record action after the fact.
- Option 3: Correct. The writer needs explicit authority.

**CCIE-DC-Q0295 · single · implementation**

Which response requires asynchronous follow-up?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

1. An accepted task still deploying
2. A local schema rejection
3. A completed read with valid data

**Correct option(s):** 1

- Option 1: Correct. Acceptance is not final completion.
- Option 2: Incorrect. No remote task was accepted.
- Option 3: Incorrect. It may not require a task poll.

**CCIE-DC-Q0296 · single · implementation**

What should secret redaction preserve?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

1. Nothing except HTTP 200
2. The full bearer token for convenience
3. Useful identifiers without credentials

**Correct option(s):** 3

- Option 1: Incorrect. That removes needed evidence.
- Option 2: Incorrect. That exposes authority.
- Option 3: Correct. Diagnostics must remain interpretable.

**CCIE-DC-Q0297 · single · design**

Which retry design risks duplicate allocation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

1. Repeating a non-idempotent POST after ambiguous timeout
2. Using a stable supported idempotency key
3. Reading current allocation state

**Correct option(s):** 1

- Option 1: Correct. The first request may have committed.
- Option 2: Incorrect. That can reduce duplication.
- Option 3: Incorrect. That helps reconciliation.

**CCIE-DC-Q0298 · single · implementation**

What distinguishes CLI-like from model-driven APIs?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

1. One guarantees all hardware is healthy
2. Representation and operation semantics
3. One always has no authentication

**Correct option(s):** 2

- Option 1: Incorrect. Neither does.
- Option 2: Correct. Both require version-aware interpretation.
- Option 3: Incorrect. Both need access controls.

**CCIE-DC-Q0299 · single · calculation**

What is the correct result for incomplete deployment?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

1. Fail or hold at the deployment gate
2. Report success because intent exists
3. Delete all unrelated tenants

**Correct option(s):** 1

- Option 1: Correct. Do not report service success.
- Option 2: Incorrect. That hides missing effective state.
- Option 3: Incorrect. That is unjustified scope.

**CCIE-DC-Q0300 · single · diagnosis**

Which evidence supports a completed automated change?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic API exchange: POST desired EPG returns HTTP 200 with body {"error":{"code":"103","text":"unknown target"}}. Another POST times out after controller creates object X. GET object X then returns the intended attributes. Automation currently retries every POST three times and logs the bearer token.

1. Request, effective state and service validation
2. Only source code in Git
3. Only a successful login

**Correct option(s):** 1

- Option 1: Correct. It links intent to observed outcome.
- Option 2: Incorrect. Code may never have run.
- Option 3: Incorrect. Authentication precedes change.

#### Recall

**How should HTTP 200 with error 103 be classified?**

Semantic failure The body explicitly rejects the operation.

**Which error should not receive blind retries?**

Authorization or validation rejection Repetition does not correct authority or schema.

**Why pin an API schema?**

Attributes and behavior vary by release Assumed structures can break silently.

**Which check catches a dangling relationship?**

Resolve the referenced target Syntax alone cannot establish existence.

**Which retry design risks duplicate allocation?**

Repeating a non-idempotent POST after ambiguous timeout The first request may have committed.

#### References

- [APIC API configuration guides](https://www.cisco.com/c/en/us/support/cloud-systems-management/application-policy-infrastructure-controller-apic/products-installation-and-configuration-guides-list.html)
- [Cisco NX-API guides](https://www.cisco.com/c/en/us/support/switches/nexus-9000-series-switches/products-installation-and-configuration-guides-list.html)

## CCIE-DC-M16 — Declarative automation, drift and partial-commit recovery

### CCIE-DC-L16 — Declarative automation, drift and partial-commit recovery

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L15

Declarative automation compares desired state with observed state and applies a plan. The state file or inventory is a model of resources, not the resources themselves. Drift can arise from manual changes, failed prior operations or stale reads. Refresh and review the plan before execution; importing existing resources prevents accidental duplication but must preserve their actual ownership and lifecycle.

A multi-device rollout is rarely one atomic transaction. Device A may accept a change while B rejects it, leaving an inconsistent network. Define the unit of change, dependencies and safe intermediate states. A staged rollout can create objects before references, verify a canary, then expand. Deletion should reverse dependencies carefully. A rollback that simply restores old files can be insufficient if the external system has changed or if one part never committed.

Ansible-style task execution, Terraform-style planning/state and platform-specific controllers each have different strengths and failure modes. Idempotence must be demonstrated by repeated no-change execution, not inferred from tool branding. Protect state because it can contain sensitive attributes; coordinate concurrent writers with locking or an equivalent controlled mechanism.

Build validation into the workflow: schema and semantic checks before change, live preconditions immediately before execution, effective-state checks after each stage and service invariants throughout. If a precondition changes between plan and apply, stop and replan rather than forcing a stale decision.

### Implementation walkthrough: model a partial commit explicitly
Represent each target as `before`, `desired`, `observed_after`, `operation_result` and `service_result`. Do not collapse these fields into a single green/red task status. In the supplied two-leaf change, A's observed state is new while B's is old or independently changed. The state file saying both are old is now stale evidence, not authoritative reality.

Before plan generation, refresh inventory and state using scoped reads. Validate that the proposed route-target set contains exactly the approved relationships. Record a version/hash or supported precondition token where available. Immediately before apply, check that the relevant preconditions still hold. A change at 09:05 invalidates a 09:00 plan if it affects those assumptions.

Create dependencies in an order that permits safe intermediate state: containers and referenced objects first, then relationships, then traffic activation. For deletion, drain or move traffic, remove dependent references and only then remove targets. This is a graph problem; alphabetical object order is not a safe substitute.

During apply, coordinate writers and stop expansion after a failed canary or device. Collect actual A/B state. Decide between forward completion and rollback based on the required service/isolation invariant and supported recovery path. Reapplying the same source file without knowing what committed is not a recovery plan. Updating the state file to match a wish does not change the network.

Test idempotence by executing a converged plan again and verifying that no unintended device change occurs. Test drift by introducing one approved and one unauthorized difference in the isolated lab; demonstrate how the workflow preserves the approved change through review and rejects or remediates the unauthorized one. Protect state files and plan artifacts because they can contain sensitive attributes.

The independent deliverable is a failed-run record followed by a verified recovery, including exact changed targets, blocked unsafe inputs and service tests. A clean happy-path run alone does not demonstrate operation under partial failure.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

**Reasoning:** The rollout is partial and the plan was stale. Stop concurrent execution, capture actual states and evaluate whether the safe recovery is finishing the reviewed new state or restoring A. Update the model only after observing reality. Neither blindly rerunning nor deleting state repairs network consistency.

#### Guided practice

Create a dependency-aware create/update/delete order for VRF, VNI and route-target references, including a failed second-device update.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Create the required container and target objects before referencing them; validate each. For a partial update, compare effective state with the invariant and choose reviewed forward recovery or rollback. Delete dependent references before their targets after traffic is drained.

#### Independent task

Environment: vendor

Build a controlled declarative rollout that detects drift, prevents concurrent writers and recovers partial application.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Repeated converged execution causes no unintended changes.
- Partial failure cannot be reported as total success.
- The service and isolation invariants hold through recovery.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0301 · single · diagnosis**

Why is the 09:00 plan unsafe to assume current?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

1. B changed after planning
2. A successful A update proves B unchanged
3. Plans never depend on live state

**Correct option(s):** 1

- Option 1: Correct. The precondition is stale.
- Option 2: Incorrect. It does not.
- Option 3: Incorrect. They do.

**CCIE-DC-Q0302 · single · calculation**

What is the immediate rollout state?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

1. Fully rolled back
2. Partially applied
3. Fully converged

**Correct option(s):** 2

- Option 1: Incorrect. No rollback occurred.
- Option 2: Correct. A and B differ.
- Option 3: Incorrect. B rejected the update.

**CCIE-DC-Q0303 · single · implementation**

What should precede another pipeline?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

1. Force both pipelines simultaneously
2. Delete all audit history
3. Coordinate or lock writers

**Correct option(s):** 3

- Option 1: Incorrect. That increases races.
- Option 2: Incorrect. That destroys evidence.
- Option 3: Correct. Concurrent changes complicate recovery.

**CCIE-DC-Q0304 · single · implementation**

Which source establishes actual configuration?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

1. Only the old state file
2. Fresh device/controller observation
3. Only the intended Git commit

**Correct option(s):** 2

- Option 1: Incorrect. It contradicts known actions.
- Option 2: Correct. The state file is stale.
- Option 3: Incorrect. Intent is not execution.

**CCIE-DC-Q0305 · single · implementation**

What demonstrates idempotence?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

1. A script contains a loop
2. A repeat converged run makes no unintended change
3. Every run recreates all objects

**Correct option(s):** 2

- Option 1: Incorrect. Loops do not imply idempotence.
- Option 2: Correct. Tool name alone is insufficient.
- Option 3: Incorrect. That causes repeated change.

**CCIE-DC-Q0306 · single · implementation**

Which recovery choice needs current invariants?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

1. Only renaming the pipeline
2. Only compressing logs
3. Forward completion versus rollback

**Correct option(s):** 3

- Option 1: Incorrect. Names do not restore consistency.
- Option 2: Incorrect. That does not recover service.
- Option 3: Correct. The safest direction depends on actual state.

**CCIE-DC-Q0307 · single · diagnosis**

Why protect automation state?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

1. It replaces all access control
2. It never contains credentials
3. It may contain sensitive resource data

**Correct option(s):** 3

- Option 1: Incorrect. It also needs protection.
- Option 2: Incorrect. Providers can record sensitive values.
- Option 3: Correct. State is not harmless metadata.

**CCIE-DC-Q0308 · single · implementation**

Which order usually avoids dangling references?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

1. Delete targets during creation
2. Create targets before dependent references
3. Create references before every target

**Correct option(s):** 2

- Option 1: Incorrect. That is contradictory.
- Option 2: Correct. Dependencies must resolve.
- Option 3: Incorrect. That can fail or remain unresolved.

**CCIE-DC-Q0309 · single · implementation**

Which deletion order reduces reference breakage?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

1. Remove dependents before targets
2. Ignore traffic using the objects
3. Delete every target first

**Correct option(s):** 1

- Option 1: Correct. Reverse the dependency chain safely.
- Option 2: Incorrect. That can interrupt service.
- Option 3: Incorrect. Dependents then dangle.

**CCIE-DC-Q0310 · single · implementation**

What does importing existing resources require?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

1. No verification because they already exist
2. Correct identity and ownership mapping
3. Automatic deletion of their configuration

**Correct option(s):** 2

- Option 1: Incorrect. Existing state can still be wrong.
- Option 2: Correct. Import should not seize unrelated resources.
- Option 3: Incorrect. Import is not a purge.

**CCIE-DC-Q0311 · single · implementation**

What should a changed precondition trigger?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

1. Force apply with all checks disabled
2. Declare the drift irrelevant automatically
3. Stop and replan

**Correct option(s):** 3

- Option 1: Incorrect. That bypasses the guard.
- Option 2: Incorrect. It may affect the invariant.
- Option 3: Correct. A stale plan no longer matches reality.

**CCIE-DC-Q0312 · single · diagnosis**

Why use a canary?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

1. Eliminate rollback planning
2. Limit initial change exposure and test behavior
3. Prove every scale condition

**Correct option(s):** 2

- Option 1: Incorrect. Canaries can fail too.
- Option 2: Correct. It gives bounded evidence before expansion.
- Option 3: Incorrect. One canary cannot do that.

**CCIE-DC-Q0313 · single · implementation**

Which gate catches a tenant RT leak?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

1. Only JSON formatting
2. Semantic policy validation and negative tests
3. Only interface linkup

**Correct option(s):** 2

- Option 1: Incorrect. Valid JSON can encode unsafe policy.
- Option 2: Correct. Syntax alone accepts wrong membership.
- Option 3: Incorrect. It does not establish isolation.

**CCIE-DC-Q0314 · single · implementation**

What should a failed second-device update report?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

1. Exact partial state and affected invariants
2. Success if one device changed
3. Failure with no device details

**Correct option(s):** 1

- Option 1: Correct. Binary success hides the condition.
- Option 2: Incorrect. That overstates completion.
- Option 3: Incorrect. That obstructs recovery.

**CCIE-DC-Q0315 · single · diagnosis**

Why can restoring old files be insufficient?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

1. Live resources may differ from the old model
2. Old files always trigger automatic hardware reset
3. Files never control automation

**Correct option(s):** 1

- Option 1: Correct. Rollback must reconcile actual state.
- Option 2: Incorrect. That is not general behavior.
- Option 3: Incorrect. They often do.

**CCIE-DC-Q0316 · single · implementation**

Which workflow validates before execution?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

1. Schema, semantics and live preconditions
2. Only unit-test source formatting
3. Only post failure complaints

**Correct option(s):** 1

- Option 1: Correct. Each detects a different failure class.
- Option 2: Incorrect. That misses live dependencies.
- Option 3: Incorrect. That is reactive and incomplete.

**CCIE-DC-Q0317 · single · implementation**

What does a state lock not guarantee?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

1. Correctness of the planned change
2. A single coordinated writer
3. Reduced simultaneous modification

**Correct option(s):** 1

- Option 1: Correct. It prevents concurrent writers, not bad intent.
- Option 2: Incorrect. That is its purpose.
- Option 3: Incorrect. That is relevant benefit.

**CCIE-DC-Q0318 · single · diagnosis**

Why preserve failed-run evidence?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

1. It guarantees rollback without action
2. It automatically fixes B
3. It reconstructs which actions committed

**Correct option(s):** 3

- Option 1: Incorrect. Evidence supports action, not replace it.
- Option 2: Incorrect. It does not modify devices.
- Option 3: Correct. Recovery depends on exact partial state.

**CCIE-DC-Q0319 · single · implementation**

What is a valid service invariant?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

1. Approved flows persist and forbidden flows stay denied
2. The pipeline always finishes quickly
3. Every task prints OK

**Correct option(s):** 1

- Option 1: Correct. It is behavioral and testable.
- Option 2: Incorrect. Speed is not service correctness.
- Option 3: Incorrect. Task output may hide semantic failure.

**CCIE-DC-Q0320 · single · implementation**

Which result closes partial-commit recovery?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic rollout: desired tenant RT changes on Leaf A and Leaf B. Plan generated 09:00; operator changes B at 09:05. Apply 09:10 succeeds on A, rejects B. State file still records both at old RT. Another pipeline begins concurrently. Required invariant: no tenant leak and no unplanned loss of interleaf service.

1. Both effective states and service tests match reviewed intent
2. Only rerunning until exit code zero
3. Only editing state file to green

**Correct option(s):** 1

- Option 1: Correct. Model and network must agree.
- Option 2: Incorrect. Exit status may miss behavior.
- Option 3: Incorrect. That changes records not devices.

#### Recall

**Why is the 09:00 plan unsafe to assume current?**

B changed after planning The precondition is stale.

**What demonstrates idempotence?**

A repeat converged run makes no unintended change Tool name alone is insufficient.

**Which deletion order reduces reference breakage?**

Remove dependents before targets Reverse the dependency chain safely.

**Which gate catches a tenant RT leak?**

Semantic policy validation and negative tests Syntax alone accepts wrong membership.

**What does a state lock not guarantee?**

Correctness of the planned change It prevents concurrent writers, not bad intent.

#### References

- [Cisco Nexus automation guides](https://www.cisco.com/c/en/us/support/switches/nexus-9000-series-switches/products-installation-and-configuration-guides-list.html)
- [APIC automation guides](https://www.cisco.com/c/en/us/support/cloud-systems-management/application-policy-infrastructure-controller-apic/products-installation-and-configuration-guides-list.html)

## CCIE-DC-M17 — Telemetry semantics, sampling and causal incident timelines

### CCIE-DC-L17 — Telemetry semantics, sampling and causal incident timelines

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L16

A measurement is useful only when its meaning, location and time are understood. Interface counters can be cumulative or interval values; a reset or wrap can create a misleading negative delta. A sampled flow record represents a sampling process, not necessarily every packet. A dashboard average can hide a brief microburst that exhausts a queue and violates an application deadline. Match the observation timescale to the mechanism being investigated.

Streaming telemetry depends on a valid subscription, model path, encoding, transport, authentication and collector processing. A connected session does not prove the requested fields are present or fresh. Track source timestamps, collector receipt times, sequence gaps and expected update intervals. A stale last-known value should be displayed as stale, not silently treated as a healthy current measurement.

For incident reconstruction, distinguish clock synchronization from event order. Sources can have offset, drift, different precision and delayed logging. Preserve raw timestamps with clock-quality metadata, then construct a bounded timeline. Do not infer submillisecond causality from devices whose clocks disagree by seconds. Correlate control-plane events with packet loss, queue occupancy and application transactions; temporal coincidence alone is not proof of causation.

An effective alarm needs a defined condition, persistence rule, owner, service consequence and recovery criterion. Alarm storms can obscure the initiating failure. Dependency-aware suppression should preserve the primary evidence and never turn missing telemetry into a healthy state.

### Implementation walkthrough: build a defensible incident timeline
Keep a raw event table with source, raw timestamp, timezone, measured offset, uncertainty, collector receipt time and event text. Derive a normalized time interval rather than a falsely exact point when uncertainty is material. If a source leads reference by 4 seconds, subtract 4 seconds before comparing it with the host. Retain the original timestamp so later corrections remain possible.

For cumulative counters, compute a rate only when the two samples belong to the same counter epoch and the elapsed time is known. If an interface counter drops from 9000 to 10 after reboot, start a new baseline. A negative traffic rate is a parser/model error, not a physical observation. Use the platform's supported counter width and reset indicators when handling wrap.

For streaming telemetry, create a subscription acceptance table: model/path, expected type/unit, sample cadence, source timestamp, receipt timestamp, sequence/gap information and stale threshold. Deliberately request a wrong field in the local fixture or lab and confirm that a connected session without valid samples is not reported healthy. Then interrupt the collector and verify that the dashboard transitions to unknown/degraded.

To investigate a microburst, match observation resolution to the suspected queue event. A 60-second average of 20% cannot exclude a 10-millisecond full queue. Use supported high-resolution queue/drop telemetry or packet/workload evidence. If the platform cannot observe that timescale, state the limit and avoid claiming the absence of bursts.

Build alarms from service consequences: a stale EPMS value, routing adjacency loss or blocked storage path requires a different owner and response than high CPU alone. Test the whole chain from device event through parsing to notification and clearance. Dependency suppression should reduce duplicate alarms while preserving the initiating event and the fact that downstream observations may be unavailable.

The final timeline should distinguish fact, inference and unresolved ordering. A plausible narrative is not enough; each causal arrow must have a mechanism and supporting evidence.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

**Reasoning:** Correcting the switch offset places link loss at 12:00:00, before the host timeout. The 60-second average cannot exclude the 10-millisecond queue event. The connected but stale subscription is an observability fault, and the counter decrease is a reset rather than negative traffic.

#### Guided practice

Create an alarm state table for fresh healthy data, fresh bad data, stale data and collector failure.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Fresh healthy data can support normal state; fresh bad data supports the measured fault; stale or missing data must produce an unknown/degraded observability state with its own response. Do not carry forward the last healthy value indefinitely.

#### Independent task

Environment: vendor

Build an evidence timeline and telemetry acceptance test that handles freshness, counter resets, sampling and clock uncertainty.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- All measurements retain units, source and time semantics.
- Stale data cannot appear as current health.
- Causal claims respect clock uncertainty and capture location.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0321 · single · implementation**

Which event occurred first after clock correction?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

1. Host timeout at 12:00:02
2. Link loss at 12:00:00
3. They are necessarily simultaneous

**Correct option(s):** 2

- Option 1: Incorrect. It follows the corrected link event.
- Option 2: Correct. Subtract the switch's 4-second offset.
- Option 3: Incorrect. The corrected times differ.

**CCIE-DC-Q0322 · single · implementation**

What does 20% average queue use not exclude?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

1. Any packet forwarding
2. A short full-queue burst
3. A permanently empty queue

**Correct option(s):** 2

- Option 1: Incorrect. Average occupancy implies no such prohibition.
- Option 2: Correct. A 60-second average smooths 10 ms events.
- Option 3: Incorrect. The average is nonzero.

**CCIE-DC-Q0323 · single · implementation**

How should the 15-minute-old sample be classified?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

1. Current healthy measurement
2. A confirmed link failure
3. Stale observability

**Correct option(s):** 3

- Option 1: Incorrect. The source timestamp contradicts that.
- Option 2: Incorrect. Staleness alone does not identify the underlying device fault.
- Option 3: Correct. A connected transport does not ensure freshness.

**CCIE-DC-Q0324 · single · implementation**

What explains counter 9000 becoming 10 after reboot?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

1. Negative transmitted traffic
2. Counter reset
3. Guaranteed packet duplication

**Correct option(s):** 2

- Option 1: Incorrect. Traffic cannot reverse cumulative count that way.
- Option 2: Correct. A new counter epoch began.
- Option 3: Incorrect. No duplication evidence is supplied.

**CCIE-DC-Q0325 · single · implementation**

Which metadata is essential for event ordering?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

1. Only switch model
2. Clock offset and uncertainty
3. Only log filename

**Correct option(s):** 2

- Option 1: Incorrect. Models do not quantify current offset.
- Option 2: Correct. Raw timestamps alone can mislead.
- Option 3: Incorrect. It does not establish time quality.

**CCIE-DC-Q0326 · single · implementation**

What does a connected telemetry session prove?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

1. Every requested metric is valid
2. Transport/session availability
3. Application deadlines are satisfied

**Correct option(s):** 2

- Option 1: Incorrect. Subscriptions can be wrong or stale.
- Option 2: Correct. Field freshness still requires checks.
- Option 3: Incorrect. Telemetry connection does not test service.

**CCIE-DC-Q0327 · single · implementation**

Which metric can expose microbursts?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

1. Only daily average bandwidth
2. Appropriate short-timescale queue/drop evidence
3. Only annual availability

**Correct option(s):** 2

- Option 1: Incorrect. It smooths the event further.
- Option 2: Correct. Long averages hide bursts.
- Option 3: Incorrect. It is too coarse.

**CCIE-DC-Q0328 · single · diagnosis**

Why preserve source and collector timestamps?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

1. To force them to be identical
2. To eliminate clock validation
3. To distinguish event time from delivery delay

**Correct option(s):** 3

- Option 1: Incorrect. They represent different stages.
- Option 2: Incorrect. Offsets still matter.
- Option 3: Correct. Collection latency can reorder observations.

**CCIE-DC-Q0329 · single · implementation**

What should an alarm on missing data indicate?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

1. Healthy because no fault was received
2. Unknown or degraded observation
3. A specific broken optic automatically

**Correct option(s):** 2

- Option 1: Incorrect. That confuses silence with success.
- Option 2: Correct. Absence is not healthy evidence.
- Option 3: Incorrect. The cause is not established.

**CCIE-DC-Q0330 · single · implementation**

Which counter calculation needs reset awareness?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

1. Current minus previous value
2. A static configured MTU
3. A policy object name

**Correct option(s):** 1

- Option 1: Correct. A reset invalidates naive deltas.
- Option 2: Incorrect. It is not a cumulative counter.
- Option 3: Incorrect. It is not a counter.

**CCIE-DC-Q0331 · single · implementation**

What does sampled flow telemetry omit?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

1. Some individual packets by design
2. Every large flow necessarily
3. All timing information

**Correct option(s):** 1

- Option 1: Correct. Sampling is not full capture.
- Option 2: Incorrect. Sampling behavior depends on method.
- Option 3: Incorrect. Records can contain timing.

**CCIE-DC-Q0332 · single · diagnosis**

Why correlate application evidence?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

1. Network counters do not define service success alone
2. Applications cannot detect network faults
3. Application logs replace all network evidence

**Correct option(s):** 1

- Option 1: Correct. The intended function must be observed.
- Option 2: Incorrect. They experience effects.
- Option 3: Incorrect. Both layers help causal analysis.

**CCIE-DC-Q0333 · single · implementation**

What must an alarm definition include?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

1. Threshold, persistence, consequence and owner
2. Only the raw threshold number
3. Only the vendor logo

**Correct option(s):** 1

- Option 1: Correct. A number alone lacks response meaning.
- Option 2: Incorrect. Persistence, service consequence, ownership and recovery remain undefined.
- Option 3: Incorrect. It does not define the condition.

**CCIE-DC-Q0334 · single · calculation**

What is the risk of dependency suppression?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

1. Hiding primary evidence if done badly
2. Always increasing sensor accuracy
3. Automatically repairing the dependency

**Correct option(s):** 1

- Option 1: Correct. Suppression must retain the initiating fault.
- Option 2: Incorrect. It changes alarm handling, not measurement.
- Option 3: Incorrect. Suppression does not repair systems.

**CCIE-DC-Q0335 · single · implementation**

Which claim exceeds the timestamp fidelity?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

1. A bounded sequence after offset correction
2. Submillisecond ordering with seconds of clock uncertainty
3. Acknowledging unknown ordering

**Correct option(s):** 2

- Option 1: Incorrect. That can be defensible.
- Option 2: Correct. Precision cannot exceed source quality.
- Option 3: Incorrect. That respects uncertainty.

**CCIE-DC-Q0336 · single · implementation**

What should a subscription acceptance test verify?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

1. Only TCP establishment
2. Correct fields, rates, freshness and gaps
3. Only collector CPU

**Correct option(s):** 2

- Option 1: Incorrect. That isone dependency.
- Option 2: Correct. Connection alone is insufficient.
- Option 3: Incorrect. It does not prove semantic delivery.

**CCIE-DC-Q0337 · single · diagnosis**

Why retain raw timestamps?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

1. They are always perfectly accurate
2. They allow later reconstruction and correction
3. They replace timezone information

**Correct option(s):** 2

- Option 1: Incorrect. They can be offset.
- Option 2: Correct. Normalization should not destroy originals.
- Option 3: Incorrect. Context remains necessary.

**CCIE-DC-Q0338 · single · implementation**

Which observation distinguishes collector delay?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

1. Only the collector receipt timestamp
2. Fresh source times arriving late
3. Only a link description

**Correct option(s):** 2

- Option 1: Incorrect. Without source time, receipt time cannot distinguish late delivery from a late event.
- Option 2: Correct. Event time and arrival time diverge.
- Option 3: Incorrect. It provides no delivery timing.

**CCIE-DC-Q0339 · single · implementation**

What should follow a counter epoch change?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

1. Delete all historical data
2. Report a huge negative rate
3. Reset the delta baseline

**Correct option(s):** 3

- Option 1: Incorrect. Earlier evidence remains useful.
- Option 2: Incorrect. That is not physical traffic.
- Option 3: Correct. Do not compare across incompatible epochs.

**CCIE-DC-Q0340 · single · implementation**

What closes a telemetry repair?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic timeline: switch clock is +4 s; host clock is accurate. Switch logs link down 12:00:04. Host logs I/O timeout 12:00:02. Queue average over 60 s is 20%; a 10 ms burst fills the queue. Telemetry session connected, but last source sample is 15 minutes old. Interface counter resets from 9000 to 10 after reboot.

1. Only clearing the alarm manually
2. Only reconnecting TCP
3. Fresh expected metrics and validated alarm behavior

**Correct option(s):** 3

- Option 1: Incorrect. That does not restore measurement.
- Option 2: Incorrect. Semantic failure can remain.
- Option 3: Correct. Transport recovery alone is partial.

#### Recall

**Which event occurred first after clock correction?**

Link loss at 12:00:00 Subtract the switch's 4-second offset.

**Which metadata is essential for event ordering?**

Clock offset and uncertainty Raw timestamps alone can mislead.

**What should an alarm on missing data indicate?**

Unknown or degraded observation Absence is not healthy evidence.

**What must an alarm definition include?**

Threshold, persistence, consequence and owner A number alone lacks response meaning.

**Why retain raw timestamps?**

They allow later reconstruction and correction Normalization should not destroy originals.

#### References

- [Cisco Nexus telemetry guides](https://www.cisco.com/c/en/us/support/switches/nexus-9000-series-switches/products-installation-and-configuration-guides-list.html)

## CCIE-DC-M18 — Management-plane security, AAA failure and emergency authority

### CCIE-DC-L18 — Management-plane security, AAA failure and emergency authority

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L17

Management access combines reachability, authenticated identity, authorization and accounting. Central AAA can separate login from command authorization; successful authentication does not imply permission to change configuration. An external service failure can also produce a different result from an explicit rejection. Understand the platform's method-list behavior rather than assuming local fallback always occurs.

Design a dedicated management boundary with restricted sources, secure protocols, validated certificates and appropriate control-plane protection. Out-of-band access is useful only when it avoids the same failed power, network and identity dependencies as the in-band path. Keep emergency credentials individually controlled, tested and audited; they are a recovery mechanism, not a shared daily account.

Role design should map exact operating responsibilities to actions. A monitoring integration needs reads, a configuration pipeline needs a scoped write role and an operator may need bounded recovery commands. Test both allowed and denied actions. Logging a successful login is not enough to reconstruct a change; retain actor, command/API operation, target, time and result without storing secrets.

Control-plane policing protects finite CPU resources but can also starve routing, management or telemetry if classification or rates are wrong. Diagnose with class counters and service effects before increasing all limits. Security maintenance must preserve recovery authority: a certificate rollover, AAA policy change or ACL update should be tested through an independent session before the last working access path is closed.

### Implementation walkthrough: preserve management authority through a security change
Build an access matrix with actor, source network, protocol, authentication method, authorized commands/API scope, accounting destination and emergency path. Separate monitoring, automation, ordinary administration and break-glass roles. Test a read-only role with both a permitted read and a denied write; a successful login alone does not validate least privilege.

In the isolated NX-OS lab, test AAA server acceptance, explicit rejection and unavailability as three separate cases. Record the configured method-list semantics and observed result. Local fallback on timeout must not be generalized to fallback after an explicit reject. Use the matching release guide; do not discover these semantics while closing the last working production session.

Stage a management ACL change while retaining a known-good session and independent console. Test a new connection from each approved source, a denied connection from an unapproved source and the emergency source. The supplied 10.1.0.10 console server is outside 10.0.0.0/24, so its network path requires an explicit reviewed allowance or truly independent console transport. Do not describe it as out-of-band merely because it has a different name.

For CoPP, capture class matches, offered/dropped traffic and the affected protocol's state before tuning. A routing class accumulating drops can explain adjacency instability without physical loss. Correct the classification/rate according to supported guidance and measured demand; disabling all protection discards a requirement and can expose the control plane to overload.

For certificate or AAA rollover, validate trust and roles through an independent new session before retiring old credentials. Preserve attributable accounting without logging passwords or bearer tokens. If a token has been exposed, rotate/revoke it and update dependents through the controlled recovery path.

Close the change only when authorized access, denied access, logging and emergency recovery all pass. A locked-down device that cannot be recovered after its shared identity service fails is not an acceptable lifecycle design.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

**Reasoning:** Explicit rejection and server unavailability are different AAA outcomes; consult configured method semantics before expecting local fallback. The emergency server is blocked bythe stated ACL if it uses that path. Preserve the open session while testing the corrected policy independently. CoPP drops may explain routing instability without physical failure.

#### Guided practice

Plan an AAA/ACL change that cannot strand the operator if the new policy is wrong.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Confirm independent console access, capture current policy, stage a bounded change, keep one working session, test new login and allowed/denied commands from approved sources, then close the old session only after acceptance. Rollback promptly on failure.

#### Independent task

Environment: vendor

Commission platform administration with scoped roles, accountable changes and tested AAA/management failure recovery.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Allowed and denied actions match roles.
- AAA rejection and outage behavior are both tested.
- Emergency access survives the defined dependency failure.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0341 · single · diagnosis**

Why might local Ops not be used after explicit reject?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

1. The local account must be deleted
2. AAA reachability proves authorization
3. Rejection may terminate the method chain

**Correct option(s):** 3

- Option 1: Incorrect. Its existence is not the issue.
- Option 2: Incorrect. The server explicitly denied it.
- Option 3: Correct. Fallback semantics distinguish denial from unavailability.

**CCIE-DC-Q0342 · single · implementation**

Which case is different from explicit reject?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

1. AAA timeout
2. Another explicit reject
3. A successful command authorization

**Correct option(s):** 1

- Option 1: Correct. No authorization decision was received.
- Option 2: Incorrect. That is the same category.
- Option 3: Incorrect. That is approval, not failure.

**CCIE-DC-Q0343 · single · implementation**

What blocks the emergency server on the stated path?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

1. The local account password is expired
2. The source ACL excludes10.1.0.10
3. It uses a console application

**Correct option(s):** 2

- Option 1: Incorrect. The stated ACL blocks the source address before this credential hypothesis is established.
- Option 2: Correct. Only 10.0.0.0/24 is allowed.
- Option 3: Incorrect. The stated network rule still applies.

**CCIE-DC-Q0344 · single · diagnosis**

Why keep the existing SSH session?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

1. It proves new logins will succeed
2. It automatically bypasses every ACL forever
3. It may provide rollback authority

**Correct option(s):** 3

- Option 1: Incorrect. Established sessions do not test new authentication.
- Option 2: Incorrect. Behavior depends on state and policy.
- Option 3: Correct. New access could fail.

**CCIE-DC-Q0345 · single · implementation**

What separates authentication from authorization?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

1. Authorization only records logs
2. Identity proof versus permitted actions
3. They are always one operation

**Correct option(s):** 2

- Option 1: Incorrect. That is accounting.
- Option 2: Correct. A valid user may lack write authority.
- Option 3: Incorrect. Systems can separate them.

**CCIE-DC-Q0346 · single · implementation**

Which test verifies a monitoring role?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

1. Read succeeds and write fails
2. Only the password meets length policy
3. Only login succeeds

**Correct option(s):** 1

- Option 1: Correct. Both positive and negative authorization matter.
- Option 2: Incorrect. That does not establish privilege.
- Option 3: Incorrect. That does not establish action scope.

**CCIE-DC-Q0347 · single · diagnosis**

What can Co PP drops cause?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

1. Control-service starvation
2. Automatic VLAN renumbering
3. Direct disk corruption necessarily

**Correct option(s):** 1

- Option 1: Correct. Finite CPU traffic maybe dropped.
- Option 2: Incorrect. Policing does not renumber VLANs.
- Option 3: Incorrect. No such causal evidence exists.

**CCIE-DC-Q0348 · single · diagnosis**

Which evidence justifies Co PP tuning?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

1. Class-specific drops and service impact
2. Only aggregate interface speed
3. Only a login banner

**Correct option(s):** 1

- Option 1: Correct. Broad increases lack causal precision.
- Option 2: Incorrect. That does not identify CPU class load.
- Option 3: Incorrect. It says nothing about policing.

**CCIE-DC-Q0349 · single · diagnosis**

Why is out-of-band not automatically independent?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

1. It may share power or identity dependencies
2. It always uses the data plane identically
3. It never requires credentials

**Correct option(s):** 1

- Option 1: Correct. A separate interface is not full independence.
- Option 2: Incorrect. Topology can separate it.
- Option 3: Incorrect. Access still needs authority.

**CCIE-DC-Q0350 · single · implementation**

What should emergency credentials avoid?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

1. Periodic tested access
2. Routine shared daily use
3. Controlled storage and rotation

**Correct option(s):** 2

- Option 1: Incorrect. Testing is necessary.
- Option 2: Correct. That weakens traceability and recovery control.
- Option 3: Incorrect. Those support recovery.

**CCIE-DC-Q0351 · single · implementation**

Which audit record reconstructs change authority?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

1. The full password
2. Actor, operation, target, time and result
3. Only login success

**Correct option(s):** 2

- Option 1: Incorrect. Secrets should not be logged.
- Option 2: Correct. Login alone is incomplete.
- Option 3: Incorrect. It omits actions.

**CCIE-DC-Q0352 · single · implementation**

What should precede closing the last old session?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

1. Only saving the configuration
2. Independent new access and role tests
3. Only receiving no complaints

**Correct option(s):** 2

- Option 1: Incorrect. Saved policy can still lock out access.
- Option 2: Correct. Preserve rollback until replacement works.
- Option 3: Incorrect. That is not verification.

**CCIE-DC-Q0353 · single · diagnosis**

Why validate TLS certificates on management APIs?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

1. To authenticate the server and protect trust
2. To prove firmware compatibility
3. To authorize every API action

**Correct option(s):** 1

- Option 1: Correct. Encryption alone with unverified identity is insufficient.
- Option 2: Incorrect. PKI does not test compatibility.
- Option 3: Incorrect. Authorization is separate.

**CCIE-DC-Q0354 · single · implementation**

Which condition requires a role adjustment?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

1. An unauthorized source is blocked
2. A pipeline can modify unrelated tenants
3. A read-only user cannot write

**Correct option(s):** 2

- Option 1: Incorrect. That is expected policy.
- Option 2: Correct. Its authority exceeds its assignment.
- Option 3: Incorrect. That is expected.

**CCIE-DC-Q0355 · single · implementation**

What should an AAA outage drill measure?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

1. Only the number of accounts
2. Only server uptime before the drill
3. Access behavior, recovery and accountability

**Correct option(s):** 3

- Option 1: Incorrect. Counts do not show behavior.
- Option 2: Incorrect. It does not test outage response.
- Option 3: Correct. Availability must not erase control.

**CCIE-DC-Q0356 · single · implementation**

Which first response to protocol starvation is justified?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

1. Reboot every neighbor
2. Disable all control-plane protection
3. Inspect class match and drop counters

**Correct option(s):** 3

- Option 1: Incorrect. That expands impact before diagnosis.
- Option 2: Incorrect. That creates broader exposure.
- Option 3: Correct. Locate the policing cause.

**CCIE-DC-Q0357 · single · diagnosis**

Why test certificate rollover before expiry?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

1. Expiry only changes a GUI warning
2. Trust distribution and client behavior can fail
3. Certificates never affect automation

**Correct option(s):** 2

- Option 1: Incorrect. Clients can reject sessions.
- Option 2: Correct. A new certificate is not automatically trusted.
- Option 3: Incorrect. They often authenticate APIs.

**CCIE-DC-Q0358 · single · implementation**

What must break-glass use record?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

1. Only the successful password
2. Who invoked it, why and what changed
3. Nothing during incidents

**Correct option(s):** 2

- Option 1: Incorrect. Do not store credentials.
- Option 2: Correct. Emergency authority still needs accountability.
- Option 3: Incorrect. That loses critical evidence.

**CCIE-DC-Q0359 · single · implementation**

Which boundary does source ACL enforce?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

1. Application database integrity
2. Management reachability from approved sources
3. Every user's full role

**Correct option(s):** 2

- Option 1: Incorrect. That is another system.
- Option 2: Correct. It does not by itself define command privileges.
- Option 3: Incorrect. AAA/RBAC governs that.

**CCIE-DC-Q0360 · single · implementation**

What closes a management-security change?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic NX-OS 10.x: AAA server reachable and returns explicit reject for user Ops. Local Ops account exists. A separate outage makes AAA time out. Management ACL allows only 10.0.0.0/24; emergency console server is 10.1.0.10. CoPP class for routing accumulates drops after a new policy. Existing SSH session remains open.

1. Only fewer open ports
2. Only successful authentication
3. Reachability, roles, logging and recovery tests

**Correct option(s):** 3

- Option 1: Incorrect. Access may now be unrecoverable.
- Option 2: Incorrect. Authorization and recovery remain unproven.
- Option 3: Correct. All four constraints matter.

#### Recall

**Why might local Ops not be used after explicit reject?**

Rejection may terminate the method chain Fallback semantics distinguish denial from unavailability.

**What separates authentication from authorization?**

Identity proof versus permitted actions A valid user may lack write authority.

**Why is out-of-band not automatically independent?**

It may share power or identity dependencies A separate interface is not full independence.

**Why validate TLS certificates on management APIs?**

To authenticate the server and protect trust Encryption alone with unverified identity is insufficient.

**Why test certificate rollover before expiry?**

Trust distribution and client behavior can fail A new certificate is not automatically trusted.

#### References

- [Cisco Nexus security guides](https://www.cisco.com/c/en/us/support/switches/nexus-9000-series-switches/products-installation-and-configuration-guides-list.html)
- [TACACS+ protocol](https://www.rfc-editor.org/rfc/rfc8907.html)

## CCIE-DC-M19 — QoS, buffering and congestion under AI and storage loads

### CCIE-DC-L19 — QoS, buffering and congestion under AI and storage loads

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L18

Capacity engineering must distinguish average rate, burst rate, queue service and application completion time. If arrivals exceed departures, backlog grows; a finite buffer only absorbs a bounded interval. A 100-Gbit/s ingress feeding a 25-Gbit/s egress accumulates 75 Gbit/s while that condition lasts. A 10 MB available queue fills in roughly 1.07 ms under this simplified model. This is why low long-term utilization cannot exclude drops.

Classification determines which traffic enters each queue. Trusting endpoint markings without boundary policy allows an endpoint to claim a privileged class. Scheduling then determines how queues share service; strict priority can protect a critical class but starve lower classes if unbounded. Weighted scheduling needs an explicit allocation and congestion test. Policing drops or remarks excess traffic at a boundary, while shaping delays it within finite buffering; neither creates capacity.

RoCE performance adds specific congestion behavior. ECN marks congestion, endpoints react through the supported congestion-control mechanism, and PFC can pause selected priorities to avoid loss under defined conditions. Excessive reliance on pause can spread congestion or create deadlock dependencies. Verify the exact NIC, switch, firmware and workload combination rather than copying a generic 'lossless' configuration.

Use workload-relevant metrics: completion time, tail latency, retransmissions, congestion notifications, pause duration and queue occupancy. An aggregate throughput gain can conceal a failed control-system deadline. Reserve and test the required control traffic while stressing storage or AI flows, including degraded capacity after maintenance.

### Implementation walkthrough: calculate and then measure queue behavior
Begin with a conservation model: queue growth equals arrival minus service while arrivals exceed service. Convert bytes and bits explicitly. The supplied 10 MB free buffer contains 80 Mbit; at 75 Gbit/s excess, ideal fill time is about 1.07 ms. This calculation identifies a plausible timescale. It does not establish the actual hardware's shared-buffer allocation, cell accounting, thresholds or dynamic behavior.

Create a classification table for control traffic, storage/RDMA, ordinary application traffic and management. Record marking at the host, trust/remark behavior at ingress, internal class, queue and scheduler treatment. Inspect actual packets and counters. A configured policy name such as `lossless` is not proof that the intended traffic enters the intended priority.

In a supported lab, run each class alone to establish a baseline, then run them concurrently. Measure control transaction tail latency, AI/storage completion, queue occupancy, drops, ECN and pause duration. Add a sender that falsely marks ordinary traffic as privileged and verify the boundary policy. An accepted high-priority mark must be an authorized treatment, not a user-controlled way to steal service.

Now remove an uplink or otherwise reduce capacity through an approved isolated procedure. Recompute the feasible demand and rerun the workload. If the requirement exceeds surviving service capacity, no finite buffer or clever scheduler can satisfy unlimited sustained demand; add capacity, constrain admission or obtain an explicit requirement change.

For RoCE, verify the supported endpoint reaction to congestion as well as switch marking. Observe whether one slow receiver causes broader pause coupling. Do not tune ECN/PFC thresholds by copying values from an unrelated NIC/switch generation. Preserve the platform, firmware, cable, MTU and workload context in every result.

Acceptance is simultaneous: critical control deadlines, required useful throughput, isolation and recoverability. A throughput record that sacrifices the control system's deadline is a failed design, not an optimization.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

**Reasoning:** Backlog grows at 75 Gbit/s.10MB is 80 Mbit, so ideal fill time is 80 e 6/75 e 9≈1.07ms. An unbounded priority queue can consume all service and starve controls. Correct classification and bounded scheduling are separate from adding buffer capacity.

#### Guided practice

Design a test that preserves a 10 ms control deadline while a RoCE workload saturates the degraded uplink.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Generate representative control transactions and RoCE load on the actual supported lab path. Measure control tail latency and loss, queue/pause/ECN behavior and workload completion. Test permitted marking and spoofed marking, then remove one uplink. Accept only if both classes meet their stated limits.

#### Independent task

Environment: vendor

Engineer and validate QoS under burst, congestion and degraded-capacity conditions without sacrificing control-system deadlines.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Queue calculations show units and assumptions.
- Marking trust is constrained.
- Application deadlines pass under degraded load.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0361 · single · calculation**

What is the backlog growth rate?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

1. 125 Gbit/s
2. 75 Gbit/s
3. 25 Gbit/s

**Correct option(s):** 2

- Option 1: Incorrect. Adding rates misstates backlog.
- Option 2: Correct. Arrival 100 minus service 25.
- Option 3: Incorrect. That is service, not excess arrival.

**CCIE-DC-Q0362 · single · calculation**

What is the approximate buffer fill time?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

1. 1.07ms
2. 400 ms
3. 10 seconds

**Correct option(s):** 1

- Option 1: Correct. 80 Mbit divided by 75 Gbit/s.
- Option 2: Incorrect. That does not follow the supplied rates.
- Option 3: Incorrect. Buffer size is far smaller at these rates.

**CCIE-DC-Q0363 · single · diagnosis**

Why can low daily utilization coexist with drops?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

1. Daily averages prove no burst occurred
2. Short bursts exceed queue service
3. Drops require a failed physical link

**Correct option(s):** 2

- Option 1: Incorrect. They do not.
- Option 2: Correct. Averages hide the relevant timescale.
- Option 3: Incorrect. Congestion can drop packets on healthy links.

**CCIE-DC-Q0364 · single · implementation**

What threatens the control queue?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

1. Unbounded strict-priority demand
2. A lower average RoCE rate alone
3. A valid VLAN tag

**Correct option(s):** 1

- Option 1: Correct. Priority P can consume all service.
- Option 2: Incorrect. Burst and scheduling behavior still matter.
- Option 3: Incorrect. Tags do not inherently starve queues.

**CCIE-DC-Q0365 · single · implementation**

Which control limits false priority claims?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

1. Trust every marked packet
2. Boundary classification and remarking
3. Increase only the link description

**Correct option(s):** 2

- Option 1: Incorrect. That enables privilege inflation.
- Option 2: Correct. Do not trust arbitrary endpoint markings.
- Option 3: Incorrect. It changes no treatment.

**CCIE-DC-Q0366 · single · implementation**

How does shaping differ from policing?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

1. Shaping delays within finite buffers
2. Policing guarantees no loss
3. Shaping creates extra bandwidth

**Correct option(s):** 1

- Option 1: Correct. Policing can drop or remark excess.
- Option 2: Incorrect. Dropping may be its mechanism.
- Option 3: Incorrect. It cannot.

**CCIE-DC-Q0367 · single · implementation**

What does ECN communicate?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

1. The application committed its data
2. Congestion without requiring that packet's drop
3. The path has infinite buffers

**Correct option(s):** 2

- Option 1: Incorrect. That is unrelated.
- Option 2: Correct. Endpoints must react appropriately.
- Option 3: Incorrect. ECN exists because resources are finite.

**CCIE-DC-Q0368 · single · diagnosis**

Why is PFC not a universal solution?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

1. Pause can propagate and couple queues
2. It removes congestion sources
3. It automatically fixes all application timeouts

**Correct option(s):** 1

- Option 1: Correct. Loss avoidance adds dependencies.
- Option 2: Incorrect. It only controls transmission.
- Option 3: Incorrect. It does not.

**CCIE-DC-Q0369 · single · design**

Which metric protects the control requirement?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

1. Tail transaction latency under stress
2. Only mean CPU use
3. Only aggregate fabric throughput

**Correct option(s):** 1

- Option 1: Correct. Average throughput misses deadlines.
- Option 2: Incorrect. It does not measure the transaction.
- Option 3: Incorrect. It can rise while controls fail.

**CCIE-DC-Q0370 · single · implementation**

What should a degraded test remove?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

1. A real capacity or failure-domain component
2. Only a dashboard widget
3. Only a documentation link

**Correct option(s):** 1

- Option 1: Correct. Normal-state testing misses concentration.
- Option 2: Incorrect. That changes no forwarding capacity.
- Option 3: Incorrect. It creates no operational fault.

**CCIE-DC-Q0371 · single · diagnosis**

Why include workload completion time?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

1. It replaces every network counter
2. Network counters do not fully describe useful work
3. It is always proportional to line rate

**Correct option(s):** 2

- Option 1: Incorrect. Both are needed.
- Option 2: Correct. Collective or storage completion matters.
- Option 3: Incorrect. Dependencies can break that assumption.

**CCIE-DC-Q0372 · single · implementation**

Which claim is unsupported by this model?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

1. Actual switch buffer behavior is proven
2. Finite buffers cannot absorb unlimited excess
3. The modeled queue can fill rapidly

**Correct option(s):** 1

- Option 1: Correct. The calculation is explicitly simplified.
- Option 2: Incorrect. That follows conservation.
- Option 3: Incorrect. The arithmetic supports that.

**CCIE-DC-Q0373 · single · implementation**

What can strict priority require to protect others?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

1. Removing all classification
2. A bounded offered load or enforced limit
3. Unlimited admission

**Correct option(s):** 2

- Option 1: Incorrect. That eliminates the intended control.
- Option 2: Correct. Otherwise lower classes can starve.
- Option 3: Incorrect. That worsens starvation.

**CCIE-DC-Q0374 · single · implementation**

What must RoCE validation pin?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

1. NIC, switch, firmware and congestion behavior
2. Only the application name
3. Only the switch QoS configuration

**Correct option(s):** 1

- Option 1: Correct. Interoperability affects results.
- Option 2: Incorrect. Names do not define transport behavior.
- Option 3: Incorrect. NIC behavior and firmware/workload compatibility also determine congestion response.

**CCIE-DC-Q0375 · single · diagnosis**

Why test spoofed markings?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

1. To prove every host is malicious
2. To replace ordinary load tests
3. To verify the trust boundary

**Correct option(s):** 3

- Option 1: Incorrect. The test checks a control, not intent.
- Option 2: Incorrect. Both are needed.
- Option 3: Correct. Allowed traffic tests do not reveal abuse.

**CCIE-DC-Q0376 · single · implementation**

Which observation suggests pause coupling?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

1. Only a successful DNS query
2. Only a changed route description
3. Unrelated protected flows stall with one receiver

**Correct option(s):** 3

- Option 1: Incorrect. It does not establish pause behavior.
- Option 2: Incorrect. That is not traffic evidence.
- Option 3: Correct. Shared backpressure may propagate.

**CCIE-DC-Q0377 · single · implementation**

What does a weighted scheduler require for validation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

1. Only a saved policy
2. Measured service under simultaneous contention
3. Only one active queue

**Correct option(s):** 2

- Option 1: Incorrect. It does not prove hardware scheduling.
- Option 2: Correct. Configured weights alone are intent.
- Option 3: Incorrect. That cannot show sharing.

**CCIE-DC-Q0378 · single · design**

Which action cannot meet an infeasible capacity requirement?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

1. Reducing admitted load
2. Adding finite buffers indefinitely
3. Increasing usable service capacity

**Correct option(s):** 2

- Option 1: Incorrect. That can restore feasibility.
- Option 2: Correct. Sustained excess still exceeds service.
- Option 3: Incorrect. That can address the constraint.

**CCIE-DC-Q0379 · single · diagnosis**

Why retain control traffic during stress?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

1. To make all measurements invalid
2. To test simultaneous requirements
3. To guarantee all tests pass

**Correct option(s):** 2

- Option 1: Incorrect. Representative coexistence is intentional.
- Option 2: Correct. Isolated benchmarks miss interactions.
- Option 3: Incorrect. The result must be measured.

**CCIE-DC-Q0380 · single · implementation**

Which acceptance result is complete?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic queue model: 100 Gbit/s arrival, 25 Gbit/s service, 10 MB free buffer. Strict-priority queue P can send at the entire 25 Gbit/s rate. Control traffic shares a lower queue. RoCE uses priority 3, but a boundary trusts arbitrary endpoint markings. No measured hardware result is claimed.

1. Required application limits plus queue and loss evidence
2. Only peak throughput
3. Only zero average queue occupancy

**Correct option(s):** 1

- Option 1: Correct. It connects mechanism with service.
- Option 2: Incorrect. That ignores latency and protection.
- Option 3: Incorrect. Sampling may miss bursts.

#### Recall

**What is the backlog growth rate?**

75 Gbit/s Arrival 100 minus service 25.

**Which control limits false priority claims?**

Boundary classification and remarking Do not trust arbitrary endpoint markings.

**Which metric protects the control requirement?**

Tail transaction latency under stress Average throughput misses deadlines.

**What can strict priority require to protect others?**

A bounded offered load or enforced limit Otherwise lower classes can starve.

**What does a weighted scheduler require for validation?**

Measured service under simultaneous contention Configured weights alone are intent.

#### References

- [Cisco Nexus QoS guides](https://www.cisco.com/c/en/us/support/switches/nexus-9000-series-switches/products-installation-and-configuration-guides-list.html)

## CCIE-DC-M20 — DCI and external routing: leak prevention and failure-domain design

### CCIE-DC-L20 — DCI and external routing: leak prevention and failure-domain design

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L19

A data-center border connects different authority and failure domains. Route policy must state which prefixes may enter, which may leave, which next hops are valid and what happens when a peer exceeds expected behavior. Default-deny import/export intent is easier to audit than implicit acceptance. Prefix filters, path policy, maximum-prefix controls and route-origin validation address different risks; none replaces the others.

RPKI origin validation compares an announcement's origin with authorized origin information. It does not validate the entire AS path or prove the service behind the prefix is benign. A route can be origin-valid yet violate commercial or topology policy. Likewise, a route leak can preserve the legitimate origin while propagating through an unintended relationship. Evaluate path and relationship policy independently.

DCI choice should follow application requirements for addressing, latency, failure scope and recovery. Stretching Layer 2 extends broadcast and endpoint dependencies; routed boundaries can constrain them but may require application or addressing changes. A redundant border pair sharing one carrier duct, one control system or one upstream policy is not fully independent.

Commission ingress and egress filters with an isolated route generator, never by advertising test routes to the public Internet. Verify accepted and rejected prefixes, maximum-prefix behavior, default route withdrawal, asymmetric paths and application continuity. Preserve console access and a reviewed rollback, because routing changes can remove the operator's own management path.

### Implementation walkthrough: prove routing policy with positive and negative advertisements
Build an isolated three-relationship lab: customer, peer and transit. For each neighbor, specify allowed import prefixes, allowed export prefixes, next-hop handling, communities, origin-validation policy and maximum-prefix behavior. Use private documentation/test ranges only inside the isolated environment; no public experimental advertisement is authorized by this workbook.

Create a route-policy test table:

| Input | Expected import | Expected onward export |
|---|---|---|
| Contracted customer prefix | Accept | Only approved relationships |
| Customer default without permission | Reject | None |
| Peer-learned prefix toward another peer | Policy-dependent, normally no unintended transit | Reject unless explicitly authorized |
| Origin-invalid route | Follow documented reject/exception policy | Never silently ignore validation |
| Origin-valid but unauthorized relationship | Reject under relationship policy | None |

Origin validity and path/relationship validity occupy separate columns. A valid origin can survive a leak, so the validation result cannot replace explicit export control.

Collect received, accepted, best and installed routes using the supported platform's BGP and forwarding views. Verify next-hop recursion and application traffic in both directions. Then withdraw the preferred upstream and observe route changes, hardware installation, stateful boundary behavior and application recovery. Internal reachability during the event is useful but does not prove Internet service.

For physical resilience, trace each circuit to carrier demarcation, building entry, duct, power and management dependencies. Two circuit IDs can share one failure. Record carrier escalation contacts and the exact demarcation tests the operator can perform under authority; an escalation should include times, interfaces, prefixes and packet-loss evidence.

A completed border design includes rejected-route evidence, allowed-route forwarding, capacity under maintenance, protected management access and an executed rollback. Do not use full routing-table size or neighbor count as a proxy for correctness.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

**Reasoning:** Reject routes outside the customer contract; accepting a default can redirect broad traffic. Origin-valid does not authorize the observed transit relationship. The shared duct remains a common cause despite two circuits. Test filter behavior only in the isolated lab and document each independent control.

#### Guided practice

One upstream withdraws its default while specific internal routes remain. Explain the difference between preserving internal reachability and retaining Internet service.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Internal routes can continue forwarding within their scope while destinations requiring the default become unreachable or use another eligible default. Test actual external application paths and DNS dependencies; internal ping success is not Internet continuity.

#### Independent task

Environment: vendor

Build a constrained DCI/border routing design with tested route-leak prevention and independent recovery paths.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Only contracted routes are imported and exported.
- Origin validation is not overstated as path validation.
- Failure tests include physical and policy common causes.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0381 · single · implementation**

Which customer advertisement is authorized?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

1. Every private prefix
2. 10.10.0.0/16 only
3. The default route

**Correct option(s):** 2

- Option 1: Incorrect. Private addressing does not grant authorization.
- Option 2: Correct. The contract explicitly limits the prefix.
- Option 3: Incorrect. It is outside the contract.

**CCIE-DC-Q0382 · single · calculation**

What is the risk of accepting the customer's default?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

1. It automatically strengthens origin validation
2. Only one host route changes
3. Broad unintended traffic attraction

**Correct option(s):** 3

- Option 1: Incorrect. These are separate controls.
- Option 2: Incorrect. Default has much wider scope.
- Option 3: Correct. Default can match many destinations.

**CCIE-DC-Q0383 · single · implementation**

What does origin-valid not establish?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

1. The complete AS path is authorized
2. A validation result exists
3. The origin matches valid authorization data

**Correct option(s):** 1

- Option 1: Correct. Origin validation checks the origin relationship.
- Option 2: Incorrect. The case supplies one.
- Option 3: Incorrect. That is its purpose.

**CCIE-DC-Q0384 · single · diagnosis**

Why can a route leak remain origin-valid?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

1. Leaks always rewrite every origin
2. RPKI validates every commercial relationship
3. The legitimate origin can be preserved

**Correct option(s):** 3

- Option 1: Incorrect. They need not.
- Option 2: Incorrect. It does not.
- Option 3: Correct. Propagation policy can still be wrong.

**CCIE-DC-Q0385 · single · implementation**

Which control bounds unexpected route volume?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

1. Maximum-prefix behavior
2. Only one prefix description
3. Only an NTP setting

**Correct option(s):** 1

- Option 1: Correct. It limits quantity under defined policy.
- Option 2: Incorrect. Descriptions do not enforce count.
- Option 3: Incorrect. It does not bound routes.

**CCIE-DC-Q0386 · single · implementation**

What defeats circuit independence?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

1. The shared duct
2. Different BGP autonomous systems
3. Different circuit labels

**Correct option(s):** 1

- Option 1: Correct. One physical event can cut both.
- Option 2: Incorrect. Logical provider distinction does not remove the shared physical duct.
- Option 3: Incorrect. Labels do not establish routing diversity.

**CCIE-DC-Q0387 · single · implementation**

Where should leak tests run?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

1. An isolated multi-AS environment
2. The production Internet without filters
3. Only a spreadsheet with no protocol test

**Correct option(s):** 1

- Option 1: Correct. Do not advertise experimental leaks publicly.
- Option 2: Incorrect. That creates external impact.
- Option 3: Incorrect. That cannot demonstrate implementation.

**CCIE-DC-Q0388 · single · diagnosis**

What does an internal ping after default loss prove?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

1. Only that tested internal reachability remains
2. Internet access is intact
3. All DNS services are healthy

**Correct option(s):** 1

- Option 1: Correct. External service needs separate routes.
- Option 2: Incorrect. The default may be missing.
- Option 3: Incorrect. The probe does not test DNS.

**CCIE-DC-Q0389 · single · diagnosis**

Why use explicit export policy?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

1. To replace physical diversity
2. To prevent unintended announcements
3. To eliminate BGP next hops

**Correct option(s):** 2

- Option 1: Incorrect. Policy does not change ducts.
- Option 2: Correct. Import policy does not govern every export.
- Option 3: Incorrect. Forwarding still needs them.

**CCIE-DC-Q0390 · single · implementation**

Which DCI consequence follows Layer 2 stretch?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

1. Elimination of duplicate addresses
2. Broader endpoint and broadcast failure scope
3. Automatic application consistency

**Correct option(s):** 2

- Option 1: Incorrect. Duplicates can propagate.
- Option 2: Correct. Mobility adds coupling.
- Option 3: Incorrect. That is not a network guarantee.

**CCIE-DC-Q0391 · single · implementation**

What should an asymmetric-path test include?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

1. Only neighbor uptime
2. Only outbound throughput
3. Both directions and stateful boundaries

**Correct option(s):** 3

- Option 1: Incorrect. Sessions do not prove application symmetry.
- Option 2: Incorrect. It misses return enforcement.
- Option 3: Correct. Forward and return paths can differ.

**CCIE-DC-Q0392 · single · implementation**

Which next-hop condition blocks an accepted route?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

1. A documented carrier name
2. A unique RD
3. Un re solvable forwarding next hop

**Correct option(s):** 3

- Option 1: Incorrect. Names do not resolve next hops.
- Option 2: Incorrect. Uniqueness is not this failure.
- Option 3: Correct. Policy acceptance alone is insufficient.

**CCIE-DC-Q0393 · single · diagnosis**

Why preserve independent management access?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

1. A routing change can remove in-band access
2. BGP guarantees management delivery
3. Management never uses IP

**Correct option(s):** 1

- Option 1: Correct. Rollback needs another path.
- Option 2: Incorrect. It can withdraw that route too.
- Option 3: Incorrect. It often does.

**CCIE-DC-Q0394 · single · implementation**

What distinguishes prefix filtering from origin validation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

1. They always produce identical decisions
2. Allowed address scope versus authorized origin
3. Both validate application users

**Correct option(s):** 2

- Option 1: Incorrect. A route can pass one and fail the other.
- Option 2: Correct. Both may be required.
- Option 3: Incorrect. They are routing controls.

**CCIE-DC-Q0395 · single · implementation**

Which maintenance precheck matters at the border?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

1. Surviving path capacity and policy
2. Only the contract renewal date
3. Only the number of BGP sessions

**Correct option(s):** 1

- Option 1: Correct. A second circuit may be unusable or overloaded.
- Option 2: Incorrect. It does not verify forwarding.
- Option 3: Incorrect. Count omits behavior.

**CCIE-DC-Q0396 · single · implementation**

What should a maximum-prefix test verify?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

1. Only received route names
2. Only the configured number
3. Threshold action and recovery procedure

**Correct option(s):** 3

- Option 1: Incorrect. Routes have attributes, not arbitrary names.
- Option 2: Incorrect. Effective behavior can differ.
- Option 3: Correct. An alarm-only and shutdown policy differ.

**CCIE-DC-Q0397 · single · design**

Which design decision requires application input?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

1. Whether every subnet must be stretched for convenience
2. Whether address continuity needs Layer 2 stretch
3. Which unused label to choose

**Correct option(s):** 2

- Option 1: Incorrect. Application/address-continuity requirements should justify stretch rather than convenience.
- Option 2: Correct. Network convenience alone is insufficient.
- Option 3: Incorrect. That does not constrain applications.

**CCIE-DC-Q0398 · single · implementation**

What should happen to unauthorized10.20.0.0/16?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

1. Accept because it is private
2. Advertise it publicly for testing
3. Reject and record it

**Correct option(s):** 3

- Option 1: Incorrect. Private space still needs policy.
- Option 2: Incorrect. That is unauthorized external action.
- Option 3: Correct. It exceeds the customer scope.

**CCIE-DC-Q0399 · single · implementation**

What is a bounded recovery claim?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

1. Valid origin prevents every leak
2. Two circuits eliminate every outage
3. The tested peer loss met the stated application limit

**Correct option(s):** 3

- Option 1: Incorrect. It does not validate the full path.
- Option 2: Incorrect. Shared dependencies remain.
- Option 3: Correct. It describes observed scope.

**CCIE-DC-Q0400 · single · implementation**

Which closeout combines security and availability?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic isolated multi-AS lab: customer AS 65010 may advertise 10.10.0.0/16 only. It sends 10.10.0.0/16 plus default 0.0.0.0/0 and 10.20.0.0/16. Upstream imports all. A separate public-prefix example has valid origin but an unauthorized transit path. Two carrier circuits share one building duct.

1. Only a full routing table
2. Only low link utilization
3. Filter rejection evidence plus failover application tests

**Correct option(s):** 3

- Option 1: Incorrect. Quantity is not correctness.
- Option 2: Incorrect. That does not establish policy or recovery.
- Option 3: Correct. Both constraints must pass.

#### Recall

**Which customer advertisement is authorized?**

10.10.0.0/16 only The contract explicitly limits the prefix.

**Which control bounds unexpected route volume?**

Maximum-prefix behavior It limits quantity under defined policy.

**Why use explicit export policy?**

To prevent unintended announcements Import policy does not govern every export.

**Why preserve independent management access?**

A routing change can remove in-band access Rollback needs another path.

**Which design decision requires application input?**

Whether address continuity needs Layer 2 stretch Network convenience alone is insufficient.

#### References

- [BGP operational security](https://www.rfc-editor.org/rfc/rfc7454.html)
- [Cisco Nexus routing guides](https://www.cisco.com/c/en/us/support/switches/nexus-9000-series-switches/products-installation-and-configuration-guides-list.html)

## CCIE-DC-M21 — Integrated fault isolation across ACI, UCS and SAN

### CCIE-DC-L21 — Integrated fault isolation across ACI, UCS and SAN

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L20

Integrated troubleshooting is an exercise in competing hypotheses. Begin with the failing function and the last known good state, then list the necessary dependencies without assuming that the most recent change caused everything. A database outage may combine network policy, storage path and compute identity failures. Restoring one dependency can reveal another. Keep each hypothesis tied to an observation that could disprove it.

Use a layered evidence table: workload state, host interfaces and routes, fabric classification and forwarding, storage discovery and I/O, identity/authorization and relevant control events. Distinguish unavailable evidence from evidence of absence. If a collector is stale, its green status cannot eliminate a hypothesis. Prefer narrow read-only observations before disruptive resets, and state what result would justify the next action.

A safe correction preserves unaffected services and diagnostic evidence. If the suspected fault is a single missing contract, disabling an entire VRF's enforcement is an unjustified expansion. If storage paths are failing, a server reboot may erase the only useful timing evidence while adding recovery risk. An incident commander should track parallel technical work so two teams do not change shared state in incompatible ways.

After restoration, test the full application transaction and the original negative controls, then capture the causal chain and latent defects. A root cause can include both an initiating error and a missing acceptance gate that allowed it into service. Improve the engineering process using specific evidence rather than simply blaming an operator.

### Implementation walkthrough: maintain a hypothesis ledger
Write the failing function precisely: `App cannot complete a database transaction`, not `the network is down`. Create hypotheses for application listener, network classification/contract, route/adjacency, host storage access, identity and telemetry validity. For each, record a predicted observation, an observation that would disprove it, current evidence and the next least-disruptive test.

For the supplied incident, the responsive console rules out total host power loss but leaves application and storage failures open. The missing DB contract predicts a policy drop for the specific tuple. Wrong array WWPN mapping predicts absent LUN access even if a physical path is up. The stale dashboard cannot eliminate any current-state hypothesis. These are three independent observations, not one generic red status.

Run parallel read-only investigations where they do not conflict. One engineer can inspect ACI policy while another inspects host and array state, but all changes need a shared incident record. Before an action, state expected effect, affected scope, rollback and stop condition. Avoid simultaneous broad changes that make the causal result uninterpretable.

After restoring the contract, retest and record which symptom changed. If storage still fails, do not undo the valid network repair merely because the application remains down. Correct the approved storage identity and then test a real query against disposable or owner-approved data. Include latency, data integrity and denied lateral access.

A final causal record should distinguish initiating changes, latent defects and failed detection/acceptance gates. 'Operator error' is not sufficient if the system lacked a check that would have rejected an obsolete WWPN or missing contract. Add specific prevention: identity reconciliation before boot, policy matrix testing before release and freshness alarms for the dashboard.

The independent assessment uses a new incident with at least two interacting faults. The assessor supplies incomplete but consistent evidence and asks the learner to request the next observation. Credit depends on discrimination and safe correction, not guessing the hidden answer from a familiar symptom.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

**Reasoning:** The missing contract explains one network barrier; it does not establish storage readiness. The host console rules out total power loss but not disk unavailability. Path B link state is insufficient because masking references an obsolete identity. Preserve the working tenant, repair approved dependencies one at a time and test a real database transaction. Mark the dashboard stale.

#### Guided practice

Order three minimally disruptive observations that distinguish network policy failure, host service failure and storage authorization failure.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Confirm the DB process/listener and local storage status; inspect the specific ACI classification/contract path; compare current host WWPN with active zoning and array mapping. The exact order can depend on access and impact, but each observation should discriminate a hypothesis without resetting unrelated systems.

#### Independent task

Environment: vendor

Diagnose an unfamiliar multi-domain incident using falsifiable hypotheses, coordinated changes and full-function recovery evidence.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Each hypothesis has supporting and disconfirming evidence.
- Unaffected tenant service is preserved.
- Recovery includes application function and negative security tests.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0401 · single · implementation**

What does the responsive console rule out?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

1. Every network policy fault
2. Total host power loss
3. Every storage failure

**Correct option(s):** 2

- Option 1: Incorrect. Console may use another path.
- Option 2: Correct. It does not establish disk or service health.
- Option 3: Incorrect. Console access can survive disk failure.

**CCIE-DC-Q0402 · single · diagnosis**

Why is path B up insufficient?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

1. Array mapping still uses the wrong WWPN
2. An up path cannot carry FC
3. The database must be powered off

**Correct option(s):** 1

- Option 1: Correct. Transport and authorization differ.
- Option 2: Incorrect. It can if other dependencies work.
- Option 3: Incorrect. No such evidence exists.

**CCIE-DC-Q0403 · single · implementation**

Which dashboard conclusion is valid?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

1. All systems are healthy
2. The collector proves an array fault
3. Current health is unknown from that stale sample

**Correct option(s):** 3

- Option 1: Incorrect. The sample is 30 minutes old.
- Option 2: Incorrect. Staleness does not identify that cause.
- Option 3: Correct. Freshness is missing.

**CCIE-DC-Q0404 · single · calculation**

What is the narrow network correction?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

1. Restore the approved DB contract
2. Delete every tenant route
3. Disable all VRF enforcement

**Correct option(s):** 1

- Option 1: Correct. It addresses the specific missing relation.
- Option 2: Incorrect. That expands the outage.
- Option 3: Incorrect. That violates unaffected isolation.

**CCIE-DC-Q0405 · single · diagnosis**

Why can one repair reveal another fault?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

1. Dependencies fail independently
2. Repair always causes the next fault
3. Only one fault can exist per incident

**Correct option(s):** 1

- Option 1: Correct. Multiple barriers can coexist.
- Option 2: Incorrect. Temporal order alone does not prove causation.
- Option 3: Incorrect. That assumption is false.

**CCIE-DC-Q0406 · single · implementation**

Which observation tests host service state?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

1. Only interface linkup
2. Only APIC login
3. Local process/listener and transaction checks

**Correct option(s):** 3

- Option 1: Incorrect. That is network transport.
- Option 2: Incorrect. That is controller access.
- Option 3: Correct. Console availability alone is weaker.

**CCIE-DC-Q0407 · single · implementation**

What should happen before a broad reboot?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

1. Close all incident records
2. Preserve evidence and test narrower hypotheses
3. Assume reboot is the only diagnostic

**Correct option(s):** 2

- Option 1: Incorrect. The cause is unresolved.
- Option 2: Correct. Reboot can erase state and expand impact.
- Option 3: Incorrect. Read-only observations remain available.

**CCIE-DC-Q0408 · single · implementation**

Which negative test belongs after repair?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

1. Forbidden lateral access remains blocked
2. Only check server power
3. Only repeat the allowed query

**Correct option(s):** 1

- Option 1: Correct. Restoration must preserve isolation.
- Option 2: Incorrect. That omits application and policy.
- Option 3: Incorrect. That omits security scope.

**CCIE-DC-Q0409 · single · diagnosis**

What distinguishes missing evidence from evidence of absence?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

1. Whether the dashboard is green
2. Whether one engineer is confident
3. Whether the observation was valid and complete

**Correct option(s):** 3

- Option 1: Incorrect. Color does not establish validity.
- Option 2: Incorrect. Confidence is not measurement.
- Option 3: Correct. A stale collector cannot prove no fault.

**CCIE-DC-Q0410 · single · diagnosis**

Why coordinate network and storage teams?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

1. Only one team can investigate
2. Team names determine root cause
3. They can change shared dependencies

**Correct option(s):** 3

- Option 1: Incorrect. Parallel read-only work can be useful.
- Option 2: Incorrect. Evidence does.
- Option 3: Correct. Uncoordinated actions complicate causality.

**CCIE-DC-Q0411 · single · implementation**

Which artifact makes a hypothesis falsifiable?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

1. A strong assertion without a test
2. A generic vendor escalation
3. A predicted observation that would disprove it

**Correct option(s):** 3

- Option 1: Incorrect. That cannot be falsified operationally.
- Option 2: Incorrect. It does not define the prediction.
- Option 3: Correct. Diagnosis needs more than a guess.

**CCIE-DC-Q0412 · single · implementation**

What does another healthy tenant support?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

1. All SAN mappings are correct
2. Some shared fabric functions still work
3. The failing tenant must be healthy

**Correct option(s):** 2

- Option 1: Incorrect. The other tenant may use different storage.
- Option 2: Correct. It narrows but does not eliminate tenant-specific faults.
- Option 3: Incorrect. Policies differ.

**CCIE-DC-Q0413 · single · implementation**

What should a correction preserve?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

1. Only configuration aesthetics
2. Only the fastest possible change
3. Unaffected services and needed evidence

**Correct option(s):** 3

- Option 1: Incorrect. That is not the objective.
- Option 2: Incorrect. Speed alone can increase harm.
- Option 3: Correct. Recovery should not expand blast radius.

**CCIE-DC-Q0414 · single · implementation**

Which test establishes useful database recovery?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

1. Only port 5432 opens
2. Only FC login
3. A correct application transaction with integrity checks

**Correct option(s):** 3

- Option 1: Incorrect. The service may still fail queries.
- Option 2: Incorrect. Storage authorization may still fail.
- Option 3: Correct. TCP connect alone is partial.

**CCIE-DC-Q0415 · single · diagnosis**

Why compare current and previous WWPN?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

1. Identity changed across maintenance
2. WWPN is only a cosmetic label
3. WWPN determines TCP port

**Correct option(s):** 1

- Option 1: Correct. External authorization may reference the old identity.
- Option 2: Incorrect. Policies use it as identity.
- Option 3: Incorrect. It does not.

**CCIE-DC-Q0416 · single · implementation**

What can be a latent contributing defect?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

1. Missing post maintenance acceptance tests
2. The existence of documentation
3. Any unrelated old warning

**Correct option(s):** 1

- Option 1: Correct. They allowed the initiating error to escape.
- Option 2: Incorrect. Documentation itself is not a fault.
- Option 3: Incorrect. Causality needs relevance.

**CCIE-DC-Q0417 · single · implementation**

Which incident claim requires caution?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

1. A contract is currently absent
2. The latest change caused all symptoms
3. The dashboard sample is stale

**Correct option(s):** 2

- Option 1: Incorrect. That is observed state.
- Option 2: Correct. Coincidence is not a complete causal chain.
- Option 3: Incorrect. The timestamp establishes that.

**CCIE-DC-Q0418 · single · implementation**

What should a stop point protect?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

1. Only the planned completion time
2. The last known usable recovery path
3. Only the ticket's wording

**Correct option(s):** 2

- Option 1: Incorrect. A deadline does not prove safety.
- Option 2: Correct. A failed change should not consume every option.
- Option 3: Incorrect. Operational state matters.

**CCIE-DC-Q0419 · single · implementation**

Which record supports future prevention?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

1. Only 'operator error'
2. Only a list of reboots
3. Initiating error, missed gate and specific new test

**Correct option(s):** 3

- Option 1: Incorrect. That omits systemic controls.
- Option 2: Incorrect. That does not explain causality.
- Option 3: Correct. It connects cause with improvement.

**CCIE-DC-Q0420 · single · implementation**

What closes the integrated incident?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: App-to-DB TCP 5432 fails after maintenance. ACI policy shows no DB contract. DB host console is responsive. SAN path A is down; path B is up but array LUN mapping uses a previous WWPN. Dashboard says healthy but last sample is 30 minutes old. Another tenant remains fully operational.

1. Only a successful configuration commit
2. Function, isolation and recoverability verified across dependencies
3. Only the first green icon

**Correct option(s):** 2

- Option 1: Incorrect. Intent is not service recovery.
- Option 2: Correct. Each layer contributes to acceptance.
- Option 3: Incorrect. Other faults can remain.

#### Recall

**What does the responsive console rule out?**

Total host power loss It does not establish disk or service health.

**Why can one repair reveal another fault?**

Dependencies fail independently Multiple barriers can coexist.

**What distinguishes missing evidence from evidence of absence?**

Whether the observation was valid and complete A stale collector cannot prove no fault.

**What should a correction preserve?**

Unaffected services and needed evidence Recovery should not expand blast radius.

**Which incident claim requires caution?**

The latest change caused all symptoms Coincidence is not a complete causal chain.

#### References

- [APIC troubleshooting guides](https://www.cisco.com/c/en/us/support/cloud-systems-management/application-policy-infrastructure-controller-apic/products-installation-and-configuration-guides-list.html)
- [UCS troubleshooting guides](https://www.cisco.com/c/en/us/support/servers-unified-computing/ucs-manager/products-installation-and-configuration-guides-list.html)
- [MDS troubleshooting guides](https://www.cisco.com/c/en/us/support/storage-networking/mds-9000-nx-os-san-os-software/products-installation-and-configuration-guides-list.html)

## CCIE-DC-M22 — Brownfield migration and reversible policy transition

### CCIE-DC-L22 — Brownfield migration and reversible policy transition

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L21

A migration must maintain service while moving authority and forwarding responsibility from one design to another. Inventory actual dependencies before drawing the target architecture: hidden static routes, hard-coded addresses, DHCP relays, multicast receivers, storage identities and monitoring paths can be missed by a logical diagram. Capture effective state, not only the intended configuration database.

Define coexistence rules. Which system owns a gateway, which advertises a prefix, which learns an endpoint and which enforces a policy during each stage? Two active owners can cause loops, duplicate addresses or inconsistent authorization. A staged design may deliberately permit temporary interoperability, but its scope and removal condition must be explicit. Avoid a broad temporary exception with no expiry or owner.

A rollback must remain feasible after each step. Data written on the new system, changed identities or schema conversion can make an old snapshot stale. Distinguish forwarding rollback from application/data rollback. Agree the point after which recovery becomes a forward repair rather than a simple return to the old state.

Use a canary representing the relevant dependencies, then expand in bounded batches. Validate allowed flows, denied flows, performance, monitoring and operational access after each batch. Keep the old environment available only as long as it supports a defined recovery requirement; otherwise it becomes unmanaged residual infrastructure.

### Implementation walkthrough: assign ownership at every migration stage
Create a stage table covering gateway ownership, prefix advertisement, endpoint attachment, security enforcement, DNS, storage identity, monitoring and operator access. Each row must identify the old owner, target owner, transfer condition and rollback consequence. A migration is unsafe if two systems can simultaneously claim an identity without an explicit supported coexistence design.

During preparation, discover actual static routes, hidden allow rules, relay addresses and application dependencies. Compare observed traffic with the documented flow matrix. Stage the target configuration without attracting production traffic prematurely. Use an isolated canary whose dependencies include the application's storage, multicast, identity and monitoring functions; a ping-only VM is not representative.

For the first cutover, withdraw or transfer the old gateway/advertisement according to the chosen architecture, attach the canary and validate the complete service. Record ARP/ND, endpoint learning, route/FIB and policy state. Test a denied flow immediately so a broad temporary permit cannot masquerade as successful migration.

Define the data decision point. Once new writes occur, a two-hour-old snapshot is not a complete rollback source. Determine whether writes are replicated, quiesced, journaled or reconciled under the application's supported recovery design. Network rollback can restore paths while leaving data inconsistent; the two recovery plans must agree.

Expand in bounded batches with explicit stop criteria. Preserve the old environment only while it has a reviewed recovery role, and maintain its security/monitoring during that interval. At retirement, remove obsolete routes, gateways, certificates, service accounts and temporary contracts. Keep evidence and required backups; retiring infrastructure is not permission to erase the migration record.

The closeout report states what moved, what was measured, which exceptions remain, their owners/expiry and the exact point after which recovery requires forward repair rather than simple reversal.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

**Reasoning:** Duplicate gateway ownership and premature route advertisement can cause inconsistent forwarding before all endpoints move. The canary lacks critical dependencies and cannot validate the application. Permit-any hides policy defects, and a 2-hour-old snapshot creates data-loss implications. Redesign staged ownership, test representative dependencies and define data-aware recovery.

#### Guided practice

Write a four-stage ownership table for preparation, canary, batch migration and old-fabric retirement.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Preparation retains old ownership while target policy is staged. Canary moves explicit endpoints with controlled route/gateway scope. Batches transfer documented ownership and validate each group. Retirement removes obsolete advertisements, exceptions and management access only after recovery and data-retention gates are met.

#### Independent task

Environment: vendor

Plan and execute a brownfield fabric migration with explicit ownership, representative canaries and data-aware recovery.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Exactly intended gateway and prefix owners exist at each stage.
- Temporary exceptions expire under review.
- Rollback includes data written after cutover.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0421 · single · implementation**

What does duplicate gateway response threaten?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

1. Consistent first-hop ownership
2. Guaranteed capacity improvement
3. Only DNS naming

**Correct option(s):** 1

- Option 1: Correct. Two responders can create ambiguous forwarding.
- Option 2: Incorrect. Duplicate ownership does not add safe capacity.
- Option 3: Incorrect. The fault is at gateway resolution.

**CCIE-DC-Q0422 · single · diagnosis**

Why is early prefix advertisement risky?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

1. A prefix advertisement moves VMs automatically
2. BGP forbids all migrations
3. Traffic can reach unmigrated dependencies

**Correct option(s):** 3

- Option 1: Incorrect. It does not.
- Option 2: Incorrect. It does not.
- Option 3: Correct. Reachability is claimed before delivery exists.

**CCIE-DC-Q0423 · single · diagnosis**

Why is the test VM a weak canary?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

1. It hasan IP address
2. It can ping
3. It omits storage and multicast dependencies

**Correct option(s):** 3

- Option 1: Incorrect. That is needed for network tests.
- Option 2: Incorrect. That is useful but insufficient.
- Option 3: Correct. Representative ness is missing.

**CCIE-DC-Q0424 · single · implementation**

What is wrong with permit-any without expiry?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

1. It creates unbounded policy drift
2. It guarantees least privilege
3. It fixes gateway ownership

**Correct option(s):** 1

- Option 1: Correct. Temporary scope can become permanent.
- Option 2: Incorrect. It permits broad access.
- Option 3: Incorrect. Policy does not resolve duplicate gateways.

**CCIE-DC-Q0425 · single · implementation**

What does the old snapshot omit?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

1. Two hours of new writes
2. Every network configuration
3. All historical data

**Correct option(s):** 1

- Option 1: Correct. Rollback may lose committed data.
- Option 2: Incorrect. The case describes a database snapshot.
- Option 3: Incorrect. It contains older state.

**CCIE-DC-Q0426 · single · implementation**

Which table should define each stage?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

1. Only equipment cost
2. Gateway, route, endpoint and policy ownership
3. Only task start times

**Correct option(s):** 2

- Option 1: Incorrect. Cost does not define forwarding control.
- Option 2: Correct. Authority must be unambiguous.
- Option 3: Incorrect. Timing alone omits ownership.

**CCIE-DC-Q0427 · single · diagnosis**

Why distinguish network and data rollback?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

1. Returning routes does not reconcile new data
2. Data never changes during migration
3. A gateway change automatically restores databases

**Correct option(s):** 1

- Option 1: Correct. Different state domains need recovery plans.
- Option 2: Incorrect. The case explicitly has writes.
- Option 3: Incorrect. It does not.

**CCIE-DC-Q0428 · single · implementation**

What should a temporary exception include?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

1. Owner, scope, expiry and removal test
2. Only 'temporary' in its name
3. No logging to reduce noise

**Correct option(s):** 1

- Option 1: Correct. It needs bounded lifecycle control.
- Option 2: Incorrect. Names do not enforce expiry.
- Option 3: Incorrect. That weakens oversight.

**CCIE-DC-Q0429 · single · implementation**

What proves a batch is ready to expand?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

1. Required positive, negative and operational tests pass
2. No one complained immediately
3. The previous batch finished quickly

**Correct option(s):** 1

- Option 1: Correct. Ping alone omits constraints.
- Option 2: Incorrect. Silent defects can remain.
- Option 3: Incorrect. Speed is not acceptance.

**CCIE-DC-Q0430 · single · diagnosis**

Why inventory actual static routes?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

1. Static routes cannot affect migration
2. Undocumented dependencies may bypass the target design
3. All static routes are automatically wrong

**Correct option(s):** 2

- Option 1: Incorrect. They can redirect traffic.
- Option 2: Correct. Intent databases can be incomplete.
- Option 3: Incorrect. Some are intentional.

**CCIE-DC-Q0431 · single · implementation**

Which event can end simple rollback feasibility?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

1. A harmless read-only inventory
2. Saving an extra log copy
3. Irreversible or unreconciled state changes

**Correct option(s):** 3

- Option 1: Incorrect. It changes no state.
- Option 2: Incorrect. That does not constrain rollback.
- Option 3: Correct. Recovery may need forward repair.

**CCIE-DC-Q0432 · single · implementation**

What should old-fabric retirement remove?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

1. All historical evidence
2. Obsolete advertisements, exceptions and access
3. Only the diagram label

**Correct option(s):** 2

- Option 1: Incorrect. Records support audit and recovery.
- Option 2: Correct. Residual authority creates risk.
- Option 3: Incorrect. Live state would remain.

**CCIE-DC-Q0433 · single · implementation**

Which negative test catches policy drift?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

1. Only a second allowed ping
2. A forbidden flow across new classification
3. Only an interface speed check

**Correct option(s):** 2

- Option 1: Incorrect. It repeats positive coverage.
- Option 2: Correct. Allowed traffic alone is insufficient.
- Option 3: Incorrect. It does not test authorization.

**CCIE-DC-Q0434 · single · diagnosis**

Why preserve monitoring during cutover?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

1. Monitoring automatically prevents outages
2. Loss of observation can hide failure
3. The new fabric needs only a GUI

**Correct option(s):** 2

- Option 1: Incorrect. It detects, not prevents all faults.
- Option 2: Correct. The measurement path is a dependency.
- Option 3: Incorrect. Service evidence remains necessary.

**CCIE-DC-Q0435 · single · implementation**

What should a rollback trigger be?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

1. A measurable breach of agreed acceptance
2. Only subjective discomfort
3. Only expiration of the whole weekend

**Correct option(s):** 1

- Option 1: Correct. It supports timely decisions.
- Option 2: Incorrect. That lacks a defined gate.
- Option 3: Incorrect. Waiting may exceed recovery limits.

**CCIE-DC-Q0436 · single · implementation**

Which dependency can require special coexistence handling?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

1. Only the project codename
2. Only the final target topology drawing
3. Multicast receiver and source state

**Correct option(s):** 3

- Option 1: Incorrect. Names have no forwarding effect.
- Option 2: Incorrect. Coexistence also needs live source/receiver and membership state during transition.
- Option 3: Correct. Membership and trees may cross the boundary.

**CCIE-DC-Q0437 · single · implementation**

What does preserved addressing not guarantee?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

1. That address-dependent configuration can be retained
2. Application continuity
3. That the IP value is unchanged

**Correct option(s):** 2

- Option 1: Incorrect. It may, subject to validation.
- Option 2: Correct. Policy, routing and state can still fail.
- Option 3: Incorrect. That is what is preserved.

**CCIE-DC-Q0438 · single · diagnosis**

Why use bounded batches?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

1. To limit blast radius and maintain recovery options
2. To guarantee zero downtime
3. To avoid all testing

**Correct option(s):** 1

- Option 1: Correct. Whole-site change concentrates risk.
- Option 2: Incorrect. Batching alone cannot prove that.
- Option 3: Incorrect. Each batch still needs validation.

**CCIE-DC-Q0439 · single · implementation**

What should a data-aware cutover record include?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

1. Only the gateway MAC
2. Only link utilization
3. Last consistent point and subsequent writes

**Correct option(s):** 3

- Option 1: Incorrect. That does not describe data.
- Option 2: Incorrect. It omits database changes.
- Option 3: Correct. Recovery needs state history.

**CCIE-DC-Q0440 · single · implementation**

Which final claim is defensible?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic migration: old gateway and new anycast gateway both answer 10.50.0.1. New fabric advertises 10.50.0.0/24 before all endpoints are attached. Temporary permit-any contract has no expiry. Database receives new writes after cutover; rollback snapshot is 2 hours old. A test VM passes ping but has no storage or multicast dependencies.

1. A saved rollback file guarantees recovery
2. The tested migration stages met stated constraints
3. The canary proves every future application

**Correct option(s):** 2

- Option 1: Incorrect. Recovery requires executable, validated procedure.
- Option 2: Correct. Evidence is scoped to observed conditions.
- Option 3: Incorrect. Representative ness is limited.

#### Recall

**What does duplicate gateway response threaten?**

Consistent first-hop ownership Two responders can create ambiguous forwarding.

**What does the old snapshot omit?**

Two hours of new writes Rollback may lose committed data.

**What proves a batch is ready to expand?**

Required positive, negative and operational tests pass Ping alone omits constraints.

**Which negative test catches policy drift?**

A forbidden flow across new classification Allowed traffic alone is insufficient.

**What does preserved addressing not guarantee?**

Application continuity Policy, routing and state can still fail.

#### References

- [Cisco Nexus migration guides](https://www.cisco.com/c/en/us/support/switches/nexus-9000-series-switches/products-installation-and-configuration-guides-list.html)
- [APIC migration guidance](https://www.cisco.com/c/en/us/support/cloud-systems-management/application-policy-infrastructure-controller-apic/products-installation-and-configuration-guides-list.html)

## CCIE-DC-M23 — Trusted restoration and controller recovery after compromise

### CCIE-DC-L23 — Trusted restoration and controller recovery after compromise

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L22

Restoring availability and restoring trust are different tasks. A configuration backup can contain the unauthorized account, route leak or malicious automation reference that caused the incident. Determine a trustworthy restoration point using provenance, timestamps, change records and comparison with reviewed intent. Preserve forensic evidence before overwriting compromised systems, subject to the incident authority and service constraints.

A controller backup may include tenant policy while relying on separately managed certificates, external identity, licensing, device state or software versions. Document the recovery set as a dependency graph. Protect backup confidentiality and integrity, retain an offline or otherwise isolated copy appropriate to the threat model, and test restoration into a representative isolated environment. A successful backup job is not a restore test.

Credential and key recovery must cover every authority the attacker could use: local administrators, AAA integrations, API tokens, controller certificates and automation runners. Rotating one password while leaving a stolen token valid does not remove access. Sequence rotation so operators retain a controlled recovery path and dependent services can authenticate to the rebuilt system.

Reconnect only after validating supported firmware/software, approved configuration, identities, policy boundaries and essential telemetry. Test useful application service and denied attack paths. Keep enhanced observation during return to service, record residual uncertainty and require the appropriate owner to accept it. The app's synthetic exercises demonstrate reasoning; actual trusted recovery requires independently reviewed execution evidence.

### Implementation walkthrough: rebuild a trusted recovery set
Inventory recovery dependencies before the incident: approved software images, configuration exports, controller backups, certificates/keys, identity integrations, licenses, device inventory, automation source/state and the procedures required to combine them. Classify which artifacts contain secrets and which can be safely shared with an assessor. Keep a protected reference copy that an ordinary compromised administrator cannot silently rewrite.

After compromise, preserve the relevant evidence under the incident authority before replacing state. Determine the earliest known malicious change and compare candidate backups with reviewed change history. A backup's cryptographic hash establishes consistency with a recorded file, not that its contents were benign when captured. Select a source whose provenance and content support the intended trust claim.

Restore into an isolated representative environment first. Validate software support and schema migration. Recreate controlled administration, then restore reviewed configuration and external dependencies. Revoke or rotate every compromised authority, including API tokens and automation runners, not merely one interactive password. Keep a tested recovery identity available so rotation does not strand the defenders.

Use a staged reconnection checklist: correct software/firmware, expected inventory, no unauthorized accounts, approved routes/contracts, current certificates, fresh logs/telemetry and required service transactions. Execute negative tests with the revoked token and prohibited network paths. A restored controller that routes but cannot send audit records has not passed the whole requirement.

Measure restoration time from the defined start event to the defined service/trust acceptance point. Do not stop the RTO clock at boot if the agreed service is still unavailable. Record data-loss implications separately where relevant. If the lab omits real hardware or external identity, mark those dependencies untested rather than promoting the result to production recovery evidence.

Return to service with enhanced observation and an owner-approved residual-risk record. The lesson is complete as study when the reasoning is understood; the practical gate closes only after independently reviewed execution evidence exists.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

**Reasoning:** Backup B is not automatically trustworthy merely because it is newest. Evaluate backup A against supported restoration/migration procedures and reviewed changes since its creation. Revoke the stolen token and rebuild dependent trust deliberately. Routing success alone is not acceptance while audit delivery and identity recovery remain incomplete.

#### Guided practice

Define a recovery gate for restoring network service without reintroducing the unauthorized account or losing operator access.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Preserve evidence; select and verify a trusted source; rebuild supported software; restore reviewed configuration through the supported schema path; establish controlled administration; revoke compromised authorities; validate policy and fresh audit delivery; then reconnect in stages with owner approval.

#### Independent task

Environment: vendor

Restore a compromised infrastructure controller from a reviewed recovery set and demonstrate both service and trust recovery.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- No known compromised authority remains valid.
- Restored state matches approved intent.
- Audit delivery and negative policy tests pass before broad reconnection.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0441 · single · diagnosis**

Why is backup B suspect?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

1. It is necessarily unreadable
2. It includes post-compromise state
3. All backups are inherently malicious

**Correct option(s):** 2

- Option 1: Incorrect. No readability fault is given.
- Option 2: Correct. Newest does not mean trusted.
- Option 3: Incorrect. Trust must be evaluated, not assumed either way.

**CCIE-DC-Q0442 · single · implementation**

What limits using backup A directly?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

1. It predates the attack
2. It contains no newest changes
3. Its older schema may need supported migration

**Correct option(s):** 3

- Option 1: Incorrect. That can be beneficial.
- Option 2: Incorrect. That requires reconciliation, not automatic rejection.
- Option 3: Correct. Version compatibility matters.

**CCIE-DC-Q0443 · single · implementation**

What remains after one password rotation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

1. Every certificate is automatically revoked
2. No attacker access can remain
3. The stolen API token

**Correct option(s):** 3

- Option 1: Incorrect. Password rotation does not do that.
- Option 2: Incorrect. Other authorities exist.
- Option 3: Correct. Independent credentials retain authority.

**CCIE-DC-Q0444 · single · implementation**

What does routing success not establish?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

1. The controller is powered on
2. Trusted identity and logging recovery
3. Some tested forwarding works

**Correct option(s):** 2

- Option 1: Incorrect. The test implies operation.
- Option 2: Correct. Forwarding is only one function.
- Option 3: Incorrect. That is observed.

**CCIE-DC-Q0445 · single · diagnosis**

Why preserve forensic evidence before overwrite?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

1. Preservation forbids all recovery
2. Rebuild can erase causal records
3. Evidence automatically restores service

**Correct option(s):** 2

- Option 1: Incorrect. Authorities can balance both.
- Option 2: Correct. Investigation and scope depend on them.
- Option 3: Incorrect. It supports analysis, not execution.

**CCIE-DC-Q0446 · single · implementation**

What should a recovery set include?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

1. Configuration, versions, keys and external dependencies
2. Only a device inventory
3. Only the latest GUI export

**Correct option(s):** 1

- Option 1: Correct. One file may not be sufficient.
- Option 2: Incorrect. Inventory is not recoverable state.
- Option 3: Incorrect. Its scope may omit dependencies.

**CCIE-DC-Q0447 · single · implementation**

Which test proves backup usability?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

1. Representative isolated restore and validation
2. Only seeing a green backup icon
3. Only checking file existence

**Correct option(s):** 1

- Option 1: Correct. Job success alone is insufficient.
- Option 2: Incorrect. That is not execution evidence.
- Option 3: Incorrect. A file can be unusable.

**CCIE-DC-Q0448 · single · diagnosis**

Why repair collector trust before acceptance?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

1. Logs never matter after recovery
2. Fresh audit delivery is a required control
3. A changed certificate means all traffic is corrupt

**Correct option(s):** 2

- Option 1: Incorrect. They support verification and detection.
- Option 2: Correct. Availability without observation is partial.
- Option 3: Incorrect. That claim is unsupported.

**CCIE-DC-Q0449 · single · implementation**

What should credential scope analysis include?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

1. Only interactive administrator passwords
2. Only the interactive password
3. Tokens, local accounts, AAA and automation identities

**Correct option(s):** 3

- Option 1: Incorrect. API tokens, AAA integrations and automation identities can retain independent authority.
- Option 2: Incorrect. That omits other access.
- Option 3: Correct. Authority exists across interfaces.

**CCIE-DC-Q0450 · single · diagnosis**

Why stage reconnection?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

1. To avoid negative testing
2. To observe and bound residual risk
3. To guarantee no latent issue exists

**Correct option(s):** 2

- Option 1: Incorrect. Denied-path tests remain necessary.
- Option 2: Correct. Broad exposure can reintroduce impact.
- Option 3: Incorrect. Staging cannot prove absence universally.

**CCIE-DC-Q0451 · single · implementation**

Which source deserves comparison with restored state?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

1. Reviewed intended configuration and change records
2. Only the last login message
3. Only the compromised dashboard

**Correct option(s):** 1

- Option 1: Correct. They help detect unauthorized drift.
- Option 2: Incorrect. It omits most policy.
- Option 3: Incorrect. It maybe untrustworthy.

**CCIE-DC-Q0452 · single · implementation**

What must key rotation preserve?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

1. Every old token forever
2. Anonymous administration
3. Controlled operator recovery access

**Correct option(s):** 3

- Option 1: Incorrect. Compromised authority must be removed.
- Option 2: Incorrect. That loses accountability.
- Option 3: Correct. Locking out defenders can block restoration.

**CCIE-DC-Q0453 · single · diagnosis**

Which claim requires independent execution evidence?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

1. A backup dependency exists
2. The proposed sequence is documented
3. The actual platform recovered within its limit

**Correct option(s):** 3

- Option 1: Incorrect. The inventory can show it.
- Option 2: Incorrect. The document can establish that.
- Option 3: Correct. A written scenario cannot prove that.

**CCIE-DC-Q0454 · single · implementation**

What does a valid backup hash prove?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

1. No unauthorized configuration exists
2. Integrity relative to the recorded hash
3. Every restore will succeed

**Correct option(s):** 2

- Option 1: Incorrect. Malicious state can hash consistently.
- Option 2: Correct. It does not prove benign content.
- Option 3: Incorrect. Compatibility remains separate.

**CCIE-DC-Q0455 · single · implementation**

Which negative test belongs before broad return?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

1. Only an allowed ping
2. Compromised token and forbidden paths are rejected
3. Only checking CPU temperature

**Correct option(s):** 2

- Option 1: Incorrect. That omits attacker access.
- Option 2: Correct. Trust recovery needs denial evidence.
- Option 3: Incorrect. That does not validate authority.

**CCIE-DC-Q0456 · single · implementation**

What is the risk of restoring blindly?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

1. Reintroducing unauthorized state
2. Automatically erasing all application data
3. Guaranteed hardware damage

**Correct option(s):** 1

- Option 1: Correct. Backups can preserve compromise.
- Option 2: Incorrect. That depends on the system.
- Option 3: Incorrect. No such mechanism is supplied.

**CCIE-DC-Q0457 · single · diagnosis**

Why record residual uncertainty?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

1. To substitute opinions for evidence
2. To declare every system unusable forever
3. Owners need an honest acceptance basis

**Correct option(s):** 3

- Option 1: Incorrect. It should identify evidence gaps.
- Option 2: Incorrect. Uncertainty can be bounded and managed.
- Option 3: Correct. Unverified aspects must remain visible.

**CCIE-DC-Q0458 · single · implementation**

Which step supports a trustworthy software base?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

1. Only restart the same unknown image
2. Validate supported images and provenance
3. Only change a tenant name

**Correct option(s):** 2

- Option 1: Incorrect. Restart does not establish trust.
- Option 2: Correct. Configuration alone is not the whole base.
- Option 3: Incorrect. That leaves software unchanged.

**CCIE-DC-Q0459 · single · implementation**

What distinguishes RTO from trust acceptance?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

1. Recovery time is one constraint among others
2. Trust review eliminates timing requirements
3. RTO proves all security controls

**Correct option(s):** 1

- Option 1: Correct. Fast restoration can still be compromised.
- Option 2: Incorrect. Both matter.
- Option 3: Incorrect. It measures time, not trust.

**CCIE-DC-Q0460 · single · implementation**

What closes the recovery exercise?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic incident: controller backup B was made after an unauthorized admin account appeared. Backup A predates that account but uses an older schema. A stolen API token remains valid. The restored lab controller can route traffic but cannot send audit logs because its collector certificate changed. No production action is authorized.

1. Only completing the checklist without observations
2. Approved state, revoked compromise, working service and fresh evidence
3. Only restored routing

**Correct option(s):** 2

- Option 1: Incorrect. Implementation is not demonstrated behavior.
- Option 2: Correct. All specified gates must pass.
- Option 3: Incorrect. Identity and logging remain open.

#### Recall

**Why is backup B suspect?**

It includes post-compromise state Newest does not mean trusted.

**Why preserve forensic evidence before overwrite?**

Rebuild can erase causal records Investigation and scope depend on them.

**What should credential scope analysis include?**

Tokens, local accounts, AAA and automation identities Authority exists across interfaces.

**Which claim requires independent execution evidence?**

The actual platform recovered within its limit A written scenario cannot prove that.

**Why record residual uncertainty?**

Owners need an honest acceptance basis Unverified aspects must remain visible.

#### References

- [Cisco APIC backup and recovery guidance](https://www.cisco.com/c/en/us/support/cloud-systems-management/application-policy-infrastructure-controller-apic/products-installation-and-configuration-guides-list.html)
- [Cisco Nexus security guidance](https://www.cisco.com/c/en/us/support/switches/nexus-9000-series-switches/products-installation-and-configuration-guides-list.html)

## CCIE-DC-M24 — Constrained design: capacity, failure budgets and operational cost

### CCIE-DC-L24 — Constrained design: capacity, failure budgets and operational cost

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L23

A design decision is defensible when it satisfies stated constraints under the required operating states. Begin with traffic demand, application latency, isolation, recovery objectives, growth, equipment support, maintenance requirements and budget. Distinguish a forecast from a measurement. Do not silently lower a requirement when a preferred architecture cannot satisfy it; expose the infeasibility and compare explicit alternatives.

Capacity must be evaluated after the allowed failure or maintenance event. Four 100 Gbit/s uplinks provide 400 Gbit/s nominally, but a requirement to survive two unavailable uplinks leaves 200 Gbit/s. If demand is 240 Gbit/s, the design is infeasible before overhead and bursts. ECMP hash granularity and uneven demand can also make aggregate capacity misleading. Evaluate oversubscription at the actual bottleneck and state the workload assumptions.

Redundancy analysis needs failure-domain independence. Two controllers may share power, identity, storage or a software defect. A common-cause matrix should accompany the topology. Recovery design then asks whether a fault is detected, whether the surviving path is usable, whether operators can act and whether the application recovers within its limit.

Lifecycle cost includes licensing, platform access, spares, power, cooling, training, operational complexity, upgrade windows and recovery labor. A cheaper device may be more expensive if it creates unsupported integration or fragile manual procedures. Conversely, maximum feature count can increase complexity without serving a requirement. Select the simplest supported design that meets the whole constraint set, and validate the key assumptions with representative tests.

### Implementation walkthrough: compare feasible complete alternatives
Turn every requirement into an explicit constraint: sustained and burst demand, allowed failures, maintenance state, latency, isolation, recovery, growth, supported equipment, cost and operational access. Write units and whether each input is measured, forecast or assumed. A design spreadsheet should expose uncertainty instead of hiding it behind a precise-looking total.

For the supplied rack, normal capacity is 4 × 100 = 400 Gbit/s. With two links unavailable, only 200 Gbit/s remains, below 240 Gbit/s demand. This is infeasible even before overhead. Candidate A adds enough independent usable links or higher-rate capacity to satisfy the same failure state. Candidate B proposes a changed failure/maintenance assumption or approved admission control; it is not equivalent until the owner accepts that requirement change.

Compare failure domains with a matrix rather than counting devices. For each pair of nominally redundant components, inspect power, room/duct, control plane, identity, management path, software version, operator procedure and spare availability. A common software defect can affect separate chassis; a shared identity outage can block every recovery login. State which common causes are accepted and which are mitigated.

Estimate lifecycle cost over a defined horizon. Include acquisition, subscriptions, support, spares, power/cooling impact, training, change effort, outage exposure and recovery labor. Use ranges for uncertain labor or failure assumptions. An automation platform can reduce repetitive work while adding licensing, state management and specialist support requirements; compare the complete paths rather than only the purchase invoice.

Design validation should target the assumptions most likely to change the decision: degraded-state capacity, hash distribution, tail latency, restore time and operator task complexity. A representative lab can reduce uncertainty but does not establish all production scale effects. Record the remaining extrapolation.

The final decision memo names the selected alternative, rejected alternatives, violated constraints, sensitivity to assumptions and next evidence gate. A technically impressive topology that silently drops the maintenance requirement is rejected.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

**Reasoning:** The remaining 200 Gbit/s cannot carry 240 Gbit/s even before overhead, so the uplink proposal fails the requirement. Add capacity, reduce the allowed simultaneous outage, or negotiate demand controls explicitly. Shared UPS and identity create common causes. Compare total operating cost and failure risk rather than choosing solely by purchase price.

#### Guided practice

Propose two feasible alternatives and define the measurements that would discriminate them.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** One option increases uplink capacity enough to meet 240 Gbit/s after two losses; another revises the maintenance/failure requirement only with owner agreement. Compare cost, hash distribution, latency, maintenance time and recovery. For automation options, measure repeatable change effort and failure containment on a representative subset.

#### Independent task

Environment: vendor

Defend a data-center design against simultaneous capacity, security, reliability, maintainability and cost constraints.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- All required failure states are capacity-feasible.
- Common causes are explicit.
- Trade-offs retain every requirement or record an approved change.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0461 · single · implementation**

What capacity remains after two uplink losses?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

1. 240 Gbit/s
2. 200 Gbit/s
3. 400 Gbit/s

**Correct option(s):** 2

- Option 1: Incorrect. That is demand, not available capacity.
- Option 2: Correct. Two 100 Gbit/s links remain.
- Option 3: Incorrect. That is normal-state capacity.

**CCIE-DC-Q0462 · single · design**

Does the design meet the stated demand?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

1. Yes, normal capacity is 400
2. Yes, ECMP creates extra bandwidth
3. No, demand exceeds surviving capacity

**Correct option(s):** 3

- Option 1: Incorrect. The failure state is required.
- Option 2: Incorrect. It distributes, not creates capacity.
- Option 3: Correct. The deficit exists before overhead.

**CCIE-DC-Q0463 · single · design**

Which change preserves the original requirement?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

1. Ignore simultaneous maintenance
2. Increase usable surviving capacity
3. Silently allow demand shedding

**Correct option(s):** 2

- Option 1: Incorrect. That drops a stated constraint.
- Option 2: Correct. Demand and two-loss requirement remain intact.
- Option 3: Incorrect. That changes a prohibited behavior.

**CCIE-DC-Q0464 · single · diagnosis**

What common cause affects both controllers?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

1. Shared UPS and identity provider
2. Different controller names
3. Separate management IP addresses

**Correct option(s):** 1

- Option 1: Correct. Either dependency can affect both.
- Option 2: Incorrect. Names do not share operational failure.
- Option 3: Incorrect. Those do not remove the shared dependencies.

**CCIE-DC-Q0465 · single · diagnosis**

Why can aggregate capacity mislead?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

1. Hash imbalance and flow granularity matter
2. Aggregate rate is never useful
3. All links always split every packet equally

**Correct option(s):** 1

- Option 1: Correct. One flow may not use all paths.
- Option 2: Incorrect. It is useful but incomplete.
- Option 3: Incorrect. That is not generally true.

**CCIE-DC-Q0466 · single · implementation**

Which figure is a forecast?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

1. The stated future demand unless measured
2. A captured packet timestamp
3. An observed counter sample

**Correct option(s):** 1

- Option 1: Correct. Its evidence status must be explicit.
- Option 2: Incorrect. That is an observation.
- Option 3: Incorrect. That isa measurement, subject to quality.

**CCIE-DC-Q0467 · single · implementation**

What belongs to lifecycle cost?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

1. Licensing, operations, spares and recovery effort
2. Only chassis price
3. Only peak link speed

**Correct option(s):** 1

- Option 1: Correct. Purchase price is only one component.
- Option 2: Incorrect. That omits ongoing costs.
- Option 3: Incorrect. That is not a complete cost measure.

**CCIE-DC-Q0468 · single · diagnosis**

Why compare manual change effort?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

1. Manual work always fails
2. Automation has zero cost
3. Eighty-device workflows create recurring cost and risk

**Correct option(s):** 3

- Option 1: Incorrect. That universal claim is unsupported.
- Option 2: Incorrect. Licensing and training are explicit.
- Option 3: Correct. Operational complexity has consequences.

**CCIE-DC-Q0469 · single · diagnosis**

What should a common-cause matrix include?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

1. Only the number of chassis
2. Only interface counts
3. Power, identity, software and management dependencies

**Correct option(s):** 3

- Option 1: Incorrect. Separate chassis can share power, identity, software and management dependencies.
- Option 2: Incorrect. They omit shared services.
- Option 3: Correct. Physical link count is insufficient.

**CCIE-DC-Q0470 · single · implementation**

Which response is valid when infeasibility is found?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

1. Expose it and compare explicit trade-offs
2. Ignore the most expensive constraint
3. Relabel the design as advanced

**Correct option(s):** 1

- Option 1: Correct. Do not hide a requirement violation.
- Option 2: Incorrect. That changes scope without authorization.
- Option 3: Incorrect. Labels do not add capacity.

**CCIE-DC-Q0471 · single · calculation**

What musta recovery budget include?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

1. Only equipment delivery time
2. Detection, convergence, operator and application stages
3. Only BGP timer

**Correct option(s):** 2

- Option 1: Incorrect. That is not the whole incident recovery chain.
- Option 2: Correct. Total service interruption spans layers.
- Option 3: Incorrect. Other stages consume time.

**CCIE-DC-Q0472 · single · implementation**

Which architecture is preferable under equal compliance?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

1. The newest platform regardless of support
2. The simpler supported operable design
3. The one with most features regardless of need

**Correct option(s):** 2

- Option 1: Incorrect. Novelty is not compatibility.
- Option 2: Correct. Unneeded complexity adds lifecycle burden.
- Option 3: Incorrect. Feature count is not suitability.

**CCIE-DC-Q0473 · single · diagnosis**

Why test maintenance states?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

1. Planned withdrawal can expose hidden insufficiency
2. Normal-state throughput proves all states
3. Maintenance never coincides with faults

**Correct option(s):** 1

- Option 1: Correct. Availability includes ordinary maintenance.
- Option 2: Incorrect. Capacity changes after withdrawal.
- Option 3: Incorrect. That cannot be assumed.

**CCIE-DC-Q0474 · single · design**

What should an approved requirement change contain?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

1. Owner agreement and consequence analysis
2. Only anew diagram title
3. Only an engineer's private assumption

**Correct option(s):** 1

- Option 1: Correct. Trade-offs must be explicit.
- Option 2: Incorrect. It does not change the actual requirement.
- Option 3: Incorrect. That lacks approval and traceability.

**CCIE-DC-Q0475 · single · implementation**

Which measure discriminates automation options?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

1. Repeatable change effort and failure containment
2. Only source code line count
3. Only the number of automated commands

**Correct option(s):** 1

- Option 1: Correct. It connects operations with cost and risk.
- Option 2: Incorrect. More code is not necessarily better.
- Option 3: Incorrect. Command count does not measure repeatable labor reduction or failure containment.

**CCIE-DC-Q0476 · single · implementation**

What does dual-controller count not establish?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

1. Independent recovery authority
2. That two controller objects exist
3. Potential management redundancy

**Correct option(s):** 1

- Option 1: Correct. Shared identity can block both.
- Option 2: Incorrect. Inventory can establish that.
- Option 3: Incorrect. It can provide that if dependencies work.

**CCIE-DC-Q0477 · single · diagnosis**

Why include overhead after basic feasibility?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

1. Overhead matters only in storage
2. Usable capacity is below ideal line-rate assumptions
3. Overhead always doubles capacity

**Correct option(s):** 2

- Option 1: Incorrect. Networks transmit headers too.
- Option 2: Correct. Headers and bursts reduce the margin.
- Option 3: Incorrect. It consumes resources.

**CCIE-DC-Q0478 · single · implementation**

Which test should accompany a bottleneck calculation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

1. Representative traffic distribution under failure
2. Only an asset inventory
3. Only one idle ping

**Correct option(s):** 1

- Option 1: Correct. The model needs behavioral validation.
- Option 2: Incorrect. It contains no workload behavior.
- Option 3: Incorrect. It does not exercise demand.

**CCIE-DC-Q0479 · single · implementation**

What isa defensible gigabit-scale claim?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

1. The design is sized under stated assumptions
2. The user has operated that scale
3. All future loads are covered

**Correct option(s):** 1

- Option 1: Correct. A plan is not measured achievement.
- Option 2: Incorrect. No such evidence exists.
- Option 3: Incorrect. Forecasts have bounds.

**CCIE-DC-Q0480 · single · design**

What closes the design review?

SYNTHETIC TEACHING DATA — not captured from equipment.
Synthetic requirement: rack demand 240 Gbit/s sustained; four 100 Gbit/s uplinks; any two uplinks may be unavailable; no demand shedding permitted. Two controllers share one UPS and one identity provider. Option X costs less initially but requires manual per-device changes across 80 switches. Option Y adds supported central automation with licensing and training cost.

1. Only a certificate badge
2. Requirement traceability, feasible calculations and validation plan
3. Only a visually clean topology

**Correct option(s):** 2

- Option 1: Incorrect. Credentials do not validate this design.
- Option 2: Correct. The design must be assessable.
- Option 3: Incorrect. Appearance is not engineering evidence.

#### Recall

**What capacity remains after two uplink losses?**

200 Gbit/s Two 100 Gbit/s links remain.

**Why can aggregate capacity mislead?**

Hash imbalance and flow granularity matter One flow may not use all paths.

**What should a common-cause matrix include?**

Power, identity, software and management dependencies Physical link count is insufficient.

**Why test maintenance states?**

Planned withdrawal can expose hidden insufficiency Availability includes ordinary maintenance.

**Why include overhead after basic feasibility?**

Usable capacity is below ideal line-rate assumptions Headers and bursts reduce the margin.

#### References

- [Cisco Nexus design guides](https://www.cisco.com/c/en/us/support/switches/nexus-9000-series-switches/products-installation-and-configuration-guides-list.html)
- [CCIE programme](https://www.cisco.com/site/us/en/learn/training-certifications/certifications/datacenter/ccie-data-center/index.html)

## CCIE-DC-M25 — Timed integrated practice and independent engineering evidence

### CCIE-DC-L25 — Timed integrated practice and independent engineering evidence

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CCIE-DC-L24

The public CCIE programme describes an eight-hour practical examination. The practice session here is original training, not a reproduction of that examination's tasks, scoring or timing partitions. Its purpose is to make the learner integrate mechanisms under a bounded clock while preserving engineering discipline. Do not infer readiness from answering the bank repeatedly; unfamiliar configurations, independent build work and recoverable mistakes are essential.

Before starting, prepare lawful platform access, a versioned topology, consoles, clean snapshots and a separate evidence directory. Read the complete task set before changing anything. Convert requirements into a dependency graph and acceptance checklist. Identify constraints that cannot be met with the supplied equipment, record them explicitly and request the exercise assessor's decision; do not secretly remove them.

Use checkpoints after infrastructure, tenant policy, compute/storage attachment and automation. A checkpoint records effective state and a tested service boundary, not merely a saved file. If a later task fails, compare against the last accepted state. Reserve time for negative tests, failover and recovery; a build that works only in normal conditions has not completed this programme's operating scope.

An assessor should vary the fault and requirements without revealing the answer. The learner must explain cause, demonstrate the correction and show that unrelated service remains healthy. Record assistance received, untested branches, simulation limits and actual platform versions. A timed analytical case is valid learning evidence, but it cannot be promoted into a claim of physical or production operation.

### Implementation walkthrough: an original eight-hour integration workbook
This is an authored practice session, not an official exam simulation. Use a licensed lab that can implement the relevant Nexus, ACI, UCS and SAN functions. If a component is unavailable, run the analytical version and label that branch unexecuted; do not substitute a generic virtual router and claim it reproduced an APIC or fabric interconnect.

Before the clock, the assessor provides a clean topology, platform versions, address/identity plan, approved traffic matrix, storage ownership, management roles and fault-injection authority. The learner receives requirements but not the fault answers. The assessor keeps a sealed fault manifest and a known-good reference state for recovery.

During the first hour, convert requirements into a dependency graph and identify infeasible constraints. The next three hours build and verify component dependencies. Two hours then address unfamiliar interacting faults. One hour validates automation, semantic rejection and telemetry. The final hour proves recovery and closes the evidence record. These allocations are training choices and can be changed for learning; they are not claimed official examination partitions.

Use these acceptance categories: transport/MTU; tenant routing and isolation; ACI classification/contracts; compute identity/boot; SAN access/integrity; automation authority/partial failure; management recovery; application performance. Every category needs a positive result and a relevant negative or failure result. A broad permit-all repair fails isolation even if it restores the intended flow.

Keep a command/API journal with timestamps, expected effect and observed result. Save checkpoints only after effective-state and service tests pass. On a failed task, record the uncertainty and next discriminating test rather than repeatedly applying unrelated fixes. At expiry, report exactly what is complete, partial, failed and untested.

The assessor scores causal reasoning, implementation precision, preservation of constraints, recovery and evidence quality. Retest with a different fault and dependency combination. Repeating the same 500-question bank can support recall, but readiness requires transfer to unfamiliar builds and actual supported-platform execution. No score in this app awards a certification or operating authority.

#### Worked demonstrations

**Trace the supplied state before changing it**

SYNTHETIC TEACHING DATA. Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

**Reasoning:** The allocation totals 480 minutes. Read all constraints before build, identify the impossible demand and obtain a recorded exercise decision. Build dependency checkpoints, preserve baseline evidence and reserve the final hour for recovery/closeout. If time expires with an unresolved fault, record the failed requirement instead of claiming completion.

#### Guided practice

Design an assessor rubric that gives no credit for a broad permit-all repair, even when the permitted application begins working.

**Hint:** Separate configured intent, installed control state, forwarding state and application observation. Predict the result before reading the solution.

**Worked solution:** Score mechanism explanation, narrow implementation, effective-state evidence, positive service, negative isolation, failure recovery and evidence integrity. A permit-all repair fails the security invariant and therefore cannot pass the task solely on reachability. Require an unfamiliar retest after remediation.

#### Independent task

Environment: vendor

Complete independently assessed integrated builds and fault recovery within a bounded practice session, with transparent evidence and unresolved requirements.

**Packaged starter material**

- course_labs/CCIE-DC/README.md

**Evidence to produce**

- Versioned topology and dependency map
- Intended and effective configuration with a causal packet or transaction trace
- Before/during/after evidence, counter deltas and accepted or rejected changes
- Recovery record with outstanding limitations

**Acceptance criteria**

- Every completed claim has observable evidence.
- Un met or infeasible constraints remain visible.
- The assessor verifies service, isolation and recovery on unfamiliar tasks.

The supplied exhibits are authored simulations. Platform syntax and features must be checked against the installed release. Written answers do not demonstrate physical forwarding, scale, RF, storage integrity or production authority.

#### Chapter practice

**CCIE-DC-Q0481 · single · implementation**

How long is the original practice allocation?

SYNTHETIC TEACHING DATA — not captured from equipment.
Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

1. 480 minutes
2. 600 minutes
3. 420 minutes

**Correct option(s):** 1

- Option 1: Correct. The five blocks total eight hours.
- Option 2: Incorrect. That exceeds the supplied allocation.
- Option 3: Incorrect. That omits one 60-minute block.

**CCIE-DC-Q0482 · single · implementation**

Does this reproduce the official examination?

SYNTHETIC TEACHING DATA — not captured from equipment.
Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

1. Yes, the same duration proves equivalence
2. No, it is original practice
3. Yes, every question is an actual exam item

**Correct option(s):** 2

- Option 1: Incorrect. Duration does not establish content equivalence.
- Option 2: Correct. Official tasks and scoring are not claimed.
- Option 3: Incorrect. The content is independently authored.

**CCIE-DC-Q0483 · single · implementation**

What should happen to the infeasible demand?

SYNTHETIC TEACHING DATA — not captured from equipment.
Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

1. Ignore it to finish faster
2. Record it and obtain an explicit exercise decision
3. Mark it passed because the topology is complex

**Correct option(s):** 2

- Option 1: Incorrect. That falsifies compliance.
- Option 2: Correct. Do not silently drop a constraint.
- Option 3: Incorrect. Complexity does not create capacity.

**CCIE-DC-Q0484 · single · implementation**

What makes a checkpoint meaningful?

SYNTHETIC TEACHING DATA — not captured from equipment.
Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

1. Only a configuration filename
2. Only elapsed time
3. Effective state plus tested behavior

**Correct option(s):** 3

- Option 1: Incorrect. It may never have been applied.
- Option 2: Incorrect. Time does not establish state.
- Option 3: Correct. A saved file alone is intent.

**CCIE-DC-Q0485 · single · diagnosis**

Why read the full task set first?

SYNTHETIC TEACHING DATA — not captured from equipment.
Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

1. Dependencies and constraints can interact
2. To memorize every command before acting
3. To avoid all planning records

**Correct option(s):** 1

- Option 1: Correct. A local shortcut may violate a later requirement.
- Option 2: Incorrect. References and reasoning remain useful.
- Option 3: Incorrect. The task calls for traceability.

**CCIE-DC-Q0486 · single · diagnosis**

What should happen when time expires with a fault?

SYNTHETIC TEACHING DATA — not captured from equipment.
Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

1. Erase the failed test
2. Declare success if most links are up
3. Record the unresolved requirement

**Correct option(s):** 3

- Option 1: Incorrect. That destroys evidence integrity.
- Option 2: Incorrect. Partial completion is not full acceptance.
- Option 3: Correct. Honest evidence preserves the gap.

**CCIE-DC-Q0487 · single · diagnosis**

Why include an unfamiliar retest?

SYNTHETIC TEACHING DATA — not captured from equipment.
Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

1. To guarantee certification success
2. Recall of one answer is not transfer
3. To avoid reviewing mechanisms

**Correct option(s):** 2

- Option 1: Incorrect. No exercise can guarantee that.
- Option 2: Correct. A new fault checks independent reasoning.
- Option 3: Incorrect. Mechanism review remains useful.

**CCIE-DC-Q0488 · single · implementation**

Which repair fails the rubric despite restored traffic?

SYNTHETIC TEACHING DATA — not captured from equipment.
Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

1. A supported rollback with verified service
2. A narrow approved contract repair
3. Permit-all that violates isolation

**Correct option(s):** 3

- Option 1: Incorrect. That can be valid recovery.
- Option 2: Incorrect. That can meet the policy requirement.
- Option 3: Correct. All simultaneous constraints matter.

**CCIE-DC-Q0489 · single · implementation**

What should the assessor conceal initially?

SYNTHETIC TEACHING DATA — not captured from equipment.
Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

1. The required acceptance criteria
2. The injected fault's answer
3. The task's safety and scope constraints

**Correct option(s):** 2

- Option 1: Incorrect. The learner needs the objectives.
- Option 2: Correct. Diagnosis should require evidence.
- Option 3: Incorrect. Those must be explicit.

**CCIE-DC-Q0490 · single · implementation**

What should assistance records show?

SYNTHETIC TEACHING DATA — not captured from equipment.
Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

1. Which steps required external help
2. No assistance because it looks weaker
3. Only the final score

**Correct option(s):** 1

- Option 1: Correct. Independence claims depend on it.
- Option 2: Incorrect. Omission misrepresents evidence.
- Option 3: Incorrect. That hides how work was completed.

**CCIE-DC-Q0491 · single · diagnosis**

Why reserve recovery time?

SYNTHETIC TEACHING DATA — not captured from equipment.
Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

1. The clock stops automatically during failures
2. Recovery is an assessed lifecycle function
3. Recovery is always instantaneous

**Correct option(s):** 2

- Option 1: Incorrect. That is not the stated practice rule.
- Option 2: Correct. A build-only result is incomplete.
- Option 3: Incorrect. It can consume substantial time.

**CCIE-DC-Q0492 · single · implementation**

Which claim can an analytical case support?

SYNTHETIC TEACHING DATA — not captured from equipment.
Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

1. Reasoned design and diagnosis within its model
2. Production ownership at scale
3. Physical forwarding performance

**Correct option(s):** 1

- Option 1: Correct. It does not prove hardware execution.
- Option 2: Incorrect. No production observation exists.
- Option 3: Incorrect. No actual platform measurement is given.

**CCIE-DC-Q0493 · single · diagnosis**

What should platform evidence identify?

SYNTHETIC TEACHING DATA — not captured from equipment.
Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

1. Only a course badge
2. Only a generic product family
3. Exact hardware/software and capture source

**Correct option(s):** 3

- Option 1: Incorrect. It does not identify the test environment.
- Option 2: Incorrect. That can omit important differences.
- Option 3: Correct. Behavior is version and environment dependent.

**CCIE-DC-Q0494 · single · implementation**

Which observation supports a narrow correction?

SYNTHETIC TEACHING DATA — not captured from equipment.
Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

1. Only a reduced alarm count
2. The failed function recovers while controls remain intact
3. Only a successful command exit

**Correct option(s):** 2

- Option 1: Incorrect. Suppression could hide faults.
- Option 2: Correct. It preserves unrelated requirements.
- Option 3: Incorrect. That may not prove behavior.

**CCIE-DC-Q0495 · single · diagnosis**

Why keep clean starting snapshots?

SYNTHETIC TEACHING DATA — not captured from equipment.
Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

1. They eliminate every data-loss risk
2. They replace current evidence capture
3. They support repeatable independent trials

**Correct option(s):** 3

- Option 1: Incorrect. Snapshots have scope and limitations.
- Option 2: Incorrect. Each run still needs observations.
- Option 3: Correct. A known baseline enables comparison.

**CCIE-DC-Q0496 · single · implementation**

What should a dependency graph expose?

SYNTHETIC TEACHING DATA — not captured from equipment.
Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

1. Only device purchase order
2. Only visual symmetry
3. Prerequisite objects and service relationships

**Correct option(s):** 3

- Option 1: Incorrect. That does not describe operational dependence.
- Option 2: Incorrect. Aesthetic balance is not dependency.
- Option 3: Correct. It guides safe build and recovery order.

**CCIE-DC-Q0497 · single · implementation**

What does repeated bank success not establish?

SYNTHETIC TEACHING DATA — not captured from equipment.
Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

1. That some concepts were recalled
2. Independent practical readiness
3. That the bank was attempted

**Correct option(s):** 2

- Option 1: Incorrect. It can show that limited result.
- Option 2: Correct. Recognition can improve without implementation skill.
- Option 3: Incorrect. Records can show attempts.

**CCIE-DC-Q0498 · single · implementation**

Which failure should remain in the final report?

SYNTHETIC TEACHING DATA — not captured from equipment.
Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

1. No failures if the final screenshot is green
2. Only faults that were easy to explain
3. Any untested or failed required branch

**Correct option(s):** 3

- Option 1: Incorrect. Screenshots do not erase missing tests.
- Option 2: Incorrect. That selectively hides evidence.
- Option 3: Correct. Coverage must be honest.

**CCIE-DC-Q0499 · single · calculation**

What is the purpose of negative tests?

SYNTHETIC TEACHING DATA — not captured from equipment.
Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

1. Replace application success tests
2. Verify required prohibitions remain enforced
3. Make all services unavailable

**Correct option(s):** 2

- Option 1: Incorrect. Both are required.
- Option 2: Correct. Successful access alone is incomplete.
- Option 3: Incorrect. Denial should be scoped.

**CCIE-DC-Q0500 · single · implementation**

What defines completion of this practice task?

SYNTHETIC TEACHING DATA — not captured from equipment.
Original eight-hour practice allocation: requirements/design 60 min; component build 180 min; integrated faults 120 min; automation/assurance 60 min; recovery/closeout 60 min. Synthetic topology includes two Nexus leaves, two spines, an ACI tenant, UCS compute and two SAN fabrics. The assessor injects three undisclosed faults and one infeasible capacity demand. Licensed platform access is required for actual execution.

1. Finishing before the clock with no records
2. Using every available command
3. Observed acceptance across build, isolation and recovery

**Correct option(s):** 3

- Option 1: Incorrect. Speed without evidence is insufficient.
- Option 2: Incorrect. Command count is not capability.
- Option 3: Correct. All required functions need evidence.

#### Recall

**How long is the original practice allocation?**

480 minutes The five blocks total eight hours.

**Why read the full task set first?**

Dependencies and constraints can interact A local shortcut may violate a later requirement.

**What should the assessor conceal initially?**

The injected fault's answer Diagnosis should require evidence.

**What should platform evidence identify?**

Exact hardware/software and capture source Behavior is version and environment dependent.

**What does repeated bank success not establish?**

Independent practical readiness Recognition can improve without implementation skill.

#### References

- [Official CCIE programme](https://www.cisco.com/site/us/en/learn/training-certifications/certifications/datacenter/ccie-data-center/index.html)
- [Official equipment/software baseline](https://learningcontent.cisco.com/documents/marketing/exam-topics/CCIE-DC-3.1-equipment_and_SW_reviewed.pdf)
