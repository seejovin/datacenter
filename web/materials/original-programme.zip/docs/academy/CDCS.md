# CDCS — Certified Data Centre Specialist — complete original design-review study course

Original independent instruction and practice. Read the teaching, work the demonstrations and guided exercise, then attempt questions before reading their explanations. Independent tasks require your own evidence.

Source baseline: [EPI public course syllabus; original independent study programme](https://www.epi-ap.com/services/1/3/5) · Public outline checked 2026-09-19 · checked 2026-09-19

Maps the public syllabus into original instruction and assessment. Provider examination weighting and protected training materials are not reproduced. These are original practice questions, not actual examination questions.

## Scope and external requirements

- Public outline does not disclose the full protected provider curriculum or item bank.

- App study does not award a credential or replace provider eligibility, required examinations, equipment access or field authority.

- Rating schemes, normative limits and installation duties require their actual applicable editions and competent authorities. Examples below are supplied educational models, not certified designs or permission for physical work.

- Retain the curriculum-assigned EPI course and official examination as separate requirements.

- Use approved vendor tools and procedures; physical, electrical, fire and mechanical work requires competent personnel and appropriate authority.

- D1 content is examination and interface literacy only. D2/D3 specialist engineering remains the later charter horizon; integration and operational coordination do not confer specialist authority.

- Obtain the applicable current normative standards and exact product/version manuals for real design decisions. Public source landing pages do not reproduce their protected full requirements.

- Retain external EPI CDCS instruction/examination and the valid actual CDCP prerequisite. Original practice-bank completion is not provider certification.

## Preparation

Prior courses: CDCP

- Provider enrollment and examination eligibility must be checked directly.

- EPI requires a valid actual CDCP certificate at the time of passing the CDCS examination. Completing this app’s CDCP course does not satisfy the provider credential requirement.

## CDCS-M01 — Design lifecycle, requirements and accepted operational capability

### CDCS-L01 — Design lifecycle, requirements and accepted operational capability

Estimated study time: 120 minutes before independent work. Prerequisite chapters: Use the course prerequisites.

## Requirements precede equipment selection

Data-centre design is a lifecycle of decisions that converts a business service into an accepted, maintainable and recoverable facility. A useful first document describes the service: workload, usable capacity, growth horizon, consequence of loss, recovery expectations, operating hours, interfaces, location constraints and environmental objectives. “Build a 1 MW data centre” is incomplete until the megawatt boundary is known. It may describe utility input, IT output or installed equipment nameplates. Define what is usable now, reserved for committed growth and conditional on future construction. State the required operating states, including maintenance, degraded service and restoration.

The owner’s requirements express the needed outcomes. A basis of design explains how the selected solution will meet them, with assumptions, calculations, standards, interfaces and alternatives. A vendor datasheet describes a product under specified conditions; it is not the site's complete design basis. Preserve a traceable chain from requirement to design decision, implementation item, verification method, evidence and acceptance. If a requirement has no testable observation, refine it before procurement locks the project into an ambiguous result. Availability, energy and environmental promises need measurement boundaries and reporting periods as well as a target.

Feasibility evaluates whether the service can be delivered at the chosen site and within resource constraints. Review utility capacity and delivery dates, cooling resources, telecommunications routes, ground and structural constraints, access, hazards, permissions, supply-chain dependencies and operating support. A planning assumption becomes a risk when its failure can change the decision; once an adverse condition occurs, it becomes an issue requiring resolution. Record source, confidence, owner, validation date and consequence. Do not transform an unconfirmed utility letter into a guaranteed energization date by placing it on a polished schedule.

## Develop and compare complete alternatives

Concept design identifies workable architectures and major trade-offs. Detailed design resolves calculations, component selection, interfaces, protection, maintainability, controls, drawings and specifications to the required maturity. Procurement should use a defined technical baseline and acceptance evidence. A low equipment price can conceal missing controls licenses, service clearances, commissioning, spare parts, treatment systems or future operating costs. Compare alternatives on an equivalent boundary and demand profile; record excluded items rather than assigning them zero cost. Value engineering should preserve the required outcome and expose the consequences of changes.

Capacity planning needs several dimensions. A rack can fit in floor area while exceeding power, cooling, structural or network capacity. A high-density AI row can meet total-room cooling capacity yet fail at a local coolant distribution unit or rack inlet. Map each capacity to its physical interface and limiting state. “N+1” equipment does not settle every distribution-path constraint. Define growth increments and what must be installed before each increment is admitted. Reserve space, routes and interfaces deliberately; empty floor area cannot substitute for unbuilt electrical or mechanical capability.

Life-cycle evaluation includes capital expenditure, energy, maintenance, consumables, staffing, renewal, downtime exposure and disposal within the chosen model. A simple undiscounted comparison is useful only when labeled as such. Discounted cash-flow analysis needs a stated discount rate, timing and assumptions; sensitivity tests should expose decisions that reverse under plausible changes. Avoid false precision when workload growth or energy price is uncertain. Reliability and safety requirements are constraints, not optional values to remove because a spreadsheet shows a short payback. A cheaper alternative that fails a mandatory criterion is not equivalent value.

## Manage interfaces and changes explicitly

Design responsibility is distributed. An electrical specialist owns protection and power design; a mechanical specialist owns relevant cooling design; controls engineers implement the agreed operating narrative and interfaces; network engineers provide communications within specified timing, security and availability requirements. An integrated review makes the boundaries fit. In this curriculum, D1 building and civil content remains examination and interface literacy, and D2/D3 specialist ownership remains a later charter horizon. Studying a calculation does not authorize signing a structural design, changing protective settings or executing live switching.

An interface control record should identify source and destination, physical/electrical requirements, protocol and data semantics, timing, authority, failure behavior, tests and owners. For a cooling permissive, ask which system owns the truth, what stale or missing data means, what independent protection remains, and how recovery is verified. A network heartbeat is not proof of a valid process measurement. A BAS or EPMS display must not silently become the independent protective function merely because both report the same equipment. Retain vendor platform/version constraints and the responsibility matrix through design, commissioning and operations.

Changes require impact analysis across those relationships. A sensor model substitution can change range, output type, scaling, wiring, calibration and alarm behavior. A rack power-density increase can affect airflow, liquid requirements, cable loading and maintenance clearances. Record the reason, alternatives, affected requirements, safety and support constraints, cost/schedule effects, tests and approving roles. A approved drawing revision is not proof the installation changed; an installed change is not automatically accepted. Keep as-designed, as-built and accepted operational baselines linked with their dates and evidence.

## Commission the service and hand it over

Commissioning is planned verification of installed functions against requirements through the lifecycle. Factory evidence can reveal product behavior under its test conditions; site evidence verifies installed interfaces; integrated testing examines interactions and failure/recovery sequences. None automatically substitutes for all others. Define prerequisites, safe test boundaries, expected observations, data capture, abort criteria, recovery method and acceptance authority. Tests should examine the service at the consuming interface, including stale data, alarm delivery and restoration, rather than only equipment lights. Record the actual tested state and limitations, especially when loads or failure conditions are simulated.

A test that fails is useful evidence. Preserve the initial result, diagnose cause, implement an approved correction and repeat affected verification. Do not overwrite the failed record with a clean screenshot that hides the history. A waiver or conditional acceptance needs explicit consequence, restriction, owner and deadline under the site's authority model. Test completion percentage alone can mislead if the untested items include the most consequential failure state. Requirements traceability helps the receiving owner see which outcomes are demonstrated and which remain unresolved.

Handover transfers a usable capability: accepted configuration, asset identity, drawings, procedures, alarms, support, entitlements, backups, recovery evidence, training and residual restrictions. A backup file that has never been restored leaves a recovery question unanswered. A supplier account still active after commissioning leaves an access-governance question. Operations should be able to identify the current state and act within authority without relying on an installer’s memory. Warranty and support clocks, spare-part arrangements and renewal obligations need owners before the project team disperses.

Operation, maintenance, optimization, troubleshooting, incident response and recovery feed evidence back into design. A repeated failure may expose a missing requirement, weak interface or incorrect assumption. Refresh and decommissioning require their own transition plans, data disposition, capacity reconciliation and archival evidence. The nine charter lifecycle responsibilities remain connected rather than ending at installation. A strong specialist-review portfolio therefore includes requirements, calculations, interface decisions, commissioning evidence, operating records and recovery acceptance, with clear distinction between analytical study and genuinely executed vendor or field work.


#### Worked demonstrations

**The ambiguous megawatt requirement**

Synthetic training case — not a field record.

An owner requests “1 MW, highly available, ready next year.” The draft has no IT/facility boundary, growth profile or maintenance-state requirement. A supplier quotes a 1 MW nameplate UPS. The intended service is initially 600 kW IT with a committed 200 kW expansion, while cooling capability has not been established.

**Reasoning:** Define usable IT output and required operating states before accepting the equipment quote. Initial and committed demand total 800 kW, but that arithmetic does not establish cooling, distribution or resilience. Convert availability and readiness into measurable requirements with assumptions and owners.

**Feasibility assumptions with conflicting dates**

Synthetic training case — not a field record.

The target service date is 1 October. A utility email estimates supply in November but is not a firm agreement. The project schedule still shows September energization. Two telecommunications providers quote separate services, but both proposed routes enter through the same street duct. A site flood review is pending.

**Reasoning:** The schedule conflicts with current evidence. Preserve the supply uncertainty and obtain an owned resolution or approved alternative; investigate shared route exposure rather than counting provider names. A pending site-hazard review remains an open decision dependency.

**A cheaper proposal with omitted lifecycle scope**

Synthetic training case — not a field record.

Option A costs 100000 currency, uses 10 kW average auxiliary power and costs 4000/year maintenance. Option B costs 80000, uses 16 kW and costs 3000/year maintenance. Compare five years at 8000 operating hours/year and 0.10 currency/kWh, ignoring discounting and taxes. Both meet the stated service requirement, but B’s quote excludes a required 12000 controls license; A includes it.

**Reasoning:** A’s modeled five-year total is 100000+40000+20000=160000. B’s comparable total is 80000+64000+15000+12000=171000. The complete boundary reverses the capital-price preference. These are bounded undiscounted estimates; changes in hours, price, maintenance or required service can change the decision.

**A cooling permissive crossing responsibility boundaries**

Synthetic training case — not a field record.

A PLC receives a cooling-ready point from a BAS gateway. The gateway repeats its last value if communication fails. The network team promises link recovery in 200 ms, but the application can take 12 seconds to reconnect. An independent protective relay exists. A supplier proposes using the BAS display as proof that the relay’s protective function has passed.

**Reasoning:** Define source validity, age, failure behavior and end-to-end application recovery separately from link recovery. Keep independent protection owned and tested by the responsible specialist. A healthy display or link is not proof of the protective function or a fresh permissive.

**Commissioning records and an incomplete handover**

Synthetic training case — not a field record.

Factory tests passed for a UPS. At site, the normal supply test passes, but a transfer test fails and is later corrected. The original failed record is deleted. A dashboard reports 95% tests passed; the remaining 5% includes restore from backup. The night shift lacks the recovery license credentials, and a temporary installer account remains active.

**Reasoning:** Factory evidence is bounded to its conditions. Preserve failed and corrected site results, assess critical untested outcomes rather than percentage alone, and require usable recovery entitlements and access disposition for handover. Track residual items under explicit authority, not hidden closure.

#### Guided practice

Build a requirement-to-acceptance matrix for the 800 kW committed service, compare the two cost proposals and resolve the permissive and handover gaps.

**Hint:** Keep capacity boundaries, assumptions, interface ownership and acceptance evidence distinct.

**Worked solution:** Define IT output and required states; flag cooling and supply dependencies; calculate A at 160000 and B at 171000 over the supplied five years; specify stale-data behavior and end-to-end timing; preserve failed/retested records and require accessible recovery evidence before handover.

#### Independent task

Environment: analytical

Create a design-review pack that traces a service requirement through alternatives, interfaces, commissioning and operations.

**Packaged starter material**

- course_labs/CDCS/README.md
- course_labs/CDCS/fixture.json
- course_labs/CDCS/assessment_template.md
- course_labs/CDCS/lab.py
- course_labs/CDCS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- Requirements and assumptions register
- Equivalent-boundary cost calculation
- Interface control record
- Commissioning/handover evidence matrix

**Acceptance criteria**

- Every accepted claim has a defined boundary and evidence.
- Specialist approval and actual physical execution are not inferred from paper study.
- Unresolved recovery and service dependencies remain visible.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer.

#### Chapter practice

**CDCS-Q0001 · single · operations**

What must be clarified first about 1 MW?

Synthetic training case — not a field record.

An owner requests “1 MW, highly available, ready next year.” The draft has no IT/facility boundary, growth profile or maintenance-state requirement. A supplier quotes a 1 MW nameplate UPS. The intended service is initially 600 kW IT with a committed 200 kW expansion, while cooling capability has not been established.

1. Only the sum of installed UPS nameplate ratings
2. Only the current normal-state IT load
3. The capacity boundary and required operating state
4. Only the utility connection’s maximum import rating

**Correct option(s):** 3

- Option 1: Installed rating is not necessarily deliverable IT capacity under the required operating or failure state.
- Option 2: Current consumption does not define what boundary and degraded-state capacity the 1 MW requirement specifies.
- Option 3: Input, IT output and nameplate quantities are not interchangeable.
- Option 4: Utility import is an upstream quantity; losses, dependencies and required states can constrain IT delivery.

**CDCS-Q0002 · single · calculation**

What is the stated initial plus committed IT demand?

Synthetic training case — not a field record.

An owner requests “1 MW, highly available, ready next year.” The draft has no IT/facility boundary, growth profile or maintenance-state requirement. A supplier quotes a 1 MW nameplate UPS. The intended service is initially 600 kW IT with a committed 200 kW expansion, while cooling capability has not been established.

1. 600 kW
2. 1000 kW
3. 1200 kW
4. 800 kW

**Correct option(s):** 4

- Option 1: That omits the committed expansion.
- Option 2: That is the ambiguous headline target, not the stated demand sum.
- Option 3: That doubles the initial demand without basis.
- Option 4: 600 plus the committed 200 gives 800.

**CDCS-Q0003 · single · mechanism**

Why does a 1 MW UPS nameplate not establish the requested service?

Synthetic training case — not a field record.

An owner requests “1 MW, highly available, ready next year.” The draft has no IT/facility boundary, growth profile or maintenance-state requirement. A supplier quotes a 1 MW nameplate UPS. The intended service is initially 600 kW IT with a committed 200 kW expansion, while cooling capability has not been established.

1. A UPS rating never contains useful information
2. Other capacity paths, conditions and required states remain unverified
3. Cooling capacity is always numerically identical to installed UPS capacity
4. Any 1 MW component automatically supplies 1 MW IT through all failures

**Correct option(s):** 2

- Option 1: It is relevant within its specified conditions.
- Option 2: A component rating is not the complete service.
- Option 3: It needs its own load and design assessment.
- Option 4: Distribution and redundancy constraints can limit usable output.

**CDCS-Q0004 · single · operations**

Which revision makes highly available testable?

Synthetic training case — not a field record.

An owner requests “1 MW, highly available, ready next year.” The draft has no IT/facility boundary, growth profile or maintenance-state requirement. A supplier quotes a 1 MW nameplate UPS. The intended service is initially 600 kW IT with a committed 200 kW expansion, while cooling capability has not been established.

1. Require the latest equipment models only
2. Define service boundary, allowed interruptions, states and measurement method
3. Specify the largest possible battery room
4. Replace it with extremely available

**Correct option(s):** 2

- Option 1: Recency does not establish service availability.
- Option 2: The target needs observable acceptance.
- Option 3: Size alone does not define the outcome.
- Option 4: A stronger adjective does not add criteria.

**CDCS-Q0005 · single · design**

What should the design basis explain?

Synthetic training case — not a field record.

An owner requests “1 MW, highly available, ready next year.” The draft has no IT/facility boundary, growth profile or maintenance-state requirement. A supplier quotes a 1 MW nameplate UPS. The intended service is initially 600 kW IT with a committed 200 kW expansion, while cooling capability has not been established.

1. Only the owner’s initial slogan
2. How the selected architecture meets requirements and which assumptions it uses
3. Only the final equipment quantities and capital-cost schedule
4. Only a vendor product brochure

**Correct option(s):** 2

- Option 1: That does not describe the selected solution.
- Option 2: It connects outcomes to engineering decisions.
- Option 3: Quantities and cost do not show why the architecture meets functional requirements under its stated assumptions.
- Option 4: A product document omits site-wide interfaces and decisions.

**CDCS-Q0006 · single · operations**

What should qualify ready next year?

Synthetic training case — not a field record.

An owner requests “1 MW, highly available, ready next year.” The draft has no IT/facility boundary, growth profile or maintenance-state requirement. A supplier quotes a 1 MW nameplate UPS. The intended service is initially 600 kW IT with a committed 200 kW expansion, while cooling capability has not been established.

1. The expected shipment date alone
2. A dated accepted-service milestone with dependencies and commissioning scope
3. The date a contract is signed
4. The first time the UPS powers on

**Correct option(s):** 2

- Option 1: Installation, integration and acceptance may remain.
- Option 2: Readiness means more than equipment delivery.
- Option 3: Contract execution does not create operating capability.
- Option 4: One energized component does not prove the complete service.

**CDCS-Q0007 · single · implementation**

How should the unestablished cooling capability be recorded?

Synthetic training case — not a field record.

An owner requests “1 MW, highly available, ready next year.” The draft has no IT/facility boundary, growth profile or maintenance-state requirement. A supplier quotes a 1 MW nameplate UPS. The intended service is initially 600 kW IT with a committed 200 kW expansion, while cooling capability has not been established.

1. As fully available because the UPS has capacity
2. As permanently out of project scope
3. As zero risk until equipment overheats
4. An open requirement/dependency with owner and validation plan

**Correct option(s):** 4

- Option 1: Electrical capacity does not prove cooling.
- Option 2: Cooling is material to the intended data-centre service.
- Option 3: Design should resolve the dependency before service admission.
- Option 4: It can constrain admission of the load.

**CDCS-Q0008 · single · mechanism**

What distinguishes reserved growth from usable present capacity?

Synthetic training case — not a field record.

An owner requests “1 MW, highly available, ready next year.” The draft has no IT/facility boundary, growth profile or maintenance-state requirement. A supplier quotes a 1 MW nameplate UPS. The intended service is initially 600 kW IT with a committed 200 kW expansion, while cooling capability has not been established.

1. They are always the same because both appear in a plan
2. Growth reservations eliminate the need for operating margin
3. Present capacity can be inferred solely from empty racks
4. Reserved growth may depend on future installations and acceptance

**Correct option(s):** 4

- Option 1: A plan does not prove installed capacity.
- Option 2: Reservations consume planned capability rather than create it.
- Option 3: Space is only one constraint.
- Option 4: A commitment must be linked to its delivery conditions.

**CDCS-Q0009 · single · design**

What evidence should link a requirement to acceptance?

Synthetic training case — not a field record.

An owner requests “1 MW, highly available, ready next year.” The draft has no IT/facility boundary, growth profile or maintenance-state requirement. A supplier quotes a 1 MW nameplate UPS. The intended service is initially 600 kW IT with a committed 200 kW expansion, while cooling capability has not been established.

1. Only a checkbox saying discussed
2. Only the supplier’s model number
3. Only the number of drawings produced
4. The design item, verification method, result and accepting authority

**Correct option(s):** 4

- Option 1: Discussion is not implementation evidence.
- Option 2: A model cannot demonstrate every site requirement.
- Option 3: Document quantity does not prove the outcome.
- Option 4: The chain makes fulfillment reviewable.

**CDCS-Q0010 · single · operations**

What is the appropriate role of the course’s capacity arithmetic?

Synthetic training case — not a field record.

An owner requests “1 MW, highly available, ready next year.” The draft has no IT/facility boundary, growth profile or maintenance-state requirement. A supplier quotes a 1 MW nameplate UPS. The intended service is initially 600 kW IT with a committed 200 kW expansion, while cooling capability has not been established.

1. A replacement for all equipment performance curves
2. A bounded design-review calculation requiring specialist validation for implementation
3. A certified site capacity assessment
4. An authorization to change protective settings

**Correct option(s):** 2

- Option 1: The simple sum does not model operating conditions.
- Option 2: It teaches interpretation without granting field authority.
- Option 3: No physical survey or full design verification occurred.
- Option 4: No such authority follows from study.

**CDCS-Q0011 · single · operations**

What is the immediate scheduling inconsistency?

Synthetic training case — not a field record.

The target service date is 1 October. A utility email estimates supply in November but is not a firm agreement. The project schedule still shows September energization. Two telecommunications providers quote separate services, but both proposed routes enter through the same street duct. A site flood review is pending.

1. The target service date has a named month
2. Two providers have offered service
3. September energization is assumed despite a later uncommitted utility estimate
4. The schedule includes commissioning work

**Correct option(s):** 3

- Option 1: A date can be valid if dependencies support it.
- Option 2: Provider count alone is not the scheduling contradiction.
- Option 3: The plan is unsupported by the current supply evidence.
- Option 4: Commissioning belongs in a readiness plan.

**CDCS-Q0012 · single · mechanism**

What does the utility email establish?

Synthetic training case — not a field record.

The target service date is 1 October. A utility email estimates supply in November but is not a firm agreement. The project schedule still shows September energization. Two telecommunications providers quote separate services, but both proposed routes enter through the same street duct. A site flood review is pending.

1. A guaranteed November supply date
2. A complete power-system design
3. A current estimate with stated uncertainty
4. Proof that September supply is impossible under every alternative

**Correct option(s):** 3

- Option 1: The case explicitly says it is not firm.
- Option 2: A date estimate does not define the installation.
- Option 3: It is not a firm energization commitment.
- Option 4: Alternatives may exist but need review.

**CDCS-Q0013 · single · implementation**

What should an assumption register record for supply availability?

Synthetic training case — not a field record.

The target service date is 1 October. A utility email estimates supply in November but is not a firm agreement. The project schedule still shows September energization. Two telecommunications providers quote separate services, but both proposed routes enter through the same street duct. A site flood review is pending.

1. Only a note to check after service launch
2. Source, confidence, owner, validation date and consequence
3. Only the desired date
4. Only the largest available transformer rating

**Correct option(s):** 2

- Option 1: The dependency can prevent launch.
- Option 2: These make uncertainty actionable.
- Option 3: A wish does not establish its basis.
- Option 4: Capacity rating does not resolve delivery timing.

**CDCS-Q0014 · single · mechanism**

Why do two provider names not prove route diversity?

Synthetic training case — not a field record.

The target service date is 1 October. A utility email estimates supply in November but is not a firm agreement. The project schedule still shows September energization. Two telecommunications providers quote separate services, but both proposed routes enter through the same street duct. A site flood review is pending.

1. Different providers can never offer diverse routes
2. A common duct always doubles available resilience
3. Route diversity is determined only by IP addressing
4. Both services may share the same physical duct exposure

**Correct option(s):** 4

- Option 1: They can, but actual paths need evidence.
- Option 2: It introduces a shared physical dependency.
- Option 3: Logical addressing does not define civil paths.
- Option 4: Commercial separation is not physical independence.

**CDCS-Q0015 · single · operations**

What evidence best resolves the route concern?

Synthetic training case — not a field record.

The target service date is 1 October. A utility email estimates supply in November but is not a firm agreement. The project schedule still shows September energization. Two telecommunications providers quote separate services, but both proposed routes enter through the same street duct. A site flood review is pending.

1. Different provider network identifiers without physical route records
2. Different contract account numbers
3. Verified end-to-end route and shared-dependency information
4. Equal service bandwidths

**Correct option(s):** 3

- Option 1: Administrative separation does not establish duct independence.
- Option 2: Administrative identifiers do not establish route separation.
- Option 3: The review needs actual physical path evidence.
- Option 4: Capacity and path independence are separate properties.

**CDCS-Q0016 · single · design**

How should the pending flood review affect the decision?

Synthetic training case — not a field record.

The target service date is 1 October. A utility email estimates supply in November but is not a firm agreement. The project schedule still shows September energization. Two telecommunications providers quote separate services, but both proposed routes enter through the same street duct. A site flood review is pending.

1. Treat no completed report as proof of no flood exposure
2. Move the issue to IT application testing
3. Reject every site near any water without assessment
4. Keep the relevant site-hazard acceptance open until evaluated

**Correct option(s):** 4

- Option 1: Missing evidence is not a clean result.
- Option 2: That would not resolve the physical site concern.
- Option 3: The decision requires defined hazards and criteria.
- Option 4: An unreviewed hazard cannot be assumed absent.

**CDCS-Q0017 · single · operations**

When would the supply dependency become a realized issue?

Synthetic training case — not a field record.

The target service date is 1 October. A utility email estimates supply in November but is not a firm agreement. The project schedule still shows September energization. Two telecommunications providers quote separate services, but both proposed routes enter through the same street duct. A site flood review is pending.

1. Never, because utilities are outside the project
2. Only after the first customer outage
3. As soon as any uncertain date is written down
4. When an adverse condition occurs, such as a missed committed delivery milestone

**Correct option(s):** 4

- Option 1: External dependencies can create project issues.
- Option 2: Project blockers can occur before operation.
- Option 3: Uncertainty alone is not necessarily a realized adverse event.
- Option 4: A risk concerns uncertainty; an issue records an occurred condition.

**CDCS-Q0018 · single · operations**

What must an alternative temporary supply proposal assess?

Synthetic training case — not a field record.

The target service date is 1 October. A utility email estimates supply in November but is not a firm agreement. The project schedule still shows September energization. Two telecommunications providers quote separate services, but both proposed routes enter through the same street duct. A site flood review is pending.

1. Only whether its nameplate equals the target megawatts
2. Only whether it avoids updating the schedule
3. Only whether it can be delivered before October
4. Capacity, support, safety, approvals, operating constraints and transition

**Correct option(s):** 4

- Option 1: Other conditions and interfaces matter.
- Option 2: Preserving a date is not a technical acceptance criterion.
- Option 3: Timing alone does not establish suitability.
- Option 4: An alternative must meet the required service boundary.

**CDCS-Q0019 · single · operations**

Which status statement is defensible now?

Synthetic training case — not a field record.

The target service date is 1 October. A utility email estimates supply in November but is not a firm agreement. The project schedule still shows September energization. Two telecommunications providers quote separate services, but both proposed routes enter through the same street duct. A site flood review is pending.

1. The target depends on unresolved supply, route and hazard evidence
2. All feasibility items passed because quotes exist
3. The site is definitely unsuitable
4. No uncertainty remains if contingency is mentioned

**Correct option(s):** 1

- Option 1: It accurately identifies what blocks confidence.
- Option 2: Quotes do not settle every requirement.
- Option 3: The evidence shows unresolved matters, not a complete rejection basis.
- Option 4: A named contingency needs actual feasibility and authority.

**CDCS-Q0020 · single · operations**

Who should accept a changed service-date or risk commitment?

Synthetic training case — not a field record.

The target service date is 1 October. A utility email estimates supply in November but is not a firm agreement. The project schedule still shows September energization. Two telecommunications providers quote separate services, but both proposed routes enter through the same street duct. A site flood review is pending.

1. The first operator assigned to the night shift
2. Any supplier independently on behalf of the owner
3. The designated owner with the relevant technical and commercial evidence
4. The schedule software automatically

**Correct option(s):** 3

- Option 1: That role has no stated authority over the project commitment.
- Option 2: Supplier statements do not confer owner authority.
- Option 3: Project staff cannot silently alter the business promise.
- Option 4: Software calculates dates but does not accept business risk.

**CDCS-Q0021 · single · calculation**

What is A’s annual auxiliary energy?

Synthetic training case — not a field record.

Option A costs 100000 currency, uses 10 kW average auxiliary power and costs 4000/year maintenance. Option B costs 80000, uses 16 kW and costs 3000/year maintenance. Compare five years at 8000 operating hours/year and 0.10 currency/kWh, ignoring discounting and taxes. Both meet the stated service requirement, but B’s quote excludes a required 12000 controls license; A includes it.

1. 80000 kWh
2. 10 kWh
3. 8000 kWh
4. 800000 kWh

**Correct option(s):** 1

- Option 1: 10 kW times 8000 hours gives 80000.
- Option 2: Power alone is not annual energy.
- Option 3: That omits the 10 kW factor.
- Option 4: That introduces a factor-of-ten error.

**CDCS-Q0022 · single · calculation**

What is B’s annual energy charge?

Synthetic training case — not a field record.

Option A costs 100000 currency, uses 10 kW average auxiliary power and costs 4000/year maintenance. Option B costs 80000, uses 16 kW and costs 3000/year maintenance. Compare five years at 8000 operating hours/year and 0.10 currency/kWh, ignoring discounting and taxes. Both meet the stated service requirement, but B’s quote excludes a required 12000 controls license; A includes it.

1. 3000 currency
2. 1600 currency
3. 64000 currency
4. 12800 currency

**Correct option(s):** 4

- Option 1: That is annual maintenance, not energy.
- Option 2: That does not apply the supplied operating duration correctly.
- Option 3: That is the five-year energy charge.
- Option 4: 16 × 8000 × 0.10 equals 12800.

**CDCS-Q0023 · single · calculation**

What is A’s five-year modeled total?

Synthetic training case — not a field record.

Option A costs 100000 currency, uses 10 kW average auxiliary power and costs 4000/year maintenance. Option B costs 80000, uses 16 kW and costs 3000/year maintenance. Compare five years at 8000 operating hours/year and 0.10 currency/kWh, ignoring discounting and taxes. Both meet the stated service requirement, but B’s quote excludes a required 12000 controls license; A includes it.

1. 120000 currency
2. 160000 currency
3. 200000 currency
4. 140000 currency

**Correct option(s):** 2

- Option 1: That omits energy.
- Option 2: Capital 100000 plus energy 40000 plus maintenance 20000.
- Option 3: That is not the sum of the supplied cost terms.
- Option 4: That omits maintenance.

**CDCS-Q0024 · single · calculation**

What is B’s equivalent five-year total including the license?

Synthetic training case — not a field record.

Option A costs 100000 currency, uses 10 kW average auxiliary power and costs 4000/year maintenance. Option B costs 80000, uses 16 kW and costs 3000/year maintenance. Compare five years at 8000 operating hours/year and 0.10 currency/kWh, ignoring discounting and taxes. Both meet the stated service requirement, but B’s quote excludes a required 12000 controls license; A includes it.

1. 92000 currency
2. 183000 currency
3. 159000 currency
4. 171000 currency

**Correct option(s):** 4

- Option 1: That includes only capital and license.
- Option 2: That counts the license twice.
- Option 3: That omits the required controls license.
- Option 4: 80000+64000+15000+12000 gives 171000.

**CDCS-Q0025 · single · operations**

Which option has lower cost within this supplied model?

Synthetic training case — not a field record.

Option A costs 100000 currency, uses 10 kW average auxiliary power and costs 4000/year maintenance. Option B costs 80000, uses 16 kW and costs 3000/year maintenance. Compare five years at 8000 operating hours/year and 0.10 currency/kWh, ignoring discounting and taxes. Both meet the stated service requirement, but B’s quote excludes a required 12000 controls license; A includes it.

1. B by 20000 currency
2. A by 11000 currency
3. They are equal because both meet the service requirement
4. B by 1000 currency

**Correct option(s):** 2

- Option 1: That compares only the initial equipment price.
- Option 2: 171000 minus 160000 gives the modeled difference.
- Option 3: Equivalent function does not imply equal cost.
- Option 4: That is not the complete five-year difference.

**CDCS-Q0026 · single · mechanism**

Why is this not a discounted cash-flow result?

Synthetic training case — not a field record.

Option A costs 100000 currency, uses 10 kW average auxiliary power and costs 4000/year maintenance. Option B costs 80000, uses 16 kW and costs 3000/year maintenance. Compare five years at 8000 operating hours/year and 0.10 currency/kWh, ignoring discounting and taxes. Both meet the stated service requirement, but B’s quote excludes a required 12000 controls license; A includes it.

1. Five-year calculations are always discounted automatically
2. Energy charges cannot be discounted
3. Capital expenditure is absent
4. No discount rate or time-value calculation is included

**Correct option(s):** 4

- Option 1: Duration alone does not apply discounting.
- Option 2: Future cash flows can be discounted under a stated model.
- Option 3: Both initial costs are included.
- Option 4: The case explicitly uses an undiscounted comparison.

**CDCS-Q0027 · single · operations**

What sensitivity would directly test the energy-cost assumption?

Synthetic training case — not a field record.

Option A costs 100000 currency, uses 10 kW average auxiliary power and costs 4000/year maintenance. Option B costs 80000, uses 16 kW and costs 3000/year maintenance. Compare five years at 8000 operating hours/year and 0.10 currency/kWh, ignoring discounting and taxes. Both meet the stated service requirement, but B’s quote excludes a required 12000 controls license; A includes it.

1. Recalculate using plausible operating hours and electricity prices
2. Remove maintenance from both options without explanation
3. Assume the lower-capital option always wins
4. Change only the option labels

**Correct option(s):** 1

- Option 1: Those inputs govern the energy term.
- Option 2: That changes the boundary rather than tests the energy assumption.
- Option 3: That avoids analysis.
- Option 4: Labels do not alter cost behavior.

**CDCS-Q0028 · single · design**

What should happen if B later fails a mandatory service criterion?

Synthetic training case — not a field record.

Option A costs 100000 currency, uses 10 kW average auxiliary power and costs 4000/year maintenance. Option B costs 80000, uses 16 kW and costs 3000/year maintenance. Compare five years at 8000 operating hours/year and 0.10 currency/kWh, ignoring discounting and taxes. Both meet the stated service requirement, but B’s quote excludes a required 12000 controls license; A includes it.

1. Treat it as nonequivalent until the requirement is met or legitimately revised
2. Delete the criterion from the comparison silently
3. Average the two service levels to declare compliance
4. Select it anyway because initial capital is lower

**Correct option(s):** 1

- Option 1: A price comparison cannot waive a mandatory outcome.
- Option 2: That misrepresents equivalence.
- Option 3: Each selected solution must meet its requirements.
- Option 4: Cost does not override the stated requirement.

**CDCS-Q0029 · single · operations**

What procurement question resolves the license omission?

Synthetic training case — not a field record.

Option A costs 100000 currency, uses 10 kW average auxiliary power and costs 4000/year maintenance. Option B costs 80000, uses 16 kW and costs 3000/year maintenance. Compare five years at 8000 operating hours/year and 0.10 currency/kWh, ignoring discounting and taxes. Both meet the stated service requirement, but B’s quote excludes a required 12000 controls license; A includes it.

1. Ask only whether the hardware ships with a sticker
2. Assume the license is optional because omitted
3. Confirm required entitlement, scope, support and renewal terms in the comparable offer
4. Use an unrelated product’s license estimate as final

**Correct option(s):** 3

- Option 1: That does not establish software rights or functionality.
- Option 2: The case states it is required.
- Option 3: The missing item may affect both cost and operation.
- Option 4: The actual supported solution needs confirmed terms.

**CDCS-Q0030 · single · operations**

How should the conclusion be reported?

Synthetic training case — not a field record.

Option A costs 100000 currency, uses 10 kW average auxiliary power and costs 4000/year maintenance. Option B costs 80000, uses 16 kW and costs 3000/year maintenance. Compare five years at 8000 operating hours/year and 0.10 currency/kWh, ignoring discounting and taxes. Both meet the stated service requirement, but B’s quote excludes a required 12000 controls license; A includes it.

1. B is fraudulent because its base quote excludes an item
2. A is cheaper under the declared five-year assumptions and complete scope
3. A is always cheaper in every site and operating profile
4. The model proves lower environmental impact in every category

**Correct option(s):** 2

- Option 1: An exclusion needs clarification; intent is not established.
- Option 2: The boundary and assumptions limit the result.
- Option 3: Different inputs can change the result.
- Option 4: Cost does not measure all environmental effects.

**CDCS-Q0031 · single · diagnosis**

What is the central defect in repeating the last ready value without quality?

Synthetic training case — not a field record.

A PLC receives a cooling-ready point from a BAS gateway. The gateway repeats its last value if communication fails. The network team promises link recovery in 200 ms, but the application can take 12 seconds to reconnect. An independent protective relay exists. A supplier proposes using the BAS display as proof that the relay’s protective function has passed.

1. A Boolean value does not need a source
2. Consumers can mistake stale readiness for current process state
3. Caching can never be useful
4. A gateway automatically verifies the physical plant every scan

**Correct option(s):** 2

- Option 1: Even a simple permissive has an origin and freshness requirement.
- Option 2: The cached value needs explicit validity and age semantics.
- Option 3: It can support history or continuity when correctly labeled.
- Option 4: Repeating data does not establish a new observation.

**CDCS-Q0032 · single · operations**

What must the interface contract define for communication loss?

Synthetic training case — not a field record.

A PLC receives a cooling-ready point from a BAS gateway. The gateway repeats its last value if communication fails. The network team promises link recovery in 200 ms, but the application can take 12 seconds to reconnect. An independent protective relay exists. A supplier proposes using the BAS display as proof that the relay’s protective function has passed.

1. Only the gateway’s normal polling interval
2. Only the Ethernet port speed
3. Only the last valid Boolean value with no quality or expiry
4. Quality, timeout and authorized downstream behavior

**Correct option(s):** 4

- Option 1: The normal interval does not define loss timeout or downstream action.
- Option 2: Link speed does not establish application validity.
- Option 3: The consumer cannot distinguish a current permissive from cached data.
- Option 4: The consuming control needs a specified response to unavailable evidence.

**CDCS-Q0033 · single · recovery**

What does observed 200 ms link recovery establish?

Synthetic training case — not a field record.

A PLC receives a cooling-ready point from a BAS gateway. The gateway repeats its last value if communication fails. The network team promises link recovery in 200 ms, but the application can take 12 seconds to reconnect. An independent protective relay exists. A supplier proposes using the BAS display as proof that the relay’s protective function has passed.

1. A guaranteed 200 ms fresh permissive at the PLC
2. That link recovery milestone under the test conditions
3. That independent protection is now unnecessary
4. That the 12-second application delay cannot occur

**Correct option(s):** 2

- Option 1: The application reconnects separately.
- Option 2: It does not prove the application recovered at the same time.
- Option 3: Network recovery does not replace protective functions.
- Option 4: The supplied evidence says it can.

**CDCS-Q0034 · single · design**

Which acceptance should cover the 12-second reconnect behavior?

Synthetic training case — not a field record.

A PLC receives a cooling-ready point from a BAS gateway. The gateway repeats its last value if communication fails. The network team promises link recovery in 200 ms, but the application can take 12 seconds to reconnect. An independent protective relay exists. A supplier proposes using the BAS display as proof that the relay’s protective function has passed.

1. Only a physical cable continuity check
2. Only a switch reboot completion timestamp
3. End-to-end application data validity and consumer response
4. Only a BAS login screen test

**Correct option(s):** 3

- Option 1: Continuity does not measure application reconnection.
- Option 2: The source-to-consumer service has additional stages.
- Option 3: It tests the operational interface beyond the link.
- Option 4: Login does not prove the permissive’s timing and semantics.

**CDCS-Q0035 · single · mechanism**

Why is a normal BAS display insufficient to accept the protective relay?

Synthetic training case — not a field record.

A PLC receives a cooling-ready point from a BAS gateway. The gateway repeats its last value if communication fails. The network team promises link recovery in 200 ms, but the application can take 12 seconds to reconnect. An independent protective relay exists. A supplier proposes using the BAS display as proof that the relay’s protective function has passed.

1. Supervisory indication does not execute or verify the independent protective function
2. A BAS can never display relay information
3. The relay is automatically redundant when monitored
4. The gateway’s model determines all relay settings

**Correct option(s):** 1

- Option 1: Separate authority and tests remain.
- Option 2: It can display information without proving protection.
- Option 3: Monitoring does not create protective redundancy.
- Option 4: Protection settings require their own design basis.

**CDCS-Q0036 · single · operations**

Who should own protective-setting approval?

Synthetic training case — not a field record.

A PLC receives a cooling-ready point from a BAS gateway. The gateway repeats its last value if communication fails. The network team promises link recovery in 200 ms, but the application can take 12 seconds to reconnect. An independent protective relay exists. A supplier proposes using the BAS display as proof that the relay’s protective function has passed.

1. The designated competent protection specialist under site authority
2. The network engineer solely because packets carry relay data
3. Any learner who passes this question
4. The dashboard designer because the status is visible there

**Correct option(s):** 1

- Option 1: Integration review does not transfer that responsibility.
- Option 2: Transport responsibility is not protection design authority.
- Option 3: Study does not confer field authorization.
- Option 4: Display ownership is a different scope.

**CDCS-Q0037 · single · operations**

What should a source-age test preserve?

Synthetic training case — not a field record.

A PLC receives a cooling-ready point from a BAS gateway. The gateway repeats its last value if communication fails. The network team promises link recovery in 200 ms, but the application can take 12 seconds to reconnect. An independent protective relay exists. A supplier proposes using the BAS display as proof that the relay’s protective function has passed.

1. Source and consumer timestamps, clock assumptions, quality and observed behavior
2. Only the consumer screenshot time
3. Only a successful ping
4. Only the source device’s serial number

**Correct option(s):** 1

- Option 1: These support the end-to-end timing conclusion.
- Option 2: That may show a recently rendered old value.
- Option 3: Reachability does not prove fresh application data.
- Option 4: Identity alone does not establish timing.

**CDCS-Q0038 · single · diagnosis**

What should the PLC do on stale readiness?

Synthetic training case — not a field record.

A PLC receives a cooling-ready point from a BAS gateway. The gateway repeats its last value if communication fails. The network team promises link recovery in 200 ms, but the application can take 12 seconds to reconnect. An independent protective relay exists. A supplier proposes using the BAS display as proof that the relay’s protective function has passed.

1. Always apply a universal emergency-stop rule invented by the integrator
2. Ignore age because Ethernet has checksums
3. Follow the reviewed control narrative and independent safety/protection constraints
4. Always force ready true to avoid interruption

**Correct option(s):** 3

- Option 1: No site-independent rule is established here.
- Option 2: Frame integrity does not guarantee freshness.
- Option 3: The correct response depends on the designed process.
- Option 4: That can authorize action without valid evidence.

**CDCS-Q0039 · single · implementation**

What should be recorded if the gateway firmware changes timeout behavior?

Synthetic training case — not a field record.

A PLC receives a cooling-ready point from a BAS gateway. The gateway repeats its last value if communication fails. The network team promises link recovery in 200 ms, but the application can take 12 seconds to reconnect. An independent protective relay exists. A supplier proposes using the BAS display as proof that the relay’s protective function has passed.

1. A controlled interface change with affected tests and approvals
2. Reuse the prior acceptance because normal-state values still match
3. Only an updated firmware version in the asset inventory
4. No change because the IP address is unchanged

**Correct option(s):** 1

- Option 1: Behavioral changes can alter operating consequences.
- Option 2: The timeout change affects failure behavior beyond normal values.
- Option 3: Version traceability is necessary but does not assess or accept the changed timeout behavior.
- Option 4: Address continuity does not preserve application behavior.

**CDCS-Q0040 · single · operations**

Which commissioning result would be strongest for this interface?

Synthetic training case — not a field record.

A PLC receives a cooling-ready point from a BAS gateway. The gateway repeats its last value if communication fails. The network team promises link recovery in 200 ms, but the application can take 12 seconds to reconnect. An independent protective relay exists. A supplier proposes using the BAS display as proof that the relay’s protective function has passed.

1. A single normal-state reading with no timestamps
2. A bounded loss/recovery test showing source quality through gateway and PLC response
3. A supplier statement that all network products are fast
4. A protective relay certificate used as a substitute for gateway testing

**Correct option(s):** 2

- Option 1: It omits the failure and recovery requirement.
- Option 2: It follows the complete required path.
- Option 3: A generic statement lacks site evidence.
- Option 4: Different functions need their own evidence.

**CDCS-Q0041 · single · mechanism**

What does the factory pass establish?

Synthetic training case — not a field record.

Factory tests passed for a UPS. At site, the normal supply test passes, but a transfer test fails and is later corrected. The original failed record is deleted. A dashboard reports 95% tests passed; the remaining 5% includes restore from backup. The night shift lacks the recovery license credentials, and a temporary installer account remains active.

1. All site transfer paths are accepted
2. The tested product behavior under the recorded factory conditions
3. The night shift has usable recovery access
4. Every future configuration is validated

**Correct option(s):** 2

- Option 1: The site test later failed.
- Option 2: It does not prove every installed site interface.
- Option 3: Factory function tests do not establish site credentials.
- Option 4: Changes require assessment.

**CDCS-Q0042 · single · mechanism**

Why preserve the initial failed transfer record?

Synthetic training case — not a field record.

Factory tests passed for a UPS. At site, the normal supply test passes, but a transfer test fails and is later corrected. The original failed record is deleted. A dashboard reports 95% tests passed; the remaining 5% includes restore from backup. The night shift lacks the recovery license credentials, and a temporary installer account remains active.

1. It explains the defect, correction and retest history
2. Because every failure proves permanent design invalidity
3. To replace the corrected retest result
4. To prevent any corrected system from ever being accepted

**Correct option(s):** 1

- Option 1: Deletion removes important acceptance evidence.
- Option 2: Some failures are correctable.
- Option 3: Both records serve different parts of the evidence chain.
- Option 4: A controlled correction and retest can support acceptance.

**CDCS-Q0043 · single · mechanism**

Why is 95% passed not enough for an acceptance decision?

Synthetic training case — not a field record.

Factory tests passed for a UPS. At site, the normal supply test passes, but a transfer test fails and is later corrected. The original failed record is deleted. A dashboard reports 95% tests passed; the remaining 5% includes restore from backup. The night shift lacks the recovery license credentials, and a temporary installer account remains active.

1. The untested fraction can include critical required functions
2. Percentages can never help report progress
3. The remaining tests are automatically minor
4. A high percentage guarantees all failure states passed

**Correct option(s):** 1

- Option 1: Count does not represent consequence or coverage.
- Option 2: They can help when paired with scope and significance.
- Option 3: The case includes recovery.
- Option 4: It does not identify which tests remain.

**CDCS-Q0044 · single · recovery**

What must a backup restore test demonstrate?

Synthetic training case — not a field record.

Factory tests passed for a UPS. At site, the normal supply test passes, but a transfer test fails and is later corrected. The original failed record is deleted. A dashboard reports 95% tests passed; the remaining 5% includes restore from backup. The night shift lacks the recovery license credentials, and a temporary installer account remains active.

1. Only that the backup job reports successful completion
2. Only the original installer can log in
3. Only that normal operation never stopped during installation
4. Restoration of the required service with dependencies and acceptance evidence

**Correct option(s):** 4

- Option 1: A completed job does not demonstrate that the captured set can restore the required service and dependencies.
- Option 2: Operational recovery must be usable by authorized receiving roles.
- Option 3: That is a different outcome.
- Option 4: A backup file alone does not prove usable recovery.

**CDCS-Q0045 · single · recovery**

Why are missing recovery credentials a handover issue?

Synthetic training case — not a field record.

Factory tests passed for a UPS. At site, the normal supply test passes, but a transfer test fails and is later corrected. The original failed record is deleted. A dashboard reports 95% tests passed; the remaining 5% includes restore from backup. The night shift lacks the recovery license credentials, and a temporary installer account remains active.

1. The authorized shift cannot use a required recovery dependency
2. Recovery licenses never affect restoration
3. Credentials should be shared publicly to avoid delays
4. The project team can assume permanent availability

**Correct option(s):** 1

- Option 1: Documentation without access may be unusable during an incident.
- Option 2: The case identifies them as required.
- Option 3: Access must remain controlled.
- Option 4: Handover should not depend on unspecified personal support.

**CDCS-Q0046 · single · operations**

What should happen to the installer account?

Synthetic training case — not a field record.

Factory tests passed for a UPS. At site, the normal supply test passes, but a transfer test fails and is later corrected. The original failed record is deleted. A dashboard reports 95% tests passed; the remaining 5% includes restore from backup. The night shift lacks the recovery license credentials, and a temporary installer account remains active.

1. Remove it or explicitly reauthorize a bounded operational purpose
2. Keep it permanently because the supplier is trusted
3. Give all operators the same installer password
4. Delete its audit history when deleting the account

**Correct option(s):** 1

- Option 1: Temporary access should not persist without need and owner.
- Option 2: Trust does not replace lifecycle authorization.
- Option 3: That weakens accountability and privilege control.
- Option 4: Records may need retention independently of access removal.

**CDCS-Q0047 · single · design**

What should conditional acceptance include if site policy permits it?

Synthetic training case — not a field record.

Factory tests passed for a UPS. At site, the normal supply test passes, but a transfer test fails and is later corrected. The original failed record is deleted. A dashboard reports 95% tests passed; the remaining 5% includes restore from backup. The night shift lacks the recovery license credentials, and a temporary installer account remains active.

1. A promise to test whenever convenient with no owner
2. An automatic waiver of all untested recovery requirements
3. Only the phrase accepted with comments
4. Residual consequence, restriction, owner, deadline and approving authority

**Correct option(s):** 4

- Option 1: That is not controlled closure.
- Option 2: A bounded disposition is not a blanket waiver.
- Option 3: That does not define the operating constraint.
- Option 4: The incomplete outcome stays visible and governed.

**CDCS-Q0048 · single · mechanism**

What is the difference between as-built and accepted?

Synthetic training case — not a field record.

Factory tests passed for a UPS. At site, the normal supply test passes, but a transfer test fails and is later corrected. The original failed record is deleted. A dashboard reports 95% tests passed; the remaining 5% includes restore from backup. The night shift lacks the recovery license credentials, and a temporary installer account remains active.

1. Accepted drawings never need updating
2. As-built records apply only before construction starts
3. As-built describes installation; acceptance records satisfaction of criteria
4. They always mean the same thing

**Correct option(s):** 3

- Option 1: Later changes can alter the baseline.
- Option 2: They describe what was actually installed.
- Option 3: Installed state can still contain unaccepted defects.
- Option 4: Installation alone does not prove service behavior.

**CDCS-Q0049 · single · design**

What should operations feed back into design?

Synthetic training case — not a field record.

Factory tests passed for a UPS. At site, the normal supply test passes, but a transfer test fails and is later corrected. The original failed record is deleted. A dashboard reports 95% tests passed; the remaining 5% includes restore from backup. The night shift lacks the recovery license credentials, and a temporary installer account remains active.

1. Only incidents that caused public complaints
2. Recurring failures, maintenance constraints and recovery evidence
3. No feedback after final payment
4. Only the original procurement price

**Correct option(s):** 2

- Option 1: Other significant failures and near misses can matter.
- Option 2: Lifecycle experience can reveal deficient assumptions or interfaces.
- Option 3: Payment does not end the engineering lifecycle.
- Option 4: Operating evidence has broader design implications.

**CDCS-Q0050 · single · operations**

What must a later decommissioning plan include?

Synthetic training case — not a field record.

Factory tests passed for a UPS. At site, the normal supply test passes, but a transfer test fails and is later corrected. The original failed record is deleted. A dashboard reports 95% tests passed; the remaining 5% includes restore from backup. The night shift lacks the recovery license credentials, and a temporary installer account remains active.

1. Service transition, physical status, data disposition, capacity and retained records
2. Only canceling the maintenance contract
3. Only turning off the equipment without dependency review
4. Only deleting the device from the dashboard

**Correct option(s):** 1

- Option 1: Retirement spans several controlled responsibilities.
- Option 2: Contract closure does not prove safe or complete retirement.
- Option 3: Other services may rely on it.
- Option 4: A display change does not remove physical or data obligations.

#### Recall

**The ambiguous megawatt requirement — Synthetic training case — not a field record.

An owner requests “1 MW, highly available, ready next year.” The draft has no IT/facility boundary, growth profile or maintenance-state requirement. A supplier quotes a 1 MW nameplate UPS. The intended service is initially 600 kW IT with a committed 200 kW expansion, while cooling capability has not been established.**

Define usable IT output and required operating states before accepting the equipment quote. Initial and committed demand total 800 kW, but that arithmetic does not establish cooling, distribution or resilience. Convert availability and readiness into measurable requirements with assumptions and owners.

**Feasibility assumptions with conflicting dates — Synthetic training case — not a field record.

The target service date is 1 October. A utility email estimates supply in November but is not a firm agreement. The project schedule still shows September energization. Two telecommunications providers quote separate services, but both proposed routes enter through the same street duct. A site flood review is pending.**

The schedule conflicts with current evidence. Preserve the supply uncertainty and obtain an owned resolution or approved alternative; investigate shared route exposure rather than counting provider names. A pending site-hazard review remains an open decision dependency.

**A cheaper proposal with omitted lifecycle scope — Synthetic training case — not a field record.

Option A costs 100000 currency, uses 10 kW average auxiliary power and costs 4000/year maintenance. Option B costs 80000, uses 16 kW and costs 3000/year maintenance. Compare five years at 8000 operating hours/year and 0.10 currency/kWh, ignoring discounting and taxes. Both meet the stated service requirement, but B’s quote excludes a required 12000 controls license; A includes it.**

A’s modeled five-year total is 100000+40000+20000=160000. B’s comparable total is 80000+64000+15000+12000=171000. The complete boundary reverses the capital-price preference. These are bounded undiscounted estimates; changes in hours, price, maintenance or required service can change the decision.

**A cooling permissive crossing responsibility boundaries — Synthetic training case — not a field record.

A PLC receives a cooling-ready point from a BAS gateway. The gateway repeats its last value if communication fails. The network team promises link recovery in 200 ms, but the application can take 12 seconds to reconnect. An independent protective relay exists. A supplier proposes using the BAS display as proof that the relay’s protective function has passed.**

Define source validity, age, failure behavior and end-to-end application recovery separately from link recovery. Keep independent protection owned and tested by the responsible specialist. A healthy display or link is not proof of the protective function or a fresh permissive.

**Commissioning records and an incomplete handover — Synthetic training case — not a field record.

Factory tests passed for a UPS. At site, the normal supply test passes, but a transfer test fails and is later corrected. The original failed record is deleted. A dashboard reports 95% tests passed; the remaining 5% includes restore from backup. The night shift lacks the recovery license credentials, and a temporary installer account remains active.**

Factory evidence is bounded to its conditions. Preserve failed and corrected site results, assess critical untested outcomes rather than percentage alone, and require usable recovery entitlements and access disposition for handover. Track residual items under explicit authority, not hidden closure.

#### References

- [EPI CDCS public syllabus](https://www.epi-ap.com/services/1/3/5)

## CDCS-M02 — Capacity redundancy, maintainability and bounded resilience claims

### CDCS-L02 — Capacity redundancy, maintainability and bounded resilience claims

Estimated study time: 120 minutes before independent work. Prerequisite chapters: CDCS-L01

## Read resilience claims as testable system properties

Rating schemes organize expectations for data-centre infrastructure, but their labels, scopes, editions and assessment processes are not interchangeable. A project should name the scheme and edition it intends to satisfy, the relevant scope and the evidence required. A designer's self-description, a reviewed design and a verified constructed facility are different claims. Do not attach a scheme's formal certification to a site because one drawing contains a familiar redundancy symbol. This chapter teaches the engineering distinctions in the public CDCS outline; exact normative requirements and formal certification decisions remain with the applicable scheme and competent assessors.

Begin with the service boundary and load. N is the capacity required to support that defined load under the stated conditions. For identical units, a simple quantity model divides required load by usable per-unit capacity and rounds up. If load is 250 kW and each unit supplies 100 kW in the relevant condition, N is three. Four installed units provide one additional unit in that model. This does not establish distribution-path redundancy, control independence, maintenance isolation or response to every failure. Derating, ambient conditions, load sharing, startup transients and support dependencies can invalidate a nameplate-only calculation.

Capacity redundancy and path redundancy answer different questions. Additional capacity components can survive a unit loss while a common output bus still interrupts all loads. Two complete paths can remain dependent on the same upstream source, room hazard, control supply or transfer mechanism. A dual-corded server connected twice to the same rack PDU does not gain independent power paths from the second cord. Draw the end-to-end chain from source through conversion, switching, distribution and the consuming equipment. Include the return, control and auxiliary services needed for the chain to work.

## Examine normal, maintenance, failure and recovery states

A normal-state calculation is only the first row of a state matrix. Identify credible maintenance isolations and failure events according to the design basis. For each state, calculate available capacity, route connectivity, isolation boundaries, control behavior, load effects and recovery conditions. A design may carry load after one component loss but lack enough capacity for a second unavailable component during maintenance. State the claimed condition precisely. “One spare” is not a promise of unlimited simultaneous faults, and an operational restriction can be necessary until the unavailable component is restored.

Concurrent maintainability concerns performing the required maintenance on relevant capacity components and distribution paths without interrupting the defined critical service, within the applicable criteria. It depends on isolation and remaining service capability as well as component count. A valve or breaker placed so that maintaining it interrupts both alternatives can defeat the intended result. Review service clearances, lifting/removal paths, access to isolation points, temporary operating states and the procedures needed to establish them. An alternative path that exists on paper but cannot be safely or practically placed in service does not establish maintainability.

Fault tolerance concerns response to specified unplanned failures while preserving the required service. A planned transfer under controlled conditions can pass even when an abrupt fault produces a different transient or propagation path. Distinguish the event, detection, isolation, transfer and consuming-equipment response. Selectivity and compartmentalization can limit how far a fault propagates; common controls or a shared fuel system can defeat independent-looking equipment. Claims require the actual applicable fault set and criteria, not an invented universal guarantee against every conceivable event. Do not equate a rating label with a contractual uptime percentage or a forecast of observed annual outages.

Recovery completes the state model. Once a failed component is repaired, the system must return to an accepted configuration without creating a new interruption or hidden mismatch. Check synchronization where relevant, load redistribution, alarms, protection, control mode and records. A restored status bit is not sufficient if the alternate path remains isolated or a temporary override remains active. Operational procedures should identify who authorizes each transition and what evidence verifies it. This course reviews the logic on supplied diagrams and data; it does not instruct a learner to operate energized equipment.

## Distributed redundancy and transfer constraints

Distributed redundant arrangements share spare capability among blocks or loads rather than assigning every load a dedicated complete duplicate. They can use capacity efficiently, but the post-failure distribution must be calculated. Three blocks each rated 200 kW and each carrying 150 kW have 600 kW installed for 450 kW load. Losing one block leaves 400 kW, so no redistribution can carry all 450 kW within those ratings. The 150 kW failed load split equally adds 75 kW to each survivor, taking them to 225 kW. Installed spare capacity in aggregate is not the same as usable capacity after the particular loss.

Even when aggregate surviving capacity is adequate, topology can restrict which loads can reach it. A transfer switch, bus section or cable may have a lower limit; a load may have only one eligible alternate; control coordination may prohibit a proposed state. Analyze both the capacity inequalities and the connectivity constraints. A spare block that serves several loads must have an admission rule so simultaneous transfers do not exceed its supported capability. Record whether overload behavior is continuous, time-limited or unavailable; do not silently use a short-duration overload rating as permanent capacity.

Maintenance changes the distributed model. If one block is isolated for work, the remaining arrangement may have no further spare capacity. The operating decision should identify the exposure, permitted load, duration, restrictions and restoration plan. Scheduling simultaneous work on apparently separate equipment can create a shared loss state. Coordinate electrical, mechanical, controls and network maintenance through the service dependency model. A cooling system's redundancy cannot be assessed independently of the electrical supply and control services it needs.

## Upstream supply, substations and common causes

Two utility feeds are not automatically independent. Ask where they originate, which substation and bus sections they share, whether cable routes converge, what protection and control dependencies exist, and how maintenance or a regional event affects them. A separate cable entry does not prove separate upstream supply; separate substations do not eliminate every regional hazard. Record the actual evidence and its limits. Utility information may be constrained, so unresolved independence should remain a stated assumption rather than being converted into a fact.

Substation interfaces include capacity, protection coordination, earthing arrangements, switching responsibilities, metering, communications, physical separation, access and maintenance. The responsible specialists and utility define the applicable design and operating requirements. The integration engineer should verify that EPMS indications, time synchronization, alarms and records accurately represent the accepted arrangement without taking ownership of protective design. The distinction matters when a dashboard says two sources available while a shared upstream breaker has isolated both supply paths.

Common-cause review asks which single event can defeat several nominal alternatives. Examples include shared control power, flood exposure, cooling-water supply, fuel contamination, software changes and a common maintenance error. Diversity can reduce some shared mechanisms while introducing integration complexity; it is not automatically better in every respect. Evidence should address the identified mechanism, such as physically separated routing or independently supplied controls, rather than merely counting different vendor logos. Keep the review tied to the required service and defined failure scenarios.

## Prove the claim at the correct scope

Create a resilience evidence matrix with one row per required state or event. Identify initial state, unavailable components, expected remaining path/capacity, transition behavior, observation points, acceptance threshold, actual result and residual limits. Use a diagram to support reasoning, calculations to test capacity and authorized demonstrations to establish actual behavior. Where a test is simulated, explain which physical effects were not reproduced. An emulator cannot establish breaker clearing time, thermal transients or a real fuel-system dependency.

Formal review should reconcile drawings, installed labels, operating procedures and tested configuration. A certificate or assessment for one phase or scope should not be extended to unassessed additions. A later expansion can change load, isolation or common dependencies; preserve change control and reassess affected claims. A credible report can state that a supplied capacity model passes one-unit loss while the distribution-path review remains open. That bounded conclusion is more useful than a single broad resilience adjective unsupported by evidence.


#### Worked demonstrations

**Four units and two unavailable states**

Synthetic training case — not a field record.

Four identical units each provide 100 kW usable capacity under the stated conditions. The load is 250 kW. All four normally share load. One unit can be isolated for maintenance. A separate scenario adds one further failed unit while maintenance continues. No distribution-path or transient evidence is supplied.

**Reasoning:** N is ceil(250/100)=3, so four units form N+1 in this capacity-only model. One unavailable leaves 300 kW and 50 kW headroom. Two unavailable leave 200 kW, 50 kW short. The model cannot establish path independence, transient behavior or a formal rating.

**Distributed capacity that cannot absorb a block loss**

Synthetic training case — not a field record.

Three blocks A/B/C each support 200 kW continuously and each normally carry 150 kW. If A fails, its load is split equally to B and C. Their transfer paths are each limited to 60 kW of additional load. A proposed fourth spare block can supply 200 kW, but a shared transfer bus is rated 120 kW. No overload allowance is authorized.

**Reasoning:** After A fails, B and C would each reach 225 kW, above their 200 kW ratings; each would also need 75 kW transferred through a 60 kW path. A fourth block’s rating alone does not solve a 150 kW transfer through a 120 kW bus. Capacity and connectivity must both pass.

**Two cords, one upstream dependency**

Synthetic training case — not a field record.

A server has two power cords. Cord A goes to rack PDU-A and cord B to PDU-B. Both PDUs feed from separate branch breakers on the same upstream bus U. Two external utility cables reach U through a common street duct and originate from one substation bus. Both PDU monitoring gateways use one control-power supply.

**Reasoning:** There are distinct branch paths but several common dependencies: U, the external duct/substation bus and monitoring control power. Trace the required service end to end. Loss of monitoring power is not automatically loss of IT power, but it can remove the visibility needed for an operational claim.

**A maintainable unit behind an unmaintainable valve**

Synthetic training case — not a field record.

Two cooling units can each meet the full stated load. They connect to separate branches, but both branches pass through one common isolation valve V before the header. The maintenance plan requires V to be removed for service. Unit B’s removal route is blocked by a permanent cable tray. A proposed test only stops unit A during normal operation.

**Reasoning:** The duplicate units do not establish maintenance of the shared valve without service loss. Physical removal access is also part of maintainability. Stopping A proves a narrower condition than servicing every required component/path; review V, access and the complete state matrix with the responsible specialists.

**Planned transfer versus abrupt fault evidence**

Synthetic training case — not a field record.

A design report claims a named rating but cites no edition or scope. It includes a successful planned transfer with synchronized sources. No abrupt-fault test or validated fault analysis is supplied. A downstream fault is predicted to trip a shared upstream device because selectivity is unresolved. A design-stage assessment exists for the original hall; a later extension uses a different shared control supply.

**Reasoning:** Identify the applicable scheme, edition and assessment scope. Planned transfer evidence does not establish every abrupt-fault response. Resolve protection selectivity through competent design review and reassess the changed extension; do not extend a design-stage or original-hall claim to unassessed construction.

#### Guided practice

Review the five synthetic topologies by calculating each unavailable state and building a capacity/path/authority evidence matrix.

**Hint:** Check quantity, connectivity, common causes, transition behavior and recovery separately.

**Worked solution:** The four-unit system carries one unavailable unit but not two. The distributed arrangement fails both block capacity and transfer limits. Dual cords share upstream dependencies. The common valve and blocked removal route defeat the unqualified maintenance claim. Planned transfer evidence cannot close abrupt-fault or extension assessment gaps.

#### Independent task

Environment: analytical

Produce a resilience design-review report without claiming formal site certification.

**Packaged starter material**

- course_labs/CDCS/README.md
- course_labs/CDCS/fixture.json
- course_labs/CDCS/assessment_template.md
- course_labs/CDCS/lab.py
- course_labs/CDCS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- State-capacity table
- Common-dependency register
- Maintenance access/isolation review
- Fault-response acceptance matrix and scope statement

**Acceptance criteria**

- Every conclusion identifies the exact state and load.
- Rating claims use actual scheme scope rather than generic labels.
- Physical tests and specialist protection approvals remain explicit external gates.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer.

#### Chapter practice

**CDCS-Q0051 · single · calculation**

How many units are required for N at this load?

Synthetic training case — not a field record.

Four identical units each provide 100 kW usable capacity under the stated conditions. The load is 250 kW. All four normally share load. One unit can be isolated for maintenance. A separate scenario adds one further failed unit while maintenance continues. No distribution-path or transient evidence is supplied.

1. 2.5
2. 2
3. 3
4. 4

**Correct option(s):** 3

- Option 1: A physical unit count must be rounded up.
- Option 2: That is below the 250 kW load.
- Option 3: Two units provide only 200 kW, while three provide 300.
- Option 4: Four are installed, but the minimum required count is three.

**CDCS-Q0052 · single · operations**

What is the installed capacity redundancy in this simple model?

Synthetic training case — not a field record.

Four identical units each provide 100 kW usable capacity under the stated conditions. The load is 250 kW. All four normally share load. One unit can be isolated for maintenance. A separate scenario adds one further failed unit while maintenance continues. No distribution-path or transient evidence is supplied.

1. 2N
2. N+2
3. N+1
4. N only

**Correct option(s):** 3

- Option 1: Two full sets of three would require six identical units.
- Option 2: That would require five units for this load.
- Option 3: Four installed minus three required leaves one additional unit.
- Option 4: The model has one unit above the required three.

**CDCS-Q0053 · single · calculation**

What capacity remains with one unit unavailable?

Synthetic training case — not a field record.

Four identical units each provide 100 kW usable capacity under the stated conditions. The load is 250 kW. All four normally share load. One unit can be isolated for maintenance. A separate scenario adds one further failed unit while maintenance continues. No distribution-path or transient evidence is supplied.

1. 200 kW
2. 300 kW
3. 400 kW
4. 250 kW

**Correct option(s):** 2

- Option 1: That corresponds to two unavailable units.
- Option 2: Three available units times 100 kW.
- Option 3: That includes the unavailable unit.
- Option 4: That is the load, not the remaining rating.

**CDCS-Q0054 · single · calculation**

What is headroom during the one-unit maintenance state?

Synthetic training case — not a field record.

Four identical units each provide 100 kW usable capacity under the stated conditions. The load is 250 kW. All four normally share load. One unit can be isolated for maintenance. A separate scenario adds one further failed unit while maintenance continues. No distribution-path or transient evidence is supplied.

1. 50 kW
2. Zero
3. 100 kW
4. 150 kW

**Correct option(s):** 1

- Option 1: 300 available minus 250 load.
- Option 2: The stated remaining capacity exceeds load.
- Option 3: That is a unit rating, not remaining headroom.
- Option 4: That uses all four units despite one being unavailable.

**CDCS-Q0055 · single · calculation**

What is the capacity deficit with maintenance plus the additional failure?

Synthetic training case — not a field record.

Four identical units each provide 100 kW usable capacity under the stated conditions. The load is 250 kW. All four normally share load. One unit can be isolated for maintenance. A separate scenario adds one further failed unit while maintenance continues. No distribution-path or transient evidence is supplied.

1. 150 kW
2. 100 kW
3. 50 kW
4. Zero because the system is called N+1

**Correct option(s):** 3

- Option 1: That overstates the difference between remaining capacity and load.
- Option 2: That is the lost unit’s rating, not the final deficit.
- Option 3: Only 200 kW remains for 250 kW load.
- Option 4: The label does not cover two unavailable units here.

**CDCS-Q0056 · single · mechanism**

What does this arithmetic leave unproven?

Synthetic training case — not a field record.

Four identical units each provide 100 kW usable capacity under the stated conditions. The load is 250 kW. All four normally share load. One unit can be isolated for maintenance. A separate scenario adds one further failed unit while maintenance continues. No distribution-path or transient evidence is supplied.

1. That 250 kW exceeds 200 kW
2. Distribution-path continuity and transition behavior
3. That four units are installed
4. That three 100 kW units total 300 kW

**Correct option(s):** 2

- Option 1: The supplied quantities establish the deficit.
- Option 2: The case supplies only steady capacity quantities.
- Option 3: That is an explicit premise.
- Option 4: The arithmetic establishes that within the model.

**CDCS-Q0057 · single · operations**

If the usable per-unit rating is later derated, what must be recalculated?

Synthetic training case — not a field record.

Four identical units each provide 100 kW usable capacity under the stated conditions. The load is 250 kW. All four normally share load. One unit can be isolated for maintenance. A separate scenario adds one further failed unit while maintenance continues. No distribution-path or transient evidence is supplied.

1. Nothing because the nameplate number is unchanged
2. Only the number of labels on the units
3. N and every relevant available-state capacity
4. Only the equipment purchase cost

**Correct option(s):** 3

- Option 1: The model must use the relevant operating capability.
- Option 2: Labels do not restore usable output.
- Option 3: The original calculation used the former usable rating.
- Option 4: Derating changes technical capability.

**CDCS-Q0058 · single · design**

What should govern admission of another 60 kW load while preserving the one-unit-loss criterion?

Synthetic training case — not a field record.

Four identical units each provide 100 kW usable capacity under the stated conditions. The load is 250 kW. All four normally share load. One unit can be isolated for maintenance. A separate scenario adds one further failed unit while maintenance continues. No distribution-path or transient evidence is supplied.

1. Accept because one unit is called spare
2. Reassess the criterion because 310 kW exceeds 300 kW surviving capacity
3. Reject all future load growth permanently
4. Accept because total installed capacity is 400 kW

**Correct option(s):** 2

- Option 1: The spare designation does not alter the capacity sum.
- Option 2: The new load would defeat the stated model.
- Option 3: Growth may be possible through a reviewed capacity change.
- Option 4: The required unavailable state controls this decision.

**CDCS-Q0059 · single · calculation**

What is a defensible maintenance-state report?

Synthetic training case — not a field record.

Four identical units each provide 100 kW usable capacity under the stated conditions. The load is 250 kW. All four normally share load. One unit can be isolated for maintenance. A separate scenario adds one further failed unit while maintenance continues. No distribution-path or transient evidence is supplied.

1. 250 kW load, 300 kW available, with no capacity to carry the stated second-loss scenario
2. The system has no redundancy in normal operation
3. Two units can remain unavailable indefinitely at full load
4. All resilience requirements guaranteed by N+1

**Correct option(s):** 1

- Option 1: It exposes the relevant state and limit.
- Option 2: One additional unit exists in the model.
- Option 3: Their remaining 200 kW is insufficient.
- Option 4: Other criteria remain untested.

**CDCS-Q0060 · single · operations**

Can this calculation award a formal facility rating?

Synthetic training case — not a field record.

Four identical units each provide 100 kW usable capacity under the stated conditions. The load is 250 kW. All four normally share load. One unit can be isolated for maintenance. A separate scenario adds one further failed unit while maintenance continues. No distribution-path or transient evidence is supplied.

1. Yes, if the result is rounded to a whole number
2. No; rating assessment requires the applicable complete criteria and evidence
3. Yes, because every four-unit system has the same rating
4. Only if the units use different vendors

**Correct option(s):** 2

- Option 1: Rounding does not create certification evidence.
- Option 2: A component-count model is only one input.
- Option 3: Load, paths and other requirements differ.
- Option 4: Vendor diversity alone does not establish a rating.

**CDCS-Q0061 · single · calculation**

What is the total normal load?

Synthetic training case — not a field record.

Three blocks A/B/C each support 200 kW continuously and each normally carry 150 kW. If A fails, its load is split equally to B and C. Their transfer paths are each limited to 60 kW of additional load. A proposed fourth spare block can supply 200 kW, but a shared transfer bus is rated 120 kW. No overload allowance is authorized.

1. 200 kW
2. 450 kW
3. 300 kW
4. 600 kW

**Correct option(s):** 2

- Option 1: That is one block’s capacity.
- Option 2: Three blocks each carry 150 kW.
- Option 3: That counts only two normal loads.
- Option 4: That is installed block capacity, not load.

**CDCS-Q0062 · single · calculation**

What aggregate block capacity survives loss of A?

Synthetic training case — not a field record.

Three blocks A/B/C each support 200 kW continuously and each normally carry 150 kW. If A fails, its load is split equally to B and C. Their transfer paths are each limited to 60 kW of additional load. A proposed fourth spare block can supply 200 kW, but a shared transfer bus is rated 120 kW. No overload allowance is authorized.

1. 600 kW
2. 300 kW
3. 400 kW
4. 450 kW

**Correct option(s):** 3

- Option 1: That incorrectly retains A’s unavailable capacity.
- Option 2: That is the survivors’ initial load, not their capacity.
- Option 3: B and C each retain 200 kW.
- Option 4: That is the load requiring support.

**CDCS-Q0063 · single · calculation**

What would each survivor carry after equal redistribution?

Synthetic training case — not a field record.

Three blocks A/B/C each support 200 kW continuously and each normally carry 150 kW. If A fails, its load is split equally to B and C. Their transfer paths are each limited to 60 kW of additional load. A proposed fourth spare block can supply 200 kW, but a shared transfer bus is rated 120 kW. No overload allowance is authorized.

1. 300 kW
2. 200 kW
3. 175 kW
4. 225 kW

**Correct option(s):** 4

- Option 1: That assigns all of A’s load to each survivor.
- Option 2: That assumes the transfer exactly fills capacity, contrary to the load quantity.
- Option 3: That transfers only 25 kW to each survivor.
- Option 4: 150 original plus half of A’s 150.

**CDCS-Q0064 · single · operations**

What independently limits the additional transfer into each survivor?

Synthetic training case — not a field record.

Three blocks A/B/C each support 200 kW continuously and each normally carry 150 kW. If A fails, its load is split equally to B and C. Their transfer paths are each limited to 60 kW of additional load. A proposed fourth spare block can supply 200 kW, but a shared transfer bus is rated 120 kW. No overload allowance is authorized.

1. The normal 150 kW load makes path rating irrelevant
2. The path automatically inherits the block’s 200 kW rating
3. The 60 kW path limit is below the required 75 kW
4. Equal splitting guarantees every path is adequate

**Correct option(s):** 3

- Option 1: Transferred load still passes through the limited path.
- Option 2: Different components have different ratings.
- Option 3: Connectivity capacity fails even before assuming unrestricted redistribution.
- Option 4: Equal allocation does not remove a rating constraint.

**CDCS-Q0065 · single · calculation**

What is the largest total load that two surviving blocks can carry by block ratings alone?

Synthetic training case — not a field record.

Three blocks A/B/C each support 200 kW continuously and each normally carry 150 kW. If A fails, its load is split equally to B and C. Their transfer paths are each limited to 60 kW of additional load. A proposed fourth spare block can supply 200 kW, but a shared transfer bus is rated 120 kW. No overload allowance is authorized.

1. 600 kW
2. 450 kW
3. 400 kW
4. 120 kW

**Correct option(s):** 3

- Option 1: That includes the lost block.
- Option 2: That exceeds surviving rated capacity.
- Option 3: Two times 200 kW establishes that aggregate upper bound.
- Option 4: That is the proposed spare bus rating, a different constraint.

**CDCS-Q0066 · single · mechanism**

Why does adding the fourth 200 kW spare not alone resolve A’s loss?

Synthetic training case — not a field record.

Three blocks A/B/C each support 200 kW continuously and each normally carry 150 kW. If A fails, its load is split equally to B and C. Their transfer paths are each limited to 60 kW of additional load. A proposed fourth spare block can supply 200 kW, but a shared transfer bus is rated 120 kW. No overload allowance is authorized.

1. Its shared transfer bus is limited to 120 kW against a 150 kW transfer
2. Four blocks automatically become 2N
3. A spare block can never support a failed block
4. The spare’s unused capacity is unavailable by definition

**Correct option(s):** 1

- Option 1: The path is a bottleneck despite adequate spare block rating.
- Option 2: The relationship depends on load and topology.
- Option 3: It can if the complete supported arrangement permits it.
- Option 4: Unused capacity can be usable when connected and controlled correctly.

**CDCS-Q0067 · single · operations**

What must a spare-sharing admission rule consider?

Synthetic training case — not a field record.

Three blocks A/B/C each support 200 kW continuously and each normally carry 150 kW. If A fails, its load is split equally to B and C. Their transfer paths are each limited to 60 kW of additional load. A proposed fourth spare block can supply 200 kW, but a shared transfer bus is rated 120 kW. No overload allowance is authorized.

1. Which simultaneous transfers can reach the spare within all path and block limits
2. Only the average historical load
3. Only the spare’s physical footprint
4. Only the number of normal operating blocks

**Correct option(s):** 1

- Option 1: Aggregate rating alone is insufficient.
- Option 2: The required event can impose a higher simultaneous demand.
- Option 3: Space does not define transfer capability.
- Option 4: Transfer combinations and routes matter.

**CDCS-Q0068 · single · design**

Can an unstated temporary overload be assumed to pass this design?

Synthetic training case — not a field record.

Three blocks A/B/C each support 200 kW continuously and each normally carry 150 kW. If A fails, its load is split equally to B and C. Their transfer paths are each limited to 60 kW of additional load. A proposed fourth spare block can supply 200 kW, but a shared transfer bus is rated 120 kW. No overload allowance is authorized.

1. No; supported duration, magnitude and authorization would need explicit evidence
2. Yes, all equipment tolerates 25% overload indefinitely
3. Yes, because the transfer lasts less than a day
4. No overload capability can ever exist

**Correct option(s):** 1

- Option 1: The case provides no overload allowance.
- Option 2: That is an unsupported universal claim.
- Option 3: No allowable duration is established.
- Option 4: Some products support bounded overload, but it must be verified.

**CDCS-Q0069 · single · design**

What design change would require a new review beyond adding block capacity?

Synthetic training case — not a field record.

Three blocks A/B/C each support 200 kW continuously and each normally carry 150 kW. If A fails, its load is split equally to B and C. Their transfer paths are each limited to 60 kW of additional load. A proposed fourth spare block can supply 200 kW, but a shared transfer bus is rated 120 kW. No overload allowance is authorized.

1. Increasing transfer-path capability and verifying controls/protection for the revised topology
2. Renaming the arrangement distributed redundant
3. Removing the failed-block scenario from the report without approval
4. Counting normal load twice to create more margin

**Correct option(s):** 1

- Option 1: The bottlenecks include paths and coordinated behavior.
- Option 2: A label does not alter its constraints.
- Option 3: That silently changes the requirement.
- Option 4: Arithmetic manipulation does not change physical capability.

**CDCS-Q0070 · single · operations**

What should be stated about maintenance on one block?

Synthetic training case — not a field record.

Three blocks A/B/C each support 200 kW continuously and each normally carry 150 kW. If A fails, its load is split equally to B and C. Their transfer paths are each limited to 60 kW of additional load. A proposed fourth spare block can supply 200 kW, but a shared transfer bus is rated 120 kW. No overload allowance is authorized.

1. A spare block always permits unlimited simultaneous work
2. It changes the available-state model and may reduce remaining failure tolerance
3. Maintenance planning can ignore IT load placement
4. Maintenance never affects distributed capacity

**Correct option(s):** 2

- Option 1: Shared capacity and paths impose limits.
- Option 2: Maintenance must be analyzed as a real unavailable state.
- Option 3: Placement affects which surviving paths can serve the load.
- Option 4: An isolated block cannot provide normal support.

**CDCS-Q0071 · single · mechanism**

What does the second cord establish by itself?

Synthetic training case — not a field record.

A server has two power cords. Cord A goes to rack PDU-A and cord B to PDU-B. Both PDUs feed from separate branch breakers on the same upstream bus U. Two external utility cables reach U through a common street duct and originate from one substation bus. Both PDU monitoring gateways use one control-power supply.

1. Complete source independence
2. A second connection to the server, requiring path analysis for independence
3. Two separate substations
4. Automatic fault tolerance for every server failure

**Correct option(s):** 2

- Option 1: Both paths share bus U.
- Option 2: Cord count does not prove distinct upstream supply.
- Option 3: The case states one substation bus.
- Option 4: Internal equipment behavior and other failures remain outside the cord count.

**CDCS-Q0072 · single · operations**

Which component is a common power-path dependency for both rack PDUs?

Synthetic training case — not a field record.

A server has two power cords. Cord A goes to rack PDU-A and cord B to PDU-B. Both PDUs feed from separate branch breakers on the same upstream bus U. Two external utility cables reach U through a common street duct and originate from one substation bus. Both PDU monitoring gateways use one control-power supply.

1. Upstream bus U
2. Only the server’s external label
3. The separate branch breaker unique to PDU-B
4. The separate branch breaker unique to PDU-A

**Correct option(s):** 1

- Option 1: Both branch paths connect to it.
- Option 2: A label is not the electrical dependency.
- Option 3: That breaker is not stated to feed PDU-A.
- Option 4: That breaker is not stated to feed PDU-B.

**CDCS-Q0073 · single · operations**

What can a fault or isolation of U potentially affect?

Synthetic training case — not a field record.

A server has two power cords. Cord A goes to rack PDU-A and cord B to PDU-B. Both PDUs feed from separate branch breakers on the same upstream bus U. Two external utility cables reach U through a common street duct and originate from one substation bus. Both PDU monitoring gateways use one control-power supply.

1. Only the monitoring gateways by definition
2. Neither cord because their branch breakers differ
3. Only the branch carrying the smaller load
4. Both rack supply paths

**Correct option(s):** 4

- Option 1: U is part of the power path.
- Option 2: Distinct downstream breakers do not remove the shared source.
- Option 3: Both branches share U regardless of their relative load.
- Option 4: They share the upstream bus.

**CDCS-Q0074 · single · mechanism**

Why are the two external cables not proven physically diverse?

Synthetic training case — not a field record.

A server has two power cords. Cord A goes to rack PDU-A and cord B to PDU-B. Both PDUs feed from separate branch breakers on the same upstream bus U. Two external utility cables reach U through a common street duct and originate from one substation bus. Both PDU monitoring gateways use one control-power supply.

1. They carry alternating current
2. They share the street duct
3. They terminate at a data centre
4. They have separate conductors

**Correct option(s):** 2

- Option 1: Current type is not the diversity criterion.
- Option 2: A single duct event may affect both.
- Option 3: Facility purpose does not establish route diversity.
- Option 4: Separate conductors can still share exposure.

**CDCS-Q0075 · single · operations**

What upstream fact limits the source-independence claim?

Synthetic training case — not a field record.

A server has two power cords. Cord A goes to rack PDU-A and cord B to PDU-B. Both PDUs feed from separate branch breakers on the same upstream bus U. Two external utility cables reach U through a common street duct and originate from one substation bus. Both PDU monitoring gateways use one control-power supply.

1. The PDUs have separate monitoring addresses
2. The cables use different circuit identifiers
3. Both originate from the same substation bus
4. Both are represented on one drawing

**Correct option(s):** 3

- Option 1: Monitoring addresses do not establish upstream independence.
- Option 2: Identifiers do not remove the shared bus.
- Option 3: That is a shared upstream dependency.
- Option 4: A drawing can show independent or dependent sources.

**CDCS-Q0076 · single · mechanism**

What does loss of the shared gateway control supply directly threaten?

Synthetic training case — not a field record.

A server has two power cords. Cord A goes to rack PDU-A and cord B to PDU-B. Both PDUs feed from separate branch breakers on the same upstream bus U. Two external utility cables reach U through a common street duct and originate from one substation bus. Both PDU monitoring gateways use one control-power supply.

1. No operational function because monitoring is always optional
2. Monitoring availability for both gateways
3. Only the gateway with the lower measured power demand
4. Guaranteed loss of every server power supply

**Correct option(s):** 2

- Option 1: Visibility may be required for operation and acceptance.
- Option 2: IT power loss would need its own physical evidence.
- Option 3: Both depend on the same control-power source.
- Option 4: The case does not place gateway power in the IT supply path.

**CDCS-Q0077 · single · implementation**

What should a common-cause register record?

Synthetic training case — not a field record.

A server has two power cords. Cord A goes to rack PDU-A and cord B to PDU-B. Both PDUs feed from separate branch breakers on the same upstream bus U. Two external utility cables reach U through a common street duct and originate from one substation bus. Both PDU monitoring gateways use one control-power supply.

1. Only vendor brand differences
2. Shared component/event, affected services, evidence and mitigation owner
3. Only normal-state voltage readings
4. Only a total count of duplicated devices

**Correct option(s):** 2

- Option 1: Different brands can share the same source or hazard.
- Option 2: It turns a dependency into a reviewable risk.
- Option 3: Normal readings do not reveal all common exposures.
- Option 4: Count does not identify shared causes.

**CDCS-Q0078 · single · operations**

What would best substantiate a revised diverse-route claim?

Synthetic training case — not a field record.

A server has two power cords. Cord A goes to rack PDU-A and cord B to PDU-B. Both PDUs feed from separate branch breakers on the same upstream bus U. Two external utility cables reach U through a common street duct and originate from one substation bus. Both PDU monitoring gateways use one control-power supply.

1. Different upstream switch ports without tracing the external cable paths
2. Verified route records and inspection/acceptance evidence for the actual paths
3. Two distinct IP subnets on the gateways
4. Two separate provider contracts without verification of their physical routes

**Correct option(s):** 2

- Option 1: Distinct ports do not establish physical separation through shared infrastructure.
- Option 2: The claim concerns physical routing.
- Option 3: Logical segmentation is a different property.
- Option 4: Commercial diversity can still share a duct, entrance or other physical failure point.

**CDCS-Q0079 · single · mechanism**

Why should monitoring and IT power consequences be recorded separately?

Synthetic training case — not a field record.

A server has two power cords. Cord A goes to rack PDU-A and cord B to PDU-B. Both PDUs feed from separate branch breakers on the same upstream bus U. Two external utility cables reach U through a common street duct and originate from one substation bus. Both PDU monitoring gateways use one control-power supply.

1. Monitoring never matters to resilience
2. Separate records prevent integrated analysis
3. Their dependency paths and service effects can differ
4. IT power can be inferred from any lost telemetry

**Correct option(s):** 3

- Option 1: It can be an important operational dependency.
- Option 2: Linked records can preserve distinctions and support integration.
- Option 3: A visibility outage is not automatically an electrical outage.
- Option 4: Missing data does not prove physical loss.

**CDCS-Q0080 · single · design**

Who should resolve substation protection and supply requirements?

Synthetic training case — not a field record.

A server has two power cords. Cord A goes to rack PDU-A and cord B to PDU-B. Both PDUs feed from separate branch breakers on the same upstream bus U. Two external utility cables reach U through a common street duct and originate from one substation bus. Both PDU monitoring gateways use one control-power supply.

1. The cable installer without reference to the design basis
2. The responsible utility and competent electrical specialists with defined interfaces
3. The dashboard operator by changing a status label
4. The server application developer alone

**Correct option(s):** 2

- Option 1: Installation scope does not automatically include protection approval.
- Option 2: An integration review identifies questions without assuming their authority.
- Option 3: Display changes cannot resolve physical supply requirements.
- Option 4: That role does not own the stated electrical design.

**CDCS-Q0081 · single · mechanism**

Why is full-capacity unit duplication insufficient here?

Synthetic training case — not a field record.

Two cooling units can each meet the full stated load. They connect to separate branches, but both branches pass through one common isolation valve V before the header. The maintenance plan requires V to be removed for service. Unit B’s removal route is blocked by a permanent cable tray. A proposed test only stops unit A during normal operation.

1. Two units can never support maintenance
2. A header is necessarily prohibited in every design
3. The common valve remains a maintenance dependency for both branches
4. The units must always be from different vendors

**Correct option(s):** 3

- Option 1: They can when the complete topology and access permit it.
- Option 2: Suitability depends on the required arrangement and criteria.
- Option 3: Capacity redundancy does not create a bypass around V.
- Option 4: Vendor difference does not resolve V.

**CDCS-Q0082 · single · operations**

What required operation exposes the common-valve problem?

Synthetic training case — not a field record.

Two cooling units can each meet the full stated load. They connect to separate branches, but both branches pass through one common isolation valve V before the header. The maintenance plan requires V to be removed for service. Unit B’s removal route is blocked by a permanent cable tray. A proposed test only stops unit A during normal operation.

1. Removing V for its planned service
2. Reading one normal temperature value
3. Viewing V on a drawing
4. Running both cooling units simultaneously at normal load

**Correct option(s):** 1

- Option 1: Both branches depend on the component being maintained.
- Option 2: Normal conditions do not prove the maintenance state.
- Option 3: Document viewing does not exercise isolation.
- Option 4: That does not exercise maintenance removal of the common valve.

**CDCS-Q0083 · single · mechanism**

What does stopping unit A demonstrate if the test passes?

Synthetic training case — not a field record.

Two cooling units can each meet the full stated load. They connect to separate branches, but both branches pass through one common isolation valve V before the header. The maintenance plan requires V to be removed for service. Unit B’s removal route is blocked by a permanent cable tray. A proposed test only stops unit A during normal operation.

1. Unit B can be physically removed past the cable tray
2. The defined service can continue for that specific tested state
3. Every unplanned cooling failure is tolerated
4. Every component is concurrently maintainable

**Correct option(s):** 2

- Option 1: Operating B does not prove its removal route.
- Option 2: It does not verify maintenance of V or every path.
- Option 3: A planned stop is a narrower event.
- Option 4: The shared valve was not tested.

**CDCS-Q0084 · single · mechanism**

Why is the cable tray a design-review issue?

Synthetic training case — not a field record.

Two cooling units can each meet the full stated load. They connect to separate branches, but both branches pass through one common isolation valve V before the header. The maintenance plan requires V to be removed for service. Unit B’s removal route is blocked by a permanent cable tray. A proposed test only stops unit A during normal operation.

1. It obstructs the required equipment removal route
2. Cable trays cannot exist near cooling equipment
3. It changes the unit’s thermal nameplate automatically
4. It can be ignored because the unit works today

**Correct option(s):** 1

- Option 1: Maintainability includes practical physical access.
- Option 2: The issue is this route and clearance, not a universal prohibition.
- Option 3: The stated problem is removal access.
- Option 4: Future maintenance is a lifecycle requirement.

**CDCS-Q0085 · single · operations**

What should the maintenance-state matrix include?

Synthetic training case — not a field record.

Two cooling units can each meet the full stated load. They connect to separate branches, but both branches pass through one common isolation valve V before the header. The maintenance plan requires V to be removed for service. Unit B’s removal route is blocked by a permanent cable tray. A proposed test only stops unit A during normal operation.

1. Only the count of installed cooling units
2. Only the annual maintenance budget
3. Only the vendor warranty period
4. Components/paths isolated, remaining capacity, transitions and service acceptance

**Correct option(s):** 4

- Option 1: Count omits paths and operating states.
- Option 2: Cost does not establish continuity.
- Option 3: Warranty does not prove isolation capability.
- Option 4: These determine whether the required work can occur.

**CDCS-Q0086 · single · operations**

What should a proposed temporary bypass require?

Synthetic training case — not a field record.

Two cooling units can each meet the full stated load. They connect to separate branches, but both branches pass through one common isolation valve V before the header. The maintenance plan requires V to be removed for service. Unit B’s removal route is blocked by a permanent cable tray. A proposed test only stops unit A during normal operation.

1. Automatic acceptance whenever flow is visible
2. Specialist-reviewed capability, protection, authority and transition evidence
3. No review because its use is brief
4. Only a hose long enough to reach both sides

**Correct option(s):** 2

- Option 1: Observed flow alone does not establish the required service and constraints.
- Option 2: A temporary path is an engineered operating state.
- Option 3: Short duration does not remove consequences.
- Option 4: Length alone does not establish compatibility or safe operation.

**CDCS-Q0087 · single · operations**

What is the correct treatment of an operating restriction during maintenance?

Synthetic training case — not a field record.

Two cooling units can each meet the full stated load. They connect to separate branches, but both branches pass through one common isolation valve V before the header. The maintenance plan requires V to be removed for service. Unit B’s removal route is blocked by a permanent cable tray. A proposed test only stops unit A during normal operation.

1. Hide it because the normal arrangement is redundant
2. Record permitted load/state, duration, owner and restoration criteria
3. Assume the restriction expires when the work starts
4. Treat it as a permanent waiver of every service requirement

**Correct option(s):** 2

- Option 1: Normal-state redundancy does not describe the maintenance state.
- Option 2: The reduced capability must remain visible.
- Option 3: It often governs the work period.
- Option 4: A bounded restriction has defined scope and authority.

**CDCS-Q0088 · single · mechanism**

Why coordinate other work during V maintenance?

Synthetic training case — not a field record.

Two cooling units can each meet the full stated load. They connect to separate branches, but both branches pass through one common isolation valve V before the header. The maintenance plan requires V to be removed for service. Unit B’s removal route is blocked by a permanent cable tray. A proposed test only stops unit A during normal operation.

1. Cooling maintenance cannot interact with power work
2. All unrelated work must always stop indefinitely
3. Another intervention may remove the remaining service or recovery dependency
4. Coordination is needed only after an outage begins

**Correct option(s):** 3

- Option 1: Cooling equipment and controls depend on power.
- Option 2: Coordination should follow dependencies and risk.
- Option 3: Separate work packages can interact through shared systems.
- Option 4: Planning should identify combined unavailable states beforehand.

**CDCS-Q0089 · single · operations**

What confirms successful return from the maintenance state?

Synthetic training case — not a field record.

Two cooling units can each meet the full stated load. They connect to separate branches, but both branches pass through one common isolation valve V before the header. The maintenance plan requires V to be removed for service. Unit B’s removal route is blocked by a permanent cable tray. A proposed test only stops unit A during normal operation.

1. Only the normal unit count on a screen
2. Accepted flow/control configuration, alarms, removed overrides and service evidence
3. Only a technician saying the valve is installed
4. Only the absence of a customer complaint

**Correct option(s):** 2

- Option 1: The display can omit isolation or control details.
- Option 2: Restoration is more than closing the work order.
- Option 3: Installation does not establish complete operational recovery.
- Option 4: A hidden restriction may remain.

**CDCS-Q0090 · single · design**

What conclusion is supportable before redesign or further evidence?

Synthetic training case — not a field record.

Two cooling units can each meet the full stated load. They connect to separate branches, but both branches pass through one common isolation valve V before the header. The maintenance plan requires V to be removed for service. Unit B’s removal route is blocked by a permanent cable tray. A proposed test only stops unit A during normal operation.

1. The duplicated units provide no useful capability at all
2. The entire facility has a formally failed certification
3. The blocked route is acceptable because maintenance is infrequent
4. The stated concurrent-maintenance claim is not established for V and B removal

**Correct option(s):** 4

- Option 1: They can still support the tested single-unit state.
- Option 2: No formal assessment process is supplied.
- Option 3: Infrequency does not satisfy the requirement.
- Option 4: Two specific required aspects remain unresolved.

**CDCS-Q0091 · single · operations**

What should be requested first about the rating claim?

Synthetic training case — not a field record.

A design report claims a named rating but cites no edition or scope. It includes a successful planned transfer with synchronized sources. No abrupt-fault test or validated fault analysis is supplied. A downstream fault is predicted to trip a shared upstream device because selectivity is unresolved. A design-stage assessment exists for the original hall; a later extension uses a different shared control supply.

1. Only the customer’s desired uptime percentage
2. Only the site’s preferred marketing wording
3. Only the number of redundant units
4. The named scheme, edition, scope and supporting assessment evidence

**Correct option(s):** 4

- Option 1: A service target is not the formal assessment scope.
- Option 2: Wording cannot establish criteria.
- Option 3: That is only one possible aspect of the complete scheme.
- Option 4: A label alone is ambiguous.

**CDCS-Q0092 · single · mechanism**

Why does the planned transfer not prove abrupt-fault behavior?

Synthetic training case — not a field record.

A design report claims a named rating but cites no edition or scope. It includes a successful planned transfer with synchronized sources. No abrupt-fault test or validated fault analysis is supplied. A downstream fault is predicted to trip a shared upstream device because selectivity is unresolved. A design-stage assessment exists for the original hall; a later extension uses a different shared control supply.

1. Initial conditions, detection, isolation and transients can differ
2. Synchronization proves every downstream load remains supported in any fault
3. Planned transfers provide no useful evidence
4. Abrupt faults always behave identically to scheduled transfers

**Correct option(s):** 1

- Option 1: The tested event is narrower than the claimed failure set.
- Option 2: Other failure mechanisms and paths remain.
- Option 3: They can verify their defined operating sequence.
- Option 4: That assumption needs evidence and may be false.

**CDCS-Q0093 · single · operations**

What is the consequence of unresolved selectivity in the supplied prediction?

Synthetic training case — not a field record.

A design report claims a named rating but cites no edition or scope. It includes a successful planned transfer with synchronized sources. No abrupt-fault test or validated fault analysis is supplied. A downstream fault is predicted to trip a shared upstream device because selectivity is unresolved. A design-stage assessment exists for the original hall; a later extension uses a different shared control supply.

1. A local fault may trip the shared upstream device and affect a broader service
2. All protective devices should be disabled to prevent interruption
3. The fault can affect only its branch by definition
4. The dashboard should conceal the upstream trip

**Correct option(s):** 1

- Option 1: The interruption can propagate beyond the faulty branch.
- Option 2: Protection duties cannot be removed for availability.
- Option 3: The predicted upstream trip contradicts that assumption.
- Option 4: Concealment does not resolve fault propagation.

**CDCS-Q0094 · single · operations**

Who should validate the protection coordination?

Synthetic training case — not a field record.

A design report claims a named rating but cites no edition or scope. It includes a successful planned transfer with synchronized sources. No abrupt-fault test or validated fault analysis is supplied. A downstream fault is predicted to trip a shared upstream device because selectivity is unresolved. A design-stage assessment exists for the original hall; a later extension uses a different shared control supply.

1. The network administrator because alarms use IP
2. The rack installer based only on breaker labels
3. The course quiz engine
4. The competent electrical/protection designer under the applicable requirements

**Correct option(s):** 4

- Option 1: Transport ownership does not confer protection authority.
- Option 2: Labels alone do not establish coordination.
- Option 3: Knowledge assessment cannot approve a site protection study.
- Option 4: This is a specialist design responsibility.

**CDCS-Q0095 · single · mechanism**

What does the design-stage assessment apply to?

Synthetic training case — not a field record.

A design report claims a named rating but cites no edition or scope. It includes a successful planned transfer with synchronized sources. No abrupt-fault test or validated fault analysis is supplied. A downstream fault is predicted to trip a shared upstream device because selectivity is unresolved. A design-stage assessment exists for the original hall; a later extension uses a different shared control supply.

1. Its documented design scope and conditions
2. Every future extension automatically
3. A guaranteed maximum number of annual outages
4. All installed construction regardless of deviations

**Correct option(s):** 1

- Option 1: It should not be expanded beyond its stated assessment.
- Option 2: Changes can introduce new dependencies.
- Option 3: No such operating guarantee follows from this case.
- Option 4: Actual installation requires its relevant evidence.

**CDCS-Q0096 · single · mechanism**

Why review the extension’s shared control supply?

Synthetic training case — not a field record.

A design report claims a named rating but cites no edition or scope. It includes a successful planned transfer with synchronized sources. No abrupt-fault test or validated fault analysis is supplied. A downstream fault is predicted to trip a shared upstream device because selectivity is unresolved. A design-stage assessment exists for the original hall; a later extension uses a different shared control supply.

1. It may introduce a common dependency absent from the assessed design
2. Only changes to capacity components need reassessment
3. Control power never affects infrastructure availability
4. Every different supply necessarily improves independence

**Correct option(s):** 1

- Option 1: The resilience model changed.
- Option 2: Control dependencies can also alter the resilience model.
- Option 3: Control functions can depend on it.
- Option 4: The supplied arrangement is shared, and its effects need analysis.

**CDCS-Q0097 · single · operations**

What should a fault-response evidence row specify?

Synthetic training case — not a field record.

A design report claims a named rating but cites no edition or scope. It includes a successful planned transfer with synchronized sources. No abrupt-fault test or validated fault analysis is supplied. A downstream fault is predicted to trip a shared upstream device because selectivity is unresolved. A design-stage assessment exists for the original hall; a later extension uses a different shared control supply.

1. Only a final green status icon
2. Initial state, fault, expected isolation/transfer, load observation and acceptance
3. Only the model number of the protective device
4. Only the time the test team arrived

**Correct option(s):** 2

- Option 1: It omits event and service behavior.
- Option 2: The claim needs a reproducible scenario and result.
- Option 3: Product identity does not demonstrate the installed response.
- Option 4: Attendance timing is not fault-response evidence.

**CDCS-Q0098 · single · operations**

What limitation should accompany an emulator-based fault study?

Synthetic training case — not a field record.

A design report claims a named rating but cites no edition or scope. It includes a successful planned transfer with synchronized sources. No abrupt-fault test or validated fault analysis is supplied. A downstream fault is predicted to trip a shared upstream device because selectivity is unresolved. A design-stage assessment exists for the original hall; a later extension uses a different shared control supply.

1. An emulator proves all live clearing times exactly
2. Unmodeled physical protection, thermal and equipment dynamics remain unproven
3. Simulation can never assist design review
4. A simulated pass authorizes live fault injection by any learner

**Correct option(s):** 2

- Option 1: The physical system needs its own validated evidence.
- Option 2: Simulation fidelity bounds the conclusion.
- Option 3: It can test logic and assumptions within scope.
- Option 4: Field tests require separate competence and authority.

**CDCS-Q0099 · single · operations**

Can different rating schemes be treated as identical because their levels have similar names?

Synthetic training case — not a field record.

A design report claims a named rating but cites no edition or scope. It includes a successful planned transfer with synchronized sources. No abrupt-fault test or validated fault analysis is supplied. A downstream fault is predicted to trip a shared upstream device because selectivity is unresolved. A design-stage assessment exists for the original hall; a later extension uses a different shared control supply.

1. Yes, matching level numbers guarantee identical requirements
2. Only the newest scheme can ever be used
3. No; compare actual scope, criteria, editions and assessment methods
4. Yes, if both mention redundancy

**Correct option(s):** 3

- Option 1: Numbering is not a technical comparison.
- Option 2: Project applicability depends on its requirements and context.
- Option 3: Similar labels do not establish equivalence.
- Option 4: Shared vocabulary does not make every criterion equal.

**CDCS-Q0100 · single · operations**

What is a defensible final claim before the missing work is resolved?

Synthetic training case — not a field record.

A design report claims a named rating but cites no edition or scope. It includes a successful planned transfer with synchronized sources. No abrupt-fault test or validated fault analysis is supplied. A downstream fault is predicted to trip a shared upstream device because selectivity is unresolved. A design-stage assessment exists for the original hall; a later extension uses a different shared control supply.

1. The planned transfer passed; abrupt-fault response and extension scope remain open
2. The design-stage certificate proves future operational availability
3. The successful transfer must be discarded as worthless
4. The whole expanded site is fault tolerant under every event

**Correct option(s):** 1

- Option 1: It states demonstrated evidence and its limits.
- Option 2: Operational outcomes and later changes require further evidence.
- Option 3: It remains valid for its recorded test condition.
- Option 4: The evidence does not support that scope.

#### Recall

**Four units and two unavailable states — Synthetic training case — not a field record.

Four identical units each provide 100 kW usable capacity under the stated conditions. The load is 250 kW. All four normally share load. One unit can be isolated for maintenance. A separate scenario adds one further failed unit while maintenance continues. No distribution-path or transient evidence is supplied.**

N is ceil(250/100)=3, so four units form N+1 in this capacity-only model. One unavailable leaves 300 kW and 50 kW headroom. Two unavailable leave 200 kW, 50 kW short. The model cannot establish path independence, transient behavior or a formal rating.

**Distributed capacity that cannot absorb a block loss — Synthetic training case — not a field record.

Three blocks A/B/C each support 200 kW continuously and each normally carry 150 kW. If A fails, its load is split equally to B and C. Their transfer paths are each limited to 60 kW of additional load. A proposed fourth spare block can supply 200 kW, but a shared transfer bus is rated 120 kW. No overload allowance is authorized.**

After A fails, B and C would each reach 225 kW, above their 200 kW ratings; each would also need 75 kW transferred through a 60 kW path. A fourth block’s rating alone does not solve a 150 kW transfer through a 120 kW bus. Capacity and connectivity must both pass.

**Two cords, one upstream dependency — Synthetic training case — not a field record.

A server has two power cords. Cord A goes to rack PDU-A and cord B to PDU-B. Both PDUs feed from separate branch breakers on the same upstream bus U. Two external utility cables reach U through a common street duct and originate from one substation bus. Both PDU monitoring gateways use one control-power supply.**

There are distinct branch paths but several common dependencies: U, the external duct/substation bus and monitoring control power. Trace the required service end to end. Loss of monitoring power is not automatically loss of IT power, but it can remove the visibility needed for an operational claim.

**A maintainable unit behind an unmaintainable valve — Synthetic training case — not a field record.

Two cooling units can each meet the full stated load. They connect to separate branches, but both branches pass through one common isolation valve V before the header. The maintenance plan requires V to be removed for service. Unit B’s removal route is blocked by a permanent cable tray. A proposed test only stops unit A during normal operation.**

The duplicate units do not establish maintenance of the shared valve without service loss. Physical removal access is also part of maintainability. Stopping A proves a narrower condition than servicing every required component/path; review V, access and the complete state matrix with the responsible specialists.

**Planned transfer versus abrupt fault evidence — Synthetic training case — not a field record.

A design report claims a named rating but cites no edition or scope. It includes a successful planned transfer with synchronized sources. No abrupt-fault test or validated fault analysis is supplied. A downstream fault is predicted to trip a shared upstream device because selectivity is unresolved. A design-stage assessment exists for the original hall; a later extension uses a different shared control supply.**

Identify the applicable scheme, edition and assessment scope. Planned transfer evidence does not establish every abrupt-fault response. Resolve protection selectivity through competent design review and reassess the changed extension; do not extend a design-stage or original-hall claim to unassessed construction.

#### References

- [EPI CDCS public syllabus](https://www.epi-ap.com/services/1/3/5)

## CDCS-M03 — Building interfaces, floor systems and specialist review boundaries

### CDCS-L03 — Building interfaces, floor systems and specialist review boundaries

Estimated study time: 120 minutes before independent work. Prerequisite chapters: CDCS-L02

## Site selection is a connected hazard and service decision

A site must support the required service across its planned life, not merely fit the first rack layout. Evaluate power and cooling resources, telecommunications, access, construction and maintenance logistics, neighboring activities, natural hazards, security, permissions and expansion. Separate hazard presence from consequence and mitigation. A river nearby is a reason for a competent flood assessment, not by itself a complete accept/reject decision. A location far from a river can still have drainage, groundwater or upstream infrastructure exposure. Use site-specific evidence and the applicable authorities rather than universal distance rules invented from a map.

Trace dependencies beyond the property line. Diverse internal paths can share an external bridge, duct, substation, water source or access road. A site can remain physically intact while fuel delivery, staff access or telecommunications fail. Record which service each dependency supports, the plausible disruption, duration assumptions and response. Compare alternatives against the same requirements and review residual risks with the authorized owner. Environmental and community constraints, including noise, discharge and planning conditions, can limit otherwise attractive engineering options. These considerations belong early enough to influence the design.

The charter boundary is explicit: building/civil/structural content here is D1 examination and interface literacy, not owned specialist design. The learner should recognize the information needed, check whether a proposal addresses it and route decisions to competent designers. A paper floor-load calculation is useful for spotting a mismatch; it is not approval to move a loaded rack over a slab, floor panel or lift. Likewise, the course does not provide universal wall ratings, blast standoff distances, seismic anchor designs or permission to alter fire barriers.

## Distinguish mass, force, distributed load and local load

Mass in kilograms becomes gravitational force through F = m g. Using the supplied educational value g = 9.81 m/s², a 1200 kg rack exerts approximately 11772 N, or 11.772 kN, before considering other loads or dynamic effects. Dividing by a 0.6 m × 1.2 m footprint gives an average 16.35 kN/m², numerically 16.35 kPa. This average is not the force at each leveling foot or caster. Actual contact areas can be small, and the load distribution may be uneven. A slab's allowable distributed loading does not automatically establish panel, pedestal, point-load or rolling-load capability.

The installation route is part of the load review. A rack might be acceptable in its final position but exceed a lift rating, ramp capability, threshold detail or raised-floor rolling-load condition during transport. Packaging and moving equipment add mass. Acceleration, braking, impact, wheel spacing and route transitions can affect local demands. The competent designer and manufacturer's system documentation determine the applicable checks and limits. Record the complete load state and route; do not average a concentrated load across an entire room to make the arithmetic appear compliant.

Hanging loads need their own load path to a suitable supporting structure. Cable trays, busways, pipework and suspended ceilings have different support systems and design duties. Attaching a heavy tray to a ceiling grid because it is nearby does not establish capacity. Include installed cables, future reserved fill, fittings and other relevant loads in the reviewed design. Coordinate supports, fire protection, maintenance access and seismic restraints. A supplier's component rating may not describe the assembled system with its actual anchors, spacing and substrate.

## Evaluate barriers as complete assemblies

Fire-resisting walls, glazing, doors and penetrations form an assembly with a specified purpose and tested or approved conditions. A wall's nominal rating does not automatically cover an unsealed cable opening, substituted glass or propped-open door. Verify the applicable assembly, installation details, penetrations, joints, supports and inspection evidence through the responsible fire/building specialists. Changes after acceptance can defeat the original performance: a new cable route or liquid pipe needs a reviewed penetration system, not a convenient gap filled with an unspecified material.

Security barriers address defined threats such as unauthorized entry, forced entry, projectile or blast exposure. Those are different performance requirements with different tests and conditions. “Security glass” is not a universal specification. Define the threat, protected area, expected performance, supporting frame and installation boundary through competent risk and design work. Strengthening one element can leave a weaker adjacent door, wall, ceiling void or service opening. Review the complete path, including access control and monitoring, while preserving required emergency egress and life-safety functions.

Do not infer one property from another. A product may have a fire performance classification without meeting a specified forced-entry requirement, or vice versa. Glazing performance depends on the complete tested assembly and use conditions. Thermal stability, weather resistance and building movement are additional design considerations. The integration engineer can verify that sensors, access controls and alarms interface correctly with the accepted barrier arrangement; that role does not authorize changing a life-safety release or certifying a blast design.

## Raised floors are engineered systems

A raised access floor consists of panels, pedestals, stringers or other support details as applicable, perimeter conditions and penetrations. Performance depends on correct component selection and installation as a system. Review level, alignment, pedestal support, attachment, panel seating, cut-edge treatment and the manufacturer's instructions. Rocking panels, uneven transitions, damaged edges and loose supports can create handling or trip hazards and compromise the intended load path. The existence of a nominal panel rating does not excuse an incorrectly installed pedestal or unsupported cut panel.

An underfloor space can be used for air distribution, cabling or other services according to the design. Unsealed openings can bypass intended airflow paths; crowded cable bundles or abandoned materials can obstruct distribution and maintenance access. A perforated tile's open area is not the same as its delivered airflow. Pressure, location, obstruction and the complete cooling arrangement determine actual flow. Moving tiles as an informal response to a hot rack can change the wider airflow pattern and must follow the authorized operating process. Retain the accepted tile and cable layout as part of the configuration baseline.

Seismic considerations include equipment restraint, floor-system behavior, ceilings, suspended services and their relative movement. A rack fixed to a floor panel does not automatically have a verified load path into the building structure. Anchors depend on substrate, edge distances, installation and the engineered design. Flexible connections and clearances may be required where systems move differently, but dimensions and details must come from the applicable design. A visual check can identify missing restraints or obvious deviations; it does not replace the calculations, installation verification or local requirements.

## Suspended ceilings, access and coordinated acceptance

Suspended ceilings interact with lighting, detection, suppression, airflow and above-ceiling services. Define which components the ceiling may support and which require independent support. Access panels should allow required inspection and maintenance without damaging critical services. Ceiling layout changes can affect detector coverage or fire-system discharge distribution, so coordination extends beyond appearance. Tiles and grids installed beneath leaking pipework or in a maintenance removal path introduce lifecycle concerns that a plan view alone may miss.

Acceptance should reconcile the installed system with the reviewed drawings, product system, inspection records and unresolved deviations. Record load restrictions and route limitations where operators will actually use them. Protect temporary openings and maintain safe access during work under the site's approved procedures. Reinspect after significant cable additions, heavy equipment moves, leaks or structural alterations as required by the responsible owners. A data-centre design review succeeds when it makes the specialist interfaces and evidence clear enough that operations can preserve the accepted condition over time.


#### Worked demonstrations

**A site with intact buildings but exposed dependencies**

Synthetic training case — not a field record.

Site A has low quoted land cost. Its two fiber routes cross one bridge; the fuel delivery route and staff access use the same road. A drainage study is pending. Site B costs more but has documented alternate access and separate fiber routes. Neither site has an accepted full hazard/capacity review. The owner values continuous service during a regional storm.

**Reasoning:** Compare the sites on the same service and hazard boundary. Site A has identifiable common dependencies, while Site B’s documented alternatives address only those aspects. Complete the competent hazard, utility and operating review before claiming either site meets the full requirement.

**Rack mass, local contact and transport route**

Synthetic training case — not a field record.

A loaded rack has mass 1200 kg and footprint 0.6 m × 1.2 m. Use g=9.81 m/s² for this training calculation. It rests on four small feet. The quoted floor limit is a distributed-load value; no point or rolling-load evidence is supplied. A 150 kg moving cradle is used through a lift rated 1300 kg. A proposed cable tray would hang from an unverified ceiling grid.

**Reasoning:** Rack weight is 11.772 kN and footprint-average pressure is 16.35 kPa, but foot contacts and floor-system ratings require separate review. Rack plus cradle is 1350 kg, exceeding the supplied lift rating before any other load. The tray needs an approved supporting load path rather than an assumed ceiling-grid capacity.

**A rated wall with an unreviewed penetration**

Synthetic training case — not a field record.

A room wall has an approved fire-resisting assembly. A contractor adds a cable opening using unspecified foam. Replacement glazing is advertised as security glass but has no evidence for the project’s specified fire and forced-entry performance. A door is held open for deliveries. The security team proposes disabling emergency release to improve access control.

**Reasoning:** Assess the modified complete assemblies with the competent fire/building/security owners. Unspecified penetration material and unsupported glazing claims do not preserve the approved performance. Delivery control and security changes must retain required life-safety and egress behavior.

**Raised-floor and ceiling deviations after cabling work**

Synthetic training case — not a field record.

After a cable addition, one raised-floor panel rocks, a cut panel has an unsupported edge, and unused cable openings remain unsealed in an air plenum. A perforated tile was moved to a hot rack without an airflow review. A rack restraint attaches only to the removable panel, with no documented structural load path. New ceiling equipment is fixed to a grid whose allowed loads are unknown.

**Reasoning:** Hold acceptance of the deviations and refer load/restraint details to the responsible specialists. Restore the approved floor and airflow configuration through controlled work, verify the complete supports and penetrations, and review ceiling/detection/suppression interfaces. Visual presence of an anchor does not establish seismic performance.

#### Guided practice

Prepare an interface review for the 1200 kg rack route, modified fire barrier and disturbed floor/ceiling installation.

**Hint:** Calculate only what the supplied model supports; identify every missing system or specialist approval.

**Worked solution:** The rack is 11.772 kN over 0.72 m², averaging 16.35 kPa; this does not prove local floor capacity. The 1350 kg moving load exceeds the stated lift rating. Review the complete penetration/glazing assemblies, preserve egress, and require documented structural/support and airflow acceptance for the changed floor and ceiling.

#### Independent task

Environment: analytical

Build a D1 literacy review that identifies technical evidence and routes decisions to the correct specialists.

**Packaged starter material**

- course_labs/CDCS/README.md
- course_labs/CDCS/fixture.json
- course_labs/CDCS/assessment_template.md
- course_labs/CDCS/lab.py
- course_labs/CDCS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- Site dependency comparison
- Load/route screening calculation
- Barrier and penetration deviation register
- Floor/ceiling inspection and interface checklist

**Acceptance criteria**

- No average-load calculation is treated as structural approval.
- Actual assembly and route conditions are included.
- D1 specialist ownership is not claimed by the learner.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer.

#### Chapter practice

**CDCS-Q0101 · single · operations**

What shared dependency can affect both fiber services at Site A?

Synthetic training case — not a field record.

Site A has low quoted land cost. Its two fiber routes cross one bridge; the fuel delivery route and staff access use the same road. A drainage study is pending. Site B costs more but has documented alternate access and separate fiber routes. Neither site has an accepted full hazard/capacity review. The owner values continuous service during a regional storm.

1. The fact that fiber is used
2. The different provider contracts
3. The bridge crossing
4. The rack patch-panel numbering

**Correct option(s):** 3

- Option 1: Fiber technology alone does not establish common physical routing.
- Option 2: Separate contracts do not remove the shared bridge.
- Option 3: Both routes pass through the same exposed structure.
- Option 4: Internal labels do not define the external route.

**CDCS-Q0102 · single · mechanism**

Why analyze fuel delivery and staff access together?

Synthetic training case — not a field record.

Site A has low quoted land cost. Its two fiber routes cross one bridge; the fuel delivery route and staff access use the same road. A drainage study is pending. Site B costs more but has documented alternate access and separate fiber routes. Neither site has an accepted full hazard/capacity review. The owner values continuous service during a regional storm.

1. Fuel storage always eliminates every delivery concern
2. Staff and fuel are identical resources
3. A site needs no staff access during any incident
4. A single road disruption can affect both operational dependencies

**Correct option(s):** 4

- Option 1: Required duration and replenishment conditions still matter.
- Option 2: They support different functions despite sharing access.
- Option 3: That assumption is not established.
- Option 4: The same event can create multiple consequences.

**CDCS-Q0103 · single · mechanism**

What does the pending drainage study mean for selection?

Synthetic training case — not a field record.

Site A has low quoted land cost. Its two fiber routes cross one bridge; the fuel delivery route and staff access use the same road. A drainage study is pending. Site B costs more but has documented alternate access and separate fiber routes. Neither site has an accepted full hazard/capacity review. The owner values continuous service during a regional storm.

1. Drainage is unrelated to data-centre service
2. The site must be rejected solely because a study is pending
3. A relevant site-hazard question remains unresolved
4. The site is proven free from flooding

**Correct option(s):** 3

- Option 1: Water exposure can affect facilities and access.
- Option 2: The result may support a suitable mitigation or decision.
- Option 3: No accepted conclusion is available yet.
- Option 4: Missing evidence does not establish absence.

**CDCS-Q0104 · single · mechanism**

What does Site B’s alternate access evidence establish?

Synthetic training case — not a field record.

Site A has low quoted land cost. Its two fiber routes cross one bridge; the fuel delivery route and staff access use the same road. A drainage study is pending. Site B costs more but has documented alternate access and separate fiber routes. Neither site has an accepted full hazard/capacity review. The owner values continuous service during a regional storm.

1. Complete immunity to regional storms
2. A documented alternative for that dependency within its stated conditions
3. Automatic approval of its structural design
4. Guaranteed lower lifecycle cost

**Correct option(s):** 2

- Option 1: Other hazards and shared dependencies remain.
- Option 2: It does not close every site requirement.
- Option 3: Access evidence does not assess structure.
- Option 4: Its cost and operating profile need separate analysis.

**CDCS-Q0105 · single · operations**

What should the comparison use besides land price?

Synthetic training case — not a field record.

Site A has low quoted land cost. Its two fiber routes cross one bridge; the fuel delivery route and staff access use the same road. A drainage study is pending. Site B costs more but has documented alternate access and separate fiber routes. Neither site has an accepted full hazard/capacity review. The owner values continuous service during a regional storm.

1. Only the shorter travel time in normal weather
2. Only the maximum advertised utility capacity
3. Equivalent service requirements, dependency risks and lifecycle implications
4. Only the number of roads visible on a map

**Correct option(s):** 3

- Option 1: The owner’s disruption requirement also matters.
- Option 2: Delivery, reliability and other interfaces matter.
- Option 3: Initial price is only one decision input.
- Option 4: Visible routes may share choke points or be unusable.

**CDCS-Q0106 · single · operations**

Who should assess the site’s drainage and structural mitigation?

Synthetic training case — not a field record.

Site A has low quoted land cost. Its two fiber routes cross one bridge; the fuel delivery route and staff access use the same road. A drainage study is pending. Site B costs more but has documented alternate access and separate fiber routes. Neither site has an accepted full hazard/capacity review. The owner values continuous service during a regional storm.

1. The app learner solely after passing the site quiz
2. Competent specialists under applicable local requirements
3. The server vendor using only rack dimensions
4. The fiber provider alone

**Correct option(s):** 2

- Option 1: Study does not confer professional design authority.
- Option 2: This is beyond integration-literacy ownership.
- Option 3: Rack information does not establish site drainage.
- Option 4: Its route scope does not cover the whole building hazard design.

**CDCS-Q0107 · single · implementation**

Which record makes a residual site risk actionable?

Synthetic training case — not a field record.

Site A has low quoted land cost. Its two fiber routes cross one bridge; the fuel delivery route and staff access use the same road. A drainage study is pending. Site B costs more but has documented alternate access and separate fiber routes. Neither site has an accepted full hazard/capacity review. The owner values continuous service during a regional storm.

1. Event, affected service, assumptions, mitigation, owner and acceptance
2. Only the historical land sale price
3. Only a red or green map marker
4. Only a vendor promise of best effort

**Correct option(s):** 1

- Option 1: The decision needs consequence and accountability.
- Option 2: That does not describe the hazard response.
- Option 3: A color does not explain the risk basis.
- Option 4: It lacks defined capability and acceptance.

**CDCS-Q0108 · single · operations**

Can separate fiber routes still share a regional dependency?

Synthetic training case — not a field record.

Site A has low quoted land cost. Its two fiber routes cross one bridge; the fuel delivery route and staff access use the same road. A drainage study is pending. Site B costs more but has documented alternate access and separate fiber routes. Neither site has an accepted full hazard/capacity review. The owner values continuous service during a regional storm.

1. Only if the two services terminate on the same rack switch
2. Yes; upstream facilities or wider hazards can remain common
3. No; separate trenches eliminate every common cause
4. Only if the fibers use identical wavelengths

**Correct option(s):** 2

- Option 1: Common dependencies can exist far upstream of the rack.
- Option 2: Route separation addresses only identified parts of the chain.
- Option 3: Other dependencies can remain.
- Option 4: Wavelength is not the regional hazard criterion.

**CDCS-Q0109 · single · operations**

What should a continuity assumption about stored fuel include?

Synthetic training case — not a field record.

Site A has low quoted land cost. Its two fiber routes cross one bridge; the fuel delivery route and staff access use the same road. A drainage study is pending. Site B costs more but has documented alternate access and separate fiber routes. Neither site has an accepted full hazard/capacity review. The owner values continuous service during a regional storm.

1. Only the number of generators
2. Only tank geometric volume
3. Only the supplier’s annual sales volume
4. Usable quantity, demand, duration and replenishment constraints

**Correct option(s):** 4

- Option 1: Consumption and supported load also matter.
- Option 2: Unusable reserve and consumption affect endurance.
- Option 3: That does not establish site delivery during the event.
- Option 4: Storage quantity alone is not a complete operating promise.

**CDCS-Q0110 · single · design**

What is the defensible selection status now?

Synthetic training case — not a field record.

Site A has low quoted land cost. Its two fiber routes cross one bridge; the fuel delivery route and staff access use the same road. A drainage study is pending. Site B costs more but has documented alternate access and separate fiber routes. Neither site has an accepted full hazard/capacity review. The owner values continuous service during a regional storm.

1. Site A is best because its land is cheapest
2. Neither site has complete evidence for final service acceptance
3. Both sites are equivalent because both can hold racks
4. Site B is fully approved because two alternatives are documented

**Correct option(s):** 2

- Option 1: Price alone does not meet the service requirement.
- Option 2: Some useful comparative evidence exists, but reviews remain open.
- Option 3: Space does not establish the required service.
- Option 4: The full hazard and capacity review is incomplete.

**CDCS-Q0111 · single · calculation**

What is the rack’s gravitational force using the supplied g?

Synthetic training case — not a field record.

A loaded rack has mass 1200 kg and footprint 0.6 m × 1.2 m. Use g=9.81 m/s² for this training calculation. It rests on four small feet. The quoted floor limit is a distributed-load value; no point or rolling-load evidence is supplied. A 150 kg moving cradle is used through a lift rated 1300 kg. A proposed cable tray would hang from an unverified ceiling grid.

1. 11772 kN
2. 11.772 kN
3. 1200 kPa
4. 1.2 kN

**Correct option(s):** 2

- Option 1: That fails to convert newtons to kilonewtons.
- Option 2: 1200 × 9.81 gives 11772 N, divided by 1000 for kN.
- Option 3: Mass is not pressure and area has not been applied.
- Option 4: That treats tonnes as force without applying gravity.

**CDCS-Q0112 · single · calculation**

What is the footprint area?

Synthetic training case — not a field record.

A loaded rack has mass 1200 kg and footprint 0.6 m × 1.2 m. Use g=9.81 m/s² for this training calculation. It rests on four small feet. The quoted floor limit is a distributed-load value; no point or rolling-load evidence is supplied. A 150 kg moving cradle is used through a lift rated 1300 kg. A proposed cable tray would hang from an unverified ceiling grid.

1. 0.72 m²
2. 7.2 m²
3. 1.8 m²
4. 0.6 m²

**Correct option(s):** 1

- Option 1: 0.6 multiplied by 1.2 equals 0.72.
- Option 2: That introduces a factor-of-ten error.
- Option 3: That adds lengths instead of multiplying.
- Option 4: That omits the second dimension.

**CDCS-Q0113 · single · calculation**

What is the average pressure over that footprint?

Synthetic training case — not a field record.

A loaded rack has mass 1200 kg and footprint 0.6 m × 1.2 m. Use g=9.81 m/s² for this training calculation. It rests on four small feet. The quoted floor limit is a distributed-load value; no point or rolling-load evidence is supplied. A 150 kg moving cradle is used through a lift rated 1300 kg. A proposed cable tray would hang from an unverified ceiling grid.

1. 8.48 kPa
2. 16.35 kPa
3. 0.061 kPa
4. 11.772 kPa

**Correct option(s):** 2

- Option 1: That multiplies force by area rather than dividing.
- Option 2: 11.772 kN divided by 0.72 m² gives 16.35 kN/m².
- Option 3: That reverses the force/area relationship.
- Option 4: That ignores the footprint area.

**CDCS-Q0114 · single · mechanism**

Why does this average not settle the raised-floor acceptance?

Synthetic training case — not a field record.

A loaded rack has mass 1200 kg and footprint 0.6 m × 1.2 m. Use g=9.81 m/s² for this training calculation. It rests on four small feet. The quoted floor limit is a distributed-load value; no point or rolling-load evidence is supplied. A 150 kg moving cradle is used through a lift rated 1300 kg. A proposed cable tray would hang from an unverified ceiling grid.

1. The arithmetic is irrelevant to every review
2. All four feet necessarily carry exactly equal force
3. Small feet create local loads and the complete floor system has separate limits
4. A rack footprint always equals its contact area

**Correct option(s):** 3

- Option 1: It is a useful screening quantity within its limits.
- Option 2: Actual distribution and support conditions need evidence.
- Option 3: Distributed pressure is not a point-load verification.
- Option 4: The feet contact much smaller areas.

**CDCS-Q0115 · single · calculation**

What is the rack-plus-cradle mass?

Synthetic training case — not a field record.

A loaded rack has mass 1200 kg and footprint 0.6 m × 1.2 m. Use g=9.81 m/s² for this training calculation. It rests on four small feet. The quoted floor limit is a distributed-load value; no point or rolling-load evidence is supplied. A 150 kg moving cradle is used through a lift rated 1300 kg. A proposed cable tray would hang from an unverified ceiling grid.

1. 1050 kg
2. 1200 kg
3. 150 kg
4. 1350 kg

**Correct option(s):** 4

- Option 1: That subtracts rather than adds handling equipment.
- Option 2: That omits the cradle.
- Option 3: That counts only the cradle.
- Option 4: 1200 plus 150 equals 1350.

**CDCS-Q0116 · single · mechanism**

What does the supplied lift rating imply for this move?

Synthetic training case — not a field record.

A loaded rack has mass 1200 kg and footprint 0.6 m × 1.2 m. Use g=9.81 m/s² for this training calculation. It rests on four small feet. The quoted floor limit is a distributed-load value; no point or rolling-load evidence is supplied. A 150 kg moving cradle is used through a lift rated 1300 kg. A proposed cable tray would hang from an unverified ceiling grid.

1. It passes if moved slowly regardless of rating
2. It passes because the rack alone is below 1300 kg
3. It passes because the destination floor is larger
4. The 1350 kg load exceeds 1300 kg before any additional load

**Correct option(s):** 4

- Option 1: Speed does not authorize exceeding the stated limit.
- Option 2: The lift carries the cradle too.
- Option 3: Destination area does not change lift capacity.
- Option 4: The proposed route cannot be accepted on the supplied rating.

**CDCS-Q0117 · single · operations**

What additional floor evidence is relevant during movement?

Synthetic training case — not a field record.

A loaded rack has mass 1200 kg and footprint 0.6 m × 1.2 m. Use g=9.81 m/s² for this training calculation. It rests on four small feet. The quoted floor limit is a distributed-load value; no point or rolling-load evidence is supplied. A 150 kg moving cradle is used through a lift rated 1300 kg. A proposed cable tray would hang from an unverified ceiling grid.

1. Rolling/contact loads, route transitions and the assembled system’s approved capability
2. Only a normal-temperature reading under the floor
3. Only the room’s total floor area
4. Only the rack’s network port count

**Correct option(s):** 1

- Option 1: Transport can differ from static final loading.
- Option 2: Thermal conditions do not prove rolling-load capability.
- Option 3: A large average area does not resolve local route loads.
- Option 4: That does not establish mechanical loading.

**CDCS-Q0118 · single · mechanism**

Why is attaching the tray to the unverified grid unacceptable as a design assumption?

Synthetic training case — not a field record.

A loaded rack has mass 1200 kg and footprint 0.6 m × 1.2 m. Use g=9.81 m/s² for this training calculation. It rests on four small feet. The quoted floor limit is a distributed-load value; no point or rolling-load evidence is supplied. A 150 kg moving cradle is used through a lift rated 1300 kg. A proposed cable tray would hang from an unverified ceiling grid.

1. Cable mass is always negligible
2. All trays must be floor-mounted in every data centre
3. The grid’s supporting load path and capacity are not established for that tray
4. Ceiling grids automatically inherit slab capacity

**Correct option(s):** 3

- Option 1: Installed and future fill can create significant load.
- Option 2: Other supported designs can be appropriate.
- Option 3: Proximity is not structural approval.
- Option 4: Connections and system details govern the load path.

**CDCS-Q0119 · single · design**

What should the tray load review include?

Synthetic training case — not a field record.

A loaded rack has mass 1200 kg and footprint 0.6 m × 1.2 m. Use g=9.81 m/s² for this training calculation. It rests on four small feet. The quoted floor limit is a distributed-load value; no point or rolling-load evidence is supplied. A 150 kg moving cradle is used through a lift rated 1300 kg. A proposed cable tray would hang from an unverified ceiling grid.

1. Tray, cables, fittings, reserved fill and relevant support conditions
2. Only the empty tray catalogue mass
3. Only the grid’s visual straightness
4. Only current cables with no planned expansion despite a reservation

**Correct option(s):** 1

- Option 1: The complete loaded system needs evaluation.
- Option 2: That omits carried and accessory loads.
- Option 3: Appearance does not establish structural capacity.
- Option 4: Reserved future loading should be addressed.

**CDCS-Q0120 · single · operations**

What is the learner’s correct outcome from these calculations?

Synthetic training case — not a field record.

A loaded rack has mass 1200 kg and footprint 0.6 m × 1.2 m. Use g=9.81 m/s² for this training calculation. It rests on four small feet. The quoted floor limit is a distributed-load value; no point or rolling-load evidence is supplied. A 150 kg moving cradle is used through a lift rated 1300 kg. A proposed cable tray would hang from an unverified ceiling grid.

1. Redesign anchors independently from the quiz answer
2. Identify mismatches and request competent structural/handling approval
3. Ignore all limits because the rack has wheels
4. Approve the rack move because the average pressure was calculated

**Correct option(s):** 2

- Option 1: Anchor design requires appropriate competence and site data.
- Option 2: The course supports interface review, not authorized physical movement.
- Option 3: Mobility does not remove loading constraints.
- Option 4: The route already exceeds the supplied lift rating.

**CDCS-Q0121 · single · mechanism**

Why does the original wall approval not settle the new opening?

Synthetic training case — not a field record.

A room wall has an approved fire-resisting assembly. A contractor adds a cable opening using unspecified foam. Replacement glazing is advertised as security glass but has no evidence for the project’s specified fire and forced-entry performance. A door is held open for deliveries. The security team proposes disabling emergency release to improve access control.

1. Cable insulation alone replaces the wall’s penetration system
2. Any cable penetration automatically makes every wall unusable
3. Foam appearance proves its fire capability
4. The penetration changes the assembly and needs an applicable approved detail

**Correct option(s):** 4

- Option 1: The complete opening needs its specified treatment.
- Option 2: Suitable designed penetration systems can preserve required performance.
- Option 3: Material and installation evidence are required.
- Option 4: Original wall performance does not cover arbitrary modifications.

**CDCS-Q0122 · single · operations**

What evidence should support the penetration repair?

Synthetic training case — not a field record.

A room wall has an approved fire-resisting assembly. A contractor adds a cable opening using unspecified foam. Replacement glazing is advertised as security glass but has no evidence for the project’s specified fire and forced-entry performance. A door is held open for deliveries. The security team proposes disabling emergency release to improve access control.

1. Only a material datasheet without the applicable penetration assembly
2. Only the installer’s statement that the gap is filled
3. Only the number of cables crossing the wall
4. The applicable tested/approved system, installation conditions and verification

**Correct option(s):** 4

- Option 1: A material alone may not cover the installed opening and service combination.
- Option 2: Filling does not establish performance.
- Option 3: Cable count alone omits material and assembly conditions.
- Option 4: Suitability depends on the complete detail.

**CDCS-Q0123 · single · operations**

What is missing from the security-glass proposal?

Synthetic training case — not a field record.

A room wall has an approved fire-resisting assembly. A contractor adds a cable opening using unspecified foam. Replacement glazing is advertised as security glass but has no evidence for the project’s specified fire and forced-entry performance. A door is held open for deliveries. The security team proposes disabling emergency release to improve access control.

1. Only a test for a different pane/frame assembly
2. Only a darker tint
3. Only a larger pane size
4. Evidence for the specified performance of the complete glazing/frame assembly

**Correct option(s):** 4

- Option 1: The evidence must apply to the proposed complete installation.
- Option 2: Tint does not establish fire or forced-entry capability.
- Option 3: Dimensions alone do not prove required performance.
- Option 4: A marketing term does not define test conditions or ratings.

**CDCS-Q0124 · single · operations**

Can fire performance be inferred from a forced-entry claim?

Synthetic training case — not a field record.

A room wall has an approved fire-resisting assembly. A contractor adds a cable opening using unspecified foam. Replacement glazing is advertised as security glass but has no evidence for the project’s specified fire and forced-entry performance. A door is held open for deliveries. The security team proposes disabling emergency release to improve access control.

1. No; they are distinct properties needing applicable evidence
2. Yes, any strong glass is fire resisting
3. Only if the glass is thicker than the original
4. Yes, if the frame is metal

**Correct option(s):** 1

- Option 1: One test purpose does not automatically establish another.
- Option 2: Strength and fire behavior differ.
- Option 3: Thickness is not a universal equivalence rule.
- Option 4: Frame material alone does not prove the assembly.

**CDCS-Q0125 · single · design**

What should a blast-protection requirement define?

Synthetic training case — not a field record.

A room wall has an approved fire-resisting assembly. A contractor adds a cable opening using unspecified foam. Replacement glazing is advertised as security glass but has no evidence for the project’s specified fire and forced-entry performance. A door is held open for deliveries. The security team proposes disabling emergency release to improve access control.

1. Only a bullet-resistance classification without blast criteria
2. Only the phrase blast proof
3. The assessed threat, performance objective and complete engineered boundary
4. Only a universal distance taken from this quiz

**Correct option(s):** 3

- Option 1: Projectile and blast performance are different requirements.
- Option 2: That lacks a bounded threat and acceptance basis.
- Option 3: A generic adjective cannot specify the design.
- Option 4: No site-independent design distance is supplied.

**CDCS-Q0126 · single · mechanism**

Why review adjacent doors and service openings in a security barrier?

Synthetic training case — not a field record.

A room wall has an approved fire-resisting assembly. A contractor adds a cable opening using unspecified foam. Replacement glazing is advertised as security glass but has no evidence for the project’s specified fire and forced-entry performance. A door is held open for deliveries. The security team proposes disabling emergency release to improve access control.

1. Doors are never part of physical security
2. Only the strongest component determines every entry path
3. A camera automatically compensates for any physical weakness
4. They may provide a weaker route around the strengthened element

**Correct option(s):** 4

- Option 1: They are common access paths.
- Option 2: An attacker or event may affect another opening.
- Option 3: Detection and resistance are different functions.
- Option 4: Performance depends on the complete boundary.

**CDCS-Q0127 · single · operations**

What is the issue with holding the door open?

Synthetic training case — not a field record.

A room wall has an approved fire-resisting assembly. A contractor adds a cable opening using unspecified foam. Replacement glazing is advertised as security glass but has no evidence for the project’s specified fire and forced-entry performance. A door is held open for deliveries. The security team proposes disabling emergency release to improve access control.

1. A badge reader guarantees the door is physically closed
2. Every delivery must permanently stop
3. It can defeat the intended barrier and access-control condition
4. A door’s rating is irrelevant once installed

**Correct option(s):** 3

- Option 1: Access records do not prove door position.
- Option 2: A controlled arrangement may be feasible.
- Option 3: The delivery process needs an approved method preserving required functions.
- Option 4: Its operating state can affect the barrier.

**CDCS-Q0128 · single · operations**

How should the proposed emergency-release change be handled?

Synthetic training case — not a field record.

A room wall has an approved fire-resisting assembly. A contractor adds a cable opening using unspecified foam. Replacement glazing is advertised as security glass but has no evidence for the project’s specified fire and forced-entry performance. A door is held open for deliveries. The security team proposes disabling emergency release to improve access control.

1. Let a dashboard operator choose the setting informally
2. Disable it immediately because security is the only objective
3. Review it with the competent life-safety and security authorities
4. Assume the course’s access-control chapter authorizes it

**Correct option(s):** 3

- Option 1: The change requires appropriate authority and design review.
- Option 2: Life-safety requirements remain.
- Option 3: Security must not silently defeat required egress behavior.
- Option 4: Study does not approve a live building change.

**CDCS-Q0129 · single · implementation**

What should post-installation inspection compare?

Synthetic training case — not a field record.

A room wall has an approved fire-resisting assembly. A contractor adds a cable opening using unspecified foam. Replacement glazing is advertised as security glass but has no evidence for the project’s specified fire and forced-entry performance. A door is held open for deliveries. The security team proposes disabling emergency release to improve access control.

1. Only the central wall area away from all openings
2. Only the delivery certificates for the specified materials
3. Actual products, supports, joints, penetrations and operating conditions with the accepted detail
4. Only the product labels visible on accessible wall panels

**Correct option(s):** 3

- Option 1: Interfaces can be the critical deviations.
- Option 2: Correct delivered products do not prove the installed assembly, joints, supports or penetrations match the accepted detail.
- Option 3: The assembled installation determines the relevant performance.
- Option 4: Labels on selected components do not verify the completed assembly or its interfaces.

**CDCS-Q0130 · single · operations**

What can an integration engineer properly verify here?

Synthetic training case — not a field record.

A room wall has an approved fire-resisting assembly. A contractor adds a cable opening using unspecified foam. Replacement glazing is advertised as security glass but has no evidence for the project’s specified fire and forced-entry performance. A door is held open for deliveries. The security team proposes disabling emergency release to improve access control.

1. The agreed sensor/alarm/access interfaces within assigned scope
2. Universal blast resistance of any replacement wall
3. A new legal egress requirement without the authority’s review
4. Fire rating solely from a successful network ping

**Correct option(s):** 1

- Option 1: That supports the accepted barrier design without certifying specialist construction.
- Option 2: That exceeds the stated competence and evidence.
- Option 3: Applicable rules require their proper process.
- Option 4: Communications do not prove physical fire performance.

**CDCS-Q0131 · single · mechanism**

What does a rocking panel suggest should be inspected?

Synthetic training case — not a field record.

After a cable addition, one raised-floor panel rocks, a cut panel has an unsupported edge, and unused cable openings remain unsealed in an air plenum. A perforated tile was moved to a hot rack without an airflow review. A rack restraint attaches only to the removable panel, with no documented structural load path. New ceiling equipment is fixed to a grid whose allowed loads are unknown.

1. Only the panel’s catalogue load rating without its supports
2. Seating, level, supports and component condition
3. Only the rack’s software version
4. Nothing if the nominal panel rating is high

**Correct option(s):** 2

- Option 1: The assembled installation can fail to meet the catalogue conditions.
- Option 2: The assembled floor may not provide the intended stable load path.
- Option 3: That does not affect panel seating.
- Option 4: A rating assumes appropriate installation conditions.

**CDCS-Q0132 · single · mechanism**

Why is the unsupported cut edge a concern?

Synthetic training case — not a field record.

After a cable addition, one raised-floor panel rocks, a cut panel has an unsupported edge, and unused cable openings remain unsealed in an air plenum. A perforated tile was moved to a hot rack without an airflow review. A rack restraint attaches only to the removable panel, with no documented structural load path. New ceiling equipment is fixed to a grid whose allowed loads are unknown.

1. All cut panels are forbidden in every system
2. The adjacent panel necessarily carries the load safely
3. The modified panel may lack the required supporting detail
4. A small opening automatically increases load capacity

**Correct option(s):** 3

- Option 1: Manufacturer-approved details may permit them.
- Option 2: Load transfer must be designed and verified.
- Option 3: Cutting can change its load path and system performance.
- Option 4: Removing material does not establish added strength.

**CDCS-Q0133 · single · operations**

What can unsealed unused plenum openings cause?

Synthetic training case — not a field record.

After a cable addition, one raised-floor panel rocks, a cut panel has an unsupported edge, and unused cable openings remain unsealed in an air plenum. A perforated tile was moved to a hot rack without an airflow review. A rack restraint attaches only to the removable panel, with no documented structural load path. New ceiling equipment is fixed to a grid whose allowed loads are unknown.

1. A higher structural panel rating
2. Automatic elimination of pressure differences
3. Guaranteed improvement at every rack
4. Air bypass that changes intended distribution

**Correct option(s):** 4

- Option 1: Sealing and structural capacity are different properties.
- Option 2: Actual flow depends on the complete system.
- Option 3: More uncontrolled leakage is not necessarily useful airflow.
- Option 4: Openings can divert air away from useful delivery paths.

**CDCS-Q0134 · single · mechanism**

Why review the moved perforated tile?

Synthetic training case — not a field record.

After a cable addition, one raised-floor panel rocks, a cut panel has an unsupported edge, and unused cable openings remain unsealed in an air plenum. A perforated tile was moved to a hot rack without an airflow review. A rack restraint attaches only to the removable panel, with no documented structural load path. New ceiling equipment is fixed to a grid whose allowed loads are unknown.

1. Perforated tiles can never be relocated
2. Open-area percentage alone proves delivered airflow
3. Its location changes airflow distribution and may affect other racks
4. A hot rack always requires the nearest tile to be fully open

**Correct option(s):** 3

- Option 1: Controlled changes may be appropriate.
- Option 2: Pressure and obstructions also matter.
- Option 3: A local response can alter the wider system.
- Option 4: The correct solution depends on the airflow mechanism.

**CDCS-Q0135 · single · operations**

What should substantiate delivered tile airflow?

Synthetic training case — not a field record.

After a cable addition, one raised-floor panel rocks, a cut panel has an unsupported edge, and unused cable openings remain unsealed in an air plenum. A perforated tile was moved to a hot rack without an airflow review. A rack restraint attaches only to the removable panel, with no documented structural load path. New ceiling equipment is fixed to a grid whose allowed loads are unknown.

1. Only the number of holes without pressure information
2. Only the tile’s catalogue airflow at an unspecified test pressure
3. Only the rack’s electrical nameplate
4. Measurements or a validated model under the relevant system conditions

**Correct option(s):** 4

- Option 1: Flow depends on more than count.
- Option 2: Catalogue flow does not establish delivery at the installed plenum pressure and system resistance.
- Option 3: Load indicates demand, not actual air delivery.
- Option 4: Nominal open area alone is insufficient.

**CDCS-Q0136 · single · mechanism**

Why is the restraint attachment not yet a verified seismic solution?

Synthetic training case — not a field record.

After a cable addition, one raised-floor panel rocks, a cut panel has an unsupported edge, and unused cable openings remain unsealed in an air plenum. A perforated tile was moved to a hot rack without an airflow review. A rack restraint attaches only to the removable panel, with no documented structural load path. New ceiling equipment is fixed to a grid whose allowed loads are unknown.

1. The restraint can be accepted solely because its bolt is tight
2. Any visible bolt guarantees all seismic performance
3. The load path from rack through attachment into the structure is undocumented
4. Racks never require seismic review

**Correct option(s):** 3

- Option 1: Tightness alone does not establish substrate, anchor or load-path adequacy.
- Option 2: Anchor presence is not a complete design.
- Option 3: A removable panel alone does not establish the engineered restraint.
- Option 4: Requirements depend on location and design.

**CDCS-Q0137 · single · design**

What information should the restraint review include?

Synthetic training case — not a field record.

After a cable addition, one raised-floor panel rocks, a cut panel has an unsupported edge, and unused cable openings remain unsealed in an air plenum. A perforated tile was moved to a hot rack without an airflow review. A rack restraint attaches only to the removable panel, with no documented structural load path. New ceiling equipment is fixed to a grid whose allowed loads are unknown.

1. Only the rack’s static weight without the restraint load case
2. Applicable design, substrate, anchors, installation and relative movement interfaces
3. Only the number of cable ties installed
4. Only a universal bolt size selected by this course

**Correct option(s):** 2

- Option 1: Seismic restraint requires its applicable design actions and connections.
- Option 2: The complete system governs performance.
- Option 3: Cable ties are not a substitute for the engineered system.
- Option 4: No site-independent anchor design is supplied.

**CDCS-Q0138 · single · operations**

What is required before adding the ceiling equipment load?

Synthetic training case — not a field record.

After a cable addition, one raised-floor panel rocks, a cut panel has an unsupported edge, and unused cable openings remain unsealed in an air plenum. A perforated tile was moved to a hot rack without an airflow review. A rack restraint attaches only to the removable panel, with no documented structural load path. New ceiling equipment is fixed to a grid whose allowed loads are unknown.

1. Only a matching ceiling tile size
2. Verification of the approved support system and load path
3. Only confirmation that the equipment is small
4. Only the installer’s ability to lift it by hand

**Correct option(s):** 2

- Option 1: Fit does not establish strength.
- Option 2: Unknown grid capability cannot be assumed adequate.
- Option 3: Small appearance does not quantify load or support.
- Option 4: Handling ability is not structural acceptance.

**CDCS-Q0139 · single · operations**

Which ceiling interfaces may change with the new layout?

Synthetic training case — not a field record.

After a cable addition, one raised-floor panel rocks, a cut panel has an unsupported edge, and unused cable openings remain unsealed in an air plenum. A perforated tile was moved to a hot rack without an airflow review. A rack restraint attaches only to the removable panel, with no documented structural load path. New ceiling equipment is fixed to a grid whose allowed loads are unknown.

1. Only decorative appearance
2. Detection, suppression, airflow, lighting and maintenance access
3. Only the network routing table
4. None if the grid remains level

**Correct option(s):** 2

- Option 1: The layout has functional interfaces.
- Option 2: Ceiling work can affect multiple required functions.
- Option 3: Logical routing does not describe physical ceiling effects.
- Option 4: Level does not prove all interfaces unchanged.

**CDCS-Q0140 · single · implementation**

What is a defensible completion record?

Synthetic training case — not a field record.

After a cable addition, one raised-floor panel rocks, a cut panel has an unsupported edge, and unused cable openings remain unsealed in an air plenum. A perforated tile was moved to a hot rack without an airflow review. A rack restraint attaches only to the removable panel, with no documented structural load path. New ceiling equipment is fixed to a grid whose allowed loads are unknown.

1. Reviewed deviations, corrected configuration, inspections and remaining restrictions
2. Inspection records that omit the altered floor-edge section
3. A copied original acceptance with a new date
4. A statement that cabling is complete with no floor review

**Correct option(s):** 1

- Option 1: It links the accepted state to evidence and owners.
- Option 2: Omitting the changed area leaves the known support deviation unverified.
- Option 3: The changed installation requires its own relevant verification.
- Option 4: The work introduced material floor and ceiling issues.

#### Recall

**A site with intact buildings but exposed dependencies — Synthetic training case — not a field record.

Site A has low quoted land cost. Its two fiber routes cross one bridge; the fuel delivery route and staff access use the same road. A drainage study is pending. Site B costs more but has documented alternate access and separate fiber routes. Neither site has an accepted full hazard/capacity review. The owner values continuous service during a regional storm.**

Compare the sites on the same service and hazard boundary. Site A has identifiable common dependencies, while Site B’s documented alternatives address only those aspects. Complete the competent hazard, utility and operating review before claiming either site meets the full requirement.

**Rack mass, local contact and transport route — Synthetic training case — not a field record.

A loaded rack has mass 1200 kg and footprint 0.6 m × 1.2 m. Use g=9.81 m/s² for this training calculation. It rests on four small feet. The quoted floor limit is a distributed-load value; no point or rolling-load evidence is supplied. A 150 kg moving cradle is used through a lift rated 1300 kg. A proposed cable tray would hang from an unverified ceiling grid.**

Rack weight is 11.772 kN and footprint-average pressure is 16.35 kPa, but foot contacts and floor-system ratings require separate review. Rack plus cradle is 1350 kg, exceeding the supplied lift rating before any other load. The tray needs an approved supporting load path rather than an assumed ceiling-grid capacity.

**A rated wall with an unreviewed penetration — Synthetic training case — not a field record.

A room wall has an approved fire-resisting assembly. A contractor adds a cable opening using unspecified foam. Replacement glazing is advertised as security glass but has no evidence for the project’s specified fire and forced-entry performance. A door is held open for deliveries. The security team proposes disabling emergency release to improve access control.**

Assess the modified complete assemblies with the competent fire/building/security owners. Unspecified penetration material and unsupported glazing claims do not preserve the approved performance. Delivery control and security changes must retain required life-safety and egress behavior.

**Raised-floor and ceiling deviations after cabling work — Synthetic training case — not a field record.

After a cable addition, one raised-floor panel rocks, a cut panel has an unsupported edge, and unused cable openings remain unsealed in an air plenum. A perforated tile was moved to a hot rack without an airflow review. A rack restraint attaches only to the removable panel, with no documented structural load path. New ceiling equipment is fixed to a grid whose allowed loads are unknown.**

Hold acceptance of the deviations and refer load/restraint details to the responsible specialists. Restore the approved floor and airflow configuration through controlled work, verify the complete supports and penetrations, and review ceiling/detection/suppression interfaces. Visual presence of an anchor does not establish seismic performance.

#### References

- [EPI CDCS public syllabus](https://www.epi-ap.com/services/1/3/5)

## CDCS-M04 — Electrical quantities, diagrams and protective design review

### CDCS-L04 — Electrical quantities, diagrams and protective design review

Estimated study time: 120 minutes before independent work. Prerequisite chapters: CDCS-L03

## Read electrical quantities before comparing capacity

Electrical design review begins with quantities and assumptions. For direct current in a simple resistive circuit, power is voltage times current and resistance relates them through V = I R. Alternating-current systems require RMS values and attention to phase relationships and waveform distortion. Apparent power S is expressed in volt-amperes, real power P in watts, and power factor is P/S. Under a balanced sinusoidal three-phase assumption, S = √3 × line-to-line voltage × line current. Real power is S multiplied by power factor. Do not insert phase-to-neutral voltage into the line-to-line formula or apply the balanced model to an unbalanced waveform without qualification.

At 400 V line-to-line and 100 A, apparent power is approximately 69.28 kVA. At power factor 0.90, real power is approximately 62.35 kW. A source may be constrained by both current/apparent power and real-power capability, so checking only one rating can miss a limit. For sinusoidal conditions, reactive power follows Q² = S² − P² with appropriate sign conventions; distorted conditions require more careful power-quality interpretation. Displacement power factor concerns the fundamental phase relationship, while true power factor includes the effect of distortion. A correction that improves the fundamental phase angle does not necessarily eliminate harmonic current.

Load estimates should distinguish measured demand, expected coincidence, nameplates, growth and required degraded states. A diversity factor or demand assumption is not an unexplained discount applied to make a design fit. Preserve the evidence and operating conditions that support it. AI or other rapidly varying loads can create transient and aggregation behavior not represented by a long-period average. The responsible electrical designer validates source, distribution and protective requirements; the integration engineer ensures the measurements and controls represent the agreed quantities and limits accurately.

## Use the single-line diagram as a functional model

A single-line diagram summarizes electrical connectivity and relevant equipment without drawing every conductor. Read its legend, revision, normal positions, source identities, ratings, protection, earthing and interlocks. Trace a load backward through distribution, conversion and transfer paths to every possible source, including generators, UPS energy storage, bypass paths and backfeed possibilities. A diagram is a design or record artifact, not proof of present isolation. Current field state, approved procedures and authorized verification govern physical work.

A UPS normal path and a bypass path may share upstream or downstream dependencies. Maintenance bypass can preserve load supply while changing conditioning or protection characteristics. A closed bypass does not mean the equipment being serviced is isolated from every source. Identify the designed operating states and interlocks, but do not derive a live switching sequence from a simplified teaching diagram. Preserve specialist-approved procedures and site authority. Compare the as-built diagram with asset labels and EPMS points so operators do not act on an incorrectly named source or breaker.

## Protective coordination is more than choosing a current number

Overcurrent protection addresses overload and short-circuit conditions through the selected device's characteristics and the installation design. A common screening relationship is that design load current should not exceed the selected protective rating/setting, which should not exceed the relevant corrected conductor capacity, with further conditions required by the applicable method. This is a review aid, not a complete cable or protection design. Installation method, grouping, ambient temperature, insulation, harmonics and other conditions affect conductor capability. Use the actual applicable standards and manufacturer data through a competent designer.

Breaking capacity must suit the prospective fault duty and the approved system arrangement. A 10 kA device cannot simply be assumed adequate for an 18 kA prospective fault because its normal current rating is high enough. Supported backup/cascading arrangements, if used, need the actual manufacturer's tested coordination evidence and applicable design approval; do not infer them from adjacent devices. Minimum fault current and disconnection behavior also matter. A generator or inverter source can produce a different fault-current profile from the utility, so protection must be reviewed in every relevant source state.

Selectivity aims to limit interruption to the appropriate part of the installation for defined fault conditions. It requires time-current, energy and device coordination evidence across the relevant range, not merely descending breaker ampere ratings. A larger upstream rating may still trip for some events. Protection and availability objectives must be reconciled without defeating required safety functions. The controls or EPMS engineer can verify indications, alarms, time stamps and records; setting protective devices and approving the coordination study remain specialist responsibilities.

## Residual current, earthing and protective conductors

A residual-current device compares current in the intended live conductors passing through its sensing arrangement. In a simple single-phase example, current leaving through line and returning through neutral balances when no current leaves that intended path. A difference can indicate current flowing elsewhere. The protective conductor is not intended to carry normal load current as a substitute neutral. Earthing/bonding and automatic disconnection arrangements depend on the system design and applicable requirements; an RCD does not make missing protective conductors or damaged insulation acceptable.

RCD selection includes the relevant residual waveform, sensitivity, timing, compatibility, coordination and application. An ordinary residual-current function is not automatically an overload/short-circuit protective function; combined devices must be identified by their actual capabilities. Electronic loads can contribute normal leakage and waveform components that matter to selection and grouping. Adding the estimated leakage gives a screening quantity, but it does not establish a universal nuisance-trip threshold or permission to weaken protection. Investigate actual measurements, manufacturer limits and the competent design response.

A trip is a condition to investigate through authorized procedures, not an instruction to bypass the device until service returns. Distinguish real insulation faults, cumulative normal leakage, wiring errors, transient effects and incompatible device selection using appropriate evidence. A monitoring alarm can support diagnosis, but it does not replace a required protective trip. The app's analytical cases do not authorize live testing or contact with exposed conductors. Preserve the field competence and permit requirements assigned in the curriculum.

## Surge protection, cables and rack distribution

Surge protective devices limit transient overvoltage within their designed function and installation conditions. They are not a substitute for every form of voltage regulation, overcurrent protection or lightning protection. Selection considers the system voltage and earthing arrangement, expected surge duty, protection level, coordination, backup protection and equipment withstand. Connection layout matters because conductor impedance during a fast transient can add voltage at the protected equipment. A device's catalogue protection level does not automatically equal the installed equipment-terminal voltage under every event. Status and end-of-life indication need a maintained response.

Cable review combines continuous current, voltage drop, short-circuit withstand, protective conductor/neutral requirements, installation conditions and mechanical/fire constraints. For a supplied simple resistive loop model, voltage drop is I × total loop resistance. At 20 A and 0.20 Ω, drop is 4 V, about 1.74% of 230 V. The example intentionally excludes reactance, temperature change and nonlinear effects; it is not a complete AC installation design. Confirm whether a quoted resistance is one conductor or the complete loop before using it. A small calculated voltage drop does not prove current-carrying or fault withstand adequacy.

Rack PDUs have input, branch, outlet and sometimes phase limits. A total nameplate does not permit any individual outlet or phase to exceed its rating. Review load placement and failure transfer: dual-power equipment may shift more load to one surviving path. Phase balance can reduce avoidable imbalance, but triplen harmonic currents from certain nonlinear loads can add in a neutral rather than cancel as balanced fundamental currents do. The actual load waveform and wiring system determine the analysis. Measurements must identify RMS, harmonic, phase and timing semantics accurately.

The design-review deliverable should state assumptions, equations, component data, relevant source states, unresolved coordination and acceptance evidence. Use it to ask precise questions of electrical specialists and suppliers. Keep the monitoring/control interface faithful to their accepted design, and retain clear boundaries between numerical literacy, approved design and executed physical work.


#### Worked demonstrations

**Balanced three-phase load and dual ratings**

Synthetic training case — not a field record.

A synthetic balanced sinusoidal three-phase load draws 100 A line current at 400 V line-to-line with power factor 0.90. Use √3=1.732. A proposed source is rated 70 kVA and 60 kW continuously under the same conditions. A meter displays displacement PF only; future nonlinear loads are being considered.

**Reasoning:** S=1.732×400×100=69280 VA=69.28 kVA. P=69.28×0.90=62.352 kW. The source passes the apparent-power quantity but exceeds its 60 kW real-power rating. A displacement-PF reading alone may not describe true PF when future loads distort current.

**Reading a bypass path without inventing switching authority**

Synthetic training case — not a field record.

The supplied abstract SLD has utility U feeding UPS rectifier R, inverter I and output bus O. A static bypass also connects U to O. A maintenance bypass connects U directly to the load bus L, downstream of O. Battery B feeds the UPS DC link. The diagram is revision 4; the installed bypass label refers to revision 3. No switching procedure or verified field state is supplied.

**Reasoning:** Trace all possible sources and paths, including battery energy and bypass. A bypass supply path does not itself establish UPS isolation. Resolve the drawing/label discrepancy and use the specialist-approved site procedure; this abstract topology is not a safe live switching sequence.

**A protective device that passes one check and fails two**

Synthetic training case — not a field record.

A circuit’s design load current is 100 A. The proposed protective setting is 125 A. Corrected conductor capacity under the supplied installation conditions is 110 A. Prospective short-circuit current is 18 kA; the proposed device’s breaking capacity is 10 kA at the relevant voltage. No approved backup/cascading combination is supplied. A generator source has a different fault-current profile from utility operation.

**Reasoning:** The load is below the protective setting, but the setting exceeds corrected conductor capacity. The standalone breaking capacity is also below the prospective fault duty. Resolve both through the competent design process; do not assume an undocumented backup combination or utility-only coordination applies on generator.

**Residual current and electronic-load leakage**

Synthetic training case — not a field record.

A synthetic single-phase circuit measures 10.000 A leaving in line and 9.976 A returning in neutral through the sensing arrangement. Six electronic loads each have a stated 4 mA normal leakage estimate. A proposed RCD is labeled 30 mA; its full type, tolerance and coordination data have not been reviewed. A technician suggests removing PE or bypassing the RCD to prevent trips.

**Reasoning:** The supplied difference is 24 mA, matching the simple sum of six 4 mA estimates, but this does not prove the actual cause or a guaranteed trip threshold. Review waveform, wiring, measured leakage and device selection through competent personnel. Never treat removal of PE or bypassing required protection as the design solution.

**Cable drop, rack limits and an SPD installation**

Synthetic training case — not a field record.

A simple resistive teaching model has a 230 V source, 20 A current and 0.20 Ω total loop resistance; ignore reactance and temperature change. A rack PDU total rating is adequate, but one outlet is rated 10 A and its proposed load is 12 A. A surge device has an appropriate catalogue selection under review, yet its connecting leads are much longer than the approved installation detail. No installed surge test is supplied.

**Reasoning:** The model gives 4 V drop, or about 1.74% of 230 V. That does not prove cable current/fault capability. The 12 A load exceeds the individual 10 A outlet regardless of total PDU capacity. SPD connection geometry affects installed protection; reconcile it with the approved detail and specialist review.

#### Guided practice

Calculate the three-phase source mismatch and cable drop, then produce a review register for the SLD, protective device, residual-current and SPD cases.

**Hint:** Keep kW and kVA, diagram and field state, overcurrent and residual-current duties, and catalogue versus installed behavior distinct.

**Worked solution:** The load is 69.28 kVA and 62.352 kW, exceeding the source kW rating. The 125 A setting exceeds corrected 110 A conductor capacity, and 10 kA breaking capacity does not cover the supplied 18 kA duty without supported coordination. The 24 mA difference is a diagnostic observation, not permission to remove protection. Cable drop is 4 V or 1.74%, and the 12 A outlet load exceeds its 10 A limit.

#### Independent task

Environment: analytical

Prepare an electrical interface-review worksheet using only supplied synthetic values.

**Packaged starter material**

- course_labs/CDCS/README.md
- course_labs/CDCS/fixture.json
- course_labs/CDCS/assessment_template.md
- course_labs/CDCS/lab.py
- course_labs/CDCS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- Units and assumption-aware calculations
- SLD source/path and revision review
- Protection/earthing questions for the competent designer
- PDU and SPD deviation/acceptance register

**Acceptance criteria**

- No electrical setting or live switching sequence is invented.
- Every rating comparison uses the relevant conditions and component boundary.
- Analytical screening is clearly separated from specialist approval and field execution.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer.

#### Chapter practice

**CDCS-Q0141 · single · calculation**

What is the load’s apparent power?

Synthetic training case — not a field record.

A synthetic balanced sinusoidal three-phase load draws 100 A line current at 400 V line-to-line with power factor 0.90. Use √3=1.732. A proposed source is rated 70 kVA and 60 kW continuously under the same conditions. A meter displays displacement PF only; future nonlinear loads are being considered.

1. 62.352 kVA
2. 40 kVA
3. 69.28 kVA
4. 120 kVA

**Correct option(s):** 3

- Option 1: That applies power factor to apparent power and mislabels the result.
- Option 2: That omits the √3 factor for the stated quantities.
- Option 3: Use the balanced three-phase line-to-line formula.
- Option 4: That multiplies line-to-line voltage by three rather than √3.

**CDCS-Q0142 · single · calculation**

What is the real power?

Synthetic training case — not a field record.

A synthetic balanced sinusoidal three-phase load draws 100 A line current at 400 V line-to-line with power factor 0.90. Use √3=1.732. A proposed source is rated 70 kVA and 60 kW continuously under the same conditions. A meter displays displacement PF only; future nonlinear loads are being considered.

1. 76.978 kW
2. 69.28 kW
3. 36 kW
4. 62.352 kW

**Correct option(s):** 4

- Option 1: That divides by power factor instead of multiplying.
- Option 2: That assumes unity power factor.
- Option 3: That uses a single-phase product with the supplied line quantities.
- Option 4: 69.28 kVA multiplied by 0.90 gives real power.

**CDCS-Q0143 · single · operations**

Which proposed source limit is exceeded?

Synthetic training case — not a field record.

A synthetic balanced sinusoidal three-phase load draws 100 A line current at 400 V line-to-line with power factor 0.90. Use √3=1.732. A proposed source is rated 70 kVA and 60 kW continuously under the same conditions. A meter displays displacement PF only; future nonlinear loads are being considered.

1. Both limits
2. Only the 70 kVA limit
3. The 60 kW real-power limit
4. Neither because kVA is the only relevant rating

**Correct option(s):** 3

- Option 1: Only the real-power quantity exceeds its stated rating.
- Option 2: The apparent load is below 70 kVA.
- Option 3: 62.352 kW is above it while 69.28 kVA is below 70.
- Option 4: The separate real-power capability also constrains the source.

**CDCS-Q0144 · single · mechanism**

Why must line-to-line voltage be identified in the formula?

Synthetic training case — not a field record.

A synthetic balanced sinusoidal three-phase load draws 100 A line current at 400 V line-to-line with power factor 0.90. Use √3=1.732. A proposed source is rated 70 kVA and 60 kW continuously under the same conditions. A meter displays displacement PF only; future nonlinear loads are being considered.

1. Voltage reference never affects three-phase power
2. Every three-phase system has exactly 400 V
3. Line-to-line and phase-to-neutral voltages are always equal
4. The √3 relationship assumes the stated line quantities

**Correct option(s):** 4

- Option 1: Line and phase quantities differ.
- Option 2: This is only the supplied example.
- Option 3: They are not equal in the stated balanced system.
- Option 4: Using a different voltage basis changes the calculation.

**CDCS-Q0145 · single · operations**

What assumption limits this calculation?

Synthetic training case — not a field record.

A synthetic balanced sinusoidal three-phase load draws 100 A line current at 400 V line-to-line with power factor 0.90. Use √3=1.732. A proposed source is rated 70 kVA and 60 kW continuously under the same conditions. A meter displays displacement PF only; future nonlinear loads are being considered.

1. That a meter reading authorizes electrical work
2. Balanced sinusoidal operation at the supplied values
3. That all future loads will have the same power factor
4. That the source can ignore its thermal conditions

**Correct option(s):** 2

- Option 1: A measurement does not grant authority.
- Option 2: Unbalance and distortion require appropriate analysis.
- Option 3: No such future evidence is supplied.
- Option 4: The ratings are explicitly conditional.

**CDCS-Q0146 · single · mechanism**

What does power factor P/S compare?

Synthetic training case — not a field record.

A synthetic balanced sinusoidal three-phase load draws 100 A line current at 400 V line-to-line with power factor 0.90. Use √3=1.732. A proposed source is rated 70 kVA and 60 kW continuously under the same conditions. A meter displays displacement PF only; future nonlinear loads are being considered.

1. Line voltage with phase voltage
2. Real power with apparent power
3. Energy with elapsed time
4. Fault current with protective rating

**Correct option(s):** 2

- Option 1: That is a voltage relationship.
- Option 2: The ratio expresses how much apparent-power demand corresponds to real power.
- Option 3: That gives average power, a different relationship.
- Option 4: That is a protection comparison.

**CDCS-Q0147 · single · mechanism**

Why might displacement PF alone be insufficient for future nonlinear loads?

Synthetic training case — not a field record.

A synthetic balanced sinusoidal three-phase load draws 100 A line current at 400 V line-to-line with power factor 0.90. Use √3=1.732. A proposed source is rated 70 kVA and 60 kW continuously under the same conditions. A meter displays displacement PF only; future nonlinear loads are being considered.

1. Displacement PF measures only temperature
2. A current waveform cannot contain harmonics
3. It omits distortion effects included in true power factor
4. Nonlinear loads always have zero real power

**Correct option(s):** 3

- Option 1: It concerns the fundamental electrical phase relationship.
- Option 2: Nonlinear loads can produce them.
- Option 3: Fundamental phase angle is not the entire waveform relationship.
- Option 4: They can consume substantial real power.

**CDCS-Q0148 · single · operations**

What would an improved fundamental phase angle fail to prove?

Synthetic training case — not a field record.

A synthetic balanced sinusoidal three-phase load draws 100 A line current at 400 V line-to-line with power factor 0.90. Use √3=1.732. A proposed source is rated 70 kVA and 60 kW continuously under the same conditions. A meter displays displacement PF only; future nonlinear loads are being considered.

1. That apparent power uses volt-ampere units
2. That harmonic current has been eliminated
3. That the load still has a fundamental component
4. That the measured displacement PF changed

**Correct option(s):** 2

- Option 1: The unit definition is independent of the correction.
- Option 2: Phase correction and harmonic distortion are different issues.
- Option 3: The phase-angle statement concerns it.
- Option 4: That is the stated improvement.

**CDCS-Q0149 · single · design**

What should an updated source selection review include?

Synthetic training case — not a field record.

A synthetic balanced sinusoidal three-phase load draws 100 A line current at 400 V line-to-line with power factor 0.90. Use √3=1.732. A proposed source is rated 70 kVA and 60 kW continuously under the same conditions. A meter displays displacement PF only; future nonlinear loads are being considered.

1. Only the source’s short-duration overload rating
2. Both kW/kVA limits, operating conditions, waveform and required states
3. Only normal-load average kW
4. Only the kVA rating, assuming it also equals available kW

**Correct option(s):** 2

- Option 1: A brief overload rating does not establish continuous capability or all required load states.
- Option 2: A single headline rating is incomplete.
- Option 3: Transient and degraded-state requirements may matter.
- Option 4: Real-power and apparent-power limits are separate constraints for the supplied power factor and waveform.

**CDCS-Q0150 · single · operations**

What should the learner do with the detected rating mismatch?

Synthetic training case — not a field record.

A synthetic balanced sinusoidal three-phase load draws 100 A line current at 400 V line-to-line with power factor 0.90. Use √3=1.732. A proposed source is rated 70 kVA and 60 kW continuously under the same conditions. A meter displays displacement PF only; future nonlinear loads are being considered.

1. Raise the source’s software current limit without approval
2. Ignore the kW limit because apparent power nearly fits
3. Relabel the load as 60 kW
4. Record it and request a supported design resolution from the responsible specialist

**Correct option(s):** 4

- Option 1: That does not change its certified capability and exceeds authority.
- Option 2: The exceeded limit remains material.
- Option 3: Changing a label cannot remove the calculated demand.
- Option 4: The calculation identifies a review issue.

**CDCS-Q0151 · single · operations**

Which source can support the UPS DC link independently of the utility input in the diagram?

Synthetic training case — not a field record.

The supplied abstract SLD has utility U feeding UPS rectifier R, inverter I and output bus O. A static bypass also connects U to O. A maintenance bypass connects U directly to the load bus L, downstream of O. Battery B feeds the UPS DC link. The diagram is revision 4; the installed bypass label refers to revision 3. No switching procedure or verified field state is supplied.

1. Only the maintenance bypass
2. Battery B
3. Only the static bypass
4. Output bus O as a new energy source

**Correct option(s):** 2

- Option 1: It connects utility to the load bus.
- Option 2: It is explicitly connected to the DC link.
- Option 3: That is a utility-to-output AC path in the supplied diagram.
- Option 4: A bus distributes energy rather than creating it.

**CDCS-Q0152 · single · operations**

What common source do the normal and static-bypass paths share here?

Synthetic training case — not a field record.

The supplied abstract SLD has utility U feeding UPS rectifier R, inverter I and output bus O. A static bypass also connects U to O. A maintenance bypass connects U directly to the load bus L, downstream of O. Battery B feeds the UPS DC link. The diagram is revision 4; the installed bypass label refers to revision 3. No switching procedure or verified field state is supplied.

1. Separate sources implied by different path names
2. Utility U
3. Two independently verified substations
4. The maintenance log database

**Correct option(s):** 2

- Option 1: Different names do not create source independence.
- Option 2: Both originate from the same stated utility source.
- Option 3: The diagram provides only U.
- Option 4: It is not an electrical source in this model.

**CDCS-Q0153 · single · mechanism**

What does the maintenance bypass provide in this abstract topology?

Synthetic training case — not a field record.

The supplied abstract SLD has utility U feeding UPS rectifier R, inverter I and output bus O. A static bypass also connects U to O. A maintenance bypass connects U directly to the load bus L, downstream of O. Battery B feeds the UPS DC link. The diagram is revision 4; the installed bypass label refers to revision 3. No switching procedure or verified field state is supplied.

1. Automatic voltage conditioning identical to the inverter
2. Proof that every UPS terminal is isolated
3. A utility path directly to load bus L
4. A second independent battery system

**Correct option(s):** 3

- Option 1: The bypass path does not establish that behavior.
- Option 2: Other paths and stored energy remain to be assessed.
- Option 3: Its function is distinct from the normal UPS conversion path.
- Option 4: No such source is shown.

**CDCS-Q0154 · single · mechanism**

Why can the diagram not prove present isolation?

Synthetic training case — not a field record.

The supplied abstract SLD has utility U feeding UPS rectifier R, inverter I and output bus O. A static bypass also connects U to O. A maintenance bypass connects U directly to the load bus L, downstream of O. Battery B feeds the UPS DC link. The diagram is revision 4; the installed bypass label refers to revision 3. No switching procedure or verified field state is supplied.

1. Single-line diagrams cannot show useful connectivity
2. Revision numbers always prove field positions
3. It records connectivity, not verified current field state and absence of energy
4. A drawn open symbol removes all stored energy automatically

**Correct option(s):** 3

- Option 1: They are useful for functional understanding.
- Option 2: A revision identifies a document state, not live positions.
- Option 3: Physical work requires the approved verification process.
- Option 4: Actual conditions and other sources must be verified.

**CDCS-Q0155 · single · operations**

What is the immediate document-control issue?

Synthetic training case — not a field record.

The supplied abstract SLD has utility U feeding UPS rectifier R, inverter I and output bus O. A static bypass also connects U to O. A maintenance bypass connects U directly to the load bus L, downstream of O. Battery B feeds the UPS DC link. The diagram is revision 4; the installed bypass label refers to revision 3. No switching procedure or verified field state is supplied.

1. The drawing contains more than one path
2. The load bus appears downstream
3. The battery has a different letter from the utility
4. The installed label and current drawing reference different revisions

**Correct option(s):** 4

- Option 1: Multiple paths can be legitimate.
- Option 2: That alone is not a defect.
- Option 3: Distinct labels are appropriate.
- Option 4: The mismatch needs reconciliation before reliance.

**CDCS-Q0156 · single · operations**

What should be checked when evaluating bypass operation?

Synthetic training case — not a field record.

The supplied abstract SLD has utility U feeding UPS rectifier R, inverter I and output bus O. A static bypass also connects U to O. A maintenance bypass connects U directly to the load bus L, downstream of O. Battery B feeds the UPS DC link. The diagram is revision 4; the installed bypass label refers to revision 3. No switching procedure or verified field state is supplied.

1. Which conditioning, protection and source dependencies apply in that state
2. Only whether the load indicator remains illuminated
3. Only the original battery capacity
4. Only the UPS’s normal efficiency figure

**Correct option(s):** 1

- Option 1: Bypass behavior may differ from the normal path.
- Option 2: An indicator does not establish all required characteristics.
- Option 3: Bypass supply has a different source path.
- Option 4: That may not describe bypass operation.

**CDCS-Q0157 · single · operations**

What should govern a real switching sequence?

Synthetic training case — not a field record.

The supplied abstract SLD has utility U feeding UPS rectifier R, inverter I and output bus O. A static bypass also connects U to O. A maintenance bypass connects U directly to the load bus L, downstream of O. Battery B feeds the UPS DC link. The diagram is revision 4; the installed bypass label refers to revision 3. No switching procedure or verified field state is supplied.

1. Any sequence that keeps the dashboard green
2. The shortest path on the diagram alone
3. The order in which components are named in this question
4. The approved site procedure, competent personnel and verified conditions

**Correct option(s):** 4

- Option 1: Display status is not a complete operational criterion.
- Option 2: Topology does not resolve interlocks or safe transitions.
- Option 3: Narrative order is not an operating sequence.
- Option 4: A simplified teaching topology is not sufficient authority.

**CDCS-Q0158 · single · implementation**

What should EPMS point mapping preserve?

Synthetic training case — not a field record.

The supplied abstract SLD has utility U feeding UPS rectifier R, inverter I and output bus O. A static bypass also connects U to O. A maintenance bypass connects U directly to the load bus L, downstream of O. Battery B feeds the UPS DC link. The diagram is revision 4; the installed bypass label refers to revision 3. No switching procedure or verified field state is supplied.

1. Only visually similar breaker icons
2. Only aggregate power, with no path state
3. Correct source/device identity, state semantics and accepted drawing relationships
4. Only the old revision’s labels because they are familiar

**Correct option(s):** 3

- Option 1: Appearance does not prove identity.
- Option 2: Path state may be necessary for operation and diagnosis.
- Option 3: Operators need indications tied to the actual arrangement.
- Option 4: Familiarity does not resolve the mismatch.

**CDCS-Q0159 · single · design**

What should a design review ask about interlocks?

Synthetic training case — not a field record.

The supplied abstract SLD has utility U feeding UPS rectifier R, inverter I and output bus O. A static bypass also connects U to O. A maintenance bypass connects U directly to the load bus L, downstream of O. Battery B feeds the UPS DC link. The diagram is revision 4; the installed bypass label refers to revision 3. No switching procedure or verified field state is supplied.

1. Which incompatible states they prevent and how the accepted behavior is verified
2. Only whether an interlock word appears on the drawing
3. Whether an IP ping succeeds to the UPS
4. Whether they can all be bypassed to speed maintenance

**Correct option(s):** 1

- Option 1: Interlocks support controlled transitions within their design.
- Option 2: A label is not a functional specification.
- Option 3: Reachability does not test the interlock logic.
- Option 4: Removing them can defeat intended constraints.

**CDCS-Q0160 · single · design**

What is a defensible outcome from this paper review?

Synthetic training case — not a field record.

The supplied abstract SLD has utility U feeding UPS rectifier R, inverter I and output bus O. A static bypass also connects U to O. A maintenance bypass connects U directly to the load bus L, downstream of O. Battery B feeds the UPS DC link. The diagram is revision 4; the installed bypass label refers to revision 3. No switching procedure or verified field state is supplied.

1. Proof that the battery is discharged
2. A source/path map and unresolved state/label questions for authorized resolution
3. A completed electrical isolation certificate
4. A command to close the maintenance bypass now

**Correct option(s):** 2

- Option 1: The diagram shows a connection, not its energy state.
- Option 2: It supports preparation without claiming executed isolation.
- Option 3: No field verification occurred.
- Option 4: The case lacks procedure and authority.

**CDCS-Q0161 · single · calculation**

Which simple screening relationship passes?

Synthetic training case — not a field record.

A circuit’s design load current is 100 A. The proposed protective setting is 125 A. Corrected conductor capacity under the supplied installation conditions is 110 A. Prospective short-circuit current is 18 kA; the proposed device’s breaking capacity is 10 kA at the relevant voltage. No approved backup/cascading combination is supplied. A generator source has a different fault-current profile from utility operation.

1. All protection checks pass because one inequality passes
2. 125 A setting is below 110 A conductor capacity
3. 10 kA breaking capacity exceeds 18 kA prospective current
4. 100 A design current is below the 125 A setting

**Correct option(s):** 4

- Option 1: Independent constraints remain.
- Option 2: It is greater, so this fails.
- Option 3: It is lower, so this fails.
- Option 4: That one inequality is satisfied.

**CDCS-Q0162 · single · operations**

What is the conductor-protection mismatch?

Synthetic training case — not a field record.

A circuit’s design load current is 100 A. The proposed protective setting is 125 A. Corrected conductor capacity under the supplied installation conditions is 110 A. Prospective short-circuit current is 18 kA; the proposed device’s breaking capacity is 10 kA at the relevant voltage. No approved backup/cascading combination is supplied. A generator source has a different fault-current profile from utility operation.

1. The load is 10 A below conductor capacity
2. The 125 A setting exceeds the supplied 110 A corrected capacity
3. The conductor capacity exceeds the load
4. The protective rating is expressed in amperes

**Correct option(s):** 2

- Option 1: That difference is not the mismatch.
- Option 2: The proposed setting does not satisfy this screening relationship.
- Option 3: That is favorable for this particular quantity.
- Option 4: That is the relevant unit.

**CDCS-Q0163 · single · calculation**

What is the standalone fault-duty mismatch?

Synthetic training case — not a field record.

A circuit’s design load current is 100 A. The proposed protective setting is 125 A. Corrected conductor capacity under the supplied installation conditions is 110 A. Prospective short-circuit current is 18 kA; the proposed device’s breaking capacity is 10 kA at the relevant voltage. No approved backup/cascading combination is supplied. A generator source has a different fault-current profile from utility operation.

1. The normal load is below 18 kA
2. 10 kA breaking capacity is below 18 kA prospective fault current
3. The cable capacity is 110 A
4. The breaker has a 125 A setting

**Correct option(s):** 2

- Option 1: Normal load does not establish breaking capability.
- Option 2: The device is not justified by the supplied standalone rating.
- Option 3: That does not resolve device interruption duty.
- Option 4: Normal current setting and fault interruption rating are distinct.

**CDCS-Q0164 · single · operations**

Can an assumed upstream backup device automatically resolve the 10 kA limit?

Synthetic training case — not a field record.

A circuit’s design load current is 100 A. The proposed protective setting is 125 A. Corrected conductor capacity under the supplied installation conditions is 110 A. Prospective short-circuit current is 18 kA; the proposed device’s breaking capacity is 10 kA at the relevant voltage. No approved backup/cascading combination is supplied. A generator source has a different fault-current profile from utility operation.

1. Yes, if the upstream enclosure is larger
2. No; the actual supported combination and applicable approval need evidence
3. No manufacturer-supported backup arrangement can ever exist
4. Yes, any upstream breaker raises all downstream ratings

**Correct option(s):** 2

- Option 1: Physical size does not establish tested coordination.
- Option 2: Backup coordination cannot be invented.
- Option 3: Such arrangements can exist but are not supplied here.
- Option 4: Only supported arrangements justify such claims.

**CDCS-Q0165 · single · mechanism**

Why use corrected conductor capacity rather than a generic catalogue value?

Synthetic training case — not a field record.

A circuit’s design load current is 100 A. The proposed protective setting is 125 A. Corrected conductor capacity under the supplied installation conditions is 110 A. Prospective short-circuit current is 18 kA; the proposed device’s breaking capacity is 10 kA at the relevant voltage. No approved backup/cascading combination is supplied. A generator source has a different fault-current profile from utility operation.

1. The protective device can define cable capacity arbitrarily
2. Correction can be omitted whenever the cable is new
3. Installation conditions can change allowable current
4. Catalogue values are always false

**Correct option(s):** 3

- Option 1: Protection must respect the actual conductor design.
- Option 2: Age does not remove installation-condition derating.
- Option 3: Grouping, ambient and other factors matter.
- Option 4: They are conditional data requiring correct application.

**CDCS-Q0166 · single · design**

What must be reviewed for generator operation?

Synthetic training case — not a field record.

A circuit’s design load current is 100 A. The proposed protective setting is 125 A. Corrected conductor capacity under the supplied installation conditions is 110 A. Prospective short-circuit current is 18 kA; the proposed device’s breaking capacity is 10 kA at the relevant voltage. No approved backup/cascading combination is supplied. A generator source has a different fault-current profile from utility operation.

1. Nothing because all AC sources produce identical fault current
2. Fault-current profile and protective response in that source state
3. Only the generator’s normal full-load current
4. Only the normal utility short-circuit value

**Correct option(s):** 2

- Option 1: Source characteristics vary.
- Option 2: Utility-only assumptions may not apply.
- Option 3: Fault response can differ from normal operating current.
- Option 4: The alternate source is stated to differ.

**CDCS-Q0167 · single · mechanism**

What does selectivity seek for defined faults?

Synthetic training case — not a field record.

A circuit’s design load current is 100 A. The proposed protective setting is 125 A. Corrected conductor capacity under the supplied installation conditions is 110 A. Prospective short-circuit current is 18 kA; the proposed device’s breaking capacity is 10 kA at the relevant voltage. No approved backup/cascading combination is supplied. A generator source has a different fault-current profile from utility operation.

1. Limit interruption to the appropriate part of the installation
2. Replace conductor sizing with alarm monitoring
3. Prevent every protective device from ever tripping
4. Maximize the number of disconnected healthy circuits

**Correct option(s):** 1

- Option 1: Coordination controls how protection propagates service loss.
- Option 2: Monitoring does not remove physical protection requirements.
- Option 3: Protection must still clear required faults.
- Option 4: That is contrary to selective interruption.

**CDCS-Q0168 · single · mechanism**

Why are descending breaker ampere ratings alone insufficient for selectivity?

Synthetic training case — not a field record.

A circuit’s design load current is 100 A. The proposed protective setting is 125 A. Corrected conductor capacity under the supplied installation conditions is 110 A. Prospective short-circuit current is 18 kA; the proposed device’s breaking capacity is 10 kA at the relevant voltage. No approved backup/cascading combination is supplied. A generator source has a different fault-current profile from utility operation.

1. Selectivity is determined only by cable length
2. Time-current and energy behavior across the fault range also matter
3. Every larger upstream rating guarantees no upstream trip
4. Ampere ratings have no role in design

**Correct option(s):** 2

- Option 1: Length affects conditions but does not replace device coordination.
- Option 2: Different devices can interact despite their nominal ratings.
- Option 3: That is not universally true.
- Option 4: They matter but are not the entire analysis.

**CDCS-Q0169 · single · operations**

What should the integration engineer verify after specialist approval?

Synthetic training case — not a field record.

A circuit’s design load current is 100 A. The proposed protective setting is 125 A. Corrected conductor capacity under the supplied installation conditions is 110 A. Prospective short-circuit current is 18 kA; the proposed device’s breaking capacity is 10 kA at the relevant voltage. No approved backup/cascading combination is supplied. A generator source has a different fault-current profile from utility operation.

1. Correct EPMS identities, indications, alarms and evidence interfaces
2. New protective settings chosen without the study
3. Removal of protective trips to improve uptime
4. A software label that conceals the 10 kA device

**Correct option(s):** 1

- Option 1: These are integration responsibilities around the accepted design.
- Option 2: That would assume specialist authority.
- Option 3: Availability does not justify defeating protection.
- Option 4: Labeling cannot resolve the physical duty.

**CDCS-Q0170 · single · design**

What is the proper review disposition now?

Synthetic training case — not a field record.

A circuit’s design load current is 100 A. The proposed protective setting is 125 A. Corrected conductor capacity under the supplied installation conditions is 110 A. Prospective short-circuit current is 18 kA; the proposed device’s breaking capacity is 10 kA at the relevant voltage. No approved backup/cascading combination is supplied. A generator source has a different fault-current profile from utility operation.

1. Declare every product in the proposal defective
2. Hold the affected design acceptance and request supported corrections
3. Accept because the load is only 100 A
4. Authorize live testing to destruction by the learner

**Correct option(s):** 2

- Option 1: The issue is suitability of the proposed application, not proven product defect.
- Option 2: Two material mismatches and source-state evidence remain.
- Option 3: That passes only one screening check.
- Option 4: No such authority or safe test basis is provided.

**CDCS-Q0171 · single · calculation**

What is the measured line-neutral difference?

Synthetic training case — not a field record.

A synthetic single-phase circuit measures 10.000 A leaving in line and 9.976 A returning in neutral through the sensing arrangement. Six electronic loads each have a stated 4 mA normal leakage estimate. A proposed RCD is labeled 30 mA; its full type, tolerance and coordination data have not been reviewed. A technician suggests removing PE or bypassing the RCD to prevent trips.

1. 24 mA
2. 24 A
3. 9.976 mA
4. 0.024 mA

**Correct option(s):** 1

- Option 1: 10.000 minus 9.976 is 0.024 A.
- Option 2: That multiplies rather than converts the small difference.
- Option 3: That confuses return current with residual current.
- Option 4: That fails to convert amperes to milliamperes.

**CDCS-Q0172 · single · calculation**

What is the simple sum of the six stated leakage estimates?

Synthetic training case — not a field record.

A synthetic single-phase circuit measures 10.000 A leaving in line and 9.976 A returning in neutral through the sensing arrangement. Six electronic loads each have a stated 4 mA normal leakage estimate. A proposed RCD is labeled 30 mA; its full type, tolerance and coordination data have not been reviewed. A technician suggests removing PE or bypassing the RCD to prevent trips.

1. 30 mA
2. 4 mA
3. 24 mA
4. 6 mA

**Correct option(s):** 3

- Option 1: That is the device label, not the estimated sum.
- Option 2: That counts only one load.
- Option 3: Six times 4 mA equals 24 mA.
- Option 4: That uses the number of loads as current.

**CDCS-Q0173 · single · mechanism**

Does agreement between the estimate and difference prove the cause?

Synthetic training case — not a field record.

A synthetic single-phase circuit measures 10.000 A leaving in line and 9.976 A returning in neutral through the sensing arrangement. Six electronic loads each have a stated 4 mA normal leakage estimate. A proposed RCD is labeled 30 mA; its full type, tolerance and coordination data have not been reviewed. A technician suggests removing PE or bypassing the RCD to prevent trips.

1. No; actual waveform, wiring and measurement conditions still need investigation
2. Yes, it proves every load is fault-free
3. No, arithmetic can never support a diagnostic hypothesis
4. Yes, it proves the device must trip at exactly 24 mA

**Correct option(s):** 1

- Option 1: Numerical agreement alone is not complete diagnosis.
- Option 2: Other conditions can contribute to the measurement.
- Option 3: It can support a bounded hypothesis requiring validation.
- Option 4: The full device behavior is not supplied.

**CDCS-Q0174 · single · mechanism**

What does the residual-current function fundamentally compare?

Synthetic training case — not a field record.

A synthetic single-phase circuit measures 10.000 A leaving in line and 9.976 A returning in neutral through the sensing arrangement. Six electronic loads each have a stated 4 mA normal leakage estimate. A proposed RCD is labeled 30 mA; its full type, tolerance and coordination data have not been reviewed. A technician suggests removing PE or bypassing the RCD to prevent trips.

1. Current balance through the intended live-conductor sensing arrangement
2. Only room humidity with a threshold
3. Only real power with apparent power
4. Only line voltage with equipment nameplate voltage

**Correct option(s):** 1

- Option 1: A difference indicates current outside that intended return balance.
- Option 2: That is unrelated to the sensing function.
- Option 3: That is a power-factor relationship.
- Option 4: That is not the residual-current mechanism.

**CDCS-Q0175 · single · mechanism**

Why is removing PE not an acceptable remedy?

Synthetic training case — not a field record.

A synthetic single-phase circuit measures 10.000 A leaving in line and 9.976 A returning in neutral through the sensing arrangement. Six electronic loads each have a stated 4 mA normal leakage estimate. A proposed RCD is labeled 30 mA; its full type, tolerance and coordination data have not been reviewed. A technician suggests removing PE or bypassing the RCD to prevent trips.

1. PE determines the application’s network throughput
2. PE is the intended normal neutral return
3. It can defeat the required protective path and does not properly resolve leakage
4. Removing PE guarantees zero electric-shock risk

**Correct option(s):** 3

- Option 1: That does not address the electrical protection duty.
- Option 2: It should not substitute for normal load neutral.
- Option 3: Protective conductors are not optional nuisance controls.
- Option 4: It can increase danger.

**CDCS-Q0176 · single · operations**

What should be checked about RCD type for electronic loads?

Synthetic training case — not a field record.

A synthetic single-phase circuit measures 10.000 A leaving in line and 9.976 A returning in neutral through the sensing arrangement. Six electronic loads each have a stated 4 mA normal leakage estimate. A proposed RCD is labeled 30 mA; its full type, tolerance and coordination data have not been reviewed. A technician suggests removing PE or bypassing the RCD to prevent trips.

1. Only the load’s Ethernet speed
2. Only enclosure width
3. Compatibility with relevant residual-current waveforms and the application
4. Only the number 30 without the rest of the specification

**Correct option(s):** 3

- Option 1: Network speed does not define residual-current waveform.
- Option 2: Fit does not establish sensing suitability.
- Option 3: Different waveform conditions affect appropriate selection.
- Option 4: Sensitivity alone is incomplete.

**CDCS-Q0177 · single · operations**

Does an ordinary RCD automatically provide overload protection?

Synthetic training case — not a field record.

A synthetic single-phase circuit measures 10.000 A leaving in line and 9.976 A returning in neutral through the sensing arrangement. Six electronic loads each have a stated 4 mA normal leakage estimate. A proposed RCD is labeled 30 mA; its full type, tolerance and coordination data have not been reviewed. A technician suggests removing PE or bypassing the RCD to prevent trips.

1. No circuit containing an RCD needs a cable rating
2. No; verify whether the actual device includes the required overcurrent functions
3. Yes, every RCD is a combined overcurrent device
4. Only if its indicator is green

**Correct option(s):** 2

- Option 1: Conductor design remains necessary.
- Option 2: Residual-current and overcurrent duties are distinct.
- Option 3: Device forms and functions differ.
- Option 4: Indicator state does not establish protective function set.

**CDCS-Q0178 · single · operations**

What should happen after repeated trips?

Synthetic training case — not a field record.

A synthetic single-phase circuit measures 10.000 A leaving in line and 9.976 A returning in neutral through the sensing arrangement. Six electronic loads each have a stated 4 mA normal leakage estimate. A proposed RCD is labeled 30 mA; its full type, tolerance and coordination data have not been reviewed. A technician suggests removing PE or bypassing the RCD to prevent trips.

1. Replace PE with a network cable shield
2. Increase the threshold arbitrarily until trips stop
3. Bypass the RCD until the next annual visit
4. Investigate through authorized procedures and competent design/maintenance review

**Correct option(s):** 4

- Option 1: That is not a valid protective-conductor solution.
- Option 2: Selection and coordination require the proper design basis.
- Option 3: That removes a required protective function without resolving cause.
- Option 4: The response must preserve required protection.

**CDCS-Q0179 · single · operations**

What can a residual-current monitor contribute?

Synthetic training case — not a field record.

A synthetic single-phase circuit measures 10.000 A leaving in line and 9.976 A returning in neutral through the sensing arrangement. Six electronic loads each have a stated 4 mA normal leakage estimate. A proposed RCD is labeled 30 mA; its full type, tolerance and coordination data have not been reviewed. A technician suggests removing PE or bypassing the RCD to prevent trips.

1. Proof of insulation integrity under every fault
2. Guaranteed automatic disconnection regardless of model
3. Alarm and trend evidence within its specified function
4. Permission to omit protective bonding

**Correct option(s):** 3

- Option 1: A single trend cannot establish all conditions.
- Option 2: A monitor may only indicate.
- Option 3: Monitoring does not automatically replace a required trip device.
- Option 4: Monitoring does not remove that duty.

**CDCS-Q0180 · single · design**

What is the correct status of the 30 mA label in this review?

Synthetic training case — not a field record.

A synthetic single-phase circuit measures 10.000 A leaving in line and 9.976 A returning in neutral through the sensing arrangement. Six electronic loads each have a stated 4 mA normal leakage estimate. A proposed RCD is labeled 30 mA; its full type, tolerance and coordination data have not been reviewed. A technician suggests removing PE or bypassing the RCD to prevent trips.

1. A complete substitute for site protection design
2. One selection parameter requiring the full applicable specification
3. A promise that any 29.9 mA condition can never trip
4. A promise that every 30.0 mA waveform trips identically

**Correct option(s):** 2

- Option 1: Other requirements remain.
- Option 2: It is not a guaranteed universal operating threshold by itself.
- Option 3: Device behavior and conditions require proper data.
- Option 4: Waveform and device characteristics matter.

**CDCS-Q0181 · single · calculation**

What is the voltage drop in the supplied resistive model?

Synthetic training case — not a field record.

A simple resistive teaching model has a 230 V source, 20 A current and 0.20 Ω total loop resistance; ignore reactance and temperature change. A rack PDU total rating is adequate, but one outlet is rated 10 A and its proposed load is 12 A. A surge device has an appropriate catalogue selection under review, yet its connecting leads are much longer than the approved installation detail. No installed surge test is supplied.

1. 4 V
2. 100 V
3. 0.01 V
4. 46 V

**Correct option(s):** 1

- Option 1: 20 A multiplied by 0.20 Ω equals 4 V.
- Option 2: That divides current by resistance.
- Option 3: That divides resistance by current.
- Option 4: That multiplies source voltage by resistance without the required current relationship.

**CDCS-Q0182 · single · calculation**

What percentage of 230 V is the calculated drop?

Synthetic training case — not a field record.

A simple resistive teaching model has a 230 V source, 20 A current and 0.20 Ω total loop resistance; ignore reactance and temperature change. A rack PDU total rating is adequate, but one outlet is rated 10 A and its proposed load is 12 A. A surge device has an appropriate catalogue selection under review, yet its connecting leads are much longer than the approved installation detail. No installed surge test is supplied.

1. Approximately 1.74%
2. 0.0174%
3. 17.4%
4. 4%

**Correct option(s):** 1

- Option 1: 4 divided by 230 and multiplied by 100 gives 1.739.
- Option 2: That omits the percentage conversion correctly.
- Option 3: That is a factor-of-ten error.
- Option 4: Four volts is not four percent of 230 V.

**CDCS-Q0183 · single · mechanism**

Why does the calculation use total loop resistance?

Synthetic training case — not a field record.

A simple resistive teaching model has a 230 V source, 20 A current and 0.20 Ω total loop resistance; ignore reactance and temperature change. A rack PDU total rating is adequate, but one outlet is rated 10 A and its proposed load is 12 A. A surge device has an appropriate catalogue selection under review, yet its connecting leads are much longer than the approved installation detail. No installed surge test is supplied.

1. The source voltage already includes every future cable drop
2. Loop resistance is identical to every single-conductor value
3. The complete outgoing and return path contributes to this simple voltage drop
4. Only the protective earth carries all normal return current

**Correct option(s):** 3

- Option 1: The model explicitly calculates a distribution drop.
- Option 2: The quantities differ.
- Option 3: Using only one conductor would omit part of the model.
- Option 4: That is not the intended normal load path.

**CDCS-Q0184 · single · diagnosis**

What remains unproven by the small drop?

Synthetic training case — not a field record.

A simple resistive teaching model has a 230 V source, 20 A current and 0.20 Ω total loop resistance; ignore reactance and temperature change. A rack PDU total rating is adequate, but one outlet is rated 10 A and its proposed load is 12 A. A surge device has an appropriate catalogue selection under review, yet its connecting leads are much longer than the approved installation detail. No installed surge test is supplied.

1. That the model excludes reactance
2. Current-carrying capacity, fault withstand and protective coordination
3. That 20 times 0.20 equals 4
4. That the supplied source is 230 V

**Correct option(s):** 2

- Option 1: The premise explicitly states it.
- Option 2: Voltage drop is only one design check.
- Option 3: The arithmetic establishes that.
- Option 4: That is a given training value.

**CDCS-Q0185 · single · operations**

What limits the proposed 12 A outlet load?

Synthetic training case — not a field record.

A simple resistive teaching model has a 230 V source, 20 A current and 0.20 Ω total loop resistance; ignore reactance and temperature change. A rack PDU total rating is adequate, but one outlet is rated 10 A and its proposed load is 12 A. A surge device has an appropriate catalogue selection under review, yet its connecting leads are much longer than the approved installation detail. No installed surge test is supplied.

1. Only the PDU’s total rating
2. The individual outlet’s 10 A rating
3. Only the upstream feeder’s larger current rating
4. Only the average current across all PDU outlets

**Correct option(s):** 2

- Option 1: Branch and outlet limits also apply.
- Option 2: Total PDU headroom does not override a local component limit.
- Option 3: An upstream rating does not increase the outlet limit.
- Option 4: An average can conceal the overloaded individual outlet.

**CDCS-Q0186 · single · design**

What should a dual-power rack review examine after loss of one feed?

Synthetic training case — not a field record.

A simple resistive teaching model has a 230 V source, 20 A current and 0.20 Ω total loop resistance; ignore reactance and temperature change. A rack PDU total rating is adequate, but one outlet is rated 10 A and its proposed load is 12 A. A surge device has an appropriate catalogue selection under review, yet its connecting leads are much longer than the approved installation detail. No installed surge test is supplied.

1. The surviving path’s resulting load at input, branch, outlet and phase limits
2. Only the pre-failure half-load on each feed
3. Only the combined nameplate of both unavailable and available paths
4. Only the number of power cords

**Correct option(s):** 1

- Option 1: Failure transfer can increase demand on the remaining path.
- Option 2: That may understate the surviving-path condition.
- Option 3: An unavailable path cannot carry the required load.
- Option 4: Cord count does not establish capacity.

**CDCS-Q0187 · single · mechanism**

Why do long SPD leads matter?

Synthetic training case — not a field record.

A simple resistive teaching model has a 230 V source, 20 A current and 0.20 Ω total loop resistance; ignore reactance and temperature change. A rack PDU total rating is adequate, but one outlet is rated 10 A and its proposed load is 12 A. A surge device has an appropriate catalogue selection under review, yet its connecting leads are much longer than the approved installation detail. No installed surge test is supplied.

1. Longer leads always improve clamping proportionally
2. Lead length affects only appearance
3. Connection impedance during a fast transient can add voltage at the protected equipment
4. Any SPD makes all connection details irrelevant

**Correct option(s):** 3

- Option 1: They can worsen the installed voltage behavior.
- Option 2: Electrical transient behavior can be affected.
- Option 3: Catalogue performance depends on installation conditions.
- Option 4: The complete installation matters.

**CDCS-Q0188 · single · operations**

Which statement correctly bounds the SPD’s protective role?

Synthetic training case — not a field record.

A simple resistive teaching model has a 230 V source, 20 A current and 0.20 Ω total loop resistance; ignore reactance and temperature change. A rack PDU total rating is adequate, but one outlet is rated 10 A and its proposed load is 12 A. A surge device has an appropriate catalogue selection under review, yet its connecting leads are much longer than the approved installation detail. No installed surge test is supplied.

1. Its specified transient-limiting function does not replace the complete regulation, overcurrent and lightning-protection design
2. Any installed SPD regulates every sustained overvoltage
3. A correct catalogue model makes lead geometry irrelevant
4. An SPD removes the need for upstream overcurrent protection

**Correct option(s):** 1

- Option 1: Those duties require their own supported design.
- Option 2: Transient limiting does not imply complete sustained-voltage regulation.
- Option 3: Installed connections can affect the equipment-terminal transient voltage.
- Option 4: Its surge function does not replace all overcurrent duties.

**CDCS-Q0189 · single · operations**

What should happen when an SPD indicates end of life?

Synthetic training case — not a field record.

A simple resistive teaching model has a 230 V source, 20 A current and 0.20 Ω total loop resistance; ignore reactance and temperature change. A rack PDU total rating is adequate, but one outlet is rated 10 A and its proposed load is 12 A. A surge device has an appropriate catalogue selection under review, yet its connecting leads are much longer than the approved installation detail. No installed surge test is supplied.

1. Treat it as proof of a current IT outage
2. Follow the approved inspection/replacement response and assess protection status
3. Ignore it while the load remains powered
4. Disable every upstream protective device

**Correct option(s):** 2

- Option 1: Loss of protection and loss of load supply are different conditions.
- Option 2: The indication can mean the intended protection is no longer available.
- Option 3: Continued supply does not prove surge protection remains.
- Option 4: That is unrelated and can defeat safety.

**CDCS-Q0190 · single · design**

What review action follows the lead-length deviation?

Synthetic training case — not a field record.

A simple resistive teaching model has a 230 V source, 20 A current and 0.20 Ω total loop resistance; ignore reactance and temperature change. A rack PDU total rating is adequate, but one outlet is rated 10 A and its proposed load is 12 A. A surge device has an appropriate catalogue selection under review, yet its connecting leads are much longer than the approved installation detail. No installed surge test is supplied.

1. Claim the equipment-terminal surge voltage was measured
2. Accept solely because the SPD model number matches
3. Invent a universal allowable length from the quiz
4. Reconcile the installed arrangement with manufacturer/design requirements and verify the corrected state

**Correct option(s):** 4

- Option 1: No installed surge test is supplied.
- Option 2: Correct product identity does not prove correct installation.
- Option 3: The applicable detail and system design govern.
- Option 4: The deviation needs a supported resolution.

#### Recall

**Balanced three-phase load and dual ratings — Synthetic training case — not a field record.

A synthetic balanced sinusoidal three-phase load draws 100 A line current at 400 V line-to-line with power factor 0.90. Use √3=1.732. A proposed source is rated 70 kVA and 60 kW continuously under the same conditions. A meter displays displacement PF only; future nonlinear loads are being considered.**

S=1.732×400×100=69280 VA=69.28 kVA. P=69.28×0.90=62.352 kW. The source passes the apparent-power quantity but exceeds its 60 kW real-power rating. A displacement-PF reading alone may not describe true PF when future loads distort current.

**Reading a bypass path without inventing switching authority — Synthetic training case — not a field record.

The supplied abstract SLD has utility U feeding UPS rectifier R, inverter I and output bus O. A static bypass also connects U to O. A maintenance bypass connects U directly to the load bus L, downstream of O. Battery B feeds the UPS DC link. The diagram is revision 4; the installed bypass label refers to revision 3. No switching procedure or verified field state is supplied.**

Trace all possible sources and paths, including battery energy and bypass. A bypass supply path does not itself establish UPS isolation. Resolve the drawing/label discrepancy and use the specialist-approved site procedure; this abstract topology is not a safe live switching sequence.

**A protective device that passes one check and fails two — Synthetic training case — not a field record.

A circuit’s design load current is 100 A. The proposed protective setting is 125 A. Corrected conductor capacity under the supplied installation conditions is 110 A. Prospective short-circuit current is 18 kA; the proposed device’s breaking capacity is 10 kA at the relevant voltage. No approved backup/cascading combination is supplied. A generator source has a different fault-current profile from utility operation.**

The load is below the protective setting, but the setting exceeds corrected conductor capacity. The standalone breaking capacity is also below the prospective fault duty. Resolve both through the competent design process; do not assume an undocumented backup combination or utility-only coordination applies on generator.

**Residual current and electronic-load leakage — Synthetic training case — not a field record.

A synthetic single-phase circuit measures 10.000 A leaving in line and 9.976 A returning in neutral through the sensing arrangement. Six electronic loads each have a stated 4 mA normal leakage estimate. A proposed RCD is labeled 30 mA; its full type, tolerance and coordination data have not been reviewed. A technician suggests removing PE or bypassing the RCD to prevent trips.**

The supplied difference is 24 mA, matching the simple sum of six 4 mA estimates, but this does not prove the actual cause or a guaranteed trip threshold. Review waveform, wiring, measured leakage and device selection through competent personnel. Never treat removal of PE or bypassing required protection as the design solution.

**Cable drop, rack limits and an SPD installation — Synthetic training case — not a field record.

A simple resistive teaching model has a 230 V source, 20 A current and 0.20 Ω total loop resistance; ignore reactance and temperature change. A rack PDU total rating is adequate, but one outlet is rated 10 A and its proposed load is 12 A. A surge device has an appropriate catalogue selection under review, yet its connecting leads are much longer than the approved installation detail. No installed surge test is supplied.**

The model gives 4 V drop, or about 1.74% of 230 V. That does not prove cable current/fault capability. The 12 A load exceeds the individual 10 A outlet regardless of total PDU capacity. SPD connection geometry affects installed protection; reconcile it with the approved detail and specialist review.

#### References

- [EPI CDCS public syllabus](https://www.epi-ap.com/services/1/3/5)
- [Schneider Electric conductor sizing and protection guide](https://www.electrical-installation.org/enwiki/Sizing_and_protection_of_conductors)
- [Schneider Electric protection against shock and electrical fires](https://www.electrical-installation.org/enwiki/Protection_against_electric_shocks_and_electrical_fires)
- [Schneider Electric overvoltage protection guide](https://www.electrical-installation.org/enwiki/Overvoltage_protection)

## CDCS-M05 — Generation, UPS operating modes and waveform-aware power quality

### CDCS-L05 — Generation, UPS operating modes and waveform-aware power quality

Estimated study time: 120 minutes before independent work. Prerequisite chapters: CDCS-L04

## Generator capability depends on duty and supporting systems

A generator set combines an engine or other prime mover, alternator, fuel and starting systems, cooling, exhaust, controls, protection and supporting services. Its usable output depends on the specified duty rating, ambient conditions, altitude, fuel, load power factor, transient response and manufacturer limits. A quoted maximum output is not automatically a continuous operating promise. Diesel and gas-fueled sets have different fuel-supply and operating characteristics; select from a complete supported application rather than assuming one fuel type is universally best. Site emissions, noise, storage and permissions also require the applicable specialist review.

Starting and accepting load are separate milestones. A set may crank successfully yet fail to reach acceptable voltage/frequency, close through its approved transfer arrangement or sustain the applied load step. Large motor starts, transformer energization and electronic-load behavior can affect transient response. A load-bank result is bounded by the load type and conditions used; it does not automatically reproduce the site's full dynamic mixture. Review the sequence from loss detection through start, stabilization, transfer, load acceptance, sustained operation and return, with the responsible electrical and controls specialists.

Auxiliary dependencies can defeat nominal redundancy. Several generators may share a fuel-transfer pump supply, contaminated bulk tank, ventilation opening, starting-battery maintenance weakness or control network. Identify how fuel reaches each engine during the required event and how cooling/exhaust remain effective. A full bulk tank does not prove the day tank can be replenished when normal power is absent. Operations needs alarms, accessible service points, inspection requirements and recovery procedures that match the actual system. These interfaces belong in commissioning and maintenance evidence, not only in the equipment purchase specification.

## Calculate endurance with usable fuel and explicit demand

Geometric tank volume differs from usable operating fuel. Account for the supplied unusable volume, required reserve, present fill, consumption curve and the supported replenishment arrangement. In a simplified example, an 8000 L filled tank with 800 L unusable and a 1200 L reserve leaves 6000 L for the modeled operating period. At a constant 180 L/h, endurance is 6000/180 = 33.33 h. A 36 h requirement consumes 6480 L, leaving a 480 L gap. This model assumes constant consumption and no replenishment; it is not a fuel-system design or a universal autonomy requirement.

Use consumption data at the actual operating condition, not a single favorable catalogue point. Multiple sets may operate at different load fractions, and auxiliary consumption or test operation can matter. Replenishment during a regional event depends on access, supplier capability, transfer equipment, fuel quality and authority. Record whether a duration promise assumes delivery; a stored-fuel-only requirement cannot be met by silently including an unconfirmed truck. Fuel sampling, contamination control and storage obligations remain with the competent site process and applicable rules.

## Paralleling requires controlled electrical and mechanical behavior

Connecting AC sources in parallel requires the appropriate relationship among voltage magnitude, frequency, phase sequence and phase angle, using the supported synchronizing and protection system. The existence of two running engines does not establish a permissible connection. Out-of-condition connection can create severe currents and mechanical stress. This course explains what a design review must verify; it does not provide a manual live synchronization sequence. Interlocks, permissives, sensing, failure responses and authority must come from the approved equipment and site design.

Once sources are paralleled, load sharing is another function. In a simplified synchronous-generator explanation, prime-mover/governor action governs real-power sharing, while excitation/voltage-control behavior governs reactive-power sharing within the supported control scheme. Droop and isochronous arrangements have different coordination needs. An equal kW reading does not prove equal kVAr or current. Review controller compatibility, sensing polarity, communication dependency, loss-of-communication behavior and the transition when one source becomes unavailable. A control-network failover time alone does not establish acceptable electrical load sharing.

Protection includes the relevant source and bus conditions, such as reverse-power or other functions required by the actual design. The specific settings and coordination belong to competent specialists. The integration role is to preserve correct indications, time correlation, alarms and test evidence. A mismatch between a physical meter and a controller value needs investigation; it should not be corrected by changing the displayed scale until the underlying sensor and configuration are understood. Record product and firmware combinations because parallel operation can depend on supported versions and options.

## Select UPS behavior for the actual load and modes

UPS selection includes real and apparent output limits, input characteristics, efficiency by operating point/mode, output regulation, transient response, overload behavior, fault contribution, bypass requirements, battery/DC compatibility, communications, maintainability and service support. Topology names such as double conversion or line interactive describe broad mechanisms, not every product's behavior in every mode. In a double-conversion normal path, input conversion supplies a DC link and the inverter supplies the output; alternate modes and bypass paths can change power conditioning and transfer behavior. Verify the exact supported mode and load tolerance.

Efficiency is output real power divided by input real power at the stated point and boundary. A 300 kW output at 96% efficiency requires 312.5 kW input and produces 12.5 kW loss within that simplified boundary. Do not multiply output by efficiency to find required input. Losses become a thermal load and energy cost, but the calculation must state whether battery charging and other auxiliaries are included. A high efficiency at one loading point is not the annual result; evaluate the actual load profile and mode distribution. An economy mode may change the normal power path and transition behavior, so energy benefit must be assessed with service requirements.

Parallel UPS systems need a manufacturer-supported architecture with compatible modules, controls, firmware, cabling, bypass and DC arrangements. Equal nameplate ratings do not prove compatibility. Load-sharing errors, circulating currents or a common bypass/control dependency can undermine the intended result. A shared battery bank is not automatically equivalent to independent battery strings; fault isolation, protection, charging and maintenance must follow the supported design. Do not combine arbitrary modules or parallel their outputs based on a paper capacity sum. Commission normal sharing, defined unavailable states, bypass behavior and restoration with appropriate authority.

## Harmonics require waveform-aware evidence

A nonlinear load can draw nonsinusoidal current even when supplied by a nearly sinusoidal voltage. Harmonics are frequency components at integer multiples of the fundamental. For orthogonal harmonic components, total RMS current is the square root of the sum of squared component RMS values. If fundamental current is 100 A, third harmonic 40 A and fifth harmonic 30 A, total RMS is √(100²+40²+30²) ≈111.8 A. Current THD relative to the fundamental is √(40²+30²)/100 = 50%. This supplied model omits other harmonics and does not by itself predict every equipment temperature or voltage distortion.

In a four-wire system under the relevant balanced harmonic conditions, triplen components can add in the neutral while balanced fundamental currents cancel. Three equal 40 A third-harmonic phase components can therefore produce 120 A of that neutral component in the simplified model. Do not assume zero neutral current from balanced fundamental load alone. The full waveform, neutral sizing, protective arrangement and equipment ratings require the competent electrical design. Measurement should use suitable bandwidth and true-RMS/harmonic functions, with defined sampling and loading conditions.

Mitigation options include suitable equipment input design, active or passive filtering and system configuration changes. Selection depends on spectrum, source impedance, load variation and interactions. A capacitor bank selected only for displacement-power-factor correction can interact with inductance and create resonance; it is not a universal harmonic filter. An active filter also has rating, control and installation limits. Compare before/after spectra and relevant voltage/current behavior under representative source/load states. A lower THD percentage can coexist with a higher absolute harmonic current if the fundamental changes, so retain the underlying quantities.

The acceptance package links generator, UPS and harmonic decisions to the required service, manufacturer support and actual state evidence. Keep auxiliary dependencies, mode changes, maintenance and recovery visible. Analytical calculations support review; they do not replace the external vendor training, specialist design or authorized physical commissioning assigned in the curriculum.


#### Worked demonstrations

**Fuel endurance with reserve and a failed transfer dependency**

Synthetic training case — not a field record.

A filled tank contains 8000 L. The supplied design marks 800 L unusable and 1200 L as a reserve excluded from the autonomy calculation. At the modeled load, consumption is 180 L/h constant. Required stored-fuel endurance is 36 h without deliveries. The transfer pump is fed only from normal utility power; its outage behavior is unverified.

**Reasoning:** Usable modeled fuel is 6000 L, yielding 33.33 h. Thirty-six hours requires 6480 L, so the available quantity is 480 L short. Even that endurance depends on fuel reaching the engine; the utility-only pump is an unresolved common dependency.

**Generator synchronizing and unequal reactive sharing**

Synthetic training case — not a field record.

Two compatible generator sets are intended to parallel through a supported controller. A review packet records equal frequency but omits phase sequence and phase-angle evidence. Once operating in a synthetic recorded parallel state, both sets show 300 kW, but reactive outputs are 40 and 160 kVAr. Controller communication-loss behavior is undocumented. No live switching is authorized by this exercise.

**Reasoning:** Equal frequency is only one synchronizing condition. Review voltage, phase sequence/angle and the supported protection/permissive system. Equal real-power sharing does not prove reactive sharing; excitation/voltage-control behavior and sensing need competent investigation. Document communication-loss response rather than assuming the network recovers fast enough.

**UPS efficiency and a mode change with service consequences**

Synthetic training case — not a field record.

A UPS supplies 300 kW real output at stated 96% efficiency in double-conversion mode. The measurement boundary excludes battery charging. A proposed economy mode has higher steady efficiency but normally uses an alternate power path; its transition behavior with the actual IT load has not been tested. The supplier provides only one efficiency point, while site load varies through the day.

**Reasoning:** Input is 300/0.96=312.5 kW and modeled UPS loss is 12.5 kW, excluding charging. Economy-mode service behavior and annual energy performance need their own evidence. A single efficiency point cannot establish a variable-load annual result or acceptable transition behavior.

**Parallel UPS modules with incompatible assumptions**

Synthetic training case — not a field record.

Two UPS modules have the same nominal output rating but different firmware branches. Their proposed parallel combination is not listed in the supplied support matrix. A synthetic operating record from a vendor-approved test setup shows 230 kW on one module and 170 kW on the other for a 400 kW total; the agreed steady sharing criterion is within 10 kW of an equal split. Both depend on one bypass control supply. A shared battery proposal has no approved protection/charging diagram.

**Reasoning:** Equal split is 200 kW each; the recorded deviations are +30 and −30 kW, outside the supplied ±10 kW criterion. Resolve support compatibility separately from this test result. Shared bypass controls and the unsupported battery arrangement require complete design review; equal nameplates do not prove equivalent redundancy.

**Harmonic current with a loaded neutral**

Synthetic training case — not a field record.

A supplied synthetic phase-current spectrum contains 100 A fundamental, 40 A third harmonic and 30 A fifth harmonic, with all other components zero. Use orthogonal RMS summation. In a separate balanced four-wire model, each phase has an equal in-phase 40 A third-harmonic component in the neutral reference. A proposal adds a plain capacitor bank solely because displacement PF is low; no resonance study exists.

**Reasoning:** Total phase RMS is √12500≈111.8 A. Harmonic RMS is 50 A, so THDi relative to the 100 A fundamental is 50%. The three stated third-harmonic components sum to 120 A in the neutral model. A plain capacitor bank is not automatically a harmonic solution; evaluate spectrum and system interaction.

#### Guided practice

Review the generator/UPS supply chain from fuel quantity through transfer, sharing, conversion losses and harmonic effects.

**Hint:** Use supported operating states and explicit waveform assumptions; do not turn a calculation into a live control action.

**Worked solution:** Fuel endurance is 33.33 h with a 480 L gap to the 36 h model. Synchronizing requires more than equal frequency; equal kW does not prove reactive sharing. UPS input is 312.5 kW with 12.5 kW loss. The recorded parallel sharing exceeds its ±10 kW criterion. Phase RMS is 111.8 A, THDi 50%, and the stated third-harmonic neutral component 120 A.

#### Independent task

Environment: analytical

Prepare a source/UPS design-review workbook and commissioning evidence plan.

**Packaged starter material**

- course_labs/CDCS/README.md
- course_labs/CDCS/fixture.json
- course_labs/CDCS/assessment_template.md
- course_labs/CDCS/lab.py
- course_labs/CDCS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- Fuel and auxiliary dependency model
- Synchronizing/sharing interface questions
- UPS mode/efficiency comparison
- Parallel support and harmonic assessment register

**Acceptance criteria**

- Fuel, source, path and control dependencies are all included.
- Calculations retain their waveform and boundary assumptions.
- Vendor support, protection approval and physical tests remain separately evidenced.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer.

#### Chapter practice

**CDCS-Q0191 · single · calculation**

What fuel quantity is available to the stated autonomy model?

Synthetic training case — not a field record.

A filled tank contains 8000 L. The supplied design marks 800 L unusable and 1200 L as a reserve excluded from the autonomy calculation. At the modeled load, consumption is 180 L/h constant. Required stored-fuel endurance is 36 h without deliveries. The transfer pump is fed only from normal utility power; its outage behavior is unverified.

1. 6000 L
2. 8000 L
3. 7200 L
4. 6800 L

**Correct option(s):** 1

- Option 1: Subtract 800 unusable and 1200 reserved from 8000.
- Option 2: That ignores the excluded quantities.
- Option 3: That subtracts unusable volume but not the specified reserve.
- Option 4: That subtracts reserve but not unusable volume.

**CDCS-Q0192 · single · calculation**

What is the constant-consumption endurance?

Synthetic training case — not a field record.

A filled tank contains 8000 L. The supplied design marks 800 L unusable and 1200 L as a reserve excluded from the autonomy calculation. At the modeled load, consumption is 180 L/h constant. Required stored-fuel endurance is 36 h without deliveries. The transfer pump is fed only from normal utility power; its outage behavior is unverified.

1. 36 h
2. 44.44 h
3. Approximately 33.33 h
4. 30 h

**Correct option(s):** 3

- Option 1: That is the requirement, not the computed capability.
- Option 2: That uses the full tank without exclusions.
- Option 3: 6000 L divided by 180 L/h.
- Option 4: That is not the supplied volume/rate quotient.

**CDCS-Q0193 · single · calculation**

How much fuel does the 36-hour requirement consume in this model?

Synthetic training case — not a field record.

A filled tank contains 8000 L. The supplied design marks 800 L unusable and 1200 L as a reserve excluded from the autonomy calculation. At the modeled load, consumption is 180 L/h constant. Required stored-fuel endurance is 36 h without deliveries. The transfer pump is fed only from normal utility power; its outage behavior is unverified.

1. 6480 L
2. 180 L
3. 5000 L
4. 6000 L

**Correct option(s):** 1

- Option 1: 36 multiplied by 180 gives 6480.
- Option 2: That is one hour’s consumption.
- Option 3: That is not the supplied rate-duration product.
- Option 4: That is the available modeled quantity.

**CDCS-Q0194 · single · calculation**

What is the modeled fuel shortfall?

Synthetic training case — not a field record.

A filled tank contains 8000 L. The supplied design marks 800 L unusable and 1200 L as a reserve excluded from the autonomy calculation. At the modeled load, consumption is 180 L/h constant. Required stored-fuel endurance is 36 h without deliveries. The transfer pump is fed only from normal utility power; its outage behavior is unverified.

1. 1520 L
2. Zero because the tank holds 8000 L
3. 1200 L
4. 480 L

**Correct option(s):** 4

- Option 1: That compares required fuel to the full tank rather than available quantity.
- Option 2: Excluded volumes cannot be silently counted.
- Option 3: That is the specified reserve, not the computed gap.
- Option 4: 6480 required minus 6000 available.

**CDCS-Q0195 · single · mechanism**

Why does bulk volume not prove engine endurance?

Synthetic training case — not a field record.

A filled tank contains 8000 L. The supplied design marks 800 L unusable and 1200 L as a reserve excluded from the autonomy calculation. At the modeled load, consumption is 180 L/h constant. Required stored-fuel endurance is 36 h without deliveries. The transfer pump is fed only from normal utility power; its outage behavior is unverified.

1. Fuel must reach the engine through functioning transfer and auxiliary systems
2. A full tank automatically supplies every day tank without pumps
3. Fuel volume has no relationship to endurance
4. Generator output rating alone determines fuel delivery

**Correct option(s):** 1

- Option 1: The pump dependency remains unresolved.
- Option 2: The actual system has a pump dependency.
- Option 3: It is necessary but not sufficient.
- Option 4: Delivery equipment has separate functions.

**CDCS-Q0196 · single · operations**

What is the concern with utility-only pump power?

Synthetic training case — not a field record.

A filled tank contains 8000 L. The supplied design marks 800 L unusable and 1200 L as a reserve excluded from the autonomy calculation. At the modeled load, consumption is 180 L/h constant. Required stored-fuel endurance is 36 h without deliveries. The transfer pump is fed only from normal utility power; its outage behavior is unverified.

1. Utility-fed auxiliaries are always forbidden universally
2. The transfer function may be unavailable during the event requiring generator operation
3. The concern disappears if the pump is new
4. The pump necessarily consumes all fuel immediately

**Correct option(s):** 2

- Option 1: The actual supported design and required event need review.
- Option 2: The supporting source can fail with utility loss.
- Option 3: Age does not remove the source dependency.
- Option 4: No such behavior is stated.

**CDCS-Q0197 · single · design**

Can an unconfirmed emergency delivery close this stored-fuel requirement?

Synthetic training case — not a field record.

A filled tank contains 8000 L. The supplied design marks 800 L unusable and 1200 L as a reserve excluded from the autonomy calculation. At the modeled load, consumption is 180 L/h constant. Required stored-fuel endurance is 36 h without deliveries. The transfer pump is fed only from normal utility power; its outage behavior is unverified.

1. Yes, any nearby fuel supplier guarantees availability
2. Yes, because the remaining gap is less than a tank
3. No delivery can ever support any endurance plan
4. No; the requirement explicitly excludes deliveries

**Correct option(s):** 4

- Option 1: Regional access and supply are not established.
- Option 2: Quantity does not override the defined boundary.
- Option 3: It can in a plan that explicitly includes and validates it.
- Option 4: A different assumption would need authorized requirement change.

**CDCS-Q0198 · single · operations**

What should replace the constant-rate model for a varying load assessment?

Synthetic training case — not a field record.

A filled tank contains 8000 L. The supplied design marks 800 L unusable and 1200 L as a reserve excluded from the autonomy calculation. At the modeled load, consumption is 180 L/h constant. Required stored-fuel endurance is 36 h without deliveries. The transfer pump is fed only from normal utility power; its outage behavior is unverified.

1. Only the highest tank level ever recorded
2. Supported consumption data and the expected operating profile
3. An assumption that all loads consume the same liters per hour
4. Only the generator’s enclosure dimensions

**Correct option(s):** 2

- Option 1: That does not model consumption.
- Option 2: Consumption can vary with load and conditions.
- Option 3: That is not generally valid.
- Option 4: Size is not a fuel curve.

**CDCS-Q0199 · single · design**

What else should a generator duty review confirm?

Synthetic training case — not a field record.

A filled tank contains 8000 L. The supplied design marks 800 L unusable and 1200 L as a reserve excluded from the autonomy calculation. At the modeled load, consumption is 180 L/h constant. Required stored-fuel endurance is 36 h without deliveries. The transfer pump is fed only from normal utility power; its outage behavior is unverified.

1. Only the fuel type’s popularity
2. The applicable duty rating, ambient conditions and transient load acceptance
3. Only that the alternator label is readable
4. Only that the engine starts without load

**Correct option(s):** 2

- Option 1: Selection depends on the complete application.
- Option 2: A maximum headline output is not every operating capability.
- Option 3: Identity alone does not establish suitability.
- Option 4: Load acceptance is a separate milestone.

**CDCS-Q0200 · single · design**

What should be the acceptance status now?

Synthetic training case — not a field record.

A filled tank contains 8000 L. The supplied design marks 800 L unusable and 1200 L as a reserve excluded from the autonomy calculation. At the modeled load, consumption is 180 L/h constant. Required stored-fuel endurance is 36 h without deliveries. The transfer pump is fed only from normal utility power; its outage behavior is unverified.

1. Accepted after changing the dashboard endurance label
2. Open for both the quantity shortfall and transfer-pump event behavior
3. Rejected solely because a diesel engine is assumed
4. Accepted because one arithmetic result is close to 36 h

**Correct option(s):** 2

- Option 1: A display change does not create usable fuel or pump capability.
- Option 2: Both can prevent the required service.
- Option 3: The case does not require a universal fuel-type rejection.
- Option 4: Close is not the stated criterion.

**CDCS-Q0201 · single · mechanism**

Why is equal frequency insufficient for connection approval?

Synthetic training case — not a field record.

Two compatible generator sets are intended to parallel through a supported controller. A review packet records equal frequency but omits phase sequence and phase-angle evidence. Once operating in a synthetic recorded parallel state, both sets show 300 kW, but reactive outputs are 40 and 160 kVAr. Controller communication-loss behavior is undocumented. No live switching is authorized by this exercise.

1. Equal frequency proves equal instantaneous phase angle
2. Other synchronizing conditions and permissives remain unverified
3. A controller nameplate automatically supplies all missing evidence
4. Frequency has no relevance to AC paralleling

**Correct option(s):** 2

- Option 1: Sources can have the same frequency and different phase angle.
- Option 2: Voltage, phase sequence and phase angle matter.
- Option 3: The actual supported setup must be verified.
- Option 4: It is relevant but not sufficient.

**CDCS-Q0202 · single · mechanism**

What does equal 300 kW output establish in the recorded state?

Synthetic training case — not a field record.

Two compatible generator sets are intended to parallel through a supported controller. A review packet records equal frequency but omits phase sequence and phase-angle evidence. Once operating in a synthetic recorded parallel state, both sets show 300 kW, but reactive outputs are 40 and 160 kVAr. Controller communication-loss behavior is undocumented. No live switching is authorized by this exercise.

1. Equal kVAr sharing
2. Equal RMS current under every condition
3. Equal real-power sharing at that observation
4. Correct synchronization for every previous event

**Correct option(s):** 3

- Option 1: The supplied reactive values differ.
- Option 2: Current also depends on voltage and reactive/distortion components.
- Option 3: It says nothing by itself about equal reactive sharing.
- Option 4: A later power reading does not reconstruct every connection condition.

**CDCS-Q0203 · single · calculation**

Which supplied quantity reveals unequal reactive sharing?

Synthetic training case — not a field record.

Two compatible generator sets are intended to parallel through a supported controller. A review packet records equal frequency but omits phase sequence and phase-angle evidence. Once operating in a synthetic recorded parallel state, both sets show 300 kW, but reactive outputs are 40 and 160 kVAr. Controller communication-loss behavior is undocumented. No live switching is authorized by this exercise.

1. The number of generator sets
2. The equal real-power readings alone
3. 300 versus 300 kW
4. 40 versus 160 kVAr

**Correct option(s):** 4

- Option 1: Count does not quantify sharing.
- Option 2: They do not describe the differing reactive contributions.
- Option 3: Those show equal real power.
- Option 4: Those are the differing reactive-power outputs.

**CDCS-Q0204 · single · operations**

In the simplified supported synchronous-generator model, what principally adjusts real-power sharing?

Synthetic training case — not a field record.

Two compatible generator sets are intended to parallel through a supported controller. A review packet records equal frequency but omits phase sequence and phase-angle evidence. Once operating in a synthetic recorded parallel state, both sets show 300 kW, but reactive outputs are 40 and 160 kVAr. Controller communication-loss behavior is undocumented. No live switching is authorized by this exercise.

1. Only the excitation setting
2. Prime-mover/governor control
3. Only the rack PDU outlet count
4. Only the monitoring display scale

**Correct option(s):** 2

- Option 1: Excitation principally influences reactive/voltage behavior in this explanation.
- Option 2: Mechanical power input governs real-power contribution.
- Option 3: That does not control generator sharing.
- Option 4: Changing a display does not change physical load share.

**CDCS-Q0205 · single · operations**

What principally influences reactive sharing in the same simplified model?

Synthetic training case — not a field record.

Two compatible generator sets are intended to parallel through a supported controller. A review packet records equal frequency but omits phase sequence and phase-angle evidence. Once operating in a synthetic recorded parallel state, both sets show 300 kW, but reactive outputs are 40 and 160 kVAr. Controller communication-loss behavior is undocumented. No live switching is authorized by this exercise.

1. Excitation/voltage-control behavior
2. Only the project schedule
3. Only the engine’s real-power setpoint with no voltage interaction
4. Only the fuel-tank level

**Correct option(s):** 1

- Option 1: It affects reactive contribution within the coordinated system.
- Option 2: Schedule is not an electrical control variable.
- Option 3: The relevant control mechanism differs.
- Option 4: Fuel quantity does not directly set reactive sharing.

**CDCS-Q0206 · single · operations**

What should be checked before changing a displayed reactive-power value?

Synthetic training case — not a field record.

Two compatible generator sets are intended to parallel through a supported controller. A review packet records equal frequency but omits phase sequence and phase-angle evidence. Once operating in a synthetic recorded parallel state, both sets show 300 kW, but reactive outputs are 40 and 160 kVAr. Controller communication-loss behavior is undocumented. No live switching is authorized by this exercise.

1. Only whether the total bus kVAr is plausible
2. Only the supplier’s preferred dashboard layout
3. Measurement polarity/scaling, actual readings and control configuration
4. Only which number looks more balanced

**Correct option(s):** 3

- Option 1: A plausible total can still conceal incorrect per-set sensing or sharing.
- Option 2: Layout does not resolve reactive sharing.
- Option 3: A display discrepancy may reflect sensing or real behavior.
- Option 4: Cosmetic equality is not a correction.

**CDCS-Q0207 · single · mechanism**

Why is communication-loss behavior part of the design review?

Synthetic training case — not a field record.

Two compatible generator sets are intended to parallel through a supported controller. A review packet records equal frequency but omits phase sequence and phase-angle evidence. Once operating in a synthetic recorded parallel state, both sets show 300 kW, but reactive outputs are 40 and 160 kVAr. Controller communication-loss behavior is undocumented. No live switching is authorized by this exercise.

1. Every parallel system necessarily shuts down on any lost packet
2. Network redundancy automatically guarantees electrical sharing
3. Communication is always irrelevant once engines run
4. Load-sharing and control response may depend on that communication

**Correct option(s):** 4

- Option 1: Actual supported behavior varies.
- Option 2: End-to-end control behavior still needs evidence.
- Option 3: The case includes a supported controller with an undocumented dependency.
- Option 4: Failure behavior must be specified and verified.

**CDCS-Q0208 · single · operations**

What must a controller/firmware substitution establish?

Synthetic training case — not a field record.

Two compatible generator sets are intended to parallel through a supported controller. A review packet records equal frequency but omits phase sequence and phase-angle evidence. Once operating in a synthetic recorded parallel state, both sets show 300 kW, but reactive outputs are 40 and 160 kVAr. Controller communication-loss behavior is undocumented. No live switching is authorized by this exercise.

1. Only a successful management login
2. Manufacturer-supported compatibility and affected function verification
3. Only a newer release date
4. Only equal enclosure dimensions

**Correct option(s):** 2

- Option 1: Login does not test sharing or protection functions.
- Option 2: Parallel coordination can depend on version and options.
- Option 3: Newer does not guarantee supported interoperability.
- Option 4: Physical fit does not establish control compatibility.

**CDCS-Q0209 · single · implementation**

What should the commissioning record include for this topic?

Synthetic training case — not a field record.

Two compatible generator sets are intended to parallel through a supported controller. A review packet records equal frequency but omits phase sequence and phase-angle evidence. Once operating in a synthetic recorded parallel state, both sets show 300 kW, but reactive outputs are 40 and 160 kVAr. Controller communication-loss behavior is undocumented. No live switching is authorized by this exercise.

1. Only a vendor brochure
2. Only that both engines can crank
3. Initial state, synchronizing evidence, sharing response and defined failure/recovery tests
4. Only total bus kW with no per-set data

**Correct option(s):** 3

- Option 1: Generic specifications are not the actual test result.
- Option 2: Starting is not parallel load acceptance.
- Option 3: The required behavior spans more than startup.
- Option 4: That can conceal unequal contributions.

**CDCS-Q0210 · single · operations**

What action is authorized by this analytical case?

Synthetic training case — not a field record.

Two compatible generator sets are intended to parallel through a supported controller. A review packet records equal frequency but omits phase sequence and phase-angle evidence. Once operating in a synthetic recorded parallel state, both sets show 300 kW, but reactive outputs are 40 and 160 kVAr. Controller communication-loss behavior is undocumented. No live switching is authorized by this exercise.

1. Prepare precise review questions and an evidence plan for competent specialists
2. Adjust excitation until both numbers match without investigation
3. Disable synchronizing permissives to obtain a test result
4. Manually close the parallel breaker when frequency looks equal

**Correct option(s):** 1

- Option 1: No live switching or setting change is authorized.
- Option 2: That can affect the electrical system and exceeds the exercise.
- Option 3: That defeats intended protective controls.
- Option 4: The required conditions and authority are absent.

**CDCS-Q0211 · single · calculation**

What input real power corresponds to the stated efficiency?

Synthetic training case — not a field record.

A UPS supplies 300 kW real output at stated 96% efficiency in double-conversion mode. The measurement boundary excludes battery charging. A proposed economy mode has higher steady efficiency but normally uses an alternate power path; its transition behavior with the actual IT load has not been tested. The supplier provides only one efficiency point, while site load varies through the day.

1. 396 kW
2. 300 kW
3. 312.5 kW
4. 288 kW

**Correct option(s):** 3

- Option 1: That adds a percentage incorrectly.
- Option 2: That assumes no loss.
- Option 3: Input equals output divided by 0.96.
- Option 4: That multiplies output by efficiency and would understate required input.

**CDCS-Q0212 · single · calculation**

What is the modeled UPS loss at this point?

Synthetic training case — not a field record.

A UPS supplies 300 kW real output at stated 96% efficiency in double-conversion mode. The measurement boundary excludes battery charging. A proposed economy mode has higher steady efficiency but normally uses an alternate power path; its transition behavior with the actual IT load has not been tested. The supplier provides only one efficiency point, while site load varies through the day.

1. 300 kW
2. 4 kW
3. 12.5 kW
4. 312.5 kW

**Correct option(s):** 3

- Option 1: That is delivered output, not conversion loss.
- Option 2: Four percent of a percentage is not the correct power difference.
- Option 3: 312.5 input minus 300 output.
- Option 4: That is total input rather than loss.

**CDCS-Q0213 · single · operations**

What must be stated about battery charging in this result?

Synthetic training case — not a field record.

A UPS supplies 300 kW real output at stated 96% efficiency in double-conversion mode. The measurement boundary excludes battery charging. A proposed economy mode has higher steady efficiency but normally uses an alternate power path; its transition behavior with the actual IT load has not been tested. The supplier provides only one efficiency point, while site load varies through the day.

1. It is excluded by the supplied measurement boundary
2. It is zero under every operating condition
3. It equals the 300 kW output
4. It is included automatically in every efficiency figure

**Correct option(s):** 1

- Option 1: Adding charging can change total input and heat accounting.
- Option 2: No such universal condition is supplied.
- Option 3: Charging demand is a separate quantity.
- Option 4: Boundaries differ and this case explicitly excludes it.

**CDCS-Q0214 · single · mechanism**

Why does the single efficiency point not establish annual performance?

Synthetic training case — not a field record.

A UPS supplies 300 kW real output at stated 96% efficiency in double-conversion mode. The measurement boundary excludes battery charging. A proposed economy mode has higher steady efficiency but normally uses an alternate power path; its transition behavior with the actual IT load has not been tested. The supplier provides only one efficiency point, while site load varies through the day.

1. Efficiency cannot be measured in a UPS
2. Annual energy is always the best catalogue efficiency times all hours
3. The highest published efficiency applies at every load and mode
4. The actual load and mode distribution vary

**Correct option(s):** 4

- Option 1: It can be measured with a defined boundary.
- Option 2: That ignores the operating profile.
- Option 3: Actual efficiency can vary across the operating profile.
- Option 4: Efficiency can depend on operating point and mode.

**CDCS-Q0215 · single · operations**

What thermal interface follows from the modeled loss?

Synthetic training case — not a field record.

A UPS supplies 300 kW real output at stated 96% efficiency in double-conversion mode. The measurement boundary excludes battery charging. A proposed economy mode has higher steady efficiency but normally uses an alternate power path; its transition behavior with the actual IT load has not been tested. The supplier provides only one efficiency point, while site load varies through the day.

1. The relevant heat-rejection design must account for that loss within its boundary
2. All 300 kW output disappears without becoming load heat
3. Losses have no effect on cooling because they are electrical
4. The loss is automatically removed by the network switches

**Correct option(s):** 1

- Option 1: Electrical conversion loss contributes to facility thermal demand.
- Option 2: The consuming IT equipment also dissipates energy under its own boundary.
- Option 3: Dissipated electrical energy becomes heat.
- Option 4: Cooling needs its actual physical path.

**CDCS-Q0216 · single · operations**

What should be assessed before accepting economy mode?

Synthetic training case — not a field record.

A UPS supplies 300 kW real output at stated 96% efficiency in double-conversion mode. The measurement boundary excludes battery charging. A proposed economy mode has higher steady efficiency but normally uses an alternate power path; its transition behavior with the actual IT load has not been tested. The supplier provides only one efficiency point, while site load varies through the day.

1. Actual path, power-quality and transition behavior against IT service tolerance
2. Only the normal-state output voltage before a source event
3. Only the number of batteries installed
4. Only the higher efficiency percentage

**Correct option(s):** 1

- Option 1: Higher steady efficiency does not prove equivalent service.
- Option 2: Transition behavior and load response remain untested.
- Option 3: Mode transitions involve additional functions.
- Option 4: Other requirements remain.

**CDCS-Q0217 · single · mechanism**

What does double conversion describe in this chapter?

Synthetic training case — not a field record.

A UPS supplies 300 kW real output at stated 96% efficiency in double-conversion mode. The measurement boundary excludes battery charging. A proposed economy mode has higher steady efficiency but normally uses an alternate power path; its transition behavior with the actual IT load has not been tested. The supplier provides only one efficiency point, while site load varies through the day.

1. A guarantee that every possible mode has no transfer event
2. Two batteries connected in series
3. Two independent utility substations
4. A normal path using conversion to a DC link and inversion to AC output

**Correct option(s):** 4

- Option 1: Products can use bypass or alternate modes.
- Option 2: That is a different configuration concept.
- Option 3: Topology terminology does not imply upstream source diversity.
- Option 4: Exact product modes and bypass behavior still need verification.

**CDCS-Q0218 · single · mechanism**

Why test the actual IT load or a justified representative model?

Synthetic training case — not a field record.

A UPS supplies 300 kW real output at stated 96% efficiency in double-conversion mode. The measurement boundary excludes battery charging. A proposed economy mode has higher steady efficiency but normally uses an alternate power path; its transition behavior with the actual IT load has not been tested. The supplier provides only one efficiency point, while site load varies through the day.

1. All IT loads behave identically to every load bank
2. Testing the load replaces all design review
3. Load tolerance and dynamics affect the service response
4. Only the UPS manufacturer’s office load is relevant

**Correct option(s):** 3

- Option 1: That is an unsupported assumption.
- Option 2: Testing and design evidence complement each other.
- Option 3: A generic resistive test may not reproduce all relevant behavior.
- Option 4: Site conditions and requirements matter.

**CDCS-Q0219 · single · operations**

What should an energy comparison between modes preserve?

Synthetic training case — not a field record.

A UPS supplies 300 kW real output at stated 96% efficiency in double-conversion mode. The measurement boundary excludes battery charging. A proposed economy mode has higher steady efficiency but normally uses an alternate power path; its transition behavior with the actual IT load has not been tested. The supplier provides only one efficiency point, while site load varies through the day.

1. Different delivered loads with no normalization
2. The same output service, boundary, load profile and relevant conditions
3. Only a shorter reporting interval for the preferred mode
4. Only the lowest observed input reading in each mode

**Correct option(s):** 2

- Option 1: That confounds efficiency comparison.
- Option 2: Otherwise the apparent saving may not be comparable.
- Option 3: Unequal coverage can bias the result.
- Option 4: Selected minima can mislead.

**CDCS-Q0220 · single · design**

What is the appropriate acceptance status of the proposed mode?

Synthetic training case — not a field record.

A UPS supplies 300 kW real output at stated 96% efficiency in double-conversion mode. The measurement boundary excludes battery charging. A proposed economy mode has higher steady efficiency but normally uses an alternate power path; its transition behavior with the actual IT load has not been tested. The supplier provides only one efficiency point, while site load varies through the day.

1. Universally prohibited because it changes the path
2. Fully accepted because steady efficiency is higher
3. Equivalent to a physical commissioning pass
4. Energy potential is identified; service transition and annual benefit remain unproven

**Correct option(s):** 4

- Option 1: A supported mode may be suitable after assessment.
- Option 2: The required service behavior is untested.
- Option 3: No such test has occurred in this case.
- Option 4: The evidence supports a bounded next step.

**CDCS-Q0221 · single · operations**

What is the key compatibility gap in the proposal?

Synthetic training case — not a field record.

Two UPS modules have the same nominal output rating but different firmware branches. Their proposed parallel combination is not listed in the supplied support matrix. A synthetic operating record from a vendor-approved test setup shows 230 kW on one module and 170 kW on the other for a 400 kW total; the agreed steady sharing criterion is within 10 kW of an equal split. Both depend on one bypass control supply. A shared battery proposal has no approved protection/charging diagram.

1. The total load is expressed in kW
2. The actual firmware/module combination lacks support-matrix evidence
3. The setup contains two modules
4. The modules have equal nominal ratings

**Correct option(s):** 2

- Option 1: That is an appropriate real-power unit.
- Option 2: Equal ratings do not establish approved parallel operation.
- Option 3: Parallel systems can legitimately contain two modules.
- Option 4: Equal ratings can be compatible but are not sufficient proof.

**CDCS-Q0222 · single · calculation**

What is the equal real-power share for 400 kW total?

Synthetic training case — not a field record.

Two UPS modules have the same nominal output rating but different firmware branches. Their proposed parallel combination is not listed in the supplied support matrix. A synthetic operating record from a vendor-approved test setup shows 230 kW on one module and 170 kW on the other for a 400 kW total; the agreed steady sharing criterion is within 10 kW of an equal split. Both depend on one bypass control supply. A shared battery proposal has no approved protection/charging diagram.

1. 400 kW per module
2. 230 kW per module
3. 200 kW per module
4. 170 kW per module

**Correct option(s):** 3

- Option 1: That would double the total.
- Option 2: That would total 460 kW.
- Option 3: Divide the total equally between two modules.
- Option 4: That would total 340 kW.

**CDCS-Q0223 · single · design**

Does the recorded sharing meet the stated criterion?

Synthetic training case — not a field record.

Two UPS modules have the same nominal output rating but different firmware branches. Their proposed parallel combination is not listed in the supplied support matrix. A synthetic operating record from a vendor-approved test setup shows 230 kW on one module and 170 kW on the other for a 400 kW total; the agreed steady sharing criterion is within 10 kW of an equal split. Both depend on one bypass control supply. A shared battery proposal has no approved protection/charging diagram.

1. Yes, because both values are below an unspecified overload limit
2. It cannot be calculated because the ratings are omitted
3. No; each module differs from 200 kW by 30 kW
4. Yes, because the total is still 400 kW

**Correct option(s):** 3

- Option 1: The actual sharing criterion remains failed.
- Option 2: The criterion compares with the supplied equal split, not a missing rating.
- Option 3: The permitted deviation is only 10 kW.
- Option 4: Total delivery does not satisfy the sharing criterion.

**CDCS-Q0224 · single · diagnosis**

What should be investigated for unequal sharing?

Synthetic training case — not a field record.

Two UPS modules have the same nominal output rating but different firmware branches. Their proposed parallel combination is not listed in the supplied support matrix. A synthetic operating record from a vendor-approved test setup shows 230 kW on one module and 170 kW on the other for a 400 kW total; the agreed steady sharing criterion is within 10 kW of an equal split. Both depend on one bypass control supply. A shared battery proposal has no approved protection/charging diagram.

1. Only the equipment purchase dates
2. Supported control configuration, sensing, cabling and module behavior
3. Only whether the total meter is green
4. Only the number of rack outlets

**Correct option(s):** 2

- Option 1: Age alone does not identify the mechanism.
- Option 2: Several implementation factors can affect distribution.
- Option 3: A summary can conceal the mismatch.
- Option 4: That does not directly explain module sharing.

**CDCS-Q0225 · single · mechanism**

Why is the common bypass control supply relevant?

Synthetic training case — not a field record.

Two UPS modules have the same nominal output rating but different firmware branches. Their proposed parallel combination is not listed in the supplied support matrix. A synthetic operating record from a vendor-approved test setup shows 230 kW on one module and 170 kW on the other for a 400 kW total; the agreed steady sharing criterion is within 10 kW of an equal split. Both depend on one bypass control supply. A shared battery proposal has no approved protection/charging diagram.

1. Only battery count determines every common cause
2. Bypass controls can never affect service
3. It automatically doubles control redundancy
4. Its loss may affect a function used by both modules

**Correct option(s):** 4

- Option 1: Controls and paths also matter.
- Option 2: Their function can be important in required states.
- Option 3: One shared supply is not two independent supplies.
- Option 4: It is a shared dependency in the complete architecture.

**CDCS-Q0226 · single · operations**

What is missing from the shared battery proposal?

Synthetic training case — not a field record.

Two UPS modules have the same nominal output rating but different firmware branches. Their proposed parallel combination is not listed in the supplied support matrix. A synthetic operating record from a vendor-approved test setup shows 230 kW on one module and 170 kW on the other for a 400 kW total; the agreed steady sharing criterion is within 10 kW of an equal split. Both depend on one bypass control supply. A shared battery proposal has no approved protection/charging diagram.

1. Only matching nominal DC voltage without protection or charging details
2. A supported protection, charging, isolation and maintenance arrangement
3. Only equal AC output ratings
4. Only a battery monitoring dashboard with no supported connection diagram

**Correct option(s):** 2

- Option 1: Voltage agreement is not a complete supported DC architecture.
- Option 2: A capacity sum does not establish safe DC integration.
- Option 3: AC rating equality does not establish the shared DC protection and charging arrangement.
- Option 4: Visibility does not supply the required DC architecture.

**CDCS-Q0227 · single · mechanism**

Why can a vendor-approved test setup’s result not automatically approve the proposed combination?

Synthetic training case — not a field record.

Two UPS modules have the same nominal output rating but different firmware branches. Their proposed parallel combination is not listed in the supplied support matrix. A synthetic operating record from a vendor-approved test setup shows 230 kW on one module and 170 kW on the other for a 400 kW total; the agreed steady sharing criterion is within 10 kW of an equal split. Both depend on one bypass control supply. A shared battery proposal has no approved protection/charging diagram.

1. Vendor tests never provide useful evidence
2. A recorded total load eliminates version dependencies
3. Any two products with equal ratings are equivalent to the test
4. Its exact hardware/firmware/configuration scope may differ

**Correct option(s):** 4

- Option 1: They can establish behavior within their documented scope.
- Option 2: Control behavior can remain version-dependent.
- Option 3: Compatibility is more specific than rating.
- Option 4: Evidence must match the actual intended implementation.

**CDCS-Q0228 · single · design**

What should a parallel UPS acceptance plan include beyond normal sharing?

Synthetic training case — not a field record.

Two UPS modules have the same nominal output rating but different firmware branches. Their proposed parallel combination is not listed in the supplied support matrix. A synthetic operating record from a vendor-approved test setup shows 230 kW on one module and 170 kW on the other for a 400 kW total; the agreed steady sharing criterion is within 10 kW of an equal split. Both depend on one bypass control supply. A shared battery proposal has no approved protection/charging diagram.

1. Only simultaneous power-on
2. Only a management-port ping
3. Only a battery label inspection
4. Defined unavailable states, bypass behavior and controlled restoration

**Correct option(s):** 4

- Option 1: Startup alone does not verify the complete required behavior.
- Option 2: Reachability does not establish parallel electrical operation.
- Option 3: Other AC/control functions remain.
- Option 4: Resilience includes transitions and recovery.

**CDCS-Q0229 · single · operations**

How should a firmware upgrade be evaluated?

Synthetic training case — not a field record.

Two UPS modules have the same nominal output rating but different firmware branches. Their proposed parallel combination is not listed in the supplied support matrix. A synthetic operating record from a vendor-approved test setup shows 230 kW on one module and 170 kW on the other for a 400 kW total; the agreed steady sharing criterion is within 10 kW of an equal split. Both depend on one bypass control supply. A shared battery proposal has no approved protection/charging diagram.

1. By upgrading one live module without the site process
2. As automatically safe because the version number increases
3. By deleting the old support matrix
4. Against supported combinations and affected parallel functions with rollback/recovery evidence

**Correct option(s):** 4

- Option 1: The exercise gives no such authority or procedure.
- Option 2: Newness does not prove compatibility.
- Option 3: Removing evidence does not validate the new state.
- Option 4: A version change can alter coordination.

**CDCS-Q0230 · single · operations**

What conclusion is justified now?

Synthetic training case — not a field record.

Two UPS modules have the same nominal output rating but different firmware branches. Their proposed parallel combination is not listed in the supplied support matrix. A synthetic operating record from a vendor-approved test setup shows 230 kW on one module and 170 kW on the other for a 400 kW total; the agreed steady sharing criterion is within 10 kW of an equal split. Both depend on one bypass control supply. A shared battery proposal has no approved protection/charging diagram.

1. The learner can correct the DC wiring from this question
2. The proposal passes because total load was delivered once
3. Every parallel UPS architecture is unsuitable
4. The supplied sharing test fails its criterion and the proposed support/DC dependencies remain open

**Correct option(s):** 4

- Option 1: Specialist design and authorized execution remain required.
- Option 2: That does not close compatibility, sharing or failure-state requirements.
- Option 3: The case identifies specific unresolved conditions.
- Option 4: These are separate concrete review findings.

**CDCS-Q0231 · single · calculation**

What is harmonic RMS excluding the fundamental?

Synthetic training case — not a field record.

A supplied synthetic phase-current spectrum contains 100 A fundamental, 40 A third harmonic and 30 A fifth harmonic, with all other components zero. Use orthogonal RMS summation. In a separate balanced four-wire model, each phase has an equal in-phase 40 A third-harmonic component in the neutral reference. A proposal adds a plain capacitor bank solely because displacement PF is low; no resonance study exists.

1. 100 A
2. 70 A
3. 10 A
4. 50 A

**Correct option(s):** 4

- Option 1: That is the fundamental component.
- Option 2: Arithmetic addition is not orthogonal RMS summation.
- Option 3: Subtracting harmonic amplitudes is not RMS combination.
- Option 4: √(40²+30²)=50.

**CDCS-Q0232 · single · calculation**

What is total phase RMS current in the supplied spectrum?

Synthetic training case — not a field record.

A supplied synthetic phase-current spectrum contains 100 A fundamental, 40 A third harmonic and 30 A fifth harmonic, with all other components zero. Use orthogonal RMS summation. In a separate balanced four-wire model, each phase has an equal in-phase 40 A third-harmonic component in the neutral reference. A proposal adds a plain capacitor bank solely because displacement PF is low; no resonance study exists.

1. 100 A
2. Approximately 111.8 A
3. 170 A
4. 50 A

**Correct option(s):** 2

- Option 1: That ignores the harmonic components.
- Option 2: √(100²+40²+30²)=√12500.
- Option 3: That adds RMS components directly rather than by squares.
- Option 4: That omits the fundamental.

**CDCS-Q0233 · single · calculation**

What is current THD relative to the fundamental?

Synthetic training case — not a field record.

A supplied synthetic phase-current spectrum contains 100 A fundamental, 40 A third harmonic and 30 A fifth harmonic, with all other components zero. Use orthogonal RMS summation. In a separate balanced four-wire model, each phase has an equal in-phase 40 A third-harmonic component in the neutral reference. A proposal adds a plain capacitor bank solely because displacement PF is low; no resonance study exists.

1. 50%
2. 111.8%
3. 70%
4. 44.72%

**Correct option(s):** 1

- Option 1: 50 A harmonic RMS divided by 100 A fundamental.
- Option 2: That uses total RMS divided by fundamental.
- Option 3: That uses arithmetic harmonic addition.
- Option 4: That divides harmonic RMS by total RMS instead of the specified fundamental definition.

**CDCS-Q0234 · single · calculation**

What is the third-harmonic neutral component in the separate stated model?

Synthetic training case — not a field record.

A supplied synthetic phase-current spectrum contains 100 A fundamental, 40 A third harmonic and 30 A fifth harmonic, with all other components zero. Use orthogonal RMS summation. In a separate balanced four-wire model, each phase has an equal in-phase 40 A third-harmonic component in the neutral reference. A proposal adds a plain capacitor bank solely because displacement PF is low; no resonance study exists.

1. 120 A
2. 69.28 A
3. 40 A
4. 0 A

**Correct option(s):** 1

- Option 1: Three in-phase 40 A components add.
- Option 2: That applies a √3 relation inappropriate to the supplied in-phase sum.
- Option 3: That counts only one phase contribution.
- Option 4: Balanced fundamental cancellation does not apply to these stated triplen components.

**CDCS-Q0235 · single · mechanism**

Why can balanced fundamental currents coexist with substantial neutral current?

Synthetic training case — not a field record.

A supplied synthetic phase-current spectrum contains 100 A fundamental, 40 A third harmonic and 30 A fifth harmonic, with all other components zero. Use orthogonal RMS summation. In a separate balanced four-wire model, each phase has an equal in-phase 40 A third-harmonic component in the neutral reference. A proposal adds a plain capacitor bank solely because displacement PF is low; no resonance study exists.

1. Triplen harmonic components can add under the relevant four-wire conditions
2. All harmonic currents always cancel in every neutral
3. The neutral creates current independently of the load
4. Only voltage imbalance can ever produce neutral current

**Correct option(s):** 1

- Option 1: Fundamental balance does not imply all waveform components cancel.
- Option 2: The supplied model demonstrates otherwise.
- Option 3: It carries the resulting return components.
- Option 4: Harmonic content can also contribute.

**CDCS-Q0236 · single · mechanism**

Why is a plain capacitor bank not automatically the correct mitigation?

Synthetic training case — not a field record.

A supplied synthetic phase-current spectrum contains 100 A fundamental, 40 A third harmonic and 30 A fifth harmonic, with all other components zero. Use orthogonal RMS summation. In a separate balanced four-wire model, each phase has an equal in-phase 40 A third-harmonic component in the neutral reference. A proposal adds a plain capacitor bank solely because displacement PF is low; no resonance study exists.

1. Any PF correction guarantees zero THD
2. It can interact with system inductance and does not universally remove harmonics
3. Capacitors can never affect power factor
4. A capacitor bank eliminates the need for neutral review

**Correct option(s):** 2

- Option 1: Phase correction and distortion are different.
- Option 2: A spectrum and resonance assessment is needed.
- Option 3: They can affect displacement PF in suitable applications.
- Option 4: The resulting waveform and system still need evaluation.

**CDCS-Q0237 · single · design**

What evidence should guide filter selection?

Synthetic training case — not a field record.

A supplied synthetic phase-current spectrum contains 100 A fundamental, 40 A third harmonic and 30 A fifth harmonic, with all other components zero. Use orthogonal RMS summation. In a separate balanced four-wire model, each phase has an equal in-phase 40 A third-harmonic component in the neutral reference. A proposal adds a plain capacitor bank solely because displacement PF is low; no resonance study exists.

1. Only the number of servers
2. Only the lowest displacement PF reading
3. Load spectrum, source impedance, operating states and supported equipment limits
4. Only the filter cabinet dimensions

**Correct option(s):** 3

- Option 1: Count does not describe their aggregate waveform.
- Option 2: That omits harmonic distribution and interactions.
- Option 3: The mitigation must fit the actual system.
- Option 4: Fit does not establish electrical suitability.

**CDCS-Q0238 · single · mechanism**

Why record absolute harmonic current as well as THD percentage?

Synthetic training case — not a field record.

A supplied synthetic phase-current spectrum contains 100 A fundamental, 40 A third harmonic and 30 A fifth harmonic, with all other components zero. Use orthogonal RMS summation. In a separate balanced four-wire model, each phase has an equal in-phase 40 A third-harmonic component in the neutral reference. A proposal adds a plain capacitor bank solely because displacement PF is low; no resonance study exists.

1. Percentages determine conductor heating independently of current
2. THD contains no information at all
3. A changing fundamental can alter the percentage without reducing harmonic amperes
4. Absolute current is always identical to THD

**Correct option(s):** 3

- Option 1: Actual RMS and waveform conditions matter.
- Option 2: It is useful with its definition and underlying quantities.
- Option 3: The ratio alone can mislead.
- Option 4: They have different units and meanings.

**CDCS-Q0239 · single · operations**

What should a before/after mitigation test preserve?

Synthetic training case — not a field record.

A supplied synthetic phase-current spectrum contains 100 A fundamental, 40 A third harmonic and 30 A fifth harmonic, with all other components zero. Use orthogonal RMS summation. In a separate balanced four-wire model, each phase has an equal in-phase 40 A third-harmonic component in the neutral reference. A proposal adds a plain capacitor bank solely because displacement PF is low; no resonance study exists.

1. Comparable load/source states and appropriate RMS/spectral measurements
2. Only the displacement angle with harmonics unmeasured
3. Only a screenshot of the best moment
4. Only equal elapsed calendar days

**Correct option(s):** 1

- Option 1: The comparison needs representative conditions.
- Option 2: The stated objective includes harmonic behavior.
- Option 3: Selection can hide adverse states.
- Option 4: That does not ensure comparable electrical conditions.

**CDCS-Q0240 · single · mechanism**

What does this simplified spectrum not establish by itself?

Synthetic training case — not a field record.

A supplied synthetic phase-current spectrum contains 100 A fundamental, 40 A third harmonic and 30 A fifth harmonic, with all other components zero. Use orthogonal RMS summation. In a separate balanced four-wire model, each phase has an equal in-phase 40 A third-harmonic component in the neutral reference. A proposal adds a plain capacitor bank solely because displacement PF is low; no resonance study exists.

1. The calculated 50 A harmonic RMS
2. The specified absence of other components in the model
3. The arithmetic sum of the three stated neutral components
4. Every equipment temperature, voltage distortion and protection response

**Correct option(s):** 4

- Option 1: That follows from the supplied components.
- Option 2: That is an explicit assumption.
- Option 3: That is defined by the separate model.
- Option 4: Those depend on additional system characteristics.

#### Recall

**Fuel endurance with reserve and a failed transfer dependency — Synthetic training case — not a field record.

A filled tank contains 8000 L. The supplied design marks 800 L unusable and 1200 L as a reserve excluded from the autonomy calculation. At the modeled load, consumption is 180 L/h constant. Required stored-fuel endurance is 36 h without deliveries. The transfer pump is fed only from normal utility power; its outage behavior is unverified.**

Usable modeled fuel is 6000 L, yielding 33.33 h. Thirty-six hours requires 6480 L, so the available quantity is 480 L short. Even that endurance depends on fuel reaching the engine; the utility-only pump is an unresolved common dependency.

**Generator synchronizing and unequal reactive sharing — Synthetic training case — not a field record.

Two compatible generator sets are intended to parallel through a supported controller. A review packet records equal frequency but omits phase sequence and phase-angle evidence. Once operating in a synthetic recorded parallel state, both sets show 300 kW, but reactive outputs are 40 and 160 kVAr. Controller communication-loss behavior is undocumented. No live switching is authorized by this exercise.**

Equal frequency is only one synchronizing condition. Review voltage, phase sequence/angle and the supported protection/permissive system. Equal real-power sharing does not prove reactive sharing; excitation/voltage-control behavior and sensing need competent investigation. Document communication-loss response rather than assuming the network recovers fast enough.

**UPS efficiency and a mode change with service consequences — Synthetic training case — not a field record.

A UPS supplies 300 kW real output at stated 96% efficiency in double-conversion mode. The measurement boundary excludes battery charging. A proposed economy mode has higher steady efficiency but normally uses an alternate power path; its transition behavior with the actual IT load has not been tested. The supplier provides only one efficiency point, while site load varies through the day.**

Input is 300/0.96=312.5 kW and modeled UPS loss is 12.5 kW, excluding charging. Economy-mode service behavior and annual energy performance need their own evidence. A single efficiency point cannot establish a variable-load annual result or acceptable transition behavior.

**Parallel UPS modules with incompatible assumptions — Synthetic training case — not a field record.

Two UPS modules have the same nominal output rating but different firmware branches. Their proposed parallel combination is not listed in the supplied support matrix. A synthetic operating record from a vendor-approved test setup shows 230 kW on one module and 170 kW on the other for a 400 kW total; the agreed steady sharing criterion is within 10 kW of an equal split. Both depend on one bypass control supply. A shared battery proposal has no approved protection/charging diagram.**

Equal split is 200 kW each; the recorded deviations are +30 and −30 kW, outside the supplied ±10 kW criterion. Resolve support compatibility separately from this test result. Shared bypass controls and the unsupported battery arrangement require complete design review; equal nameplates do not prove equivalent redundancy.

**Harmonic current with a loaded neutral — Synthetic training case — not a field record.

A supplied synthetic phase-current spectrum contains 100 A fundamental, 40 A third harmonic and 30 A fifth harmonic, with all other components zero. Use orthogonal RMS summation. In a separate balanced four-wire model, each phase has an equal in-phase 40 A third-harmonic component in the neutral reference. A proposal adds a plain capacitor bank solely because displacement PF is low; no resonance study exists.**

Total phase RMS is √12500≈111.8 A. Harmonic RMS is 50 A, so THDi relative to the 100 A fundamental is 50%. The three stated third-harmonic components sum to 120 A in the neutral model. A plain capacitor bank is not automatically a harmonic solution; evaluate spectrum and system interaction.

#### References

- [EPI CDCS public syllabus](https://www.epi-ap.com/services/1/3/5)
- [Schneider Electric conductor sizing and protection guide](https://www.electrical-installation.org/enwiki/Sizing_and_protection_of_conductors)
- [Schneider Electric protection against shock and electrical fires](https://www.electrical-installation.org/enwiki/Protection_against_electric_shocks_and_electrical_fires)
- [Schneider Electric overvoltage protection guide](https://www.electrical-installation.org/enwiki/Overvoltage_protection)
- [Schneider Electric power harmonics management](https://www.electrical-installation.org/enwiki/Power_harmonics_management)
- [Schneider Electric generator parallel-connection](https://www.electrical-installation.org/enwiki/Generator_Set_parallel-connection)

## CDCS-M06 — Battery systems, reserve restoration and alternative ride-through

### CDCS-L06 — Battery systems, reserve restoration and alternative ride-through

Estimated study time: 120 minutes before independent work. Prerequisite chapters: CDCS-L05

## Battery terminology describes several different capabilities

A cell is an electrochemical unit; a block or module may contain several cells; a string connects units in series to obtain the required voltage; parallel strings increase available current and capacity within a supported design. Nominal voltage is a naming/design reference, not a constant terminal voltage during charge and discharge. Ampere-hours describe charge capacity at specified test conditions. Multiplying nominal volts by ampere-hours gives a nominal energy estimate, but it does not establish usable energy at every discharge rate, temperature, age or end voltage. UPS battery selection must match the manufacturer's supported DC range and performance data.

In a simple model, forty 12 V, 100 Ah blocks in series form a nominal 480 V, 100 Ah string. Series connection adds voltage while the string's ampere-hour capacity remains that of the compatible series units. Two such matched strings in parallel remain nominally 480 V and total 200 Ah. Nominal energy is 480 × 200 = 96000 Wh, or 96 kWh. If an explicitly supplied model permits 80% usable energy and assumes 90% conversion efficiency, modeled AC energy is 96 × 0.80 × 0.90 = 69.12 kWh. At a constant 200 kW load that is 0.3456 h, or 20.736 min. These arithmetic assumptions are not a manufacturer's runtime guarantee.

Real high-rate discharge selection often uses constant-power or current tables at the specified duration, temperature and end voltage, with aging and other design factors applied under the accepted method. A battery can meet a nominal ampere-hour label yet fail the required short-duration power duty. The weakest block in a series string can constrain usable performance. Do not mix arbitrary ages, chemistries, capacities or states of charge because the nominal voltage matches. Replacement strategy and permitted combinations require the battery/UPS manufacturer's supported instructions and the responsible specialist's approval.

## Charging is a recovery function with its own constraints

Charging must replace removed charge while respecting the chemistry, voltage/current limits, temperature conditions and battery management. A simple charge deficit divided by constant current gives an ideal lower-bound time under the supplied assumptions, not the complete recharge curve. Replacing 40 Ah at a constant 10 A would take four hours before considering losses or a tapering stage. Lead-acid and lithium-based systems have different supported charging behavior; do not transfer a voltage setting from one chemistry to another. The exact product instructions govern float, boost, constant-current/voltage or other modes as applicable.

Charger capacity also competes with the source's total operating duty. A UPS may need to support IT load and recharge after an outage. The generator or input path must accommodate the resulting demand, and charge-current limiting may lengthen recovery. A site that experiences another outage before the required reserve is restored can have less endurance than the dashboard's nominal value. Record current state of charge, the evidence behind it, required reserve and the conditions for returning to full service. A charging status indicator is not proof that a full-capacity test has passed.

Temperature affects performance and life, but universal lifespan formulas are not a substitute for the actual product data and operating history. Review ambient and cell temperatures, ventilation, spacing, access, monitoring and abnormal-condition response. Valve-regulated lead-acid batteries are not a promise of zero gas under every condition; lithium-based systems require their supported management and protective arrangements. Chemistry influences enclosure, fire, ventilation, spill and maintenance considerations. The responsible electrical, fire and mechanical specialists must assess the installation under applicable requirements.

## Parallel strings need engineered current paths and isolation

Parallel strings can increase capacity but create additional fault and maintenance paths. Their voltage compatibility, connection resistance, protection, isolation, cable arrangement and monitoring must be supported. Unequal resistance can produce unequal current sharing; identical block labels do not prove balanced operation. A disconnected string changes capacity and may change the remaining strings' discharge stress. An open protective device on one string may remain hidden in an aggregate voltage reading because another string maintains the bus. Per-string status and appropriate measurements help identify the actual available arrangement.

Do not assume a shared DC bus makes all strings interchangeable or safe to connect at any moment. State-of-charge and voltage differences can cause significant equalization currents, and DC systems can present sustained arc and stored-energy hazards. This course provides design and evidence literacy, not connection instructions. Approved procedures, competent personnel and the equipment's protective design govern physical work. A paper diagram should identify the intended isolations and monitoring interfaces without claiming that a device is physically de-energized.

Battery cabinets and racks are part of the system. Evaluate load, restraint, access for inspection/replacement, clearances, terminal protection, cable routing, ventilation, thermal conditions and chemistry-specific needs. A cabinet selected only because the blocks fit can obstruct inspection or violate the supported installation arrangement. Clear identification of strings, blocks and polarity supports maintenance and evidence traceability, but labels alone do not validate the physical connections. Preserve serial/age history so a later weak-block result can be related to actual equipment and replacement decisions.

## Testing asks a defined performance question

Visual inspection, voltage measurement, internal-resistance or conductance trending and controlled discharge tests provide different evidence. A normal open-circuit or float voltage does not prove the required capacity under load. A resistance trend can identify a change or a suspect unit, but its interpretation depends on method, baseline, temperature and manufacturer guidance; it is not automatically a runtime measurement. A discharge test evaluates performance at its stated load, duration, end condition and initial state. Record these conditions and the actual string/block observations rather than reporting only pass or fail.

Testing can temporarily reduce reserve or take a string out of service. Plan the service state, authority, load support, abort conditions and recharge/restoration before the test. The site must know when the required reserve is actually restored. A successful test of one string does not establish all parallel strings' condition, and an old test may no longer describe a changed or aged bank. Keep failed results and corrective/retest evidence. Do not replace a missing test with an invented result based on a green battery-management display.

## Flywheels and fuel cells serve different roles

A flywheel stores kinetic energy. In a supplied ideal model E = ½ J ω², with rotational inertia J and angular speed ω in radians per second. Usable energy between maximum and minimum supported speed is ½ J(ωmax² − ωmin²), not all energy at maximum speed. With J=10 kg·m², ωmax=1000 rad/s and ωmin=500 rad/s, usable mechanical energy is 3.75 MJ. At 90% conversion efficiency and a constant 100 kW load, modeled support is 3.375 MJ / 100 kJ/s = 33.75 s. Actual products have loss, power, control, speed and containment limits; the equation is a bounded educational model.

A flywheel can support short ride-through or transitions in a suitable architecture, but it does not automatically meet a long-duration autonomy requirement. Its bearings, vacuum or other product-specific subsystems and protective containment require manufacturer-supported operation and maintenance. Compare energy, power, duration, recharge/recovery and failure behavior rather than calling every storage technology equivalent because each can supply electricity. The design should specify what bridges source start and what supports extended operation.

A fuel cell converts supplied fuel's chemical energy into electricity through electrochemical processes. A hydrogen system's point-of-use reaction produces electricity, heat and water, while lifecycle emissions depend on hydrogen production, delivery and the full system. A fuel cell is not an indefinitely self-supplying battery: fuel, air, cooling, controls and supporting equipment must remain available. Net output subtracts auxiliary demand from gross stack output. Startup and transient response depend on the technology/product and may require a separate ride-through source. Hydrogen storage, ventilation, detection and emergency response require competent specialist design and applicable rules.

The final storage review should connect the required duration and source sequence to a supported bank or alternative technology, identify measurement and protection interfaces, and define commissioning, routine assessment and trusted restoration. The app teaches the mechanisms and calculations; actual battery handling, discharge tests, flywheel service and hydrogen-system work remain external practical gates.


#### Worked demonstrations

**Series strings and a bounded runtime estimate**

Synthetic training case — not a field record.

Each synthetic block is nominally 12 V and 100 Ah. Forty compatible blocks form one series string; two matched strings are paralleled. For this simplified energy model only, usable fraction is 0.80 and conversion efficiency is 0.90. Constant AC load is 200 kW. Manufacturer discharge curves, temperature and aging factors have not been supplied.

**Reasoning:** One string is 480 V, 100 Ah; two strings are 480 V, 200 Ah. Nominal energy is 96 kWh; modeled usable AC energy is 69.12 kWh and duration 20.736 min. The missing discharge and condition data prevent a vendor-qualified runtime claim.

**Recharge time and the next outage**

Synthetic training case — not a field record.

A test removes a modeled 40 Ah from a string. The charger can provide 10 A in an initial constant-current stage, but later taper and losses are not modeled. The operating source has only 3 kW of spare real-power capacity; proposed charging demand is 5 kW at the defined input boundary. A second outage occurs after two hours. The dashboard says charging, and no full-reserve acceptance is recorded.

**Reasoning:** The ideal constant-current replacement time is four hours; actual recharge may take longer. The proposed 5 kW charging demand exceeds 3 kW source headroom. After two hours at 10 A, only 20 Ah is replaced in the ideal model, so full reserve is not established. Chemistry-specific charging and installation requirements remain necessary.

**A green aggregate voltage with an isolated string**

Synthetic training case — not a field record.

Two strings normally share one DC bus. String S2’s protective device is open, while S1 maintains a normal aggregate bus voltage. A conductance trend flags one S1 block compared with its own baseline. A discharge test from last year covered S2 only. The report says both strings are fully available because bus voltage is normal. A proposed test would remove S1 without a service-state review.

**Reasoning:** Normal bus voltage does not prove S2 is connected or that both strings have capacity. Investigate S1’s trend with the supported method; conductance is not a direct runtime measurement. The old S2 test cannot establish current S1 performance. Plan the unavailable state and restoration before testing.

**Flywheel ride-through and fuel-cell net output**

Synthetic training case — not a field record.

An ideal flywheel has J=10 kg·m², maximum speed 1000 rad/s and minimum usable speed 500 rad/s. Conversion efficiency is 90%; load is a constant 100 kW. Ignore other losses for this model. Separately, a hydrogen fuel-cell stack produces 120 kW gross and needs 15 kW auxiliaries. Its startup time and fuel delivery during an outage are unverified.

**Reasoning:** Usable mechanical energy is 0.5×10×(1000²−500²)=3.75 MJ. AC energy is 3.375 MJ, supporting 100 kW for 33.75 s. Fuel-cell net output is 105 kW, but startup, fuel and supporting-system evidence are needed before assigning a continuity role. Point-of-use products do not establish lifecycle emissions.

#### Guided practice

Calculate the supplied bank and flywheel models, then assess recharge, string availability and fuel-cell readiness evidence.

**Hint:** Nominal energy, usable energy, present reserve and demonstrated performance are different quantities.

**Worked solution:** The bank is nominally 480 V/200 Ah and 96 kWh, with 69.12 kWh modeled AC energy or 20.736 minutes. Ideal recharge is four hours before omitted effects; two hours replaces only 20 Ah. A normal bus voltage does not prove the isolated string. The flywheel model gives 33.75 seconds and the fuel cell 105 kW net, with startup and fuel dependencies still open.

#### Independent task

Environment: analytical

Build a stored-energy requirements and evidence worksheet with a recharge/recovery plan.

**Packaged starter material**

- course_labs/CDCS/README.md
- course_labs/CDCS/fixture.json
- course_labs/CDCS/assessment_template.md
- course_labs/CDCS/lab.py
- course_labs/CDCS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- Series/parallel and energy calculations
- Supported-runtime data request
- Per-string test/availability register
- Alternative-technology duty and dependency comparison

**Acceptance criteria**

- Nominal calculations are not presented as vendor-qualified runtime.
- Reserve recovery and maintenance unavailable states are explicit.
- Battery, flywheel and hydrogen physical work remains with authorized competent personnel.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer.

#### Chapter practice

**CDCS-Q0241 · single · calculation**

What is one string’s nominal voltage?

Synthetic training case — not a field record.

Each synthetic block is nominally 12 V and 100 Ah. Forty compatible blocks form one series string; two matched strings are paralleled. For this simplified energy model only, usable fraction is 0.80 and conversion efficiency is 0.90. Constant AC load is 200 kW. Manufacturer discharge curves, temperature and aging factors have not been supplied.

1. 4000 V
2. 12 V
3. 24 V
4. 480 V

**Correct option(s):** 4

- Option 1: That multiplies block count by ampere-hours instead of voltage.
- Option 2: That would ignore series voltage addition.
- Option 3: That counts only the two parallel strings incorrectly.
- Option 4: Forty series blocks times 12 V.

**CDCS-Q0242 · single · calculation**

What is one series string’s nominal charge capacity?

Synthetic training case — not a field record.

Each synthetic block is nominally 12 V and 100 Ah. Forty compatible blocks form one series string; two matched strings are paralleled. For this simplified energy model only, usable fraction is 0.80 and conversion efficiency is 0.90. Constant AC load is 200 kW. Manufacturer discharge curves, temperature and aging factors have not been supplied.

1. 200 Ah
2. 4000 Ah
3. 100 Ah
4. 480 Ah

**Correct option(s):** 3

- Option 1: That is the two-string parallel bank capacity.
- Option 2: That incorrectly adds ampere-hours in series.
- Option 3: Compatible series units add voltage rather than ampere-hours.
- Option 4: That confuses voltage with charge capacity.

**CDCS-Q0243 · single · calculation**

What is the two-string bank’s nominal voltage and capacity?

Synthetic training case — not a field record.

Each synthetic block is nominally 12 V and 100 Ah. Forty compatible blocks form one series string; two matched strings are paralleled. For this simplified energy model only, usable fraction is 0.80 and conversion efficiency is 0.90. Constant AC load is 200 kW. Manufacturer discharge curves, temperature and aging factors have not been supplied.

1. 960 V and 100 Ah
2. 480 V and 200 Ah
3. 480 V and 100 Ah
4. 24 V and 4000 Ah

**Correct option(s):** 2

- Option 1: That describes series connection of strings, not parallel.
- Option 2: Parallel strings retain voltage and add compatible capacity.
- Option 3: That omits the second matched string’s capacity.
- Option 4: That reverses the series/parallel relationships.

**CDCS-Q0244 · single · calculation**

What is nominal bank energy?

Synthetic training case — not a field record.

Each synthetic block is nominally 12 V and 100 Ah. Forty compatible blocks form one series string; two matched strings are paralleled. For this simplified energy model only, usable fraction is 0.80 and conversion efficiency is 0.90. Constant AC load is 200 kW. Manufacturer discharge curves, temperature and aging factors have not been supplied.

1. 96 kWh
2. 2.4 kWh
3. 96000 kWh
4. 480 kWh

**Correct option(s):** 1

- Option 1: 480 V times 200 Ah equals 96000 Wh.
- Option 2: That corresponds to only two 12 V, 100 Ah blocks.
- Option 3: That omits the Wh-to-kWh conversion.
- Option 4: That uses voltage alone as energy.

**CDCS-Q0245 · single · calculation**

What is modeled usable AC energy with the supplied factors?

Synthetic training case — not a field record.

Each synthetic block is nominally 12 V and 100 Ah. Forty compatible blocks form one series string; two matched strings are paralleled. For this simplified energy model only, usable fraction is 0.80 and conversion efficiency is 0.90. Constant AC load is 200 kW. Manufacturer discharge curves, temperature and aging factors have not been supplied.

1. 133.33 kWh
2. 76.8 kWh
3. 69.12 kWh
4. 86.4 kWh

**Correct option(s):** 3

- Option 1: That divides by both factors and incorrectly increases usable energy.
- Option 2: That applies usable fraction but omits conversion loss.
- Option 3: 96 × 0.80 × 0.90.
- Option 4: That applies efficiency but omits usable fraction.

**CDCS-Q0246 · single · calculation**

What is modeled duration at 200 kW?

Synthetic training case — not a field record.

Each synthetic block is nominally 12 V and 100 Ah. Forty compatible blocks form one series string; two matched strings are paralleled. For this simplified energy model only, usable fraction is 0.80 and conversion efficiency is 0.90. Constant AC load is 200 kW. Manufacturer discharge curves, temperature and aging factors have not been supplied.

1. 0.3456 minutes
2. 34.56 minutes
3. 28.8 minutes
4. 20.736 minutes

**Correct option(s):** 4

- Option 1: That leaves an hours result mislabeled as minutes.
- Option 2: That is not the supplied energy/power conversion.
- Option 3: That uses all nominal energy without the factors.
- Option 4: 69.12/200 hours multiplied by 60.

**CDCS-Q0247 · single · mechanism**

Why is this not a supported high-rate runtime guarantee?

Synthetic training case — not a field record.

Each synthetic block is nominally 12 V and 100 Ah. Forty compatible blocks form one series string; two matched strings are paralleled. For this simplified energy model only, usable fraction is 0.80 and conversion efficiency is 0.90. Constant AC load is 200 kW. Manufacturer discharge curves, temperature and aging factors have not been supplied.

1. The load is expressed in kW
2. Ampere-hours can never be used in any battery assessment
3. Actual discharge curves, end voltage, temperature and age are missing
4. The series/parallel arithmetic is always invalid

**Correct option(s):** 3

- Option 1: Power is appropriate for a constant-power duration estimate.
- Option 2: They are useful when their test conditions are understood.
- Option 3: Nominal energy arithmetic does not establish those conditions.
- Option 4: It is valid within its stated ideal assumptions.

**CDCS-Q0248 · single · mechanism**

What does a weak block in a series string potentially do?

Synthetic training case — not a field record.

Each synthetic block is nominally 12 V and 100 Ah. Forty compatible blocks form one series string; two matched strings are paralleled. For this simplified energy model only, usable fraction is 0.80 and conversion efficiency is 0.90. Constant AC load is 200 kW. Manufacturer discharge curves, temperature and aging factors have not been supplied.

1. Constrain the string’s usable performance
2. Affect only the dashboard label
3. Become irrelevant when another string is paralleled
4. Automatically double the healthy blocks’ capacity

**Correct option(s):** 1

- Option 1: The series path depends on each block’s condition.
- Option 2: Physical block condition can limit discharge.
- Option 3: Parallel capacity does not erase the weak string’s condition.
- Option 4: Other blocks do not create extra capacity.

**CDCS-Q0249 · single · design**

What must a replacement block selection verify?

Synthetic training case — not a field record.

Each synthetic block is nominally 12 V and 100 Ah. Forty compatible blocks form one series string; two matched strings are paralleled. For this simplified energy model only, usable fraction is 0.80 and conversion efficiency is 0.90. Constant AC load is 200 kW. Manufacturer discharge curves, temperature and aging factors have not been supplied.

1. Only a newer manufacturing date
2. Only that its terminals physically fit
3. Only equal open-circuit voltage at receipt
4. Supported chemistry, capacity, condition and permitted mixing rules

**Correct option(s):** 4

- Option 1: Age alone does not define a supported combination.
- Option 2: Fit does not establish electrochemical compatibility.
- Option 3: That does not establish capacity, chemistry or supported mixing.
- Option 4: Matching nominal voltage alone is insufficient.

**CDCS-Q0250 · single · design**

What should the design-review result say?

Synthetic training case — not a field record.

Each synthetic block is nominally 12 V and 100 Ah. Forty compatible blocks form one series string; two matched strings are paralleled. For this simplified energy model only, usable fraction is 0.80 and conversion efficiency is 0.90. Constant AC load is 200 kW. Manufacturer discharge curves, temperature and aging factors have not been supplied.

1. No further testing is needed because the arithmetic has decimals
2. The bank is certified for exactly 20.736 minutes at every age
3. The model estimates 20.736 minutes, pending supported performance validation
4. The learner may parallel any two banks with matching voltage

**Correct option(s):** 3

- Option 1: Precision does not supply missing performance evidence.
- Option 2: That overstates precision and scope.
- Option 3: The claim stays within its evidence.
- Option 4: Physical connection requires supported design and authority.

**CDCS-Q0251 · single · calculation**

What is the ideal constant-current time to replace 40 Ah at 10 A?

Synthetic training case — not a field record.

A test removes a modeled 40 Ah from a string. The charger can provide 10 A in an initial constant-current stage, but later taper and losses are not modeled. The operating source has only 3 kW of spare real-power capacity; proposed charging demand is 5 kW at the defined input boundary. A second outage occurs after two hours. The dashboard says charging, and no full-reserve acceptance is recorded.

1. 40 hours
2. 4 hours
3. 0.25 hours
4. 10 hours

**Correct option(s):** 2

- Option 1: That ignores the 10 A charging rate.
- Option 2: Charge divided by current gives time.
- Option 3: That reverses the division.
- Option 4: That uses the current value as duration.

**CDCS-Q0252 · single · recovery**

Why can actual recharge exceed that ideal time?

Synthetic training case — not a field record.

A test removes a modeled 40 Ah from a string. The charger can provide 10 A in an initial constant-current stage, but later taper and losses are not modeled. The operating source has only 3 kW of spare real-power capacity; proposed charging demand is 5 kW at the defined input boundary. A second outage occurs after two hours. The dashboard says charging, and no full-reserve acceptance is recorded.

1. The dashboard’s word charging guarantees immediate full reserve
2. Tapering, losses and product-specific charging constraints are omitted
3. Ampere-hours are unrelated to charge replacement
4. Every battery always charges at increasing current until full

**Correct option(s):** 2

- Option 1: Status is not completed capacity restoration.
- Option 2: The simple quotient is not the full charging profile.
- Option 3: They describe charge quantity under stated conditions.
- Option 4: Actual supported profiles differ.

**CDCS-Q0253 · single · calculation**

What is the source-headroom mismatch?

Synthetic training case — not a field record.

A test removes a modeled 40 Ah from a string. The charger can provide 10 A in an initial constant-current stage, but later taper and losses are not modeled. The operating source has only 3 kW of spare real-power capacity; proposed charging demand is 5 kW at the defined input boundary. A second outage occurs after two hours. The dashboard says charging, and no full-reserve acceptance is recorded.

1. Only battery voltage matters to the input source
2. Charging creates 2 kW extra source capacity
3. The source automatically ignores charging load
4. 5 kW proposed charging demand exceeds 3 kW spare capacity

**Correct option(s):** 4

- Option 1: Real-power demand also matters.
- Option 2: It consumes rather than creates input power.
- Option 3: The defined boundary includes it.
- Option 4: The source must support both ongoing load and charging.

**CDCS-Q0254 · single · calculation**

How much charge is replaced in two hours in the ideal constant-current model?

Synthetic training case — not a field record.

A test removes a modeled 40 Ah from a string. The charger can provide 10 A in an initial constant-current stage, but later taper and losses are not modeled. The operating source has only 3 kW of spare real-power capacity; proposed charging demand is 5 kW at the defined input boundary. A second outage occurs after two hours. The dashboard says charging, and no full-reserve acceptance is recorded.

1. 5 Ah
2. 40 Ah
3. 10 Ah
4. 20 Ah

**Correct option(s):** 4

- Option 1: That divides rather than multiplies current and time.
- Option 2: That would require four ideal hours.
- Option 3: That counts only one hour.
- Option 4: 10 A times two hours.

**CDCS-Q0255 · single · operations**

What is the reserve status before the second outage?

Synthetic training case — not a field record.

A test removes a modeled 40 Ah from a string. The charger can provide 10 A in an initial constant-current stage, but later taper and losses are not modeled. The operating source has only 3 kW of spare real-power capacity; proposed charging demand is 5 kW at the defined input boundary. A second outage occurs after two hours. The dashboard says charging, and no full-reserve acceptance is recorded.

1. Exactly the original runtime under every load
2. Guaranteed full because charging is displayed
3. Full reserve is not established by the supplied evidence
4. Guaranteed zero because any test destroys the battery

**Correct option(s):** 3

- Option 1: Initial state and actual recovered performance are not established.
- Option 2: The status does not prove completion.
- Option 3: The ideal model replaces only half the removed charge.
- Option 4: Testing does not imply total loss of capacity.

**CDCS-Q0256 · single · operations**

What should a charge-current limit change assess?

Synthetic training case — not a field record.

A test removes a modeled 40 Ah from a string. The charger can provide 10 A in an initial constant-current stage, but later taper and losses are not modeled. The operating source has only 3 kW of spare real-power capacity; proposed charging demand is 5 kW at the defined input boundary. A second outage occurs after two hours. The dashboard says charging, and no full-reserve acceptance is recorded.

1. Only the appearance of the charger screen
2. Source capacity, recharge duration and the required recovery commitment
3. Nothing because charging is outside operations
4. Only the battery cabinet dimensions

**Correct option(s):** 2

- Option 1: The change affects physical recovery.
- Option 2: Reducing charging demand can lengthen reserve restoration.
- Option 3: Recovery readiness is an operational requirement.
- Option 4: Dimensions do not calculate charging duration.

**CDCS-Q0257 · single · mechanism**

Why not copy charging voltage from a different chemistry?

Synthetic training case — not a field record.

A test removes a modeled 40 Ah from a string. The charger can provide 10 A in an initial constant-current stage, but later taper and losses are not modeled. The operating source has only 3 kW of spare real-power capacity; proposed charging demand is 5 kW at the defined input boundary. A second outage occurs after two hours. The dashboard says charging, and no full-reserve acceptance is recorded.

1. Supported electrochemical limits and management behavior differ
2. Nominal voltage alone defines every charge stage
3. All chemistries have identical charge curves
4. A higher voltage always restores reserve safely faster

**Correct option(s):** 1

- Option 1: A setting suitable for one system may be unsuitable for another.
- Option 2: It does not supply the complete profile.
- Option 3: They do not.
- Option 4: That is not a valid universal rule.

**CDCS-Q0258 · single · design**

What should cabinet selection consider beyond physical fit?

Synthetic training case — not a field record.

A test removes a modeled 40 Ah from a string. The charger can provide 10 A in an initial constant-current stage, but later taper and losses are not modeled. The operating source has only 3 kW of spare real-power capacity; proposed charging demand is 5 kW at the defined input boundary. A second outage occurs after two hours. The dashboard says charging, and no full-reserve acceptance is recorded.

1. Only the number of blocks that can be packed inside
2. Thermal conditions, access, protection and chemistry-specific installation needs
3. Only the building’s total floor area
4. Only the UPS management protocol

**Correct option(s):** 2

- Option 1: Fit alone can compromise service and safety.
- Option 2: The enclosure is part of the supported system.
- Option 3: Local loading and installation conditions still matter.
- Option 4: Communications do not establish enclosure suitability.

**CDCS-Q0259 · single · mechanism**

What is wrong with calling valve-regulated lead-acid batteries gas-free under all conditions?

Synthetic training case — not a field record.

A test removes a modeled 40 Ah from a string. The charger can provide 10 A in an initial constant-current stage, but later taper and losses are not modeled. The operating source has only 3 kW of spare real-power capacity; proposed charging demand is 5 kW at the defined input boundary. A second outage occurs after two hours. The dashboard says charging, and no full-reserve acceptance is recorded.

1. Valve-regulated construction does not eliminate every possible gas release
2. They have no electrochemical reactions
3. Normal recombination performance guarantees no venting in abnormal conditions
4. Every such battery must continuously vent at the same rate

**Correct option(s):** 1

- Option 1: Installation and abnormal-condition requirements still apply.
- Option 2: Electrochemical processes are their operating mechanism.
- Option 3: The normal mechanism does not remove every abnormal release possibility.
- Option 4: That is also an unsupported universal claim.

**CDCS-Q0260 · single · recovery**

What evidence should close recharge recovery?

Synthetic training case — not a field record.

A test removes a modeled 40 Ah from a string. The charger can provide 10 A in an initial constant-current stage, but later taper and losses are not modeled. The operating source has only 3 kW of spare real-power capacity; proposed charging demand is 5 kW at the defined input boundary. A second outage occurs after two hours. The dashboard says charging, and no full-reserve acceptance is recorded.

1. The required reserve/condition criteria under the supported method and operating restrictions
2. Only the previous month’s capacity result
3. Only elapsed time since the charger was enabled
4. Only a reset of the battery alarm

**Correct option(s):** 1

- Option 1: A completed recovery decision needs more than an in-progress status.
- Option 2: The current post-test state is different.
- Option 3: Actual current, stages and condition may differ.
- Option 4: Alarm reset does not create stored energy.

**CDCS-Q0261 · single · mechanism**

Why is the aggregate voltage misleading as an availability proof?

Synthetic training case — not a field record.

Two strings normally share one DC bus. String S2’s protective device is open, while S1 maintains a normal aggregate bus voltage. A conductance trend flags one S1 block compared with its own baseline. A discharge test from last year covered S2 only. The report says both strings are fully available because bus voltage is normal. A proposed test would remove S1 without a service-state review.

1. Two parallel strings always have twice the voltage of one
2. An open S2 device automatically drives bus voltage to zero
3. S1 can maintain bus voltage while S2 is disconnected
4. Voltage measurements are never useful

**Correct option(s):** 3

- Option 1: Parallel connection retains nominal voltage.
- Option 2: S1 remains connected.
- Option 3: The aggregate reading hides the per-string state.
- Option 4: They are useful for their actual scope.

**CDCS-Q0262 · single · operations**

What evidence directly identifies S2’s present connection status?

Synthetic training case — not a field record.

Two strings normally share one DC bus. String S2’s protective device is open, while S1 maintains a normal aggregate bus voltage. A conductance trend flags one S1 block compared with its own baseline. A discharge test from last year covered S2 only. The report says both strings are fully available because bus voltage is normal. A proposed test would remove S1 without a service-state review.

1. Only the total cabinet count
2. Only the shared bus voltage
3. Only last year’s S2 test certificate
4. Its protective/isolation state with appropriate verified records

**Correct option(s):** 4

- Option 1: Installed cabinets do not prove connected strings.
- Option 2: That can remain normal through S1.
- Option 3: Historical performance does not show current connection.
- Option 4: The open device is material to availability.

**CDCS-Q0263 · single · mechanism**

What does the S1 conductance trend establish by itself?

Synthetic training case — not a field record.

Two strings normally share one DC bus. String S2’s protective device is open, while S1 maintains a normal aggregate bus voltage. A conductance trend flags one S1 block compared with its own baseline. A discharge test from last year covered S2 only. The report says both strings are fully available because bus voltage is normal. A proposed test would remove S1 without a service-state review.

1. Proof that the block must be healthy because voltage is normal
2. Proof that every block in both strings has failed
3. A precise remaining runtime at every load
4. A measured change or anomaly relative to the defined baseline

**Correct option(s):** 4

- Option 1: Different observations can reveal different conditions.
- Option 2: The trend concerns one identified block.
- Option 3: Conductance is not a direct runtime test.
- Option 4: Its meaning requires supported interpretation.

**CDCS-Q0264 · single · operations**

What should be retained with a conductance comparison?

Synthetic training case — not a field record.

Two strings normally share one DC bus. String S2’s protective device is open, while S1 maintains a normal aggregate bus voltage. A conductance trend flags one S1 block compared with its own baseline. A discharge test from last year covered S2 only. The report says both strings are fully available because bus voltage is normal. A proposed test would remove S1 without a service-state review.

1. Only the latest rounded number
2. Only an average baseline from a different block type
3. Method, baseline, temperature, identity and measurement conditions
4. Only a green overall battery icon

**Correct option(s):** 3

- Option 1: It lacks the context needed to judge change.
- Option 2: Different construction and conditions can make that comparison unsuitable.
- Option 3: These affect interpretation and comparability.
- Option 4: The summary does not explain the trend.

**CDCS-Q0265 · single · mechanism**

What does last year’s S2 discharge test support?

Synthetic training case — not a field record.

Two strings normally share one DC bus. String S2’s protective device is open, while S1 maintains a normal aggregate bus voltage. A conductance trend flags one S1 block compared with its own baseline. A discharge test from last year covered S2 only. The report says both strings are fully available because bus voltage is normal. A proposed test would remove S1 without a service-state review.

1. Automatic approval to remove S1 today
2. S1’s current block conductance values
3. Current full capacity of every string
4. S2 performance under that test’s recorded conditions and date

**Correct option(s):** 4

- Option 1: The current service state needs review.
- Option 2: S1 was not the tested string.
- Option 3: The scope and time do not support that.
- Option 4: It does not prove current S1 capacity.

**CDCS-Q0266 · single · operations**

What must be assessed before removing S1 for the proposed test?

Synthetic training case — not a field record.

Two strings normally share one DC bus. String S2’s protective device is open, while S1 maintains a normal aggregate bus voltage. A conductance trend flags one S1 block compared with its own baseline. A discharge test from last year covered S2 only. The report says both strings are fully available because bus voltage is normal. A proposed test would remove S1 without a service-state review.

1. The service consequence when S2 is already open and the required alternative support
2. Only whether the test instrument is available
3. Only the normal bus voltage before removal
4. Only the original design’s two-string capacity total

**Correct option(s):** 1

- Option 1: The test may remove the only connected string.
- Option 2: Service capability and authority also matter.
- Option 3: It does not prove another string will support the load.
- Option 4: The current open S2 state makes that total unavailable.

**CDCS-Q0267 · single · implementation**

What should a capacity test record?

Synthetic training case — not a field record.

Two strings normally share one DC bus. String S2’s protective device is open, while S1 maintains a normal aggregate bus voltage. A conductance trend flags one S1 block compared with its own baseline. A discharge test from last year covered S2 only. The report says both strings are fully available because bus voltage is normal. A proposed test would remove S1 without a service-state review.

1. Only a final pass word
2. Load, duration, end condition, initial state and string/block observations
3. Only open-circuit voltage before the test
4. Only the battery supplier’s average catalogue life

**Correct option(s):** 2

- Option 1: That omits conditions and scope.
- Option 2: These define the performance question actually tested.
- Option 3: That does not measure sustained discharge performance.
- Option 4: Age expectations are not this test’s evidence.

**CDCS-Q0268 · single · mechanism**

Why review parallel connection resistance and routing?

Synthetic training case — not a field record.

Two strings normally share one DC bus. String S2’s protective device is open, while S1 maintains a normal aggregate bus voltage. A conductance trend flags one S1 block compared with its own baseline. A discharge test from last year covered S2 only. The report says both strings are fully available because bus voltage is normal. A proposed test would remove S1 without a service-state review.

1. Unequal paths can contribute to unequal current sharing
2. Identical block capacities make connection resistance irrelevant
3. The highest-resistance path always carries all current
4. Parallel current is always exactly equal regardless of resistance

**Correct option(s):** 1

- Option 1: Identical labels do not ensure balanced physical currents.
- Option 2: Physical path differences can still affect sharing.
- Option 3: That reverses the usual sharing tendency in the simple model.
- Option 4: The circuit paths can influence sharing.

**CDCS-Q0269 · single · operations**

What must follow a test that depletes reserve?

Synthetic training case — not a field record.

Two strings normally share one DC bus. String S2’s protective device is open, while S1 maintains a normal aggregate bus voltage. A conductance trend flags one S1 block compared with its own baseline. A discharge test from last year covered S2 only. The report says both strings are fully available because bus voltage is normal. A proposed test would remove S1 without a service-state review.

1. Automatic cancellation of all battery monitoring
2. Deletion of the discharge trace
3. Immediate full-availability declaration regardless of charge
4. Controlled recharge and verification of the required restored service state

**Correct option(s):** 4

- Option 1: Monitoring remains relevant during recovery.
- Option 2: The trace supports the result and later review.
- Option 3: The stored-energy condition has changed.
- Option 4: Testing completion does not mean reserve is restored.

**CDCS-Q0270 · single · operations**

What is a defensible report correction?

Synthetic training case — not a field record.

Two strings normally share one DC bus. String S2’s protective device is open, while S1 maintains a normal aggregate bus voltage. A conductance trend flags one S1 block compared with its own baseline. A discharge test from last year covered S2 only. The report says both strings are fully available because bus voltage is normal. A proposed test would remove S1 without a service-state review.

1. S2 is isolated; S1 supports the bus and has a block anomaly requiring review
2. S1 runtime equals S2’s old result
3. Both strings healthy because nominal voltage is present
4. Both strings failed because one device is open

**Correct option(s):** 1

- Option 1: It states actual connection and evidence limits.
- Option 2: The scope and date do not justify transferring the result.
- Option 3: That repeats the unsupported inference.
- Option 4: S1 still supports the bus in the supplied state.

**CDCS-Q0271 · single · calculation**

What is the flywheel’s usable mechanical energy between the stated speeds?

Synthetic training case — not a field record.

An ideal flywheel has J=10 kg·m², maximum speed 1000 rad/s and minimum usable speed 500 rad/s. Conversion efficiency is 90%; load is a constant 100 kW. Ignore other losses for this model. Separately, a hydrogen fuel-cell stack produces 120 kW gross and needs 15 kW auxiliaries. Its startup time and fuel delivery during an outage are unverified.

1. 2.5 MJ
2. 3.75 MJ
3. 1.25 MJ
4. 5 MJ

**Correct option(s):** 2

- Option 1: That applies the speed difference without the required squared relationship.
- Option 2: Use half J times the difference of squared speeds.
- Option 3: That is energy remaining at minimum speed.
- Option 4: That is energy at maximum speed without subtracting the minimum-speed reserve.

**CDCS-Q0272 · single · calculation**

What AC energy remains after the stated conversion efficiency?

Synthetic training case — not a field record.

An ideal flywheel has J=10 kg·m², maximum speed 1000 rad/s and minimum usable speed 500 rad/s. Conversion efficiency is 90%; load is a constant 100 kW. Ignore other losses for this model. Separately, a hydrogen fuel-cell stack produces 120 kW gross and needs 15 kW auxiliaries. Its startup time and fuel delivery during an outage are unverified.

1. 4.167 MJ
2. 0.375 MJ
3. 3.375 MJ
4. 3.75 MJ

**Correct option(s):** 3

- Option 1: That divides by efficiency and increases delivered energy.
- Option 2: That is the loss, not delivered energy.
- Option 3: 3.75 multiplied by 0.90.
- Option 4: That ignores conversion loss.

**CDCS-Q0273 · single · calculation**

What is the modeled support duration at 100 kW?

Synthetic training case — not a field record.

An ideal flywheel has J=10 kg·m², maximum speed 1000 rad/s and minimum usable speed 500 rad/s. Conversion efficiency is 90%; load is a constant 100 kW. Ignore other losses for this model. Separately, a hydrogen fuel-cell stack produces 120 kW gross and needs 15 kW auxiliaries. Its startup time and fuel delivery during an outage are unverified.

1. 50 seconds
2. 33.75 hours
3. 33.75 seconds
4. 37.5 seconds

**Correct option(s):** 3

- Option 1: That uses all maximum-speed energy without minimum speed or conversion loss.
- Option 2: That mislabels the energy/power units.
- Option 3: 3.375 MJ divided by 100 kJ/s.
- Option 4: That ignores the stated conversion loss.

**CDCS-Q0274 · single · mechanism**

Why subtract energy at minimum usable speed?

Synthetic training case — not a field record.

An ideal flywheel has J=10 kg·m², maximum speed 1000 rad/s and minimum usable speed 500 rad/s. Conversion efficiency is 90%; load is a constant 100 kW. Ignore other losses for this model. Separately, a hydrogen fuel-cell stack produces 120 kW gross and needs 15 kW auxiliaries. Its startup time and fuel delivery during an outage are unverified.

1. The system cannot use the modeled energy below its supported operating boundary
2. The subtraction accounts for hydrogen fuel consumption
3. Energy is linear in angular speed
4. The minimum speed is always zero

**Correct option(s):** 1

- Option 1: Not all stored kinetic energy is deliverable in the required mode.
- Option 2: That belongs to the separate technology case.
- Option 3: The supplied kinetic model is quadratic.
- Option 4: The case supplies 500 rad/s.

**CDCS-Q0275 · single · calculation**

What is the fuel-cell system’s net output in the supplied boundary?

Synthetic training case — not a field record.

An ideal flywheel has J=10 kg·m², maximum speed 1000 rad/s and minimum usable speed 500 rad/s. Conversion efficiency is 90%; load is a constant 100 kW. Ignore other losses for this model. Separately, a hydrogen fuel-cell stack produces 120 kW gross and needs 15 kW auxiliaries. Its startup time and fuel delivery during an outage are unverified.

1. 105 kW
2. 120 kW
3. 15 kW
4. 135 kW

**Correct option(s):** 1

- Option 1: 120 gross minus 15 auxiliary demand.
- Option 2: That omits the auxiliaries.
- Option 3: That is auxiliary consumption, not net output.
- Option 4: That adds consumed auxiliary power to delivered output.

**CDCS-Q0276 · single · operations**

What prevents assigning immediate ride-through duty to this fuel cell from the data alone?

Synthetic training case — not a field record.

An ideal flywheel has J=10 kg·m², maximum speed 1000 rad/s and minimum usable speed 500 rad/s. Conversion efficiency is 90%; load is a constant 100 kW. Ignore other losses for this model. Separately, a hydrogen fuel-cell stack produces 120 kW gross and needs 15 kW auxiliaries. Its startup time and fuel delivery during an outage are unverified.

1. Startup and transient response are unverified
2. The gross rating is expressed in kW
3. Fuel cells can never supply electricity
4. The auxiliaries are smaller than the gross output

**Correct option(s):** 1

- Option 1: Net steady power does not establish immediate availability.
- Option 2: Power is a relevant quantity.
- Option 3: They convert fuel energy to electrical output.
- Option 4: That permits positive net output but does not prove startup behavior.

**CDCS-Q0277 · single · mechanism**

What ongoing dependency distinguishes the fuel cell from a finite charged battery in this comparison?

Synthetic training case — not a field record.

An ideal flywheel has J=10 kg·m², maximum speed 1000 rad/s and minimum usable speed 500 rad/s. Conversion efficiency is 90%; load is a constant 100 kW. Ignore other losses for this model. Separately, a hydrogen fuel-cell stack produces 120 kW gross and needs 15 kW auxiliaries. Its startup time and fuel delivery during an outage are unverified.

1. It generates fuel without any external input indefinitely
2. It needs no cooling or controls under any condition
3. Continued suitable fuel and supporting services
4. It automatically recharges the flywheel without an electrical connection

**Correct option(s):** 3

- Option 1: That is not the stated mechanism.
- Option 2: Supporting systems can be essential.
- Option 3: Its energy production depends on supplied reactants and auxiliaries.
- Option 4: No such integration is supplied.

**CDCS-Q0278 · single · mechanism**

What does hydrogen point-of-use operation not establish?

Synthetic training case — not a field record.

An ideal flywheel has J=10 kg·m², maximum speed 1000 rad/s and minimum usable speed 500 rad/s. Conversion efficiency is 90%; load is a constant 100 kW. Ignore other losses for this model. Separately, a hydrogen fuel-cell stack produces 120 kW gross and needs 15 kW auxiliaries. Its startup time and fuel delivery during an outage are unverified.

1. That the described reaction can produce water and heat
2. Zero lifecycle emissions for hydrogen production and delivery
3. That auxiliary demand reduces net output
4. That the system has an electrical output

**Correct option(s):** 2

- Option 1: Those are part of the hydrogen fuel-cell mechanism.
- Option 2: The full energy chain requires separate evidence.
- Option 3: The given quantities establish that reduction.
- Option 4: The gross output is supplied.

**CDCS-Q0279 · single · operations**

What should a technology comparison include beyond nameplate power?

Synthetic training case — not a field record.

An ideal flywheel has J=10 kg·m², maximum speed 1000 rad/s and minimum usable speed 500 rad/s. Conversion efficiency is 90%; load is a constant 100 kW. Ignore other losses for this model. Separately, a hydrogen fuel-cell stack produces 120 kW gross and needs 15 kW auxiliaries. Its startup time and fuel delivery during an outage are unverified.

1. Only the equipment footprint
2. Only whether the technology is called green
3. Usable energy/duration, startup, dependencies, recovery and supported limits
4. Only the largest kW number

**Correct option(s):** 3

- Option 1: Space is one constraint among several.
- Option 2: A label does not establish service or environmental performance.
- Option 3: Power alone does not define continuity capability.
- Option 4: That can hide insufficient duration or delayed startup.

**CDCS-Q0280 · single · operations**

What is the practical limit of the flywheel equation here?

Synthetic training case — not a field record.

An ideal flywheel has J=10 kg·m², maximum speed 1000 rad/s and minimum usable speed 500 rad/s. Conversion efficiency is 90%; load is a constant 100 kW. Ignore other losses for this model. Separately, a hydrogen fuel-cell stack produces 120 kW gross and needs 15 kW auxiliaries. Its startup time and fuel delivery during an outage are unverified.

1. It certifies every flywheel for the calculated duration
2. It proves no separate source-transition test is needed
3. It does not verify an actual product’s containment, losses, control or physical performance
4. It authorizes opening a running flywheel enclosure

**Correct option(s):** 3

- Option 1: Real products and conditions differ.
- Option 2: Integration behavior still requires evidence.
- Option 3: The result is an ideal supplied model.
- Option 4: No physical work is authorized.

#### Recall

**Series strings and a bounded runtime estimate — Synthetic training case — not a field record.

Each synthetic block is nominally 12 V and 100 Ah. Forty compatible blocks form one series string; two matched strings are paralleled. For this simplified energy model only, usable fraction is 0.80 and conversion efficiency is 0.90. Constant AC load is 200 kW. Manufacturer discharge curves, temperature and aging factors have not been supplied.**

One string is 480 V, 100 Ah; two strings are 480 V, 200 Ah. Nominal energy is 96 kWh; modeled usable AC energy is 69.12 kWh and duration 20.736 min. The missing discharge and condition data prevent a vendor-qualified runtime claim.

**Recharge time and the next outage — Synthetic training case — not a field record.

A test removes a modeled 40 Ah from a string. The charger can provide 10 A in an initial constant-current stage, but later taper and losses are not modeled. The operating source has only 3 kW of spare real-power capacity; proposed charging demand is 5 kW at the defined input boundary. A second outage occurs after two hours. The dashboard says charging, and no full-reserve acceptance is recorded.**

The ideal constant-current replacement time is four hours; actual recharge may take longer. The proposed 5 kW charging demand exceeds 3 kW source headroom. After two hours at 10 A, only 20 Ah is replaced in the ideal model, so full reserve is not established. Chemistry-specific charging and installation requirements remain necessary.

**A green aggregate voltage with an isolated string — Synthetic training case — not a field record.

Two strings normally share one DC bus. String S2’s protective device is open, while S1 maintains a normal aggregate bus voltage. A conductance trend flags one S1 block compared with its own baseline. A discharge test from last year covered S2 only. The report says both strings are fully available because bus voltage is normal. A proposed test would remove S1 without a service-state review.**

Normal bus voltage does not prove S2 is connected or that both strings have capacity. Investigate S1’s trend with the supported method; conductance is not a direct runtime measurement. The old S2 test cannot establish current S1 performance. Plan the unavailable state and restoration before testing.

**Flywheel ride-through and fuel-cell net output — Synthetic training case — not a field record.

An ideal flywheel has J=10 kg·m², maximum speed 1000 rad/s and minimum usable speed 500 rad/s. Conversion efficiency is 90%; load is a constant 100 kW. Ignore other losses for this model. Separately, a hydrogen fuel-cell stack produces 120 kW gross and needs 15 kW auxiliaries. Its startup time and fuel delivery during an outage are unverified.**

Usable mechanical energy is 0.5×10×(1000²−500²)=3.75 MJ. AC energy is 3.375 MJ, supporting 100 kW for 33.75 s. Fuel-cell net output is 105 kW, but startup, fuel and supporting-system evidence are needed before assigning a continuity role. Point-of-use products do not establish lifecycle emissions.

#### References

- [EPI CDCS public syllabus](https://www.epi-ap.com/services/1/3/5)
- [Schneider Electric UPS batteries](https://www.electrical-installation.org/enwiki/UPS_Batteries)
- [US Department of Energy fuel-cell principles](https://www.energy.gov/cmei/fuels/fuel-cells)

## CDCS-M07 — Electromagnetic sources, measurement and bounded mitigation

### CDCS-L07 — Electromagnetic sources, measurement and bounded mitigation

Estimated study time: 120 minutes before independent work. Prerequisite chapters: CDCS-L06

## Separate electromagnetic source, coupling and consequence

Electromagnetic-field review has two related but different purposes: assessing applicable human-exposure requirements and ensuring equipment can operate compatibly in its electromagnetic environment. Passing one does not automatically establish the other. A field below an applicable human-exposure reference may still interfere with a sensitive measurement system, and a controller that operates normally does not establish occupational exposure compliance. Identify the purpose, frequency range, field quantity, source operating state, location and acceptance authority before selecting an instrument or making a claim.

Electric fields relate to voltage and charge; magnetic fields relate to current and its geometry. In power installations, sources include transformers, busways, cables, generators, motors and switching electronics. Power-frequency fields, switching transients and radio-frequency emissions need different measurement and mitigation considerations. A generic radio-frequency meter may not measure a 50/60 Hz magnetic field correctly. Record electric field strength in appropriate units such as V/m and magnetic flux density in tesla or its scaled units. Do not compare a microtesla reading directly with a volts-per-metre limit or treat frequency-independent numbers as universally applicable.

The source is only one part of an interference problem. Coupling transfers a disturbance into a susceptible circuit through shared impedance, capacitive, inductive or radiated mechanisms. A current through a shared return impedance can shift a reference voltage; a changing magnetic field can induce voltage in a loop; fast voltage changes can couple through capacitance. A communication error that appears during a motor start is a useful correlation, but it does not by itself identify which mechanism caused it. Preserve event timing, load state, physical routing and measurement evidence before changing filters, bonds or cable screens.

## Geometry matters more than a universal distance slogan

For an ideal long straight conductor under its stated physical assumptions, magnetic field varies inversely with distance. Other source geometries and regions have different spatial behavior. A nearby multi-conductor system is not automatically a point radiator, and a far-field inverse-square power-density rule is not a universal low-frequency magnetic-field law. The correct model depends on source dimensions, return paths, frequency, material and observation location. Use a competent model or measurement over the relevant range; do not infer a universally safe separation distance from one reading.

Bringing outgoing and return conductors into the supported geometry can reduce external magnetic fields because their contributions partly cancel at some locations. In a balanced three-phase arrangement, phase relationship and conductor placement influence the resulting field. Balance does not guarantee zero field everywhere: finite spacing, unbalance, harmonics and nearby structures matter. Separating phases or routing a return far from its outgoing conductor can enlarge the effective loop and alter coupling. The electrical design must still satisfy thermal, mechanical, protection and installation requirements; electromagnetic improvement is not permission to rearrange live conductors informally.

Distance can be a useful mitigation when validated for the actual source and receiver. Moving a sensitive cable away from a busway may reduce coupling, but its route may then share a different disturbance or violate access/fire constraints. Review the complete installation. Shielding also depends on frequency and field type, material, continuity, openings, bonding and geometry. A thin conductive screen that reduces an electric field does not necessarily provide the required low-frequency magnetic attenuation. A shield claim needs a specified quantity, frequency, installation and before/after evidence.

## Measure the relevant quantity in a reproducible state

Plan a survey around the required decision. Identify source loading and operating modes, accessible locations, worker or equipment positions, relevant frequencies and time behavior. Select an instrument with appropriate sensing range, bandwidth, axis response, calibration and uncertainty. A single-axis probe can miss a field component when misoriented. A suitable three-axis instrument may report a resultant according to its defined method; verify what the display actually means rather than adding arbitrary readings. Record probe position and orientation so a later comparison can be reproduced.

In a supplied orthogonal-component model, Bx=3 µT, By=4 µT and Bz=0 give resultant √(3²+4²+0²)=5 µT. One microtesla equals ten milligauss, so the same magnitude is 50 mG. Unit conversion does not change the physical field. If expanded uncertainty is stated as ±0.6 µT, the corresponding interval is 4.4–5.6 µT under that reporting convention. An equipment acceptance threshold of 5.2 µT is crossed by the interval, so the stated decision rule must address uncertainty; reporting an unqualified pass from the central value alone is not justified. This threshold is a synthetic equipment criterion, not a human-health limit.

Measurements depend on source state. A low reading with the busway at 10% load does not necessarily represent peak operation. Motor starts or switching transients can be missed by a slow average. A survey should capture representative and required worst-case states using an authorized plan, without exposing personnel or disrupting service to create an uncontrolled test. Record what was actually observed and what remains modeled. Calibration traceability supports confidence in measurement, but the instrument must also be suitable for the quantity and range in this application.

## Quantify attenuation without overextending the model

An amplitude attenuation factor can be expressed as before-field magnitude divided by after-field magnitude under comparable conditions. Reducing 80 µT to 20 µT gives a factor of four, with 75% reduction in amplitude. If explicitly using an amplitude decibel convention, attenuation is 20 log10(80/20) ≈12.04 dB. This differs from a power-ratio convention using 10 log10. State the quantity and convention, and do not call a fourfold amplitude reduction four decibels. A zero or below-range reading requires treatment of the instrument detection limit rather than an infinite attenuation claim.

A fitted distance relationship is valid only within its assumptions and validated range. Suppose a supplied local empirical model is B(r)=40/r² µT with r in metres and validation only from 1 m to 2 m for the recorded source state. At 1.5 m it predicts approximately 17.78 µT. That is a model prediction within the supplied interval, not a universal law for all busways. Extrapolating to 0.1 m or another load state lacks validation. A real compliance decision needs the applicable criterion, uncertainty and competent assessment, not only a fitted equation.

Before/after comparisons require the same relevant source load, frequency, probe location/orientation and instrument method, or a justified normalization. If load falls while shielding is added, the observed reduction cannot be attributed entirely to the shield without additional evidence. Preserve both absolute values and the conditions. A mitigation can also create new issues: a poorly bonded screen, an unintended conductive loop or an obstructed cooling path may affect another requirement. Recheck the whole interface after the approved change.

## Connect EMC controls with safe installation practice

Cable segregation, balanced/twisted signaling, suitable screens, bonding and routing can reduce particular coupling mechanisms when correctly applied. There is no universal instruction to connect every screen at one end or both ends regardless of signal frequency, equipment design and grounding system. Follow the supported system's EMC and electrical requirements, and distinguish a functional screen from the protective conductor. Fiber can remove a conductive signal path and resist certain electromagnetic coupling, but media converters, power supplies and endpoint electronics remain part of the system.

For an interference investigation, compare a time-aligned error trace with source events, inspect routing and bonding against the accepted design, then test a bounded hypothesis through authorized changes. Keep the original evidence and record the actual improvement criterion, such as error-free operation under a specified motor-start campaign. Do not infer a human-exposure conclusion from a repaired serial link. Human-exposure assessment needs the current applicable legal and technical framework, frequency-specific guidance and qualified interpretation. ICNIRP's public low-frequency material is a reference point; local adoption and the specific assessment remain separate.

The practical deliverable is an evidence-backed survey and mitigation review: source/coupling hypothesis, instrument suitability, measurement table, units and uncertainty, supported attenuation calculation, proposed change and validation limits. It demonstrates electromagnetic literacy and disciplined integration while preserving specialist ownership of exposure compliance and electrical installation.


#### Worked demonstrations

**Communication errors beside a power route**

Synthetic training case — not a field record.

A serial sensor link reports bursts of CRC errors during a motor start. Its cable runs parallel to a high-current power route; the outgoing and return power conductors are widely separated. A radio-frequency survey meter has no specified 50/60 Hz magnetic response. A proposal claims that balanced three-phase power creates zero field everywhere and that moving the cable one metre always guarantees safety.

**Reasoning:** The timing and routing support an interference hypothesis, not a proven mechanism. Review source geometry, coupling path and instrument suitability. Balanced currents do not guarantee zero field everywhere, and a universal distance claim is unsupported. Equipment EMC and human exposure need separate acceptance.

**Three-axis measurement and an uncertain equipment threshold**

Synthetic training case — not a field record.

A synthetic orthogonal measurement reports Bx=3 µT, By=4 µT, Bz=0. Use resultant square-root-of-sum-of-squares. Stated expanded uncertainty is ±0.6 µT. The project’s synthetic equipment criterion is at most 5.2 µT under peak load; no decision rule for uncertainty is supplied. The survey was performed at 10% source load. This is not a human-health threshold.

**Reasoning:** Resultant is 5 µT or 50 mG; its stated interval is 4.4–5.6 µT. The interval crosses the equipment criterion, and the required peak-load state was not observed. A pass is not established without the applicable decision rule and representative operating evidence.

**Attenuation and a limited distance model**

Synthetic training case — not a field record.

Under comparable conditions, measured field amplitude falls from 80 to 20 µT after a reviewed mitigation. Use amplitude attenuation dB=20 log10(before/after). Separately, an explicitly supplied empirical model B(r)=40/r² µT is validated only for 1≤r≤2 metres at one source state. A planner wants to extrapolate it to 0.1 m and claim the same result after load doubles.

**Reasoning:** The amplitude factor is 4, reduction 75%, and attenuation about 12.04 dB. At 1.5 m, the local model predicts 17.78 µT. Neither the 0.1 m extrapolation nor a changed source state is validated; this fitted model is not a universal field law.

#### Guided practice

Create a source/coupling hypothesis for the serial errors, interpret the three-axis survey and calculate the mitigation and distance-model results.

**Hint:** Keep exposure, equipment compatibility, measurement uncertainty and model validity separate.

**Worked solution:** The error correlation needs a suitable low-frequency investigation. The measured resultant is 5 µT or 50 mG, with 4.4–5.6 µT uncertainty crossing the synthetic equipment criterion and no peak-load coverage. Attenuation is factor 4, 75% reduction or 12.04 dB; the local model predicts 17.78 µT at 1.5 m only within its supported conditions.

#### Independent task

Environment: analytical

Produce an EMC survey and mitigation review using synthetic data only.

**Packaged starter material**

- course_labs/CDCS/README.md
- course_labs/CDCS/fixture.json
- course_labs/CDCS/assessment_template.md
- course_labs/CDCS/lab.py
- course_labs/CDCS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- Source/coupling/receiver diagram or table
- Instrument and uncertainty review
- Attenuation/model calculations
- Bounded acceptance and specialist escalation statement

**Acceptance criteria**

- No universal safe distance or near-field inverse-square law is asserted.
- Human-exposure and equipment-function conclusions remain distinct.
- Physical routing/bonding changes require the actual approved design and authority.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer.

#### Chapter practice

**CDCS-Q0281 · single · mechanism**

What does the error timing establish?

Synthetic training case — not a field record.

A serial sensor link reports bursts of CRC errors during a motor start. Its cable runs parallel to a high-current power route; the outgoing and return power conductors are widely separated. A radio-frequency survey meter has no specified 50/60 Hz magnetic response. A proposal claims that balanced three-phase power creates zero field everywhere and that moving the cable one metre always guarantees safety.

1. Proof that every CRC error is caused by magnetic fields
2. Proof that the motor is electrically unsafe
3. A correlation with motor starts that supports investigation
4. Definitive proof of a failed sensor

**Correct option(s):** 3

- Option 1: Other disturbances and faults can produce errors.
- Option 2: The supplied link trace does not establish that conclusion.
- Option 3: It does not yet prove the coupling mechanism.
- Option 4: The pattern could arise elsewhere in the path.

**CDCS-Q0282 · single · mechanism**

Why can wide separation of outgoing and return conductors matter?

Synthetic training case — not a field record.

A serial sensor link reports bursts of CRC errors during a motor start. Its cable runs parallel to a high-current power route; the outgoing and return power conductors are widely separated. A radio-frequency survey meter has no specified 50/60 Hz magnetic response. A proposal claims that balanced three-phase power creates zero field everywhere and that moving the cable one metre always guarantees safety.

1. It changes the loop geometry and external field/coupling behavior
2. It guarantees lower temperature regardless of design
3. It always eliminates magnetic fields
4. It changes only the conductor labels

**Correct option(s):** 1

- Option 1: Return-path placement influences cancellation and induction.
- Option 2: Thermal and electromagnetic requirements need their own review.
- Option 3: Greater loop area can have the opposite effect.
- Option 4: Geometry has physical consequences.

**CDCS-Q0283 · single · mechanism**

What is wrong with the zero-field claim?

Synthetic training case — not a field record.

A serial sensor link reports bursts of CRC errors during a motor start. Its cable runs parallel to a high-current power route; the outgoing and return power conductors are widely separated. A radio-frequency survey meter has no specified 50/60 Hz magnetic response. A proposal claims that balanced three-phase power creates zero field everywhere and that moving the cable one metre always guarantees safety.

1. Phase balance does not guarantee cancellation at every location and frequency
2. Only single-phase systems can produce current
3. Balanced three-phase currents have no phase relationship
4. A zero vector sum at one selected point proves zero field everywhere

**Correct option(s):** 1

- Option 1: Geometry, harmonics and unbalance matter.
- Option 2: Three-phase systems carry current too.
- Option 3: They do, but that does not imply universal zero field.
- Option 4: Spatial geometry changes the contribution at other points.

**CDCS-Q0284 · single · mechanism**

Why is the proposed RF meter not yet suitable for this survey?

Synthetic training case — not a field record.

A serial sensor link reports bursts of CRC errors during a motor start. Its cable runs parallel to a high-current power route; the outgoing and return power conductors are widely separated. A radio-frequency survey meter has no specified 50/60 Hz magnetic response. A proposal claims that balanced three-phase power creates zero field everywhere and that moving the cable one metre always guarantees safety.

1. Any meter with a digital display is unsuitable
2. RF and power-frequency magnetic measurements are always identical
3. A current-carrying conductor cannot produce a low-frequency field
4. Its required low-frequency magnetic response is unspecified

**Correct option(s):** 4

- Option 1: Suitability depends on its specification.
- Option 2: Frequency response and sensing methods differ.
- Option 3: AC current can produce one.
- Option 4: A meter must cover the quantity and frequency of interest.

**CDCS-Q0285 · single · mechanism**

What should the investigation distinguish?

Synthetic training case — not a field record.

A serial sensor link reports bursts of CRC errors during a motor start. Its cable runs parallel to a high-current power route; the outgoing and return power conductors are widely separated. A radio-frequency survey meter has no specified 50/60 Hz magnetic response. A proposal claims that balanced three-phase power creates zero field everywhere and that moving the cable one metre always guarantees safety.

1. Only the motor’s rated current without its event waveform or coupling path
2. Only the receiver’s immunity specification without the actual disturbance
3. Only a single normal-state packet capture with no motor-start event
4. Source, coupling path and susceptible receiver

**Correct option(s):** 4

- Option 1: A source rating alone does not identify how the disturbance reaches the link.
- Option 2: Susceptibility data must be related to source and coupling conditions.
- Option 3: It omits the condition associated with the errors.
- Option 4: These identify where a targeted mitigation can act.

**CDCS-Q0286 · single · mechanism**

Why is a universal one-metre guarantee unsupported?

Synthetic training case — not a field record.

A serial sensor link reports bursts of CRC errors during a motor start. Its cable runs parallel to a high-current power route; the outgoing and return power conductors are widely separated. A radio-frequency survey meter has no specified 50/60 Hz magnetic response. A proposal claims that balanced three-phase power creates zero field everywhere and that moving the cable one metre always guarantees safety.

1. Distance can never reduce coupling
2. Any measured value below one metre is automatically illegal
3. Field and coupling behavior depend on source geometry, state and criteria
4. All electromagnetic quantities follow one universal inverse-square law nearby

**Correct option(s):** 3

- Option 1: It can help when assessed for the actual system.
- Option 2: No applicable legal criterion is supplied.
- Option 3: One distance cannot settle every installation.
- Option 4: Near-field and source models differ.

**CDCS-Q0287 · single · diagnosis**

What would help discriminate the hypothesis?

Synthetic training case — not a field record.

A serial sensor link reports bursts of CRC errors during a motor start. Its cable runs parallel to a high-current power route; the outgoing and return power conductors are widely separated. A radio-frequency survey meter has no specified 50/60 Hz magnetic response. A proposal claims that balanced three-phase power creates zero field everywhere and that moving the cable one metre always guarantees safety.

1. Only a single error-free minute with the motor off
2. Only restarting every device without preserving logs
3. Time-aligned source events, link errors and suitable field/routing evidence
4. Only repeating a successful test with the motor continuously stopped

**Correct option(s):** 3

- Option 1: That omits the triggering condition.
- Option 2: That can erase useful evidence and does not isolate cause.
- Option 3: A controlled comparison can test the suspected relationship.
- Option 4: That does not challenge the suspected start-related coupling.

**CDCS-Q0288 · single · implementation**

What could fiber conversion change in this context?

Synthetic training case — not a field record.

A serial sensor link reports bursts of CRC errors during a motor start. Its cable runs parallel to a high-current power route; the outgoing and return power conductors are widely separated. A radio-frequency survey meter has no specified 50/60 Hz magnetic response. A proposal claims that balanced three-phase power creates zero field everywhere and that moving the cable one metre always guarantees safety.

1. It supplies power to all endpoints without a source
2. It automatically certifies human-exposure compliance
3. It can remove the conductive signal path and certain coupling mechanisms
4. It eliminates every possible electromagnetic issue in the room

**Correct option(s):** 3

- Option 1: Fiber signaling does not imply electrical power delivery.
- Option 2: Media choice does not perform that assessment.
- Option 3: Endpoint power and electronics still need consideration.
- Option 4: Other equipment and paths remain.

**CDCS-Q0289 · single · operations**

What should govern a screen/bonding change?

Synthetic training case — not a field record.

A serial sensor link reports bursts of CRC errors during a motor start. Its cable runs parallel to a high-current power route; the outgoing and return power conductors are widely separated. A radio-frequency survey meter has no specified 50/60 Hz magnetic response. A proposal claims that balanced three-phase power creates zero field everywhere and that moving the cable one metre always guarantees safety.

1. A universal instruction to disconnect all screens
2. Only the screen arrangement used on a different signal system
3. The assumption that screens replace protective earth
4. The supported signal system and electrical/EMC design

**Correct option(s):** 4

- Option 1: That can defeat the intended EMC design.
- Option 2: Frequency, equipment and bonding requirements may differ.
- Option 3: Functional shielding and protective conductors have different duties.
- Option 4: One-end versus both-end rules are not universal.

**CDCS-Q0290 · single · design**

Which statement correctly limits acceptance after the serial errors are corrected?

Synthetic training case — not a field record.

A serial sensor link reports bursts of CRC errors during a motor start. Its cable runs parallel to a high-current power route; the outgoing and return power conductors are widely separated. A radio-frequency survey meter has no specified 50/60 Hz magnetic response. A proposal claims that balanced three-phase power creates zero field everywhere and that moving the cable one metre always guarantees safety.

1. Reliable communication alone does not establish human-exposure compliance
2. An error-free link proves every worker exposure is acceptable
3. Successful communication proves the field magnitude is zero
4. A corrected cable route eliminates the need to document the tested operating state

**Correct option(s):** 1

- Option 1: The exposure purpose needs its own applicable assessment.
- Option 2: Equipment function and human exposure have different criteria.
- Option 3: A receiver can operate successfully in a nonzero field.
- Option 4: The result remains conditional on its actual state and method.

**CDCS-Q0291 · single · calculation**

What is the resultant field in the supplied model?

Synthetic training case — not a field record.

A synthetic orthogonal measurement reports Bx=3 µT, By=4 µT, Bz=0. Use resultant square-root-of-sum-of-squares. Stated expanded uncertainty is ±0.6 µT. The project’s synthetic equipment criterion is at most 5.2 µT under peak load; no decision rule for uncertainty is supplied. The survey was performed at 10% source load. This is not a human-health threshold.

1. 7 µT
2. 25 µT
3. 1 µT
4. 5 µT

**Correct option(s):** 4

- Option 1: That adds orthogonal magnitudes directly.
- Option 2: That is the sum of squares without taking the square root.
- Option 3: That subtracts components rather than combining their squares.
- Option 4: √(3²+4²+0²)=5.

**CDCS-Q0292 · single · calculation**

What is 5 µT in milligauss?

Synthetic training case — not a field record.

A synthetic orthogonal measurement reports Bx=3 µT, By=4 µT, Bz=0. Use resultant square-root-of-sum-of-squares. Stated expanded uncertainty is ±0.6 µT. The project’s synthetic equipment criterion is at most 5.2 µT under peak load; no decision rule for uncertainty is supplied. The survey was performed at 10% source load. This is not a human-health threshold.

1. 0.5 mG
2. 50 mG
3. 5000 mG
4. 5 mG

**Correct option(s):** 2

- Option 1: That reverses the conversion.
- Option 2: One microtesla equals ten milligauss.
- Option 3: That applies an extra factor of 100.
- Option 4: The numerical values are not equal in these units.

**CDCS-Q0293 · single · calculation**

What interval follows from the stated uncertainty convention?

Synthetic training case — not a field record.

A synthetic orthogonal measurement reports Bx=3 µT, By=4 µT, Bz=0. Use resultant square-root-of-sum-of-squares. Stated expanded uncertainty is ±0.6 µT. The project’s synthetic equipment criterion is at most 5.2 µT under peak load; no decision rule for uncertainty is supplied. The survey was performed at 10% source load. This is not a human-health threshold.

1. 4.94 to 5.06 µT
2. 4.4 to 5.6 µT
3. 3 to 4 µT
4. Exactly 5 µT with no interval

**Correct option(s):** 2

- Option 1: That treats 0.6 µT as 0.06.
- Option 2: Subtract and add 0.6 to the 5 µT result.
- Option 3: Those are component readings, not the uncertainty interval.
- Option 4: The case explicitly supplies uncertainty.

**CDCS-Q0294 · single · mechanism**

Why is an unqualified pass against 5.2 µT not established?

Synthetic training case — not a field record.

A synthetic orthogonal measurement reports Bx=3 µT, By=4 µT, Bz=0. Use resultant square-root-of-sum-of-squares. Stated expanded uncertainty is ±0.6 µT. The project’s synthetic equipment criterion is at most 5.2 µT under peak load; no decision rule for uncertainty is supplied. The survey was performed at 10% source load. This is not a human-health threshold.

1. The units make comparison impossible
2. The central value is above 5.2 µT
3. Every uncertainty interval automatically means failure
4. The uncertainty interval crosses the criterion and no decision rule is supplied

**Correct option(s):** 4

- Option 1: Both result and criterion are in microtesla.
- Option 2: It is below, but uncertainty remains.
- Option 3: The applicable decision rule must define treatment.
- Option 4: The central value alone does not settle the required decision.

**CDCS-Q0295 · single · operations**

What additional scope gap exists beyond uncertainty?

Synthetic training case — not a field record.

A synthetic orthogonal measurement reports Bx=3 µT, By=4 µT, Bz=0. Use resultant square-root-of-sum-of-squares. Stated expanded uncertainty is ±0.6 µT. The project’s synthetic equipment criterion is at most 5.2 µT under peak load; no decision rule for uncertainty is supplied. The survey was performed at 10% source load. This is not a human-health threshold.

1. The criterion uses a maximum value
2. The source had a recorded load
3. The survey used 10% load instead of the required peak-load state
4. Three axes were included

**Correct option(s):** 3

- Option 1: A maximum criterion can be valid if properly assessed.
- Option 2: Recording state is helpful, not a defect.
- Option 3: The observation does not cover the specified operating condition.
- Option 4: That supports the specified resultant model.

**CDCS-Q0296 · single · operations**

What should a repeat survey preserve for comparability?

Synthetic training case — not a field record.

A synthetic orthogonal measurement reports Bx=3 µT, By=4 µT, Bz=0. Use resultant square-root-of-sum-of-squares. Stated expanded uncertainty is ±0.6 µT. The project’s synthetic equipment criterion is at most 5.2 µT under peak load; no decision rule for uncertainty is supplied. The survey was performed at 10% source load. This is not a human-health threshold.

1. Only the same nominal equipment nameplate rating
2. Position, orientation, instrument method, frequency and source state
3. Only the same meter calibration certificate
4. Only using the same meter without matching source load or probe position

**Correct option(s):** 2

- Option 1: Actual source state and measurement geometry can differ even when nominal ratings are unchanged.
- Option 2: These define what is being compared.
- Option 3: Calibration is important, but identical calibration evidence does not reproduce position, orientation, frequency or source loading.
- Option 4: Instrument continuity alone does not make the conditions comparable.

**CDCS-Q0297 · single · mechanism**

Why can a single-axis reading be misleading?

Synthetic training case — not a field record.

A synthetic orthogonal measurement reports Bx=3 µT, By=4 µT, Bz=0. Use resultant square-root-of-sum-of-squares. Stated expanded uncertainty is ±0.6 µT. The project’s synthetic equipment criterion is at most 5.2 µT under peak load; no decision rule for uncertainty is supplied. The survey was performed at 10% source load. This is not a human-health threshold.

1. A field always points along the instrument’s chosen axis
2. Probe orientation may miss other field components
3. Single-axis probes can never measure anything useful
4. Adding more decimal places captures missing axes

**Correct option(s):** 2

- Option 1: Orientation is a physical relationship, not a guarantee.
- Option 2: A low component is not necessarily a low resultant.
- Option 3: They can when used appropriately.
- Option 4: Numerical precision does not replace spatial measurement.

**CDCS-Q0298 · single · design**

Can this equipment criterion be used as a health-exposure limit?

Synthetic training case — not a field record.

A synthetic orthogonal measurement reports Bx=3 µT, By=4 µT, Bz=0. Use resultant square-root-of-sum-of-squares. Stated expanded uncertainty is ±0.6 µT. The project’s synthetic equipment criterion is at most 5.2 µT under peak load; no decision rule for uncertainty is supplied. The survey was performed at 10% source load. This is not a human-health threshold.

1. No; the case explicitly defines a synthetic equipment requirement
2. Yes, every microtesla threshold has the same purpose
3. Only after converting to milligauss
4. Yes, if the equipment functions normally

**Correct option(s):** 1

- Option 1: Human-exposure criteria need their own applicable assessment.
- Option 2: Quantity units do not determine regulatory meaning.
- Option 3: Unit conversion does not change the criterion’s purpose.
- Option 4: Function does not define exposure compliance.

**CDCS-Q0299 · single · operations**

What additional assessment is required even with valid calibration traceability?

Synthetic training case — not a field record.

A synthetic orthogonal measurement reports Bx=3 µT, By=4 µT, Bz=0. Use resultant square-root-of-sum-of-squares. Stated expanded uncertainty is ±0.6 µT. The project’s synthetic equipment criterion is at most 5.2 µT under peak load; no decision rule for uncertainty is supplied. The survey was performed at 10% source load. This is not a human-health threshold.

1. Ignore uncertainty because a calibration chain exists
2. Assume every frequency is covered by the calibration certificate
3. Treat the certificate as a substitute for recording probe position
4. Suitability of frequency response, range and method for this survey

**Correct option(s):** 4

- Option 1: Uncertainty remains part of the measurement decision.
- Option 2: The actual scope must match the survey.
- Option 3: Calibration does not define the field geometry.
- Option 4: Traceability does not automatically establish fitness for every use.

**CDCS-Q0300 · single · operations**

What is the proper report disposition?

Synthetic training case — not a field record.

A synthetic orthogonal measurement reports Bx=3 µT, By=4 µT, Bz=0. Use resultant square-root-of-sum-of-squares. Stated expanded uncertainty is ±0.6 µT. The project’s synthetic equipment criterion is at most 5.2 µT under peak load; no decision rule for uncertainty is supplied. The survey was performed at 10% source load. This is not a human-health threshold.

1. A guaranteed peak-load value of 5 µT
2. A certified safe distance for every nearby person
3. A bounded measurement result with unresolved peak-load and decision-rule acceptance
4. An instruction to change energized conductor routing immediately

**Correct option(s):** 3

- Option 1: Peak load was not observed or modeled.
- Option 2: The case supplies neither that assessment nor authority.
- Option 3: It preserves what was measured without overstating compliance.
- Option 4: The analytical result does not authorize physical work.

**CDCS-Q0301 · single · calculation**

What is the measured amplitude attenuation factor?

Synthetic training case — not a field record.

Under comparable conditions, measured field amplitude falls from 80 to 20 µT after a reviewed mitigation. Use amplitude attenuation dB=20 log10(before/after). Separately, an explicitly supplied empirical model B(r)=40/r² µT is validated only for 1≤r≤2 metres at one source state. A planner wants to extrapolate it to 0.1 m and claim the same result after load doubles.

1. 0.25
2. 4
3. 60
4. 75

**Correct option(s):** 2

- Option 1: That is after/before, the remaining fraction.
- Option 2: 80 divided by 20 gives four.
- Option 3: That is the absolute difference in microtesla.
- Option 4: That is the percentage reduction value, not a ratio factor.

**CDCS-Q0302 · single · calculation**

What percentage of the original amplitude remains?

Synthetic training case — not a field record.

Under comparable conditions, measured field amplitude falls from 80 to 20 µT after a reviewed mitigation. Use amplitude attenuation dB=20 log10(before/after). Separately, an explicitly supplied empirical model B(r)=40/r² µT is validated only for 1≤r≤2 metres at one source state. A planner wants to extrapolate it to 0.1 m and claim the same result after load doubles.

1. 20%
2. 25%
3. 75%
4. 400%

**Correct option(s):** 2

- Option 1: That treats the final microtesla value as a percentage.
- Option 2: 20/80 multiplied by 100.
- Option 3: That is the reduction, not the remaining fraction.
- Option 4: That reverses the ratio.

**CDCS-Q0303 · single · calculation**

What is the amplitude reduction percentage?

Synthetic training case — not a field record.

Under comparable conditions, measured field amplitude falls from 80 to 20 µT after a reviewed mitigation. Use amplitude attenuation dB=20 log10(before/after). Separately, an explicitly supplied empirical model B(r)=40/r² µT is validated only for 1≤r≤2 metres at one source state. A planner wants to extrapolate it to 0.1 m and claim the same result after load doubles.

1. 300%
2. 25%
3. 75%
4. 60%

**Correct option(s):** 3

- Option 1: A reduction from 80 to 20 does not exceed 100%.
- Option 2: That is the remaining fraction.
- Option 3: The decrease is 60 out of the original 80.
- Option 4: The absolute 60 µT decrease is not 60% of 80.

**CDCS-Q0304 · single · calculation**

What attenuation follows from the supplied decibel convention?

Synthetic training case — not a field record.

Under comparable conditions, measured field amplitude falls from 80 to 20 µT after a reviewed mitigation. Use amplitude attenuation dB=20 log10(before/after). Separately, an explicitly supplied empirical model B(r)=40/r² µT is validated only for 1≤r≤2 metres at one source state. A planner wants to extrapolate it to 0.1 m and claim the same result after load doubles.

1. 6.02 dB
2. 4 dB
3. 75 dB
4. Approximately 12.04 dB

**Correct option(s):** 4

- Option 1: That uses 10 log10 for the amplitude ratio instead of the stated convention.
- Option 2: The linear factor is not the decibel value.
- Option 3: The percentage reduction is not decibel attenuation.
- Option 4: 20 log10(4) gives 12.04.

**CDCS-Q0305 · single · calculation**

What does the local model predict at 1.5 m?

Synthetic training case — not a field record.

Under comparable conditions, measured field amplitude falls from 80 to 20 µT after a reviewed mitigation. Use amplitude attenuation dB=20 log10(before/after). Separately, an explicitly supplied empirical model B(r)=40/r² µT is validated only for 1≤r≤2 metres at one source state. A planner wants to extrapolate it to 0.1 m and claim the same result after load doubles.

1. Approximately 17.78 µT
2. 10 µT
3. 90 µT
4. 26.67 µT

**Correct option(s):** 1

- Option 1: 40 divided by 1.5 squared.
- Option 2: That is the model value at 2 m.
- Option 3: That multiplies by the square instead of dividing.
- Option 4: That divides by distance rather than its square in the supplied model.

**CDCS-Q0306 · single · mechanism**

Why is prediction at 0.1 m unsupported by validation?

Synthetic training case — not a field record.

Under comparable conditions, measured field amplitude falls from 80 to 20 µT after a reviewed mitigation. Use amplitude attenuation dB=20 log10(before/after). Separately, an explicitly supplied empirical model B(r)=40/r² µT is validated only for 1≤r≤2 metres at one source state. A planner wants to extrapolate it to 0.1 m and claim the same result after load doubles.

1. Every field model is invalid everywhere
2. Distance is never relevant to field magnitude
3. The equation cannot be evaluated arithmetically
4. It lies outside the supplied 1–2 m validated interval

**Correct option(s):** 4

- Option 1: Models can be useful within their supported scope.
- Option 2: Geometry and distance can matter.
- Option 3: It can be evaluated, but arithmetic is not physical validation.
- Option 4: The fitted relation cannot be assumed accurate there.

**CDCS-Q0307 · single · mechanism**

Why not apply the same result after source load doubles?

Synthetic training case — not a field record.

Under comparable conditions, measured field amplitude falls from 80 to 20 µT after a reviewed mitigation. Use amplitude attenuation dB=20 log10(before/after). Separately, an explicitly supplied empirical model B(r)=40/r² µT is validated only for 1≤r≤2 metres at one source state. A planner wants to extrapolate it to 0.1 m and claim the same result after load doubles.

1. The source state is outside the model’s stated validation
2. Load can never influence magnetic field
3. The coefficient 40 automatically updates itself
4. A distance equation eliminates the need to record load

**Correct option(s):** 1

- Option 1: Its relationship to field must be assessed.
- Option 2: Current and source operation can influence it.
- Option 3: A written model does not self-calibrate.
- Option 4: The model is conditional on its source state.

**CDCS-Q0308 · single · operations**

What if the after-reading is below instrument range?

Synthetic training case — not a field record.

Under comparable conditions, measured field amplitude falls from 80 to 20 µT after a reviewed mitigation. Use amplitude attenuation dB=20 log10(before/after). Separately, an explicitly supplied empirical model B(r)=40/r² µT is validated only for 1≤r≤2 metres at one source state. A planner wants to extrapolate it to 0.1 m and claim the same result after load doubles.

1. Replace it with a negative field magnitude
2. Report the detection/measurement limit and a bounded attenuation claim
3. Report infinite attenuation automatically
4. Ignore the instrument range because the result is favorable

**Correct option(s):** 2

- Option 1: That invents a value.
- Option 2: An exact zero or infinite reduction is not established.
- Option 3: Below range is not proven zero.
- Option 4: Range limits affect evidence quality.

**CDCS-Q0309 · single · operations**

What would confound attributing a reduction entirely to the mitigation?

Synthetic training case — not a field record.

Under comparable conditions, measured field amplitude falls from 80 to 20 µT after a reviewed mitigation. Use amplitude attenuation dB=20 log10(before/after). Separately, an explicitly supplied empirical model B(r)=40/r² µT is validated only for 1≤r≤2 metres at one source state. A planner wants to extrapolate it to 0.1 m and claim the same result after load doubles.

1. Using the same probe location and method
2. Recording both before and after values
3. Applying the declared amplitude convention consistently
4. A simultaneous source-load reduction

**Correct option(s):** 4

- Option 1: That improves comparability.
- Option 2: That supports the calculation.
- Option 3: Consistency avoids a calculation ambiguity.
- Option 4: The source change could contribute to the lower field.

**CDCS-Q0310 · single · design**

What should accompany the mitigation acceptance?

Synthetic training case — not a field record.

Under comparable conditions, measured field amplitude falls from 80 to 20 µT after a reviewed mitigation. Use amplitude attenuation dB=20 log10(before/after). Separately, an explicitly supplied empirical model B(r)=40/r² µT is validated only for 1≤r≤2 metres at one source state. A planner wants to extrapolate it to 0.1 m and claim the same result after load doubles.

1. An assumption that shielding cannot affect cooling or bonding
2. Only the largest computed decibel number
3. Comparable conditions, measurement uncertainty, required criterion and new-interface checks
4. A universal health guarantee at every distance

**Correct option(s):** 3

- Option 1: Physical changes can introduce other interface consequences.
- Option 2: A number without scope can mislead.
- Option 3: Attenuation alone does not establish every requirement.
- Option 4: The evidence is a bounded equipment/source comparison.

#### Recall

**Communication errors beside a power route — Synthetic training case — not a field record.

A serial sensor link reports bursts of CRC errors during a motor start. Its cable runs parallel to a high-current power route; the outgoing and return power conductors are widely separated. A radio-frequency survey meter has no specified 50/60 Hz magnetic response. A proposal claims that balanced three-phase power creates zero field everywhere and that moving the cable one metre always guarantees safety.**

The timing and routing support an interference hypothesis, not a proven mechanism. Review source geometry, coupling path and instrument suitability. Balanced currents do not guarantee zero field everywhere, and a universal distance claim is unsupported. Equipment EMC and human exposure need separate acceptance.

**Three-axis measurement and an uncertain equipment threshold — Synthetic training case — not a field record.

A synthetic orthogonal measurement reports Bx=3 µT, By=4 µT, Bz=0. Use resultant square-root-of-sum-of-squares. Stated expanded uncertainty is ±0.6 µT. The project’s synthetic equipment criterion is at most 5.2 µT under peak load; no decision rule for uncertainty is supplied. The survey was performed at 10% source load. This is not a human-health threshold.**

Resultant is 5 µT or 50 mG; its stated interval is 4.4–5.6 µT. The interval crosses the equipment criterion, and the required peak-load state was not observed. A pass is not established without the applicable decision rule and representative operating evidence.

**Attenuation and a limited distance model — Synthetic training case — not a field record.

Under comparable conditions, measured field amplitude falls from 80 to 20 µT after a reviewed mitigation. Use amplitude attenuation dB=20 log10(before/after). Separately, an explicitly supplied empirical model B(r)=40/r² µT is validated only for 1≤r≤2 metres at one source state. A planner wants to extrapolate it to 0.1 m and claim the same result after load doubles.**

The amplitude factor is 4, reduction 75%, and attenuation about 12.04 dB. At 1.5 m, the local model predicts 17.78 µT. Neither the 0.1 m extrapolation nor a changed source state is validated; this fitted model is not a universal field law.

#### References

- [EPI CDCS public syllabus](https://www.epi-ap.com/services/1/3/5)
- [ICNIRP low-frequency field overview and current references](https://www.icnirp.org/en/frequencies/low-frequency/index.html)
- [Schneider Electric electromagnetic compatibility guide](https://www.electrical-installation.org/enwiki/ElectroMagnetic_Compatibility_(EMC))

## CDCS-M08 — Cooling physics, airflow validation and liquid-system interfaces

### CDCS-L08 — Cooling physics, airflow validation and liquid-system interfaces

Estimated study time: 180 minutes before independent work. Prerequisite chapters: CDCS-L07

## Treat cooling as a heat path from the component to the environment

Cooling design must remove the relevant heat while maintaining the equipment's accepted environmental conditions in normal, maintenance, degraded and recovery states. Trace heat from processors, memory, power supplies and other loads through air or coolant, heat exchangers, distribution and final rejection. A room-level capacity total can look adequate while a rack inlet, manifold, pump, coil or service corridor is the actual constraint. Define load, density, local distribution, growth, redundancy and operating envelope at each interface. IT equipment, facility systems and controls must agree on temperature, flow, pressure, fluid quality and failure behavior.

Thermal power is a rate, such as kW; thermal energy accumulates over time. In a steady simplified electrical-to-heat boundary, most IT input power becomes heat that must leave the equipment and room through the intended paths. State exceptions and boundary effects rather than assuming a cooling nameplate equals usable IT capacity. Use consistent conversions: in supplied training calculations, 1 kW is approximately 3412 Btu/h and 1 refrigeration ton approximately 3.517 kW. Do not confuse a ton of refrigeration with equipment mass or convert a power rating into energy without duration.

## Psychrometric quantities describe different properties

Dry-bulb temperature is the ordinary air temperature measured without evaporative cooling of the sensor. Relative humidity compares water-vapor partial pressure with saturation pressure at the same temperature. Humidity ratio is the mass of water vapor per mass of dry air. Dew point is the temperature at which the existing vapor content reaches saturation when cooled at the relevant pressure without changing that content. Wet-bulb temperature relates to evaporative cooling under its defined measurement conditions. A psychrometric chart organizes these relationships for a specified pressure; its chart pressure and units must match the intended use.

Sensible heating raises dry-bulb temperature without necessarily changing humidity ratio. Because saturation pressure rises with temperature, relative humidity can fall even though no water was removed. Cooling without condensation can lower temperature at essentially constant humidity ratio until the dew point is reached; further cooling with condensation removes moisture. Humidification, dehumidification and mixing follow different paths. Do not infer water content from relative humidity alone when temperature changes. This distinction is useful when a room's RH display falls after a setpoint change and someone proposes unnecessary humidification.

For a supplied ideal moist-air calculation, vapor partial pressure pv = W P/(0.622 + W), where W is humidity ratio in kg/kg dry air and P is total pressure in the same pressure units. If W=0.010 and P=101.325 kPa, pv is about 1.603 kPa. With supplied saturation pressure 2.985 kPa at 24°C, RH is pv/psat ×100 ≈53.7%. These numbers are an original teaching model, not an environmental limit. A psychrometric chart should yield a compatible state within reading precision and its assumptions. At a different altitude, pressure-dependent relationships require the appropriate chart or calculation.

Condensation risk depends on surface temperature relative to local dew point, not room dry-bulb alone. If local dew point is 14°C and an uninsulated surface is 12°C, condensation is possible under those conditions. Sensor placement and uncertainty matter, especially near cold piping or liquid-cooling connections. An acceptable average room temperature does not prove every surface remains above dew point. Controls should use the accepted envelope and failure response; they should not mask an alarm or alter thresholds merely to make a dashboard look compliant.

ASHRAE recommendations and equipment manufacturer limits have specific classes, editions, conditions and purposes. Recommended and allowable ranges are not interchangeable promises of identical reliability, and one device's published envelope does not automatically cover every component in a mixed rack. Retain the curriculum-assigned current ASHRAE material and the exact vendor guide as external references. This independent course teaches how to interpret and apply them without reproducing protected tables or inventing a universal setpoint. The selected project envelope needs an identified source, margin, measurement location and competent approval.

## Derive airflow from sensible heat balance

For a steady sensible-air model, Q = mass flow × specific heat × temperature rise. With volume flow, Q = density × volume flow × cp × ΔT. Keep units consistent: kW equals kJ/s, cp can be kJ/(kg·K), density kg/m³ and volume flow m³/s. A 120 kW load, density 1.2 kg/m³, cp 1.005 kJ/(kg·K) and 10 K rise require about 9.95 m³/s, or 35821 m³/h. Using the supplied conversion 1 m³/s=2118.88 CFM gives approximately 21083 CFM. This is a heat-balance requirement, not proof that a particular fan and duct network can deliver it.

At fixed heat load and properties, doubling the permitted air temperature rise halves the ideal required mass flow. That relationship does not authorize raising inlet temperature or reducing fan speed without checking equipment limits, local hotspots and controls. The temperature rise is between the defined inlet and outlet of the heat-transfer boundary. A 10 K difference equals a 10°C temperature difference, but a temperature difference should not be confused with an absolute operating temperature. Density and cp vary with conditions; use appropriate values for the actual design rather than blindly repeating the training constants.

Fans operate against system resistance. Catalogue free-air flow is not guaranteed installed flow through filters, coils, doors, tiles, cables and containment. Pressure-flow curves and control behavior determine the operating point. A perforated tile's open area or a rack door's percent perforation is only one characteristic; actual delivery depends on pressure and the complete flow path. High airflow at one location can coexist with starvation elsewhere. Measure or model the relevant rack inlets and flows, not only room averages or cooling-unit return temperature.

## Keep supply air useful and return air separate

A coherent floor plan aligns equipment airflow with supply and return paths. Hot-aisle/cold-aisle arrangements and containment can reduce mixing when implemented for the actual equipment orientation and system design. Blanking panels and seals can prevent bypass or recirculation through unused rack spaces. Missing panels, reversed airflow devices, open cable cutouts and doors left open can alter the intended pattern. More fan speed may consume energy without correcting the underlying mixing mechanism. Diagnose the path before changing a control setpoint.

Bypass occurs when conditioned air returns without doing the intended useful cooling; recirculation occurs when hot exhaust reaches an inlet. Both can coexist. A cool return-air average may indicate mixing or bypass, not necessarily healthy equipment inlets. Inspect inlet temperatures at appropriate heights and locations, equipment airflow direction, containment leakage, obstructions and actual fan behavior. Cable management and maintenance clearances are therefore thermal design inputs, not merely appearance. Changes to racks, tiles, doors or cable fill should update the accepted airflow baseline and affected tests.

Computational fluid dynamics can help compare layouts and investigate flow/temperature behavior, but output depends on model inputs and assumptions. Geometry, heat loads, fan curves, leakage, boundary conditions, turbulence treatment and mesh resolution affect results. A colorful temperature plot is not validation. Check conservation, numerical convergence, sensitivity and agreement with suitable measurements. Calibration against one observation is not proof of predictive accuracy across every failure or load state. Retain model version, input files, assumptions and the exact scenario represented.

If a model predicts a maximum inlet of 27°C but a measured rack reaches 31°C under an intended equivalent state, investigate both model and measurement: source load, sensor calibration/location, fan curves, doors, leakage and timing. Do not simply change the plot's color scale or lower the heat input until the result matches. A discrepancy is evidence that the current model does not yet support the claimed acceptance. A revised model should explain the correction and be checked against observations not used solely to tune it where feasible.

## Select sensible capacity, efficiency and humidity behavior

Cooling equipment may have a total capacity divided into sensible and latent components. Sensible heat ratio, SHR, is sensible capacity divided by total capacity at the stated conditions. A 100 kW total unit with SHR 0.80 has 80 kW sensible capacity and 20 kW latent capacity in that rating condition. A room with 85 kW sensible demand cannot be accepted from the 100 kW total number alone. Actual entering-air and fluid conditions affect the rating. Dehumidification can consume capacity and energy that does not directly remove the IT sensible load.

Coefficient of performance compares useful cooling output with input power within its stated boundary. A unit delivering 90 kW cooling for 30 kW input has COP 3.0 at that point. EER and other metrics use different unit conventions or rating conditions; identify the definition before comparing numbers. Part-load behavior, fan/pump energy, economizer modes and ambient conditions influence annual cost. An efficient unit at one point may not be the best whole-system choice. Redundancy, maintenance, control stability and service access remain constraints in the selection.

Humidity control should avoid simultaneous fighting actions, such as one unit humidifying while another unnecessarily dehumidifies the same space. Sensor calibration, location, control deadbands and supervisory coordination matter. Define setpoints and alarm thresholds from the approved equipment envelope and operating strategy. A sensor offset can cause the actual room condition to differ from the displayed control target. Calibrate or verify against a suitable reference and preserve as-found/as-left evidence; changing the display scale without measurement is not calibration.

## Liquid cooling adds hydraulic and material interfaces

Direct-to-chip cooling transfers heat from selected components to a liquid circuit; rear-door heat exchangers cool rack exhaust through a liquid interface; immersion places supported equipment in a compatible dielectric fluid. Single-phase systems transport sensible heat without intended boiling in the relevant loop; two-phase designs use phase change and require their own pressure, fluid and control considerations. These approaches are not interchangeable drop-in replacements. Confirm the exact IT equipment support, fluid compatibility, connectors, service methods and failure response.

For a simple single-phase liquid model, Q = mass flow × cp × ΔT. If a 500 kW rack exports 85% of its heat to liquid, the liquid duty is 425 kW and residual air duty is 75 kW. With supplied cp=4.18 kJ/(kg·K) and 5 K rise, required liquid mass flow is about 20.33 kg/s. Assuming density 1 kg/L gives about 20.33 L/s. A glycol mixture or other coolant may have different properties, so the water-based numbers cannot be reused without checking. The heat balance does not establish pump head, pressure limits, flow distribution or connector capability.

A coolant distribution unit can provide heat exchange, pumping, control and separation between facility and technology loops according to its design. Separation does not eliminate every dependency: facility supply temperature, flow and heat-rejection availability still constrain the technology loop. Review filtration, chemistry, corrosion compatibility, dissolved gas, flushing/cleanliness, pressure, expansion, leak detection and isolation with the responsible specialists and vendors. Independent protection and shutdown/permissive ownership must remain explicit. A leak alarm arriving at DCIM is not proof that the required local response occurred.

Commissioning should verify mapping and units, flow/temperature/pressure observations, alarms, defined loss/recovery sequences and the consuming IT response at the actual test fidelity. Maintenance access includes hose/connector service, CDU removal paths and drainage/containment arrangements. Recovery may require restoring fluid quality and removing air before returning to accepted load. The portfolio should preserve vendor platform/version and physical evidence for these activities; the app's equations and synthetic cases provide the knowledge and analytical review, not a completed liquid-system commissioning record.


#### Worked demonstrations

**Humidity ratio, relative humidity and a cold surface**

Synthetic training case — not a field record.

Use the supplied ideal relation pv=W×P/(0.622+W). At 24°C, W=0.010 kg/kg dry air, P=101.325 kPa and supplied saturation pressure is 2.985 kPa. A later sensible-heating step adds no moisture. Local dew point is separately measured as 14°C; a pipe surface is 12°C. No universal equipment or health limits are supplied.

**Reasoning:** pv≈1.603 kPa and RH≈53.7%. Sensible heating without moisture addition keeps humidity ratio approximately constant while RH generally falls. The 12°C surface is below the local 14°C dew point, so condensation is possible. Actual equipment envelopes require the selected current vendor/ASHRAE references.

**Sensible heat and the airflow requirement**

Synthetic training case — not a field record.

A synthetic steady sensible-air model removes 120 kW. Use density 1.2 kg/m³, cp=1.005 kJ/(kg·K), and air temperature rise 10 K. Use 1 m³/s=3600 m³/h=2118.88 CFM and 1 kW=3412 Btu/h. Ignore leakage, fan heat and property variation for this calculation. No fan/system pressure curve is supplied.

**Reasoning:** Mass flow is 120/(1.005×10)=11.94 kg/s. Volume flow is 9.950 m³/s, approximately 35821 m³/h or 21083 CFM. Heat is 409440 Btu/h. These are model requirements, not proof that the installed system delivers that flow.

**Cold supply, hot inlet and wasted bypass air**

Synthetic training case — not a field record.

Supply air is 22°C. One rack’s upper inlet reaches 31°C while the room-average sensor reads 24°C. Empty rack spaces lack blanking panels; a rear-exhaust switch is installed opposite the row’s intended flow direction. Several open cable cutouts return cold air directly toward cooling units. A proposal increases all fan speeds without inspecting the paths.

**Reasoning:** The evidence supports local recirculation and bypass hypotheses. Inspect equipment direction, blanking, openings, containment and actual inlet/flow measurements. A room average and additional fan speed cannot establish that useful cooling reaches the hot inlet.

**A CFD plot that disagrees with the rack**

Synthetic training case — not a field record.

A CFD model predicts maximum rack inlet 27°C at a stated load. A field survey under intended equivalent conditions records 31°C at rack R7. The model uses free-air fan flow as fixed installed flow, omits a large cable obstruction and assumes sealed containment despite an open service door. Numerical residuals are low. The sensor’s calibration and exact position have not been checked.

**Reasoning:** Low solver residuals do not validate incorrect physical inputs. Reconcile fan/system behavior, geometry, leakage and measurement conditions. Preserve the discrepancy and correct the justified inputs; do not tune heat load merely to force agreement. Validate the revised model within its stated scenario.

**Total cooling capacity, SHR and a biased sensor**

Synthetic training case — not a field record.

A unit is rated 100 kW total cooling with SHR 0.80 at the supplied conditions. The room requires 85 kW sensible and 5 kW latent removal. A separate operating measurement gives 90 kW useful cooling for 30 kW input. A controlling temperature sensor reads 2°C lower than a suitable reference; its display says 24°C. Two room units are observed humidifying and dehumidifying simultaneously.

**Reasoning:** Rated sensible capacity is 80 kW, below the 85 kW sensible requirement despite 100 kW total exceeding 90 kW total demand. The separate operating COP is 3.0. The biased sensor implies 26°C at its location under the supplied comparison. Review calibration and control coordination rather than assuming the nominal setpoint or total rating proves acceptance.

**Direct liquid duty with residual air cooling**

Synthetic training case — not a field record.

A synthetic 500 kW rack exports 85% of its heat to a single-phase liquid loop and 15% to air. Use cp=4.18 kJ/(kg·K), liquid rise 5 K and density 1 kg/L for this water-property model. A CDU separates facility and technology loops. The proposed substitute coolant has different properties and unverified connector/material compatibility. Leak alarms reach DCIM, but local response and recovery are untested.

**Reasoning:** Liquid duty is 425 kW and residual air duty 75 kW. Required mass flow is 425/(4.18×5)=20.33 kg/s, or 20.33 L/s at the supplied density. The CDU remains dependent on facility heat rejection, and substitute fluid compatibility, leak action and recovery require explicit vendor/specialist acceptance.

#### Guided practice

Solve the psychrometric, airflow, capacity and liquid cases, then defend a thermal acceptance plan against the local hotspot and CFD discrepancy.

**Hint:** Track useful heat paths, local conditions, measurement uncertainty and the exact model boundary.

**Worked solution:** RH is about 53.7%; the cold surface is below dew point. Airflow demand is about 9.95 m³/s, not proof of delivered flow. Investigate recirculation/bypass and validate CFD inputs. The 100 kW unit provides only 80 kW sensible at the supplied SHR. Liquid duty is 425 kW at about 20.33 kg/s, with 75 kW residual air duty and separate compatibility/recovery gates.

#### Independent task

Environment: analytical

Create a thermal design-review pack with calculations, model validation and vendor interface requirements.

**Packaged starter material**

- course_labs/CDCS/README.md
- course_labs/CDCS/fixture.json
- course_labs/CDCS/assessment_template.md
- course_labs/CDCS/lab.py
- course_labs/CDCS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- Psychrometric and heat-balance worksheet
- Rack airflow and CFD discrepancy investigation
- Sensible/latent capacity and control review
- Liquid CDU/IT interface and recovery acceptance matrix

**Acceptance criteria**

- No protected or universal environmental limit is invented.
- Room averages and total capacity do not replace local inlet/flow evidence.
- Liquid properties, compatibility and residual air cooling are explicit.
- Analytical/CFD evidence is not presented as executed physical commissioning.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer.

#### Chapter practice

**CDCS-Q0311 · single · calculation**

What is vapor partial pressure from the supplied relation?

Synthetic training case — not a field record.

Use the supplied ideal relation pv=W×P/(0.622+W). At 24°C, W=0.010 kg/kg dry air, P=101.325 kPa and supplied saturation pressure is 2.985 kPa. A later sensible-heating step adds no moisture. Local dew point is separately measured as 14°C; a pipe surface is 12°C. No universal equipment or health limits are supplied.

1. Approximately 1.603 kPa
2. 101.325 kPa
3. 2.985 kPa
4. 0.010 kPa

**Correct option(s):** 1

- Option 1: 0.010×101.325 divided by 0.632.
- Option 2: That is total atmospheric pressure.
- Option 3: That is the supplied saturation pressure, not actual vapor pressure.
- Option 4: That treats humidity ratio as a pressure.

**CDCS-Q0312 · single · calculation**

What is the corresponding relative humidity?

Synthetic training case — not a field record.

Use the supplied ideal relation pv=W×P/(0.622+W). At 24°C, W=0.010 kg/kg dry air, P=101.325 kPa and supplied saturation pressure is 2.985 kPa. A later sensible-heating step adds no moisture. Local dew point is separately measured as 14°C; a pipe surface is 12°C. No universal equipment or health limits are supplied.

1. Approximately 53.7%
2. 1.603%
3. 10%
4. 186.2%

**Correct option(s):** 1

- Option 1: 1.603/2.985 multiplied by 100.
- Option 2: That uses pressure as a percentage without normalization.
- Option 3: That treats 0.010 kg/kg as a direct RH fraction.
- Option 4: That reverses the actual/saturation ratio.

**CDCS-Q0313 · single · operations**

What remains approximately constant during the stated sensible heating?

Synthetic training case — not a field record.

Use the supplied ideal relation pv=W×P/(0.622+W). At 24°C, W=0.010 kg/kg dry air, P=101.325 kPa and supplied saturation pressure is 2.985 kPa. A later sensible-heating step adds no moisture. Local dew point is separately measured as 14°C; a pipe surface is 12°C. No universal equipment or health limits are supplied.

1. Dry-bulb temperature
2. Humidity ratio
3. Relative humidity necessarily
4. Saturation pressure

**Correct option(s):** 2

- Option 1: The process is explicitly heating.
- Option 2: No moisture is added or removed in the stated process.
- Option 3: Saturation pressure changes with temperature.
- Option 4: It depends on the changed temperature.

**CDCS-Q0314 · single · mechanism**

Why can RH fall without dehumidification?

Synthetic training case — not a field record.

Use the supplied ideal relation pv=W×P/(0.622+W). At 24°C, W=0.010 kg/kg dry air, P=101.325 kPa and supplied saturation pressure is 2.985 kPa. A later sensible-heating step adds no moisture. Local dew point is separately measured as 14°C; a pipe surface is 12°C. No universal equipment or health limits are supplied.

1. Warmer air has a higher saturation pressure at the same vapor content
2. Relative humidity measures only total air mass
3. The sensor is necessarily faulty
4. Water vapor must disappear whenever air warms

**Correct option(s):** 1

- Option 1: The ratio decreases even without removing water.
- Option 2: It compares vapor pressure with saturation pressure.
- Option 3: The change can follow physical behavior.
- Option 4: Sensible heating need not remove moisture.

**CDCS-Q0315 · single · mechanism**

What does the 12°C pipe surface imply with a 14°C local dew point?

Synthetic training case — not a field record.

Use the supplied ideal relation pv=W×P/(0.622+W). At 24°C, W=0.010 kg/kg dry air, P=101.325 kPa and supplied saturation pressure is 2.985 kPa. A later sensible-heating step adds no moisture. Local dew point is separately measured as 14°C; a pipe surface is 12°C. No universal equipment or health limits are supplied.

1. All room surfaces must condense simultaneously
2. Condensation is impossible because room air is 24°C
3. Condensation is possible on the surface
4. The pipe must already contain an internal leak

**Correct option(s):** 3

- Option 1: Other surfaces may remain warmer.
- Option 2: Surface temperature relative to dew point controls this concern.
- Option 3: It is below the local dew point.
- Option 4: External condensation does not prove a pipe leak.

**CDCS-Q0316 · single · mechanism**

Why identify pressure when using a psychrometric chart?

Synthetic training case — not a field record.

Use the supplied ideal relation pv=W×P/(0.622+W). At 24°C, W=0.010 kg/kg dry air, P=101.325 kPa and supplied saturation pressure is 2.985 kPa. A later sensible-heating step adds no moisture. Local dew point is separately measured as 14°C; a pipe surface is 12°C. No universal equipment or health limits are supplied.

1. Relative humidity has pressure units
2. Pressure can be ignored whenever dry-bulb temperature is known
3. The relationships and chart basis depend on pressure
4. Charts use the same exact relationships at every pressure without qualification

**Correct option(s):** 3

- Option 1: RH is a ratio, though pressure enters the state relationships.
- Option 2: Temperature alone does not fix all pressure-dependent psychrometric relationships.
- Option 3: Altitude or pressure changes can affect interpretation.
- Option 4: Their basis matters.

**CDCS-Q0317 · single · operations**

What is dew point in this context?

Synthetic training case — not a field record.

Use the supplied ideal relation pv=W×P/(0.622+W). At 24°C, W=0.010 kg/kg dry air, P=101.325 kPa and supplied saturation pressure is 2.985 kPa. A later sensible-heating step adds no moisture. Local dew point is separately measured as 14°C; a pipe surface is 12°C. No universal equipment or health limits are supplied.

1. The maximum permitted IT inlet temperature
2. The temperature of every cold pipe
3. The difference between supply and return air temperatures
4. The temperature where the existing vapor content reaches saturation on cooling

**Correct option(s):** 4

- Option 1: That is a separate equipment requirement.
- Option 2: Surface temperatures can differ from dew point.
- Option 3: That is a thermal rise, not dew point.
- Option 4: It describes a moisture-related temperature boundary.

**CDCS-Q0318 · single · operations**

What should prevent unnecessary humidification after the heating step?

Synthetic training case — not a field record.

Use the supplied ideal relation pv=W×P/(0.622+W). At 24°C, W=0.010 kg/kg dry air, P=101.325 kPa and supplied saturation pressure is 2.985 kPa. A later sensible-heating step adds no moisture. Local dew point is separately measured as 14°C; a pipe surface is 12°C. No universal equipment or health limits are supplied.

1. Add water until the old RH returns regardless of limits
2. Interpret RH together with temperature and moisture content against the approved strategy
3. Assume a single universal RH setpoint for every rack
4. Disable all humidity sensors

**Correct option(s):** 2

- Option 1: That can change moisture content unnecessarily.
- Option 2: A lower RH alone does not prove water was removed.
- Option 3: Equipment and project requirements need their actual basis.
- Option 4: That removes useful information.

**CDCS-Q0319 · single · operations**

How should recommended and allowable equipment envelopes be treated?

Synthetic training case — not a field record.

Use the supplied ideal relation pv=W×P/(0.622+W). At 24°C, W=0.010 kg/kg dry air, P=101.325 kPa and supplied saturation pressure is 2.985 kPa. A later sensible-heating step adds no moisture. Local dew point is separately measured as 14°C; a pipe surface is 12°C. No universal equipment or health limits are supplied.

1. As a license to operate every mixed-rack device at the widest limit
2. As identical whenever both use Celsius
3. As permanently fixed regardless of vendor updates
4. As distinct guidance/limits with identified source, edition and conditions

**Correct option(s):** 4

- Option 1: Each relevant component must be considered.
- Option 2: Shared units do not make meanings equal.
- Option 3: Current applicable product guidance must be verified.
- Option 4: They are not interchangeable operating promises.

**CDCS-Q0320 · single · diagnosis**

What should a condensation investigation record?

Synthetic training case — not a field record.

Use the supplied ideal relation pv=W×P/(0.622+W). At 24°C, W=0.010 kg/kg dry air, P=101.325 kPa and supplied saturation pressure is 2.985 kPa. A later sensible-heating step adds no moisture. Local dew point is separately measured as 14°C; a pipe surface is 12°C. No universal equipment or health limits are supplied.

1. Only whether the BMS screen looks normal
2. Only average room dry-bulb temperature
3. Only the coolant supply setpoint without actual surface temperature
4. Local dew point, surface temperature, sensor uncertainty and operating state

**Correct option(s):** 4

- Option 1: A summary can omit the local risk.
- Option 2: That does not establish surface-to-dew-point margin.
- Option 3: The local surface may differ from the commanded fluid temperature.
- Option 4: The comparison needs relevant local evidence.

**CDCS-Q0321 · single · calculation**

What mass flow does the supplied heat balance require?

Synthetic training case — not a field record.

A synthetic steady sensible-air model removes 120 kW. Use density 1.2 kg/m³, cp=1.005 kJ/(kg·K), and air temperature rise 10 K. Use 1 m³/s=3600 m³/h=2118.88 CFM and 1 kW=3412 Btu/h. Ignore leakage, fan heat and property variation for this calculation. No fan/system pressure curve is supplied.

1. 1200 kg/s
2. 1.194 kg/s
3. 9.95 kg/s
4. Approximately 11.94 kg/s

**Correct option(s):** 4

- Option 1: That multiplies by temperature rise instead of dividing.
- Option 2: That introduces a factor-of-ten error.
- Option 3: That is the volume-flow value after dividing by density.
- Option 4: 120 divided by 1.005×10.

**CDCS-Q0322 · single · calculation**

What is the required volume flow?

Synthetic training case — not a field record.

A synthetic steady sensible-air model removes 120 kW. Use density 1.2 kg/m³, cp=1.005 kJ/(kg·K), and air temperature rise 10 K. Use 1 m³/s=3600 m³/h=2118.88 CFM and 1 kW=3412 Btu/h. Ignore leakage, fan heat and property variation for this calculation. No fan/system pressure curve is supplied.

1. Approximately 9.95 m³/s
2. 0.0995 m³/s
3. 11.94 m³/s
4. 14.33 m³/s

**Correct option(s):** 1

- Option 1: 11.94 kg/s divided by 1.2 kg/m³.
- Option 2: That mis-scales the result.
- Option 3: That ignores density conversion.
- Option 4: That multiplies mass flow by density.

**CDCS-Q0323 · single · calculation**

What is that volume flow in cubic metres per hour?

Synthetic training case — not a field record.

A synthetic steady sensible-air model removes 120 kW. Use density 1.2 kg/m³, cp=1.005 kJ/(kg·K), and air temperature rise 10 K. Use 1 m³/s=3600 m³/h=2118.88 CFM and 1 kW=3412 Btu/h. Ignore leakage, fan heat and property variation for this calculation. No fan/system pressure curve is supplied.

1. 3582 m³/h
2. 2.764 m³/h
3. Approximately 35821 m³/h
4. 9950 m³/h

**Correct option(s):** 3

- Option 1: That is a factor of ten too low.
- Option 2: That divides by 3600 rather than multiplying.
- Option 3: 9.95025 multiplied by 3600.
- Option 4: That uses an incorrect time conversion.

**CDCS-Q0324 · single · calculation**

What is the approximate CFM requirement using the supplied factor?

Synthetic training case — not a field record.

A synthetic steady sensible-air model removes 120 kW. Use density 1.2 kg/m³, cp=1.005 kJ/(kg·K), and air temperature rise 10 K. Use 1 m³/s=3600 m³/h=2118.88 CFM and 1 kW=3412 Btu/h. Ignore leakage, fan heat and property variation for this calculation. No fan/system pressure curve is supplied.

1. 2119 CFM
2. 35821 CFM
3. 4.70 CFM
4. 21083 CFM

**Correct option(s):** 4

- Option 1: That corresponds to only 1 m³/s.
- Option 2: That confuses cubic metres per hour with cubic feet per minute.
- Option 3: That divides by the conversion factor.
- Option 4: 9.95025×2118.88.

**CDCS-Q0325 · single · calculation**

What is 120 kW in Btu/h using the supplied conversion?

Synthetic training case — not a field record.

A synthetic steady sensible-air model removes 120 kW. Use density 1.2 kg/m³, cp=1.005 kJ/(kg·K), and air temperature rise 10 K. Use 1 m³/s=3600 m³/h=2118.88 CFM and 1 kW=3412 Btu/h. Ignore leakage, fan heat and property variation for this calculation. No fan/system pressure curve is supplied.

1. 409440 Btu/h
2. 28433 Btu/h
3. 3412 Btu/h
4. 409440 Btu

**Correct option(s):** 1

- Option 1: 120×3412.
- Option 2: That divides the conversion factor by 0.12 incorrectly.
- Option 3: That is only 1 kW.
- Option 4: That labels a power conversion as accumulated energy without duration.

**CDCS-Q0326 · single · operations**

At fixed heat and properties, what happens if permitted temperature rise doubles?

Synthetic training case — not a field record.

A synthetic steady sensible-air model removes 120 kW. Use density 1.2 kg/m³, cp=1.005 kJ/(kg·K), and air temperature rise 10 K. Use 1 m³/s=3600 m³/h=2118.88 CFM and 1 kW=3412 Btu/h. Ignore leakage, fan heat and property variation for this calculation. No fan/system pressure curve is supplied.

1. Ideal required mass flow halves
2. Required mass flow doubles
3. Inlet temperature is automatically allowed to double
4. Heat removal becomes zero

**Correct option(s):** 1

- Option 1: Flow is inversely proportional to delta-T in this model.
- Option 2: That reverses the relationship.
- Option 3: Delta-T and absolute inlet limits are different quantities.
- Option 4: A larger rise can still transport the same heat.

**CDCS-Q0327 · single · mechanism**

Why is 10 K rise not a 10 K absolute inlet specification?

Synthetic training case — not a field record.

A synthetic steady sensible-air model removes 120 kW. Use density 1.2 kg/m³, cp=1.005 kJ/(kg·K), and air temperature rise 10 K. Use 1 m³/s=3600 m³/h=2118.88 CFM and 1 kW=3412 Btu/h. Ignore leakage, fan heat and property variation for this calculation. No fan/system pressure curve is supplied.

1. Kelvin cannot express temperature differences
2. It is a difference between defined temperatures
3. A 10 K difference equals a 10°F difference
4. Every 10 K rise means the supply is 0°C

**Correct option(s):** 2

- Option 1: It can.
- Option 2: An absolute inlet envelope requires its own value and source.
- Option 3: Celsius/Kelvin differences differ from Fahrenheit scaling.
- Option 4: No absolute supply temperature is implied.

**CDCS-Q0328 · single · operations**

What remains necessary to prove installed airflow delivery?

Synthetic training case — not a field record.

A synthetic steady sensible-air model removes 120 kW. Use density 1.2 kg/m³, cp=1.005 kJ/(kg·K), and air temperature rise 10 K. Use 1 m³/s=3600 m³/h=2118.88 CFM and 1 kW=3412 Btu/h. Ignore leakage, fan heat and property variation for this calculation. No fan/system pressure curve is supplied.

1. Only the calculated total cooling capacity
2. Only the fan’s free-air catalogue value
3. Fan/system pressure behavior and appropriate installed measurements
4. Only the calculated flow number

**Correct option(s):** 3

- Option 1: Thermal capacity does not establish that required air reaches the load.
- Option 2: Installed resistance can change operating flow.
- Option 3: The heat balance gives demand, not actual delivery.
- Option 4: A requirement does not prove implementation.

**CDCS-Q0329 · single · mechanism**

Why must density and cp be stated?

Synthetic training case — not a field record.

A synthetic steady sensible-air model removes 120 kW. Use density 1.2 kg/m³, cp=1.005 kJ/(kg·K), and air temperature rise 10 K. Use 1 m³/s=3600 m³/h=2118.88 CFM and 1 kW=3412 Btu/h. Ignore leakage, fan heat and property variation for this calculation. No fan/system pressure curve is supplied.

1. They are arbitrary labels that never affect the result
2. They prove every humidity condition is acceptable
3. They convert the thermal duty to mass and volume flow under specific conditions
4. They replace the need to measure IT heat load

**Correct option(s):** 3

- Option 1: Both enter the equation.
- Option 2: Thermal properties do not define the equipment envelope.
- Option 3: Different conditions can change the values.
- Option 4: Load is another required input.

**CDCS-Q0330 · single · design**

What is the correct design-review conclusion?

Synthetic training case — not a field record.

A synthetic steady sensible-air model removes 120 kW. Use density 1.2 kg/m³, cp=1.005 kJ/(kg·K), and air temperature rise 10 K. Use 1 m³/s=3600 m³/h=2118.88 CFM and 1 kW=3412 Btu/h. Ignore leakage, fan heat and property variation for this calculation. No fan/system pressure curve is supplied.

1. The facility is commissioned because the equation balances
2. The learner may reduce fan speed without the operating process
3. The model requires about 9.95 m³/s; actual delivery and local inlet conditions remain to verify
4. Every rack will receive equal airflow automatically

**Correct option(s):** 3

- Option 1: No physical system was tested.
- Option 2: The calculation does not authorize a live change.
- Option 3: It separates calculation from acceptance evidence.
- Option 4: Distribution depends on the actual paths.

**CDCS-Q0331 · single · mechanism**

Why does the 24°C room average not settle the hot-rack condition?

Synthetic training case — not a field record.

Supply air is 22°C. One rack’s upper inlet reaches 31°C while the room-average sensor reads 24°C. Empty rack spaces lack blanking panels; a rear-exhaust switch is installed opposite the row’s intended flow direction. Several open cable cutouts return cold air directly toward cooling units. A proposal increases all fan speeds without inspecting the paths.

1. The 31°C reading must be false because supply is colder
2. All sensors in a room must read identically
3. Averages are mathematically invalid
4. It can conceal a local 31°C inlet

**Correct option(s):** 4

- Option 1: Recirculation can raise local inlet temperature.
- Option 2: Spatial gradients can exist.
- Option 3: They are valid summaries but may not represent local extremes.
- Option 4: Equipment sees its actual inlet, not the room-wide average.

**CDCS-Q0332 · single · operations**

What can missing blanking panels permit?

Synthetic training case — not a field record.

Supply air is 22°C. One rack’s upper inlet reaches 31°C while the room-average sensor reads 24°C. Empty rack spaces lack blanking panels; a rear-exhaust switch is installed opposite the row’s intended flow direction. Several open cable cutouts return cold air directly toward cooling units. A proposal increases all fan speeds without inspecting the paths.

1. Elimination of every pressure difference
2. Guaranteed improvement from extra open area
3. Unwanted mixing or recirculation through unused rack spaces
4. Automatic increase in cooling-unit capacity

**Correct option(s):** 3

- Option 1: The system’s pressure field remains complex.
- Option 2: Uncontrolled paths can reduce useful delivery.
- Option 3: Openings can bypass the intended front-to-back path.
- Option 4: Rack openings do not create refrigeration capacity.

**CDCS-Q0333 · single · mechanism**

Why review the switch’s airflow direction?

Synthetic training case — not a field record.

Supply air is 22°C. One rack’s upper inlet reaches 31°C while the room-average sensor reads 24°C. Empty rack spaces lack blanking panels; a rear-exhaust switch is installed opposite the row’s intended flow direction. Several open cable cutouts return cold air directly toward cooling units. A proposal increases all fan speeds without inspecting the paths.

1. It may oppose the row’s intended supply/return arrangement
2. Airflow direction matters only for servers
3. The switch’s IP subnet determines its physical airflow
4. All network switches use identical airflow direction

**Correct option(s):** 1

- Option 1: A reversed device can send exhaust toward an inlet area.
- Option 2: Other active equipment also rejects heat.
- Option 3: Logical networking does not set fan orientation.
- Option 4: Products and options differ.

**CDCS-Q0334 · single · operations**

What is the likely function of the open cutouts in the stated path?

Synthetic training case — not a field record.

Supply air is 22°C. One rack’s upper inlet reaches 31°C while the room-average sensor reads 24°C. Empty rack spaces lack blanking panels; a rear-exhaust switch is installed opposite the row’s intended flow direction. Several open cable cutouts return cold air directly toward cooling units. A proposal increases all fan speeds without inspecting the paths.

1. A bypass route for conditioned air that avoids useful IT heat pickup
2. A replacement for a calibrated airflow sensor
3. A guaranteed exhaust-only route from every rack
4. A structural reinforcement for the floor

**Correct option(s):** 1

- Option 1: Cold air can return without serving the intended load.
- Option 2: A hole does not measure flow.
- Option 3: The case describes cold air returning directly.
- Option 4: Openings do not inherently add strength.

**CDCS-Q0335 · single · mechanism**

What distinguishes recirculation from bypass?

Synthetic training case — not a field record.

Supply air is 22°C. One rack’s upper inlet reaches 31°C while the room-average sensor reads 24°C. Empty rack spaces lack blanking panels; a rear-exhaust switch is installed opposite the row’s intended flow direction. Several open cable cutouts return cold air directly toward cooling units. A proposal increases all fan speeds without inspecting the paths.

1. Bypass always means a UPS electrical mode in every context
2. Recirculation returns hot exhaust to inlets; bypass returns supply air without useful cooling
3. Recirculation is only a software error
4. They are always identical terms for any fan operation

**Correct option(s):** 2

- Option 1: Here it describes cooling airflow.
- Option 2: They are different mixing paths.
- Option 3: It can be a physical airflow path.
- Option 4: The mechanisms differ.

**CDCS-Q0336 · single · mechanism**

Why is increasing every fan speed not yet a demonstrated solution?

Synthetic training case — not a field record.

Supply air is 22°C. One rack’s upper inlet reaches 31°C while the room-average sensor reads 24°C. Empty rack spaces lack blanking panels; a rear-exhaust switch is installed opposite the row’s intended flow direction. Several open cable cutouts return cold air directly toward cooling units. A proposal increases all fan speeds without inspecting the paths.

1. Fan changes require no review because they are software settings
2. Higher fan speed always lowers every inlet equally
3. Fan speed can never affect airflow
4. It may increase energy without correcting the wrong flow paths

**Correct option(s):** 4

- Option 1: They affect the physical process and service.
- Option 2: Distribution and recirculation can persist.
- Option 3: It can, within the system behavior.
- Option 4: The mechanism should be diagnosed.

**CDCS-Q0337 · single · operations**

What measurements best test the local hypothesis?

Synthetic training case — not a field record.

Supply air is 22°C. One rack’s upper inlet reaches 31°C while the room-average sensor reads 24°C. Empty rack spaces lack blanking panels; a rear-exhaust switch is installed opposite the row’s intended flow direction. Several open cable cutouts return cold air directly toward cooling units. A proposal increases all fan speeds without inspecting the paths.

1. Only the number of perforated tiles
2. Inlet profiles, equipment direction and relevant supply/return flows under the load state
3. Only the room’s installed cooling nameplate
4. Only one cooling-unit return average

**Correct option(s):** 2

- Option 1: Tile count does not quantify delivered flow.
- Option 2: They follow the suspected heat path.
- Option 3: Capacity does not establish distribution.
- Option 4: It may conceal local bypass and recirculation.

**CDCS-Q0338 · single · mechanism**

Why is rack-door perforation percentage insufficient alone?

Synthetic training case — not a field record.

Supply air is 22°C. One rack’s upper inlet reaches 31°C while the room-average sensor reads 24°C. Empty rack spaces lack blanking panels; a rear-exhaust switch is installed opposite the row’s intended flow direction. Several open cable cutouts return cold air directly toward cooling units. A proposal increases all fan speeds without inspecting the paths.

1. Every 60% door delivers exactly 60% of fan free-air flow
2. Door construction never affects airflow
3. Pressure resistance and the complete installed airflow path determine delivery
4. Perforation percentage determines IT electrical power

**Correct option(s):** 3

- Option 1: No such universal proportionality is established.
- Option 2: It can add resistance.
- Option 3: Open area is one property among several.
- Option 4: Thermal flow and electrical load are different quantities.

**CDCS-Q0339 · single · operations**

What should a corrective change preserve in the service corridor?

Synthetic training case — not a field record.

Supply air is 22°C. One rack’s upper inlet reaches 31°C while the room-average sensor reads 24°C. Empty rack spaces lack blanking panels; a rear-exhaust switch is installed opposite the row’s intended flow direction. Several open cable cutouts return cold air directly toward cooling units. A proposal increases all fan speeds without inspecting the paths.

1. Only the current cable count
2. Only the appearance of a sealed aisle
3. Only maximum containment density regardless of access
4. Required maintenance access, egress and equipment removal paths

**Correct option(s):** 4

- Option 1: Future service and route constraints matter too.
- Option 2: Appearance does not prove access or thermal performance.
- Option 3: Packing barriers can obstruct required work.
- Option 4: Thermal changes must not create other operational defects.

**CDCS-Q0340 · single · operations**

What should confirm the correction?

Synthetic training case — not a field record.

Supply air is 22°C. One rack’s upper inlet reaches 31°C while the room-average sensor reads 24°C. Empty rack spaces lack blanking panels; a rear-exhaust switch is installed opposite the row’s intended flow direction. Several open cable cutouts return cold air directly toward cooling units. A proposal increases all fan speeds without inspecting the paths.

1. Only a temporary door opening with no recorded operating restriction
2. Only a lower room average
3. Only that new panels were purchased
4. Repeat relevant inlet/flow observations under comparable load with the accepted layout recorded

**Correct option(s):** 4

- Option 1: An uncontrolled temporary state is not a durable acceptance.
- Option 2: The local inlet is the concern.
- Option 3: Procurement does not prove installation or effect.
- Option 4: The result needs operating evidence and a maintained baseline.

**CDCS-Q0341 · single · operations**

What do low numerical residuals primarily support?

Synthetic training case — not a field record.

A CFD model predicts maximum rack inlet 27°C at a stated load. A field survey under intended equivalent conditions records 31°C at rack R7. The model uses free-air fan flow as fixed installed flow, omits a large cable obstruction and assumes sealed containment despite an open service door. Numerical residuals are low. The sensor’s calibration and exact position have not been checked.

1. Physical accuracy under every condition
2. Convergence of the numerical solution under its model assumptions
3. Correctness of omitted geometry
4. Calibration of the field temperature sensor

**Correct option(s):** 2

- Option 1: Incorrect inputs can still yield a converged solution.
- Option 2: They do not prove those assumptions match the facility.
- Option 3: Numerical convergence cannot include an obstruction that was not modeled.
- Option 4: Solver residuals do not assess the instrument.

**CDCS-Q0342 · single · mechanism**

Why is fixed free-air fan flow a questionable installed boundary?

Synthetic training case — not a field record.

A CFD model predicts maximum rack inlet 27°C at a stated load. A field survey under intended equivalent conditions records 31°C at rack R7. The model uses free-air fan flow as fixed installed flow, omits a large cable obstruction and assumes sealed containment despite an open service door. Numerical residuals are low. The sensor’s calibration and exact position have not been checked.

1. Free-air flow is always lower than installed flow by a universal amount
2. Actual flow depends on system resistance and fan behavior
3. Fan curves never matter to CFD
4. A fan model can be replaced by rack count alone

**Correct option(s):** 2

- Option 1: No fixed universal correction exists.
- Option 2: The installed operating point can differ from free-air rating.
- Option 3: They can be essential boundary information.
- Option 4: Count does not define pressure-flow behavior.

**CDCS-Q0343 · single · operations**

What effect can the omitted cable obstruction have?

Synthetic training case — not a field record.

A CFD model predicts maximum rack inlet 27°C at a stated load. A field survey under intended equivalent conditions records 31°C at rack R7. The model uses free-air fan flow as fixed installed flow, omits a large cable obstruction and assumes sealed containment despite an open service door. Numerical residuals are low. The sensor’s calibration and exact position have not been checked.

1. It automatically increases cooling capacity
2. It has no effect if the solver converges
3. It can only change the drawing’s appearance
4. It can change airflow resistance and distribution

**Correct option(s):** 4

- Option 1: Obstruction does not create refrigeration.
- Option 2: Convergence does not remove physical significance.
- Option 3: It is a physical flow obstruction.
- Option 4: Geometry omissions can affect local inlet predictions.

**CDCS-Q0344 · single · mechanism**

Why does the open service door matter?

Synthetic training case — not a field record.

A CFD model predicts maximum rack inlet 27°C at a stated load. A field survey under intended equivalent conditions records 31°C at rack R7. The model uses free-air fan flow as fixed installed flow, omits a large cable obstruction and assumes sealed containment despite an open service door. Numerical residuals are low. The sensor’s calibration and exact position have not been checked.

1. An open door always improves every inlet
2. It changes the containment/leakage boundary from the modeled state
3. Doors never affect airflow when fans run
4. The model should silently ignore the actual door position

**Correct option(s):** 2

- Option 1: Effects depend on the pressure and heat paths.
- Option 2: The compared configurations are not equivalent.
- Option 3: Openings can redirect flow.
- Option 4: That preserves a known mismatch.

**CDCS-Q0345 · single · operations**

What must be checked about the 31°C measurement?

Synthetic training case — not a field record.

A CFD model predicts maximum rack inlet 27°C at a stated load. A field survey under intended equivalent conditions records 31°C at rack R7. The model uses free-air fan flow as fixed installed flow, omits a large cable obstruction and assumes sealed containment despite an open service door. Numerical residuals are low. The sensor’s calibration and exact position have not been checked.

1. Only the sensor’s factory calibration date without its current installation conditions
2. Only whether the reading is inconvenient for acceptance
3. Sensor suitability, calibration, location, timing and load state
4. Only the model’s predicted value

**Correct option(s):** 3

- Option 1: Location, current condition and timing still matter.
- Option 2: Preference is irrelevant to accuracy.
- Option 3: The comparison needs trustworthy equivalent observations.
- Option 4: A prediction cannot independently calibrate the sensor.

**CDCS-Q0346 · single · mechanism**

Why should the analyst not alter the heat-load input merely to force a 31°C plot without new load evidence?

Synthetic training case — not a field record.

A CFD model predicts maximum rack inlet 27°C at a stated load. A field survey under intended equivalent conditions records 31°C at rack R7. The model uses free-air fan flow as fixed installed flow, omits a large cable obstruction and assumes sealed containment despite an open service door. Numerical residuals are low. The sensor’s calibration and exact position have not been checked.

1. Models can never be calibrated
2. Arbitrary tuning can hide the actual cause and break the load evidence
3. Any agreement with one point proves all future states
4. Heat load is unrelated to temperature

**Correct option(s):** 2

- Option 1: Calibration is useful when based on justified inputs and validation.
- Option 2: Changes need a defensible physical basis.
- Option 3: One fitted observation is not broad predictive validation.
- Option 4: It is a material model input.

**CDCS-Q0347 · single · operations**

Which result supports mesh independence within the tested refinement range?

Synthetic training case — not a field record.

A CFD model predicts maximum rack inlet 27°C at a stated load. A field survey under intended equivalent conditions records 31°C at rack R7. The model uses free-air fan flow as fixed installed flow, omits a large cable obstruction and assumes sealed containment despite an open service door. Numerical residuals are low. The sensor’s calibration and exact position have not been checked.

1. Relevant quantitative results remain within the defined tolerance across suitable refinements
2. Whether the maximum inlet changes materially while boundary conditions remain fixed
3. Whether every model must use exactly the same cell count
4. Whether one refined run looks visually similar without comparing quantitative results

**Correct option(s):** 1

- Option 1: This supports bounded numerical independence, not automatic physical validation.
- Option 2: That observation would reveal sensitivity rather than automatically prove independence.
- Option 3: Appropriate resolution depends on geometry and physics.
- Option 4: Visual similarity can conceal material local differences.

**CDCS-Q0348 · single · operations**

What conservation check is useful?

Synthetic training case — not a field record.

A CFD model predicts maximum rack inlet 27°C at a stated load. A field survey under intended equivalent conditions records 31°C at rack R7. The model uses free-air fan flow as fixed installed flow, omits a large cable obstruction and assumes sealed containment despite an open service door. Numerical residuals are low. The sensor’s calibration and exact position have not been checked.

1. Whether all rack labels are alphabetically ordered
2. Whether total server count equals total fan count
3. Whether every surface has the same temperature
4. Whether modeled mass and energy flows balance within justified numerical tolerance

**Correct option(s):** 4

- Option 1: Ordering does not test physics.
- Option 2: No such physical balance is required.
- Option 3: A working cooling model normally contains gradients.
- Option 4: It can reveal inconsistent setup or solution behavior.

**CDCS-Q0349 · single · operations**

What strengthens validation after correction?

Synthetic training case — not a field record.

A CFD model predicts maximum rack inlet 27°C at a stated load. A field survey under intended equivalent conditions records 31°C at rack R7. The model uses free-air fan flow as fixed installed flow, omits a large cable obstruction and assumes sealed containment despite an open service door. Numerical residuals are low. The sensor’s calibration and exact position have not been checked.

1. Comparison with suitable observations beyond a single tuning target and stated scenario limits
2. Only declaring CFD universally exact
3. Only reusing the one point used to tune every parameter
4. Only hiding the original 27°C prediction

**Correct option(s):** 1

- Option 1: It tests predictive usefulness within scope.
- Option 2: Models retain assumptions and uncertainty.
- Option 3: That can overfit the observation.
- Option 4: History helps explain the correction.

**CDCS-Q0350 · single · design**

What is the current acceptance conclusion?

Synthetic training case — not a field record.

A CFD model predicts maximum rack inlet 27°C at a stated load. A field survey under intended equivalent conditions records 31°C at rack R7. The model uses free-air fan flow as fixed installed flow, omits a large cable obstruction and assumes sealed containment despite an open service door. Numerical residuals are low. The sensor’s calibration and exact position have not been checked.

1. The present model does not substantiate the claimed field maximum
2. The facility necessarily violates every thermal standard
3. The model must be discarded forever
4. The 27°C prediction overrides the field reading automatically

**Correct option(s):** 1

- Option 1: Inputs and measurement equivalence remain unresolved.
- Option 2: No applicable universal limit is supplied.
- Option 3: It can be corrected and revalidated.
- Option 4: A model is not superior evidence solely because it is computational.

**CDCS-Q0351 · single · calculation**

What sensible capacity follows from the stated rating?

Synthetic training case — not a field record.

A unit is rated 100 kW total cooling with SHR 0.80 at the supplied conditions. The room requires 85 kW sensible and 5 kW latent removal. A separate operating measurement gives 90 kW useful cooling for 30 kW input. A controlling temperature sensor reads 2°C lower than a suitable reference; its display says 24°C. Two room units are observed humidifying and dehumidifying simultaneously.

1. 20 kW
2. 100 kW
3. 80 kW
4. 125 kW

**Correct option(s):** 3

- Option 1: That is the latent portion in this rating.
- Option 2: That is total capacity, including latent duty.
- Option 3: 100×0.80.
- Option 4: That divides by SHR and exceeds total capacity.

**CDCS-Q0352 · single · mechanism**

Why does the unit not meet the stated load at this rating point?

Synthetic training case — not a field record.

A unit is rated 100 kW total cooling with SHR 0.80 at the supplied conditions. The room requires 85 kW sensible and 5 kW latent removal. A separate operating measurement gives 90 kW useful cooling for 30 kW input. A controlling temperature sensor reads 2°C lower than a suitable reference; its display says 24°C. Two room units are observed humidifying and dehumidifying simultaneously.

1. Its total 100 kW is below total 90 kW demand
2. Its 80 kW sensible capacity is below the 85 kW sensible demand
3. Its latent capacity is only 5 kW
4. Any unit with SHR below one is unusable

**Correct option(s):** 2

- Option 1: The total rating is higher, so that is not the mismatch.
- Option 2: Total capacity alone hides the limiting component.
- Option 3: The stated rating implies 20 kW latent.
- Option 4: Suitability depends on the actual load and conditions.

**CDCS-Q0353 · single · calculation**

What latent capacity is implied at the stated rating?

Synthetic training case — not a field record.

A unit is rated 100 kW total cooling with SHR 0.80 at the supplied conditions. The room requires 85 kW sensible and 5 kW latent removal. A separate operating measurement gives 90 kW useful cooling for 30 kW input. A controlling temperature sensor reads 2°C lower than a suitable reference; its display says 24°C. Two room units are observed humidifying and dehumidifying simultaneously.

1. 20 kW
2. 5 kW
3. 80 kW
4. 100 kW

**Correct option(s):** 1

- Option 1: 100 total minus 80 sensible.
- Option 2: That is the room’s latent demand.
- Option 3: That is the sensible portion.
- Option 4: That would leave no sensible capacity.

**CDCS-Q0354 · single · calculation**

What is COP from the separate operating measurement?

Synthetic training case — not a field record.

A unit is rated 100 kW total cooling with SHR 0.80 at the supplied conditions. The room requires 85 kW sensible and 5 kW latent removal. A separate operating measurement gives 90 kW useful cooling for 30 kW input. A controlling temperature sensor reads 2°C lower than a suitable reference; its display says 24°C. Two room units are observed humidifying and dehumidifying simultaneously.

1. 3.0
2. 120
3. 60
4. 0.333

**Correct option(s):** 1

- Option 1: 90 kW cooling divided by 30 kW input.
- Option 2: That adds cooling and input instead of dividing.
- Option 3: That subtracts power values and treats the difference as a ratio.
- Option 4: That reverses useful output and input.

**CDCS-Q0355 · single · mechanism**

Why not compare COP directly with an EER number without definition?

Synthetic training case — not a field record.

A unit is rated 100 kW total cooling with SHR 0.80 at the supplied conditions. The room requires 85 kW sensible and 5 kW latent removal. A separate operating measurement gives 90 kW useful cooling for 30 kW input. A controlling temperature sensor reads 2°C lower than a suitable reference; its display says 24°C. Two room units are observed humidifying and dehumidifying simultaneously.

1. EER automatically includes every facility auxiliary
2. Efficiency metrics never compare useful output with input
3. All efficiency numbers are identical if rounded
4. Unit conventions and rating conditions may differ

**Correct option(s):** 4

- Option 1: Its actual boundary must be checked.
- Option 2: Many do, with specific conventions.
- Option 3: Rounding does not align definitions.
- Option 4: A larger numeric value may not mean greater efficiency on the same basis.

**CDCS-Q0356 · single · calculation**

What temperature does the reference imply where the sensor displays 24°C?

Synthetic training case — not a field record.

A unit is rated 100 kW total cooling with SHR 0.80 at the supplied conditions. The room requires 85 kW sensible and 5 kW latent removal. A separate operating measurement gives 90 kW useful cooling for 30 kW input. A controlling temperature sensor reads 2°C lower than a suitable reference; its display says 24°C. Two room units are observed humidifying and dehumidifying simultaneously.

1. 48°C
2. 24°C exactly
3. 26°C
4. 22°C

**Correct option(s):** 3

- Option 1: That doubles an absolute value without basis.
- Option 2: That ignores the observed bias.
- Option 3: The sensor reads two degrees lower than the reference.
- Option 4: That applies the bias in the wrong direction.

**CDCS-Q0357 · single · operations**

What should correct the sensor issue?

Synthetic training case — not a field record.

A unit is rated 100 kW total cooling with SHR 0.80 at the supplied conditions. The room requires 85 kW sensible and 5 kW latent removal. A separate operating measurement gives 90 kW useful cooling for 30 kW input. A controlling temperature sensor reads 2°C lower than a suitable reference; its display says 24°C. Two room units are observed humidifying and dehumidifying simultaneously.

1. Change the display label to say calibrated without testing
2. Supported calibration/verification with as-found and as-left evidence
3. Use the biased sensor to certify its own reference
4. Ignore it because the control loop is stable

**Correct option(s):** 2

- Option 1: A label does not correct measurement.
- Option 2: The physical measurement must be made trustworthy.
- Option 3: That is circular verification.
- Option 4: A stable loop can regulate the wrong actual condition.

**CDCS-Q0358 · single · mechanism**

What does simultaneous humidification and dehumidification suggest?

Synthetic training case — not a field record.

A unit is rated 100 kW total cooling with SHR 0.80 at the supplied conditions. The room requires 85 kW sensible and 5 kW latent removal. A separate operating measurement gives 90 kW useful cooling for 30 kW input. A controlling temperature sensor reads 2°C lower than a suitable reference; its display says 24°C. Two room units are observed humidifying and dehumidifying simultaneously.

1. That both units should be disabled immediately by the learner
2. That humidity ratio must be zero
3. Potentially conflicting control actions requiring strategy/sensor review
4. Guaranteed optimal humidity control

**Correct option(s):** 3

- Option 1: A controlled review and authorized response are required.
- Option 2: No such conclusion follows.
- Option 3: The units may waste energy or fight over the same condition.
- Option 4: Opposing actions need justification.

**CDCS-Q0359 · single · design**

What should a selection comparison include beyond rated COP?

Synthetic training case — not a field record.

A unit is rated 100 kW total cooling with SHR 0.80 at the supplied conditions. The room requires 85 kW sensible and 5 kW latent removal. A separate operating measurement gives 90 kW useful cooling for 30 kW input. A controlling temperature sensor reads 2°C lower than a suitable reference; its display says 24°C. Two room units are observed humidifying and dehumidifying simultaneously.

1. Actual load/ambient profile, sensible duty, auxiliaries, maintenance and required states
2. Only the best catalogue operating point
3. Only the nominal thermostat setpoint
4. Only total unit mass

**Correct option(s):** 1

- Option 1: Whole-system performance differs from one point.
- Option 2: That can misrepresent annual behavior.
- Option 3: A setpoint does not prove capacity or actual conditions.
- Option 4: Mass does not establish useful cooling efficiency.

**CDCS-Q0360 · single · design**

What should operational acceptance measure?

Synthetic training case — not a field record.

A unit is rated 100 kW total cooling with SHR 0.80 at the supplied conditions. The room requires 85 kW sensible and 5 kW latent removal. A separate operating measurement gives 90 kW useful cooling for 30 kW input. A controlling temperature sensor reads 2°C lower than a suitable reference; its display says 24°C. Two room units are observed humidifying and dehumidifying simultaneously.

1. The required local environmental conditions and control response under representative states
2. Only that the compressor runs
3. Only total cooling greater than IT power
4. Only one average value before occupancy

**Correct option(s):** 1

- Option 1: Ratings and displayed targets are not enough.
- Option 2: Running does not establish the required room outcome.
- Option 3: Sensible/latent split and distribution matter.
- Option 4: The actual load and operating states remain untested.

**CDCS-Q0361 · single · calculation**

What is the liquid heat-removal duty?

Synthetic training case — not a field record.

A synthetic 500 kW rack exports 85% of its heat to a single-phase liquid loop and 15% to air. Use cp=4.18 kJ/(kg·K), liquid rise 5 K and density 1 kg/L for this water-property model. A CDU separates facility and technology loops. The proposed substitute coolant has different properties and unverified connector/material compatibility. Leak alarms reach DCIM, but local response and recovery are untested.

1. 500 kW
2. 75 kW
3. 588.2 kW
4. 425 kW

**Correct option(s):** 4

- Option 1: That ignores the stated residual air fraction.
- Option 2: That is the air duty.
- Option 3: That divides total load by the liquid fraction.
- Option 4: 500×0.85.

**CDCS-Q0362 · single · calculation**

What residual air-cooling duty remains?

Synthetic training case — not a field record.

A synthetic 500 kW rack exports 85% of its heat to a single-phase liquid loop and 15% to air. Use cp=4.18 kJ/(kg·K), liquid rise 5 K and density 1 kg/L for this water-property model. A CDU separates facility and technology loops. The proposed substitute coolant has different properties and unverified connector/material compatibility. Leak alarms reach DCIM, but local response and recovery are untested.

1. Zero
2. 425 kW
3. 15 kW
4. 75 kW

**Correct option(s):** 4

- Option 1: Direct liquid cooling of 85% does not remove all air heat.
- Option 2: That is the liquid portion.
- Option 3: That treats the percentage value as power.
- Option 4: 500×0.15.

**CDCS-Q0363 · single · calculation**

What liquid mass flow does the supplied model require?

Synthetic training case — not a field record.

A synthetic 500 kW rack exports 85% of its heat to a single-phase liquid loop and 15% to air. Use cp=4.18 kJ/(kg·K), liquid rise 5 K and density 1 kg/L for this water-property model. A CDU separates facility and technology loops. The proposed substitute coolant has different properties and unverified connector/material compatibility. Leak alarms reach DCIM, but local response and recovery are untested.

1. Approximately 20.33 kg/s
2. 425 kg/s
3. 4.07 kg/s
4. 101.67 kg/s

**Correct option(s):** 1

- Option 1: 425 divided by 4.18×5.
- Option 2: That treats heat power as mass flow without properties.
- Option 3: That divides by the temperature rise twice.
- Option 4: That omits the 5 K rise.

**CDCS-Q0364 · single · calculation**

What is the corresponding volume flow at the supplied density?

Synthetic training case — not a field record.

A synthetic 500 kW rack exports 85% of its heat to a single-phase liquid loop and 15% to air. Use cp=4.18 kJ/(kg·K), liquid rise 5 K and density 1 kg/L for this water-property model. A CDU separates facility and technology loops. The proposed substitute coolant has different properties and unverified connector/material compatibility. Leak alarms reach DCIM, but local response and recovery are untested.

1. 20.33 m³/s
2. 1 L/s
3. 20330 L/s
4. Approximately 20.33 L/s

**Correct option(s):** 4

- Option 1: That mislabels litres as cubic metres.
- Option 2: The density value is not the flow rate.
- Option 3: That adds an unnecessary factor of 1000.
- Option 4: Density is one kilogram per litre in this model.

**CDCS-Q0365 · single · mechanism**

Why cannot the same numerical flow be assumed for the substitute coolant?

Synthetic training case — not a field record.

A synthetic 500 kW rack exports 85% of its heat to a single-phase liquid loop and 15% to air. Use cp=4.18 kJ/(kg·K), liquid rise 5 K and density 1 kg/L for this water-property model. A CDU separates facility and technology loops. The proposed substitute coolant has different properties and unverified connector/material compatibility. Leak alarms reach DCIM, but local response and recovery are untested.

1. A CDU automatically converts every fluid to water
2. All liquids have identical thermal properties
3. Equal viscosity guarantees equal heat capacity and density
4. Specific heat and density may differ, changing the heat balance

**Correct option(s):** 4

- Option 1: Heat exchange does not change chemical identity.
- Option 2: They do not.
- Option 3: These are distinct fluid properties.
- Option 4: The original calculation used water-like supplied properties.

**CDCS-Q0366 · single · operations**

Which statement correctly describes the separated CDU loops?

Synthetic training case — not a field record.

A synthetic 500 kW rack exports 85% of its heat to a single-phase liquid loop and 15% to air. Use cp=4.18 kJ/(kg·K), liquid rise 5 K and density 1 kg/L for this water-property model. A CDU separates facility and technology loops. The proposed substitute coolant has different properties and unverified connector/material compatibility. Leak alarms reach DCIM, but local response and recovery are untested.

1. The technology loop can reject full heat indefinitely with no facility-side flow
2. A normal CDU network link proves both loops have adequate thermal capability
3. Technology cooling remains dependent on adequate facility-side heat rejection
4. Both loops must use identical fluid chemistry because heat crosses between them

**Correct option(s):** 3

- Option 1: The stated CDU still needs its supported heat-rejection path.
- Option 2: Communications alone do not measure flow, temperature or heat transfer.
- Option 3: A heat exchanger does not create an independent ultimate heat sink.
- Option 4: A heat exchanger can separate fluids subject to supported compatibility.

**CDCS-Q0367 · single · operations**

What must be verified for the substitute fluid?

Synthetic training case — not a field record.

A synthetic 500 kW rack exports 85% of its heat to a single-phase liquid loop and 15% to air. Use cp=4.18 kJ/(kg·K), liquid rise 5 K and density 1 kg/L for this water-property model. A CDU separates facility and technology loops. The proposed substitute coolant has different properties and unverified connector/material compatibility. Leak alarms reach DCIM, but local response and recovery are untested.

1. IT/CDU support, materials, seals, connectors, chemistry and operating limits
2. Only that it is marketed for cooling
3. Only the original water-based flow calculation
4. Only the container size

**Correct option(s):** 1

- Option 1: Thermal capacity alone does not establish compatibility.
- Option 2: The specific equipment combination matters.
- Option 3: That omits chemistry and mechanical interfaces.
- Option 4: Packaging does not establish material compatibility.

**CDCS-Q0368 · single · mechanism**

What does the received DCIM leak alarm prove by itself?

Synthetic training case — not a field record.

A synthetic 500 kW rack exports 85% of its heat to a single-phase liquid loop and 15% to air. Use cp=4.18 kJ/(kg·K), liquid rise 5 K and density 1 kg/L for this water-property model. A CDU separates facility and technology loops. The proposed substitute coolant has different properties and unverified connector/material compatibility. Leak alarms reach DCIM, but local response and recovery are untested.

1. That coolant quality is acceptable
2. That every leak is physically isolated
3. The tested notification reached DCIM
4. That the rack can remain at full load indefinitely during leakage

**Correct option(s):** 3

- Option 1: Alarm delivery does not measure fluid condition.
- Option 2: No local response test is supplied.
- Option 3: It does not demonstrate the required local protective/control response.
- Option 4: That depends on the accepted sequence and actual condition.

**CDCS-Q0369 · single · operations**

What should a return-to-service plan consider after liquid-loop intervention?

Synthetic training case — not a field record.

A synthetic 500 kW rack exports 85% of its heat to a single-phase liquid loop and 15% to air. Use cp=4.18 kJ/(kg·K), liquid rise 5 K and density 1 kg/L for this water-property model. A CDU separates facility and technology loops. The proposed substitute coolant has different properties and unverified connector/material compatibility. Leak alarms reach DCIM, but local response and recovery are untested.

1. Only resetting the leak alarm
2. Only the CDU’s network link becoming available
3. Only replacing the event timestamp
4. Required cleanliness, air removal, leak integrity, flow/control state and accepted IT response

**Correct option(s):** 4

- Option 1: Reset does not restore fluid integrity or flow.
- Option 2: Communications do not prove the thermal service.
- Option 3: That would alter evidence rather than restore the system.
- Option 4: Recovery spans physical and control conditions.

**CDCS-Q0370 · single · mechanism**

What distinguishes single-phase from two-phase cooling in this lesson?

Synthetic training case — not a field record.

A synthetic 500 kW rack exports 85% of its heat to a single-phase liquid loop and 15% to air. Use cp=4.18 kJ/(kg·K), liquid rise 5 K and density 1 kg/L for this water-property model. A CDU separates facility and technology loops. The proposed substitute coolant has different properties and unverified connector/material compatibility. Leak alarms reach DCIM, but local response and recovery are untested.

1. Single-phase means one electrical utility feed
2. The intended heat-transfer process does or does not include fluid phase change in the relevant loop
3. All immersion systems must use the same phase behavior
4. Two-phase means any two parallel pumps

**Correct option(s):** 2

- Option 1: Here phase refers to fluid state.
- Option 2: The designs have different operating requirements.
- Option 3: Supported immersion designs can differ.
- Option 4: Pump count is not the definition.

#### Recall

**Humidity ratio, relative humidity and a cold surface — Synthetic training case — not a field record.

Use the supplied ideal relation pv=W×P/(0.622+W). At 24°C, W=0.010 kg/kg dry air, P=101.325 kPa and supplied saturation pressure is 2.985 kPa. A later sensible-heating step adds no moisture. Local dew point is separately measured as 14°C; a pipe surface is 12°C. No universal equipment or health limits are supplied.**

pv≈1.603 kPa and RH≈53.7%. Sensible heating without moisture addition keeps humidity ratio approximately constant while RH generally falls. The 12°C surface is below the local 14°C dew point, so condensation is possible. Actual equipment envelopes require the selected current vendor/ASHRAE references.

**Sensible heat and the airflow requirement — Synthetic training case — not a field record.

A synthetic steady sensible-air model removes 120 kW. Use density 1.2 kg/m³, cp=1.005 kJ/(kg·K), and air temperature rise 10 K. Use 1 m³/s=3600 m³/h=2118.88 CFM and 1 kW=3412 Btu/h. Ignore leakage, fan heat and property variation for this calculation. No fan/system pressure curve is supplied.**

Mass flow is 120/(1.005×10)=11.94 kg/s. Volume flow is 9.950 m³/s, approximately 35821 m³/h or 21083 CFM. Heat is 409440 Btu/h. These are model requirements, not proof that the installed system delivers that flow.

**Cold supply, hot inlet and wasted bypass air — Synthetic training case — not a field record.

Supply air is 22°C. One rack’s upper inlet reaches 31°C while the room-average sensor reads 24°C. Empty rack spaces lack blanking panels; a rear-exhaust switch is installed opposite the row’s intended flow direction. Several open cable cutouts return cold air directly toward cooling units. A proposal increases all fan speeds without inspecting the paths.**

The evidence supports local recirculation and bypass hypotheses. Inspect equipment direction, blanking, openings, containment and actual inlet/flow measurements. A room average and additional fan speed cannot establish that useful cooling reaches the hot inlet.

**A CFD plot that disagrees with the rack — Synthetic training case — not a field record.

A CFD model predicts maximum rack inlet 27°C at a stated load. A field survey under intended equivalent conditions records 31°C at rack R7. The model uses free-air fan flow as fixed installed flow, omits a large cable obstruction and assumes sealed containment despite an open service door. Numerical residuals are low. The sensor’s calibration and exact position have not been checked.**

Low solver residuals do not validate incorrect physical inputs. Reconcile fan/system behavior, geometry, leakage and measurement conditions. Preserve the discrepancy and correct the justified inputs; do not tune heat load merely to force agreement. Validate the revised model within its stated scenario.

**Total cooling capacity, SHR and a biased sensor — Synthetic training case — not a field record.

A unit is rated 100 kW total cooling with SHR 0.80 at the supplied conditions. The room requires 85 kW sensible and 5 kW latent removal. A separate operating measurement gives 90 kW useful cooling for 30 kW input. A controlling temperature sensor reads 2°C lower than a suitable reference; its display says 24°C. Two room units are observed humidifying and dehumidifying simultaneously.**

Rated sensible capacity is 80 kW, below the 85 kW sensible requirement despite 100 kW total exceeding 90 kW total demand. The separate operating COP is 3.0. The biased sensor implies 26°C at its location under the supplied comparison. Review calibration and control coordination rather than assuming the nominal setpoint or total rating proves acceptance.

**Direct liquid duty with residual air cooling — Synthetic training case — not a field record.

A synthetic 500 kW rack exports 85% of its heat to a single-phase liquid loop and 15% to air. Use cp=4.18 kJ/(kg·K), liquid rise 5 K and density 1 kg/L for this water-property model. A CDU separates facility and technology loops. The proposed substitute coolant has different properties and unverified connector/material compatibility. Leak alarms reach DCIM, but local response and recovery are untested.**

Liquid duty is 425 kW and residual air duty 75 kW. Required mass flow is 425/(4.18×5)=20.33 kg/s, or 20.33 L/s at the supplied density. The CDU remains dependent on facility heat rejection, and substitute fluid compatibility, leak action and recovery require explicit vendor/specialist acceptance.

#### References

- [EPI CDCS public syllabus](https://www.epi-ap.com/services/1/3/5)
- [ASHRAE data-centre resource catalogue; obtain applicable assigned edition](https://www.ashrae.org/technical-resources/bookstore/datacom-series)
- [NVIDIA DGX B200 current product environmental reference](https://docs.nvidia.com/dgx/dgxb200-user-guide/introduction-to-dgxb200.html)

## CDCS-M09 — Fire detection, suppression and accepted cause-and-effect interfaces

### CDCS-L09 — Fire detection, suppression and accepted cause-and-effect interfaces

Estimated study time: 120 minutes before independent work. Prerequisite chapters: CDCS-L08

## Fire protection is a coordinated system with specialist authority

Fire protection combines prevention, detection, alarm, containment, suppression, life-safety response and recovery. The fire triangle describes fuel, heat and oxygen as necessary contributors to combustion; different protective measures interrupt different parts of the process or its consequences. Removing unnecessary combustible storage reduces available fuel, while maintaining electrical connections can reduce an ignition mechanism. Detection identifies a condition so the designed response can begin. Suppression controls or extinguishes a fire through the selected agent's mechanism. No single dashboard, detector or cylinder replaces the complete accepted system.

The applicable building/fire requirements, system standards, product approvals and authority having jurisdiction determine the actual design. This course develops the ability to review interfaces and evidence; it does not authorize a learner to set discharge concentration, alter release delays, impair protection or perform a live discharge. D1 barrier literacy and D2/D3 specialist design responsibilities remain bounded by the charter. Numerical values in the worked cases are explicitly supplied training parameters, not universal NFPA, local-code or manufacturer requirements.

## Detection performance depends on transport and environment

Point detectors sense conditions at their installed locations. Aspirating systems draw air through a sampling pipe network to a detection unit; transport time, sample balance, pipe integrity, filter condition and airflow monitoring affect the complete function. A detector electronics self-test is not the same as proving that smoke from the intended protected location reaches the sensing chamber within the required time. A blocked sampling hole, disconnected pipe or altered airflow can change performance while the central panel remains powered. Installation verification should follow the actual approved design and manufacturer method.

Detector selection and placement must suit airflow, contamination, ceiling/underfloor spaces and the intended hazard. High airflow can dilute or redirect smoke; obstructions and later layout changes can alter transport. Sensitivity alone does not establish useful detection if the sampled air does not represent the protected volume. Distinguish fire alarm, pre-alarm, supervisory and trouble conditions according to the accepted system semantics. A trouble indication can mean impaired detection capability rather than a confirmed fire. The receiving BAS/DCIM should preserve those distinctions rather than mapping every event to a generic normal/fault bit.

Testing needs an authorized plan that preserves life safety and service. Use the approved method, test medium, locations, expected timing, impairment controls and restoration checks. This app's case records are synthetic; no actual smoke generation or live system impairment is performed. Record test initiation, detection, panel processing, notification and required downstream actions with clock uncertainty understood. A successful notification test at the panel cannot by itself prove the field detection path, and a field detector response does not prove that the correct on-call team received the alarm.

## Select suppression by hazard, occupancy and complete performance

Water-based systems remove heat and can provide substantial fire-control capability in appropriate designs. Wet-pipe, dry-pipe, preaction and water-mist arrangements differ in how water is held, admitted and discharged, and in their specific supported applications. A preaction valve admitting water to piping is not necessarily the same event as water discharging from a closed heat-operated sprinkler; the actual design determines the sequence. Dry or preaction arrangements can introduce delivery-time and supervisory dependencies that must be assessed. Do not claim that water-based protection is universally incompatible with data centres or that one arrangement removes every accidental-discharge risk.

Gas/clean-agent systems use selected agents and concentrations under their approved design. Some act primarily through heat absorption or chemical effects; inert-gas systems reduce oxygen concentration within their designed application. Occupancy, exposure, egress, pressure relief, agent compatibility, enclosure integrity and post-discharge conditions require specialist evaluation. “No residue” does not mean no life-safety or equipment consideration. Agent choice must also account for current availability and applicable environmental restrictions through the responsible design/procurement process, rather than assuming an old product recommendation remains universally suitable.

The protected volume includes the spaces specified by the design, such as room, underfloor or ceiling voids, with only justified deductions. Changing a partition, raised floor, ceiling or large fixed obstruction can affect agent quantity, distribution and leakage. A geometric volume calculation is one input; actual agent sizing may require temperature, altitude, concentration, safety factors, hydraulic distribution and manufacturer software. Cylinder count without fill, availability and connected-state evidence is not usable agent quantity. An isolated cylinder cannot silently be counted as available for the required event.

## Understand quantity, discharge and hold as different questions

In an original simplified quantity exercise, a protected floor area of 80 m² spans a 3 m room, 0.5 m floor void and 0.4 m ceiling void. Gross modeled volume is 80×3.9=312 m³. A supplied approved deduction of 12 m³ leaves 300 m³. If the exercise specifies an illustrative loading factor of 0.65 kg/m³, modeled mass is 195 kg. This factor is invented for arithmetic practice and is not a selection value for any real agent. Five available 40 kg units total 200 kg in the model; four provide only 160 kg. Real design still needs its actual agent method and installation verification.

Discharge time concerns delivery of the agent according to the accepted system design. Hold time concerns maintaining the required protective condition after discharge for the specified period and purpose. They are not interchangeable. Enclosure leakage, doors, dampers, penetrations, ventilation and pressure behavior affect retention. A cylinder mass check does not establish hold performance, and a room-integrity test does not by itself prove nozzle distribution or detection/release logic. Each required outcome needs its own evidence.

A supplied exponential retention model C(t)=C0 e^(−kt) can teach sensitivity to leakage without pretending to be an actual enclosure design method. With C0=8%, k=0.02 per minute and t=10 minutes, modeled concentration is about 6.55%. If the synthetic criterion is at least 6% at ten minutes, this model passes that numerical condition. Doubling the modeled loss coefficient to 0.04 gives about 5.36%, which does not. Real hold verification uses the actual approved method, agent behavior, enclosure characteristics and acceptance criteria; this equation is only an explanatory model.

## Cause-and-effect logic must preserve meaning and authority

A fire cause-and-effect matrix connects initiating conditions to panel indications, alarms, release behavior, ventilation/damper actions, access/egress interfaces and notifications. Cross-zoning or other confirmation logic may be part of a specific design, but it is not a universal instruction to require two detectors in every system. Manual release, abort, delay and reset behavior must follow the accepted system and authority. The integration engineer should verify exact point semantics and sequences without replacing the dedicated fire panel's required function with a general-purpose PLC or BMS script.

Time sequence matters. A signal received by DCIM after a delay does not establish that a local protective action occurred on time. A commanded damper state differs from verified position; a release command differs from actual discharge feedback. Communication loss should produce the required trouble or supervisory behavior, not a false normal indication. Preserve source identity, timestamp/clock basis, quality and acknowledgement meaning. Acknowledging an alarm does not mean the fire condition is cleared or the system has been reset and returned to protection.

Life-safety interfaces need explicit coordination. Security access controls must preserve required emergency egress; ventilation shutdown can affect cooling and pressure; power isolation can affect IT and fire-system supplies. The responsible specialists define the correct behavior for the hazard and jurisdiction. An operational continuity objective cannot justify silently disabling a required fire response. If testing or maintenance requires impairment, the site must authorize the scope, compensating measures, duration, notifications and restoration according to its approved process.

## Maintain and recover the complete protective capability

Ongoing maintenance addresses detectors, sampling networks, panels, power supplies, batteries, valves, cylinders, piping/nozzles, enclosure integrity, alarms and records as applicable. A green panel does not prove every mechanical or enclosure condition. Verify replacement part compatibility and retain actual as-found/as-left evidence. Later cable penetrations, rack layouts, ceiling changes or ventilation modifications can invalidate earlier assumptions. Link those changes to fire-system review instead of waiting for the next scheduled test to discover them.

After an event or impairment, restoration includes the accepted protected state, replenished or reconnected suppression resources, cleared temporary restrictions, verified detection/control paths and usable operating records. A reset that removes the visible alarm is not proof of readiness. Preserve event evidence and coordinate re-entry or equipment recovery with the designated authorities. The practical portfolio should show how the learner traced requirements and interfaces, interpreted test records and identified gaps, while actual testing, impairment and discharge remain separately authorized physical evidence.


#### Worked demonstrations

**An aspirating detector passes electronics but misses a sampling point**

Synthetic training case — not a field record.

A synthetic aspirating-system electronics self-test passes. During an authorized recorded test at sampling point P7, no detector response occurs within the project’s supplied 60-second criterion. A disconnected sampling branch is later found. A separate panel-injected alarm reaches DCIM in two seconds. DCIM maps both fire alarm and detector trouble to one generic red icon.

**Reasoning:** The electronics test and panel notification do not establish smoke transport from P7. The disconnected branch explains a concrete path defect needing correction and retest. Preserve fire versus trouble semantics so operators know whether a fire condition or impaired detection is reported.

**Protected volume and a modeled retention condition**

Synthetic training case — not a field record.

Synthetic arithmetic only: floor area 80 m²; protected heights 3 m room +0.5 m floor void +0.4 m ceiling void; approved model deduction 12 m³. Illustrative loading factor 0.65 kg/m³ is not a real agent requirement. Five units each contain usable 40 kg, but one is isolated. Separate model C(t)=8e^(−kt) percent uses k=0.02/min and criterion C(10)≥6%; a changed leakage state has k=0.04/min.

**Reasoning:** Net modeled volume is 300 m³ and quantity 195 kg. Four available units supply 160 kg, 35 kg short. Original retention predicts 6.55% at ten minutes, while changed leakage predicts 5.36%. These models do not establish actual agent concentration, hydraulics, safety or enclosure acceptance.

**Water admission is not necessarily sprinkler discharge**

Synthetic training case — not a field record.

A supplied preaction design narrative states that a confirmed detection condition admits water to the piping; water discharges at a closed sprinkler only when its heat-responsive element operates. A recorded test proves valve admission but does not operate a sprinkler or measure end-point delivery time. The supervisory air-pressure signal is mapped as a fire alarm. A water-mist substitute is proposed without application approval evidence.

**Reasoning:** Interpret the actual supplied sequence: admission fills the piping but does not prove discharge through a still-closed sprinkler. End-point delivery and supervisory semantics remain to verify. A different water-based technology requires its own supported hazard/application design rather than automatic substitution.

**Fire cause-and-effect and restoration after impairment**

Synthetic training case — not a field record.

A synthetic cause-and-effect matrix requires a fire-panel output to command a damper closed and receive separate closed-position feedback. The BMS logs command sent but no feedback. DCIM receives a release-command event, with no discharge feedback. A temporary impairment expires at 18:00; at 18:20 the panel is reset but one cylinder remains isolated. A security change would lock an emergency exit on fire alarm.

**Reasoning:** Command, physical feedback and actual discharge are separate evidence. Reset does not restore the isolated resource or renew the impairment. Resolve the life-safety interface with competent authorities; a BMS/DCIM integration must not silently replace the dedicated panel or defeat egress.

#### Guided practice

Review the detection transport, gas arithmetic, preaction sequence and expired impairment records as one fire-system evidence package.

**Hint:** Separate indication, command, physical action, suppression quantity, retention and restored readiness.

**Worked solution:** P7 fails despite electronics and notification passes. The synthetic gas model needs 195 kg but only 160 kg is available; modeled retention changes from 6.55% to 5.36% at ten minutes. Valve admission does not prove sprinkler discharge. Damper/discharge feedback, valid impairment authority, cylinder availability and egress behavior remain explicit acceptance requirements.

#### Independent task

Environment: analytical

Produce a fire-system interface and acceptance review using the synthetic records.

**Packaged starter material**

- course_labs/CDCS/README.md
- course_labs/CDCS/fixture.json
- course_labs/CDCS/assessment_template.md
- course_labs/CDCS/lab.py
- course_labs/CDCS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- Detection/notification stage trace
- Clearly labeled illustrative quantity/retention calculations
- Water-system sequence and evidence gaps
- Cause-and-effect/impairment/restoration matrix

**Acceptance criteria**

- No training factor is used as a real agent design value.
- Fire alarm, trouble, command and feedback remain distinct.
- Live testing, impairment, release settings and re-entry decisions retain competent site authority.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer.

#### Chapter practice

**CDCS-Q0371 · single · mechanism**

What does the passed electronics self-test establish?

Synthetic training case — not a field record.

A synthetic aspirating-system electronics self-test passes. During an authorized recorded test at sampling point P7, no detector response occurs within the project’s supplied 60-second criterion. A disconnected sampling branch is later found. A separate panel-injected alarm reaches DCIM in two seconds. DCIM maps both fire alarm and detector trouble to one generic red icon.

1. That every alarm recipient is current
2. The function covered by that internal test
3. Correct room enclosure hold time
4. Successful smoke transport from every protected point

**Correct option(s):** 2

- Option 1: Electronics testing does not establish the contact list.
- Option 2: It does not prove the full sampling network.
- Option 3: That is a separate suppression property.
- Option 4: P7 failed its path test.

**CDCS-Q0372 · single · design**

What is the P7 test result against its supplied criterion?

Synthetic training case — not a field record.

A synthetic aspirating-system electronics self-test passes. During an authorized recorded test at sampling point P7, no detector response occurs within the project’s supplied 60-second criterion. A disconnected sampling branch is later found. A separate panel-injected alarm reaches DCIM in two seconds. DCIM maps both fire alarm and detector trouble to one generic red icon.

1. It is automatically invalid because aspirating detection cannot be timed
2. It passes because DCIM received a different injected alarm
3. It proves a real fire occurred
4. It fails the 60-second response criterion

**Correct option(s):** 4

- Option 1: Transport and response can be evaluated under an approved method.
- Option 2: That tests another path.
- Option 3: The record is an authorized synthetic training test.
- Option 4: No response occurred within the required interval.

**CDCS-Q0373 · single · mechanism**

What does the disconnected branch affect directly?

Synthetic training case — not a field record.

A synthetic aspirating-system electronics self-test passes. During an authorized recorded test at sampling point P7, no detector response occurs within the project’s supplied 60-second criterion. A disconnected sampling branch is later found. A separate panel-injected alarm reaches DCIM in two seconds. DCIM maps both fire alarm and detector trouble to one generic red icon.

1. The sampling transport path from the affected locations
2. Only the network routing table
3. The required agent cylinder mass automatically
4. Only the detector’s electronic sensitivity setting

**Correct option(s):** 1

- Option 1: Air may not reach the intended detector as designed.
- Option 2: The branch is part of the sampling system.
- Option 3: Detection piping is a different subsystem.
- Option 4: A disconnected path can prevent sample transport regardless of sensitivity.

**CDCS-Q0374 · single · mechanism**

What does the two-second panel-injected notification prove?

Synthetic training case — not a field record.

A synthetic aspirating-system electronics self-test passes. During an authorized recorded test at sampling point P7, no detector response occurs within the project’s supplied 60-second criterion. A disconnected sampling branch is later found. A separate panel-injected alarm reaches DCIM in two seconds. DCIM maps both fire alarm and detector trouble to one generic red icon.

1. That the room can retain agent for its required hold time
2. That all sampling holes have equal flow
3. That the tested panel-to-DCIM notification path responded in two seconds
4. That P7 detected smoke within two seconds

**Correct option(s):** 3

- Option 1: Notification timing does not establish enclosure integrity.
- Option 2: No such test is supplied.
- Option 3: It does not include smoke transport from P7.
- Option 4: The alarm was injected at the panel.

**CDCS-Q0375 · single · mechanism**

Why distinguish detector trouble from fire alarm in DCIM?

Synthetic training case — not a field record.

A synthetic aspirating-system electronics self-test passes. During an authorized recorded test at sampling point P7, no detector response occurs within the project’s supplied 60-second criterion. A disconnected sampling branch is later found. A separate panel-injected alarm reaches DCIM in two seconds. DCIM maps both fire alarm and detector trouble to one generic red icon.

1. Trouble indications never require action
2. Every red icon has identical meaning by definition
3. Fire alarms can be treated as routine device inventory updates
4. They communicate different conditions and required responses

**Correct option(s):** 4

- Option 1: An impairment may need prompt response.
- Option 2: The system semantics differ.
- Option 3: That loses their operational significance.
- Option 4: Impaired detection is not the same as a detected fire.

**CDCS-Q0376 · single · operations**

What should a corrected P7 retest preserve?

Synthetic training case — not a field record.

A synthetic aspirating-system electronics self-test passes. During an authorized recorded test at sampling point P7, no detector response occurs within the project’s supplied 60-second criterion. A disconnected sampling branch is later found. A separate panel-injected alarm reaches DCIM in two seconds. DCIM maps both fire alarm and detector trouble to one generic red icon.

1. Only a visual inspection that the sampling pipe is connected
2. Location, method, timing, system state and observed detector/panel response
3. Only the DCIM server uptime
4. Only the original self-test result

**Correct option(s):** 2

- Option 1: A connected pipe can still have obstruction, leakage or transport performance that requires an end-to-end retest.
- Option 2: The evidence must cover the repaired path.
- Option 3: Server availability does not verify sampling.
- Option 4: That did not cover the defect.

**CDCS-Q0377 · single · mechanism**

Why can airflow changes affect smoke detection?

Synthetic training case — not a field record.

A synthetic aspirating-system electronics self-test passes. During an authorized recorded test at sampling point P7, no detector response occurs within the project’s supplied 60-second criterion. A disconnected sampling branch is later found. A separate panel-injected alarm reaches DCIM in two seconds. DCIM maps both fire alarm and detector trouble to one generic red icon.

1. Higher room fan speed always improves detection equally
2. Detector sensitivity alone fixes every transport defect
3. Smoke always travels straight upward regardless of airflow
4. They can redirect or dilute smoke before it reaches a sensor/sample point

**Correct option(s):** 4

- Option 1: The effect depends on the configuration.
- Option 2: A sensor cannot detect material that does not reach it as required.
- Option 3: Real airflow can alter transport.
- Option 4: Placement and transport depend on the environment.

**CDCS-Q0378 · single · operations**

What is needed before performing a real detection test?

Synthetic training case — not a field record.

A synthetic aspirating-system electronics self-test passes. During an authorized recorded test at sampling point P7, no detector response occurs within the project’s supplied 60-second criterion. A disconnected sampling branch is later found. A separate panel-injected alarm reaches DCIM in two seconds. DCIM maps both fire alarm and detector trouble to one generic red icon.

1. Only a can of any smoke-producing material
2. Only permission to log into DCIM
3. The approved method, authority, impairment controls and restoration plan
4. Only the course completion badge

**Correct option(s):** 3

- Option 1: Unapproved media can be unsafe or unsuitable.
- Option 2: Dashboard access is not fire-test authority.
- Option 3: The exercise does not authorize live system work.
- Option 4: Study is not site authorization.

**CDCS-Q0379 · single · operations**

Which timestamp distinction matters in the evidence?

Synthetic training case — not a field record.

A synthetic aspirating-system electronics self-test passes. During an authorized recorded test at sampling point P7, no detector response occurs within the project’s supplied 60-second criterion. A disconnected sampling branch is later found. A separate panel-injected alarm reaches DCIM in two seconds. DCIM maps both fire alarm and detector trouble to one generic red icon.

1. Only the screenshot export time
2. Only the date the detector was purchased
3. Test initiation, detection, panel processing and receipt times
4. All clocks can be assumed identical without checking

**Correct option(s):** 3

- Option 1: That may not represent any actual event stage.
- Option 2: Purchase date does not measure response.
- Option 3: They identify different stages of the response.
- Option 4: Clock differences can distort elapsed-time conclusions.

**CDCS-Q0380 · single · design**

What should the final acceptance claim say after correction?

Synthetic training case — not a field record.

A synthetic aspirating-system electronics self-test passes. During an authorized recorded test at sampling point P7, no detector response occurs within the project’s supplied 60-second criterion. A disconnected sampling branch is later found. A separate panel-injected alarm reaches DCIM in two seconds. DCIM maps both fire alarm and detector trouble to one generic red icon.

1. Every fire-protection function is now certified
2. The initial failure should be deleted
3. No future sampling maintenance is needed
4. Only the paths and conditions actually retested and passed

**Correct option(s):** 4

- Option 1: A sampling repair does not test all suppression or life-safety functions.
- Option 2: Failure/correction history supports traceability.
- Option 3: A successful test does not remove ongoing obligations.
- Option 4: Scope should match the evidence.

**CDCS-Q0381 · single · calculation**

What is the gross protected volume in the supplied model?

Synthetic training case — not a field record.

Synthetic arithmetic only: floor area 80 m²; protected heights 3 m room +0.5 m floor void +0.4 m ceiling void; approved model deduction 12 m³. Illustrative loading factor 0.65 kg/m³ is not a real agent requirement. Five units each contain usable 40 kg, but one is isolated. Separate model C(t)=8e^(−kt) percent uses k=0.02/min and criterion C(10)≥6%; a changed leakage state has k=0.04/min.

1. 92 m³
2. 240 m³
3. 300 m³
4. 312 m³

**Correct option(s):** 4

- Option 1: That adds area and deduction with incompatible dimensions.
- Option 2: That counts only the main room.
- Option 3: That is after the supplied deduction.
- Option 4: 80×(3+0.5+0.4).

**CDCS-Q0382 · single · calculation**

What is the net modeled volume?

Synthetic training case — not a field record.

Synthetic arithmetic only: floor area 80 m²; protected heights 3 m room +0.5 m floor void +0.4 m ceiling void; approved model deduction 12 m³. Illustrative loading factor 0.65 kg/m³ is not a real agent requirement. Five units each contain usable 40 kg, but one is isolated. Separate model C(t)=8e^(−kt) percent uses k=0.02/min and criterion C(10)≥6%; a changed leakage state has k=0.04/min.

1. 228 m³
2. 324 m³
3. 300 m³
4. 312 m³

**Correct option(s):** 3

- Option 1: That omits both protected voids before deduction.
- Option 2: That adds rather than subtracts the deduction.
- Option 3: 312 minus the approved 12 m³ deduction.
- Option 4: That ignores the supplied deduction.

**CDCS-Q0383 · single · calculation**

What mass follows from the illustrative loading factor?

Synthetic training case — not a field record.

Synthetic arithmetic only: floor area 80 m²; protected heights 3 m room +0.5 m floor void +0.4 m ceiling void; approved model deduction 12 m³. Illustrative loading factor 0.65 kg/m³ is not a real agent requirement. Five units each contain usable 40 kg, but one is isolated. Separate model C(t)=8e^(−kt) percent uses k=0.02/min and criterion C(10)≥6%; a changed leakage state has k=0.04/min.

1. 461.54 kg
2. 202.8 kg
3. 0.65 kg
4. 195 kg

**Correct option(s):** 4

- Option 1: That divides volume by the factor.
- Option 2: That uses gross volume before the approved deduction.
- Option 3: That treats a per-volume factor as total mass.
- Option 4: 300×0.65.

**CDCS-Q0384 · single · calculation**

What usable quantity is presently available with one unit isolated?

Synthetic training case — not a field record.

Synthetic arithmetic only: floor area 80 m²; protected heights 3 m room +0.5 m floor void +0.4 m ceiling void; approved model deduction 12 m³. Illustrative loading factor 0.65 kg/m³ is not a real agent requirement. Five units each contain usable 40 kg, but one is isolated. Separate model C(t)=8e^(−kt) percent uses k=0.02/min and criterion C(10)≥6%; a changed leakage state has k=0.04/min.

1. 40 kg
2. 160 kg
3. 200 kg
4. 195 kg

**Correct option(s):** 2

- Option 1: That counts only one unit.
- Option 2: Four connected available units times 40 kg.
- Option 3: That counts the isolated unit as available.
- Option 4: That is the requirement, not measured available inventory.

**CDCS-Q0385 · single · calculation**

What is the quantity gap against this model?

Synthetic training case — not a field record.

Synthetic arithmetic only: floor area 80 m²; protected heights 3 m room +0.5 m floor void +0.4 m ceiling void; approved model deduction 12 m³. Illustrative loading factor 0.65 kg/m³ is not a real agent requirement. Five units each contain usable 40 kg, but one is isolated. Separate model C(t)=8e^(−kt) percent uses k=0.02/min and criterion C(10)≥6%; a changed leakage state has k=0.04/min.

1. Zero
2. 40 kg
3. 5 kg
4. 35 kg

**Correct option(s):** 4

- Option 1: Available quantity is below the model requirement.
- Option 2: That is one unit’s content, not the exact gap.
- Option 3: That compares the requirement with all five units, including the isolated one.
- Option 4: 195 required minus 160 available.

**CDCS-Q0386 · single · calculation**

What is C(10) for k=0.02/min?

Synthetic training case — not a field record.

Synthetic arithmetic only: floor area 80 m²; protected heights 3 m room +0.5 m floor void +0.4 m ceiling void; approved model deduction 12 m³. Illustrative loading factor 0.65 kg/m³ is not a real agent requirement. Five units each contain usable 40 kg, but one is isolated. Separate model C(t)=8e^(−kt) percent uses k=0.02/min and criterion C(10)≥6%; a changed leakage state has k=0.04/min.

1. 8%
2. 1.6%
3. Approximately 6.55%
4. 5.36%

**Correct option(s):** 3

- Option 1: That ignores modeled loss over time.
- Option 2: That multiplies initial concentration by the exponent magnitude rather than exponentiating.
- Option 3: 8e^(−0.2).
- Option 4: That is the changed k=0.04/min result.

**CDCS-Q0387 · single · design**

Does the changed k=0.04/min model meet the synthetic ten-minute criterion?

Synthetic training case — not a field record.

Synthetic arithmetic only: floor area 80 m²; protected heights 3 m room +0.5 m floor void +0.4 m ceiling void; approved model deduction 12 m³. Illustrative loading factor 0.65 kg/m³ is not a real agent requirement. Five units each contain usable 40 kg, but one is isolated. Separate model C(t)=8e^(−kt) percent uses k=0.02/min and criterion C(10)≥6%; a changed leakage state has k=0.04/min.

1. No conclusion can be calculated from an exponential model
2. No; approximately 5.36% is below 6%
3. Yes; cylinder count alone proves retention
4. Yes; initial concentration is 8%

**Correct option(s):** 2

- Option 1: The supplied arithmetic supports this bounded model comparison.
- Option 2: The increased loss coefficient lowers retention.
- Option 3: Quantity and leakage are distinct properties.
- Option 4: The criterion applies at ten minutes.

**CDCS-Q0388 · single · mechanism**

What distinguishes discharge time from hold time?

Synthetic training case — not a field record.

Synthetic arithmetic only: floor area 80 m²; protected heights 3 m room +0.5 m floor void +0.4 m ceiling void; approved model deduction 12 m³. Illustrative loading factor 0.65 kg/m³ is not a real agent requirement. Five units each contain usable 40 kg, but one is isolated. Separate model C(t)=8e^(−kt) percent uses k=0.02/min and criterion C(10)≥6%; a changed leakage state has k=0.04/min.

1. Hold time means only how long an alarm is acknowledged
2. Delivery timing and maintaining the required condition afterward are different outcomes
3. Discharge time is the cylinder’s manufacturing age
4. They are always the same number

**Correct option(s):** 2

- Option 1: That is not the suppression-retention meaning.
- Option 2: Each needs its own acceptance evidence.
- Option 3: It concerns agent delivery.
- Option 4: Their purposes and criteria differ.

**CDCS-Q0389 · single · mechanism**

Why cannot 0.65 kg/m³ be used to design a real agent system?

Synthetic training case — not a field record.

Synthetic arithmetic only: floor area 80 m²; protected heights 3 m room +0.5 m floor void +0.4 m ceiling void; approved model deduction 12 m³. Illustrative loading factor 0.65 kg/m³ is not a real agent requirement. Five units each contain usable 40 kg, but one is isolated. Separate model C(t)=8e^(−kt) percent uses k=0.02/min and criterion C(10)≥6%; a changed leakage state has k=0.04/min.

1. The factor becomes official after passing the quiz
2. Any factor in kg/m³ is universally valid for every agent
3. It is explicitly an illustrative training factor with no real-agent basis
4. Volume never matters to gas systems

**Correct option(s):** 3

- Option 1: Assessment does not confer normative status.
- Option 2: Agents and design conditions differ.
- Option 3: Actual sizing requires the selected approved method and conditions.
- Option 4: Protected volume can be a key input.

**CDCS-Q0390 · single · design**

What additional evidence is required for actual system acceptance?

Synthetic training case — not a field record.

Synthetic arithmetic only: floor area 80 m²; protected heights 3 m room +0.5 m floor void +0.4 m ceiling void; approved model deduction 12 m³. Illustrative loading factor 0.65 kg/m³ is not a real agent requirement. Five units each contain usable 40 kg, but one is isolated. Separate model C(t)=8e^(−kt) percent uses k=0.02/min and criterion C(10)≥6%; a changed leakage state has k=0.04/min.

1. Only confirmation that the cylinder count matches the schedule
2. Applicable agent design, distribution, enclosure, occupancy and release/response verification
3. Only the larger of the two computed percentages
4. Only a room-temperature reading

**Correct option(s):** 2

- Option 1: Quantity alone does not establish agent distribution, enclosure performance, release logic or occupancy provisions.
- Option 2: The simple quantity and decay models omit these functions.
- Option 3: Selecting a favorable result does not validate the installation.
- Option 4: One environmental value does not establish the complete design.

**CDCS-Q0391 · single · mechanism**

What does confirmed detection initiate in this supplied narrative?

Synthetic training case — not a field record.

A supplied preaction design narrative states that a confirmed detection condition admits water to the piping; water discharges at a closed sprinkler only when its heat-responsive element operates. A recorded test proves valve admission but does not operate a sprinkler or measure end-point delivery time. The supervisory air-pressure signal is mapped as a fire alarm. A water-mist substitute is proposed without application approval evidence.

1. Automatic opening of every closed sprinkler
2. Water admission to the piping
3. A permanent bypass of the fire panel
4. Guaranteed gas-agent release

**Correct option(s):** 2

- Option 1: The narrative requires each heat-responsive element to operate.
- Option 2: That is the explicitly defined first action.
- Option 3: No such action is specified.
- Option 4: This is a water-based sequence.

**CDCS-Q0392 · single · operations**

What additional event permits discharge from the stated closed sprinkler?

Synthetic training case — not a field record.

A supplied preaction design narrative states that a confirmed detection condition admits water to the piping; water discharges at a closed sprinkler only when its heat-responsive element operates. A recorded test proves valve admission but does not operate a sprinkler or measure end-point delivery time. The supervisory air-pressure signal is mapped as a fire alarm. A water-mist substitute is proposed without application approval evidence.

1. Operation of its heat-responsive element
2. The expiry of the maintenance contract
3. Any DCIM user acknowledging the alarm
4. A network ping to the valve controller

**Correct option(s):** 1

- Option 1: Water in the pipe alone does not open the closed sprinkler.
- Option 2: That is not a fire-response event.
- Option 3: Acknowledgement is not the stated physical release mechanism.
- Option 4: Reachability does not operate the element.

**CDCS-Q0393 · single · mechanism**

What does the valve-admission test establish?

Synthetic training case — not a field record.

A supplied preaction design narrative states that a confirmed detection condition admits water to the piping; water discharges at a closed sprinkler only when its heat-responsive element operates. A recorded test proves valve admission but does not operate a sprinkler or measure end-point delivery time. The supervisory air-pressure signal is mapped as a fire alarm. A water-mist substitute is proposed without application approval evidence.

1. That all pipes are free from obstruction
2. Complete suppression performance at every sprinkler
3. That the alternative mist system is approved
4. The tested admission function under its recorded conditions

**Correct option(s):** 4

- Option 1: Admission alone does not establish every downstream path.
- Option 2: Those functions were not tested.
- Option 3: A different system needs separate evidence.
- Option 4: It does not prove end-point discharge or delivery time.

**CDCS-Q0394 · single · mechanism**

Why assess end-point delivery time?

Synthetic training case — not a field record.

A supplied preaction design narrative states that a confirmed detection condition admits water to the piping; water discharges at a closed sprinkler only when its heat-responsive element operates. A recorded test proves valve admission but does not operate a sprinkler or measure end-point delivery time. The supervisory air-pressure signal is mapped as a fire alarm. A water-mist substitute is proposed without application approval evidence.

1. The complete piping and release sequence can delay water reaching the required point
2. Water always reaches every endpoint instantaneously
3. Timing is relevant only to network protocols
4. A full tank makes pipe condition irrelevant

**Correct option(s):** 1

- Option 1: Response depends on more than the valve command.
- Option 2: Transport and system state matter.
- Option 3: Physical suppression has timing requirements too.
- Option 4: Supply quantity does not prove delivery.

**CDCS-Q0395 · single · mechanism**

Why should low supervisory air pressure not be mislabeled as confirmed fire?

Synthetic training case — not a field record.

A supplied preaction design narrative states that a confirmed detection condition admits water to the piping; water discharges at a closed sprinkler only when its heat-responsive element operates. A recorded test proves valve admission but does not operate a sprinkler or measure end-point delivery time. The supervisory air-pressure signal is mapped as a fire alarm. A water-mist substitute is proposed without application approval evidence.

1. Every pressure change proves combustion
2. Changing the label physically repairs the leak
3. It indicates a different system condition in the accepted semantics
4. Supervisory signals can always be ignored

**Correct option(s):** 3

- Option 1: Pressure can change for other reasons.
- Option 2: Display semantics do not fix the underlying condition.
- Option 3: Impairment/supervision and fire response must remain distinguishable.
- Option 4: They may reveal impaired readiness.

**CDCS-Q0396 · single · operations**

What should a water-mist substitution establish?

Synthetic training case — not a field record.

A supplied preaction design narrative states that a confirmed detection condition admits water to the piping; water discharges at a closed sprinkler only when its heat-responsive element operates. A recorded test proves valve admission but does not operate a sprinkler or measure end-point delivery time. The supervisory air-pressure signal is mapped as a fire alarm. A water-mist substitute is proposed without application approval evidence.

1. Only a smaller droplet marketing claim
2. Only that both systems use water
3. Only lower pipe diameter
4. Approval/support for the actual hazard, enclosure and installation conditions

**Correct option(s):** 4

- Option 1: That is not the complete approved design.
- Option 2: Shared agent material does not make system behavior equivalent.
- Option 3: Pipe size alone does not establish suppression capability.
- Option 4: Technology names do not prove equivalent application performance.

**CDCS-Q0397 · single · mechanism**

Why is water-based protection not automatically ruled out by IT equipment?

Synthetic training case — not a field record.

A supplied preaction design narrative states that a confirmed detection condition admits water to the piping; water discharges at a closed sprinkler only when its heat-responsive element operates. A recorded test proves valve admission but does not operate a sprinkler or measure end-point delivery time. The supervisory air-pressure signal is mapped as a fire alarm. A water-mist substitute is proposed without application approval evidence.

1. The accepted fire strategy balances the hazard and system performance under applicable requirements
2. Every water system has identical accidental-discharge behavior
3. A gas system always removes every need for other protection
4. Water can never damage equipment

**Correct option(s):** 1

- Option 1: Data centres can use suitable water-based designs.
- Option 2: Architectures and conditions differ.
- Option 3: The complete strategy depends on applicable requirements.
- Option 4: Damage considerations remain real.

**CDCS-Q0398 · single · design**

What dependency should a valve actuation review include?

Synthetic training case — not a field record.

A supplied preaction design narrative states that a confirmed detection condition admits water to the piping; water discharges at a closed sprinkler only when its heat-responsive element operates. A recorded test proves valve admission but does not operate a sprinkler or measure end-point delivery time. The supervisory air-pressure signal is mapped as a fire alarm. A water-mist substitute is proposed without application approval evidence.

1. Only a normal panel light
2. Power, control, sensing, water supply and required supervision
3. Only the management IP address
4. Only the number of ceiling tiles

**Correct option(s):** 2

- Option 1: Readiness indications need their defined evidence.
- Option 2: The command must result in the intended physical function.
- Option 3: Transport is one possible interface, not the whole mechanism.
- Option 4: That does not establish valve operation.

**CDCS-Q0399 · single · operations**

What should happen before a real impairment for testing?

Synthetic training case — not a field record.

A supplied preaction design narrative states that a confirmed detection condition admits water to the piping; water discharges at a closed sprinkler only when its heat-responsive element operates. A recorded test proves valve admission but does not operate a sprinkler or measure end-point delivery time. The supervisory air-pressure signal is mapped as a fire alarm. A water-mist substitute is proposed without application approval evidence.

1. Disable the system whenever the test team arrives
2. Authorize scope, compensating measures, notifications and restoration under the site process
3. Assume no protection is needed because IT is idle
4. Keep the impairment hidden to avoid operational concern

**Correct option(s):** 2

- Option 1: Presence alone is not authority.
- Option 2: The course does not authorize live impairment.
- Option 3: Fire/life-safety duties remain.
- Option 4: Relevant parties need the approved status.

**CDCS-Q0400 · single · design**

What is a defensible acceptance gap statement?

Synthetic training case — not a field record.

A supplied preaction design narrative states that a confirmed detection condition admits water to the piping; water discharges at a closed sprinkler only when its heat-responsive element operates. A recorded test proves valve admission but does not operate a sprinkler or measure end-point delivery time. The supervisory air-pressure signal is mapped as a fire alarm. A water-mist substitute is proposed without application approval evidence.

1. The design necessarily failed every code
2. Admission passed; end-point delivery, semantic mapping and substitute approval remain open
3. The complete system passed because the valve moved
4. The substitute can be installed first and assessed after an incident

**Correct option(s):** 2

- Option 1: No such full compliance assessment is supplied.
- Option 2: It separates demonstrated and unproven outcomes.
- Option 3: That overextends the test.
- Option 4: Application suitability belongs before acceptance.

**CDCS-Q0401 · single · mechanism**

What does command sent prove about the damper?

Synthetic training case — not a field record.

A synthetic cause-and-effect matrix requires a fire-panel output to command a damper closed and receive separate closed-position feedback. The BMS logs command sent but no feedback. DCIM receives a release-command event, with no discharge feedback. A temporary impairment expires at 18:00; at 18:20 the panel is reset but one cylinder remains isolated. A security change would lock an emergency exit on fire alarm.

1. That every airflow path is sealed
2. That the damper is physically closed
3. The command stage was issued or recorded as sent
4. That the actuator needs no maintenance

**Correct option(s):** 3

- Option 1: One command does not establish enclosure integrity.
- Option 2: Feedback is absent.
- Option 3: It does not prove closed position.
- Option 4: Command logging does not prove mechanical condition.

**CDCS-Q0402 · single · operations**

What should verify the required damper position?

Synthetic training case — not a field record.

A synthetic cause-and-effect matrix requires a fire-panel output to command a damper closed and receive separate closed-position feedback. The BMS logs command sent but no feedback. DCIM receives a release-command event, with no discharge feedback. A temporary impairment expires at 18:00; at 18:20 the panel is reset but one cylinder remains isolated. A security change would lock an emergency exit on fire alarm.

1. The specified independent position feedback and accepted test evidence
2. Only a closed icon drawn manually
3. A copy of the command value
4. Only the BMS page refresh time

**Correct option(s):** 1

- Option 1: The matrix requires a separate observation.
- Option 2: A graphic does not establish the state.
- Option 3: Repeating the request is not feedback.
- Option 4: Display activity does not show physical position.

**CDCS-Q0403 · single · mechanism**

What does the release-command event establish?

Synthetic training case — not a field record.

A synthetic cause-and-effect matrix requires a fire-panel output to command a damper closed and receive separate closed-position feedback. The BMS logs command sent but no feedback. DCIM receives a release-command event, with no discharge feedback. A temporary impairment expires at 18:00; at 18:20 the panel is reset but one cylinder remains isolated. A security change would lock an emergency exit on fire alarm.

1. That the release command event reached DCIM
2. That the room met hold time
3. That occupants have been cleared for re-entry
4. That every nozzle delivered the required agent quantity

**Correct option(s):** 1

- Option 1: It does not prove actual agent discharge.
- Option 2: Retention is another outcome.
- Option 3: That requires the designated safety authority.
- Option 4: No discharge feedback or distribution test is supplied.

**CDCS-Q0404 · single · recovery**

Why is panel reset insufficient for restoration at 18:20?

Synthetic training case — not a field record.

A synthetic cause-and-effect matrix requires a fire-panel output to command a damper closed and receive separate closed-position feedback. The BMS logs command sent but no feedback. DCIM receives a release-command event, with no discharge feedback. A temporary impairment expires at 18:00; at 18:20 the panel is reset but one cylinder remains isolated. A security change would lock an emergency exit on fire alarm.

1. Every reset automatically refills cylinders
2. Reset can never be part of restoration
3. The original expiry silently renews when reset occurs
4. A cylinder remains isolated and the impairment has expired

**Correct option(s):** 4

- Option 1: It does not create or reconnect agent resources.
- Option 2: It can be one step in the approved process.
- Option 3: A technical action does not extend authority.
- Option 4: The full protected state is not restored by clearing indications.

**CDCS-Q0405 · single · operations**

What should happen if the impairment must continue?

Synthetic training case — not a field record.

A synthetic cause-and-effect matrix requires a fire-panel output to command a damper closed and receive separate closed-position feedback. The BMS logs command sent but no feedback. DCIM receives a release-command event, with no discharge feedback. A temporary impairment expires at 18:00; at 18:20 the panel is reset but one cylinder remains isolated. A security change would lock an emergency exit on fire alarm.

1. Assume the contractor can authorize every extension
2. Change the old expiry timestamp without history
3. Leave it unreported because no fire has occurred
4. Obtain reassessment and authorization with required controls/notifications

**Correct option(s):** 4

- Option 1: Authority must follow the site process.
- Option 2: That falsifies the decision record.
- Option 3: Absence of an event does not restore protection.
- Option 4: The expired condition cannot be silently prolonged.

**CDCS-Q0406 · single · mechanism**

Why is the proposed emergency-exit lock change a concern?

Synthetic training case — not a field record.

A synthetic cause-and-effect matrix requires a fire-panel output to command a damper closed and receive separate closed-position feedback. The BMS logs command sent but no feedback. DCIM receives a release-command event, with no discharge feedback. A temporary impairment expires at 18:00; at 18:20 the panel is reset but one cylinder remains isolated. A security change would lock an emergency exit on fire alarm.

1. Fire alarms automatically cancel all egress duties
2. All access controls must always be removed
3. The BMS programmer can decide solely from convenience
4. It may defeat required egress during the event

**Correct option(s):** 4

- Option 1: They make correct egress behavior especially relevant.
- Option 2: Suitable systems can preserve both requirements.
- Option 3: This exceeds an informal integration choice.
- Option 4: Security and life-safety behavior need coordinated specialist approval.

**CDCS-Q0407 · single · operations**

What should communication loss from the fire panel produce?

Synthetic training case — not a field record.

A synthetic cause-and-effect matrix requires a fire-panel output to command a damper closed and receive separate closed-position feedback. The BMS logs command sent but no feedback. DCIM receives a release-command event, with no discharge feedback. A temporary impairment expires at 18:00; at 18:20 the panel is reset but one cylinder remains isolated. A security change would lock an emergency exit on fire alarm.

1. A permanent normal indication to avoid nuisance alarms
2. An automatic claim that a fire exists
3. Deletion of the panel from the asset register
4. The specified trouble/quality behavior rather than an invented normal state

**Correct option(s):** 4

- Option 1: That hides impaired visibility.
- Option 2: Loss of communication is not identical to detected fire.
- Option 3: That does not resolve the interface.
- Option 4: The consumer must know when evidence is unavailable.

**CDCS-Q0408 · single · operations**

What is the correct role of a general-purpose BMS in this case?

Synthetic training case — not a field record.

A synthetic cause-and-effect matrix requires a fire-panel output to command a damper closed and receive separate closed-position feedback. The BMS logs command sent but no feedback. DCIM receives a release-command event, with no discharge feedback. A temporary impairment expires at 18:00; at 18:20 the panel is reset but one cylinder remains isolated. A security change would lock an emergency exit on fire alarm.

1. Integrate the approved indications and interfaces within its assigned scope
2. Suppress all trouble events because the fire panel is separate
3. Reimplement release logic independently without approval
4. Choose a new universal release delay

**Correct option(s):** 1

- Option 1: It does not automatically replace the dedicated fire-panel function.
- Option 2: Operations may need those indications.
- Option 3: That changes the protective architecture.
- Option 4: Actual requirements and authority govern timing.

**CDCS-Q0409 · single · design**

What should maintenance review after new cable penetrations?

Synthetic training case — not a field record.

A synthetic cause-and-effect matrix requires a fire-panel output to command a damper closed and receive separate closed-position feedback. The BMS logs command sent but no feedback. DCIM receives a release-command event, with no discharge feedback. A temporary impairment expires at 18:00; at 18:20 the panel is reset but one cylinder remains isolated. A security change would lock an emergency exit on fire alarm.

1. Nothing because fire design ends at construction
2. Only the original room test date
3. Only whether the new cable passes its data test
4. Whether the accepted enclosure/barrier and detection/suppression assumptions remain valid

**Correct option(s):** 4

- Option 1: The lifecycle requires maintaining the accepted state.
- Option 2: A later change can invalidate earlier conditions.
- Option 3: Transmission performance does not verify the fire barrier or enclosure leakage.
- Option 4: Physical changes can alter protective performance.

**CDCS-Q0410 · single · recovery**

What should the final restoration record contain?

Synthetic training case — not a field record.

A synthetic cause-and-effect matrix requires a fire-panel output to command a damper closed and receive separate closed-position feedback. The BMS logs command sent but no feedback. DCIM receives a release-command event, with no discharge feedback. A temporary impairment expires at 18:00; at 18:20 the panel is reset but one cylinder remains isolated. A security change would lock an emergency exit on fire alarm.

1. Only a new work-order number
2. Reconnected/replenished resources, verified functions, cleared restrictions and authority
3. Only a screenshot with no alarms
4. Only the contractor’s departure time

**Correct option(s):** 2

- Option 1: Administrative identity is not functional evidence.
- Option 2: Readiness requires the complete accepted condition.
- Option 3: A quiet display can conceal isolated equipment.
- Option 4: Departure does not prove restoration.

#### Recall

**An aspirating detector passes electronics but misses a sampling point — Synthetic training case — not a field record.

A synthetic aspirating-system electronics self-test passes. During an authorized recorded test at sampling point P7, no detector response occurs within the project’s supplied 60-second criterion. A disconnected sampling branch is later found. A separate panel-injected alarm reaches DCIM in two seconds. DCIM maps both fire alarm and detector trouble to one generic red icon.**

The electronics test and panel notification do not establish smoke transport from P7. The disconnected branch explains a concrete path defect needing correction and retest. Preserve fire versus trouble semantics so operators know whether a fire condition or impaired detection is reported.

**Protected volume and a modeled retention condition — Synthetic training case — not a field record.

Synthetic arithmetic only: floor area 80 m²; protected heights 3 m room +0.5 m floor void +0.4 m ceiling void; approved model deduction 12 m³. Illustrative loading factor 0.65 kg/m³ is not a real agent requirement. Five units each contain usable 40 kg, but one is isolated. Separate model C(t)=8e^(−kt) percent uses k=0.02/min and criterion C(10)≥6%; a changed leakage state has k=0.04/min.**

Net modeled volume is 300 m³ and quantity 195 kg. Four available units supply 160 kg, 35 kg short. Original retention predicts 6.55% at ten minutes, while changed leakage predicts 5.36%. These models do not establish actual agent concentration, hydraulics, safety or enclosure acceptance.

**Water admission is not necessarily sprinkler discharge — Synthetic training case — not a field record.

A supplied preaction design narrative states that a confirmed detection condition admits water to the piping; water discharges at a closed sprinkler only when its heat-responsive element operates. A recorded test proves valve admission but does not operate a sprinkler or measure end-point delivery time. The supervisory air-pressure signal is mapped as a fire alarm. A water-mist substitute is proposed without application approval evidence.**

Interpret the actual supplied sequence: admission fills the piping but does not prove discharge through a still-closed sprinkler. End-point delivery and supervisory semantics remain to verify. A different water-based technology requires its own supported hazard/application design rather than automatic substitution.

**Fire cause-and-effect and restoration after impairment — Synthetic training case — not a field record.

A synthetic cause-and-effect matrix requires a fire-panel output to command a damper closed and receive separate closed-position feedback. The BMS logs command sent but no feedback. DCIM receives a release-command event, with no discharge feedback. A temporary impairment expires at 18:00; at 18:20 the panel is reset but one cylinder remains isolated. A security change would lock an emergency exit on fire alarm.**

Command, physical feedback and actual discharge are separate evidence. Reset does not restore the isolated resource or renew the impairment. Resolve the life-safety interface with competent authorities; a BMS/DCIM integration must not silently replace the dedicated panel or defeat egress.

#### References

- [EPI CDCS public syllabus](https://www.epi-ap.com/services/1/3/5)
- [NFPA 2001 official standard-development reference; obtain applicable edition](https://www.nfpa.org/codes-and-standards/nfpa-2001-standard-development/2001)
- [NFPA 75 official standard-development reference; obtain applicable edition](https://www.nfpa.org/codes-and-standards/nfpa-75-standard-development/75)

## CDCS-M10 — Scalable copper/fiber pathways and auditable cabling changes

### CDCS-L10 — Scalable copper/fiber pathways and auditable cabling changes

Estimated study time: 120 minutes before independent work. Prerequisite chapters: CDCS-L09

## Cabling architecture is a lifecycle interface

A scalable cabling system defines where services enter, where distribution and cross-connect functions occur, how equipment areas connect and how changes are administered. The CDCS outline references TIA-942 topology; use the actual applicable edition for formal requirements and terminology. Common structured-cabling concepts include entrance facilities, main and horizontal distribution areas, optional zone distribution where appropriate, and equipment distribution. These are functional relationships, not a requirement to install every possible area in every small site. Record the chosen architecture, growth assumptions, distances, media and responsibilities so a later rack move does not depend on guessing hidden patch routes.

Separate physical cabling topology from the logical network. A leaf-spine logical design can use several physical cabling arrangements; a cross-connect does not by itself create a routed or switched function. Physical route diversity is also different from logical redundancy. Two VLANs on one cable share that cable's failure exposure, while two fibers in one sheath share several physical dependencies. The design review should trace endpoints, intermediate connections, route, media, test boundary and service. Labels and DCIM records support the map but must be reconciled with actual installation evidence.

## Compare top-of-rack and end-of-row on complete consequences

Top-of-rack places access switching close to equipment in each rack or group, often reducing server patch lengths but increasing the number of distributed active devices. End-of-row centralizes access switching for a row, which can concentrate management and capacity while requiring longer equipment cable runs and larger cable-management paths. Neither is universally better. Compare endpoint count, port speeds, media distance, oversubscription, growth, power/cooling, failure domains, maintenance access, spare strategy and operating effort. A cable-cost comparison that omits active switches and their support is incomplete.

Port arithmetic must reflect the intended resilience and uplinks. If 12 racks each contain 16 servers and each server connects once to each of two local switches, each local switch needs 16 server ports before uplinks and reserves. With four uplink ports on a 24-port switch, four ports remain. Across the row there are 192 servers. Two end-of-row switches with each server connected once to each require 192 server-facing ports per switch; a 144-port proposal is short by 48 on each, before other uses. The topology and port allocation, not just the total number of boxes, determine suitability.

Bandwidth needs its own model. Port count does not establish uplink capacity or workload performance. A rack full of ports can oversubscribe its uplinks, and failure may further reduce available bandwidth. The network engineering courses teach those protocols and performance mechanisms in depth; this CDCS chapter focuses on physical infrastructure and design interfaces. Coordinate optical type, connector, polarity, distance, rack location and maintenance labeling with the accepted network design rather than selecting cables solely from connector appearance.

## Copper channels need the correct test boundary

A permanent link and a complete channel are different test boundaries. The permanent link covers the installed fixed infrastructure as defined by the applicable method; a channel includes the relevant equipment and patch cords within its definition. A passing permanent-link result does not automatically validate later-added cords or an overlong channel. Use the selected application/category, connector system, temperature and test limits. Training cases provide explicit limits so the learner can calculate without pretending those values describe every copper application.

Copper performance includes insertion loss, return loss, crosstalk, propagation behavior, continuity and other parameters required by the chosen test. A wire map pass is necessary for some faults but is not a complete high-speed certification. Poor termination, excessive untwist, inappropriate components, damaged cable or unsupported patch cords can affect performance. Installation also considers bend radius, pulling force, separation, support, fire properties and bonding where applicable. Manufacturer instructions and the actual standard govern exact values; do not invent a universal bend radius or maximum pulling force for all products.

Power delivery over data cabling adds thermal and current considerations. Bundle size, conductor characteristics, ambient conditions, connectors and supported power class can affect heating and channel performance. A link that carries data successfully at low load has not necessarily demonstrated the required power duty. Conversely, a powered endpoint does not prove the channel meets its data performance class. Review both functions and the complete supported equipment/cabling combination. Preserve the selected test configuration and calibration so a pass can be interpreted later.

## Optical links need power margin and correct physical implementation

An optical link budget compares transmitter capability, passive path loss, receiver sensitivity and any required engineering margin under the supported wavelength and application. In a supplied model, transmitter minimum power −2 dBm and receiver minimum acceptable power −8 dBm provide 6 dB of allowable loss before additional margin. If fiber loss is 0.2 dB, connector-pair loss totals 2 dB and splice loss totals 0.4 dB, modeled path loss is 2.6 dB. Received power is −4.6 dBm, leaving 3.4 dB above the supplied sensitivity. Receiver maximum input also matters; excessive received power can be unacceptable even when sensitivity is met.

Decibels express ratios, while dBm expresses power relative to one milliwatt. Subtract path loss in dB from transmitter power in dBm to estimate received dBm; do not add dBm values as though they were linear milliwatts. A budget calculation is not an installed loss measurement. Actual connectors, contamination, bends, splices and component tolerances can change the result. The transceiver's supported reach, dispersion, fiber type and application constraints must also pass; adequate power alone does not prove every optical specification.

Connector shape does not establish fiber type, polish compatibility, polarity or lane mapping. Inspect and clean using approved methods before mating where required, and verify the complete path. Never look into a fiber or connector to decide whether it is active; use appropriate instruments and procedures. A visual fault locator, optical loss test set and OTDR answer different questions. An OTDR can help locate events along a path, while an insertion-loss test evaluates the defined end-to-end loss with its reference method. Use the tests required by the actual acceptance plan rather than assuming one tool replaces every other measurement.

Polarity matters for duplex and parallel optics. A physically seated connector can still route transmit to transmit or map lanes incorrectly. Label and test according to the selected supported system. Patch changes can alter loss and polarity, so retain both the permanent infrastructure record and the current channel arrangement. Optical cleanliness and inspection evidence should identify the actual connector/path, not a generic photograph from another installation. Keep test wavelength, direction, reference method, instrument and results traceable.

## Installation, bonding and administration preserve the design

Cable pathways need capacity for installed and planned fill while preserving bend radius, supports, access and required separation. Overfilled trays can obstruct cooling, complicate replacement and conceal damage. Abandoned cables should be handled through the site's approved process, including dependency verification and applicable fire/housekeeping requirements; do not remove an unlabeled cable merely because no one remembers its purpose. A physical survey and controlled change are preferable to guessing from a quiet port. Cable removal is also a lifecycle event requiring record updates and service checks.

Bonding and grounding support electrical safety and EMC under the actual design. A functional cable screen is not a substitute for protective earthing. Follow the equipment and cabling system's supported bonding arrangement; a universal instruction to connect or disconnect every shield at one end is inappropriate. Coordinate metallic pathways, racks and building bonding with the competent electrical specialists. Fiber's optical signal path avoids some conductive coupling, but metallic strength members, armor, racks and active endpoint power can still have installation requirements.

Administration should identify both ends, intermediate patch points, route, media, service, ownership and test evidence through stable identifiers. A hostname or IP address can change independently of a physical cable. A label should link to the accepted record rather than encode every mutable fact into an unmaintainable string. DCIM such as Sunbird can map physical relationships; discovery protocols can add observations but do not prove every hidden patch or passive path. Reconcile conflicting records with controlled evidence.

For a change, capture the pre-state, authorized target, affected service, patch sequence, rollback, tests and final record update. A successful ping verifies limited reachability at that time; it does not certify the cabling class, intended redundant route or every workload. Preserve failed tests and corrected retests. Handover includes usable labeling, current diagrams, test results and maintenance access. This course's paper calculations establish design-review literacy, while actual installation and certification require the appropriate tools, competence and external practical evidence.


#### Worked demonstrations

**Top-of-rack versus an undersized end-of-row proposal**

Synthetic training case — not a field record.

Twelve racks contain 16 servers each. Every server requires one connection to each of two access switches. ToR proposal: two 24-port switches per rack, each using 16 server ports and four uplink ports. EoR proposal: two 144-port switches for the row, with every server connected once to each. No breakout or extra line cards are proposed.

**Reasoning:** There are 192 servers. Each ToR switch uses 20 ports and has four spare. Each EoR switch needs 192 server ports and is 48 short before uplinks. Compare physical cable length and active-device operations separately; neither architecture is universally preferred.

**A passing fixed link in an overlong channel**

Synthetic training case — not a field record.

The project’s supplied copper limits are 90 m for the permanent link and 100 m for the complete channel under its selected application. Fixed cabling is 81 m; current patch/equipment cords total 22 m. The permanent-link test passes. A technician runs a wire-map test only after adding cords. The bundle also supplies powered endpoints, but thermal/power-duty review is absent.

**Reasoning:** The fixed 81 m is within its supplied length limit, while the 103 m channel exceeds its 100 m limit by 3 m. A wire map does not certify the complete performance class. Powered-cabling duty adds supported current/thermal considerations; these case limits are not universal for every application.

**Optical budget and receiver range**

Synthetic training case — not a field record.

Synthetic supported-wavelength model: transmitter minimum −2 dBm; receiver sensitivity −8 dBm and maximum accepted input −1 dBm. Fiber length 0.5 km at supplied 0.4 dB/km; four connector pairs at 0.5 dB each; two splices at 0.2 dB each. Required engineering margin is 2 dB. No installed insertion-loss, polarity or dispersion evidence is supplied.

**Reasoning:** Passive loss is 0.2+2+0.4=2.6 dB. Predicted received power is −4.6 dBm, inside the supplied receiver range. Sensitivity margin is 3.4 dB, exceeding the 2 dB requirement by 1.4 dB in the model. Actual loss, polarity and application constraints still need verification.

**A patch change with conflicting physical records**

Synthetic training case — not a field record.

A cable labeled C-17 at rack R1 is labeled C-71 at the distribution panel. DCIM maps it to port 12; a recent work order says port 14. LLDP reports the expected neighboring switch but does not reveal passive patch panels. An unlabeled cable is proposed for removal because no traffic appeared during a five-minute sample. A shield change is suggested without the equipment EMC instructions.

**Reasoning:** Reconcile endpoint and intermediate-path identity using controlled evidence before changing records or removing cables. LLDP and short traffic observations have limited scope. Use the supported bonding/screen design and preserve pre-state, authorization, test and as-built records for the patch change.

#### Guided practice

Compare the ToR/EoR port plans, resolve the copper channel length and optical budget, and reconstruct C-17’s physical record before a patch change.

**Hint:** Physical capacity, transmission performance, logical reachability and record identity are separate checks.

**Worked solution:** There are 192 servers and each EoR switch is 48 server ports short. The copper channel is 103 m against its supplied 100 m criterion despite a passing fixed link. Optical loss is 2.6 dB, received power −4.6 dBm and sensitivity margin 3.4 dB. Reconcile labels and passive paths; LLDP and a short traffic sample cannot authorize removal.

#### Independent task

Environment: analytical

Build a scalable cabling design and change-evidence pack.

**Packaged starter material**

- course_labs/CDCS/README.md
- course_labs/CDCS/fixture.json
- course_labs/CDCS/assessment_template.md
- course_labs/CDCS/lab.py
- course_labs/CDCS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- Topology/port allocation and pathway comparison
- Copper boundary and test plan
- Optical budget with installed-test requirements
- Cable identity/change/rollback register

**Acceptance criteria**

- Calculations use the actual dual-homing and test boundaries.
- Optical budget is not substituted for polarity or installed loss evidence.
- Unknown cables and bonding changes remain controlled by verified design and authority.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer.

#### Chapter practice

**CDCS-Q0411 · single · calculation**

How many servers are in the row?

Synthetic training case — not a field record.

Twelve racks contain 16 servers each. Every server requires one connection to each of two access switches. ToR proposal: two 24-port switches per rack, each using 16 server ports and four uplink ports. EoR proposal: two 144-port switches for the row, with every server connected once to each. No breakout or extra line cards are proposed.

1. 192
2. 28
3. 144
4. 384

**Correct option(s):** 1

- Option 1: 12×16.
- Option 2: That adds racks and servers per rack.
- Option 3: That is an EoR switch port count.
- Option 4: That counts dual connections as separate servers.

**CDCS-Q0412 · single · calculation**

How many ports remain on each proposed ToR switch?

Synthetic training case — not a field record.

Twelve racks contain 16 servers each. Every server requires one connection to each of two access switches. ToR proposal: two 24-port switches per rack, each using 16 server ports and four uplink ports. EoR proposal: two 144-port switches for the row, with every server connected once to each. No breakout or extra line cards are proposed.

1. 4
2. 8
3. 16
4. 0

**Correct option(s):** 1

- Option 1: 24−16−4.
- Option 2: That omits the four uplink ports.
- Option 3: That is the server-facing allocation, not spare count.
- Option 4: The supplied allocation uses only 20 of 24.

**CDCS-Q0413 · single · calculation**

How many server-facing ports does each EoR switch need?

Synthetic training case — not a field record.

Twelve racks contain 16 servers each. Every server requires one connection to each of two access switches. ToR proposal: two 24-port switches per rack, each using 16 server ports and four uplink ports. EoR proposal: two 144-port switches for the row, with every server connected once to each. No breakout or extra line cards are proposed.

1. 384
2. 192
3. 144
4. 96

**Correct option(s):** 2

- Option 1: That counts both switches’ connections on one switch.
- Option 2: Every server connects once to each switch.
- Option 3: That is available capacity, not required endpoints.
- Option 4: That incorrectly splits servers between switches instead of dual-homing each.

**CDCS-Q0414 · single · calculation**

What is the server-port shortfall on each EoR switch?

Synthetic training case — not a field record.

Twelve racks contain 16 servers each. Every server requires one connection to each of two access switches. ToR proposal: two 24-port switches per rack, each using 16 server ports and four uplink ports. EoR proposal: two 144-port switches for the row, with every server connected once to each. No breakout or extra line cards are proposed.

1. 96
2. 48
3. Zero because two switches total 288 ports
4. 24

**Correct option(s):** 2

- Option 1: That doubles the per-switch shortfall.
- Option 2: 192 required minus 144 available.
- Option 3: The dual-homing requirement needs 192 on each.
- Option 4: That halves the actual shortfall without basis.

**CDCS-Q0415 · single · operations**

What is a typical physical benefit of the ToR arrangement to evaluate?

Synthetic training case — not a field record.

Twelve racks contain 16 servers each. Every server requires one connection to each of two access switches. ToR proposal: two 24-port switches per rack, each using 16 server ports and four uplink ports. EoR proposal: two 144-port switches for the row, with every server connected once to each. No breakout or extra line cards are proposed.

1. Automatic elimination of all uplink cabling
2. Shorter server patch runs within each rack
3. No need for rack power or cooling
4. Guaranteed lowest lifecycle cost in every site

**Correct option(s):** 2

- Option 1: ToR switches still need upstream connectivity.
- Option 2: It can reduce those cable distances while adding distributed active devices.
- Option 3: The added switches consume both.
- Option 4: Support and active equipment costs can change the result.

**CDCS-Q0416 · single · operations**

What is a typical EoR trade-off to evaluate?

Synthetic training case — not a field record.

Twelve racks contain 16 servers each. Every server requires one connection to each of two access switches. ToR proposal: two 24-port switches per rack, each using 16 server ports and four uplink ports. EoR proposal: two 144-port switches for the row, with every server connected once to each. No breakout or extra line cards are proposed.

1. Every EoR design has zero failure concentration
2. Centralized switching with longer server cable paths and pathway demands
3. No server cabling is required
4. Port count becomes irrelevant

**Correct option(s):** 2

- Option 1: Centralization can change failure domains.
- Option 2: The physical layout affects distance and management.
- Option 3: Servers still need connections.
- Option 4: The proposal demonstrates a concrete port shortage.

**CDCS-Q0417 · single · mechanism**

What does passing the port count not establish?

Synthetic training case — not a field record.

Twelve racks contain 16 servers each. Every server requires one connection to each of two access switches. ToR proposal: two 24-port switches per rack, each using 16 server ports and four uplink ports. EoR proposal: two 144-port switches for the row, with every server connected once to each. No breakout or extra line cards are proposed.

1. That the proposed EoR allocation is short
2. That a 24-port switch has 24 stated ports
3. Required uplink bandwidth and workload performance
4. That 12 racks each contain 16 servers

**Correct option(s):** 3

- Option 1: The arithmetic establishes the shortfall.
- Option 2: That is an explicit premise.
- Option 3: Physical ports and traffic capacity are separate checks.
- Option 4: That is the supplied population.

**CDCS-Q0418 · single · operations**

How should structured-cabling functional areas be used?

Synthetic training case — not a field record.

Twelve racks contain 16 servers each. Every server requires one connection to each of two access switches. ToR proposal: two 24-port switches per rack, each using 16 server ports and four uplink ports. EoR proposal: two 144-port switches for the row, with every server connected once to each. No breakout or extra line cards are proposed.

1. Ignore them once a logical network diagram exists
2. According to the selected applicable architecture and standard edition
3. Treat a passive cross-connect as an IP router
4. Install every possible area regardless of scale

**Correct option(s):** 2

- Option 1: Logical and physical designs serve different purposes.
- Option 2: Not every optional area is required in every small design.
- Option 3: Physical distribution does not create routing behavior.
- Option 4: That is not a justified universal rule.

**CDCS-Q0419 · single · operations**

What should an equivalent cost comparison include?

Synthetic training case — not a field record.

Twelve racks contain 16 servers each. Every server requires one connection to each of two access switches. ToR proposal: two 24-port switches per rack, each using 16 server ports and four uplink ports. EoR proposal: two 144-port switches for the row, with every server connected once to each. No breakout or extra line cards are proposed.

1. Only the shortest possible cable in either option
2. Only switch chassis count
3. Only patch-cord purchase price
4. Cables, switches, pathways, power/cooling, support and growth effects

**Correct option(s):** 4

- Option 1: The complete installed population matters.
- Option 2: Port capacity and lifecycle duties differ.
- Option 3: That omits active and operating costs.
- Option 4: A cable-only comparison can omit material consequences.

**CDCS-Q0420 · single · operations**

What is the proper EoR proposal disposition?

Synthetic training case — not a field record.

Twelve racks contain 16 servers each. Every server requires one connection to each of two access switches. ToR proposal: two 24-port switches per rack, each using 16 server ports and four uplink ports. EoR proposal: two 144-port switches for the row, with every server connected once to each. No breakout or extra line cards are proposed.

1. Accept by counting each server on only one switch silently
2. Revise supported port capacity or the authorized requirement before acceptance
3. Use undocumented breakout assumptions
4. Declare EoR universally unsuitable

**Correct option(s):** 2

- Option 1: That removes the stated requirement.
- Option 2: The supplied dual-homing allocation does not fit.
- Option 3: The case explicitly proposes none.
- Option 4: A correctly sized design may be appropriate.

**CDCS-Q0421 · single · calculation**

What is the complete channel length?

Synthetic training case — not a field record.

The project’s supplied copper limits are 90 m for the permanent link and 100 m for the complete channel under its selected application. Fixed cabling is 81 m; current patch/equipment cords total 22 m. The permanent-link test passes. A technician runs a wire-map test only after adding cords. The bundle also supplies powered endpoints, but thermal/power-duty review is absent.

1. 22 m
2. 103 m
3. 81 m
4. 59 m

**Correct option(s):** 2

- Option 1: That counts only patch/equipment cords.
- Option 2: 81 fixed plus 22 m cords.
- Option 3: That omits the channel’s cords.
- Option 4: That subtracts cords rather than adding them.

**CDCS-Q0422 · single · operations**

Which supplied length check fails?

Synthetic training case — not a field record.

The project’s supplied copper limits are 90 m for the permanent link and 100 m for the complete channel under its selected application. Fixed cabling is 81 m; current patch/equipment cords total 22 m. The permanent-link test passes. A technician runs a wire-map test only after adding cords. The bundle also supplies powered endpoints, but thermal/power-duty review is absent.

1. Neither because the permanent link passed
2. The permanent link exceeds 90 m
3. Both checks fail
4. The channel exceeds 100 m

**Correct option(s):** 4

- Option 1: The channel is a different boundary.
- Option 2: 81 m does not exceed that limit.
- Option 3: Only the channel length fails.
- Option 4: 103 m is above its stated limit while 81 m is below 90.

**CDCS-Q0423 · single · calculation**

What is the channel’s excess length?

Synthetic training case — not a field record.

The project’s supplied copper limits are 90 m for the permanent link and 100 m for the complete channel under its selected application. Fixed cabling is 81 m; current patch/equipment cords total 22 m. The permanent-link test passes. A technician runs a wire-map test only after adding cords. The bundle also supplies powered endpoints, but thermal/power-duty review is absent.

1. 13 m
2. 22 m
3. 3 m
4. 9 m

**Correct option(s):** 3

- Option 1: That compares channel length with the permanent-link limit.
- Option 2: That is total cord length, not the excess.
- Option 3: 103−100.
- Option 4: That is the permanent link’s remaining margin to 90.

**CDCS-Q0424 · single · mechanism**

Why does the permanent-link pass not certify the current channel?

Synthetic training case — not a field record.

The project’s supplied copper limits are 90 m for the permanent link and 100 m for the complete channel under its selected application. Fixed cabling is 81 m; current patch/equipment cords total 22 m. The permanent-link test passes. A technician runs a wire-map test only after adding cords. The bundle also supplies powered endpoints, but thermal/power-duty review is absent.

1. All patch cords are electrically ideal
2. A channel excludes equipment cords in every method
3. The later cords and complete channel boundary were not covered by that result
4. Permanent-link tests are never useful

**Correct option(s):** 3

- Option 1: Real cords have loss and performance characteristics.
- Option 2: The supplied case explicitly includes them.
- Option 3: Additional components can change performance.
- Option 4: They verify their defined fixed infrastructure.

**CDCS-Q0425 · single · mechanism**

What does a wire-map test primarily address?

Synthetic training case — not a field record.

The project’s supplied copper limits are 90 m for the permanent link and 100 m for the complete channel under its selected application. Fixed cabling is 81 m; current patch/equipment cords total 22 m. The permanent-link test passes. A technician runs a wire-map test only after adding cords. The bundle also supplies powered endpoints, but thermal/power-duty review is absent.

1. Conductor connectivity/pairing faults within its function
2. The endpoint’s application response time
3. The building’s fire rating
4. Complete crosstalk and return-loss compliance automatically

**Correct option(s):** 1

- Option 1: It does not alone certify all high-speed transmission parameters.
- Option 2: That is a different layer.
- Option 3: Wire mapping does not assess building assemblies.
- Option 4: Those require the appropriate performance test.

**CDCS-Q0426 · single · design**

What should the full copper acceptance test match?

Synthetic training case — not a field record.

The project’s supplied copper limits are 90 m for the permanent link and 100 m for the complete channel under its selected application. Fixed cabling is 81 m; current patch/equipment cords total 22 m. The permanent-link test passes. A technician runs a wire-map test only after adding cords. The bundle also supplies powered endpoints, but thermal/power-duty review is absent.

1. Only the category printed on one patch cord
2. Selected application/category, boundary, limits and instrument setup
3. Only a successful low-speed connection
4. Only the tester’s default profile regardless of cable

**Correct option(s):** 2

- Option 1: The entire selected channel and test boundary must satisfy the requirement.
- Option 2: A pass is meaningful only for its configured test.
- Option 3: That does not prove the required higher-performance class.
- Option 4: Defaults may not match the requirement.

**CDCS-Q0427 · single · operations**

What additional concern comes from powered endpoints in a bundle?

Synthetic training case — not a field record.

The project’s supplied copper limits are 90 m for the permanent link and 100 m for the complete channel under its selected application. Fixed cabling is 81 m; current patch/equipment cords total 22 m. The permanent-link test passes. A technician runs a wire-map test only after adding cords. The bundle also supplies powered endpoints, but thermal/power-duty review is absent.

1. Data success automatically proves every power duty
2. An idle endpoint power measurement proves the bundle’s maximum duty
3. Supported current, thermal conditions, connectors and channel performance
4. Power delivery removes all temperature dependence

**Correct option(s):** 3

- Option 1: The functions have separate constraints.
- Option 2: The required simultaneous load and thermal conditions may be higher.
- Option 3: Power delivery can affect installation suitability.
- Option 4: Heating can matter.

**CDCS-Q0428 · single · mechanism**

Why not use a universal bend radius from memory for every cable?

Synthetic training case — not a field record.

The project’s supplied copper limits are 90 m for the permanent link and 100 m for the complete channel under its selected application. Fixed cabling is 81 m; current patch/equipment cords total 22 m. The permanent-link test passes. A technician runs a wire-map test only after adding cords. The bundle also supplies powered endpoints, but thermal/power-duty review is absent.

1. Bend radius never affects cabling
2. Only fiber has any mechanical limits
3. A larger rack always permits any bend
4. Product and installation conditions differ

**Correct option(s):** 4

- Option 1: Excessive bending can damage or degrade it.
- Option 2: Copper systems also have installation constraints.
- Option 3: Local routing still matters.
- Option 4: The actual supported instructions and requirements govern.

**CDCS-Q0429 · single · operations**

What is a defensible corrective action for the length issue?

Synthetic training case — not a field record.

The project’s supplied copper limits are 90 m for the permanent link and 100 m for the complete channel under its selected application. Fixed cabling is 81 m; current patch/equipment cords total 22 m. The permanent-link test passes. A technician runs a wire-map test only after adding cords. The bundle also supplies powered endpoints, but thermal/power-duty review is absent.

1. Redesign the supported channel/route and retest the actual required boundary
2. Reuse the permanent-link certificate as a channel certificate
3. Ignore the extra length because ping succeeds
4. Relabel 103 m as 100 m

**Correct option(s):** 1

- Option 1: The installed configuration must meet its criteria.
- Option 2: That misstates test scope.
- Option 3: Reachability does not waive the specified limit.
- Option 4: Changing a record does not shorten the path.

**CDCS-Q0430 · single · implementation**

What should the final test record retain?

Synthetic training case — not a field record.

The project’s supplied copper limits are 90 m for the permanent link and 100 m for the complete channel under its selected application. Fixed cabling is 81 m; current patch/equipment cords total 22 m. The permanent-link test passes. A technician runs a wire-map test only after adding cords. The bundle also supplies powered endpoints, but thermal/power-duty review is absent.

1. Only the original fixed-cable purchase order
2. Cable identity, boundary, profile, instrument/calibration, result and actual cord arrangement
3. Only the technician’s memory
4. Only a pass word with no link ID

**Correct option(s):** 2

- Option 1: Procurement does not describe the accepted channel.
- Option 2: These make later interpretation possible.
- Option 3: A durable record is needed.
- Option 4: It cannot be reliably tied to the installed channel.

**CDCS-Q0431 · single · calculation**

What is the fiber-only loss?

Synthetic training case — not a field record.

Synthetic supported-wavelength model: transmitter minimum −2 dBm; receiver sensitivity −8 dBm and maximum accepted input −1 dBm. Fiber length 0.5 km at supplied 0.4 dB/km; four connector pairs at 0.5 dB each; two splices at 0.2 dB each. Required engineering margin is 2 dB. No installed insertion-loss, polarity or dispersion evidence is supplied.

1. 2 dB
2. 0.4 dB
3. 0.2 dB
4. 0.8 dB

**Correct option(s):** 3

- Option 1: That is the connector total.
- Option 2: That assumes one kilometre.
- Option 3: 0.5 km×0.4 dB/km.
- Option 4: That divides attenuation by length.

**CDCS-Q0432 · single · calculation**

What is the total modeled passive loss?

Synthetic training case — not a field record.

Synthetic supported-wavelength model: transmitter minimum −2 dBm; receiver sensitivity −8 dBm and maximum accepted input −1 dBm. Fiber length 0.5 km at supplied 0.4 dB/km; four connector pairs at 0.5 dB each; two splices at 0.2 dB each. Required engineering margin is 2 dB. No installed insertion-loss, polarity or dispersion evidence is supplied.

1. 0.6 dB
2. 2.6 dB
3. 2.2 dB
4. 6 dB

**Correct option(s):** 2

- Option 1: That omits connector loss.
- Option 2: 0.2 fiber+2 connectors+0.4 splices.
- Option 3: That omits splice loss.
- Option 4: That is the transmitter-to-sensitivity budget, not path loss.

**CDCS-Q0433 · single · calculation**

What received power is predicted from the minimum transmitter value?

Synthetic training case — not a field record.

Synthetic supported-wavelength model: transmitter minimum −2 dBm; receiver sensitivity −8 dBm and maximum accepted input −1 dBm. Fiber length 0.5 km at supplied 0.4 dB/km; four connector pairs at 0.5 dB each; two splices at 0.2 dB each. Required engineering margin is 2 dB. No installed insertion-loss, polarity or dispersion evidence is supplied.

1. −10.6 dBm
2. 0.6 dBm
3. −2.6 dBm
4. −4.6 dBm

**Correct option(s):** 4

- Option 1: That subtracts loss from receiver sensitivity instead of transmitter power.
- Option 2: That adds loss instead of subtracting it.
- Option 3: That ignores transmitter power.
- Option 4: −2 dBm minus 2.6 dB loss.

**CDCS-Q0434 · single · calculation**

What is the predicted margin above sensitivity?

Synthetic training case — not a field record.

Synthetic supported-wavelength model: transmitter minimum −2 dBm; receiver sensitivity −8 dBm and maximum accepted input −1 dBm. Fiber length 0.5 km at supplied 0.4 dB/km; four connector pairs at 0.5 dB each; two splices at 0.2 dB each. Required engineering margin is 2 dB. No installed insertion-loss, polarity or dispersion evidence is supplied.

1. 3.4 dB
2. 12.6 dB
3. 2.6 dB
4. 1 dB

**Correct option(s):** 1

- Option 1: −4.6 minus −8 equals 3.4.
- Option 2: That incorrectly adds magnitudes.
- Option 3: That is passive path loss.
- Option 4: That is the magnitude of maximum accepted input, not sensitivity margin.

**CDCS-Q0435 · single · calculation**

How much margin remains beyond the required 2 dB?

Synthetic training case — not a field record.

Synthetic supported-wavelength model: transmitter minimum −2 dBm; receiver sensitivity −8 dBm and maximum accepted input −1 dBm. Fiber length 0.5 km at supplied 0.4 dB/km; four connector pairs at 0.5 dB each; two splices at 0.2 dB each. Required engineering margin is 2 dB. No installed insertion-loss, polarity or dispersion evidence is supplied.

1. 0.6 dB
2. 1.4 dB
3. 3.4 dB
4. 5.4 dB

**Correct option(s):** 2

- Option 1: That subtracts 2 from loss, a different quantity.
- Option 2: 3.4−2.
- Option 3: That ignores the reserved engineering margin.
- Option 4: That adds the requirement rather than reserving it.

**CDCS-Q0436 · single · operations**

Does predicted power satisfy the supplied receiver range?

Synthetic training case — not a field record.

Synthetic supported-wavelength model: transmitter minimum −2 dBm; receiver sensitivity −8 dBm and maximum accepted input −1 dBm. Fiber length 0.5 km at supplied 0.4 dB/km; four connector pairs at 0.5 dB each; two splices at 0.2 dB each. Required engineering margin is 2 dB. No installed insertion-loss, polarity or dispersion evidence is supplied.

1. No; every negative dBm value is invalid
2. No; it exceeds the −1 dBm maximum
3. Yes; −4.6 dBm lies between −8 and −1 dBm
4. Yes, and therefore every optical requirement is proven

**Correct option(s):** 3

- Option 1: Negative dBm simply means below one milliwatt.
- Option 2: −4.6 dBm is lower power than −1 dBm.
- Option 3: Both lower and upper limits pass in the model.
- Option 4: Power range alone does not establish all link constraints.

**CDCS-Q0437 · single · operations**

What is the distinction between dB and dBm here?

Synthetic training case — not a field record.

Synthetic supported-wavelength model: transmitter minimum −2 dBm; receiver sensitivity −8 dBm and maximum accepted input −1 dBm. Fiber length 0.5 km at supplied 0.4 dB/km; four connector pairs at 0.5 dB each; two splices at 0.2 dB each. Required engineering margin is 2 dB. No installed insertion-loss, polarity or dispersion evidence is supplied.

1. dB can be added to kilometres without a model
2. dBm is a cable length unit
3. They are interchangeable absolute-power units
4. dB expresses a ratio/loss; dBm is power referenced to one milliwatt

**Correct option(s):** 4

- Option 1: They are different quantities.
- Option 2: It is a power level.
- Option 3: Their meanings differ.
- Option 4: That permits subtracting path dB from transmitter dBm.

**CDCS-Q0438 · single · mechanism**

What does adequate power margin leave unproven?

Synthetic training case — not a field record.

Synthetic supported-wavelength model: transmitter minimum −2 dBm; receiver sensitivity −8 dBm and maximum accepted input −1 dBm. Fiber length 0.5 km at supplied 0.4 dB/km; four connector pairs at 0.5 dB each; two splices at 0.2 dB each. Required engineering margin is 2 dB. No installed insertion-loss, polarity or dispersion evidence is supplied.

1. The stated receiver sensitivity value
2. The model’s use of four connector pairs
3. The arithmetic sum of supplied losses
4. Actual insertion loss, polarity and application/dispersion constraints

**Correct option(s):** 4

- Option 1: That is a given parameter.
- Option 2: That is explicitly supplied.
- Option 3: That is calculated in the model.
- Option 4: A budget is not complete installed acceptance.

**CDCS-Q0439 · single · implementation**

What should an installed optical loss test record?

Synthetic training case — not a field record.

Synthetic supported-wavelength model: transmitter minimum −2 dBm; receiver sensitivity −8 dBm and maximum accepted input −1 dBm. Fiber length 0.5 km at supplied 0.4 dB/km; four connector pairs at 0.5 dB each; two splices at 0.2 dB each. Required engineering margin is 2 dB. No installed insertion-loss, polarity or dispersion evidence is supplied.

1. Only an OTDR trace without the required loss-test reference and boundary
2. Only the transceiver’s brand
3. Only a link-up LED
4. Path identity, wavelength, direction, reference method, instrument and result

**Correct option(s):** 4

- Option 1: One tool’s record does not automatically replace the specified acceptance method.
- Option 2: Brand identity does not measure the path.
- Option 3: It does not quantify insertion loss.
- Option 4: These define the measurement boundary.

**CDCS-Q0440 · single · mechanism**

Why inspect polarity even if connectors fit?

Synthetic training case — not a field record.

Synthetic supported-wavelength model: transmitter minimum −2 dBm; receiver sensitivity −8 dBm and maximum accepted input −1 dBm. Fiber length 0.5 km at supplied 0.4 dB/km; four connector pairs at 0.5 dB each; two splices at 0.2 dB each. Required engineering margin is 2 dB. No installed insertion-loss, polarity or dispersion evidence is supplied.

1. Polarity is relevant only to DC batteries
2. A favorable loss budget automatically fixes polarity
3. Physical mating does not guarantee transmit/receive or lane mapping
4. All identical connector shapes have identical polarity

**Correct option(s):** 3

- Option 1: Optical channels also need correct endpoint mapping.
- Option 2: Power arithmetic does not reroute fibers.
- Option 3: The supported optical path must be correct.
- Option 4: Cabling assemblies can map fibers differently.

**CDCS-Q0441 · single · operations**

What should happen first with C-17/C-71?

Synthetic training case — not a field record.

A cable labeled C-17 at rack R1 is labeled C-71 at the distribution panel. DCIM maps it to port 12; a recent work order says port 14. LLDP reports the expected neighboring switch but does not reveal passive patch panels. An unlabeled cable is proposed for removal because no traffic appeared during a five-minute sample. A shield change is suggested without the equipment EMC instructions.

1. Assume the rack label is always correct
2. Resolve the physical identity mismatch before relying on either record
3. Create two active cables without investigation
4. Choose the shorter label automatically

**Correct option(s):** 2

- Option 1: Authority requires actual evidence, not location preference.
- Option 2: Conflicting labels can cause the wrong service to be changed.
- Option 3: That may duplicate one physical path.
- Option 4: Length does not establish truth.

**CDCS-Q0442 · single · diagnosis**

How should the port 12 versus port 14 conflict be handled?

Synthetic training case — not a field record.

A cable labeled C-17 at rack R1 is labeled C-71 at the distribution panel. DCIM maps it to port 12; a recent work order says port 14. LLDP reports the expected neighboring switch but does not reveal passive patch panels. An unlabeled cable is proposed for removal because no traffic appeared during a five-minute sample. A shield change is suggested without the equipment EMC instructions.

1. Compare authorized change history with verified current physical mapping
2. Use whichever port currently has a green LED
3. Ignore the work order permanently
4. Always overwrite DCIM from the newest text regardless of provenance

**Correct option(s):** 1

- Option 1: Both records need reconciliation.
- Option 2: Link state alone does not identify the intended cable path.
- Option 3: It may contain relevant executed-change evidence.
- Option 4: Recency alone does not prove correctness.

**CDCS-Q0443 · single · mechanism**

What does LLDP help establish in this case?

Synthetic training case — not a field record.

A cable labeled C-17 at rack R1 is labeled C-71 at the distribution panel. DCIM maps it to port 12; a recent work order says port 14. LLDP reports the expected neighboring switch but does not reveal passive patch panels. An unlabeled cable is proposed for removal because no traffic appeared during a five-minute sample. A shield change is suggested without the equipment EMC instructions.

1. A reported active neighbor relationship within its protocol scope
2. The cable’s certified optical loss
3. The required fire rating of the cable jacket
4. Every intermediate patch-panel port

**Correct option(s):** 1

- Option 1: It does not enumerate every passive patch segment.
- Option 2: Discovery does not measure attenuation.
- Option 3: Protocol data does not establish material classification.
- Option 4: Passive infrastructure may not participate in LLDP.

**CDCS-Q0444 · single · mechanism**

Why is five minutes without traffic insufficient to authorize removal?

Synthetic training case — not a field record.

A cable labeled C-17 at rack R1 is labeled C-71 at the distribution panel. DCIM maps it to port 12; a recent work order says port 14. LLDP reports the expected neighboring switch but does not reveal passive patch panels. An unlabeled cable is proposed for removal because no traffic appeared during a five-minute sample. A shield change is suggested without the equipment EMC instructions.

1. The cable may serve an idle, standby or infrequent function
2. Every cable always carries traffic continuously
3. Traffic counters can never help investigation
4. An unlabeled cable is automatically abandoned

**Correct option(s):** 1

- Option 1: A short sample does not prove no dependency.
- Option 2: Some legitimate services are intermittent.
- Option 3: They can provide bounded evidence.
- Option 4: Missing labels are an evidence gap, not proof of retirement.

**CDCS-Q0445 · single · operations**

What should a removal decision establish?

Synthetic training case — not a field record.

A cable labeled C-17 at rack R1 is labeled C-71 at the distribution panel. DCIM maps it to port 12; a recent work order says port 14. LLDP reports the expected neighboring switch but does not reveal passive patch panels. An unlabeled cable is proposed for removal because no traffic appeared during a five-minute sample. A shield change is suggested without the equipment EMC instructions.

1. Only that the cable is inconvenient to route around
2. Identity, dependencies, authority, rollback and post-change service checks
3. Only that another cable looks similar
4. Only a new DCIM status entered before inspection

**Correct option(s):** 2

- Option 1: Convenience does not establish dispensability.
- Option 2: Physical removal is a controlled lifecycle action.
- Option 3: Appearance does not prove equivalent service.
- Option 4: Administrative change is not physical evidence.

**CDCS-Q0446 · single · operations**

What should govern the shield change?

Synthetic training case — not a field record.

A cable labeled C-17 at rack R1 is labeled C-71 at the distribution panel. DCIM maps it to port 12; a recent work order says port 14. LLDP reports the expected neighboring switch but does not reveal passive patch panels. An unlabeled cable is proposed for removal because no traffic appeared during a five-minute sample. A shield change is suggested without the equipment EMC instructions.

1. Only a bonding method copied from an unrelated installation
2. Always disconnect every shield at both ends
3. Always use the shield as protective earth
4. The supported equipment/cabling EMC and electrical design

**Correct option(s):** 4

- Option 1: The actual supported system and electrical design govern this case.
- Option 2: That can defeat intended EMC behavior.
- Option 3: A functional screen does not replace the protective conductor.
- Option 4: A universal end-connection rule is not appropriate.

**CDCS-Q0447 · single · operations**

What should a stable cable identifier link to?

Synthetic training case — not a field record.

A cable labeled C-17 at rack R1 is labeled C-71 at the distribution panel. DCIM maps it to port 12; a recent work order says port 14. LLDP reports the expected neighboring switch but does not reveal passive patch panels. An unlabeled cable is proposed for removal because no traffic appeared during a five-minute sample. A shield change is suggested without the equipment EMC instructions.

1. Only the current IP address
2. Only the latest customer name
3. Only the cable reel batch without installed endpoints
4. Endpoints, intermediate connections, route, media, service and test history

**Correct option(s):** 4

- Option 1: Addresses can change independently of cabling.
- Option 2: Ownership can change while the cable remains.
- Option 3: Material provenance does not identify the completed physical path.
- Option 4: The record must describe the actual physical relationship.

**CDCS-Q0448 · single · mechanism**

What does a post-change ping demonstrate?

Synthetic training case — not a field record.

A cable labeled C-17 at rack R1 is labeled C-71 at the distribution panel. DCIM maps it to port 12; a recent work order says port 14. LLDP reports the expected neighboring switch but does not reveal passive patch panels. An unlabeled cable is proposed for removal because no traffic appeared during a five-minute sample. A shield change is suggested without the equipment EMC instructions.

1. Limited reachability for the tested endpoints at that time
2. Guaranteed future service under all failures
3. Complete high-speed channel certification
4. Proof that every redundant route is independent

**Correct option(s):** 1

- Option 1: It does not certify cabling class or intended physical diversity.
- Option 2: A single observation has narrower scope.
- Option 3: That requires appropriate physical tests.
- Option 4: Ping can use only one working path.

**CDCS-Q0449 · single · mechanism**

Why review pathway fill and abandoned material?

Synthetic training case — not a field record.

A cable labeled C-17 at rack R1 is labeled C-71 at the distribution panel. DCIM maps it to port 12; a recent work order says port 14. LLDP reports the expected neighboring switch but does not reveal passive patch panels. An unlabeled cable is proposed for removal because no traffic appeared during a five-minute sample. A shield change is suggested without the equipment EMC instructions.

1. More fill always increases cable rating
2. Only appearance is affected
3. They can affect access, bend/support conditions, cooling and fire/housekeeping duties
4. Removing unknown cables needs no dependency check

**Correct option(s):** 3

- Option 1: Crowding can create problems.
- Option 2: Operational and performance constraints can matter.
- Option 3: Cabling has physical lifecycle consequences.
- Option 4: Identity and service must be established first.

**CDCS-Q0450 · single · operations**

What should the final change evidence retain?

Synthetic training case — not a field record.

A cable labeled C-17 at rack R1 is labeled C-71 at the distribution panel. DCIM maps it to port 12; a recent work order says port 14. LLDP reports the expected neighboring switch but does not reveal passive patch panels. An unlabeled cable is proposed for removal because no traffic appeared during a five-minute sample. A shield change is suggested without the equipment EMC instructions.

1. Only the original plan if execution differed
2. Only a verbal assurance that the network works
3. Only the corrected as-built label schedule without post-change tests
4. Pre-state, approved target, executed mapping, tests and corrected records

**Correct option(s):** 4

- Option 1: As-built differences need reconciliation.
- Option 2: Durable scoped evidence is needed.
- Option 3: Records must agree with the executed mapping, and the affected path and service still need verification.
- Option 4: The history explains what changed and why it is accepted.

#### Recall

**Top-of-rack versus an undersized end-of-row proposal — Synthetic training case — not a field record.

Twelve racks contain 16 servers each. Every server requires one connection to each of two access switches. ToR proposal: two 24-port switches per rack, each using 16 server ports and four uplink ports. EoR proposal: two 144-port switches for the row, with every server connected once to each. No breakout or extra line cards are proposed.**

There are 192 servers. Each ToR switch uses 20 ports and has four spare. Each EoR switch needs 192 server ports and is 48 short before uplinks. Compare physical cable length and active-device operations separately; neither architecture is universally preferred.

**A passing fixed link in an overlong channel — Synthetic training case — not a field record.

The project’s supplied copper limits are 90 m for the permanent link and 100 m for the complete channel under its selected application. Fixed cabling is 81 m; current patch/equipment cords total 22 m. The permanent-link test passes. A technician runs a wire-map test only after adding cords. The bundle also supplies powered endpoints, but thermal/power-duty review is absent.**

The fixed 81 m is within its supplied length limit, while the 103 m channel exceeds its 100 m limit by 3 m. A wire map does not certify the complete performance class. Powered-cabling duty adds supported current/thermal considerations; these case limits are not universal for every application.

**Optical budget and receiver range — Synthetic training case — not a field record.

Synthetic supported-wavelength model: transmitter minimum −2 dBm; receiver sensitivity −8 dBm and maximum accepted input −1 dBm. Fiber length 0.5 km at supplied 0.4 dB/km; four connector pairs at 0.5 dB each; two splices at 0.2 dB each. Required engineering margin is 2 dB. No installed insertion-loss, polarity or dispersion evidence is supplied.**

Passive loss is 0.2+2+0.4=2.6 dB. Predicted received power is −4.6 dBm, inside the supplied receiver range. Sensitivity margin is 3.4 dB, exceeding the 2 dB requirement by 1.4 dB in the model. Actual loss, polarity and application constraints still need verification.

**A patch change with conflicting physical records — Synthetic training case — not a field record.

A cable labeled C-17 at rack R1 is labeled C-71 at the distribution panel. DCIM maps it to port 12; a recent work order says port 14. LLDP reports the expected neighboring switch but does not reveal passive patch panels. An unlabeled cable is proposed for removal because no traffic appeared during a five-minute sample. A shield change is suggested without the equipment EMC instructions.**

Reconcile endpoint and intermediate-path identity using controlled evidence before changing records or removing cables. LLDP and short traffic observations have limited scope. Use the supported bonding/screen design and preserve pre-state, authorization, test and as-built records for the patch change.

#### References

- [EPI CDCS public syllabus](https://www.epi-ap.com/services/1/3/5)
- [Corning optical link loss budget worksheet](https://www.corning.com/optical-communications/worldwide/en/home/Resources/system-design-calculators/link-loss-budget-calculator.html)
- [Fiber Optic Association loss-budget teaching reference](https://www.thefoa.org/tech/lossbudg.htm)

## CDCS-M11 — Acoustic conditions, particles and corrosive contamination

### CDCS-L11 — Acoustic conditions, particles and corrosive contamination

Estimated study time: 120 minutes before independent work. Prerequisite chapters: CDCS-L10

## Environmental acceptance needs quantities, methods and consequences

A data-centre environment can meet temperature targets while exposing people or equipment to unsuitable noise or contamination. These subjects need their own source, path, receiver and acceptance model. Specify what is being protected, which operating states matter, where measurements occur and which standards, product limits or occupational requirements apply. A clean-looking room is not a particle or corrosion measurement, and a quiet impression during idle operation is not a full acoustic survey. The integration engineer should make the requirements and evidence visible while the responsible environmental, occupational and equipment specialists own their assigned decisions.

## Noise is logarithmic and state dependent

Sound pressure at a location and a source's sound power are different quantities. Sound pressure depends on distance, reflections, barriers and operating state; source sound power characterizes emitted acoustic power under its test method. Do not compare the two directly just because both are expressed in decibels. Frequency weighting, averaging time, measurement position and the stated test method also matter. A-weighted sound level is commonly used in occupational assessments, but a single instantaneous dBA value is not a complete exposure history or universal compliance decision.

For independent incoherent sources measured at the same receiver under the supplied assumptions, combine levels by adding their linear energy terms: Ltotal=10 log10(sum(10^(Li/10))). Two equal 80 dBA contributions therefore produce approximately 83.01 dBA, not 160 dBA or 80 dBA. This calculation assumes the contributions and measurement conditions support that combination. Coherent tones and complex reflections can require a different analysis. A change of three decibels is not an arithmetic three-percent change in sound energy.

An acoustic survey should represent the required equipment states: normal load, high fan operation, generator exercise, maintenance tools and other relevant sources. Record locations and heights, instrument settings/calibration, duration and operating conditions. A personal dosimeter and an area sound-level measurement answer related but different questions because a worker moves and experiences varying duration. Applicable occupational rules depend on jurisdiction and programme. NIOSH's public guidance provides a US recommended exposure framework; it is not automatically the legal limit everywhere. Use the site's competent occupational process for exposure decisions and protection requirements.

Noise control can act at source, transmission path or receiver. Quieter equipment or operating modes may help if they preserve thermal and service requirements. Enclosures, barriers and vibration isolation need appropriate design and can affect cooling, maintenance, fire access or structural interfaces. A panel that reduces noise while blocking a required intake is not an acceptable unreviewed improvement. Administrative controls and hearing protection may be needed under the site's programme, but they do not replace evaluation of feasible engineering controls. Alarm audibility and communication also need consideration; simply masking a warning tone can create another problem.

Acoustic noise can affect equipment differently from human exposure. Some mechanical storage devices or assemblies can be sensitive to vibration or acoustic excitation under particular conditions. A room's occupational assessment does not automatically establish every equipment susceptibility limit. Investigate actual vendor evidence, frequency content, mounting and observed errors before attributing a hardware fault to noise. Conversely, a server that continues running does not prove a worker's exposure is acceptable. Preserve these separate acceptance questions in the design review.

## Contamination includes more than visible dust

Particles can obstruct heat-transfer surfaces, increase filter resistance, enter mechanisms or create conductive paths depending on their material and size. Corrosive gases can affect contacts and metal surfaces without producing a visible dust layer. Conductive fibers or metallic whiskers present different concerns from inert particles of similar count. Moisture can change deposition, corrosion or electrical behavior. Identify the relevant contaminant classes, sources, transport paths and susceptible equipment instead of treating all contamination as one scalar cleanliness value.

Sources include construction work, packaging, outdoor air, maintenance processes, floor/ceiling materials and equipment wear. Preventive measures can include controlled construction boundaries, suitable filtration, approved cleaning, receiving/packaging practices, sealed penetrations and disciplined maintenance. Filter selection needs the required capture performance and system pressure/flow capability. Installing a more restrictive filter without checking airflow can create a thermal problem. Filter appearance alone does not prove condition; pressure drop, flow, inspection and the supported replacement criteria provide stronger evidence.

A particle counter reports quantities according to its sample volume, size bins and method. Counts per litre and counts per cubic metre differ by a factor of 1000. Cumulative bins count particles at or above a threshold, so the count at a larger size threshold cannot exceed the count at a smaller threshold for the same valid sample. Differential bins describe particles within ranges and have different interpretation. Record the instrument mode before judging the data. A mislabeled cumulative report can produce an impossible sequence and must be resolved before assigning a cleanliness class.

Sampling location, duration, activity and airflow state affect representativeness. A sample taken after cleaning in an empty room may not represent a construction-adjacent maintenance state. Retain background and task conditions, instrument suitability and uncertainty. Apply the actual chosen standard's sampling and classification method; do not infer a formal class from one convenient reading or invent particle limits from the course. Vendor environmental requirements may address both particulate and gaseous contamination, so a passing particle count does not prove low corrosivity.

Corrosion assessment may use appropriate monitoring methods such as material coupons or other supported sensors with a defined exposure period and interpretation. These measure a different phenomenon from particle count. A failed corrosion indicator with low particle readings is not logically impossible; the contaminant mechanism may be gaseous. Investigate air source, filtration/treatment, humidity and nearby activities through the competent process. Avoid unapproved cleaning chemicals or aggressive interventions that can leave residues or damage equipment. Actual cleaning and sampling methods must suit the environment and equipment.

## Close the loop with controlled changes and retained evidence

A contamination or noise finding should identify the measured condition, method, affected requirement, uncertainty and source hypothesis. Select a response with a mechanism and review its interactions with cooling, fire protection, electrical safety and maintenance. Define the post-change observation that would show improvement. If the source operating state changes simultaneously, qualify causal claims rather than assigning all improvement to the intervention. Preserve the original finding and the corrected result so later staff can understand why the control exists.

Ongoing governance assigns inspection, measurement and review triggers to owners. Construction, new high-speed fans, filter substitutions, equipment density changes and altered outdoor-air modes may require reassessment. Link environmental records to assets, locations and work orders in the chosen CMMS/DCIM workflow. The learner's independent task is to interpret supplied evidence and design a defensible review. Actual occupational measurements, contamination classification and specialist acceptance remain external evidence gates with the appropriate instruments, methods and authority.


#### Worked demonstrations

**Two fans and an incomplete acoustic survey**

Synthetic training case — not a field record.

Two independent incoherent fan sources each contribute 80 dBA at the same receiver under the supplied model. Use Ltotal=10log10(10^(L1/10)+10^(L2/10)). The project’s synthetic area criterion is at most 82 dBA in the defined high-load state; this is not a legal exposure limit. A survey measured only idle operation. A proposed acoustic panel blocks part of a required air intake.

**Reasoning:** The modeled combined level is 83.01 dBA, above the supplied area criterion. The idle survey does not cover high load. Review noise mitigation together with thermal airflow and the actual occupational assessment; an area criterion is not a complete personal exposure result.

**Impossible particle bins and a corrosive environment**

Synthetic training case — not a field record.

A report labels one sample’s cumulative counts per litre as ≥0.3 µm:1000, ≥0.5 µm:800, ≥1.0 µm:900. A different valid sample has 600 particles/L in its defined bin. Particle readings near a room inlet are low, but a supported corrosion coupon result exceeds the project’s supplied criterion. A filter’s pressure drop rises while airflow falls; staff say it looks clean. Construction work is occurring nearby.

**Reasoning:** The first cumulative sequence is inconsistent because the ≥1.0 µm count exceeds ≥0.5 µm. The valid 600/L sample is 600000/m³. Low particles do not rule out corrosive gases. Review source/transport and filter performance through appropriate methods rather than relying on appearance or assigning a class from invalid data.

#### Guided practice

Evaluate the two-fan area model and repair the contamination report before proposing controls.

**Hint:** Preserve logarithmic addition, measurement scope, sample-volume units and distinct contaminant mechanisms.

**Worked solution:** Two independent 80 dBA contributions combine to about 83.01 dBA, exceeding the synthetic 82 dBA criterion; idle evidence and an airflow-blocking panel do not close the requirement. The cumulative bins are inconsistent, 600/L equals 600000/m³, and low particles do not invalidate the corrosion finding. Review representative conditions and coupled thermal effects.

#### Independent task

Environment: analytical

Create an environmental measurement and corrective-action review.

**Packaged starter material**

- course_labs/CDCS/README.md
- course_labs/CDCS/fixture.json
- course_labs/CDCS/assessment_template.md
- course_labs/CDCS/lab.py
- course_labs/CDCS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- Acoustic calculation and survey scope
- Particle data validation and unit conversion
- Corrosion/filter/source investigation plan
- Mitigation and post-change acceptance evidence

**Acceptance criteria**

- No synthetic criterion is presented as a universal legal limit.
- Particle and gaseous contamination are assessed separately.
- Noise and filtration changes preserve cooling, access and other required functions.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer.

#### Chapter practice

**CDCS-Q0451 · single · calculation**

What is the combined level under the supplied incoherent-source model?

Synthetic training case — not a field record.

Two independent incoherent fan sources each contribute 80 dBA at the same receiver under the supplied model. Use Ltotal=10log10(10^(L1/10)+10^(L2/10)). The project’s synthetic area criterion is at most 82 dBA in the defined high-load state; this is not a legal exposure limit. A survey measured only idle operation. A proposed acoustic panel blocks part of a required air intake.

1. 40 dBA
2. 80 dBA
3. Approximately 83.01 dBA
4. 160 dBA

**Correct option(s):** 3

- Option 1: That averages and divides the levels incorrectly.
- Option 2: That ignores the second equal contribution.
- Option 3: Equal independent energy contributions add about 3.01 dB.
- Option 4: Decibel levels are not added arithmetically.

**CDCS-Q0452 · single · design**

Does the modeled result meet the synthetic 82 dBA area criterion?

Synthetic training case — not a field record.

Two independent incoherent fan sources each contribute 80 dBA at the same receiver under the supplied model. Use Ltotal=10log10(10^(L1/10)+10^(L2/10)). The project’s synthetic area criterion is at most 82 dBA in the defined high-load state; this is not a legal exposure limit. A survey measured only idle operation. A proposed acoustic panel blocks part of a required air intake.

1. Yes; each source alone is below 82
2. Yes; the average of 80 and 80 is 80
3. No; 83.01 dBA exceeds it
4. It proves a legal violation in every country

**Correct option(s):** 3

- Option 1: The criterion concerns the combined state.
- Option 2: Arithmetic averaging does not combine simultaneous source energy.
- Option 3: The stated numerical comparison fails.
- Option 4: The criterion is explicitly synthetic, not a universal law.

**CDCS-Q0453 · single · mechanism**

Why is the idle survey insufficient for the required state?

Synthetic training case — not a field record.

Two independent incoherent fan sources each contribute 80 dBA at the same receiver under the supplied model. Use Ltotal=10log10(10^(L1/10)+10^(L2/10)). The project’s synthetic area criterion is at most 82 dBA in the defined high-load state; this is not a legal exposure limit. A survey measured only idle operation. A proposed acoustic panel blocks part of a required air intake.

1. Idle measurements can never be useful
2. Fan output and noise can change under high load
3. High load always has exactly the same sound level
4. A recent calibration makes all operating states equivalent

**Correct option(s):** 2

- Option 1: They can characterize the idle state.
- Option 2: The acceptance condition was not observed.
- Option 3: That needs evidence and is not generally guaranteed.
- Option 4: Calibration does not replace representative source conditions.

**CDCS-Q0454 · single · mechanism**

Why review the acoustic panel’s airflow effect?

Synthetic training case — not a field record.

Two independent incoherent fan sources each contribute 80 dBA at the same receiver under the supplied model. Use Ltotal=10log10(10^(L1/10)+10^(L2/10)). The project’s synthetic area criterion is at most 82 dBA in the defined high-load state; this is not a legal exposure limit. A survey measured only idle operation. A proposed acoustic panel blocks part of a required air intake.

1. Thermal performance is irrelevant after the noise criterion passes
2. Noise control always improves cooling automatically
3. Any obstruction is acceptable if removable
4. It can reduce required cooling intake and create another service defect

**Correct option(s):** 4

- Option 1: Both requirements remain.
- Option 2: The panel physically obstructs an intake.
- Option 3: Temporary or removable changes still need review.
- Option 4: Noise mitigation must preserve coupled requirements.

**CDCS-Q0455 · single · operations**

What differs between sound power and sound pressure?

Synthetic training case — not a field record.

Two independent incoherent fan sources each contribute 80 dBA at the same receiver under the supplied model. Use Ltotal=10log10(10^(L1/10)+10^(L2/10)). The project’s synthetic area criterion is at most 82 dBA in the defined high-load state; this is not a legal exposure limit. A survey measured only idle operation. A proposed acoustic panel blocks part of a required air intake.

1. They are always numerically identical at every distance
2. Sound pressure contains no location dependence
3. Source emission and receiver-location field are distinct quantities
4. Sound power is measured only in degrees Celsius

**Correct option(s):** 3

- Option 1: Propagation and environment affect pressure.
- Option 2: The receiver and environment matter.
- Option 3: Their decibel values use different meanings and references.
- Option 4: It is an acoustic power quantity.

**CDCS-Q0456 · single · operations**

What must accompany a sound-level value?

Synthetic training case — not a field record.

Two independent incoherent fan sources each contribute 80 dBA at the same receiver under the supplied model. Use Ltotal=10log10(10^(L1/10)+10^(L2/10)). The project’s synthetic area criterion is at most 82 dBA in the defined high-load state; this is not a legal exposure limit. A survey measured only idle operation. A proposed acoustic panel blocks part of a required air intake.

1. Only the number with dB after it
2. Weighting, time response/duration, position and operating conditions
3. Only the source’s catalogue sound-power value
4. Only the server count

**Correct option(s):** 2

- Option 1: The omitted method can change meaning.
- Option 2: These define the measurement’s interpretation.
- Option 3: That does not define the actual receiver sound-pressure measurement.
- Option 4: Count does not define acoustic measurement conditions.

**CDCS-Q0457 · single · mechanism**

Why does an area reading not by itself establish a worker’s full exposure?

Synthetic training case — not a field record.

Two independent incoherent fan sources each contribute 80 dBA at the same receiver under the supplied model. Use Ltotal=10log10(10^(L1/10)+10^(L2/10)). The project’s synthetic area criterion is at most 82 dBA in the defined high-load state; this is not a legal exposure limit. A survey measured only idle operation. A proposed acoustic panel blocks part of a required air intake.

1. Exposure depends only on equipment purchase date
2. A personal dosimeter measures rack power instead
3. Movement and duration across different levels matter
4. Workers always remain at the microphone position all day

**Correct option(s):** 3

- Option 1: Age is not the complete acoustic history.
- Option 2: It is an exposure measurement tool when appropriately used.
- Option 3: Personal exposure depends on the experienced history.
- Option 4: That is not established.

**CDCS-Q0458 · single · design**

What is the role of NIOSH guidance in a multinational site review?

Synthetic training case — not a field record.

Two independent incoherent fan sources each contribute 80 dBA at the same receiver under the supplied model. Use Ltotal=10log10(10^(L1/10)+10^(L2/10)). The project’s synthetic area criterion is at most 82 dBA in the defined high-load state; this is not a legal exposure limit. A survey measured only idle operation. A proposed acoustic panel blocks part of a required air intake.

1. A replacement for actual measurement
2. A named recommended framework to interpret alongside applicable local requirements
3. A universal law that overrides all local requirements
4. Proof that the synthetic 82 dBA criterion is its published limit

**Correct option(s):** 2

- Option 1: Guidance does not supply site data.
- Option 2: It is not automatically every jurisdiction’s legal rule.
- Option 3: Its status and adoption differ.
- Option 4: The case explicitly separates the training criterion.

**CDCS-Q0459 · single · design**

What should a quieter fan operating mode prove before acceptance?

Synthetic training case — not a field record.

Two independent incoherent fan sources each contribute 80 dBA at the same receiver under the supplied model. Use Ltotal=10log10(10^(L1/10)+10^(L2/10)). The project’s synthetic area criterion is at most 82 dBA in the defined high-load state; this is not a legal exposure limit. A survey measured only idle operation. A proposed acoustic panel blocks part of a required air intake.

1. Only a lower displayed fan percentage
2. Only that the server still responds to ping once
3. Only that the mode is labeled silent
4. The required cooling/service behavior and acoustic improvement under relevant states

**Correct option(s):** 4

- Option 1: A command value does not establish either outcome.
- Option 2: That does not verify sustained thermal performance.
- Option 3: A name is not an acceptance test.
- Option 4: Lower noise alone is not sufficient.

**CDCS-Q0460 · single · operations**

Which equipment conclusion needs evidence beyond an occupational noise assessment?

Synthetic training case — not a field record.

Two independent incoherent fan sources each contribute 80 dBA at the same receiver under the supplied model. Use Ltotal=10log10(10^(L1/10)+10^(L2/10)). The project’s synthetic area criterion is at most 82 dBA in the defined high-load state; this is not a legal exposure limit. A survey measured only idle operation. A proposed acoustic panel blocks part of a required air intake.

1. Every disk is immune whenever worker exposure passes
2. A server that remains powered proves all storage performance is unaffected
3. Any observed disk error must be caused by noise
4. Whether installed storage hardware meets its acoustic/vibration susceptibility requirements

**Correct option(s):** 4

- Option 1: Different receivers have different acceptance criteria.
- Option 2: Power state does not establish the required storage behavior.
- Option 3: Correlation and other failure mechanisms need investigation.
- Option 4: Worker-exposure criteria do not establish every hardware limit.

**CDCS-Q0461 · single · diagnosis**

What is inconsistent in the cumulative particle report?

Synthetic training case — not a field record.

A report labels one sample’s cumulative counts per litre as ≥0.3 µm:1000, ≥0.5 µm:800, ≥1.0 µm:900. A different valid sample has 600 particles/L in its defined bin. Particle readings near a room inlet are low, but a supported corrosion coupon result exceeds the project’s supplied criterion. A filter’s pressure drop rises while airflow falls; staff say it looks clean. Construction work is occurring nearby.

1. All counts are positive
2. The size units are micrometres
3. The ≥1.0 µm count exceeds the ≥0.5 µm count
4. The ≥0.3 µm count is higher than ≥0.5 µm

**Correct option(s):** 3

- Option 1: Positive counts are not inherently invalid.
- Option 2: That is a normal particle-size unit.
- Option 3: Larger-threshold particles are a subset of the smaller-threshold cumulative count.
- Option 4: That is possible for valid cumulative bins.

**CDCS-Q0462 · single · operations**

What should be checked before rejecting the instrument itself?

Synthetic training case — not a field record.

A report labels one sample’s cumulative counts per litre as ≥0.3 µm:1000, ≥0.5 µm:800, ≥1.0 µm:900. A different valid sample has 600 particles/L in its defined bin. Particle readings near a room inlet are low, but a supported corrosion coupon result exceeds the project’s supplied criterion. A filter’s pressure drop rises while airflow falls; staff say it looks clean. Construction work is occurring nearby.

1. Only the room’s PUE
2. Whether bins, units, sample identity or report mapping were mislabeled
3. Only the last software login time
4. Only whether the smallest bin is below the project limit

**Correct option(s):** 2

- Option 1: Energy ratio does not validate particle bins.
- Option 2: The inconsistency may be in interpretation or data handling.
- Option 3: Login history does not establish the sampling data format.
- Option 4: One favorable count does not resolve inconsistent cumulative data.

**CDCS-Q0463 · single · calculation**

How does 600 particles/L convert to particles/m³?

Synthetic training case — not a field record.

A report labels one sample’s cumulative counts per litre as ≥0.3 µm:1000, ≥0.5 µm:800, ≥1.0 µm:900. A different valid sample has 600 particles/L in its defined bin. Particle readings near a room inlet are low, but a supported corrosion coupon result exceeds the project’s supplied criterion. A filter’s pressure drop rises while airflow falls; staff say it looks clean. Construction work is occurring nearby.

1. 6000 particles/m³
2. 0.6 particles/m³
3. 600000 particles/m³
4. 600 particles/m³

**Correct option(s):** 3

- Option 1: That uses a factor of ten instead of 1000.
- Option 2: That divides by 1000 in the wrong direction.
- Option 3: One cubic metre contains 1000 litres.
- Option 4: That ignores the volume-unit change.

**CDCS-Q0464 · single · mechanism**

Why can low particle counts coexist with an adverse corrosion result?

Synthetic training case — not a field record.

A report labels one sample’s cumulative counts per litre as ≥0.3 µm:1000, ≥0.5 µm:800, ≥1.0 µm:900. A different valid sample has 600 particles/L in its defined bin. Particle readings near a room inlet are low, but a supported corrosion coupon result exceeds the project’s supplied criterion. A filter’s pressure drop rises while airflow falls; staff say it looks clean. Construction work is occurring nearby.

1. Particle counters directly measure every gas concentration
2. The two observations are physically impossible together
3. Gaseous corrosivity is a different contamination mechanism
4. A coupon result is automatically false whenever air looks clear

**Correct option(s):** 3

- Option 1: They are not universal gas analyzers.
- Option 2: They measure different phenomena.
- Option 3: Particle count does not measure every corrosive exposure.
- Option 4: Visual clarity does not rule out corrosive gases.

**CDCS-Q0465 · single · mechanism**

What does rising filter pressure drop with falling airflow suggest reviewing?

Synthetic training case — not a field record.

A report labels one sample’s cumulative counts per litre as ≥0.3 µm:1000, ≥0.5 µm:800, ≥1.0 µm:900. A different valid sample has 600 particles/L in its defined bin. Particle readings near a room inlet are low, but a supported corrosion coupon result exceeds the project’s supplied criterion. A filter’s pressure drop rises while airflow falls; staff say it looks clean. Construction work is occurring nearby.

1. That fan power is necessarily zero
2. Filter/system resistance and the supported maintenance condition
3. That a cleaner-looking filter must pass every criterion
4. Only whether the filter’s label is legible

**Correct option(s):** 2

- Option 1: The supplied observations do not establish that.
- Option 2: Appearance alone does not establish flow performance.
- Option 3: Visual appearance can miss relevant loading or system issues.
- Option 4: A label does not quantify restriction.

**CDCS-Q0466 · single · mechanism**

Why not install a more restrictive filter without assessment?

Synthetic training case — not a field record.

A report labels one sample’s cumulative counts per litre as ≥0.3 µm:1000, ≥0.5 µm:800, ≥1.0 µm:900. A different valid sample has 600 particles/L in its defined bin. Particle readings near a room inlet are low, but a supported corrosion coupon result exceeds the project’s supplied criterion. A filter’s pressure drop rises while airflow falls; staff say it looks clean. Construction work is occurring nearby.

1. Higher filtration always increases airflow
2. Cooling and contamination are unrelated systems
3. Any filter can be used if dimensions fit
4. It may reduce airflow beyond the cooling system’s capability

**Correct option(s):** 4

- Option 1: Restriction can have the opposite effect.
- Option 2: They share air paths and equipment.
- Option 3: Performance and compatibility requirements also matter.
- Option 4: Capture performance and pressure-flow behavior must both fit.

**CDCS-Q0467 · single · operations**

What should the construction-adjacent sampling plan include?

Synthetic training case — not a field record.

A report labels one sample’s cumulative counts per litre as ≥0.3 µm:1000, ≥0.5 µm:800, ≥1.0 µm:900. A different valid sample has 600 particles/L in its defined bin. Particle readings near a room inlet are low, but a supported corrosion coupon result exceeds the project’s supplied criterion. A filter’s pressure drop rises while airflow falls; staff say it looks clean. Construction work is occurring nearby.

1. Only one convenient sample after all work ends
2. Representative locations, activities, airflow states, duration and method
3. Only the total number of construction workers
4. Only the contractor’s statement that dust is controlled

**Correct option(s):** 2

- Option 1: That may not represent the operating risk.
- Option 2: A quiet clean-room moment may miss the relevant exposure.
- Option 3: Count does not quantify contamination.
- Option 4: The claim needs appropriate evidence.

**CDCS-Q0468 · single · operations**

Can the invalid first sample establish a formal cleanliness class?

Synthetic training case — not a field record.

A report labels one sample’s cumulative counts per litre as ≥0.3 µm:1000, ≥0.5 µm:800, ≥1.0 µm:900. A different valid sample has 600 particles/L in its defined bin. Particle readings near a room inlet are low, but a supported corrosion coupon result exceeds the project’s supplied criterion. A filter’s pressure drop rises while airflow falls; staff say it looks clean. Construction work is occurring nearby.

1. Yes, choose the lowest bin count to obtain the best class
2. No; resolve data validity and apply the actual standard’s sampling method
3. Yes, because all values have units
4. Every particle sample automatically defines a class without a method

**Correct option(s):** 2

- Option 1: Selective use conceals the inconsistency.
- Option 2: One inconsistent report cannot substantiate classification.
- Option 3: Units alone do not ensure valid data.
- Option 4: Classification has specified requirements.

**CDCS-Q0469 · single · operations**

What should a cleaning method consider?

Synthetic training case — not a field record.

A report labels one sample’s cumulative counts per litre as ≥0.3 µm:1000, ≥0.5 µm:800, ≥1.0 µm:900. A different valid sample has 600 particles/L in its defined bin. Particle readings near a room inlet are low, but a supported corrosion coupon result exceeds the project’s supplied criterion. A filter’s pressure drop rises while airflow falls; staff say it looks clean. Construction work is occurring nearby.

1. Equipment compatibility, residue, particle control and authorized procedures
2. Use any household vacuum in every live equipment space
3. Only whether the chemical has a strong smell
4. Only how quickly visible dust disappears

**Correct option(s):** 1

- Option 1: An unsuitable method can create additional contamination or damage.
- Option 2: Equipment and site requirements govern suitable tools.
- Option 3: Smell does not establish suitability.
- Option 4: Invisible residue or redistribution can remain.

**CDCS-Q0470 · single · operations**

What should close the contamination corrective action?

Synthetic training case — not a field record.

A report labels one sample’s cumulative counts per litre as ≥0.3 µm:1000, ≥0.5 µm:800, ≥1.0 µm:900. A different valid sample has 600 particles/L in its defined bin. Particle readings near a room inlet are low, but a supported corrosion coupon result exceeds the project’s supplied criterion. A filter’s pressure drop rises while airflow falls; staff say it looks clean. Construction work is occurring nearby.

1. Only a lower count in a different undisclosed sample volume
2. Only replacing the report’s failed word with passed
3. Valid representative measurements and evidence that the targeted source/path control works
4. Only removing the corrosion coupon from view

**Correct option(s):** 3

- Option 1: Unaligned units and conditions cannot support the claim.
- Option 2: That changes the label, not the condition.
- Option 3: A clean appearance alone is not the acceptance.
- Option 4: That removes evidence rather than the cause.

#### Recall

**Two fans and an incomplete acoustic survey — Synthetic training case — not a field record.

Two independent incoherent fan sources each contribute 80 dBA at the same receiver under the supplied model. Use Ltotal=10log10(10^(L1/10)+10^(L2/10)). The project’s synthetic area criterion is at most 82 dBA in the defined high-load state; this is not a legal exposure limit. A survey measured only idle operation. A proposed acoustic panel blocks part of a required air intake.**

The modeled combined level is 83.01 dBA, above the supplied area criterion. The idle survey does not cover high load. Review noise mitigation together with thermal airflow and the actual occupational assessment; an area criterion is not a complete personal exposure result.

**Impossible particle bins and a corrosive environment — Synthetic training case — not a field record.

A report labels one sample’s cumulative counts per litre as ≥0.3 µm:1000, ≥0.5 µm:800, ≥1.0 µm:900. A different valid sample has 600 particles/L in its defined bin. Particle readings near a room inlet are low, but a supported corrosion coupon result exceeds the project’s supplied criterion. A filter’s pressure drop rises while airflow falls; staff say it looks clean. Construction work is occurring nearby.**

The first cumulative sequence is inconsistent because the ≥1.0 µm count exceeds ≥0.5 µm. The valid 600/L sample is 600000/m³. Low particles do not rule out corrosive gases. Review source/transport and filter performance through appropriate methods rather than relying on appearance or assigning a class from invalid data.

#### References

- [EPI CDCS public syllabus](https://www.epi-ap.com/services/1/3/5)
- [NIOSH noise measurement/exposure and prevention reference](https://www.cdc.gov/niosh/noise/about/noise.html)
- [ASHRAE data-centre environmental reference catalogue](https://www.ashrae.org/technical-resources/bookstore/datacom-series)

## CDCS-M12 — Measured efficiency, cooling economics and open-hardware integration

### CDCS-L12 — Measured efficiency, cooling economics and open-hardware integration

Estimated study time: 120 minutes before independent work. Prerequisite chapters: CDCS-L11

## Efficiency starts with the service and the measurement boundary

Data-centre efficiency is the relationship between resources consumed and an explicitly defined useful outcome. Facility overhead, IT energy, useful computational work, water, carbon, cost and reliability are different dimensions. A design should state which objective it improves and which constraints it preserves. Lower electricity use may reflect a smaller workload rather than better efficiency; lower PUE may reflect a larger IT denominator rather than less total energy. Present absolute quantities and workload context alongside ratios so a decision maker can see the mechanism.

PUE is total facility energy divided by IT equipment energy within the selected method and reporting boundary. If annual facility energy is 2400 MWh and IT energy 1600 MWh, PUE is 1.5 and non-IT overhead is 800 MWh. After consolidation, facility energy might fall to 1700 MWh while IT energy falls to 1000 MWh, giving PUE 1.7 and overhead 700 MWh. Both total energy and overhead fell even though PUE rose. The correct conclusion is not that consolidation necessarily wasted energy; the ratio's denominator changed more strongly.

Measurement categories and reporting conventions must be taken from the applicable PUE method/edition. A meter at UPS output can include downstream distribution losses or other loads that a closer IT-equipment boundary treats differently. Do not silently compare figures from different points as equivalent. Record measurement locations, coverage, energy types, allocation of shared services, sample/aggregation method and missing-data treatment. A five-minute power ratio is not automatically an annual energy PUE. Combine periods using energy sums rather than averaging ratios with unequal denominators.

Data quality is part of efficiency design. Meter scaling, current-transformer ratios, phase mapping, resets, time alignment and missing intervals can distort a result. An apparent improvement after moving a load outside the metered boundary is not a physical saving. A shared cooling plant needs a defensible allocation method; arbitrary allocation can make one room appear efficient at another's expense. Retain raw readings and calculation lineage so the report can be audited through EPMS/DCIM rather than reconstructed from a single rounded dashboard number.

## Pair infrastructure metrics with useful-work and environmental measures

PUE does not measure useful application output. A workload comparison can use an appropriate functional unit, such as a completed task meeting the same quality and service criteria. If a baseline uses 200 kWh for 1000 comparable completed tasks, it uses 0.2 kWh/task. A new run using 180 kWh for 600 tasks uses 0.3 kWh/task. Total energy fell, but energy per completed task worsened under those supplied comparable conditions. The functional unit must preserve quality, workload and boundary; counting incomplete or lower-quality tasks can create another misleading ratio.

Water and emissions metrics need separate boundaries and methods. On-site water use, source-energy water use, location-based electricity emissions and contractual energy attributes describe different things. A low-PUE site can use carbon-intensive electricity or operate in a water-stressed area. A design review should identify trade-offs and use the applicable current accounting guidance for formal claims. This course does not infer carbon neutrality or water sustainability from a single efficiency ratio. Environmental procurement also considers useful life, repair, embodied impacts and end-of-life handling within a declared scope.

Business drivers include operating cost, available capacity, environmental commitments and service resilience. A project can create value by freeing constrained electrical or cooling capacity even when simple energy payback is long. Conversely, a short payback does not justify removing protective functions or maintenance margin. Make the objective and acceptance explicit: annual net cost saving, energy reduction at equivalent service, capacity released, or another measurable result. Assign an owner to verify the benefit after implementation rather than treating forecast values as achieved on installation day.

## Model cooling savings before claiming them

Cooling improvements should follow a physical mechanism: reduce mixing, improve heat-exchanger approach, match flow to demand, reduce unnecessary pressure drop or use an appropriate ambient-assisted mode. Each has constraints. Higher coolant or air setpoints can improve some system efficiencies while reducing equipment margin or affecting humidity/condensation behavior. Economizer operation depends on outdoor conditions, contamination, water and control strategy. The whole-system boundary must include fans, pumps, treatment, auxiliary power and the final heat-rejection path as relevant.

For a supplied ideal fan-law model at corresponding conditions, power varies approximately with the cube of speed. Reducing speed ratio to 0.8 gives a power ratio of 0.8³=0.512. A 20 kW baseline therefore becomes 10.24 kW in that model, saving 9.76 kW. Over 4000 equivalent hours, energy saving is 39040 kWh. At a stated flat charge of 0.15 currency/kWh, gross energy-charge saving is 5856 currency/year. If added annual maintenance is 1000, net modeled saving is 4856; a 50000 capital cost has simple payback about 10.30 years. Actual fan/system behavior and service conditions must validate the model.

Fan laws are conditional approximations, not a license to reduce airflow blindly. System resistance, controls, efficiency changes and minimum flow can alter results. A lower fan speed may fail the hottest rack while the room average remains acceptable. Define the trial state, measurements, stop/rollback criteria and responsible authority. Compare equivalent load and ambient conditions or use a justified normalization. Preserve adverse results; a trial that finds a thermal constraint still provides valuable design evidence. Do not annualize a short favorable window without stating representativeness and uncertainty.

Financial comparisons should distinguish energy charges from demand charges and other bill terms. Simple payback ignores time value, residual value and many risk effects; use a more complete life-cycle method when the decision needs it. Sensitivity to operating hours, energy price, maintenance and growth can change the ranking. A forecast with several decimal places is not more certain than its assumptions. Report the range or uncertainty that matters to the decision, and include the cost of maintaining the accepted service.

## Lighting improvements must preserve their required functions

Lighting energy equals power times operating duration. More efficient luminaires and occupancy/daylight controls can reduce consumption when they deliver the required illumination and supported control behavior. Evaluate task visibility, maintenance work, camera performance where relevant, emergency lighting, egress and fault behavior. Emergency functions must not be silently included in an occupancy-off strategy that defeats their purpose. A controls failure should have the accepted response, and the installed configuration needs testing at representative locations.

A lamp wattage comparison alone does not establish equal lighting service. Distribution, glare, color characteristics, driver behavior, dimming compatibility and maintenance conditions can matter. Installed lighting can also add heat to the conditioned space, but the resulting cooling saving depends on the actual thermal boundary and operating mode. Avoid counting the same energy saving twice in separate electrical and cooling calculations. Preserve the direct reduction and any modeled secondary effect as distinct terms with assumptions.

## Open hardware is a design input, not automatic compatibility

The Open Compute Project supports collaborative development and sharing of hardware-related designs and specifications. Its ecosystem can offer efficient and scalable approaches, but “open” does not mean every product is free, interchangeable, supported indefinitely or already suitable for a particular facility. Identify the exact specification, revision, product, contribution/recognition status and support arrangement. A marketing use of OCP terminology is not equivalent to verified compliance with the project's required interface or facility recognition.

An open-rack proposal can change mechanical dimensions, power distribution, cooling, service access, cabling and management interfaces. A site designed around conventional racks may need a reviewed transition rather than a simple replacement. Confirm equipment compatibility, vendor support, spare strategy, documentation, firmware/security lifecycle and operational training. Current OCP and vendor documents remain external primary references; this course does not reproduce proprietary implementation files or award OCP facility recognition from a quiz.

Procurement should compare the useful service and full lifecycle boundary. Lower operating power may be offset by reduced throughput, unsupported maintenance or premature replacement. A good design review connects the physical interface, energy evidence and operational capability. At handover, establish a measured baseline, verified control behavior and benefit-review schedule. Sustained efficiency depends on maintenance, accurate telemetry, disciplined changes and recovery that returns the system to the intended operating state rather than leaving permanent temporary overrides.


#### Worked demonstrations

**Lower total energy with higher PUE**

Synthetic training case — not a field record.

Baseline annual facility energy is 2400 MWh and IT energy 1600 MWh. After consolidation, the same complete boundary records 1700 MWh facility and 1000 MWh IT. A separate room reports a five-minute ratio measured at UPS output and calls it directly equivalent to the annual IT-equipment-boundary value. Meter coverage and shared-cooling allocation for that room are undocumented.

**Reasoning:** Baseline PUE is 1.5 and overhead 800 MWh. After consolidation PUE is 1.7 and overhead 700 MWh, with total energy down 700 MWh. The short-period UPS-output figure has a different time/measurement basis and cannot be assumed directly comparable. PUE does not establish workload, water or carbon outcomes.

**A fan-law business case with operating constraints**

Synthetic training case — not a field record.

A supplied ideal fan model uses P2/P1=(n2/n1)^3. Baseline fan power is 20 kW; proposed speed ratio is 0.8. Equivalent annual hours are 4000, flat energy charge 0.15 currency/kWh, added maintenance 1000/year and capital cost 50000. Demand charges are excluded. Hottest-rack acceptance and actual fan/system performance are not yet tested.

**Reasoning:** Modeled power is 10.24 kW and reduction 9.76 kW. Annual saving is 39040 kWh, worth 5856 before maintenance and 4856 net. Simple payback is about 10.30 years. These are conditional estimates; thermal service, installed behavior and representative operating hours need validation.

**Open hardware, useful work and lighting control**

Synthetic training case — not a field record.

A baseline workload completes 1000 equivalent quality-accepted tasks using 200 kWh. A proposed platform completes 600 of the same tasks using 180 kWh. Its rack uses a different power/cooling interface that has not been reviewed; the vendor calls it OCP-based. Separately, an occupancy-lighting proposal includes emergency luminaires in the off command and claims cooling savings without a thermal boundary calculation.

**Reasoning:** Energy per task rises from 0.2 to 0.3 kWh despite lower total consumption. OCP terminology does not prove the exact product’s compatibility or support. Review the rack interfaces and operational lifecycle. Lighting controls must preserve required emergency functions, and secondary cooling savings need their own boundary without double counting.

#### Guided practice

Review the PUE, fan-law and procurement proposals as one evidence-based efficiency decision.

**Hint:** Preserve useful service, measurement boundary, financial scope and operational constraints.

**Worked solution:** PUE rises from 1.5 to 1.7 while facility energy falls 700 MWh and overhead falls 100 MWh. The ideal fan model gives 39040 kWh/year and 4856 net currency/year, with about 10.30-year simple payback pending validation. Energy per task worsens from 0.2 to 0.3 kWh/task. OCP interfaces and emergency lighting duties require explicit review.

#### Independent task

Environment: analytical

Defend a complete efficiency proposal and a post-implementation benefit plan.

**Packaged starter material**

- course_labs/CDCS/README.md
- course_labs/CDCS/fixture.json
- course_labs/CDCS/assessment_template.md
- course_labs/CDCS/lab.py
- course_labs/CDCS/PUBLIC_SYLLABUS_MAP.md

**Evidence to produce**

- PUE boundary and useful-work metric comparison
- Cooling calculation and financial sensitivity
- Open-hardware interface/support review
- Lighting control and measured-benefit acceptance plan

**Acceptance criteria**

- Every saving has an equivalent service and explicit boundary.
- Forecast values are not reported as achieved benefits.
- Efficiency does not silently remove protective, emergency or maintenance functions.

Synthetic cases and paper decisions do not establish executed physical work. Arrange vendor, physical or supervised practice and record the actual fidelity, authority and reviewer.

#### Chapter practice

**CDCS-Q0471 · single · calculation**

What is baseline PUE?

Synthetic training case — not a field record.

Baseline annual facility energy is 2400 MWh and IT energy 1600 MWh. After consolidation, the same complete boundary records 1700 MWh facility and 1000 MWh IT. A separate room reports a five-minute ratio measured at UPS output and calls it directly equivalent to the annual IT-equipment-boundary value. Meter coverage and shared-cooling allocation for that room are undocumented.

1. 2.4
2. 1.5
3. 0.5
4. 0.667

**Correct option(s):** 2

- Option 1: That uses an incorrect denominator scale.
- Option 2: 2400/1600.
- Option 3: That is overhead relative to IT, not total facility/IT.
- Option 4: That reverses the ratio.

**CDCS-Q0472 · single · calculation**

What is post-consolidation PUE?

Synthetic training case — not a field record.

Baseline annual facility energy is 2400 MWh and IT energy 1600 MWh. After consolidation, the same complete boundary records 1700 MWh facility and 1000 MWh IT. A separate room reports a five-minute ratio measured at UPS output and calls it directly equivalent to the annual IT-equipment-boundary value. Meter coverage and shared-cooling allocation for that room are undocumented.

1. 1.5
2. 1.7
3. 0.7
4. 0.588

**Correct option(s):** 2

- Option 1: That retains the old ratio despite changed quantities.
- Option 2: 1700/1000.
- Option 3: That is overhead relative to IT.
- Option 4: That reverses the ratio.

**CDCS-Q0473 · single · calculation**

How much did total facility energy fall?

Synthetic training case — not a field record.

Baseline annual facility energy is 2400 MWh and IT energy 1600 MWh. After consolidation, the same complete boundary records 1700 MWh facility and 1000 MWh IT. A separate room reports a five-minute ratio measured at UPS output and calls it directly equivalent to the annual IT-equipment-boundary value. Meter coverage and shared-cooling allocation for that room are undocumented.

1. 700 MWh
2. 1700 MWh
3. 100 MWh
4. 600 MWh

**Correct option(s):** 1

- Option 1: 2400−1700.
- Option 2: That is the new total, not the reduction.
- Option 3: That is the overhead decrease.
- Option 4: That is the IT-energy decrease.

**CDCS-Q0474 · single · operations**

What happened to non-IT overhead energy?

Synthetic training case — not a field record.

Baseline annual facility energy is 2400 MWh and IT energy 1600 MWh. After consolidation, the same complete boundary records 1700 MWh facility and 1000 MWh IT. A separate room reports a five-minute ratio measured at UPS output and calls it directly equivalent to the annual IT-equipment-boundary value. Meter coverage and shared-cooling allocation for that room are undocumented.

1. It became zero after consolidation
2. It rose because PUE rose
3. It fell from 800 to 700 MWh
4. It stayed exactly 800 MWh

**Correct option(s):** 3

- Option 1: Facility energy still exceeds IT energy.
- Option 2: The absolute overhead calculation shows a reduction.
- Option 3: Subtract IT from facility energy in each period.
- Option 4: The new difference is 700.

**CDCS-Q0475 · single · mechanism**

Why can PUE rise while total energy falls?

Synthetic training case — not a field record.

Baseline annual facility energy is 2400 MWh and IT energy 1600 MWh. After consolidation, the same complete boundary records 1700 MWh facility and 1000 MWh IT. A separate room reports a five-minute ratio measured at UPS output and calls it directly equivalent to the annual IT-equipment-boundary value. Meter coverage and shared-cooling allocation for that room are undocumented.

1. The IT denominator can fall faster relative to overhead
2. PUE is always calculated incorrectly after consolidation
3. Consolidation necessarily adds more lighting
4. Higher PUE mathematically requires higher facility energy

**Correct option(s):** 1

- Option 1: A ratio and its numerator can move differently.
- Option 2: The supplied arithmetic is consistent.
- Option 3: No such causal claim is supplied.
- Option 4: The denominator also matters.

**CDCS-Q0476 · single · mechanism**

Why is the five-minute ratio not automatically an annual result?

Synthetic training case — not a field record.

Baseline annual facility energy is 2400 MWh and IT energy 1600 MWh. After consolidation, the same complete boundary records 1700 MWh facility and 1000 MWh IT. A separate room reports a five-minute ratio measured at UPS output and calls it directly equivalent to the annual IT-equipment-boundary value. Meter coverage and shared-cooling allocation for that room are undocumented.

1. Five-minute measurements can never be useful
2. Annual PUE is always the lowest observed short ratio
3. Calendar duration never matters to energy metrics
4. Its time coverage and aggregation differ

**Correct option(s):** 4

- Option 1: They can describe a bounded operating observation.
- Option 2: That would select a favorable instant rather than aggregate energy.
- Option 3: Energy accumulates over time.
- Option 4: A short power snapshot does not establish annual energy performance.

**CDCS-Q0477 · single · mechanism**

Why does UPS-output versus IT-equipment measurement location matter?

Synthetic training case — not a field record.

Baseline annual facility energy is 2400 MWh and IT energy 1600 MWh. After consolidation, the same complete boundary records 1700 MWh facility and 1000 MWh IT. A separate room reports a five-minute ratio measured at UPS output and calls it directly equivalent to the annual IT-equipment-boundary value. Meter coverage and shared-cooling allocation for that room are undocumented.

1. Only the meter manufacturer affects comparability
2. Every downstream location measures identical energy
3. A closer meter automatically proves zero uncertainty
4. Different downstream losses or loads can lie inside the denominator boundary

**Correct option(s):** 4

- Option 1: Boundary and method also matter.
- Option 2: Losses and included loads can differ.
- Option 3: All measurements have relevant limitations.
- Option 4: Measurement categories must be declared and aligned.

**CDCS-Q0478 · single · operations**

What should be resolved about shared cooling?

Synthetic training case — not a field record.

Baseline annual facility energy is 2400 MWh and IT energy 1600 MWh. After consolidation, the same complete boundary records 1700 MWh facility and 1000 MWh IT. A separate room reports a five-minute ratio measured at UPS output and calls it directly equivalent to the annual IT-equipment-boundary value. Meter coverage and shared-cooling allocation for that room are undocumented.

1. A defensible documented allocation within the selected reporting method
2. Ignore cooling because it is shared
3. Allocate by whichever room has the best publicity value
4. Assign all cooling to another room to improve the ratio

**Correct option(s):** 1

- Option 1: Unowned allocation can distort room-level claims.
- Option 2: Shared service still consumes energy within the relevant boundary.
- Option 3: That is not a technical method.
- Option 4: That hides real overhead.

**CDCS-Q0479 · single · mechanism**

What does PUE leave outside its direct meaning?

Synthetic training case — not a field record.

Baseline annual facility energy is 2400 MWh and IT energy 1600 MWh. After consolidation, the same complete boundary records 1700 MWh facility and 1000 MWh IT. A separate room reports a five-minute ratio measured at UPS output and calls it directly equivalent to the annual IT-equipment-boundary value. Meter coverage and shared-cooling allocation for that room are undocumented.

1. Useful computational output, carbon intensity and water impact
2. The stated reporting interval
3. The arithmetic facility-to-IT energy ratio
4. The need for an IT-energy denominator

**Correct option(s):** 1

- Option 1: Those need additional metrics and boundaries.
- Option 2: The calculation can and should identify it.
- Option 3: That is its defined purpose.
- Option 4: That is part of the metric.

**CDCS-Q0480 · single · operations**

What is the defensible report conclusion?

Synthetic training case — not a field record.

Baseline annual facility energy is 2400 MWh and IT energy 1600 MWh. After consolidation, the same complete boundary records 1700 MWh facility and 1000 MWh IT. A separate room reports a five-minute ratio measured at UPS output and calls it directly equivalent to the annual IT-equipment-boundary value. Meter coverage and shared-cooling allocation for that room are undocumented.

1. The short-period room ratio is the best annual value to publish
2. The project achieved zero carbon emissions
3. Absolute facility and overhead energy fell while the PUE ratio rose
4. The project failed environmentally solely because PUE rose

**Correct option(s):** 3

- Option 1: Its scope is not equivalent.
- Option 2: No emissions data is supplied.
- Option 3: Both observations should be reported with the same boundary.
- Option 4: The ratio alone cannot establish that broad conclusion.

**CDCS-Q0481 · single · calculation**

What is the modeled power ratio?

Synthetic training case — not a field record.

A supplied ideal fan model uses P2/P1=(n2/n1)^3. Baseline fan power is 20 kW; proposed speed ratio is 0.8. Equivalent annual hours are 4000, flat energy charge 0.15 currency/kWh, added maintenance 1000/year and capital cost 50000. Demand charges are excluded. Hottest-rack acceptance and actual fan/system performance are not yet tested.

1. 0.8
2. 0.512
3. 1.25
4. 0.64

**Correct option(s):** 2

- Option 1: That assumes power changes linearly with speed.
- Option 2: 0.8 cubed.
- Option 3: That reverses the speed ratio without applying the model.
- Option 4: That squares rather than cubes the ratio.

**CDCS-Q0482 · single · calculation**

What is proposed fan power under the model?

Synthetic training case — not a field record.

A supplied ideal fan model uses P2/P1=(n2/n1)^3. Baseline fan power is 20 kW; proposed speed ratio is 0.8. Equivalent annual hours are 4000, flat energy charge 0.15 currency/kWh, added maintenance 1000/year and capital cost 50000. Demand charges are excluded. Hottest-rack acceptance and actual fan/system performance are not yet tested.

1. 12.8 kW
2. 39.06 kW
3. 10.24 kW
4. 16 kW

**Correct option(s):** 3

- Option 1: That uses a squared relationship.
- Option 2: That divides baseline power by the ratio.
- Option 3: 20×0.512.
- Option 4: That uses a linear relationship.

**CDCS-Q0483 · single · calculation**

What annual energy reduction follows?

Synthetic training case — not a field record.

A supplied ideal fan model uses P2/P1=(n2/n1)^3. Baseline fan power is 20 kW; proposed speed ratio is 0.8. Equivalent annual hours are 4000, flat energy charge 0.15 currency/kWh, added maintenance 1000/year and capital cost 50000. Demand charges are excluded. Hottest-rack acceptance and actual fan/system performance are not yet tested.

1. 40960 kWh
2. 80000 kWh
3. 39040 kWh
4. 9760 kWh

**Correct option(s):** 3

- Option 1: That is proposed annual consumption, not the reduction.
- Option 2: That is baseline annual consumption.
- Option 3: (20−10.24)×4000.
- Option 4: That uses only 1000 hours.

**CDCS-Q0484 · single · calculation**

What is gross annual energy-charge saving?

Synthetic training case — not a field record.

A supplied ideal fan model uses P2/P1=(n2/n1)^3. Baseline fan power is 20 kW; proposed speed ratio is 0.8. Equivalent annual hours are 4000, flat energy charge 0.15 currency/kWh, added maintenance 1000/year and capital cost 50000. Demand charges are excluded. Hottest-rack acceptance and actual fan/system performance are not yet tested.

1. 39040 currency
2. 5856 currency
3. 1500 currency
4. 4856 currency

**Correct option(s):** 2

- Option 1: That treats kWh as currency without tariff.
- Option 2: 39040×0.15.
- Option 3: That is not the supplied energy-charge product.
- Option 4: That is after added maintenance.

**CDCS-Q0485 · single · calculation**

What is simple payback using net annual saving?

Synthetic training case — not a field record.

A supplied ideal fan model uses P2/P1=(n2/n1)^3. Baseline fan power is 20 kW; proposed speed ratio is 0.8. Equivalent annual hours are 4000, flat energy charge 0.15 currency/kWh, added maintenance 1000/year and capital cost 50000. Demand charges are excluded. Hottest-rack acceptance and actual fan/system performance are not yet tested.

1. Exactly one year
2. Approximately 8.54 years
3. Approximately 0.097 years
4. Approximately 10.30 years

**Correct option(s):** 4

- Option 1: The net saving is far below capital cost.
- Option 2: That ignores added annual maintenance.
- Option 3: That reverses cost and annual saving.
- Option 4: 50000/(5856−1000).

**CDCS-Q0486 · single · operations**

What must be verified before treating the fan-law estimate as installed performance?

Synthetic training case — not a field record.

A supplied ideal fan model uses P2/P1=(n2/n1)^3. Baseline fan power is 20 kW; proposed speed ratio is 0.8. Equivalent annual hours are 4000, flat energy charge 0.15 currency/kWh, added maintenance 1000/year and capital cost 50000. Demand charges are excluded. Hottest-rack acceptance and actual fan/system performance are not yet tested.

1. Only the best one-minute reading
2. Only that the speed command is 80%
3. Only the motor’s rated efficiency at full load
4. Actual fan/system behavior and relevant operating conditions

**Correct option(s):** 4

- Option 1: A selected point does not establish annual operation.
- Option 2: Command does not prove power or airflow response.
- Option 3: The changed fan/system operating point needs its own evidence.
- Option 4: The ideal relationship is conditional.

**CDCS-Q0487 · single · mechanism**

Why is hottest-rack acceptance a prerequisite to the efficiency change?

Synthetic training case — not a field record.

A supplied ideal fan model uses P2/P1=(n2/n1)^3. Baseline fan power is 20 kW; proposed speed ratio is 0.8. Equivalent annual hours are 4000, flat energy charge 0.15 currency/kWh, added maintenance 1000/year and capital cost 50000. Demand charges are excluded. Hottest-rack acceptance and actual fan/system performance are not yet tested.

1. Lower fan power always means lower rack temperature
2. Efficiency targets override equipment limits
3. Reduced flow can violate local thermal service despite energy savings
4. Room averages always guarantee every inlet

**Correct option(s):** 3

- Option 1: Less flow can increase temperature.
- Option 2: Service constraints remain.
- Option 3: The improvement must preserve required conditions.
- Option 4: Local hotspots can differ.

**CDCS-Q0488 · single · mechanism**

What does excluding demand charges mean for the financial claim?

Synthetic training case — not a field record.

A supplied ideal fan model uses P2/P1=(n2/n1)^3. Baseline fan power is 20 kW; proposed speed ratio is 0.8. Equivalent annual hours are 4000, flat energy charge 0.15 currency/kWh, added maintenance 1000/year and capital cost 50000. Demand charges are excluded. Hottest-rack acceptance and actual fan/system performance are not yet tested.

1. Demand charges are zero in every tariff
2. Capital cost is automatically excluded too
3. The result covers the stated energy-charge and maintenance model only
4. The arithmetic cannot be performed at all

**Correct option(s):** 3

- Option 1: The case only excludes them from this model.
- Option 2: It is explicitly used in payback.
- Option 3: It is not a complete bill forecast.
- Option 4: The bounded calculation is still valid.

**CDCS-Q0489 · single · operations**

Which sensitivity could materially change the business case?

Synthetic training case — not a field record.

A supplied ideal fan model uses P2/P1=(n2/n1)^3. Baseline fan power is 20 kW; proposed speed ratio is 0.8. Equivalent annual hours are 4000, flat energy charge 0.15 currency/kWh, added maintenance 1000/year and capital cost 50000. Demand charges are excluded. Hottest-rack acceptance and actual fan/system performance are not yet tested.

1. Only adding more decimal places to payback
2. Actual equivalent hours, tariff and maintenance cost
3. Only shortening the payback label to a rounded integer
4. Only changing the reporting currency symbol without converting values

**Correct option(s):** 2

- Option 1: Precision does not change assumptions.
- Option 2: They directly affect modeled annual net savings.
- Option 3: Rounding does not test uncertainty in the underlying savings.
- Option 4: Relabeling does not test an economic assumption.

**CDCS-Q0490 · single · operations**

What should a controlled trial define before changing speed?

Synthetic training case — not a field record.

A supplied ideal fan model uses P2/P1=(n2/n1)^3. Baseline fan power is 20 kW; proposed speed ratio is 0.8. Equivalent annual hours are 4000, flat energy charge 0.15 currency/kWh, added maintenance 1000/year and capital cost 50000. Demand charges are excluded. Hottest-rack acceptance and actual fan/system performance are not yet tested.

1. Only a plan to keep the lowest-energy result
2. Only a target saving with no thermal stop condition
3. Only a promise to restore settings from memory
4. Baseline, representative conditions, service limits, rollback and authority

**Correct option(s):** 4

- Option 1: Selective reporting hides adverse evidence.
- Option 2: That can sacrifice service to the metric.
- Option 3: Recovery needs a known accepted state.
- Option 4: The trial needs a safe interpretable boundary.

**CDCS-Q0491 · single · calculation**

What is baseline energy per completed task?

Synthetic training case — not a field record.

A baseline workload completes 1000 equivalent quality-accepted tasks using 200 kWh. A proposed platform completes 600 of the same tasks using 180 kWh. Its rack uses a different power/cooling interface that has not been reviewed; the vendor calls it OCP-based. Separately, an occupancy-lighting proposal includes emergency luminaires in the off command and claims cooling savings without a thermal boundary calculation.

1. 0.02 kWh/task
2. 200 kWh/task
3. 5 kWh/task
4. 0.2 kWh/task

**Correct option(s):** 4

- Option 1: That introduces a factor-of-ten error.
- Option 2: That omits the number of tasks.
- Option 3: That reverses energy and task count.
- Option 4: 200/1000.

**CDCS-Q0492 · single · calculation**

What is the proposed platform’s energy per equivalent task?

Synthetic training case — not a field record.

A baseline workload completes 1000 equivalent quality-accepted tasks using 200 kWh. A proposed platform completes 600 of the same tasks using 180 kWh. Its rack uses a different power/cooling interface that has not been reviewed; the vendor calls it OCP-based. Separately, an occupancy-lighting proposal includes emergency luminaires in the off command and claims cooling savings without a thermal boundary calculation.

1. 0.3 kWh/task
2. 0.2 kWh/task
3. 3.333 kWh/task
4. 0.18 kWh/task

**Correct option(s):** 1

- Option 1: 180/600.
- Option 2: That retains the baseline result despite changed output.
- Option 3: That reverses the ratio.
- Option 4: That divides by the old 1000-task count.

**CDCS-Q0493 · single · operations**

What conclusion follows from the two workload runs?

Synthetic training case — not a field record.

A baseline workload completes 1000 equivalent quality-accepted tasks using 200 kWh. A proposed platform completes 600 of the same tasks using 180 kWh. Its rack uses a different power/cooling interface that has not been reviewed; the vendor calls it OCP-based. Separately, an occupancy-lighting proposal includes emergency luminaires in the off command and claims cooling savings without a thermal boundary calculation.

1. PUE must have increased by exactly 0.1
2. The new platform is more efficient solely because 180 is below 200
3. The tasks cannot be compared because the case says they are equivalent
4. Total energy fell but energy per equivalent completed task worsened

**Correct option(s):** 4

- Option 1: No facility-energy data is supplied.
- Option 2: That ignores reduced useful output.
- Option 3: The supplied equivalence supports this bounded comparison.
- Option 4: The functional denominator changed materially.

**CDCS-Q0494 · single · mechanism**

Why require equal quality and service criteria for the functional unit?

Synthetic training case — not a field record.

A baseline workload completes 1000 equivalent quality-accepted tasks using 200 kWh. A proposed platform completes 600 of the same tasks using 180 kWh. Its rack uses a different power/cooling interface that has not been reviewed; the vendor calls it OCP-based. Separately, an occupancy-lighting proposal includes emergency luminaires in the off command and claims cooling savings without a thermal boundary calculation.

1. Otherwise fewer or lower-quality results can distort the efficiency comparison
2. Only the platform’s peak clock rate determines efficiency
3. Task quality never affects useful work
4. Any completed process counts identically regardless of outcome

**Correct option(s):** 1

- Option 1: The useful outcome must be comparable.
- Option 2: Actual accepted work and energy matter.
- Option 3: A failed or inadequate result may not satisfy the service.
- Option 4: The chosen service definition determines the unit.

**CDCS-Q0495 · single · mechanism**

What does OCP-based mean by itself for site compatibility?

Synthetic training case — not a field record.

A baseline workload completes 1000 equivalent quality-accepted tasks using 200 kWh. A proposed platform completes 600 of the same tasks using 180 kWh. Its rack uses a different power/cooling interface that has not been reviewed; the vendor calls it OCP-based. Separately, an occupancy-lighting proposal includes emergency luminaires in the off command and claims cooling savings without a thermal boundary calculation.

1. Guaranteed fit into every conventional rack
2. It is a claim requiring the exact specification, product and interface evidence
3. Automatic facility recognition after purchase
4. Free hardware and indefinite vendor support

**Correct option(s):** 2

- Option 1: Mechanical and electrical interfaces can differ.
- Option 2: The label alone does not establish suitability.
- Option 3: Recognition has its own scope and process.
- Option 4: Open collaboration does not imply those commercial terms.

**CDCS-Q0496 · single · design**

What should the changed rack-interface review include?

Synthetic training case — not a field record.

A baseline workload completes 1000 equivalent quality-accepted tasks using 200 kWh. A proposed platform completes 600 of the same tasks using 180 kWh. Its rack uses a different power/cooling interface that has not been reviewed; the vendor calls it OCP-based. Separately, an occupancy-lighting proposal includes emergency luminaires in the off command and claims cooling savings without a thermal boundary calculation.

1. Mechanical, power, cooling, cabling, service access and supported management lifecycle
2. Only software compatibility without mechanical or power/cooling validation
3. Only the purchase discount
4. Only the number of GPUs

**Correct option(s):** 1

- Option 1: The proposed platform affects several facility interfaces.
- Option 2: A working OS does not establish the changed rack interfaces.
- Option 3: Cost cannot prove compatibility.
- Option 4: Compute count does not define the complete installation needs.

**CDCS-Q0497 · single · mechanism**

Why retain vendor support and spare strategy in an open-hardware evaluation?

Synthetic training case — not a field record.

A baseline workload completes 1000 equivalent quality-accepted tasks using 200 kWh. A proposed platform completes 600 of the same tasks using 180 kWh. Its rack uses a different power/cooling interface that has not been reviewed; the vendor calls it OCP-based. Separately, an occupancy-lighting proposal includes emergency luminaires in the off command and claims cooling savings without a thermal boundary calculation.

1. Every part is interchangeable across all revisions
2. Operational sustainment still needs compatible parts, documentation and lifecycle support
3. Firmware/security lifecycle is irrelevant to physical hardware
4. Open designs can never have commercial support

**Correct option(s):** 2

- Option 1: Compatibility must be verified.
- Option 2: Openness does not eliminate maintenance obligations.
- Option 3: It affects continued safe and supported operation.
- Option 4: Support models vary.

**CDCS-Q0498 · single · diagnosis**

What is the defect in the occupancy-lighting off command?

Synthetic training case — not a field record.

A baseline workload completes 1000 equivalent quality-accepted tasks using 200 kWh. A proposed platform completes 600 of the same tasks using 180 kWh. Its rack uses a different power/cooling interface that has not been reviewed; the vendor calls it OCP-based. Separately, an occupancy-lighting proposal includes emergency luminaires in the off command and claims cooling savings without a thermal boundary calculation.

1. Emergency lighting requirements disappear when the room is empty
2. All lighting must remain at full output forever
3. It includes emergency luminaires without preserving their required function
4. Occupancy control is universally prohibited

**Correct option(s):** 3

- Option 1: Its function is not simply ordinary occupancy lighting.
- Option 2: A reviewed strategy can reduce energy while meeting requirements.
- Option 3: Energy control must respect the accepted life-safety design.
- Option 4: It can be suitable for appropriate circuits and behavior.

**CDCS-Q0499 · single · operations**

What should substantiate equal lighting service after replacement?

Synthetic training case — not a field record.

A baseline workload completes 1000 equivalent quality-accepted tasks using 200 kWh. A proposed platform completes 600 of the same tasks using 180 kWh. Its rack uses a different power/cooling interface that has not been reviewed; the vendor calls it OCP-based. Separately, an occupancy-lighting proposal includes emergency luminaires in the off command and claims cooling savings without a thermal boundary calculation.

1. Only a lower luminaire wattage
2. Required illumination/distribution, task visibility and supported control behavior
3. Only the sum of the replacement luminaires’ catalogue lumens
4. Only identical fixture count

**Correct option(s):** 2

- Option 1: That measures input, not delivered lighting quality.
- Option 2: Lower watts alone do not prove equivalent service.
- Option 3: Total emitted lumens do not establish delivered task illumination, spatial distribution or control behavior.
- Option 4: Different optics and output can change service.

**CDCS-Q0500 · single · operations**

How should secondary cooling savings from lighting be handled?

Synthetic training case — not a field record.

A baseline workload completes 1000 equivalent quality-accepted tasks using 200 kWh. A proposed platform completes 600 of the same tasks using 180 kWh. Its rack uses a different power/cooling interface that has not been reviewed; the vendor calls it OCP-based. Separately, an occupancy-lighting proposal includes emergency luminaires in the off command and claims cooling savings without a thermal boundary calculation.

1. Assume cooling energy falls by exactly the same kWh as lighting in every mode
2. Calculate them within the actual thermal/operating boundary and avoid double counting
3. Add the full lighting saving twice to improve payback
4. Ignore the lighting schedule when estimating heat effects

**Correct option(s):** 2

- Option 1: System efficiency and heat paths differ.
- Option 2: Direct electrical and induced cooling effects are distinct terms.
- Option 3: That double counts the direct reduction.
- Option 4: Timing and conditioned-space operation matter.

#### Recall

**Lower total energy with higher PUE — Synthetic training case — not a field record.

Baseline annual facility energy is 2400 MWh and IT energy 1600 MWh. After consolidation, the same complete boundary records 1700 MWh facility and 1000 MWh IT. A separate room reports a five-minute ratio measured at UPS output and calls it directly equivalent to the annual IT-equipment-boundary value. Meter coverage and shared-cooling allocation for that room are undocumented.**

Baseline PUE is 1.5 and overhead 800 MWh. After consolidation PUE is 1.7 and overhead 700 MWh, with total energy down 700 MWh. The short-period UPS-output figure has a different time/measurement basis and cannot be assumed directly comparable. PUE does not establish workload, water or carbon outcomes.

**A fan-law business case with operating constraints — Synthetic training case — not a field record.

A supplied ideal fan model uses P2/P1=(n2/n1)^3. Baseline fan power is 20 kW; proposed speed ratio is 0.8. Equivalent annual hours are 4000, flat energy charge 0.15 currency/kWh, added maintenance 1000/year and capital cost 50000. Demand charges are excluded. Hottest-rack acceptance and actual fan/system performance are not yet tested.**

Modeled power is 10.24 kW and reduction 9.76 kW. Annual saving is 39040 kWh, worth 5856 before maintenance and 4856 net. Simple payback is about 10.30 years. These are conditional estimates; thermal service, installed behavior and representative operating hours need validation.

**Open hardware, useful work and lighting control — Synthetic training case — not a field record.

A baseline workload completes 1000 equivalent quality-accepted tasks using 200 kWh. A proposed platform completes 600 of the same tasks using 180 kWh. Its rack uses a different power/cooling interface that has not been reviewed; the vendor calls it OCP-based. Separately, an occupancy-lighting proposal includes emergency luminaires in the off command and claims cooling savings without a thermal boundary calculation.**

Energy per task rises from 0.2 to 0.3 kWh despite lower total consumption. OCP terminology does not prove the exact product’s compatibility or support. Review the rack interfaces and operational lifecycle. Lighting controls must preserve required emergency functions, and secondary cooling savings need their own boundary without double counting.

#### References

- [EPI CDCS public syllabus](https://www.epi-ap.com/services/1/3/5)
- [The Green Grid PUE reference hosted by Lawrence Berkeley National Laboratory](https://datacenters.lbl.gov/sites/default/files/WP49-PUE%20A%20Comprehensive%20Examination%20of%20the%20Metric_v6.pdf)
- [Open Compute Project official overview](https://www.opencompute.org/about)
