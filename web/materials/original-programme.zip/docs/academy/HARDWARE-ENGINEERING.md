# HARDWARE-ENGINEERING — Hardware Engineering: Architecture, Integration, Operations and Recovery

Original independent instruction and practice. Read the teaching, work the demonstrations and guided exercise, then attempt questions before reading their explanations. Independent tasks require your own evidence.

Source baseline: [Curriculum Rev14 §09.2: mandatory HW-01 through HW-10](https://www.dmtf.org/standards/redfish) · Curriculum Rev14 / Portfolio v2.5; authored 2026-09-19 · checked 2026-09-19

Original instruction for the ten mandatory hardware outcomes in the retained curriculum. The URL is a technical reference, not a public copy of the private curriculum. This is an engineering extension, not an additional certification or an assertion of practical competence.

## Scope and external requirements

- Exact component compatibility, installation, fault thresholds, hot-swap support and firmware recovery are model-specific and require the applicable OEM documentation.

- Synthetic exercises establish analytical performance only. Real installation, authorized component replacement, supported firmware work and sacrificial-media sanitization require separate observed evidence.

- HW-02: stage and install a real server or storage device and retain approved rack, power, cable and handover evidence.

- HW-03: perform a supported firmware update and test the applicable recovery path on authorized equipment; record unsupported rollback.

- HW-04: configure supported storage and exercise a safe drive/path failure, replacement/rebuild and independent restoration.

- HW-06: execute bounded representative diagnostics against preapproved limits and retest an introduced safe fault.

- HW-08: complete an authorized physical FRU replacement; inaccessible component classes remain open until supervised evidence exists.

- HW-10: execute and validate an approved sanitization method on sacrificial lab media with synthetic data; evidence includes custody and identity removal.

- Study, question scores and offline fixtures do not close these physical gates.

## Preparation

Prior courses: DCCA

- Arithmetic, basic binary/decimal capacity units and elementary host/network administration.

- Appropriate equipment, supervision and authorization for the explicitly identified physical assessments.

## HARDWARE-ENGINEERING-M01 — Server, accelerator and storage architecture

### HARDWARE-ENGINEERING-L01 — CPU execution, memory channels, ECC and NUMA

Estimated study time: 65 minutes before independent work. Prerequisite chapters: Use the course prerequisites.

A server executes instructions against data. Cores issue work, caches retain recently used cache lines, and memory controllers transfer data to and from DRAM. Registers, cache, DRAM and persistent storage have different latency, capacity and persistence. More cores help only when work can execute in parallel and its dependencies can feed those cores. Simultaneous multithreading exposes multiple logical execution contexts within a physical core; it does not duplicate every execution resource. Counting logical processors as independent full-speed cores overstates capacity.

Separate latency, throughput and utilization. A serial transaction may wait on one memory access while aggregate CPU utilization remains low. A batch workload may saturate memory bandwidth before all arithmetic units are busy. A database may appear CPU-limited because threads spin waiting for a contended lock. Measure a representative transaction and its bottleneck before choosing a processor solely by clock speed or core count. As a first approximation, execution time is instruction count multiplied by average cycles per instruction divided by clock frequency. Cache misses, branch behavior and contention change the average cycles; the equation is a model, not a vendor benchmark substitute.

Memory capacity and memory bandwidth are separate design requirements. A channel transfers data independently of other channels. A supported balanced population can use more channels than placing the same capacity in a small number of large DIMMs. DIMMs per channel, rank, speed, processor generation and firmware can constrain the supported operating rate. A slot accepting a module physically does not establish electrical compatibility or a supported population. Use the system's population table, including rules for both processors. Record usable memory after firmware reservations and any resilience mode rather than quoting installed capacity alone.

ECC adds information that permits detection and, within the implemented code's limits, correction of certain memory errors. It does not make every corruption correctable. Corrected and uncorrected events are different observations; counts must be interpreted by component identity, time interval, workload and the OEM service rule. One accumulated corrected count without a sampling interval is not an error rate. Repeated events on the same DIMM location may justify investigation; a processor memory controller, channel connection or firmware defect may create similar symptoms. Preserve detailed address and location information before clearing counters or replacing parts.

In a NUMA machine, memory attached to the local processor can have a different access cost from memory attached to another processor. A task, its memory allocation and its I/O device can land on different nodes. CPU affinity alone does not guarantee that previously allocated pages move with the task. Linux memory policies influence allocation, while cpuset restrictions constrain eligible resources; existing pages require separate consideration. Inspect `lscpu`, `numactl --hardware`, process affinity and the process's NUMA mappings on a suitable lab host. Availability and output vary by platform. These are diagnostic observations, not permission to retune a production workload.

For a conventional monitoring server, begin with required service load, memory working set, data retention, failure tolerance and support period. For an accelerated node, additionally reserve host memory for input staging and operating services; GPU memory is not a transparent substitute for all host RAM. Document expected load and acceptance latency, test a supported population, then compare alternatives under the same workload. Retain a rejected configuration explaining its actual bottleneck, such as capacity meeting the requirement but insufficient active channels. A reviewed choice includes firmware support, power/thermal limits, recovery and spare availability, not just a favorable benchmark.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic two-socket host has 8 memory channels per socket. Proposal A uses two 128 GiB DIMMs on each socket; proposal B uses eight 32 GiB DIMMs on each socket. Both populations are explicitly supported. A measured workload moves 640 GB through DRAM and achieves 80 GB/s on A and 200 GB/s on B.

**Reasoning:** Both provide 512 GiB installed capacity, but B uses more channels. For the measured transfer, A requires 640/80=8 seconds and B 640/200=3.2 seconds, ignoring other work. The 2.5× bandwidth advantage is measured for this workload, not a guarantee for every application. Confirm usable memory, required latency and reliability mode before accepting B.

#### Guided practice

A task is moved from NUMA node 0 to node 1 after allocating its pages on node 0. Explain why latency may rise and design a fair comparison.

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** CPU affinity changed, but existing pages can remain remote. Compare local CPU and local allocation against the existing placement using the same workload, memory pressure and sample length. Inspect page placement and any permitted migration. Do not infer failure from a single CPU percentage.

#### Independent task

Environment: analytical / emulator / physical

Evaluate two supported conventional-server memory populations against capacity, measured bandwidth and failure requirements; explain an ECC trend without assuming every corrected event requires replacement.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Calculate installed and usable capacity separately.
- Identify channel balance and measured bottleneck.
- Propose a discriminating NUMA test and retain alternative fault causes.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0001 · single · implementation**

A server has 32 physical cores and two hardware threads per core. Which planning claim is justified?

Synthetic inventory: two sockets; 32 physical cores total; SMT threads/core=2. Logical contexts share per-core execution resources.

1. Each application necessarily runs twice as fast
2. It exposes 64 logical processors with shared per-core resources
3. It provides 64 fully independent physical cores
4. Only 32 threads can be scheduled at once

**Correct option(s):** 2

- Option 1: Incorrect. Speedup depends on workload and contention.
- Option 2: Correct. Hardware threads do not duplicate all execution resources.
- Option 3: Incorrect. Logical contexts share physical-core facilities.
- Option 4: Incorrect. The OS can schedule across the exposed logical processors.

**HARDWARE-ENGINEERING-Q0002 · single · implementation**

Two supported DIMM populations have equal capacity but different channel balance. What should decide a memory-bound workload's selection?

1. The number of DIMM labels visible in inventory
2. Representative bandwidth and latency testing with the required resilience mode
3. The total processor thread count alone
4. The highest individual DIMM capacity

**Correct option(s):** 2

- Option 1: Incorrect. Labels are not performance measurements.
- Option 2: Correct. Capacity alone does not show data-delivery performance.
- Option 3: Incorrect. Memory access can bottleneck independently of thread count.
- Option 4: Incorrect. Larger DIMMs do not inherently provide more active channels.

**HARDWARE-ENGINEERING-Q0003 · single · diagnosis**

A corrected ECC counter reads 900 after an unknown uptime. What prevents calculating an error rate?

1. The DIMM capacity must equal the error count
2. The measurement interval and counter-reset history are missing
3. Corrected errors never have timestamps
4. ECC counters measure only storage writes

**Correct option(s):** 2

- Option 1: Incorrect. Capacity and event rate are different quantities.
- Option 2: Correct. A cumulative count needs a time basis and identity context.
- Option 3: Incorrect. Many platforms expose time-correlated events.
- Option 4: Incorrect. ECC is associated with protected memory in this case.

**HARDWARE-ENGINEERING-Q0004 · single · implementation**

Moving a running process to another NUMA node increases memory latency. Which observation is most useful?

1. Only aggregate CPU utilization across both sockets
2. Location of the process's existing memory pages
3. Only the process CPU affinity after the move
4. Only the total installed memory capacity

**Correct option(s):** 2

- Option 1: Incorrect. An aggregate percentage can hide remote-memory access.
- Option 2: Correct. CPU movement does not necessarily migrate prior allocations.
- Option 3: Incorrect. CPU placement alone does not show existing page location.
- Option 4: Incorrect. Capacity does not establish where this process has allocated its pages.

**HARDWARE-ENGINEERING-Q0005 · single · implementation**

A DIMM fits mechanically but is absent from the platform's supported population list. What is the defensible decision?

1. Replace the processor before checking the list
2. Accept because capacity is larger
3. Accept if an unrelated server boots with it
4. Hold installation pending verified compatibility and population guidance

**Correct option(s):** 4

- Option 1: Incorrect. No processor fault has been established.
- Option 2: Incorrect. Higher capacity does not establish electrical or firmware compatibility.
- Option 3: Incorrect. Another platform does not validate this one.
- Option 4: Correct. Mechanical fit alone cannot establish support.

**HARDWARE-ENGINEERING-Q0006 · single · implementation**

A workload is demonstrated to be memory-bandwidth limited while average CPU use is 35%. Which proposed change least directly addresses that established bottleneck?

1. Adding cores without changing the constrained memory path
2. Correcting a demonstrated remote-memory placement issue
3. Reducing unnecessary data transfers in the workload
4. Balancing a supported memory population after a measured comparison

**Correct option(s):** 1

- Option 1: Correct. More execution contexts may increase contention without addressing bandwidth.
- Option 2: Incorrect. Locality can address a measured access penalty.
- Option 3: Incorrect. Less transfer demand can address a bandwidth bottleneck.
- Option 4: Incorrect. This directly examines the identified constraint.

**HARDWARE-ENGINEERING-Q0007 · single · diagnosis**

The same DIMM location reports recurring corrected errors. Which conclusion is premature?

1. The existing event evidence should be preserved
2. The DIMM is certainly the sole faulty component
3. The events need location and time correlation
4. The OEM service rule should guide escalation

**Correct option(s):** 2

- Option 1: Incorrect. Replacement or resets can erase useful evidence.
- Option 2: Correct. Controller, channel and firmware causes also need consideration.
- Option 3: Incorrect. This is necessary to interpret the trend.
- Option 4: Incorrect. Model-specific thresholds matter.

**HARDWARE-ENGINEERING-Q0008 · single · implementation**

In the worked case, why is the 2.5-fold bandwidth ratio not a universal application speedup?

1. The smaller DIMMs invalidate all measurements
2. Bandwidth has no relationship to execution time
3. Both populations must always perform identically
4. Other execution and waiting components remain in application time

**Correct option(s):** 4

- Option 1: Incorrect. Both populations were explicitly stated to be supported.
- Option 2: Incorrect. It matters when transfer demand is limiting.
- Option 3: Incorrect. The measured transfer rates differ.
- Option 4: Correct. Only the measured memory-transfer component has that ratio.

#### Recall

**A server has 32 physical cores and two hardware threads per core. Which planning claim is justified?**

It exposes 64 logical processors with shared per-core resources. Correct. Hardware threads do not duplicate all execution resources.

**Two supported DIMM populations have equal capacity but different channel balance. What should decide a memory-bound workload's selection?**

Representative bandwidth and latency testing with the required resilience mode. Correct. Capacity alone does not show data-delivery performance.

**A corrected ECC counter reads 900 after an unknown uptime. What prevents calculating an error rate?**

The measurement interval and counter-reset history are missing. Correct. A cumulative count needs a time basis and identity context.

**Moving a running process to another NUMA node increases memory latency. Which observation is most useful?**

Location of the process's existing memory pages. Correct. CPU movement does not necessarily migrate prior allocations.

**A DIMM fits mechanically but is absent from the platform's supported population list. What is the defensible decision?**

Hold installation pending verified compatibility and population guidance. Correct. Mechanical fit alone cannot establish support.

#### References

- [Linux kernel: NUMA memory policy](https://docs.kernel.org/admin-guide/mm/numa_memory_policy.html)

### HARDWARE-ENGINEERING-L02 — Accelerators, PCIe topology and data movement

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L01

A GPU accelerates suitable parallel work but still depends on the host, device memory and transfer paths. Host software prepares inputs, the driver submits work, the accelerator executes kernels, and results move to their consumers. A device can be underutilized because it is waiting for storage or host preprocessing. High utilization does not establish useful throughput when kernels repeatedly move data or wait on communication. Define the application result, such as samples completed per second at a specified accuracy and input size, before comparing nodes.

Device memory stores the active accelerator working set. Capacity limits may be reached even when arithmetic capacity is available. Account for model weights, intermediate tensors, optimizer state where relevant, communication buffers and runtime reservations. Precision and implementation change these requirements. Do not assume that adding host memory makes an oversized device working set perform adequately through paging. A model that fits on one device can still need a different topology to meet its latency or recovery requirement. Partitioning features, peer access and their isolation properties are model- and software-specific.

PCIe connects devices through lanes, ports, bridges and switches. A mechanical x16 slot may be wired with fewer lanes. Link generation and negotiated width jointly determine its signaling capability; the endpoint, riser, slot and root complex all constrain the result. Link negotiation can reduce speed or width for a supported configuration or because of signal integrity and seating problems. Inspect both capability and current link status under the approved workload, since platform power management can affect reported speed at idle. A capability field is not proof of the current transfer rate.

For PCIe generations using 128b/130b encoding, a useful pre-protocol-overhead upper bound is transfers per second × lanes ×128/130 ÷8 bytes per byte conversion. At 16 GT/s across eight lanes this is about 15.75 GB/s in each direction. Transaction headers, flow control, packet size, contention and software reduce useful payload throughput. This formula must not be extended blindly to generations with different encoding or signaling. Compare workload direction correctly: combining transmit and receive figures can exaggerate capacity available to a one-way transfer.

Topology matters beyond the slot. Two devices behind one switch may share its upstream link. A NIC attached to one CPU and a GPU attached to another can send data over an inter-socket connection. Peer-to-peer or direct-memory access optimizations require platform, driver and application support; a cabling diagram alone does not prove the traffic uses the desired path. An IOMMU translates and restricts device DMA mappings; enabling passthrough without reviewing isolation groups and ownership can undermine the intended boundary. A DPU or accelerator with its own firmware adds a management and recovery dependency.

Bring a topology hypothesis to commissioning. Correlate the physical slot, PCI bus address, stable device UUID, firmware and driver. On an authorized Linux lab, `lspci -tv` displays a topology view and `lspci -vv` provides detailed capability/status fields. NVIDIA systems can expose device identities and topology through supported `nvidia-smi` options; their availability and output vary. Record serial or UUID identity because enumeration indexes can change between boots. Measure host-to-device, device-to-host and relevant peer paths separately with bounded representative data. Diagnose reduced width, insufficient buffers, NUMA distance, software mismatch and thermal/power limits as distinct hypotheses before replacing a costly accelerator.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic GPU advertises PCIe 16 GT/s x16 but reports 16 GT/s x8. Its approved slot is wired x8. A 20 GB one-way transfer is requested.

**Reasoning:** The x8 pre-protocol upper bound is 16×8×128/130÷8≈15.75 GB/s. The transfer cannot complete faster than roughly 20/15.75=1.27 seconds on that path, before software and protocol overhead. The width agrees with the approved slot wiring, so this observation alone is not a defective GPU. An x16-capable alternative must also have a suitable root path and approved power/cooling.

#### Guided practice

Two GPUs can each transfer at 14 GB/s alone but together total only 15 GB/s. Form a testable explanation.

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** A shared upstream link may cap aggregate transfer. Inspect the bridge tree and negotiated upstream capacity, then compare concurrent and isolated transfers with the same buffers and CPU placement. Other candidates include host-memory bandwidth or software serialization.

#### Independent task

Environment: analytical / emulator / physical

Compare an accelerated-node topology proposal against a latency target, GPU-memory requirement, lane budget and surviving facility capacity.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Calculate a qualified transfer bound with explicit encoding assumptions.
- Identify shared root and switch paths.
- Explain why device presence is weaker evidence than representative application acceptance.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0009 · single · implementation**

A mechanical x16 connector currently negotiates x8. Which additional fact can establish that this is expected?

Synthetic slot record: endpoint capability x16; approved slot wiring x8; current link 16 GT/s x8.

1. The approved slot is electrically wired x8
2. A different x16 slot on another host negotiates x16
3. The endpoint capability field also lists x16
4. The operating system recognizes the GPU driver

**Correct option(s):** 1

- Option 1: Correct. Mechanical length and electrical lane count differ.
- Option 2: Incorrect. Another slot does not define this slot's electrical wiring.
- Option 3: Incorrect. Endpoint capability does not establish the slot wiring.
- Option 4: Incorrect. Recognition does not establish the negotiated lane requirement.

**HARDWARE-ENGINEERING-Q0010 · single · implementation**

Which value best identifies a GPU consistently across reboots?

1. Its instantaneous utilization percentage
2. Its current list index zero
3. The first process ID using it
4. Its supported stable UUID correlated with physical inventory

**Correct option(s):** 4

- Option 1: Incorrect. A measurement is not an identity.
- Option 2: Incorrect. Ordering is not guaranteed stable.
- Option 3: Incorrect. Process IDs are temporary.
- Option 4: Correct. Enumeration indexes can change.

**HARDWARE-ENGINEERING-Q0011 · single · implementation**

Two GPUs share an upstream switch link. What must an aggregate bandwidth claim include?

1. The capacity and contention of the shared upstream path
2. Only each endpoint's isolated transfer benchmark
3. Only the sum of endpoint nameplate rates
4. Only total GPU memory capacity

**Correct option(s):** 1

- Option 1: Correct. Endpoint link rates can exceed shared capacity.
- Option 2: Incorrect. Concurrent traffic can hit a shared limit absent from isolated tests.
- Option 3: Incorrect. This ignores oversubscription upstream.
- Option 4: Incorrect. Capacity does not establish transfer bandwidth.

**HARDWARE-ENGINEERING-Q0012 · single · implementation**

A model exceeds available accelerator memory although host RAM is ample. Which assumption is unsafe?

1. The active device working set should be measured
2. An alternative partitioning strategy needs validation
3. Precision and runtime allocation affect capacity
4. Host RAM automatically provides equivalent accelerator-memory performance

**Correct option(s):** 4

- Option 1: Incorrect. Reservations and intermediate data matter.
- Option 2: Incorrect. It can change performance and behavior.
- Option 3: Incorrect. They change the required bytes.
- Option 4: Correct. Off-device movement can impose major latency and bandwidth costs.

**HARDWARE-ENGINEERING-Q0013 · single · implementation**

A PCIe upper bound excludes packet and software overhead. How should it be used?

1. As guaranteed application throughput
2. As a ceiling for the stated link assumptions, not promised payload throughput
3. As the GPU's memory capacity
4. As proof that all generations use the same encoding

**Correct option(s):** 2

- Option 1: Incorrect. The excluded overhead and other bottlenecks prevent that claim.
- Option 2: Correct. Useful throughput is lower and workload-dependent.
- Option 3: Incorrect. It measures transfer rate rather than storage space.
- Option 4: Incorrect. Encoding assumptions differ by generation.

**HARDWARE-ENGINEERING-Q0014 · single · implementation**

A GPU remains mostly idle while host preprocessing is saturated. Which first investigation follows the data path?

1. Double the device count immediately
2. Replace GPU memory solely because utilization is low
3. Disable error reporting to reduce idle time
4. Measure input preparation and delivery before replacing the GPU

**Correct option(s):** 4

- Option 1: Incorrect. More devices can worsen starvation.
- Option 2: Incorrect. The observation points to an upstream constraint.
- Option 3: Incorrect. Reporting is not the demonstrated bottleneck.
- Option 4: Correct. An accelerator cannot process work that has not arrived.

**HARDWARE-ENGINEERING-Q0015 · single · implementation**

Why must device DMA isolation be reviewed before passthrough?

1. Assigning a device to a guest automatically isolates every sibling function
2. Device enumeration alone proves the intended DMA mappings
3. DMA access is automatically limited by guest filesystem permissions
4. Device access mappings and grouping affect ownership boundaries

**Correct option(s):** 4

- Option 1: Incorrect. Isolation depends on the platform, grouping and supported ownership.
- Option 2: Incorrect. Presence does not validate memory-access mappings.
- Option 3: Incorrect. Device memory access boundaries are not established by filesystem ACLs.
- Option 4: Correct. IOMMU behavior and platform topology matter.

**HARDWARE-ENGINEERING-Q0016 · single · implementation**

A GPU link is slower only at idle and reaches the approved speed under load. What is the strongest conclusion?

1. Power-state behavior may explain the idle report; validate against the platform specification
2. The slot is certainly permanently limited to the idle speed
3. The accelerator must be replaced immediately
4. All low-speed reports can always be ignored

**Correct option(s):** 1

- Option 1: Correct. An idle snapshot alone does not establish a permanent link fault.
- Option 2: Incorrect. The loaded observation contradicts a permanent idle-speed ceiling.
- Option 3: Incorrect. The loaded result contradicts a persistent speed reduction.
- Option 4: Incorrect. Some are actual degraded links.

#### Recall

**A mechanical x16 connector currently negotiates x8. Which additional fact can establish that this is expected?**

The approved slot is electrically wired x8. Correct. Mechanical length and electrical lane count differ.

**Which value best identifies a GPU consistently across reboots?**

Its supported stable UUID correlated with physical inventory. Correct. Enumeration indexes can change.

**Two GPUs share an upstream switch link. What must an aggregate bandwidth claim include?**

The capacity and contention of the shared upstream path. Correct. Endpoint link rates can exceed shared capacity.

**A model exceeds available accelerator memory although host RAM is ample. Which assumption is unsafe?**

Host RAM automatically provides equivalent accelerator-memory performance. Correct. Off-device movement can impose major latency and bandwidth costs.

**A PCIe upper bound excludes packet and software overhead. How should it be used?**

As a ceiling for the stated link assumptions, not promised payload throughput. Correct. Useful throughput is lower and workload-dependent.

#### References

- [Linux kernel: PCI error recovery](https://docs.kernel.org/PCI/pci-error-recovery.html)
- [NVIDIA System Management Interface documentation](https://docs.nvidia.com/deploy/nvidia-smi/index.html)

### HARDWARE-ENGINEERING-L03 — NICs, HBAs, DPUs and a defensible configuration/BOM

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L02

A network interface converts host data structures into frames and handles queues, DMA and offloads. Its line rate is one boundary, not the whole service. Packet size, interrupt moderation, queue count, CPU affinity, offload support and application behavior affect throughput and latency. A 100 Gb/s line rate corresponds to 12.5 GB/s before framing and protocol overhead; it does not promise 12.5 GB/s of application data. At small packet sizes the packets-per-second requirement may dominate. A link that is up can still experience errors, pause-induced stalls, dropped queues or an MTU mismatch.

An HBA connects a host to a storage transport and often exposes disks or fabric targets without the same virtual-disk abstraction as a hardware RAID controller. Product terminology varies, so verify actual mode and support. A NIC used for IP storage participates in both host networking and storage dependencies. A DPU combines specialized processing and interfaces; it may offload networking or security, but also brings its own operating image, accounts, firmware and recovery. Record whether the host, BMC or DPU owns each configuration and credential. A host OS reinstall may not reset the separate processor.

The supported combination is a matrix: server model and revision; CPU and memory population; riser and slot wiring; NIC/HBA/GPU part and firmware; boot/storage controller mode; OS and kernel; driver; optics/cables; management firmware; power and cooling. Compatibility statements apply to combinations and release conditions. A part sharing a marketing family name is not necessarily an interchangeable FRU. Keep the full part identifier, revision, support source and checked date. Unsupported combinations can create intermittent behavior that a brief boot test misses.

Turn requirements into independently testable constraints. Separate capacity, throughput, latency, fault tolerance, recoverability, security, support term, physical dimensions and facility demand. If the workload requires service after one feed failure, verify both electrical-path assignment and single surviving PSU capacity at the relevant derating conditions. If a storage path must survive adapter failure, two ports on one adapter may not meet that requirement. Spares must cover the actual supported part classes and their replenishment time. A low purchase price can be defeated by an unsupported part or a recovery delay beyond the permitted outage.

A BOM is more than a shopping list. Each line needs quantity, identifier, role, compatibility evidence, location or allocation, spare strategy and acceptance check. Conventional and accelerated nodes can share operating methods but differ sharply in power density, airflow, liquid connections, memory topology and firmware coupling. Reject proposals against the same written requirements used to accept alternatives. Avoid moving the goalposts after discovering the favored configuration fails. Keep trade-offs explicit: reduced throughput under a failure may be acceptable if the service requirement permits it, but must be measured and stated.

Commissioning reconciles the design with what was delivered. Match receiving serials to BMC inventory, OS enumeration and rack labels. An inventory mismatch can be a transcription error, wrong replacement, stale management cache or unexpected hardware; investigate before declaring malicious substitution or silently editing the record. Capture raw observations with timestamps and device identity. The final review states which requirements are satisfied, which remain untested, and which are formally accepted exceptions. Equipment integration ends with a supported, recoverable system and evidence of the required service, not with a successful power-on alone.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic service needs 20 Gb/s after any single adapter failure. Proposal A has one dual-port 25 Gb/s NIC. Proposal B has two supported 25 Gb/s NICs in separate approved slots and independent upstream paths; each path is tested at 22 Gb/s application throughput.

**Reasoning:** A can survive a port/cable failure but not loss of its sole adapter, so it fails the stated adapter-failure requirement. B has demonstrated sufficient throughput on either surviving path, subject to host, switching and failover configuration tests. Compare support and shared-root dependencies before acceptance. Do not add the two line rates and call that a failover result.

#### Guided practice

An approved BOM calls for HBA firmware F3 and driver D7. A supplier delivers F4, whose support table requires D8 unavailable on the approved OS. Write a disposition.

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** Hold the unsupported combination. Obtain a supported firmware/driver/OS combination and its recovery plan or formally review a different configuration. A higher version number does not override the matrix. Preserve receiving identity and the exception.

#### Independent task

Environment: analytical / emulator / physical

Produce conventional and accelerated node BOMs with one rejected plausible alternative each, including NIC/HBA/DPU dependencies, spare classes and facility constraints.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Apply the same requirements to accepted and rejected options.
- Verify exact identifiers and supported combinations.
- Test surviving-path service and reconcile installed inventory.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0017 · single · implementation**

A dual-port NIC is the only adapter in a host. Which failure remains shared by both ports?

Synthetic service requirement: survive any single host-adapter failure. Installed: one dual-port NIC, two cables, two upstream switches.

1. Failure of one external cable necessarily removes both ports
2. Failure of the adapter itself
3. Failure of one remote switch necessarily destroys the NIC
4. Loss of one connector necessarily corrupts both firmware images

**Correct option(s):** 2

- Option 1: Incorrect. Separate cables can fail independently.
- Option 2: Correct. Port diversity does not provide adapter diversity.
- Option 3: Incorrect. A remote switch fault does not imply adapter destruction.
- Option 4: Incorrect. That relationship is not established.

**HARDWARE-ENGINEERING-Q0018 · single · implementation**

A 100 Gb/s NIC specification is converted to bytes per second. What is the pre-overhead rate?

1. 12.5 GiB/s exactly
2. 12.5 GB/s
3. 100 GB/s
4. 800 GB/s

**Correct option(s):** 2

- Option 1: Incorrect. Decimal gigabits do not convert to the same binary unit value.
- Option 2: Correct. Eight bits form a byte; protocol overhead still reduces payload.
- Option 3: Incorrect. This treats bits as bytes.
- Option 4: Incorrect. This multiplies where division is required.

**HARDWARE-ENGINEERING-Q0019 · single · implementation**

A newer NIC firmware requires a driver unavailable on the approved OS. What should govern the change?

1. The verified supported combination and recovery path
2. The fact that the adapter fits the riser
3. The firmware's larger version number
4. A successful idle link test with the old driver

**Correct option(s):** 1

- Option 1: Correct. Version order alone does not establish compatibility.
- Option 2: Incorrect. Mechanical compatibility is only one requirement.
- Option 3: Incorrect. Newer can still be unsupported in this combination.
- Option 4: Incorrect. A brief link test does not override the unsupported combination.

**HARDWARE-ENGINEERING-Q0020 · single · implementation**

Why can reinstalling the host OS leave a DPU security issue unresolved?

1. A host OS reinstall always destroys every firmware image
2. DPUs have no administrative interfaces
3. The DPU may have separate firmware, identities and configuration
4. The host package reinstall necessarily replaces the DPU operating image

**Correct option(s):** 3

- Option 1: Incorrect. Firmware generally has separate persistence.
- Option 2: Incorrect. Their interfaces and ownership must be reviewed.
- Option 3: Correct. It is a distinct management and recovery component.
- Option 4: Incorrect. Separate processors can retain their own image and state.

**HARDWARE-ENGINEERING-Q0021 · single · implementation**

Two proposals are being compared. Which practice makes the selection defensible?

1. Choose the higher peak rate without testing the required failure state
2. Evaluate both against the same predeclared service and support requirements
3. Waive the losing proposal's strongest requirement after scoring
4. Use peak throughput as the only acceptance criterion

**Correct option(s):** 2

- Option 1: Incorrect. Peak normal-state performance does not establish surviving service.
- Option 2: Correct. Changing criteria to favor one proposal weakens the decision.
- Option 3: Incorrect. That changes the basis of comparison.
- Option 4: Incorrect. Recovery, compatibility and other constraints remain.

**HARDWARE-ENGINEERING-Q0022 · single · implementation**

BMC inventory disagrees with receiving records. What is the best immediate action?

1. Reconcile physical identity and fresh management/host observations
2. Declare a supply-chain compromise as a proven fact
3. Ignore inventory because the OS boots
4. Edit the records to agree without checking hardware

**Correct option(s):** 1

- Option 1: Correct. Several legitimate or adverse causes are possible.
- Option 2: Incorrect. The mismatch alone is insufficient proof.
- Option 3: Incorrect. Booting does not establish delivered configuration.
- Option 4: Incorrect. That hides an unresolved discrepancy.

**HARDWARE-ENGINEERING-Q0023 · single · implementation**

A spare has the same family name but a different unverified revision. Which decision is justified?

1. Treat every family member as identical
2. Count it as usable because its box is unopened
3. Remove the existing working part to discover compatibility
4. Verify exact FRU compatibility before accepting it as a recovery spare

**Correct option(s):** 4

- Option 1: Incorrect. Revisions and supported combinations can differ.
- Option 2: Incorrect. Packaging does not establish compatibility.
- Option 3: Incorrect. An avoidable disruptive trial is not the first evidence source.
- Option 4: Correct. Family branding does not prove interchangeability.

**HARDWARE-ENGINEERING-Q0024 · single · implementation**

Which result is stronger than a successful power-on for a new server?

1. A photograph of the front panel alone
2. Verified representative service behavior under its required surviving-path state
3. A supplier's undated marketing slide
4. A blank acceptance sheet with an asset number

**Correct option(s):** 2

- Option 1: Incorrect. It does not prove capacity, integrity or recovery.
- Option 2: Correct. Power-on establishes only a limited initial condition.
- Option 3: Incorrect. It is not evidence of the installed system.
- Option 4: Incorrect. Identity alone is not acceptance evidence.

#### Recall

**A dual-port NIC is the only adapter in a host. Which failure remains shared by both ports?**

Failure of the adapter itself. Correct. Port diversity does not provide adapter diversity.

**A 100 Gb/s NIC specification is converted to bytes per second. What is the pre-overhead rate?**

12.5 GB/s. Correct. Eight bits form a byte; protocol overhead still reduces payload.

**A newer NIC firmware requires a driver unavailable on the approved OS. What should govern the change?**

The verified supported combination and recovery path. Correct. Version order alone does not establish compatibility.

**Why can reinstalling the host OS leave a DPU security issue unresolved?**

The DPU may have separate firmware, identities and configuration. Correct. It is a distinct management and recovery component.

**Two proposals are being compared. Which practice makes the selection defensible?**

Evaluate both against the same predeclared service and support requirements. Correct. Changing criteria to favor one proposal weakens the decision.

#### References

- [Dell PowerEdge R760 Installation and Service Manual: illustrative OEM source; use the manual for the actual selected model](https://www.dell.com/support/manuals/en-us/poweredge-r760/per760_ism_pub/about-this-document?guid=guid-bf9eed9e-52b2-4860-911b-954e25631b96&lang=en-us)

## HARDWARE-ENGINEERING-M02 — Receiving, rack integration and physical deployment

### HARDWARE-ENGINEERING-L04 — Receiving, staging, ESD and physical installation planning

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L03

Receiving starts before equipment enters a rack. Compare shipment, purchase order, model, serials and accessory list; record packaging damage, shock indicators when supplied, seals and exceptions. A damaged package is evidence to investigate, not proof that a component is functional or failed. Keep uncertain equipment in a controlled staging state until the receiving disposition is approved. Preserve provenance records and avoid powering wet, damaged or suspect equipment merely to see whether it works. The model's receiving and installation procedure controls the actual assessment.

Stage a coherent installation kit: compatible rails and cable-management parts, approved cords, labels, optics, blanks, grounding or bonding accessories where specified, and any platform-specific cooling interfaces. Inspect connectors, fasteners and contamination using the approved method. A rail kit that can be forced into place may have the wrong load rating or depth range. Equipment width alone is not a complete rack compatibility check; verify mounting pattern, usable depth, door clearance, service space, weight, load distribution and access for replacement.

Electrostatic discharge can damage sensitive electronics without producing an immediate visible failure. Establish the approved ESD-controlled work arrangement before handling exposed components. Use qualified ESD equipment and the correct bonding arrangement for the work area; do not improvise a connection to a hazardous conductor. Handle boards by the permitted edges or carriers, keep contacts protected and retain protective packaging for approved return. An ESD wrist strap does not make energized electrical work safe, and it is not a substitute for isolating hazardous energy when the procedure requires it.

Lifting and rack stability are separate from electronic compatibility. Obtain device mass including the installed configuration, the specified number of people or lifting equipment, and the rack's stabilization instructions. Identify center-of-gravity changes when drawers or servers extend. Heavy equipment generally requires careful low-position planning, but the approved rack design and service instructions decide the actual placement. Do not infer that an empty upper rack position is suitable because the server's height fits. Document how equipment reaches its final location, including doorways, floor capacity interfaces and temporary staging loads coordinated with facilities.

The installation method states prerequisites, sequence, roles, hold points, stop conditions and handover tests. Prerequisites include verified identity, compatible parts, safe access, approved rack elevation and confirmed facility readiness. Hold points should occur before irreversible or hazardous transitions, such as energization or a qualified coolant connection. A reviewer must be able to identify a deliberately wrong arrangement on paper—wrong rail, blocked service clearance, unsupported lifting method or power cords assigned to the same path—without executing it.

After installation, reconcile the physical position and cabling against the record. Capture readable identifiers and connection endpoints; photographs supplement the record but should not expose credentials or confidential screens. Check that cable-management motion and service access remain within the manufacturer's instructions. Remove packaging and loose materials from airflow paths. Handover includes inspection and the applicable power/management/health tests. This chapter's analytical exercise prepares the method review, but HW-02 requires an actual authorized server or storage installation observed and recorded; a virtual rack drawing cannot satisfy that physical requirement.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic delivery contains the correct server but rails rated for a shorter chassis, a cracked front carrier and two identical unlabeled power cords. The installer proposes installing first and documenting later.

**Reasoning:** Hold installation. Correct server identity does not resolve rail compatibility or damage disposition. Verify the proper rail kit and inspect/dispose of the carrier through the approved process. Establish cord identity and path labels before connection. Record the reviewed installation method and receiving exceptions, then proceed only when prerequisites are satisfied.

#### Guided practice

A 2U server fits the available height but obstructs rear service clearance. Explain why the rack-elevation drawing alone is insufficient.

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** Height allocation does not prove depth, door movement, connector bend radius or component removal clearance. Add rear and front access dimensions and the OEM service envelope to the physical review.

#### Independent task

Environment: analytical / emulator / physical

Review a deliberately flawed installation method, then complete an authorized real installation with an observer when equipment access exists.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Identify identity, damage, rail, lifting and clearance hold points.
- Retain serial-linked rack/cable/power records and handover results.
- Keep the physical requirement open until the real installation is evidenced.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0025 · single · implementation**

A server fits the rack's available height but its rails are for another chassis depth. What should happen?

1. Hold installation until exact rail compatibility is established
2. Install it temporarily and omit the mismatch from handover
3. Force the rails to the nearest hole
4. Use only the front screws as a substitute

**Correct option(s):** 1

- Option 1: Correct. Height fit does not prove support or load rating.
- Option 2: Incorrect. Temporary use does not remove the unresolved risk.
- Option 3: Incorrect. Mechanical modification can invalidate support and safety.
- Option 4: Incorrect. The approved load-support method is missing.

**HARDWARE-ENGINEERING-Q0026 · single · implementation**

A shipment has damaged packaging but no visible chassis damage. What does that establish?

1. Provenance checks are no longer needed
2. The server is certainly undamaged
3. A receiving exception requiring the approved inspection and disposition
4. The server is certainly destroyed

**Correct option(s):** 3

- Option 1: Incorrect. Identity and shipment verification remain required.
- Option 2: Incorrect. Hidden damage remains possible.
- Option 3: Correct. Packaging evidence alone does not prove internal health.
- Option 4: Incorrect. The observation does not establish internal failure.

**HARDWARE-ENGINEERING-Q0027 · single · implementation**

What does an ESD wrist strap fail to authorize?

1. Following the platform's handling procedure
2. Approved handling of sensitive components in a suitable ESD setup
3. Work on hazardous energized circuitry
4. Use of protective component packaging

**Correct option(s):** 3

- Option 1: Incorrect. The procedure still governs the work.
- Option 2: Incorrect. That is the intended context.
- Option 3: Correct. ESD control is not electrical energy isolation or authorization.
- Option 4: Incorrect. Packaging complements handling controls.

**HARDWARE-ENGINEERING-Q0028 · single · implementation**

Which rack-installation fact is missing from a height-only elevation?

1. The equipment service envelope and usable depth
2. The allocated rack-unit positions
3. The number of occupied vertical units
4. The intended front-panel height

**Correct option(s):** 1

- Option 1: Correct. Vertical space is only one physical constraint.
- Option 2: Incorrect. Those are the information a height elevation provides.
- Option 3: Incorrect. That can be read from the elevation.
- Option 4: Incorrect. That is represented vertically.

**HARDWARE-ENGINEERING-Q0029 · single · implementation**

A reviewer identifies an unsafe lifting step in a proposed method. What evidence is required before correcting it?

1. A live demonstration of the unsafe step
2. Removal of all weight information from the plan
3. A faster schedule with the same step
4. A revised approved method with suitable personnel or lifting equipment

**Correct option(s):** 4

- Option 1: Incorrect. Deliberate unsafe execution is unnecessary.
- Option 2: Incorrect. That hides the basis for handling decisions.
- Option 3: Incorrect. Schedule pressure does not make the method suitable.
- Option 4: Correct. The flaw can be rejected without executing it.

**HARDWARE-ENGINEERING-Q0030 · single · implementation**

Why should receiving serials be retained through installation?

1. They replace every functional acceptance test
2. They prove all future replacement parts are compatible
3. They eliminate the need for warranty records
4. They connect provenance, physical location and later management identity

**Correct option(s):** 4

- Option 1: Incorrect. Identity does not establish performance.
- Option 2: Incorrect. Each replacement still needs verification.
- Option 3: Incorrect. Support terms are separate evidence.
- Option 4: Correct. Traceability depends on the same asset being followed.

**HARDWARE-ENGINEERING-Q0031 · single · implementation**

A virtual rack model has passed review. Has HW-02's physical installation requirement been completed?

1. Yes, if the model contains photographs from another site
2. Yes, because every physical action is equivalent to a drawing
3. No; an authorized real installation with retained evidence is still required
4. Only the number of questions answered decides this

**Correct option(s):** 3

- Option 1: Incorrect. Unrelated images do not prove the learner's work.
- Option 2: Incorrect. Handling and installation are distinct skills.
- Option 3: Correct. Analytical planning does not demonstrate physical execution.
- Option 4: Incorrect. Question scores do not establish physical evidence.

**HARDWARE-ENGINEERING-Q0032 · single · implementation**

A cable arm works when closed but strains connectors as the server extends. What should the handover conclude?

1. Accept because the server boots while closed
2. Hold acceptance until routing and motion meet the approved service instructions
3. Approve operation only while closed without reviewing future service access
4. Remove strain-relief parts without review

**Correct option(s):** 2

- Option 1: Incorrect. Normal boot does not validate maintenance access.
- Option 2: Correct. Service movement is part of installation suitability.
- Option 3: Incorrect. The installation still fails the stated service-motion requirement.
- Option 4: Incorrect. That may worsen mechanical stress.

#### Recall

**A server fits the rack's available height but its rails are for another chassis depth. What should happen?**

Hold installation until exact rail compatibility is established. Correct. Height fit does not prove support or load rating.

**A shipment has damaged packaging but no visible chassis damage. What does that establish?**

A receiving exception requiring the approved inspection and disposition. Correct. Packaging evidence alone does not prove internal health.

**What does an ESD wrist strap fail to authorize?**

Work on hazardous energized circuitry. Correct. ESD control is not electrical energy isolation or authorization.

**Which rack-installation fact is missing from a height-only elevation?**

The equipment service envelope and usable depth. Correct. Vertical space is only one physical constraint.

**A reviewer identifies an unsafe lifting step in a proposed method. What evidence is required before correcting it?**

A revised approved method with suitable personnel or lifting equipment. Correct. The flaw can be rejected without executing it.

#### References

- [Dell PowerEdge R760 Installation and Service Manual: illustrative OEM source; use the manual for the actual selected model](https://www.dell.com/support/manuals/en-us/poweredge-r760/per760_ism_pub/about-this-document?guid=guid-bf9eed9e-52b2-4860-911b-954e25631b96&lang=en-us)

### HARDWARE-ENGINEERING-L05 — Rack power, airflow, cabling and liquid-cooling interfaces

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L04

Map every server power inlet to a named rack outlet, branch and upstream path. Two cords are not two independent supplies if they share the same upstream point relevant to the failure requirement. Dual power supplies can share load, operate with a preferred supply or use other supported modes. The surviving unit must support the required server load under the stated conditions. Nameplate wattage, measured input and configured power cap answer different questions. A low idle reading does not establish the worst-case rack or failover demand.

Calculate the rack's normal and failure states explicitly. Sum simultaneous input demand using documented workload assumptions, then trace how load redistributes after a feed or supply failure. Compare the appropriate current and power limits, including equipment ratings and site rules supplied by qualified facilities staff. Do not invent a universal continuous-load percentage for every jurisdiction and device. Identify inlet voltage, phase arrangement and power factor where the conversion requires them. Rack-level acceptance requires agreement with the electrical design and approved power-path assignment; IT staff should not modify protective devices to make a configuration fit.

Air-cooled servers need the intended inlet conditions and an unobstructed internal flow path. Match chassis airflow direction to the rack design. Cable bundles, open gaps, missing blanks or an incorrectly fitted component can alter flow or create recirculation. A cold supply-air reading elsewhere in the room does not prove the inlet of the uppermost server is acceptable. Record inlet conditions at the relevant locations during the representative workload and failure state. Internal fan speed is a response variable: high speed can indicate heat demand, airflow restriction, an unsupported component or a control fallback.

Liquid-cooled equipment still has multiple heat and power paths. Some components remain air-cooled. Verify the approved fluid, connection type, supply conditions, cleanliness, flow range, pressure constraints, condensation control and leak-detection interface against the actual equipment and facility design. Those values cannot be guessed from another model. Qualified authorized personnel perform connections and leak checks using the approved procedure. An IT handover should confirm the documented readiness and alarms without asking an unqualified learner to open a pressurized circuit. A leak-detection alarm also needs an approved response that coordinates workload and facilities states.

Cabling has physical and logical identities. Label both ends with stable identifiers and retain switch/patch/port relationships. Keep management, storage and production service paths distinguishable in the record. Verify optic and cable compatibility, supported length, bend radius and service slack. Do not use a successful link light as the sole test: negotiated speed, error counters, expected VLAN or fabric membership and service reachability matter. Management connectivity must follow the restricted OOB design; a convenient temporary production-network connection can create a long-lived exposure if not removed.

Handover proves the integrated installation. Reconcile rack elevation, asset identity, power paths, cooling readiness, cable map and management access. Exercise only approved failure or transfer tests with defined abort conditions and observe actual service impact. A result can be 'accepted for normal operation but failure-state verification pending' if the governance process permits that status; it cannot silently become full resilience acceptance. Retain the exact state tested, including removed components, capped workload, ambient condition and temporary jumpers. The record should let another engineer reproduce the reasoning and identify what remains unproven.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic rack has six nodes drawing 1.2 kW each. Each node has two 1.6 kW PSUs and separate A/B feeds. In the tested sharing mode, each feed carries 3.6 kW normally. The stated allowable surviving feed capacity is 6 kW.

**Reasoning:** Total node demand is 7.2 kW. Losing one feed transfers the full 7.2 kW to the survivor, exceeding the stated 6 kW limit although each node PSU can carry its 1.2 kW. The design therefore fails the specified rack feed-loss state. Reduce approved demand or obtain a suitable reviewed facility design; do not count normal sharing as failure-state capacity.

#### Guided practice

A liquid-cooled node has correct coolant flow but overheats its NIC. Explain an integrated diagnosis.

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** The NIC may remain air-cooled. Check the documented heat split, air inlet, fan/control state and obstruction while correlating workload. Correct coolant flow is only evidence for the liquid path.

#### Independent task

Environment: analytical / emulator / physical

Review a rack handover pack containing a shared upstream power dependency, a missing top-rack inlet measurement and an unverified liquid readiness sign-off.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Calculate normal and surviving-path demand.
- Identify both liquid and air dependencies.
- State accepted, held and externally verified requirements without claiming unperformed switching.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0033 · single · implementation**

Six 1.2 kW nodes share two feeds normally. What demand reaches one surviving feed if all nodes continue at the same load?

Synthetic rack: six nodes at 1.2 kW input each; normal equal A/B sharing; surviving feed permitted capacity 6 kW.

1. 1.2 kW
2. 14.4 kW
3. 3.6 kW
4. 7.2 kW

**Correct option(s):** 4

- Option 1: Incorrect. That is only one node's demand.
- Option 2: Incorrect. Losing a feed does not double the nodes' total consumption in this stated model.
- Option 3: Incorrect. That is the normal equal-share value.
- Option 4: Correct. The remaining feed supplies the full combined load.

**HARDWARE-ENGINEERING-Q0034 · single · implementation**

Two server cords terminate in different rack PDUs sharing one upstream breaker. What remains unproven?

1. Whether there are physically two cords
2. Whether the chassis has two inlet connectors
3. Whether a single cord can be labeled
4. Survival of that common upstream breaker failure

**Correct option(s):** 4

- Option 1: Incorrect. That is already given.
- Option 2: Incorrect. The cord arrangement already implies the stated connections.
- Option 3: Incorrect. Labeling is unrelated to the shared failure.
- Option 4: Correct. Outlet separation does not remove the shared dependency.

**HARDWARE-ENGINEERING-Q0035 · single · implementation**

The room supply air is acceptable but a top-rack node overheats. Which measurement is most relevant next?

1. Only the GPU core temperature without inlet or flow context
2. Only the temperature at the room supply diffuser
3. Only the average temperature across all rack sensors
4. The node's actual inlet conditions and airflow path under load

**Correct option(s):** 4

- Option 1: Incorrect. Core temperature shows the symptom but does not localize the heat-transfer path.
- Option 2: Incorrect. It may differ from the actual server inlet.
- Option 3: Incorrect. An average can hide the local hot inlet.
- Option 4: Correct. Room supply temperature may not represent local inlet conditions.

**HARDWARE-ENGINEERING-Q0036 · single · implementation**

Liquid cooling is healthy but an air-cooled NIC overheats. What does this show?

1. The residual air-cooling path still needs validation
2. The NIC's logical address determines its temperature
3. Every NIC must be immersed in coolant
4. Coolant flow readings prove all components are cool

**Correct option(s):** 1

- Option 1: Correct. Liquid capture does not remove every air-cooled load.
- Option 2: Incorrect. Logical addressing is not the thermal mechanism.
- Option 3: Incorrect. Cooling method is platform-specific.
- Option 4: Incorrect. Different components can have separate paths.

**HARDWARE-ENGINEERING-Q0037 · single · implementation**

Which statement about power limits is appropriate for an installation review?

1. Ignore current when watts are known
2. Apply one remembered derating percentage to every installation
3. Use the actual equipment ratings and applicable site/design requirements
4. Change protective settings to match the proposed load without review

**Correct option(s):** 3

- Option 1: Incorrect. Voltage, phase and power factor can matter.
- Option 2: Incorrect. Requirements and ratings vary.
- Option 3: Correct. A universal percentage cannot be assumed for every device and jurisdiction.
- Option 4: Incorrect. Protection changes require appropriate engineering authority.

**HARDWARE-ENGINEERING-Q0038 · single · implementation**

A temporary BMC connection bypasses the approved OOB restrictions. What must handover address?

1. Leave it because the server is reachable
2. Disable all management logging to hide the exception
3. Rename it as a storage cable
4. Remove or formally resolve the temporary exposure and verify the intended management path

**Correct option(s):** 4

- Option 1: Incorrect. Reachability alone does not meet the access design.
- Option 2: Incorrect. That destroys evidence rather than resolving the issue.
- Option 3: Incorrect. A label cannot change the exposure.
- Option 4: Correct. Temporary access can otherwise persist unnoticed.

**HARDWARE-ENGINEERING-Q0039 · single · implementation**

Who performs model-specific pressurized coolant connections in the physical assessment?

1. An IT administrator relying only on a flow-dashboard reading
2. Any learner who passed the arithmetic quiz
3. A technician using a procedure for a different connector family
4. Qualified authorized personnel following the approved procedure

**Correct option(s):** 4

- Option 1: Incorrect. A reading does not confer qualification for the physical connection.
- Option 2: Incorrect. A quiz does not establish physical qualification.
- Option 3: Incorrect. The approved procedure must match the actual equipment and authority.
- Option 4: Correct. The curriculum requires coordination without unauthorized hazardous work.

**HARDWARE-ENGINEERING-Q0040 · single · implementation**

A resilience test ran with half the required workload. Which acceptance claim is supported?

1. The result applies to that tested state; the full required state remains unverified
2. Full-load resilience is proven automatically
3. The test contains no useful information at all
4. The workload value should be omitted from the report

**Correct option(s):** 1

- Option 1: Correct. Test conditions define the scope of evidence.
- Option 2: Incorrect. The higher demand was not exercised or otherwise justified.
- Option 3: Incorrect. It can provide bounded evidence.
- Option 4: Incorrect. Omission would conceal the test's limitation.

#### Recall

**Six 1.2 kW nodes share two feeds normally. What demand reaches one surviving feed if all nodes continue at the same load?**

7.2 kW. Correct. The remaining feed supplies the full combined load.

**Two server cords terminate in different rack PDUs sharing one upstream breaker. What remains unproven?**

Survival of that common upstream breaker failure. Correct. Outlet separation does not remove the shared dependency.

**The room supply air is acceptable but a top-rack node overheats. Which measurement is most relevant next?**

The node's actual inlet conditions and airflow path under load. Correct. Room supply temperature may not represent local inlet conditions.

**Liquid cooling is healthy but an air-cooled NIC overheats. What does this show?**

The residual air-cooling path still needs validation. Correct. Liquid capture does not remove every air-cooled load.

**Which statement about power limits is appropriate for an installation review?**

Use the actual equipment ratings and applicable site/design requirements. Correct. A universal percentage cannot be assumed for every device and jurisdiction.

#### References

- [Dell PowerEdge R760 Installation and Service Manual: illustrative OEM source; use the manual for the actual selected model](https://www.dell.com/support/manuals/en-us/poweredge-r760/per760_ism_pub/about-this-document?guid=guid-bf9eed9e-52b2-4860-911b-954e25631b96&lang=en-us)

## HARDWARE-ENGINEERING-M03 — Bring-up, boot chain and hardware management

### HARDWARE-ENGINEERING-L06 — Boot chain, trusted configuration and firmware compatibility

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L05

Power-on begins a sequence of hardware initialization, firmware execution, device discovery, boot selection, operating-system loading and service startup. A failure at one stage can prevent later evidence from existing. Distinguish no power, failed POST, no boot device, bootloader failure, kernel/driver failure and application failure. A black remote-console screen is not by itself proof of a failed motherboard: the console path, video initialization and selected session may also be wrong. Preserve stage-specific messages and timestamps before resetting the system.

UEFI or platform firmware initializes hardware and supplies boot services. Settings such as storage-controller mode, boot mode, device ordering, virtualization support and secure-boot configuration interact with the installed OS. Changing a controller from a RAID abstraction to direct disk exposure can change device presentation and invalidate the existing boot path. Document the current settings, supported target configuration and recovery method before changing them. Firmware defaults after a board replacement may differ from the approved baseline even when the OS disk is unchanged.

Secure Boot checks permitted signatures in the boot chain according to the configured trust databases and policy. It does not prove that every signed component is free of defects, nor does a disabled setting alone prove compromise. A TPM can protect keys and record measurements used by higher-level trust decisions. Measured boot records what was measured; appraisal requires a reference and policy. Disk-encryption recovery material must be available through an approved process before changes that may alter measured state. The engineer must restore both bootability and the intended trust configuration, not bypass controls simply to clear an error.

Firmware compatibility spans the system BIOS/UEFI, BMC, storage controller, NIC, accelerator and their drivers. An update can have dependencies, intermediate required versions, activation resets, irreversible changes or a minimum supported rollback level. A downloaded file's existence is not enough: verify its origin and integrity using the vendor's supported mechanism, exact target identity, applicability and release conditions. Preserve the source reference and checks performed. A valid signature establishes a provenance/integrity property, not that the package is suitable for this particular system.

Treat the update as a state transition with a recovery plan. Establish healthy prerequisites, maintenance authority, workload disposition, power stability, console/OOB access, known configuration backup and tested access to recovery material. Check whether the recovery path survives loss of the component being updated. A BMC update whose only recovery instructions are stored behind that same BMC may have a dependency problem. Choose update, continue without change or hold based on support, risk and evidence. 'Newest available' is not an engineering acceptance criterion.

After activation, read back versions and settings from authoritative interfaces, inspect logs, verify device enumeration and run the affected functional checks. Successful package upload is earlier than successful activation; successful activation is earlier than restored service. Preserve the before/after evidence and any deviation. If rollback is unsupported, state that explicitly and use the documented vendor recovery or replacement route. In this programme, analytical change review is followed by an authorized supported update and recovery-path demonstration on available equipment; the physical outcome remains open until recorded.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic storage controller update requires driver D8, while the approved host runs D7. The package is correctly signed. Its release notes also state rollback to the installed firmware is unsupported. The change plan says upload, reboot, and roll back if needed.

**Reasoning:** Hold the plan. Signature verification does not resolve driver compatibility. The proposed rollback is unsupported, so the plan lacks its claimed recovery route. Establish a supported driver/firmware combination, test the documented recovery or replacement method, confirm data/configuration protection and revise the acceptance checks before approval.

#### Guided practice

A host asks for an encryption recovery key after a planned firmware change. Explain why disabling the trust features is not the default repair.

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** The measured state may have changed as expected. Follow the approved recovery-key and trust-verification process, verify the intended firmware/configuration and investigate deviations. Bypassing trust can restore boot while leaving the security objective unmet.

#### Independent task

Environment: analytical / emulator / physical

Review a firmware update proposal with an invalid rollback assumption and construct a staged boot-fault diagnostic record.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Distinguish each boot stage using evidence.
- Verify package applicability, compatibility and activation requirements.
- Record a tested recovery route or an explicit unresolved gate.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0041 · single · implementation**

A signed firmware package requires an unavailable driver version. What does the signature establish?

Synthetic firmware release conditions: target F4 requires driver D8; installed driver D7; package verification succeeds; downgrade to F3 unsupported.

1. Package provenance/integrity within the verification scheme, not platform compatibility
2. That every installed driver is compatible
3. That no post-update testing is necessary
4. That rollback is always supported

**Correct option(s):** 1

- Option 1: Correct. Applicability and dependencies still need checking.
- Option 2: Incorrect. Signing does not verify the target combination.
- Option 3: Incorrect. Activation and function still need validation.
- Option 4: Incorrect. Rollback rules are separate.

**HARDWARE-ENGINEERING-Q0042 · single · diagnosis**

A host fails before its bootloader starts. Which evidence is most relevant first?

1. Only the most recent OS service-start log
2. Platform initialization and POST messages
3. Only the application startup configuration
4. Only the last application health dashboard before the outage

**Correct option(s):** 2

- Option 1: Incorrect. The current fault occurs before the OS can reach that stage.
- Option 2: Correct. They describe the earlier failing stage.
- Option 3: Incorrect. Application settings are downstream of the failed initialization stage.
- Option 4: Incorrect. Earlier application health does not localize a current preboot failure.

**HARDWARE-ENGINEERING-Q0043 · single · implementation**

What is the distinction between measured boot and an appraisal decision?

1. Measured boot replaces every encryption key
2. Measurements record state; a reference and policy are needed to judge it
3. Measurements automatically certify all software as safe
4. Measurements always prevent any bootloader from executing

**Correct option(s):** 2

- Option 1: Incorrect. The functions are different.
- Option 2: Correct. Recorded values alone do not determine acceptability.
- Option 3: Incorrect. Appraisal and broader validation are separate.
- Option 4: Incorrect. Recording and enforcement are not identical.

**HARDWARE-ENGINEERING-Q0044 · single · implementation**

A firmware update declares rollback unsupported. Which recovery statement is acceptable?

1. Assume the package signature guarantees reversal
2. Promise to reinstall any earlier image
3. Use the documented supported recovery or replacement route and test its prerequisites
4. Call a configuration export a firmware rollback

**Correct option(s):** 3

- Option 1: Incorrect. Signing does not create rollback capability.
- Option 2: Incorrect. The stated support restriction contradicts that promise.
- Option 3: Correct. A fictional downgrade must not appear as the fallback.
- Option 4: Incorrect. Different artifacts restore different state.

**HARDWARE-ENGINEERING-Q0045 · single · implementation**

Why can changing a storage-controller mode prevent an existing OS from booting?

1. The device presentation and required driver/boot path can change
2. Every controller-mode change permanently erases all media by definition
3. The firmware mode necessarily changes every disk serial number
4. The OS must automatically select a compatible boot driver without preparation

**Correct option(s):** 1

- Option 1: Correct. The OS may no longer see its prior storage abstraction.
- Option 2: Incorrect. Destructive behavior is model-specific, not a universal assumption.
- Option 3: Incorrect. Presentation and driver requirements can change without changing physical serials.
- Option 4: Incorrect. The required driver or boot configuration may not be available.

**HARDWARE-ENGINEERING-Q0046 · single · implementation**

The update tool reports package upload successful. What remains to be established?

1. That all service recovery tests have automatically passed
2. That the upload operation itself reported transfer success
3. That the file was transferred at all
4. Activation, read-back version/settings and affected functional behavior

**Correct option(s):** 4

- Option 1: Incorrect. They have not been demonstrated.
- Option 2: Incorrect. That limited result is already given; activation and function remain separate.
- Option 3: Incorrect. The report already addresses upload, subject to verification.
- Option 4: Correct. Upload is not equivalent to completed update acceptance.

**HARDWARE-ENGINEERING-Q0047 · single · diagnosis**

A replacement motherboard boots with default firmware settings. What should happen before service acceptance?

1. Disable all logs to match the old board's silence
2. Compare and restore the approved settings and trust configuration
3. Accept every factory default as site-approved
4. Assume the old disk transfers every firmware setting

**Correct option(s):** 2

- Option 1: Incorrect. Logging is part of validation, not a nuisance.
- Option 2: Correct. Bootability alone does not establish the intended baseline.
- Option 3: Incorrect. Defaults can differ from the design.
- Option 4: Incorrect. Board firmware state can be separate.

**HARDWARE-ENGINEERING-Q0048 · single · implementation**

An encryption recovery prompt appears after an authorized firmware change. What is the appropriate first route?

1. Permanently disable every trust feature without review
2. Erase the data immediately
3. Use the approved recovery and trust-verification procedure
4. Declare the motherboard physically broken solely from the prompt

**Correct option(s):** 3

- Option 1: Incorrect. That can defeat the intended security state.
- Option 2: Incorrect. No evidence establishes that erasure is required.
- Option 3: Correct. Expected measurement changes still require controlled recovery.
- Option 4: Incorrect. The symptom can result from changed measured state.

#### Recall

**A signed firmware package requires an unavailable driver version. What does the signature establish?**

Package provenance/integrity within the verification scheme, not platform compatibility. Correct. Applicability and dependencies still need checking.

**A host fails before its bootloader starts. Which evidence is most relevant first?**

Platform initialization and POST messages. Correct. They describe the earlier failing stage.

**What is the distinction between measured boot and an appraisal decision?**

Measurements record state; a reference and policy are needed to judge it. Correct. Recorded values alone do not determine acceptability.

**A firmware update declares rollback unsupported. Which recovery statement is acceptable?**

Use the documented supported recovery or replacement route and test its prerequisites. Correct. A fictional downgrade must not appear as the fallback.

**Why can changing a storage-controller mode prevent an existing OS from booting?**

The device presentation and required driver/boot path can change. Correct. The OS may no longer see its prior storage abstraction.

#### References

- [NIST SP 800-193: Platform Firmware Resiliency Guidelines](https://csrc.nist.gov/pubs/sp/800/193/final)

### HARDWARE-ENGINEERING-L07 — BMC, OOB and Redfish: management that agrees with hardware

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L06

The baseboard management controller can expose inventory, sensors, event logs, console, power control and update functions even when the host OS is unavailable. This independence makes it a valuable recovery path and a sensitive administrative system. Distinguish the physical management interface, the BMC service, host-based management agents and any shared-NIC arrangement. A dedicated-looking port does not guarantee upstream isolation, and BMC reachability does not prove host service health.

Out-of-band design identifies who can reach the management plane, through which controlled access path, using which identity and audit mechanisms. Apply the supported account, role, authentication, certificate and session controls. Separate routine observation from configuration and power actions where the platform allows it. Rotate initial credentials and remove temporary accounts through an approved credential process; do not embed secrets in scripts, screenshots or exported lesson evidence. Recovery access must remain available when normal identity services fail, under controlled custody and review.

Redfish is a standardized management interface using web technologies and structured resources. Discover the service root and follow resource links instead of assuming every vendor exposes identical fixed paths and properties. A collection points to members; a member contains identity, status and further links. Some properties are optional or version-dependent, and a vendor may expose extensions. Read the resource type/version and supported actions. A missing property is not necessarily a false value. A client must distinguish successful retrieval, authentication failure, missing resources and transport errors.

Begin with read-only inventory in an authorized lab. A typical service root is `/redfish/v1/`; systems, chassis and managers represent related but different resources. A system's overall health can summarize subordinate state, while a specific component can have its own state, health and timestamps. Follow links to the actual device identity and compare serials with receiving and physical records. Preserve the raw response and collection time. A stale cached 'OK' response is weaker than fresh component evidence and a successful functional check.

Mutating actions require a separate reviewed workflow. Resetting a BMC is not necessarily resetting the host; a host power action can interrupt service. Use the platform's documented action semantics and permitted reset types. Asynchronous tasks may return a task monitor or location requiring follow-up; an accepted request is not completed work. A conditional update can use resource version information where supported to avoid overwriting a concurrent change. Check the resulting task, read back state and validate service behavior. The offline exercises deliberately parse synthetic responses without sending power or update commands.

A useful management baseline records BMC identity/version, network exposure, certificates and expiry, accounts/roles, time source, log forwarding, console/media policy and recovery access. Verify remote-media sessions are removed after use and that abandoned sessions do not retain authority. Test management-plane loss separately from host loss: the OS may keep running while the recovery path is unavailable. Diagnose routing, ACLs, DNS, time, TLS, identity and BMC health in order of observed evidence. Replace hardware only after the dependency evidence supports that conclusion.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic Redfish response says System serial S100, Health OK, collected at 09:00. Physical receiving records show S101. At 10:00 a fresh component resource reports a failed fan; the dashboard still displays the 09:00 summary.

**Reasoning:** There are two unresolved issues: identity mismatch and stale/insufficient health evidence. Reconcile S100/S101 with the physical unit and management endpoint before modifying anything. Refresh linked component state and verify the fan against model-specific evidence. The old summary cannot establish current health or the identity of the installed system.

#### Guided practice

A reset request returns HTTP 202 with a task link. What proves completion?

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** Follow the supported task monitor to its terminal state, inspect messages, then read back the intended state and perform the affected function check. A 202 response means accepted processing, not successful completion.

#### Independent task

Environment: analytical / emulator / physical

Analyze the synthetic Redfish inventory fixture and propose a restricted OOB baseline with a recovery path independent of normal host identity services.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Reconcile stable identity across physical, management and host evidence.
- Distinguish missing, stale, accepted and completed states.
- Keep secrets out of artifacts and separate read-only analysis from authorized mutations.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0049 · single · implementation**

A Redfish request returns 202 Accepted with a task monitor. What should the client infer?

Synthetic HTTP response: status 202 Accepted; Location: /redfish/v1/TaskService/TaskMonitors/42. No terminal task result has yet been read.

1. The task failed because the response was not 200 OK
2. The operation has completed because the request was authorized
3. The host has certainly rebooted successfully
4. Processing was accepted and completion still needs tracking

**Correct option(s):** 4

- Option 1: Incorrect. An asynchronous accepted response is not automatically a failure.
- Option 2: Incorrect. Authorization and acceptance do not establish terminal task success.
- Option 3: Incorrect. The task may still be pending or fail.
- Option 4: Correct. Acceptance is not the terminal operation result.

**HARDWARE-ENGINEERING-Q0050 · single · implementation**

A BMC is reachable while the host application is down. Which conclusion is valid?

1. The application must be healthy
2. The host OS must be powered off
3. The application storage and identity dependencies must be healthy
4. The management path works, but host service health remains separate

**Correct option(s):** 4

- Option 1: Incorrect. Management reachability is a different function.
- Option 2: Incorrect. Several application and dependency faults are possible.
- Option 3: Incorrect. Management reachability does not validate those dependencies.
- Option 4: Correct. BMC independence does not prove application availability.

**HARDWARE-ENGINEERING-Q0051 · single · implementation**

A component's optional health property is absent. How should a robust client treat it?

1. As proof that the component is physically missing
2. As proof that the component is healthy
3. As permission to reset the component
4. As unavailable/unspecified information requiring appropriate follow-up

**Correct option(s):** 4

- Option 1: Incorrect. Optional metadata can be omitted.
- Option 2: Incorrect. No such value was supplied.
- Option 3: Incorrect. Missing information does not authorize a mutation.
- Option 4: Correct. Absence is not automatically a false or healthy value.

**HARDWARE-ENGINEERING-Q0052 · single · implementation**

Why follow Redfish resource links rather than hard-code every vendor path?

1. Resource structure and supported properties can vary across implementations and versions
2. Hard-coded paths automatically improve authorization
3. Links contain a guarantee of physical service health
4. All implementations intentionally use random unrelated protocols

**Correct option(s):** 1

- Option 1: Correct. Discovery reduces unsupported assumptions.
- Option 2: Incorrect. Path choice does not establish access rights.
- Option 3: Incorrect. They locate resources, not acceptance evidence.
- Option 4: Incorrect. Redfish provides a common model despite variations.

**HARDWARE-ENGINEERING-Q0053 · single · implementation**

An inventory response serial differs from the chassis label. Which step comes first?

1. Overwrite the chassis label immediately
2. Reconcile endpoint, fresh resource identity and physical records
3. Issue a power reset to see which server stops
4. Ignore the mismatch if Health is OK

**Correct option(s):** 2

- Option 1: Incorrect. The authoritative identity is unresolved.
- Option 2: Correct. Actions against an uncertain identity could target the wrong system.
- Option 3: Incorrect. That is an unnecessary disruptive identification method.
- Option 4: Incorrect. Health does not resolve identity.

**HARDWARE-ENGINEERING-Q0054 · single · implementation**

Which OOB arrangement better supports recovery when normal identity services are unavailable?

1. A controlled documented recovery-access method with custody and auditing
2. An undocumented shared password in a public worksheet
3. Only an account hosted on the failed dependency
4. No management access at all

**Correct option(s):** 1

- Option 1: Correct. Recovery must address failure of its own dependencies.
- Option 2: Incorrect. That creates uncontrolled authority and exposure.
- Option 3: Incorrect. It leaves the recovery path circular.
- Option 4: Incorrect. That does not meet the recovery requirement.

**HARDWARE-ENGINEERING-Q0055 · single · implementation**

A dashboard displays an hour-old healthy summary after a fresh fan failure event. What is missing from its claim?

1. Only a successful login to the dashboard
2. Only the overall chassis summary with no linked component review
3. A repeat display of the same cached summary
4. Freshness and component-level evidence

**Correct option(s):** 4

- Option 1: Incorrect. Login establishes access, not freshness or hardware health.
- Option 2: Incorrect. The component event needs direct correlation and current evidence.
- Option 3: Incorrect. Repeating stale information does not establish current state.
- Option 4: Correct. An old aggregate status cannot establish present health.

**HARDWARE-ENGINEERING-Q0056 · single · implementation**

Why remove a temporary remote-media session after commissioning?

1. Its removal necessarily destroys the installed OS
2. Leaving virtual media attached can never affect later boot behavior
3. It can retain a boot/media or administrative exposure beyond the task
4. All remote-media sessions automatically expire when the OS installation ends

**Correct option(s):** 3

- Option 1: Incorrect. Detaching installation media does not inherently erase storage.
- Option 2: Incorrect. Depending on configuration, retained media can remain a boot dependency or exposure.
- Option 3: Correct. Temporary access requires closure and verification.
- Option 4: Incorrect. Session lifecycle must be verified instead of assumed.

#### Recall

**A Redfish request returns 202 Accepted with a task monitor. What should the client infer?**

Processing was accepted and completion still needs tracking. Correct. Acceptance is not the terminal operation result.

**A BMC is reachable while the host application is down. Which conclusion is valid?**

The management path works, but host service health remains separate. Correct. BMC independence does not prove application availability.

**A component's optional health property is absent. How should a robust client treat it?**

As unavailable/unspecified information requiring appropriate follow-up. Correct. Absence is not automatically a false or healthy value.

**Why follow Redfish resource links rather than hard-code every vendor path?**

Resource structure and supported properties can vary across implementations and versions. Correct. Discovery reduces unsupported assumptions.

**An inventory response serial differs from the chassis label. Which step comes first?**

Reconcile endpoint, fresh resource identity and physical records. Correct. Actions against an uncertain identity could target the wrong system.

#### References

- [DMTF Redfish standard and specifications](https://www.dmtf.org/standards/redfish)

## HARDWARE-ENGINEERING-M04 — Storage hardware and resilient data paths

### HARDWARE-ENGINEERING-L08 — Disks, flash endurance, RAID and rebuild exposure

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L07

Storage devices expose logical blocks while implementing different physical mechanisms. A rotating disk has seek and rotational costs that make random access behave differently from sequential transfer. Flash avoids mechanical seeking but manages erase blocks, wear, mapping metadata and spare capacity internally. Interface speed is not media performance: a fast transport cannot make every workload achieve its signaling ceiling. Compare sustained read/write behavior, request size, queue depth, latency distribution and the actual data-protection mode.

Use units carefully. A decimal terabyte is 10^12 bytes and a tebibyte is 2^40 bytes. Installed raw capacity is reduced by redundancy, metadata, filesystem allocation, reserves and operational free-space requirements. Capacity estimates need all those layers. SSD endurance is often expressed as total bytes written over a defined warranty condition or drive writes per day. Required host writes per day multiplied by the service duration provides a basic planning demand; workload and vendor definitions determine how it compares with the rating. Internal write amplification and unsuitable workloads can change wear behavior. A percentage-used indicator is model-defined health evidence, not a universal countdown timer.

RAID combines devices into a logical layout. RAID 0 stripes for capacity/performance without redundancy. A two-device mirror stores copies and can survive one member failure, assuming the remaining copy and common components function. RAID 5 uses distributed single parity; RAID 6 uses two independent parity relationships. With equal-size drives and no spare counted, common capacity approximations are N×S, S for a two-way mirror, (N−1)×S and (N−2)×S respectively. RAID 10 stripes across mirrored groups; which devices fail matters. State the layout instead of saying it survives any half of its drives.

Parity reconstructs missing data from surviving members, but repair is not instantaneous. Rebuild competes with foreground I/O and stresses remaining members. A degraded RAID 5 set has no remaining whole-member failure tolerance until redundancy is restored; RAID 6 with one failed member retains one such additional tolerance under its assumptions. A spare is available replacement capacity, not an extra parity equation. Global spares may serve several groups, creating competition during concurrent failures. Rebuild progress alone does not establish integrity or restored service performance.

Caching changes acknowledgement semantics. Write-through and write-back describe when a layer acknowledges writes relative to downstream persistence. Protected controller cache or drive power-loss protection can preserve particular volatile state under specified conditions; not every cache is protected. A disabled or failed protection unit can change the controller's supported policy and performance. Forcing unsafe write-back to regain benchmark speed can trade acknowledged-data integrity for throughput. Verify the complete path, including OS flush behavior and device support, rather than assuming one battery protects every buffer.

Choose a supported design against usable capacity, latency, endurance, failure state, rebuild time and restoration requirements. Keep boot volumes and data volumes distinguishable, even if their physical resources interact. Confirm controller mode, supported drives, sector format and firmware before insertion. A healthy array is not a backup: deletion, corruption, compromise and common-controller failures can affect all online copies. Acceptance includes synthetic-data integrity, a safe supported failure/replacement/rebuild exercise and an independent restoration. Report the exact remaining tolerance during each state and reject repair plans that remove a second member from an already unprotected layout.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic array uses six equal 4 TB drives in RAID 6, plus one separate hot spare. One active member has failed. A planner claims 28 TB usable capacity and three additional drive failures tolerated because of the spare.

**Reasoning:** The simplified parity capacity is (6−2)×4=16 TB before other overhead. The spare is not counted in active capacity. With one failed member, this RAID 6 layout retains one additional whole-member failure tolerance under the stated assumptions, not three. The spare enables a rebuild but does not add parity. Validate integrity and supported replacement, then measure the degraded/rebuild service state.

#### Guided practice

A four-drive RAID 10 has mirrors A/B and C/D. Compare failures A+C with A+B.

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** A+C leaves one member in each mirror and can retain the striped data under the model. A+B loses an entire mirror group and therefore data in that stripe set. The count of failed drives alone does not determine survival.

#### Independent task

Environment: analytical / emulator / physical

Review storage capacity/endurance and a repair plan; calculate remaining tolerance and identify a safe lab restoration test using synthetic data.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Separate raw, redundant and operational capacity.
- State exact layout and degraded/rebuild tolerance.
- Distinguish protected caches from unsupported forced policies and independent backups.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0057 · single · implementation**

Six equal 4 TB drives form RAID 6 with an additional spare outside the active set. What is the simplified usable capacity before other overhead?

Synthetic storage: six active 4 TB drives; RAID6; one additional spare outside the active group. Ignore non-RAID overhead for this question.

1. 24 TB
2. 28 TB
3. 20 TB
4. 16 TB

**Correct option(s):** 4

- Option 1: Incorrect. This omits parity overhead.
- Option 2: Incorrect. This counts every drive without redundancy or spare reservation.
- Option 3: Incorrect. This is the single-parity approximation, not RAID 6.
- Option 4: Correct. Two active-drive equivalents provide parity; the spare adds no active capacity.

**HARDWARE-ENGINEERING-Q0058 · single · implementation**

A RAID 5 group has one failed member. Before rebuild completes, what whole-member failure tolerance remains under the simple model?

1. One additional member for every spare
2. All remaining members
3. One additional member
4. None

**Correct option(s):** 4

- Option 1: Incorrect. Spares do not add parity before restoration.
- Option 2: Incorrect. The array still depends on their data.
- Option 3: Incorrect. That would require another independent redundancy relationship.
- Option 4: Correct. Its single parity protection is already consumed by the missing member.

**HARDWARE-ENGINEERING-Q0059 · single · implementation**

Why can two failures be survivable in one RAID 10 arrangement but fatal in another?

1. RAID 10 always ignores the second failure
2. Only the total surviving raw capacity matters
3. All RAID 10 sets survive any half of their drives
4. The failed members may be in different mirrors or the same mirror

**Correct option(s):** 4

- Option 1: Incorrect. An entire lost mirror breaks the stripe set.
- Option 2: Incorrect. Enough aggregate bytes do not replace a missing complete mirror group.
- Option 3: Incorrect. That overstates the guarantee.
- Option 4: Correct. Failure placement matters.

**HARDWARE-ENGINEERING-Q0060 · single · diagnosis**

A controller switches to a slower cache policy after its protection unit fails. What should guide the response?

1. Disable all flush requests permanently
2. The supported integrity-preserving policy and repair procedure
3. Force write-back solely to recover benchmark speed
4. Declare the disks full because latency increased

**Correct option(s):** 2

- Option 1: Incorrect. That can undermine persistence semantics.
- Option 2: Correct. Forcing unprotected acknowledgement can endanger committed data.
- Option 3: Incorrect. That may acknowledge data not protected against power loss.
- Option 4: Incorrect. Capacity is not established by this symptom.

**HARDWARE-ENGINEERING-Q0061 · single · implementation**

An SSD is rated under specified endurance conditions. What must a service-life estimate include?

1. The expected write workload and the rating's definition and conditions
2. A universal rule that every SSD lasts exactly five years
3. Only the interface peak read rate
4. Only the nominal capacity with no write-volume estimate

**Correct option(s):** 1

- Option 1: Correct. Endurance depends on how the metric is specified and used.
- Option 2: Incorrect. No such universal lifetime follows from the rating.
- Option 3: Incorrect. Read signaling performance does not quantify write endurance demand.
- Option 4: Incorrect. Capacity alone does not define how often that capacity is rewritten.

**HARDWARE-ENGINEERING-Q0062 · single · implementation**

A hot spare has begun rebuilding a failed member. What does the spare provide?

1. Immediate immunity to all additional failures
2. Guaranteed unchanged foreground latency
3. Replacement capacity that can restore the existing redundancy after successful rebuild
4. An independent historical backup of deleted files

**Correct option(s):** 3

- Option 1: Incorrect. Rebuild exposure remains.
- Option 2: Incorrect. Rebuild can compete for resources.
- Option 3: Correct. It is not an extra parity equation.
- Option 4: Incorrect. It is part of the live array.

**HARDWARE-ENGINEERING-Q0063 · single · implementation**

Why is a healthy redundant array insufficient as the only backup?

1. Logical deletion or corruption can affect the online redundant copies
2. Mirroring prevents logical deletion from reaching the second member
3. RAID never improves availability
4. A mirror stores no second copy

**Correct option(s):** 1

- Option 1: Correct. Redundancy and independent restoration solve different failure classes.
- Option 2: Incorrect. Normal mirrored writes can propagate the deletion.
- Option 3: Incorrect. It can protect against specified member failures.
- Option 4: Incorrect. A mirror does store copies but shares logical changes.

**HARDWARE-ENGINEERING-Q0064 · single · implementation**

A repair plan removes a second active drive from a degraded RAID 5 group. What is the correct review decision?

1. Ignore the array state and follow slot numbering alone
2. Accept because both drives have the same capacity
3. Accept because a spare exists in the chassis
4. Reject or hold the plan because the remaining redundancy is insufficient

**Correct option(s):** 4

- Option 1: Incorrect. Identity and protection state must both govern replacement.
- Option 2: Incorrect. Capacity compatibility does not preserve data availability.
- Option 3: Incorrect. An unused or rebuilding spare does not make the missing data safe.
- Option 4: Correct. A second missing member exceeds the simple layout's tolerance.

#### Recall

**Six equal 4 TB drives form RAID 6 with an additional spare outside the active set. What is the simplified usable capacity before other overhead?**

16 TB. Correct. Two active-drive equivalents provide parity; the spare adds no active capacity.

**A RAID 5 group has one failed member. Before rebuild completes, what whole-member failure tolerance remains under the simple model?**

None. Correct. Its single parity protection is already consumed by the missing member.

**Why can two failures be survivable in one RAID 10 arrangement but fatal in another?**

The failed members may be in different mirrors or the same mirror. Correct. Failure placement matters.

**A controller switches to a slower cache policy after its protection unit fails. What should guide the response?**

The supported integrity-preserving policy and repair procedure. Correct. Forcing unprotected acknowledgement can endanger committed data.

**An SSD is rated under specified endurance conditions. What must a service-life estimate include?**

The expected write workload and the rating's definition and conditions. Correct. Endurance depends on how the metric is specified and used.

#### References

- [Dell PowerEdge R760 Installation and Service Manual: illustrative OEM source; use the manual for the actual selected model](https://www.dell.com/support/manuals/en-us/poweredge-r760/per760_ism_pub/about-this-document?guid=guid-bf9eed9e-52b2-4860-911b-954e25631b96&lang=en-us)

### HARDWARE-ENGINEERING-L09 — Filesystems, block layers and durable data

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L08

Follow a write through its layers: application buffer, operating-system cache, filesystem, volume manager or RAID, controller, drive cache and persistent media. An acknowledgement at one layer does not automatically mean all lower layers have persisted the data. Applications that require durability use the supported synchronization or database commit mechanisms, and each lower layer must honor the necessary ordering and flush semantics. A benchmark that reports completion before persistence cannot be compared directly with a durable-write benchmark.

A partition describes regions of a device; a volume manager can assemble or allocate logical volumes; a filesystem organizes names, metadata and file data. A database adds its own consistency rules. These abstractions do not all restore in the same way. Copying a mounted database's files while writes continue can capture inconsistent relationships unless the database and backup method explicitly support the operation. A filesystem mount succeeding establishes accessibility, not that every application record is correct or that the recovered data meets its required point in time.

Journaling records selected filesystem changes so recovery can restore structural consistency after interruption. The exact data and metadata guarantees depend on the filesystem and mode. A journal does not necessarily retain historical versions for user recovery and is not an independent backup. Checksums can detect some corruption, while repair requires a trustworthy alternate copy or reconstruction mechanism. A checksum mismatch must be interpreted with provenance: comparing two hashes of the same already-corrupted copy does not establish correctness against the original.

Snapshots preserve a point-in-time view according to the implementation. Copy-on-write or redirect-on-write methods retain prior blocks while new writes create changes elsewhere. A snapshot may share the same storage, metadata and administrator authority as its source. It can aid rollback or backup consistency, but a lost array or compromised shared control plane may remove both. Space consumption grows with change, and a full snapshot reserve can have implementation-specific consequences. Retention policies must account for both capacity and recovery needs.

Plan usable space beyond the initial dataset. Include growth, temporary files, logs, snapshots, rebuild or replication overhead where relevant, and a defined operating reserve. A 10 TB volume with 8 TB of data is not automatically adequate if the job requires 3 TB of temporary workspace. Monitor bytes, inodes or equivalent metadata resources, quotas and mount state. 'Disk full' can refer to distinct limits. A service can fail with free bytes remaining because it exhausted inodes, reached a quota, or remounted read-only after an error.

Data-integrity acceptance uses known synthetic content, an independent manifest and a verified restoration path. Generate test files in a dedicated disposable workspace, hash them, copy or back them up using the selected supported method, introduce a controlled failure in that workspace, restore and compare against the preserved reference. For databases, add a supported consistency and application query check. Retain what was restored, source timestamp, elapsed recovery, permissions and application result. The offline workbook demonstrates file-level loss/restoration with synthetic data; it does not claim to validate a physical controller, filesystem crash semantics or database recovery.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic filesystem has 2 TB free but a service cannot create new small files. Inode usage is 100%, the service quota is not exhausted, and the mount is read-write.

**Reasoning:** The evidence points to inode exhaustion rather than byte capacity or read-only state. Confirm which approved directories and retention processes consume metadata, preserve required records, and correct the responsible retention or allocation issue through a reviewed action. Replacing the storage controller is not justified by these observations. Retest file creation and service function.

#### Guided practice

A snapshot resides on the same failed array as the original volume. Can it provide the planned independent restoration?

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** No access to either copy exists if the shared array is unavailable in this scenario. Use a separately protected backup/recovery source. A snapshot may still be useful against some logical changes, but that does not satisfy this common-array failure requirement.

#### Independent task

Environment: analytical / emulator / physical

Run the dedicated synthetic file-restoration exercise and explain the limits of its evidence; review a database backup plan for application consistency.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/recovery_lab.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Preserve an independent reference manifest and compare restored content.
- Separate filesystem accessibility, integrity and application correctness.
- Identify common dependencies of snapshots and backups.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0065 · single · implementation**

A filesystem has free bytes but no free inodes. Which symptom is expected?

Synthetic filesystem: free bytes=2 TB; free inodes=0; mount state=read-write; service quota not exhausted.

1. All existing file contents must instantly disappear
2. Adding byte capacity without changing metadata allocation always fixes the problem
3. Creation of additional files can fail despite byte capacity remaining
4. The service can create unlimited empty files because they contain no payload

**Correct option(s):** 3

- Option 1: Incorrect. Inode exhaustion does not imply that universal data loss.
- Option 2: Incorrect. The inode resource, not simply free bytes, is the stated constraint.
- Option 3: Correct. File metadata resources can be exhausted independently.
- Option 4: Incorrect. Even empty files generally require metadata resources.

**HARDWARE-ENGINEERING-Q0066 · single · implementation**

What does filesystem journaling primarily fail to provide by itself?

1. Any assistance with recovery after interruption
2. Any relationship to write ordering
3. Any record of filesystem changes
4. An independent historical backup against every logical deletion

**Correct option(s):** 4

- Option 1: Incorrect. Journaling can assist structural recovery.
- Option 2: Incorrect. Ordering is relevant to consistency guarantees.
- Option 3: Incorrect. Recording selected changes is its mechanism.
- Option 4: Correct. A journal serves recovery consistency, not a universal backup history.

**HARDWARE-ENGINEERING-Q0067 · single · implementation**

Two identical hashes are calculated from the same corrupted copy. What has been established?

1. The storage array has full redundancy
2. The original data is certainly intact
3. The two calculations agree on that copy, not that it matches the original
4. The backup was taken at the required time

**Correct option(s):** 3

- Option 1: Incorrect. Hashes do not reveal member state.
- Option 2: Incorrect. Both hashes can consistently describe corrupted content.
- Option 3: Correct. Correctness requires a trustworthy reference.
- Option 4: Incorrect. Timing is not established by this comparison.

**HARDWARE-ENGINEERING-Q0068 · single · implementation**

Why can copying live database files be an invalid backup method?

1. Concurrent changes can leave an inconsistent captured state unless the supported method handles them
2. Database files can never be backed up
3. Every file copy automatically includes transaction-consistent coordination
4. A database contains no files or persistent state

**Correct option(s):** 1

- Option 1: Correct. Database consistency needs more than file visibility.
- Option 2: Incorrect. Supported logical and physical methods exist.
- Option 3: Incorrect. That cannot be assumed.
- Option 4: Incorrect. It does require persistent state.

**HARDWARE-ENGINEERING-Q0069 · single · implementation**

A snapshot shares the same failed array as its source. Which requirement is unmet?

1. The ability to count physical disks
2. The existence of any point-in-time view before failure
3. Independent restoration after loss of that array
4. The ability to label the snapshot

**Correct option(s):** 3

- Option 1: Incorrect. Inventory is not restoration.
- Option 2: Incorrect. A snapshot may have existed but is now inaccessible.
- Option 3: Correct. The shared dependency removes access to both views.
- Option 4: Incorrect. Naming does not supply the missing recovery source.

**HARDWARE-ENGINEERING-Q0070 · single · implementation**

A durable-write benchmark is compared with one that acknowledges writes in volatile memory. What is wrong with the comparison?

1. Their completion semantics differ
2. Durability has no influence on performance
3. Volatile acknowledgement always proves permanent media storage
4. All write benchmarks use identical persistence semantics

**Correct option(s):** 1

- Option 1: Correct. Reported throughput measures different guarantees.
- Option 2: Incorrect. Persistence and ordering can affect latency and throughput.
- Option 3: Incorrect. It explicitly may precede persistence.
- Option 4: Incorrect. They do not.

**HARDWARE-ENGINEERING-Q0071 · single · implementation**

A restored volume mounts successfully. What additional evidence is needed for application recovery?

1. No further evidence because mounting proves all records correct
2. Only the number of mount commands issued
3. Only a new volume label
4. Content integrity, required recovery point, permissions and application function

**Correct option(s):** 4

- Option 1: Incorrect. Structural access is weaker than application correctness.
- Option 2: Incorrect. Command count is not functional evidence.
- Option 3: Incorrect. A label does not verify recovered data.
- Option 4: Correct. Mount success is only one layer of acceptance.

**HARDWARE-ENGINEERING-Q0072 · single · implementation**

A job needs 3 TB temporary space on a volume with 2 TB free. Which review outcome is justified?

1. Accept because the final output is small
2. Accept because RAID is enabled
3. Count the existing data twice because it is mirrored
4. The stated space plan is insufficient before considering other reserves

**Correct option(s):** 4

- Option 1: Incorrect. Peak workspace demand still matters.
- Option 2: Incorrect. Redundancy does not create the missing free capacity.
- Option 3: Incorrect. Mirroring does not add free workspace to the logical volume.
- Option 4: Correct. Temporary demand exceeds available free space.

#### Recall

**A filesystem has free bytes but no free inodes. Which symptom is expected?**

Creation of additional files can fail despite byte capacity remaining. Correct. File metadata resources can be exhausted independently.

**What does filesystem journaling primarily fail to provide by itself?**

An independent historical backup against every logical deletion. Correct. A journal serves recovery consistency, not a universal backup history.

**Two identical hashes are calculated from the same corrupted copy. What has been established?**

The two calculations agree on that copy, not that it matches the original. Correct. Correctness requires a trustworthy reference.

**Why can copying live database files be an invalid backup method?**

Concurrent changes can leave an inconsistent captured state unless the supported method handles them. Correct. Database consistency needs more than file visibility.

**A snapshot shares the same failed array as its source. Which requirement is unmet?**

Independent restoration after loss of that array. Correct. The shared dependency removes access to both views.

#### References

- [PostgreSQL current documentation: Backup and Restore](https://www.postgresql.org/docs/current/backup.html)

### HARDWARE-ENGINEERING-L10 — Storage transports, multipathing and path-failure diagnosis

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L09

A resilient storage path includes the host adapter or NIC, cable, switch or fabric, target port, controller and media service. Two host-visible paths may share several of these components. Describe which failure the design must survive: cable, port, adapter, switch, target controller or entire array. Diversity at one layer does not imply independence at every layer. A path diagram should identify both separate elements and shared failure points.

Multipathing presents multiple transport paths to the same logical storage object through a coordinated host mechanism. Stable identifiers distinguish the same LUN or namespace reached by different routes from genuinely separate devices. Treating each path as an independent writable filesystem can corrupt data or cause inconsistent ownership. Verify the supported multipath stack, target behavior, device identifier, path grouping and failover policy. Some paths may be preferred, optimized, nonoptimized or standby depending on the protocol and array. Do not infer a fault merely because every path is not simultaneously carrying equal traffic.

Timeouts connect storage failure to application behavior. The host may retry, queue, fail over or return an error. An indefinite queue can make an application hang long after its permitted recovery time, while overly aggressive failure can turn a brief interruption into avoidable errors. Choose settings from the supported host/array/application guidance and the actual service requirement. Record how a failed path is detected, how long the transition takes, how the application behaves and how recovery is verified. A link returning to up does not prove the storage object or application has recovered.

Local NVMe, SAS or SATA and networked block/file storage have different transport and management details. NVMe namespaces are logical storage entities; the device and namespace relationships must be recorded. A file service adds server-side filesystem and permission dependencies, while block storage exposes lower-level devices to the host. Boot-from-networked-storage adds a startup dependency: the host may need fabric, target, identity or network services before its OS can load. Keep a recovery route that does not depend exclusively on the failed path being repaired first.

Diagnose from several layers. Correlate application latency, OS I/O errors, multipath state, adapter counters, switch evidence and target health over the same interval. If one host is slow and its peer is healthy against the same target, compare host path and queue conditions. If all hosts slow simultaneously, a shared target or fabric dependency becomes more plausible but still needs evidence. A transport error can be caused by cable/signal issues, congestion, firmware, adapter behavior or target problems. Replacing drives without path evidence can leave the real fault intact.

A safe assessment uses supported lab storage and synthetic data. Establish integrity and baseline performance, remove or disable only an approved path through the documented method, observe service behavior, restore the path and verify stability. A drive failure and a path failure are different tests. Follow the separate replacement/rebuild procedure for a member failure and report remaining tolerance. Restore data independently after the exercise. The analytical fixture can grade path reasoning, but actual failover behavior, timing and physical replacement remain externally observed evidence.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic host has paths P1 and P2 to the same volume identifier. Both traverse one HBA. Pulling one cable leaves I/O working, so the report claims adapter-failure resilience.

**Reasoning:** The cable test proves only the exercised cable/path state. Both paths still depend on one HBA, so adapter-failure resilience is not established and the proposed architecture cannot meet that failure requirement without another suitable route. Record the common HBA and test the intended failure state only after a supported design and authorized method exist.

#### Guided practice

An application stalls for 180 seconds after a storage path fails; its allowed interruption is 30 seconds. A second path eventually recovers I/O. How should acceptance be stated?

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** Availability eventually returned, but the measured interruption exceeds the 30-second requirement. Review supported detection, queueing and failover behavior, correlate logs, correct the appropriate configuration or design, and retest. Eventual success does not satisfy the timing target.

#### Independent task

Environment: analytical / emulator / physical

Build a storage dependency map and review a path-failure test with a misleading resilience claim.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Identify the same logical volume across paths and shared hardware.
- Measure interruption against the service criterion.
- Keep path failover, drive rebuild and independent restoration evidence separate.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0073 · single · implementation**

Two storage paths terminate on the same host HBA. Which resilience claim is unsupported?

Synthetic paths P1 and P2 reach volume ID V100. P1: HBA1-port1 → switchA → targetA. P2: HBA1-port2 → switchB → targetB.

1. The existence of two transport paths
2. The ability to record each cable endpoint
3. Survival of failure of that HBA
4. Survival of one tested cable failure when the other path works

**Correct option(s):** 3

- Option 1: Incorrect. The scenario provides two paths.
- Option 2: Incorrect. Documentation remains possible.
- Option 3: Correct. Both paths share the adapter.
- Option 4: Incorrect. That can be demonstrated by the stated test.

**HARDWARE-ENGINEERING-Q0074 · single · implementation**

Two host devices have the same stable volume identity through different routes. What is the supported conceptual treatment?

1. Format both separately as unrelated writable volumes
2. Assume one identifier must be random corruption
3. Add their capacities as two independent copies
4. Coordinate them as paths to one logical object through the appropriate multipath stack

**Correct option(s):** 4

- Option 1: Incorrect. That can corrupt the shared object.
- Option 2: Incorrect. Shared identity is expected for multipath access.
- Option 3: Incorrect. Both routes reach the same capacity.
- Option 4: Correct. They are not automatically independent filesystems.

**HARDWARE-ENGINEERING-Q0075 · single · implementation**

A failover completes after 180 seconds against a 30-second interruption limit. Which result follows?

1. The tested timing requirement failed despite eventual recovery
2. No timing data can ever be used in storage acceptance
3. The test passed because I/O eventually resumed
4. The second path must be physically absent

**Correct option(s):** 1

- Option 1: Correct. Recovery duration is part of acceptance.
- Option 2: Incorrect. Timing is directly relevant.
- Option 3: Incorrect. That ignores the explicit limit.
- Option 4: Incorrect. It eventually carried I/O in the scenario.

**HARDWARE-ENGINEERING-Q0076 · single · diagnosis**

A multipath display shows an optimized and a nonoptimized path. What should be checked before calling a fault?

1. Whether both paths appear in inventory
2. Whether both endpoint links negotiate the same speed
3. The target's supported path-state behavior and policy
4. Whether every path carries exactly equal bytes

**Correct option(s):** 3

- Option 1: Incorrect. Presence alone does not explain their supported roles.
- Option 2: Incorrect. Equal speed does not imply equal optimized/standby roles.
- Option 3: Correct. Unequal roles may be expected.
- Option 4: Incorrect. Equal traffic is not a universal requirement.

**HARDWARE-ENGINEERING-Q0077 · single · implementation**

What is a risk of indefinite I/O queueing during a path outage?

1. It removes every shared array dependency
2. The application may hang beyond its recovery requirement
3. It guarantees immediate explicit errors for every request
4. It necessarily creates an independent backup

**Correct option(s):** 2

- Option 1: Incorrect. It does not change topology.
- Option 2: Correct. Queue policy affects service behavior and timing.
- Option 3: Incorrect. Indefinite queueing does the opposite.
- Option 4: Incorrect. Queueing is not backup.

**HARDWARE-ENGINEERING-Q0078 · single · implementation**

Only one of several hosts is slow against the same target. Which investigation is most discriminating first?

1. Replace every target disk immediately
2. Ignore host evidence because the array dashboard is green
3. Compare that host's paths, queues and errors with the healthy peers over the same interval
4. Declare all shared infrastructure impossible as a cause

**Correct option(s):** 3

- Option 1: Incorrect. The host-specific symptom needs narrower evidence.
- Option 2: Incorrect. Aggregate health may miss the relevant path issue.
- Option 3: Correct. The difference helps localize the constraint.
- Option 4: Incorrect. Shared systems can affect hosts differently.

**HARDWARE-ENGINEERING-Q0079 · single · implementation**

Why does booting from networked storage need a recovery dependency review?

1. The host no longer needs firmware
2. It guarantees that no boot failure can occur
3. The host can require storage fabric and target access before its OS starts
4. Every networked boot automatically includes offline recovery media

**Correct option(s):** 3

- Option 1: Incorrect. Firmware still initializes and locates the boot path.
- Option 2: Incorrect. Networked boot adds dependencies rather than eliminating all failure.
- Option 3: Correct. Those dependencies may also be needed to perform repairs.
- Option 4: Incorrect. That must be provided and verified separately.

**HARDWARE-ENGINEERING-Q0080 · single · implementation**

A cable-failure exercise passes. Which separate claim still needs evidence?

1. Supported drive replacement/rebuild and independent data restoration
2. That the tested cable was a component in the path
3. That the test had an author
4. That synthetic data can be named

**Correct option(s):** 1

- Option 1: Correct. Those exercise different mechanisms and failure states.
- Option 2: Incorrect. The exercise already identifies it.
- Option 3: Incorrect. Authorship is unrelated to the remaining technical claim.
- Option 4: Incorrect. Naming is not the missing resilience evidence.

#### Recall

**Two storage paths terminate on the same host HBA. Which resilience claim is unsupported?**

Survival of failure of that HBA. Correct. Both paths share the adapter.

**Two host devices have the same stable volume identity through different routes. What is the supported conceptual treatment?**

Coordinate them as paths to one logical object through the appropriate multipath stack. Correct. They are not automatically independent filesystems.

**A failover completes after 180 seconds against a 30-second interruption limit. Which result follows?**

The tested timing requirement failed despite eventual recovery. Correct. Recovery duration is part of acceptance.

**A multipath display shows an optimized and a nonoptimized path. What should be checked before calling a fault?**

The target's supported path-state behavior and policy. Correct. Unequal roles may be expected.

**What is a risk of indefinite I/O queueing during a path outage?**

The application may hang beyond its recovery requirement. Correct. Queue policy affects service behavior and timing.

#### References

- [Red Hat Enterprise Linux 9: Configuring Device Mapper Multipath](https://docs.redhat.com/en/documentation/red_hat_enterprise_linux/9/html/configuring_device_mapper_multipath/index)

## HARDWARE-ENGINEERING-M05 — Supporting hosts and infrastructure services

### HARDWARE-ENGINEERING-L11 — Reproducible Linux/Windows hosts and controlled virtualization

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L10

A supporting host converts hardware resources into a managed operating environment. The baseline includes approved installation media, verified device identity, firmware settings, storage layout, OS edition/release, drivers, patches, network configuration, time, accounts, permissions, logging, management agents and backup enrollment. Record why each installed service exists. Reproducibility means another authorized engineer can reconstruct the intended state from controlled artifacts and verify the result; it does not mean copying unreviewed secrets or machine identities between systems.

Installation media and drivers must match the supported platform combination. A generic driver may allow a device to appear while omitting supported features or producing different error behavior. After installation, reconcile detected CPU, memory, storage and interfaces with the BOM and firmware inventory. Record unknown devices and unexpected defaults as exceptions. On an authorized Linux lab, read-only observations such as `uname -r`, `lscpu`, `lsblk`, `ip address`, `ip route` and service-status queries can build a baseline. Windows provides equivalent inventory, event and service tools. Commands and permissions vary by release; verify the supported procedure before changes.

Permissions connect host function and security. Identify which service identity reads configuration, writes data, accesses devices and contacts remote systems. Grant the required rights rather than broad administrator membership to clear an unexplained error. A permission denial is evidence about identity and authorization, not a hardware diagnosis. Check effective identity, object ownership, access controls and relevant policy. Retain audit evidence while excluding credentials and private keys from shared artifacts. Recovery must restore access to required functions without silently restoring excessive authority.

Virtualization adds a hypervisor, virtual hardware and resource allocation between the physical host and guests. Virtual CPUs are scheduled on physical execution resources; configured memory, overcommit policies and storage allocation affect contention and failure behavior. Device passthrough can bind a guest to a particular physical device and constrain migration or recovery. A virtual switch or virtual disk is an additional dependency with its own configuration. A guest boot proves neither physical redundancy nor application recovery. Map every critical guest to physical storage, network, identity, backup and management dependencies.

Capacity planning must include the failure state. If two hosts run a workload near capacity, moving all guests to one may exceed memory or latency requirements even if migration technically succeeds. Reserve capacity according to the actual policy and measured workload. Avoid counting deduplication, thin provisioning or overcommit as guaranteed physical capacity under every workload. A lab should demonstrate the difference between configured resources, committed resources and available physical resources. Record any limit, reservation or placement policy needed to reproduce acceptance.

A practical baseline is declarative where supported and reviewed where manual work remains. Store a sanitized configuration manifest, package/version list, network/service dependency record and verification commands. Build in a disposable authorized environment, verify the required service, deliberately change one safe configuration item, detect the drift and restore it. Preserve the observed difference and function check. This programme uses supporting Linux/Windows and controlled virtualization as operational enablers for network/OT systems; it does not claim a complete cloud-platform specialization from this chapter.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic VM has 8 vCPUs and 32 GiB configured memory. Its physical host has 16 cores and 64 GiB usable memory. Four such guests must run simultaneously after peer-host failure without memory overcommit; host services require 8 GiB.

**Reasoning:** Guest demand is 4×32=128 GiB, plus 8 GiB host requirement, so 136 GiB exceeds 64 GiB by 72 GiB. Configured vCPU count alone does not establish CPU performance, and the memory constraint already rejects the stated failure-state design. Revise capacity/placement or workload requirements and test the accepted configuration.

#### Guided practice

A service cannot write its data directory after a host rebuild, while disks are healthy and writable by an administrator. Should the controller be replaced?

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** Not on this evidence. Check the effective service identity, directory ownership/ACLs and policy against the baseline. Correct the authorized permission mapping and verify the service operation. Administrator success does not prove service-account access.

#### Independent task

Environment: analytical / emulator / physical

Create a sanitized host baseline and a reproducible disposable service environment; detect one safe drift and restore the expected state.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Reconcile OS inventory with physical/BMC records.
- Verify effective service permissions and failure-state resource capacity.
- Retain configuration, drift evidence and end-to-end service tests.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0081 · single · implementation**

Four guests each need 32 GiB plus 8 GiB for host services on a 64 GiB host, with no overcommit allowed. What is the shortfall?

Synthetic failover capacity: four guests ×32 GiB; host services 8 GiB; host usable 64 GiB; overcommit prohibited.

1. 72 GiB
2. 8 GiB
3. 64 GiB
4. No shortfall because virtual memory is unlimited

**Correct option(s):** 1

- Option 1: Correct. The total is 136 GiB; subtracting 64 gives 72.
- Option 2: Incorrect. That counts only host services and ignores guest demand.
- Option 3: Incorrect. That omits the host-service requirement.
- Option 4: Incorrect. The requirement excludes overcommit and physical capacity is finite.

**HARDWARE-ENGINEERING-Q0082 · single · diagnosis**

A service fails to write a directory that an administrator can write. Which check is most relevant?

1. Only the administrator's successful write test
2. The service's effective identity and directory permissions
3. Only the disk controller health summary
4. Only the free-byte count on the volume

**Correct option(s):** 2

- Option 1: Incorrect. A different identity's access does not prove service access.
- Option 2: Correct. Different identities can have different authorization.
- Option 3: Incorrect. Controller health does not establish service-account authorization.
- Option 4: Incorrect. Capacity is useful context but does not explain the identity-specific denial.

**HARDWARE-ENGINEERING-Q0083 · single · implementation**

What makes a host baseline reproducible?

1. Copying every credential and identity unchanged to all machines
2. A screenshot showing the desktop once
3. Relying on one engineer's memory
4. Controlled configuration artifacts plus verification of the reconstructed state

**Correct option(s):** 4

- Option 1: Incorrect. That can create duplicate identities and expose secrets.
- Option 2: Incorrect. It omits much of the state and verification.
- Option 3: Incorrect. It is neither controlled nor independently repeatable.
- Option 4: Correct. A list alone must be connected to observed results.

**HARDWARE-ENGINEERING-Q0084 · single · implementation**

A passthrough device is assigned to a guest. Which recovery issue needs review?

1. The guest's virtual disk is necessarily erased
2. The guest is now independent of all hardware
3. The device automatically becomes a network backup
4. The guest may depend on a specific physical device and supported reassignment path

**Correct option(s):** 4

- Option 1: Incorrect. That is not implied by passthrough.
- Option 2: Incorrect. It has a more direct hardware dependency.
- Option 3: Incorrect. Assignment is not backup.
- Option 4: Correct. Passthrough can constrain migration and restoration.

**HARDWARE-ENGINEERING-Q0085 · single · implementation**

A device appears with a generic driver. What remains to be verified?

1. That the firmware can never affect it
2. That all vendor-specific functions work automatically
3. Only that some device enumeration occurred
4. Supported functionality, error behavior and the approved compatibility combination

**Correct option(s):** 4

- Option 1: Incorrect. Firmware and driver interactions still matter.
- Option 2: Incorrect. A generic driver may not provide them.
- Option 3: Incorrect. The scenario already establishes presence.
- Option 4: Correct. Presence is weaker evidence than supported operation.

**HARDWARE-ENGINEERING-Q0086 · single · implementation**

Why is a booted VM insufficient evidence for service recovery?

1. Booting proves every external identity service works
2. Its data, dependencies, permissions and required function may still be wrong
3. A VM has no storage dependency
4. VMs never run useful services

**Correct option(s):** 2

- Option 1: Incorrect. Those dependencies require their own checks.
- Option 2: Correct. Boot is only one layer of the service.
- Option 3: Incorrect. Its virtual storage has underlying resources.
- Option 4: Incorrect. They commonly do.

**HARDWARE-ENGINEERING-Q0087 · single · implementation**

A thin-provisioned allocation is counted as guaranteed available physical storage. What is missing?

1. A second copy of the same allocation report
2. Only the configured virtual capacity of all guests
3. Evidence of actual physical capacity and growth/failure-state constraints
4. An assumption that deduplication savings are guaranteed under every workload

**Correct option(s):** 3

- Option 1: Incorrect. Repeated logical evidence does not establish physical capacity.
- Option 2: Incorrect. That repeats allocation rather than proving physical backing.
- Option 3: Correct. Logical allocation can exceed backing capacity.
- Option 4: Incorrect. Savings depend on actual data and cannot replace capacity evidence.

**HARDWARE-ENGINEERING-Q0088 · single · implementation**

A safe configuration drift is corrected. Which result closes the exercise?

1. Only the absence of a visible desktop warning
2. Read-back baseline comparison and the affected service function test
3. Deletion of the original drift record
4. Only the command being typed

**Correct option(s):** 2

- Option 1: Incorrect. That is incomplete evidence.
- Option 2: Correct. Correction must be observed and functionally verified.
- Option 3: Incorrect. That removes useful before/after evidence.
- Option 4: Incorrect. Issuing a command does not prove its result.

#### Recall

**Four guests each need 32 GiB plus 8 GiB for host services on a 64 GiB host, with no overcommit allowed. What is the shortfall?**

72 GiB. Correct. The total is 136 GiB; subtracting 64 gives 72.

**A service fails to write a directory that an administrator can write. Which check is most relevant?**

The service's effective identity and directory permissions. Correct. Different identities can have different authorization.

**What makes a host baseline reproducible?**

Controlled configuration artifacts plus verification of the reconstructed state. Correct. A list alone must be connected to observed results.

**A passthrough device is assigned to a guest. Which recovery issue needs review?**

The guest may depend on a specific physical device and supported reassignment path. Correct. Passthrough can constrain migration and restoration.

**A device appears with a generic driver. What remains to be verified?**

Supported functionality, error behavior and the approved compatibility combination. Correct. Presence is weaker evidence than supported operation.

#### References

- [Dell PowerEdge R760 Installation and Service Manual: illustrative OEM source; use the manual for the actual selected model](https://www.dell.com/support/manuals/en-us/poweredge-r760/per760_ism_pub/about-this-document?guid=guid-bf9eed9e-52b2-4860-911b-954e25631b96&lang=en-us)

### HARDWARE-ENGINEERING-L12 — Identity, DNS, time, database and backup dependency recovery

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L11

A data-center support service is a dependency graph. A monitoring application may need a host, storage, network route, name resolution, synchronized time, service credentials, a database and certificates. Failure of any dependency can resemble application or hardware failure. Draw directed relationships and identify which are needed for startup, normal operation and recovery. Those three graphs can differ. A recovery tool requiring an identity server that is itself restored by that tool creates a circular dependency unless an approved bootstrap route exists.

DNS maps names to service endpoints under a managed namespace. A successful ping to an IP does not establish that the service name resolves correctly or that a client uses the intended endpoint. Check the client's actual resolver, returned records, search behavior and relevant caching within the supported environment. Split views, stale records or a changed address after replacement can direct clients to the wrong system. A route problem, name problem and service-listener problem produce different evidence. Test each layer without assuming that one successful check validates the whole path.

Time affects event correlation, authentication and certificate validation. Compare source, offset, synchronization state and the timestamps in the relevant logs. A clock error can make a currently valid certificate appear outside its validity interval or disrupt time-sensitive authentication. Do not solve a trust failure by permanently disabling certificate validation. Restore the correct time and trust configuration, then verify identity and service access. Keep logs' time zones and collection times explicit when reconstructing an incident; events from unsynchronized hosts cannot be ordered solely by their displayed seconds.

Identity services supply accounts, group membership and authentication, while each target enforces authorization. After rebuilding a host, verify its intended machine/service identity and account relationships. A database or file path may retain permissions for an old identity rather than the replacement. Reusing an old display name does not necessarily restore the same security principal. Recovery should remove obsolete authority and validate the intended access matrix, including denied access for an unauthorized test identity in an approved lab.

Databases require supported backup and recovery methods. Logical exports, physical backups and continuous log archiving serve different needs and have different dependencies. A base backup plus the necessary transaction-log sequence can support point-in-time recovery where the database supports it. Missing required logs can limit the achievable recovery point even if the base backup is intact. A successful file transfer is not proof that a backup can be restored. Test the restore procedure with the relevant version, configuration, keys and storage, then query meaningful synthetic records through the actual application path.

Recovery order follows the graph and trust requirements. Establish controlled administrative access and a trustworthy platform, restore the minimum required network/name/time/identity dependencies, make storage and database state available, then restore application services and clients. Some services need temporary bootstrap settings that must be removed after normal operation returns. Measure time from the defined disruption start to verified function, and state the recovered data point. Record unavailable dependencies encountered during the test and revise the plan. The required outcome is the network or OT function and its data, not a collection of powered-on VMs.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic monitoring service fails after a host replacement. Hardware diagnostics pass, the database is reachable by IP, DNS still resolves its name to the retired address, and the service configuration uses that name. The proposed fix is replacing the NIC.

**Reasoning:** Reject the NIC diagnosis on this evidence. Name resolution directs the client to the wrong endpoint. Correct the controlled DNS/configuration state, account for cache behavior, then verify name resolution, authenticated database access and monitoring function. Preserve the old/new evidence and confirm that retired endpoint authority is removed.

#### Guided practice

A database recovery plan has a base backup from 01:00 and logs through 01:40, but the required recovery point is 01:55. What can be claimed?

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** The supplied artifacts do not establish recovery to 01:55. Determine the supported recoverable point with available complete logs, obtain missing authorized artifacts if possible, or report the shortfall. Do not equate a successful database start with the required recovery point.

#### Independent task

Environment: analytical / emulator / physical

Reconstruct a synthetic service dependency graph, fix the actual nonhardware fault, and document restore order including a missing recovery dependency.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/recovery_lab.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Distinguish name, route, time, identity, storage and application evidence.
- Verify functional records and restored administrative authority.
- Measure recovery duration and achievable data point separately.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0089 · single · diagnosis**

A replacement host's hardware passes diagnostics, but DNS points the service name to the retired address. Which correction is supported?

Synthetic resolution: application uses db.example.test; resolver returns retired 192.0.2.10; approved database is 192.0.2.20; direct authorized test to new endpoint succeeds.

1. Correct the controlled name-resolution state and verify the complete service path
2. Replace the NIC before checking the record
3. Increase connection timeouts while retaining the retired destination
4. Rebuild the database before checking the client resolver

**Correct option(s):** 1

- Option 1: Correct. The observed endpoint mapping is wrong.
- Option 2: Incorrect. No NIC failure is established.
- Option 3: Incorrect. Waiting longer does not correct the endpoint mapping.
- Option 4: Incorrect. The observed name mapping should be corrected and retested first.

**HARDWARE-ENGINEERING-Q0090 · single · diagnosis**

A client reaches a database by IP but the application fails by name. What remains unverified?

1. Whether a longer storage retry timeout fixes name resolution
2. Whether increasing CPU capacity changes resolver results
3. The application's actual name-resolution and connection path
4. Whether any IP packet can reach the host

**Correct option(s):** 3

- Option 1: Incorrect. Storage retries do not correct the client's endpoint lookup.
- Option 2: Incorrect. The name-specific failure does not establish a compute constraint.
- Option 3: Correct. IP reachability does not validate name use.
- Option 4: Incorrect. The direct test already provides limited reachability evidence.

**HARDWARE-ENGINEERING-Q0091 · single · implementation**

A wrong host clock makes a valid certificate appear expired. What is the appropriate repair route?

1. Restore approved time/trust configuration and retest validation
2. Replace the certificate without checking host time
3. Permanently disable certificate checks
4. Increase the connection retry count without correcting time

**Correct option(s):** 1

- Option 1: Correct. Disabling validation would bypass the security objective.
- Option 2: Incorrect. A valid certificate can fail again while the clock remains wrong.
- Option 3: Incorrect. That hides rather than repairs the trust problem.
- Option 4: Incorrect. Retries do not repair the validity-interval comparison.

**HARDWARE-ENGINEERING-Q0092 · single · implementation**

A recovery tool requires the identity service that the tool must restore. What does the plan need?

1. An assumption that identity failures never occur
2. Uncontrolled shared administrator access everywhere
3. A second copy of the same circular diagram
4. An approved independent bootstrap access path

**Correct option(s):** 4

- Option 1: Incorrect. That contradicts the scenario.
- Option 2: Incorrect. Recovery needs controlled authority, not indiscriminate privilege.
- Option 3: Incorrect. Duplication does not remove the dependency.
- Option 4: Correct. The circular recovery dependency must be broken deliberately.

**HARDWARE-ENGINEERING-Q0093 · single · implementation**

Logs are available only through 01:40 but the required database recovery point is 01:55. Which claim is justified?

1. The base backup alone necessarily contains all later transactions
2. A larger disk automatically recreates the missing logs
3. Starting the database proves all 01:55 data exists
4. The supplied artifacts do not establish the required recovery point

**Correct option(s):** 4

- Option 1: Incorrect. Later committed changes need the supported additional recovery artifacts.
- Option 2: Incorrect. Capacity cannot invent missing records.
- Option 3: Incorrect. Startup does not reconstruct unavailable transactions.
- Option 4: Correct. The missing interval must be resolved or reported.

**HARDWARE-ENGINEERING-Q0094 · single · implementation**

A rebuilt service uses the same display name but cannot access old data. What should be checked?

1. Only the administrator's access to the same data
2. Whether every user has been made an administrator
3. Only the account display name
4. Whether its actual security identity and permissions match the intended baseline

**Correct option(s):** 4

- Option 1: Incorrect. Administrative access does not prove the service identity has rights.
- Option 2: Incorrect. Excessive privilege is not a proper first repair.
- Option 3: Incorrect. A display name may refer to a different security principal.
- Option 4: Correct. Names can conceal changed principals or rights.

**HARDWARE-ENGINEERING-Q0095 · single · implementation**

What distinguishes a service recovery test from merely booting supporting VMs?

1. Only a successful login to each supporting VM
2. Only that the database process is running
3. Only the hypervisor's aggregate healthy state
4. Validation of required application function, data point and access authority through the dependency chain

**Correct option(s):** 4

- Option 1: Incorrect. Guest access is earlier than the required dependent function.
- Option 2: Incorrect. A running process does not establish recovered records or client access.
- Option 3: Incorrect. The application dependency chain needs its own verification.
- Option 4: Correct. The business/OT function is the acceptance target.

**HARDWARE-ENGINEERING-Q0096 · single · implementation**

Two incident logs use unsynchronized clocks. What is unsafe?

1. Correlating events with additional shared observations
2. Recording the known clock offsets
3. Treating their displayed timestamps as an exact cross-host event order
4. Retaining collection times and time zones

**Correct option(s):** 3

- Option 1: Incorrect. Independent evidence can constrain timing.
- Option 2: Incorrect. That improves interpretation.
- Option 3: Correct. Clock offsets can reverse apparent ordering.
- Option 4: Incorrect. They help reconstruct the timeline.

#### Recall

**A replacement host's hardware passes diagnostics, but DNS points the service name to the retired address. Which correction is supported?**

Correct the controlled name-resolution state and verify the complete service path. Correct. The observed endpoint mapping is wrong.

**A client reaches a database by IP but the application fails by name. What remains unverified?**

The application's actual name-resolution and connection path. Correct. IP reachability does not validate name use.

**A wrong host clock makes a valid certificate appear expired. What is the appropriate repair route?**

Restore approved time/trust configuration and retest validation. Correct. Disabling validation would bypass the security objective.

**A recovery tool requires the identity service that the tool must restore. What does the plan need?**

An approved independent bootstrap access path. Correct. The circular recovery dependency must be broken deliberately.

**Logs are available only through 01:40 but the required database recovery point is 01:55. Which claim is justified?**

The supplied artifacts do not establish the required recovery point. Correct. The missing interval must be resolved or reported.

#### References

- [PostgreSQL current documentation: Backup and Restore](https://www.postgresql.org/docs/current/backup.html)
- [PostgreSQL: Continuous Archiving and Point-in-Time Recovery](https://www.postgresql.org/docs/current/continuous-archiving.html)

## HARDWARE-ENGINEERING-M06 — Hardware commissioning and diagnostic validation

### HARDWARE-ENGINEERING-L13 — Commissioning tests: limits, workloads, latency and integrity

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L12

Commissioning asks whether the installed system meets defined requirements in defined states. Write the acceptance criteria before running the test: configuration, workload, duration, input size, concurrency, required throughput, latency percentile, allowed errors, environmental limits and abort conditions. Specify which measurements come from the application, host, device and facilities interfaces. A benchmark score without these conditions cannot establish the required service or be compared fairly with another system.

Test coverage follows mechanisms. Memory diagnostics exercise patterns and address ranges within the supported tool limits. Storage checks include data integrity, latency and throughput for representative request sizes and read/write mix. PCIe/NIC/GPU checks compare negotiated links, error counters, topology and application behavior. Power and thermal validation correlates demand, inlet conditions, fan or liquid state, device clocks and any limiting reason. A single synthetic CPU workload does not validate storage persistence, NIC failover or GPU communication. Neither does a clean inventory summary establish behavior under demand.

A bounded load test has a purpose, a safe envelope and a stop mechanism. Use approved diagnostics and a representative workload in an authorized lab or maintenance state. Establish current redundancy and workload ownership before starting. Avoid uncontrolled burn-in on production systems: a test can consume the very capacity needed for live recovery or stress a degraded component. Check that monitoring continues during the test and that the person responsible for stopping it can actually do so. Stop conditions use platform-specific limits and service criteria supplied by the approved plan, not invented generic temperatures.

Interpret distributions rather than averages alone. Mean latency can remain low while a small fraction of transactions violates the user requirement. Record the percentile definition and sample count. For a simple teaching nearest-rank percentile, sort N samples and select rank ceil(p×N); real monitoring systems can use different interpolation or histogram approximations. Do not average percentiles from unequal or separate populations and call the result the combined percentile. Preserve raw or appropriately aggregated evidence that supports the reported statistic.

Queueing connects utilization and latency. When arrival demand approaches a constrained service rate, requests wait and latency can rise sharply even when throughput stops increasing. In a stable measurement interval, Little's Law relates average in-flight work L, average completion rate λ and average time W by L=λW, provided the quantities describe the same system boundary and conditions. It is not a guarantee for a transient outage or mixed measurements. Use it as a consistency check: units and boundaries matter.

Acceptance needs both positive and discriminating negative evidence. Introduce a safe documented fault in the lab, such as a controlled configuration mismatch or approved path disablement, and show that the test detects the resulting requirement failure. Restore the intended state and repeat the relevant measurement. This avoids a plan that passes because it never exercises the fault mechanism. Preserve baseline, fault, correction and retest artifacts with identity and time. Release only the requirements actually demonstrated; unresolved conditions remain explicit holds or approved bounded exceptions.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic acceptance sample contains 20 sorted transaction latencies: eighteen at 8 ms, one at 30 ms and one at 200 ms. The requirement is nearest-rank p95 ≤20 ms and zero integrity mismatches. All data hashes match.

**Reasoning:** The nearest-rank p95 index is ceil(0.95×20)=19, so p95 is 30 ms and the latency requirement fails. Integrity passes for the checked synthetic dataset, but that does not cancel the latency failure. The mean is (18×8+30+200)/20=18.7 ms, showing why the mean alone would mislead this acceptance decision.

#### Guided practice

An interval completes 2,000 requests/s with average time 0.004 s under stable conditions. What average in-flight count is consistent with that boundary?

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** L=2,000×0.004=8 requests. Check that throughput and latency cover the same requests and interval; do not substitute a tail percentile for the mean in this calculation.

#### Independent task

Environment: analytical / emulator / physical

Critique an acceptance plan that records only CPU utilization, then execute the offline latency/integrity case and design a bounded equipment test.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Predeclare configuration, workload, limits and abort conditions.
- Calculate the stated percentile correctly and retain raw samples.
- Map each requirement to a mechanism-specific observation and retest.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0097 · single · implementation**

Twenty sorted latencies contain eighteen values of 8 ms, then 30 ms and 200 ms. What is nearest-rank p95?

Synthetic sorted latency sample (ms): [8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,30,200]. Percentile rule: nearest rank ceil(p×N).

1. 30 ms
2. 8 ms
3. 200 ms
4. 18.7 ms

**Correct option(s):** 1

- Option 1: Correct. Rank ceil(0.95×20)=19 selects 30 ms.
- Option 2: Incorrect. That is the eighteenth value, below the required rank.
- Option 3: Incorrect. That is the maximum and twentieth value.
- Option 4: Incorrect. That is the arithmetic mean, not p95.

**HARDWARE-ENGINEERING-Q0098 · single · diagnosis**

The latency requirement fails but all synthetic hashes match. What is the acceptance outcome?

1. Integrity must also be marked failed automatically
2. The entire system passes because integrity is more important by default
3. Discard the latency requirement after seeing results
4. Integrity evidence passes within its scope, while latency remains failed

**Correct option(s):** 4

- Option 1: Incorrect. A latency failure does not falsify matching hashes.
- Option 2: Incorrect. No such priority override was authorized.
- Option 3: Incorrect. That changes the acceptance basis after the test.
- Option 4: Correct. Requirements are assessed separately.

**HARDWARE-ENGINEERING-Q0099 · single · implementation**

Under stable matched boundaries, completion rate is 2,000/s and mean time is 0.004 s. What average in-flight count follows?

1. 8
2. 2,000
3. 500,000
4. 0.000002

**Correct option(s):** 1

- Option 1: Correct. Little's Law gives 2,000×0.004.
- Option 2: Incorrect. Rate alone is not the average concurrent count.
- Option 3: Incorrect. That divides where multiplication is needed.
- Option 4: Incorrect. That reverses the relationship.

**HARDWARE-ENGINEERING-Q0100 · single · implementation**

A CPU-only stress test passes. Which requirement is still untested by that result alone?

1. Storage durability under the specified failure state
2. The observed CPU workload completion duration
3. Ability to run that CPU workload during the measured interval
4. The CPU tool's observed completion status

**Correct option(s):** 1

- Option 1: Correct. CPU exercise does not validate persistent-write behavior.
- Option 2: Incorrect. The CPU test records its own elapsed duration; it does not test storage durability.
- Option 3: Incorrect. The test directly exercised it.
- Option 4: Incorrect. That status was measured, although its scope is limited.

**HARDWARE-ENGINEERING-Q0101 · single · implementation**

What must a bounded load test define before execution?

1. Only the desired favorable benchmark score
2. Workload, monitoring, approved limits and an effective stop process
3. Only the tool's default unlimited duration
4. Only the diagnostic tool name

**Correct option(s):** 2

- Option 1: Incorrect. That does not control risk or establish method.
- Option 2: Correct. A test needs a controlled operating envelope.
- Option 3: Incorrect. Defaults may not fit the authorized environment.
- Option 4: Incorrect. Tool identity alone does not define workload, limits or stopping authority.

**HARDWARE-ENGINEERING-Q0102 · single · implementation**

Two systems report p95 from different sample populations. What should be avoided?

1. Retaining each sample count and method
2. Reporting the populations separately
3. Computing a combined distribution from suitable raw data
4. Averaging their p95 values and presenting that as the combined p95

**Correct option(s):** 4

- Option 1: Incorrect. That supports interpretation.
- Option 2: Incorrect. Separate reporting preserves scope.
- Option 3: Incorrect. That can support a valid combined percentile.
- Option 4: Correct. Percentiles do not generally combine that way.

**HARDWARE-ENGINEERING-Q0103 · single · diagnosis**

Why introduce a safe known fault during commissioning validation?

1. To prove that every possible fault has been tested
2. To justify uncontrolled testing on live degraded systems
3. To show that the acceptance method detects the relevant failure mechanism
4. To remove the need for baseline evidence

**Correct option(s):** 3

- Option 1: Incorrect. One introduced fault cannot establish exhaustive coverage.
- Option 2: Incorrect. The exercise must remain authorized and bounded.
- Option 3: Correct. A passing test alone may be insensitive.
- Option 4: Incorrect. The comparison requires baseline context.

**HARDWARE-ENGINEERING-Q0104 · single · implementation**

A test uses a tail percentile in place of mean time in Little's Law. What is wrong?

1. The equation eliminates the need to define a system boundary
2. Throughput never has units
3. Little's Law uses only maximum values
4. The relationship requires compatible averages for the stated boundary

**Correct option(s):** 4

- Option 1: Incorrect. The boundary determines what the quantities represent.
- Option 2: Incorrect. The units are essential.
- Option 3: Incorrect. It relates averages under suitable conditions.
- Option 4: Correct. A tail statistic is not the mean residence time.

#### Recall

**Twenty sorted latencies contain eighteen values of 8 ms, then 30 ms and 200 ms. What is nearest-rank p95?**

30 ms. Correct. Rank ceil(0.95×20)=19 selects 30 ms.

**The latency requirement fails but all synthetic hashes match. What is the acceptance outcome?**

Integrity evidence passes within its scope, while latency remains failed. Correct. Requirements are assessed separately.

**Under stable matched boundaries, completion rate is 2,000/s and mean time is 0.004 s. What average in-flight count follows?**

8. Correct. Little's Law gives 2,000×0.004.

**A CPU-only stress test passes. Which requirement is still untested by that result alone?**

Storage durability under the specified failure state. Correct. CPU exercise does not validate persistent-write behavior.

**What must a bounded load test define before execution?**

Workload, monitoring, approved limits and an effective stop process. Correct. A test needs a controlled operating envelope.

#### References

- [Dell PowerEdge R760 Installation and Service Manual: illustrative OEM source; use the manual for the actual selected model](https://www.dell.com/support/manuals/en-us/poweredge-r760/per760_ism_pub/about-this-document?guid=guid-bf9eed9e-52b2-4860-911b-954e25631b96&lang=en-us)

### HARDWARE-ENGINEERING-L14 — Correlated fault diagnosis: hardware, firmware, thermal and upstream causes

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L13

A symptom is an observation; a cause is an explanation supported by discriminating evidence. Start with the required function and the first known deviation. Build a timeline using synchronized or corrected timestamps and stable component identities. Preserve raw logs, counters, settings and workload context before resets erase them. Record what changed recently, but do not equate temporal proximity with proof. A firmware update and a cooling obstruction can occur in the same maintenance window.

Use a hypothesis table. For each candidate cause, state an expected observation, a low-impact check that distinguishes it from alternatives, and what result would weaken it. For low throughput, candidates include source starvation, CPU/NUMA placement, reduced link width, queueing, protocol errors, driver incompatibility, power capping and thermal throttling. Hardware replacement is one possible corrective action after localization, not the default response to every red indicator. A failed application authentication test can be caused by time or identity state while all hardware works.

Error severity and recovery behavior matter. Corrected PCIe errors differ from uncorrectable or fatal events; the platform and driver determine what recovery is supported. A link or device reset can affect sibling functions and storage dependencies. Preserve the topology and exact error messages before assuming that one function can be reset independently. A post-reset disappearance of counters does not prove the underlying fault is fixed. Look for restored function and absence of recurrence over a suitable comparable observation interval.

Thermal and power limits can reduce clocks to protect equipment or obey a configured envelope. Correlate clock changes with supported limit-reason fields, component temperatures, inlet conditions, fan/flow state and workload. A lower clock is not automatically a defective CPU or GPU. A configured power cap can be intentional; its compatibility with service performance must still be assessed. If the workload changes, compare normalized performance and relevant conditions rather than treating every watt or temperature difference as a fault.

Controlled substitution can strengthen diagnosis when it is authorized, supported and does not destroy evidence. Change one meaningful factor at a time where practical: cable, supported slot, known-good compatible part, driver baseline or workload placement. Record both identity and state. If a fault follows a component, that supports a component-related hypothesis; if it stays with the slot or path, platform or environmental causes become more plausible. Neither pattern alone eliminates every interaction. Avoid swapping several parts simultaneously and then claiming a uniquely identified cause.

A completed diagnostic record contains the symptom, scope, timeline, competing explanations, tests, observed results, selected correction and retest. Escalate with a concise evidence bundle when the supported procedure or certainty limit is reached. Do not invent a root cause to close a ticket. It is legitimate to restore service with a documented unresolved cause and a recurrence-monitoring plan when the governance process accepts that state. Commissioning acceptance, however, must still satisfy its stated release criteria or explicitly remain held.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic GPU workload falls from 120 to 70 units/s. GPU clocks fall at the same time as a thermal-limit flag. Inlet temperature rises from 24 to 34°C after a cable bundle blocks the approved air path. PCIe width and input delivery remain unchanged.

**Reasoning:** The correlated evidence supports an airflow/thermal explanation more strongly than a PCIe-width or source-starvation explanation. Restore the approved routing through authorized work, confirm inlet and thermal state under the same workload, and retest throughput. The numerical temperatures are case observations, not universal safe limits. Preserve the before/after record and check recurrence.

#### Guided practice

A fault disappears after replacing both a NIC and its cable. What can be concluded about root cause?

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** The combined intervention restored the tested function, but it does not uniquely distinguish NIC from cable or an interaction. Retain that uncertainty; use supported further evidence or controlled tests if required rather than claiming the NIC alone was proven defective.

#### Independent task

Environment: analytical / emulator / physical

Diagnose the synthetic telemetry cases and write a hypothesis/test/result table that rejects at least one plausible but unsupported replacement.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Correlate identity, timestamps, workload and limiting/error states.
- Use discriminating checks with bounded impact.
- Separate service restoration from proven root cause and define recurrence checks.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0105 · single · implementation**

Throughput falls with a thermal-limit flag and blocked airflow while link width stays unchanged. Which hypothesis is best supported?

Synthetic telemetry: workload 120→70 units/s; thermal-limit flag false→true; inlet 24→34°C; cable obstruction appeared; PCIe width unchanged. Temperatures are observations, not general equipment limits.

1. A proven source-data starvation fault
2. Thermal restriction associated with the altered airflow path
3. A proven driver-version incompatibility as the sole cause
4. A proven reduction in PCIe width

**Correct option(s):** 2

- Option 1: Incorrect. The supplied correlation favors thermal limiting; source starvation is not shown.
- Option 2: Correct. The timing and limit reason align with that mechanism.
- Option 3: Incorrect. No driver-version change or compatibility evidence is supplied.
- Option 4: Incorrect. The measured width did not change.

**HARDWARE-ENGINEERING-Q0106 · single · diagnosis**

Both a NIC and its cable are replaced and the fault disappears. What is the strongest justified conclusion?

1. The cable alone is conclusively proven faulty
2. Neither component could have contributed
3. The combined intervention restored the tested function, but the individual cause is unresolved
4. The NIC alone is conclusively proven faulty

**Correct option(s):** 3

- Option 1: Incorrect. The NIC changed too.
- Option 2: Incorrect. The result does not exclude either.
- Option 3: Correct. Two simultaneous changes prevent unique attribution.
- Option 4: Incorrect. The cable changed too.

**HARDWARE-ENGINEERING-Q0107 · single · implementation**

A counter returns to zero after a reboot. What is still needed to establish correction?

1. Deletion of the earlier logs
2. Functional retest and a comparable recurrence observation interval
3. A claim that all cumulative counters are permanent
4. Only a screenshot of zero

**Correct option(s):** 2

- Option 1: Incorrect. That removes diagnostic context.
- Option 2: Correct. Resetting a counter can erase evidence without fixing the cause.
- Option 3: Incorrect. Many can reset.
- Option 4: Incorrect. That does not establish sustained behavior.

**HARDWARE-ENGINEERING-Q0108 · single · implementation**

A device reset may affect sibling functions on the same hardware. What must be reviewed?

1. Topology, supported reset semantics and dependent services
2. An assumption that every function has independent power
3. Only the selected function's logical interface name
4. Only that the selected function has no active user process

**Correct option(s):** 1

- Option 1: Correct. The reset scope can exceed one visible function.
- Option 2: Incorrect. That independence must be established.
- Option 3: Incorrect. A logical name does not establish the physical reset domain.
- Option 4: Incorrect. Sibling functions and dependent services can still be affected.

**HARDWARE-ENGINEERING-Q0109 · single · implementation**

What weakens a claim that a recent firmware update caused a failure?

1. A repeated assertion without new observations
2. A ticket number assigned to the update
3. Evidence that an independent airflow obstruction changed in the same interval
4. The update appearing earlier in the timeline

**Correct option(s):** 3

- Option 1: Incorrect. Repetition does not strengthen evidence.
- Option 2: Incorrect. Administrative tracking does not prove causation.
- Option 3: Correct. Competing changes need discrimination.
- Option 4: Incorrect. Temporal order alone is not definitive causation.

**HARDWARE-ENGINEERING-Q0110 · single · diagnosis**

A fault follows a component into a supported known-good path. What does that provide?

1. Evidence supporting a component-related cause while interactions still need consideration
2. No useful evidence because substitution can never help
3. Proof that all firmware interactions are impossible
4. Proof that the old slot is defective

**Correct option(s):** 1

- Option 1: Correct. Controlled substitution strengthens but does not universalize the inference.
- Option 2: Incorrect. A controlled comparison can be informative.
- Option 3: Incorrect. The component can carry firmware-dependent behavior.
- Option 4: Incorrect. The fault moved away from that slot.

**HARDWARE-ENGINEERING-Q0111 · single · implementation**

A configured power cap explains reduced clocks. What should acceptance still verify?

1. Whether the intended cap permits the required service performance
2. That the cap should always be removed immediately
3. That every lower clock is automatically a physical defect
4. That workload measurement is unnecessary

**Correct option(s):** 1

- Option 1: Correct. An intentional limit can still conflict with requirements.
- Option 2: Incorrect. It may protect an approved power envelope.
- Option 3: Incorrect. The cap provides another explanation.
- Option 4: Incorrect. Performance is the requirement being assessed.

**HARDWARE-ENGINEERING-Q0112 · single · implementation**

Service is restored but the root cause remains uncertain. Which record is defensible?

1. Claim every future occurrence is impossible
2. Invent a component defect to close the ticket
3. State the uncertainty, accepted operating conditions and recurrence plan
4. Delete all competing hypotheses

**Correct option(s):** 3

- Option 1: Incorrect. The unresolved cause prevents that assurance.
- Option 2: Incorrect. That misrepresents evidence.
- Option 3: Correct. Restoration and causal proof are different claims.
- Option 4: Incorrect. They may be relevant to recurrence.

#### Recall

**Throughput falls with a thermal-limit flag and blocked airflow while link width stays unchanged. Which hypothesis is best supported?**

Thermal restriction associated with the altered airflow path. Correct. The timing and limit reason align with that mechanism.

**Both a NIC and its cable are replaced and the fault disappears. What is the strongest justified conclusion?**

The combined intervention restored the tested function, but the individual cause is unresolved. Correct. Two simultaneous changes prevent unique attribution.

**A counter returns to zero after a reboot. What is still needed to establish correction?**

Functional retest and a comparable recurrence observation interval. Correct. Resetting a counter can erase evidence without fixing the cause.

**A device reset may affect sibling functions on the same hardware. What must be reviewed?**

Topology, supported reset semantics and dependent services. Correct. The reset scope can exceed one visible function.

**What weakens a claim that a recent firmware update caused a failure?**

Evidence that an independent airflow obstruction changed in the same interval. Correct. Competing changes need discrimination.

#### References

- [Linux kernel: PCI error recovery](https://docs.kernel.org/PCI/pci-error-recovery.html)
- [NVIDIA System Management Interface documentation](https://docs.nvidia.com/deploy/nvidia-smi/index.html)

## HARDWARE-ENGINEERING-M07 — Day-to-day health and sustaining engineering

### HARDWARE-ENGINEERING-L15 — Health telemetry, trends and maintenance decisions

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L14

An operating baseline records expected behavior under identifiable workload and environmental conditions. Collect hardware identity, sensor source, units, timestamp, collection interval and quality/freshness state alongside the value. A dashboard color is a conclusion produced by rules; inspect the underlying measurement and rule when an anomaly appears. Missing, stale and healthy are different states. A sensor reading from a replaced component must not be silently joined to the old component's lifetime trend.

Counters require interpretation. A cumulative corrected-ECC count, interface error count or drive-write count becomes a rate only after comparing compatible observations over a known interval. Account for resets, rollover and device replacement. A negative delta is often a discontinuity rather than a negative error rate. Compare rates over similar workload or exposure where appropriate. Ten errors during a minute of intense traffic are not necessarily equivalent to ten during a month of idle operation. Model-specific severity, recurrence and service guidance determine action.

Drive health combines indicators such as media errors, spare availability, endurance usage, temperature and controller-reported state, but names and meanings vary by device family. A nominal 'healthy' summary cannot override a repeated integrity error or a known service advisory. Conversely, a lifetime usage indicator near a planning threshold is not proof of immediate physical failure. Use the OEM interpretation, actual workload, redundancy state, replacement lead time and backup evidence to decide monitor, plan maintenance, reduce exposure or escalate.

Correlate component temperature with inlet conditions, workload, fan or flow state, power and clock/limit behavior. A temperature increase under a larger workload can be expected; the same increase at unchanged demand may indicate a changed heat path or sensor issue. Compare like conditions before declaring deterioration. Avoid universal numeric alarm limits across processors, GPUs, DIMMs, disks and liquid systems. Retain the applicable threshold source and its configuration version. Alarm acknowledgement records awareness; it does not repair the condition or close the maintenance action.

Sustaining engineering turns observations into a controlled feedback loop. Define normal checks, event triage, escalation ownership, support engagement, planned changes and post-change verification. Preserve enough raw evidence to explain the decision and detect recurrence. Review firmware compliance against an approved baseline and relevant advisories rather than automatically updating every device on discovery. Support status, warranty terms and spare availability influence restoration risk and should be visible before a failure, not discovered during the outage.

An operating record must include an actual sequence of normal observation, deterioration, investigation, decision, correction or escalation and follow-up. The synthetic exercises teach the analysis; the curriculum's operating campaign requires dated observations from the learner's authorized environment. Reconcile physical inventory with management and host records after maintenance. Explain why the chosen intervention addresses the evidence and what observation would show that it failed. A closed ticket without recurrence criteria or a verified function check is administrative completion, not a complete engineering feedback loop.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic DIMM counter rises from 100 to 106 over 60 minutes, then from 106 to 130 over the next 60 minutes at comparable workload. The DIMM identity is unchanged and no reset occurred. A generic dashboard remains green.

**Reasoning:** The corrected-event rates are 6/h and 24/h, a fourfold increase in this observation. That warrants model-specific trend review and correlation, not automatic acceptance based on dashboard color or a universal replacement threshold. Preserve location and timestamps, inspect related controller/channel evidence, assess redundancy and engage the applicable service procedure. Define a follow-up interval after any correction.

#### Guided practice

A NIC counter reads 8,000, then 20 after a reboot. Calculate what can be concluded.

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** The raw subtraction is not a meaningful negative error count; the counter reset breaks continuity. Start a new interval, retain the reset timestamp and compare subsequent compatible readings.

#### Independent task

Environment: analytical / emulator / physical

Analyze an operating log with counter resets, deteriorating ECC and stale health; propose maintenance and recurrence checks.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Compute only valid rates and preserve discontinuities.
- Use model-specific interpretation with competing causes.
- Connect an intervention to measurable post-change and recurrence evidence.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0113 · single · implementation**

A counter rises 100 to 106 in one hour and 106 to 130 in the next comparable hour. What changed?

Synthetic stable-identity ECC readings: 08:00=100;09:00=106;10:00=130; comparable workload; no reset/replacement.

1. The second rate is 130/h
2. The lifetime total fell by 24
3. The observed rate increased from 6/h to 24/h
4. The device must be replaced under a universal 24/h rule

**Correct option(s):** 3

- Option 1: Incorrect. That treats the cumulative value as an interval count.
- Option 2: Incorrect. The counter increased.
- Option 3: Correct. Compatible differences over equal intervals produce those rates.
- Option 4: Incorrect. No universal threshold was supplied.

**HARDWARE-ENGINEERING-Q0114 · single · implementation**

A cumulative counter drops after a reboot. How should the analyst handle the interval?

1. Report a negative physical error rate
2. Mark a reset discontinuity and start a new comparable rate interval
3. Hide the reboot so the graph looks smooth
4. Add the two values and divide by uptime without context

**Correct option(s):** 2

- Option 1: Incorrect. Counters do not represent errors being undone.
- Option 2: Correct. Negative subtraction is not a meaningful event rate here.
- Option 3: Incorrect. That conceals the measurement boundary.
- Option 4: Incorrect. That mixes incompatible counter epochs.

**HARDWARE-ENGINEERING-Q0115 · single · diagnosis**

A health summary is green while repeated integrity errors occur. What should govern investigation?

1. Only a second copy of the same summary status
2. The green color alone
3. The assumption that every summary includes every failure mechanism
4. The underlying error evidence and applicable model-specific guidance

**Correct option(s):** 4

- Option 1: Incorrect. Repeating the aggregate conclusion does not investigate the raw errors.
- Option 2: Incorrect. It cannot invalidate observed errors.
- Option 3: Incorrect. That coverage is not guaranteed.
- Option 4: Correct. An aggregate label can omit important detail.

**HARDWARE-ENGINEERING-Q0116 · single · implementation**

A component is replaced but its old lifetime trend is continued under the same slot label. What is missing?

1. A requirement to discard every historical observation
2. Stable component identity and a marked replacement boundary
3. A continuous graph using the slot label alone
4. A rule to add old and new lifetimes without distinction

**Correct option(s):** 2

- Option 1: Incorrect. History remains useful when identities are preserved.
- Option 2: Correct. Slot continuity does not mean component continuity.
- Option 3: Incorrect. The same slot can contain different components with different histories.
- Option 4: Incorrect. That obscures the physical history.

**HARDWARE-ENGINEERING-Q0117 · single · implementation**

A temperature rises after workload doubles. What comparison is needed before declaring deterioration?

1. Comparable workload, inlet and control-state context
2. An assumption that temperature never changes in healthy equipment
3. Only the current value without its source
4. Only the oldest recorded temperature

**Correct option(s):** 1

- Option 1: Correct. Demand changes can explain thermal changes.
- Option 2: Incorrect. Healthy equipment responds to load and environment.
- Option 3: Incorrect. A value alone lacks necessary context.
- Option 4: Incorrect. Different operating conditions can make it misleading.

**HARDWARE-ENGINEERING-Q0118 · single · implementation**

What does acknowledging an alarm establish?

1. That recurrence is impossible
2. That the underlying component has been repaired
3. That sensor calibration was completed
4. Awareness or handling state, not physical correction

**Correct option(s):** 4

- Option 1: Incorrect. No such test was performed.
- Option 2: Incorrect. Acknowledgement does not perform repair.
- Option 3: Incorrect. That is a different action requiring evidence.
- Option 4: Correct. The fault and its verification remain separate.

**HARDWARE-ENGINEERING-Q0119 · single · implementation**

A firmware compliance review finds a newer release. What should decide deployment?

1. Approved compatibility, advisory relevance, operational risk and recovery evidence
2. Deleting the baseline to remove the discrepancy
3. Automatic replacement of every older component
4. The release number alone

**Correct option(s):** 1

- Option 1: Correct. Availability of a newer image is only an input.
- Option 2: Incorrect. That destroys the review reference.
- Option 3: Incorrect. A firmware difference is not necessarily a hardware defect.
- Option 4: Incorrect. It does not establish suitability.

**HARDWARE-ENGINEERING-Q0120 · single · implementation**

Which record best completes a sustaining-engineering action?

1. A dashboard screenshot with the timestamp cropped out
2. Observed issue, reasoned correction, function retest and recurrence criteria
3. A replacement purchase order alone
4. A closed ticket with no technical observations

**Correct option(s):** 2

- Option 1: Incorrect. Freshness and sequence are lost.
- Option 2: Correct. The feedback loop connects evidence and effectiveness.
- Option 3: Incorrect. Procurement does not prove installation or correction.
- Option 4: Incorrect. Administrative closure is insufficient.

#### Recall

**A counter rises 100 to 106 in one hour and 106 to 130 in the next comparable hour. What changed?**

The observed rate increased from 6/h to 24/h. Correct. Compatible differences over equal intervals produce those rates.

**A cumulative counter drops after a reboot. How should the analyst handle the interval?**

Mark a reset discontinuity and start a new comparable rate interval. Correct. Negative subtraction is not a meaningful event rate here.

**A health summary is green while repeated integrity errors occur. What should govern investigation?**

The underlying error evidence and applicable model-specific guidance. Correct. An aggregate label can omit important detail.

**A component is replaced but its old lifetime trend is continued under the same slot label. What is missing?**

Stable component identity and a marked replacement boundary. Correct. Slot continuity does not mean component continuity.

**A temperature rises after workload doubles. What comparison is needed before declaring deterioration?**

Comparable workload, inlet and control-state context. Correct. Demand changes can explain thermal changes.

#### References

- [NVIDIA System Management Interface documentation](https://docs.nvidia.com/deploy/nvidia-smi/index.html)
- [DMTF Redfish standard and specifications](https://www.dmtf.org/standards/redfish)

### HARDWARE-ENGINEERING-L16 — Inventory, support, spares and controlled configuration change

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L15

Inventory is a relationship between an asset, its location, components, configuration, owner, service role and lifecycle state. Track serials or other stable identifiers, exact part revisions, firmware/driver baselines, rack/port/power assignments, warranty/support terms and relevant licenses. A hostname or IP address can change and may be reused; it is not a complete physical identity. Reconcile receiving records, physical labels, BMC and host observations at defined events such as installation, replacement, relocation and retirement.

A spare strategy follows failure impact and restoration time. Determine compatible FRU classes, failure-domain concentration, stock location, lead time, support coverage and the staff/procedure required to use the spare. A boxed replacement that cannot be installed during the required window is not equivalent to demonstrated recovery readiness. Some spares need an approved firmware level or configuration before use. Batteries, flash media and other parts can have shelf-life, maintenance or storage-condition considerations specified by the supplier; the plan must retain those requirements.

Demand and logistics can share failure modes. Several identical aging components may fail close together, and one globally shared spare may be consumed by the first incident. An offsite spare may be inaccessible during the same transport or building disruption that created the outage. Review stock assumptions against the actual credible scenarios rather than multiplying a nominal availability figure. Decide which risks are reduced by local stock, vendor response, supported alternatives, workload evacuation or architectural redundancy. Document trade-offs and the authority accepting residual exposure.

Configuration change starts with a reason, scope and verified current state. A change could correct a defect, close a security issue, restore compliance or improve measured performance. Identify affected components and services, supported target state, dependency order, maintenance state, access, backup/recovery and acceptance criteria. Include the 'do not change yet' alternative when evidence or prerequisites are insufficient. A routine configuration action can still require coordination if it alters redundancy, device ownership or a shared management path.

Review the actual proposed difference, not a vague statement such as 'optimize hardware.' A BIOS policy, NIC queue setting, controller cache mode or firmware image changes a specific mechanism. State the expected benefit and a measurable adverse effect to watch. Capture before/after settings and relevant performance, error and security evidence. If several changes are intentionally bundled, explain why and accept the resulting diagnostic limitation. Restoration of prior configuration may be separate from firmware rollback or data recovery.

Post-change verification includes read-back state, hardware identity, affected service function, telemetry and remaining authority. Update inventory and the approved baseline only after the disposition is clear; do not overwrite the historical state. Record temporary exceptions and their expiry or review owner. The independent task should show a reviewed change, including a rejected incompatible spare or unsupported setting, and demonstrate how a later engineer can reconstruct what happened. This connects hardware operations to the portfolio's full-lifecycle evidence rather than accumulating isolated screenshots.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic service has a four-hour restoration target. Its only spare NIC is at an offsite store with a six-hour access-and-delivery time, followed by one hour of installation and validation. The dashboard marks spares ready because quantity is one.

**Reasoning:** The stated path needs at least seven hours, so physical stock count alone does not meet the four-hour target. Evaluate local compatible stock, an alternative recovery architecture or a revised approved service arrangement. Include staff, supported firmware, access and validation time rather than counting only shipping.

#### Guided practice

A change proposes enabling write-back because latency is high, but the controller protection unit is failed. Write the review decision.

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** Hold/reject the unsupported unsafe policy change. Investigate and repair the protection condition through the supported procedure, then test the approved cache behavior and service requirement. A performance objective does not justify removing the persistence guarantee without an explicit suitable design.

#### Independent task

Environment: analytical / emulator / physical

Build a component/spare register and review a specific configuration change with before/after evidence and a bounded recovery plan.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Link exact compatible parts to service and restoration requirements.
- Calculate access, installation and validation time.
- Retain historical baseline and a measurable post-change outcome.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0121 · single · implementation**

A spare takes six hours to obtain and one hour to install/validate against a four-hour target. What does the plan show?

Synthetic recovery route: offsite spare access/delivery=6h; installation/validation=1h; required restoration≤4h.

1. The target is met if the box is sealed
2. Only the one-hour installation matters
3. The target is met because one spare exists
4. The seven-hour route exceeds the target despite a nonzero stock count

**Correct option(s):** 4

- Option 1: Incorrect. Packaging does not reduce the stated elapsed time.
- Option 2: Incorrect. Acquisition delay is part of the recovery path.
- Option 3: Incorrect. Availability in inventory is not timely restoration.
- Option 4: Correct. Readiness includes access and use, not quantity alone.

**HARDWARE-ENGINEERING-Q0122 · single · implementation**

Why retain exact FRU revisions in the spare register?

1. Supported interchangeability can depend on revision and configuration
2. Every revision is necessarily incompatible with every other
3. Revisions replace the need for serial tracking
4. Revision labels prove that firmware rollback is supported

**Correct option(s):** 1

- Option 1: Correct. A family name may hide incompatible variants.
- Option 2: Incorrect. Compatibility must be checked, not universally denied.
- Option 3: Incorrect. Part compatibility and unique identity serve different purposes.
- Option 4: Incorrect. Rollback requires separate evidence.

**HARDWARE-ENGINEERING-Q0123 · single · implementation**

A global spare is counted as independently available to two simultaneous repairs. What assumption needs review?

1. Both repairs compete for the same physical spare
2. The spare necessarily adds parity to both arrays
3. The spare can never be used by either system
4. The spare's location is irrelevant to restoration

**Correct option(s):** 1

- Option 1: Correct. One item cannot satisfy both uses at once.
- Option 2: Incorrect. It is replacement capacity, not extra simultaneous parity.
- Option 3: Incorrect. Compatibility and availability determine use.
- Option 4: Incorrect. Access and transport affect readiness.

**HARDWARE-ENGINEERING-Q0124 · single · implementation**

A proposed change says only 'optimize the server.' What is missing?

1. Permission to skip baseline capture
2. A promise that every metric will improve
3. Only a target benchmark score
4. The specific state difference, mechanism, expected result and acceptance test

**Correct option(s):** 4

- Option 1: Incorrect. Baseline is necessary for comparison and recovery.
- Option 2: Incorrect. Trade-offs need evidence rather than guarantees.
- Option 3: Incorrect. A desired result does not define the proposed setting or method.
- Option 4: Correct. A vague goal is not a reviewable change.

**HARDWARE-ENGINEERING-Q0125 · single · implementation**

A hostname is reused after hardware replacement. What should inventory preserve?

1. Only the newest hostname and no history
2. The distinction between old and new physical identities and their service relationship
3. One merged serial number representing both devices
4. An assumption that the old warranty transferred automatically

**Correct option(s):** 2

- Option 1: Incorrect. Historical state matters for incident and custody records.
- Option 2: Correct. A reusable name is not a unique asset history.
- Option 3: Incorrect. That obscures traceability.
- Option 4: Incorrect. Support terms need verification.

**HARDWARE-ENGINEERING-Q0126 · single · implementation**

Why can an offsite spare be unavailable during the same incident as the failed host?

1. Every offsite spare is always unusable
2. Access or transport can share the disruption's failure domain
3. Inventory software can physically deliver it instantly
4. Physical distance automatically guarantees independence

**Correct option(s):** 2

- Option 1: Incorrect. The risk is scenario-specific.
- Option 2: Correct. Logistics dependencies can be correlated.
- Option 3: Incorrect. A record does not replace logistics.
- Option 4: Incorrect. Distance alone does not address all shared dependencies.

**HARDWARE-ENGINEERING-Q0127 · single · implementation**

Several settings are changed together and performance improves. What should the record state?

1. Historical settings should be erased immediately
2. No before/after evidence is useful
3. Each individual setting is proven solely responsible
4. The bundle and its diagnostic attribution limitation

**Correct option(s):** 4

- Option 1: Incorrect. They support review and recovery.
- Option 2: Incorrect. It still establishes the combined observed result.
- Option 3: Incorrect. The bundled intervention does not show that.
- Option 4: Correct. The result does not uniquely identify each setting's contribution.

**HARDWARE-ENGINEERING-Q0128 · single · implementation**

When should an approved baseline be updated after a change?

1. Before execution so the proposed state appears compliant
2. Whenever a newer version is discovered
3. After the resulting disposition and verification are clear, while retaining history
4. Only after deleting all exception records

**Correct option(s):** 3

- Option 1: Incorrect. That confuses intention with observed state.
- Option 2: Incorrect. Discovery is not change acceptance.
- Option 3: Correct. The baseline should reflect an accepted state with traceability.
- Option 4: Incorrect. Exceptions must be resolved or retained explicitly.

#### Recall

**A spare takes six hours to obtain and one hour to install/validate against a four-hour target. What does the plan show?**

The seven-hour route exceeds the target despite a nonzero stock count. Correct. Readiness includes access and use, not quantity alone.

**Why retain exact FRU revisions in the spare register?**

Supported interchangeability can depend on revision and configuration. Correct. A family name may hide incompatible variants.

**A global spare is counted as independently available to two simultaneous repairs. What assumption needs review?**

Both repairs compete for the same physical spare. Correct. One item cannot satisfy both uses at once.

**A proposed change says only 'optimize the server.' What is missing?**

The specific state difference, mechanism, expected result and acceptance test. Correct. A vague goal is not a reviewable change.

**A hostname is reused after hardware replacement. What should inventory preserve?**

The distinction between old and new physical identities and their service relationship. Correct. A reusable name is not a unique asset history.

#### References

- [Dell PowerEdge R760 Installation and Service Manual: illustrative OEM source; use the manual for the actual selected model](https://www.dell.com/support/manuals/en-us/poweredge-r760/per760_ism_pub/about-this-document?guid=guid-bf9eed9e-52b2-4860-911b-954e25631b96&lang=en-us)

## HARDWARE-ENGINEERING-M08 — Repair, replacement and maintenance states

### HARDWARE-ENGINEERING-L17 — Maintenance states, isolation and supported FRU replacement

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L16

A replaceable component is serviceable only under the conditions specified for that model and configuration. Hot-swap capability is not inferred from a pull tab, front access or similarity to another product. The procedure may require redundancy, workload evacuation, a particular firmware state, an enclosure action or full shutdown and isolation. Distinguish hot-pluggable detection from safe hot replacement while preserving the required service. An accessible PSU module does not authorize opening hazardous internal power circuitry.

Begin with a verified target. Correlate the fault record, stable serial/part identity, physical bay or slot and the management locator function where supported. A logical device name can change across boots or path changes. The person performing the work should confirm the intended component against the approved method before removal. When uncertainty remains, stop at the identification hold point. Removing a healthy member from a degraded storage set can turn a recoverable condition into data loss.

The maintenance state describes the service and protection that remain. Record workload disposition, active redundancy, backup/restoration readiness, management access, safety isolation and any simultaneous work. A dual-PSU host may permit replacement of one failed module only if the surviving supply and path can carry the required load and the OEM method allows it. A memory module may require a shutdown and isolation even though a fan in the same chassis supports a different procedure. Do not generalize one FRU class's method to another.

Use the exact approved replacement part and preparation. Check part revision, capacity/type, firmware prerequisites and physical compatibility. Follow handling, ESD, lifting and cooling instructions. Retain the removed part's identity and custody; storage media may contain data and require controlled return or sanitization under the applicable process. Do not place a suspect component back into general spare stock without disposition. A service replacement is both an engineering state change and an inventory/custody event.

The method has explicit stop conditions: identity mismatch, incompatible spare, inadequate surviving capacity, unexpected alarms, damaged connector, unsupported operation or inability to maintain the approved safe state. The correct response is to hold and coordinate, not improvise a shorter method. Site electrical or coolant intervention stays with the qualified authorized role. The learner must demonstrate the relevant real FRU replacement on available authorized equipment; where a component class is inaccessible, the practical requirement remains open rather than being satisfied by a photograph from another system.

Return to service is a separate gate. Verify installation, component recognition, supported firmware/configuration, health and the required function. Restore intended redundancy and remove temporary maintenance bypasses or access. For storage, rebuild completion and integrity are needed; for a NIC, link, errors, path membership and service traffic matter; for memory, usable capacity/population and supported diagnostics matter. Update records with old/new identities, procedure version, observations and the final disposition. A replacement part being physically seated is earlier than an accepted repair.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic RAID 5 set is degraded because serial D3 in bay 3 failed. The replacement request mistakenly names bay 4, which contains healthy serial D4. The chassis supports the approved drive procedure, but the technician is unsure which mapping is current.

**Reasoning:** Hold removal. Reconcile the current controller identity, physical bay and locator evidence using the supported method. Correct the request and independently confirm the intended failed member before replacement. Removing healthy D4 while D3 remains missing would exceed this layout's remaining tolerance. Physical hot-swap support does not remove the need to verify identity and degraded state.

#### Guided practice

A fan has a tool-free handle. Is that sufficient authorization for replacement while powered?

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** No. Verify the model-specific procedure, supported hot/cold state, redundancy and handling requirements. Appearance cannot establish the safe service method.

#### Independent task

Environment: analytical / emulator / physical

Review a flawed FRU method, then complete one real authorized replacement with an observer and retain the return-to-service evidence.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Reject wrong target, incompatible part and unsupported swap state.
- Record surviving service/protection and stop conditions.
- Retain actual physical execution and post-repair evidence; keep inaccessible classes open.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0129 · single · implementation**

A failed RAID 5 member is D3, but the work order names healthy D4. What must happen before removal?

Synthetic array: RAID5 degraded; failed serial D3/bay3; healthy serial D4/bay4; work order mistakenly names bay4. Current mapping requires confirmation.

1. Treat hot-swap support as permission to ignore member identity
2. Hold and reconcile physical/controller identity, then correct and confirm the target
3. Remove both to eliminate ambiguity
4. Follow the work-order bay without checking

**Correct option(s):** 2

- Option 1: Incorrect. Hot-swap capability does not preserve data if the wrong member is removed.
- Option 2: Correct. Removing the healthy member can exceed remaining tolerance.
- Option 3: Incorrect. That worsens the degraded state.
- Option 4: Incorrect. The conflict is a critical identity exception.

**HARDWARE-ENGINEERING-Q0130 · single · implementation**

A component has a front pull handle. What can be inferred about hot replacement?

1. Nothing definitive without the model-specific supported method and state
2. Every handled component requires a full building shutdown
3. The handle proves that all redundancy prerequisites are satisfied
4. Every handled component can be replaced while powered

**Correct option(s):** 1

- Option 1: Correct. Accessibility does not establish safe hot-swap support.
- Option 2: Incorrect. The actual procedure determines the scope.
- Option 3: Incorrect. Physical design does not report current system state.
- Option 4: Incorrect. That is an unsafe generalization.

**HARDWARE-ENGINEERING-Q0131 · single · implementation**

Before a supported PSU-module replacement, which capacity check matters?

1. Only the sum of both PSU labels
2. Only idle power from a different workload
3. The surviving supply and path can support the required load in the approved state
4. Only the replacement PSU nominal rating

**Correct option(s):** 3

- Option 1: Incorrect. One unit will be absent during the operation.
- Option 2: Incorrect. It may not represent the required state.
- Option 3: Correct. Redundancy depends on actual remaining capacity.
- Option 4: Incorrect. The remaining unit and upstream path must carry the workload during removal.

**HARDWARE-ENGINEERING-Q0132 · single · implementation**

A replacement FRU has unverified firmware prerequisites. What is the appropriate disposition?

1. Insert it and force any available update afterward
2. Erase the prerequisite note from the work order
3. Count it as accepted because the connector matches
4. Hold use until the supported combination is established

**Correct option(s):** 4

- Option 1: Incorrect. That bypasses prerequisite review.
- Option 2: Incorrect. That hides the unresolved condition.
- Option 3: Incorrect. Connector fit is incomplete compatibility evidence.
- Option 4: Correct. Mechanical fit does not resolve firmware requirements.

**HARDWARE-ENGINEERING-Q0133 · single · implementation**

A removed drive contains service data. Which additional process applies?

1. Controlled media custody and the approved return/sanitization disposition
2. Assume removal electrically erases all content
3. Unrestricted return to general spare stock
4. Use the failed-status label as a sanitization certificate

**Correct option(s):** 1

- Option 1: Correct. Replacement does not automatically remove data obligations.
- Option 2: Incorrect. Persistent media retains data without power.
- Option 3: Incorrect. Data and fault state remain relevant.
- Option 4: Incorrect. Fault status is not sanitization evidence.

**HARDWARE-ENGINEERING-Q0134 · single · implementation**

What does a completed physical insertion establish by itself?

1. Full end-to-end service restoration
2. The part has been installed, while recognition, function and restored protection still need verification
3. Correct firmware and configuration on every part
4. Successful independent backup restoration

**Correct option(s):** 2

- Option 1: Incorrect. That requires further checks.
- Option 2: Correct. Seating is earlier than repair acceptance.
- Option 3: Incorrect. Those need read-back evidence.
- Option 4: Incorrect. That is a separate test.

**HARDWARE-ENGINEERING-Q0135 · single · implementation**

An unexpected alarm appears during a planned replacement outside the method's permitted conditions. What should the operator do?

1. Suppress the alarm permanently and proceed
2. Use the defined stop/hold process and coordinate the state
3. Continue faster to finish before review
4. Expand the work scope without recording it

**Correct option(s):** 2

- Option 1: Incorrect. That conceals evidence.
- Option 2: Correct. Unexpected conditions invalidate assumptions of the method.
- Option 3: Incorrect. Speed does not resolve the changed state.
- Option 4: Incorrect. Unreviewed scope changes can create additional risk.

**HARDWARE-ENGINEERING-Q0136 · single · implementation**

An accelerator class is unavailable for supervised physical practice. How is its practical requirement recorded?

1. Completed after viewing an unrelated photograph
2. Open until suitable authorized evidence is obtained
3. Completed because another component was replaced
4. Removed from the curriculum without review

**Correct option(s):** 2

- Option 1: Incorrect. That does not show the learner's execution.
- Option 2: Correct. Analytical understanding does not demonstrate that physical task.
- Option 3: Incorrect. Different handling and service methods need their own evidence.
- Option 4: Incorrect. Access limits do not erase mandatory outcomes.

#### Recall

**A failed RAID 5 member is D3, but the work order names healthy D4. What must happen before removal?**

Hold and reconcile physical/controller identity, then correct and confirm the target. Correct. Removing the healthy member can exceed remaining tolerance.

**A component has a front pull handle. What can be inferred about hot replacement?**

Nothing definitive without the model-specific supported method and state. Correct. Accessibility does not establish safe hot-swap support.

**Before a supported PSU-module replacement, which capacity check matters?**

The surviving supply and path can support the required load in the approved state. Correct. Redundancy depends on actual remaining capacity.

**A replacement FRU has unverified firmware prerequisites. What is the appropriate disposition?**

Hold use until the supported combination is established. Correct. Mechanical fit does not resolve firmware requirements.

**A removed drive contains service data. Which additional process applies?**

Controlled media custody and the approved return/sanitization disposition. Correct. Replacement does not automatically remove data obligations.

#### References

- [Dell PowerEdge R760 Installation and Service Manual: illustrative OEM source; use the manual for the actual selected model](https://www.dell.com/support/manuals/en-us/poweredge-r760/per760_ism_pub/about-this-document?guid=guid-bf9eed9e-52b2-4860-911b-954e25631b96&lang=en-us)

### HARDWARE-ENGINEERING-L18 — Repair verification for storage, memory, NICs, fans and accelerators

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L17

A component-specific verification plan connects the reported fault to the required recovered mechanism. For a drive, verify exact identity and supported member assignment, rebuild or resilver state as applicable, integrity and foreground service. Report degraded exposure during reconstruction and confirm the controller has returned to the expected protection state. A percentage reaching 100 is not a substitute for examining terminal status and errors. Confirm that any spare policy is restored and the failed unit is removed from available inventory.

For memory, verify type, population, recognized and usable capacity, expected operating mode and the supported diagnostic result. A replacement in the wrong population can reduce bandwidth or disable a channel while the server still boots. Correlate subsequent ECC events with the new part identity and distinguish reset lifetime counters from a genuine error-free observation interval. If the same location continues to report errors, reassess channel, controller, socket/contact and firmware hypotheses under the OEM method rather than repeatedly replacing DIMMs without learning.

For a NIC or HBA, validate the exact firmware/driver combination, negotiated links, physical errors, queue/path state and the intended service. Replacement can change MAC addresses, WWNs or other identifiers that external network/storage controls use. Restore the approved identity-dependent configuration through controlled processes; do not indiscriminately copy every old identifier. A link-up result can coexist with an unpermitted storage target or wrong network membership. Test the application through the recovered path and, where required, its supported failure state.

For fans and approved PSU modules, verify recognized identity, health, expected redundancy and the thermal/power response under an authorized representative state. A fan spinning does not prove its sensor/control feedback or intended airflow path. A PSU LED does not establish that load sharing and feed mapping meet the service design. Remove temporary blanks, bypasses or maintenance settings only as the approved procedure directs. Review neighboring components if the repair altered cabling or service access.

Accelerator replacement can affect device UUIDs, topology, memory capacity, driver compatibility, fabric membership and workload placement. Retain old/new identity, supported firmware and relevant topology. Some reset and recovery operations can affect a group of interconnected devices; use the current model-specific guidance. Run a bounded functional workload that checks meaningful output and relevant performance, while observing errors and thermal/power limiting. A successful inventory command is insufficient evidence of restored accelerator service.

Close the repair by comparing the original symptom with the post-repair state over an appropriate interval. Separate immediate functional acceptance from longer-term recurrence monitoring. If a symptom persists, do not mark it repaired merely because a new part was installed. Escalate with both original and replacement identities, methods and evidence. Update asset, spare, support and custody records; remove temporary access; hand over remaining risk and monitoring ownership. This is the transition from a mechanical task to a defensible maintenance outcome.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic NIC replacement negotiates the expected link rate but the storage service remains unavailable. The old adapter WWN was permitted on the target; the new supported adapter has a different WWN and no approved mapping yet.

**Reasoning:** Link negotiation proves only the transport link. Verify the new identity and apply the controlled storage-access configuration, then test the intended volume and application path. Do not claim a second physical NIC defect solely because the target denies the new identity. Retain the old/new mapping and remove obsolete authorization according to the change plan.

#### Guided practice

A memory replacement boots with half the expected usable capacity. Can the repair close?

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** No. Verify supported population, seating/recognition, firmware mode and component identity through the approved procedure. Booting does not meet the capacity requirement; preserve the exception and retest after correction.

#### Independent task

Environment: analytical / emulator / physical

Write component-specific post-repair tests for one drive, memory module, NIC, fan/PSU and accelerator, then execute those available under authorization.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Connect each test to the original fault and required function.
- Verify changed identities and external dependencies.
- Record immediate acceptance and subsequent recurrence ownership separately.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0137 · single · implementation**

A replacement NIC links correctly but its new WWN is not authorized by the storage target. What is the next supported action?

Synthetic replacement: link negotiated as required; new WWN=NEW01; approved target mapping still permits OLD01 only.

1. Copy an unrelated host's WWN without review
2. Declare all storage media corrupted from the denial
3. Verify and apply the controlled identity mapping, then test storage function
4. Replace the NIC again before checking access policy

**Correct option(s):** 3

- Option 1: Incorrect. That can create identity conflicts and unauthorized access.
- Option 2: Incorrect. Authorization failure does not establish media corruption.
- Option 3: Correct. Link state does not establish target authorization.
- Option 4: Incorrect. The new identity explains a plausible configuration failure.

**HARDWARE-ENGINEERING-Q0138 · single · implementation**

A memory repair leaves half the expected usable capacity while the OS boots. What is the disposition?

1. Change the written capacity requirement after the fact
2. Accept because any successful boot proves full capacity
3. Hold repair acceptance and verify population, recognition and mode
4. Assume the workload will never use the missing memory

**Correct option(s):** 3

- Option 1: Incorrect. That hides the failed criterion.
- Option 2: Incorrect. Booting is insufficient.
- Option 3: Correct. The capacity requirement is unmet.
- Option 4: Incorrect. The requirement was not conditional on that guess.

**HARDWARE-ENGINEERING-Q0139 · single · implementation**

A rebuild indicator reaches 100%. What still needs review?

1. A guarantee that no future drive can fail
2. Only whether the replacement drive appears in inventory
3. Terminal result, errors, protection state, integrity and service behavior
4. Only the displayed percentage again

**Correct option(s):** 3

- Option 1: Incorrect. No rebuild can provide that guarantee.
- Option 2: Incorrect. Recognition does not establish a successful rebuild and restored protection.
- Option 3: Correct. Progress percentage alone is incomplete acceptance.
- Option 4: Incorrect. Repeating it adds no new mechanism evidence.

**HARDWARE-ENGINEERING-Q0140 · single · diagnosis**

ECC errors continue at the same location after a supported DIMM replacement. What should change in the diagnosis?

1. Reconsider channel/controller/connection/firmware causes with the OEM method
2. Conclude that the new DIMM must always be defective
3. Erase the location information to start fresh
4. Assume ECC has stopped functioning because errors are reported

**Correct option(s):** 1

- Option 1: Correct. Repeated part replacement without discrimination is weak evidence.
- Option 2: Incorrect. Other causes remain plausible.
- Option 3: Incorrect. That removes a key correlation.
- Option 4: Incorrect. Reporting does not imply the protection mechanism is absent.

**HARDWARE-ENGINEERING-Q0141 · single · implementation**

A replaced fan spins but its feedback is not recognized. What is missing?

1. Proof of any rotor movement
2. Only the fan's visible rotation speed
3. Supported control/telemetry behavior and the required thermal verification
4. A claim that all spinning fans are interchangeable

**Correct option(s):** 3

- Option 1: Incorrect. That was observed.
- Option 2: Incorrect. Visible motion does not prove recognized feedback or supported control.
- Option 3: Correct. Mechanical motion alone is not the full function.
- Option 4: Incorrect. Compatibility and control differ.

**HARDWARE-ENGINEERING-Q0142 · single · implementation**

An accelerator appears in inventory after replacement. Which test adds material acceptance evidence?

1. Repeating only the inventory command many times
2. A bounded representative workload with output, error and limiting-state checks
3. Assuming the old UUID remains valid everywhere
4. Only a second inventory listing after reboot

**Correct option(s):** 2

- Option 1: Incorrect. That does not exercise the workload mechanism.
- Option 2: Correct. Presence does not establish useful computation.
- Option 3: Incorrect. Identity can change and dependent configuration needs review.
- Option 4: Incorrect. Enumeration remains weaker than exercising useful computation.

**HARDWARE-ENGINEERING-Q0143 · single · implementation**

The original symptom persists after installing a new part. Which report is truthful?

1. The acceptance test should be removed
2. Replacement occurred, but repair effectiveness is not established
3. The fault is repaired because the part is new
4. The original evidence should be discarded

**Correct option(s):** 2

- Option 1: Incorrect. That would hide the unresolved requirement.
- Option 2: Correct. The service fault remains unresolved.
- Option 3: Incorrect. New hardware does not prove correction.
- Option 4: Incorrect. It is necessary for comparison.

**HARDWARE-ENGINEERING-Q0144 · single · implementation**

Why separate immediate repair acceptance from recurrence monitoring?

1. A successful short test proves recurrence is impossible
2. A short functional test and a longer trend observation support different claims
3. Immediate tests are never useful
4. Long-term monitoring automatically restores failed services

**Correct option(s):** 2

- Option 1: Incorrect. It cannot guarantee future behavior.
- Option 2: Correct. Both can be necessary for effectiveness evidence.
- Option 3: Incorrect. They verify the current required function.
- Option 4: Incorrect. It observes behavior rather than performing recovery.

#### Recall

**A replacement NIC links correctly but its new WWN is not authorized by the storage target. What is the next supported action?**

Verify and apply the controlled identity mapping, then test storage function. Correct. Link state does not establish target authorization.

**A memory repair leaves half the expected usable capacity while the OS boots. What is the disposition?**

Hold repair acceptance and verify population, recognition and mode. Correct. The capacity requirement is unmet.

**A rebuild indicator reaches 100%. What still needs review?**

Terminal result, errors, protection state, integrity and service behavior. Correct. Progress percentage alone is incomplete acceptance.

**ECC errors continue at the same location after a supported DIMM replacement. What should change in the diagnosis?**

Reconsider channel/controller/connection/firmware causes with the OEM method. Correct. Repeated part replacement without discrimination is weak evidence.

**A replaced fan spins but its feedback is not recognized. What is missing?**

Supported control/telemetry behavior and the required thermal verification. Correct. Mechanical motion alone is not the full function.

#### References

- [Linux kernel: PCI error recovery](https://docs.kernel.org/PCI/pci-error-recovery.html)
- [NVIDIA System Management Interface documentation](https://docs.nvidia.com/deploy/nvidia-smi/index.html)

## HARDWARE-ENGINEERING-M09 — Failure recovery and hardware refresh

### HARDWARE-ENGINEERING-L19 — Trustworthy node rebuild and management-plane recovery

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L18

Recovery restores a required service from an unacceptable state using trustworthy resources. Classify the loss: host hardware, boot media, storage controller, firmware, management plane, configuration, data or authority. These can overlap. A replacement chassis with copied disks is not automatically a trusted recovered node, and an OS reinstall may leave compromised or incorrect BMC/DPU firmware and accounts untouched. Establish the scope from evidence and the approved incident/recovery process.

Build a recovery dependency inventory before the failure. It includes installation media, verified firmware, supported drivers, configuration, data backups, required transaction logs, encryption keys, licenses, credentials, certificates, network/storage access and the personnel/equipment needed to use them. Identify where each item is stored and how it is accessed when the normal environment is unavailable. A backup whose decryption key exists only on the failed host is an incomplete recovery design. A break-glass method must be controlled and tested, not an undocumented universal password.

A trustworthy rebuild starts with verified physical identity and a supported platform state. Apply the approved firmware/boot baseline and management restrictions, then install the supported OS and drivers. Restore only the required configuration from known sources, checking for obsolete identity or insecure exceptions. Restore data through the supported method and validate its integrity and point in time. Re-establish certificates and accounts through the intended process; remove superseded authority where appropriate. Avoid blindly cloning a machine identity into a second simultaneously active node.

Management-plane loss needs its own branch. The host may still provide service while remote power, console and hardware telemetry are unavailable. Diagnose network path, access control, name/time/TLS state and BMC service using available evidence. If the supported recovery requires a BMC reset, service interruption or physical access, coordinate the actual scope and preserve logs first where feasible. Do not assume a management reset is non-disruptive on every platform. Use only the documented supported firmware recovery, including vendor assistance or replacement when rollback is unavailable.

Measure recovery against defined start and finish events. Hardware power-on, OS login, database availability and end-user/OT function are separate timestamps. The completion point for the curriculum is the required function and data with acceptable remaining authority. A restored monitoring server that cannot authenticate to its devices or forwards no valid measurements is not complete. Verify both allowed and prohibited administrative access in an authorized test, remove temporary recovery access and confirm logging/monitoring resumed.

Exercise an unavailable dependency deliberately in a safe lab plan: missing key access, unavailable identity, absent driver package or failed management route. Observe the gap, provide a controlled alternative and revise the procedure. Record elapsed restoration and the recovered data point separately. The artifact should explain what succeeded, what required intervention and what remains uncertain. An offline fixture can assess the plan and dependency order; real node replacement/rebuild and functional restoration remain observed practical evidence.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic rebuild reaches OS login at 25 minutes, database startup at 40 minutes and valid OT monitoring with restored access controls at 55 minutes. The agreed service RTO is 45 minutes. The report claims recovery took 25 minutes.

**Reasoning:** The relevant completion is 55 minutes, so the 45-minute target is missed by 10 minutes. OS login is a useful intermediate milestone but not the required function. Preserve all timestamps, analyze dependency delays and retest the revised recovery process. Separately record the data recovery point and verify temporary authority was removed.

#### Guided practice

A backup is intact but its only decryption key is stored on the failed boot disk. What should the recovery review conclude?

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** The data artifact alone is insufficient. Establish the approved independent key-recovery route or report that restoration is blocked. Revise key custody and test access under the failure condition without exposing the key in the evidence pack.

#### Independent task

Environment: analytical / emulator / physical

Rebuild a disposable authorized node/service from controlled sources, test a missing dependency and verify function, data and remaining authority.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/recovery_lab.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Trace firmware, configuration, keys, identity and service dependencies.
- Measure to the required functional endpoint.
- Retain evidence of temporary-access removal and a revised recovery path.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0145 · single · implementation**

OS login returns at 25 minutes but the required OT function returns at 55 against a 45-minute RTO. What is the result?

Synthetic recovery milestones: disruption t=0; OS login25min; database40min; required OT function and access controls55min; RTO45min.

1. Recovery passed at 25 minutes
2. The service target is missed by 10 minutes
3. The target is missed by 30 minutes
4. RTO cannot include application dependencies

**Correct option(s):** 2

- Option 1: Incorrect. That substitutes an earlier hardware/OS milestone.
- Option 2: Correct. The defined functional endpoint determines completion.
- Option 3: Incorrect. 55−45 is 10, not the difference from OS login.
- Option 4: Incorrect. Those are part of the required service recovery.

**HARDWARE-ENGINEERING-Q0146 · single · implementation**

An encrypted backup's only key is on the failed host. What is missing?

1. A declaration that encryption guarantees recovery
2. A second encrypted copy protected only by the same unavailable key
3. An approved accessible independent key-recovery route
4. More CPU cores for decryption

**Correct option(s):** 3

- Option 1: Incorrect. Encryption protects data but adds a key dependency.
- Option 2: Incorrect. Duplicating ciphertext does not resolve key access.
- Option 3: Correct. Backup bytes alone cannot establish restorability.
- Option 4: Incorrect. Compute cannot replace unavailable key material.

**HARDWARE-ENGINEERING-Q0147 · single · implementation**

Why may an OS reinstall be insufficient after a management-plane compromise?

1. BMC or DPU firmware and identities can persist separately
2. A new desktop proves that remote authority was removed
3. An OS reinstall always replaces every firmware chip's contents
4. All management state exists only in application memory

**Correct option(s):** 1

- Option 1: Correct. Recovery scope must include the affected independent components.
- Option 2: Incorrect. Appearance does not validate access state.
- Option 3: Incorrect. It generally does not.
- Option 4: Incorrect. It can have independent persistence.

**HARDWARE-ENGINEERING-Q0148 · single · implementation**

A BMC is unavailable while the host service runs. Which recovery assumption is unsafe?

1. Any BMC reset is guaranteed non-disruptive on every platform
2. The host service may remain available during diagnosis
3. The management path needs separate diagnosis
4. Access and network controls can cause management symptoms

**Correct option(s):** 1

- Option 1: Correct. Actual semantics and dependencies are model-specific.
- Option 2: Incorrect. The scenario establishes that possibility.
- Option 3: Incorrect. It is a distinct failing function.
- Option 4: Incorrect. They are valid candidate causes.

**HARDWARE-ENGINEERING-Q0149 · single · implementation**

Two active nodes are given a cloned machine identity without review. What risk needs evaluation?

1. Elimination of certificate validation requirements
2. Guaranteed doubling of authentication resilience
3. Conflicting identity and unintended authority across the restored environment
4. Automatic independent key custody

**Correct option(s):** 3

- Option 1: Incorrect. Trust validation remains necessary.
- Option 2: Incorrect. Duplicate identities can undermine correct behavior.
- Option 3: Correct. Identity restoration must account for simultaneous ownership.
- Option 4: Incorrect. Cloning does not establish independent recovery control.

**HARDWARE-ENGINEERING-Q0150 · single · implementation**

What should a recovery test report separately?

1. Only the earliest successful ping
2. Elapsed functional restoration and the recovered data point
3. Only the largest backup file size
4. Only the replacement component cost

**Correct option(s):** 2

- Option 1: Incorrect. That omits data and required function.
- Option 2: Correct. RTO-like timing and RPO-like data age are different measurements.
- Option 3: Incorrect. Size does not establish timing or point in time.
- Option 4: Incorrect. Cost is not recovery acceptance.

**HARDWARE-ENGINEERING-Q0151 · single · implementation**

A temporary recovery account remains enabled after service restoration. Which requirement is unfinished?

1. The existence of any account on the system
2. Verification and removal or approved disposition of temporary authority
3. The fact that the OS can boot
4. The physical installation of the replacement

**Correct option(s):** 2

- Option 1: Incorrect. Authorized accounts remain necessary.
- Option 2: Correct. Functional recovery includes the intended access state.
- Option 3: Incorrect. That may already be complete.
- Option 4: Incorrect. That is a separate completed milestone.

**HARDWARE-ENGINEERING-Q0152 · single · implementation**

A lab plan deliberately withholds a recovery dependency. What is the purpose?

1. Prove that destructive production failures should be induced
2. Avoid documenting the missing dependency
3. Expose and correct the plan's dependency weakness under controlled conditions
4. Guarantee every other recovery dependency is sound

**Correct option(s):** 3

- Option 1: Incorrect. The exercise is bounded and authorized.
- Option 2: Incorrect. The finding must revise the plan.
- Option 3: Correct. A successful test with every dependency present can miss this gap.
- Option 4: Incorrect. One test has limited scope.

#### Recall

**OS login returns at 25 minutes but the required OT function returns at 55 against a 45-minute RTO. What is the result?**

The service target is missed by 10 minutes. Correct. The defined functional endpoint determines completion.

**An encrypted backup's only key is on the failed host. What is missing?**

An approved accessible independent key-recovery route. Correct. Backup bytes alone cannot establish restorability.

**Why may an OS reinstall be insufficient after a management-plane compromise?**

BMC or DPU firmware and identities can persist separately. Correct. Recovery scope must include the affected independent components.

**A BMC is unavailable while the host service runs. Which recovery assumption is unsafe?**

Any BMC reset is guaranteed non-disruptive on every platform. Correct. Actual semantics and dependencies are model-specific.

**Two active nodes are given a cloned machine identity without review. What risk needs evaluation?**

Conflicting identity and unintended authority across the restored environment. Correct. Identity restoration must account for simultaneous ownership.

#### References

- [NIST SP 800-193: Platform Firmware Resiliency Guidelines](https://csrc.nist.gov/pubs/sp/800/193/final)
- [DMTF Redfish standard and specifications](https://www.dmtf.org/standards/redfish)

### HARDWARE-ENGINEERING-L20 — Hardware refresh, migration, rollback and acceptance

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L19

A hardware refresh changes the physical platform while preserving or deliberately changing a required service. Begin with reasons such as support expiry, capacity, reliability, efficiency or compatibility. Translate them into acceptance requirements and identify the current baseline. A new system's higher benchmark score does not prove that the existing service, data, identities and operational methods will transfer successfully. Review the supported source/target combination, including firmware, drivers, virtualization features, storage formats and external access controls.

Choose a migration method appropriate to the service. Options can include rebuilding and restoring, application replication, storage migration or supported workload movement. Each has prerequisites, consistency behavior, outage requirements and rollback implications. A copied disk image may retain unsuitable drivers, stale device identifiers and old trust state. A database replica can lag or propagate unwanted changes. A supported migration tool can still be configured incorrectly. State what data is authoritative at every transition and which side is permitted to accept writes.

Avoid uncontrolled dual authority. If old and new nodes both serve the same identity or writable data without the intended coordination, clients can diverge or corrupt state. Define cutover, fencing or ownership controls according to the supported system architecture. Verify client routing, DNS, certificates and storage access after the change. A DNS update has caching behavior; a report that checks only the new node locally can miss clients still using the old endpoint. Keep a way to observe both sides during the transition.

Rollback is a conditional plan, not a magic undo button. Before cutover, returning clients to the unchanged source may be straightforward. After the target accepts new writes or changes a data format, the source may be stale or incompatible. Define the last safe rollback point, data reconciliation method, maximum acceptable divergence and the decision authority. If reversal is unsupported, document forward recovery or restoration instead. A backup taken before migration protects a historical state but does not automatically include transactions created after cutover.

Capacity and redundancy can be reduced during refresh. A rack may temporarily carry both old and new nodes; a cluster may lose one member while it is rebuilt; a storage array may run a migration and rebuild simultaneously. Calculate these transient states against power, cooling, compute, memory, storage and service limits. Sequence work so the approved surviving state is preserved. A final design that is resilient can still have an unacceptable transition plan. Stop conditions should include loss of required protection, excessive lag, integrity mismatch or inability to restore controlled authority.

Acceptance checks the promised service and the new operational baseline. Verify representative transactions, data integrity/point, performance under required states, access controls, monitoring, backup and recovery on the target. Update support, inventory and spare records. Keep the old system in the approved retained state until its role is resolved, then retire it through the separate sanitization and custody process. A migration is incomplete if it leaves an undocumented live source, obsolete credentials or a backup process still protecting only the retired host.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic application migrates at 10:00. The new node accepts writes until 10:30. A fault occurs and the plan says to redirect clients to the unchanged old node whose data stops at 10:00. The service permits no loss of acknowledged transactions.

**Reasoning:** The proposed rollback would omit the target-only writes and fails the stated data requirement. Use the supported reconciliation or forward-recovery path, or restore to a verified complete state if available. Define write authority and the last safe rollback point before migration. Do not call a 10:00 backup a complete 10:30 recovery source.

#### Guided practice

During refresh, old and new racks run together at 7 kW each but the approved temporary feed capacity is 12 kW. What should the sequence review conclude?

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** The simultaneous 14 kW state exceeds the stated capacity. Revise sequencing, approved workload placement or facility provision before execution. Final-state capacity of 7 kW does not validate the transition.

#### Independent task

Environment: analytical / emulator / physical

Review a migration with stale rollback data and temporary capacity overload; produce a supported cutover/forward-recovery plan.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Define authoritative writes, consistency and rollback boundary.
- Calculate transition and degraded states.
- Verify target service, monitoring, backup and retirement dependencies.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0153 · single · implementation**

The target accepted new writes after cutover, while the source stayed unchanged. What must rollback address?

Synthetic migration: old source frozen10:00; target accepted writes10:00–10:30; fault10:30; zero acknowledged-transaction loss permitted.

1. The target-only acknowledged data and supported reconciliation
2. The assumption that all writes are automatically copied backward
3. Only redirecting the service name to the old source
4. Only powering on the source

**Correct option(s):** 1

- Option 1: Correct. Returning to the source can lose valid transactions.
- Option 2: Incorrect. That requires an implemented supported mechanism.
- Option 3: Incorrect. Routing to stale data does not preserve target-only acknowledged writes.
- Option 4: Incorrect. Availability of stale data is not correct recovery.

**HARDWARE-ENGINEERING-Q0154 · single · implementation**

Old and new systems each draw 7 kW during migration against a 12 kW temporary limit. What is the result?

1. The demand is 49 kW
2. The demand is 7 kW because names refer to one service
3. The 14 kW transition exceeds the limit by 2 kW
4. The transition is acceptable because either final system draws 7 kW

**Correct option(s):** 3

- Option 1: Incorrect. Power values are summed, not multiplied.
- Option 2: Incorrect. Two running systems still consume power.
- Option 3: Correct. The simultaneous state must be checked.
- Option 4: Incorrect. Final-state demand does not validate overlap.

**HARDWARE-ENGINEERING-Q0155 · single · implementation**

Why define one authoritative write owner during cutover?

1. Read-only clients cannot ever be redirected
2. A shared hostname automatically coordinates all writes
3. Every application requires both systems to write independently
4. Uncoordinated concurrent writers can create divergence or corruption

**Correct option(s):** 4

- Option 1: Incorrect. Read routing is a separate question.
- Option 2: Incorrect. Naming does not implement consistency control.
- Option 3: Incorrect. That is not a universal supported mode.
- Option 4: Correct. Ownership must follow the supported architecture.

**HARDWARE-ENGINEERING-Q0156 · single · implementation**

A local test on the new node passes immediately after DNS cutover. What remains to be checked?

1. Whether the new node can run the already-passed local test
2. Whether the old node has any inventory label
3. Actual client resolution/routing and service behavior during cache transition
4. A guarantee that all DNS caches change instantly

**Correct option(s):** 3

- Option 1: Incorrect. That is existing evidence.
- Option 2: Incorrect. Identity matters, but it does not validate client cutover.
- Option 3: Correct. Clients may still use the old endpoint.
- Option 4: Incorrect. Caching prevents that assumption.

**HARDWARE-ENGINEERING-Q0157 · single · implementation**

A migration changes the data format so the old software cannot read it. What should the recovery plan state?

1. Any old binary can always read the new format
2. Rollback may be unsupported; define a verified forward-recovery or restoration route
3. Renaming the database file restores compatibility
4. A backup label removes the need for restore testing

**Correct option(s):** 2

- Option 1: Incorrect. That contradicts the stated incompatibility.
- Option 2: Correct. Reversal depends on compatibility, not intention.
- Option 3: Incorrect. Names do not change format semantics.
- Option 4: Incorrect. Artifacts must be validated with the supported software.

**HARDWARE-ENGINEERING-Q0158 · single · implementation**

Why test backup on the new target after refresh?

1. The old backup schedule necessarily discovers every target change
2. Protection may still reference only the old host or omit changed dependencies
3. A successful migration is itself a permanent backup
4. The target can never fail while under warranty

**Correct option(s):** 2

- Option 1: Incorrect. That must be verified rather than assumed.
- Option 2: Correct. Service migration does not automatically update every recovery process.
- Option 3: Incorrect. It is a transition, not enduring independent protection.
- Option 4: Incorrect. Warranty does not prevent failure.

**HARDWARE-ENGINEERING-Q0159 · single · implementation**

A final architecture meets redundancy requirements but the migration removes two required members simultaneously. What is missing?

1. A transition sequence preserving the approved surviving state
2. A larger count of final healthy components
3. An assumption that maintenance never overlaps faults
4. Only the final healthy component count

**Correct option(s):** 1

- Option 1: Correct. End-state resilience does not make every path to it acceptable.
- Option 2: Incorrect. Those are not all available during the transition.
- Option 3: Incorrect. The plan must account for its required failure state.
- Option 4: Incorrect. Final resources are not all available during the temporary state.

**HARDWARE-ENGINEERING-Q0160 · single · implementation**

When is the retained old system ready for retirement?

1. Immediately after one successful target login
2. After its service/data role is resolved and the approved decommissioning process can proceed
3. Whenever its front-panel light is off
4. As soon as its hostname is removed from a slide

**Correct option(s):** 2

- Option 1: Incorrect. That is incomplete functional and recovery evidence.
- Option 2: Correct. Acceptance must account for lingering authority and dependencies.
- Option 3: Incorrect. Power state does not establish retirement readiness.
- Option 4: Incorrect. Documentation does not disable service or erase data.

#### Recall

**The target accepted new writes after cutover, while the source stayed unchanged. What must rollback address?**

The target-only acknowledged data and supported reconciliation. Correct. Returning to the source can lose valid transactions.

**Old and new systems each draw 7 kW during migration against a 12 kW temporary limit. What is the result?**

The 14 kW transition exceeds the limit by 2 kW. Correct. The simultaneous state must be checked.

**Why define one authoritative write owner during cutover?**

Uncoordinated concurrent writers can create divergence or corruption. Correct. Ownership must follow the supported architecture.

**A local test on the new node passes immediately after DNS cutover. What remains to be checked?**

Actual client resolution/routing and service behavior during cache transition. Correct. Clients may still use the old endpoint.

**A migration changes the data format so the old software cannot read it. What should the recovery plan state?**

Rollback may be unsupported; define a verified forward-recovery or restoration route. Correct. Reversal depends on compatibility, not intention.

#### References

- [Dell PowerEdge R760 Installation and Service Manual: illustrative OEM source; use the manual for the actual selected model](https://www.dell.com/support/manuals/en-us/poweredge-r760/per760_ism_pub/about-this-document?guid=guid-bf9eed9e-52b2-4860-911b-954e25631b96&lang=en-us)

## HARDWARE-ENGINEERING-M10 — Relocation, decommissioning and media sanitisation

### HARDWARE-ENGINEERING-L21 — Relocation, retirement dependencies and chain of custody

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L20

Relocation and retirement begin with service ownership, not unplugging equipment. Identify every function the asset provides, including less visible DNS/time, logging, backup, management, license or identity roles. Determine which services are retained, migrated, replaced or formally ended. Trace clients and dependent systems rather than relying on the server's headline application name. A quiet host can still provide a critical recovery dependency or an infrequently used administrative service.

For relocation, record the source baseline and destination readiness. Verify rack/rail/weight/clearance, power paths, cooling, cable/optic compatibility, network/storage access and management restrictions. A destination with enough rack units may lack the required surviving-feed capacity or liquid interface. Plan export/backup, shutdown or supported migration, transport packaging and handling, environmental constraints, custody, installation and recommissioning. Physical movement can disturb connectors or expose latent faults; repeat the affected acceptance checks rather than assuming prior commissioning transfers unchanged.

For retirement, define a controlled lifecycle state: retained for rollback, disconnected pending sanitization, sanitized pending reuse, approved for disposal or transferred under documented custody. A single 'retired' flag hides these materially different conditions. Prevent retired hardware from reappearing on the network with active credentials or old data. Revoke or reassign accounts, certificates, management access and licensed/support relationships through the relevant owner. Update monitoring deliberately so expected removal does not create an unmanaged alert gap for a retained dependency.

Data can exist beyond the main disks. Consider boot media, controller cache, removable media, BMC configuration, diagnostic logs, accelerators or embedded storage where applicable, and exported configuration backups. The exact persistence locations and supported reset/sanitization methods are model-specific. An ordinary factory reset can restore settings while leaving data elsewhere; a media wipe does not necessarily remove management accounts. Inventory each information-bearing component and the method/evidence required for its disposition.

Chain of custody records identity, possession, location, transfer time, responsible parties and condition through the handling process. It supports accountability but does not itself prove sanitization. Match records to actual serials and maintain approved controls for transport and storage. If a disposal provider returns a certificate with a mismatched serial or unspecified method, hold closure and resolve the discrepancy. Do not claim unseen physical destruction based solely on an intended work order. The evidence must support what actually occurred.

Handover closes both service and asset relationships. Verify retained services still work, required backups/exports are accessible, access has the intended state and inventory agrees with physical custody. For relocation, validate the required network/OT function and performance in the new environment. For retirement, ensure data/media disposition and remaining credentials/configuration are separately evidenced. The independent exercise reviews a flawed move/retirement pack; real transport, sanitization and disposal claims require actual authorized observations or reliable approved third-party evidence.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic supposedly retired server is disconnected from production but its BMC remains reachable with an active administrator account. The main disks are awaiting sanitization, and the asset register says disposed although it remains in a staging cage.

**Reasoning:** The records and controls disagree. Record the actual pending-sanitization custody state, resolve the BMC exposure and administrative authority through the approved process, and complete the media disposition with identity-linked evidence. Disconnection from production is not disposal, credential removal or sanitization. Verify retained dependencies before any final action.

#### Guided practice

A destination rack has sufficient space but both proposed server cords share one feed, while the service requires feed-loss survival. Can relocation acceptance use the old site test?

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** No. The new power-path arrangement changes a required failure dependency. Correct the reviewed destination design and validate the relevant installed state; old-site evidence does not prove the new topology.

#### Independent task

Environment: analytical / emulator / physical

Review a relocation/retirement record with a retained service dependency, a custody mismatch and incomplete management reset.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Map service, data and authority before changing lifecycle state.
- Verify destination interfaces or retirement disposition.
- Reconcile serial-linked custody with actual observed events.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0161 · single · implementation**

An asset is marked disposed while physically awaiting sanitization in a cage. What should be corrected?

Synthetic custody: asset status disposed; actual location staging cage; media treatment pending; BMC still reachable.

1. The label alone should be treated as proof of destruction
2. The lifecycle/custody record must reflect the actual pending state
3. The pending media should be returned to unrestricted stock
4. The serial should be deleted so the mismatch disappears

**Correct option(s):** 2

- Option 1: Incorrect. An administrative status cannot establish the physical event.
- Option 2: Correct. Intended disposal is not completed disposal.
- Option 3: Incorrect. Its data disposition remains unresolved.
- Option 4: Incorrect. That destroys traceability.

**HARDWARE-ENGINEERING-Q0162 · single · implementation**

A retired host's disks are sanitized but its BMC account remains active. Which requirement remains separate?

1. Only the fact that production data interfaces are unplugged
2. Management identity/configuration removal or approved reassignment
3. The existence of disk sanitization evidence
4. A guarantee that power-off revokes credentials

**Correct option(s):** 2

- Option 1: Incorrect. The separate management path and credentials can remain active.
- Option 2: Correct. Media treatment does not automatically close management authority.
- Option 3: Incorrect. That can be complete within its own scope.
- Option 4: Incorrect. Persistent accounts can remain available later.

**HARDWARE-ENGINEERING-Q0163 · single · implementation**

Why inventory information-bearing components beyond the main disks?

1. Sanitizing one disk always resets every controller
2. Configuration, logs or other data can persist in separate embedded/removable components
3. Every component necessarily stores identical complete datasets
4. A motherboard label itself is a full database

**Correct option(s):** 2

- Option 1: Incorrect. That cannot be assumed.
- Option 2: Correct. The main data volume is not the only possible storage.
- Option 3: Incorrect. Actual persistence is model-specific.
- Option 4: Incorrect. Identification is not equivalent to all data content.

**HARDWARE-ENGINEERING-Q0164 · single · implementation**

A disposal certificate names a different serial from the asset sent. What is the correct disposition?

1. Hold closure and reconcile identity and evidence with the approved custody process
2. Claim the item was destroyed because a work order existed
3. Edit the sent asset's serial to match without investigation
4. Accept any certificate from the provider as interchangeable

**Correct option(s):** 1

- Option 1: Correct. The certificate does not yet support this asset's disposition.
- Option 2: Incorrect. Intent is not execution evidence.
- Option 3: Incorrect. That falsifies the identity chain.
- Option 4: Incorrect. Evidence must identify the relevant media/asset.

**HARDWARE-ENGINEERING-Q0165 · single · implementation**

A relocated server uses a different power-path topology. What must acceptance consider?

1. Only the prior site's successful feed-loss report
2. An assumption that all racks have identical feeds
3. Only the server's unchanged operating-system version
4. The new installed dependency and required failure state

**Correct option(s):** 4

- Option 1: Incorrect. That report describes a different installed topology.
- Option 2: Incorrect. Rack arrangements can differ.
- Option 3: Incorrect. That does not validate facility paths.
- Option 4: Correct. Prior-site testing does not prove the changed arrangement.

**HARDWARE-ENGINEERING-Q0166 · single · implementation**

What does chain of custody establish by itself?

1. That the service was successfully migrated
2. Documented possession and transfer history, not sanitization effectiveness
3. That all certificates and licenses were revoked
4. That every bit has been irrecoverably removed

**Correct option(s):** 2

- Option 1: Incorrect. Custody does not test application function.
- Option 2: Correct. Handling evidence and media treatment are distinct.
- Option 3: Incorrect. Those require separate administrative actions.
- Option 4: Incorrect. That requires method and outcome evidence.

**HARDWARE-ENGINEERING-Q0167 · single · implementation**

A little-used server supplies the recovery environment's time service. What must retirement review address?

1. Deletion of its role from the inventory
2. The retained recovery dependency and its replacement or approved termination
3. An assumption that recovery uses no time-dependent systems
4. Only the host's daytime CPU average

**Correct option(s):** 2

- Option 1: Incorrect. That hides rather than resolves the dependency.
- Option 2: Correct. Low normal utilization does not make the role irrelevant.
- Option 3: Incorrect. Authentication and event interpretation may depend on time.
- Option 4: Incorrect. That can miss infrequent critical functions.

**HARDWARE-ENGINEERING-Q0168 · single · implementation**

A factory reset restores BMC settings. What cannot be assumed without model-specific evidence?

1. That physical identity can still be recorded
2. That the procedure should be documented
3. That all other information-bearing media and credentials have been appropriately treated
4. That some supported settings changed

**Correct option(s):** 3

- Option 1: Incorrect. Identity tracking is still possible.
- Option 2: Incorrect. Documentation remains appropriate.
- Option 3: Correct. Reset scope can be narrower than retirement scope.
- Option 4: Incorrect. That is the stated reset action.

#### Recall

**An asset is marked disposed while physically awaiting sanitization in a cage. What should be corrected?**

The lifecycle/custody record must reflect the actual pending state. Correct. Intended disposal is not completed disposal.

**A retired host's disks are sanitized but its BMC account remains active. Which requirement remains separate?**

Management identity/configuration removal or approved reassignment. Correct. Media treatment does not automatically close management authority.

**Why inventory information-bearing components beyond the main disks?**

Configuration, logs or other data can persist in separate embedded/removable components. Correct. The main data volume is not the only possible storage.

**A disposal certificate names a different serial from the asset sent. What is the correct disposition?**

Hold closure and reconcile identity and evidence with the approved custody process. Correct. The certificate does not yet support this asset's disposition.

**A relocated server uses a different power-path topology. What must acceptance consider?**

The new installed dependency and required failure state. Correct. Prior-site testing does not prove the changed arrangement.

#### References

- [Dell PowerEdge R760 Installation and Service Manual: illustrative OEM source; use the manual for the actual selected model](https://www.dell.com/support/manuals/en-us/poweredge-r760/per760_ism_pub/about-this-document?guid=guid-bf9eed9e-52b2-4860-911b-954e25631b96&lang=en-us)

### HARDWARE-ENGINEERING-L22 — Media sanitization: method selection, verification and release evidence

Estimated study time: 65 minutes before independent work. Prerequisite chapters: HARDWARE-ENGINEERING-L21

Sanitization aims to make access to target data infeasible to the required level using an approved method appropriate to the media and disposition. Select the method from information sensitivity, reuse/transfer plan, device technology, supported capabilities and the organization's policy. The retained curriculum specifically names NIST SP 800-88 Rev.2; the current final publication is the reference for the programme's sanitization planning. It does not make one command suitable for every disk, SSD, embedded device or organization.

Distinguish logical file deletion, formatting, clearing, purging and physical destruction in the context of the approved standard and device method. Removing a directory entry or recreating a filesystem can leave data accessible through other means. Flash translation and spare/remapped areas mean that repeatedly overwriting host-visible addresses is not automatically evidence that every relevant physical location was treated. Device-supported sanitization capabilities must be verified for the exact model and implementation. Do not extrapolate a successful test on one media family to another.

Cryptographic erase can make protected data inaccessible by eliminating the relevant cryptographic keys under a suitable validated design. Its effectiveness depends on prerequisites: the data was protected by appropriate encryption before exposure, relevant keys and copies are within the method's scope, and the implementation and key handling meet the required assurance. Deleting one remembered password is not automatically cryptographic erase. Unencrypted earlier data, exported keys, alternate key slots or copies elsewhere can defeat an overbroad claim. The approved method must address these conditions explicitly.

Separate execution evidence from the release decision. Record device identity, method/tool and version, applicable capability/support evidence, operator, start/end, result, errors and prescribed checks. A tool reporting completion is useful but its target, scope and outcome still need verification. Review whether the result meets the intended policy and disposition; unresolved errors, inaccessible media areas or identity mismatches require a hold or a different approved method. Sampling and verification procedures must follow the applicable guidance and assurance requirement rather than a convenient ad hoc shortcut.

A sacrificial lab exercise uses only authorized media with synthetic data and a clearly isolated target. Establish exact device identity and confirm that no required system, backup or production data uses it. Retain an independent record of the intended target and synthetic content, execute the supported approved method under supervision where required, then perform the prescribed verification and disposition review. This course deliberately provides no universal destructive command. The offline file-restoration demo is not a sanitization method: deleting or overwriting files in a temporary directory cannot prove media-level sanitization.

Closure includes information and authority beyond the chosen medium. Reset or revoke relevant BMC/configuration identities through their own supported method, handle exported backups according to retention policy, reconcile asset/custody records and record reuse or disposal authorization. If physical destruction is the selected route, retain appropriate identity-linked approved evidence rather than claiming an unseen act. A missing result or failed verification remains open. The learner must be able to reject a plausible but insufficient certificate and explain the exact missing evidence before release.

#### Worked demonstrations

**Worked engineering case**

Synthetic educational case. A synthetic SSD retirement report records successful quick formatting. It identifies the correct serial but has no approved sanitization method, capability evidence or verification record. The device will leave organizational control.

**Reasoning:** Hold release. Correct identity and formatting success do not establish the required sanitization assurance. Select the approved method appropriate to this SSD and disposition, verify model support, execute it on the authorized target and retain the prescribed result/verification and custody evidence. A different method may be required if the device cannot complete the selected process.

#### Guided practice

A cryptographic-erasure claim deletes one key copy while an exported usable key remains. Explain the missing condition.

**Hint:** Trace the dependency or data path; distinguish observation, inference and an executable acceptance test.

**Worked solution:** The relevant key material was not eliminated across the required scope. Assess encryption history, all applicable key copies/slots and the supported implementation before making an inaccessibility claim. Treat other data copies under their own retention/disposition requirements.

#### Independent task

Environment: analytical / emulator / physical

Review the synthetic sanitization certificate and, with authorized sacrificial media, execute a supported method and document the release/hold decision.

**Packaged starter material**

- course_labs/HARDWARE-ENGINEERING/README.md
- course_labs/HARDWARE-ENGINEERING/cases.json
- course_labs/HARDWARE-ENGINEERING/workbook.py
- course_labs/HARDWARE-ENGINEERING/evidence-template.json

**Evidence to produce**

- Decision record with reproduced calculations, alternative diagnosis and acceptance evidence.

**Acceptance criteria**

- Select a method using exact media, sensitivity and disposition.
- Verify identity, execution result, prescribed checks and key-scope prerequisites where applicable.
- Keep offline analysis separate from observed media sanitization and custody evidence.

Offline analysis is not physical execution. Real work uses the approved model-specific procedure and retains observed results.

#### Chapter practice

**HARDWARE-ENGINEERING-Q0169 · single · implementation**

An SSD was quick-formatted before leaving organizational control. What is missing from a sanitization claim?

Synthetic disposition certificate: SSD serial matches; action quick format; result success; approved sanitization method absent; verification absent; asset to leave control.

1. Only a successful mount of the new empty filesystem
2. An approved media-appropriate method and its execution/verification evidence
3. A guarantee that flash has no remapped or spare areas
4. A rule that any filesystem recreation equals every sanitization category

**Correct option(s):** 2

- Option 1: Incorrect. A mount verifies filesystem accessibility, not sanitization assurance.
- Option 2: Correct. Formatting alone does not establish the required assurance.
- Option 3: Incorrect. That assumption is invalid for many devices.
- Option 4: Incorrect. The operations provide different guarantees.

**HARDWARE-ENGINEERING-Q0170 · single · implementation**

A cryptographic-erasure process leaves an exported usable key copy. What is the concern?

1. Encryption necessarily becomes stronger with each surviving key copy
2. All other data copies are sanitized automatically
3. Relevant key material remains outside the claimed deletion scope
4. The device must automatically destroy itself

**Correct option(s):** 3

- Option 1: Incorrect. Additional copies can preserve access.
- Option 2: Incorrect. Each copy and scope needs its own disposition.
- Option 3: Correct. Deleting one copy may not make protected data inaccessible.
- Option 4: Incorrect. No such physical event follows.

**HARDWARE-ENGINEERING-Q0171 · single · implementation**

Why does host-visible overwrite alone need careful review on flash media?

1. A faster interface guarantees stronger sanitization
2. Mapping, remapped and spare areas can differ from the exposed logical address space
3. Overwriting a filename necessarily invokes device sanitization
4. Flash always exposes every physical cell directly and permanently

**Correct option(s):** 2

- Option 1: Incorrect. Transport speed is not assurance.
- Option 2: Correct. Visible addresses do not necessarily cover all relevant physical locations.
- Option 3: Incorrect. Filename operations are different.
- Option 4: Incorrect. Translation layers can intervene.

**HARDWARE-ENGINEERING-Q0172 · single · implementation**

A tool reports completion but the logged serial is wrong. What is the release decision?

1. Release the intended asset based on any successful run
2. Hold until the actual target and outcome are reconciled
3. Assume all connected devices were sanitized together
4. Assume a matching model name is sufficient despite the serial mismatch

**Correct option(s):** 2

- Option 1: Incorrect. Success on another target is insufficient.
- Option 2: Correct. The result does not yet establish treatment of the intended asset.
- Option 3: Incorrect. Scope must be established by the method and record.
- Option 4: Incorrect. The target must be uniquely reconciled; a model can describe many devices.

**HARDWARE-ENGINEERING-Q0173 · single · implementation**

What must be true before a sacrificial-media sanitization exercise?

1. A production backup can be borrowed without checking dependencies
2. The target's device name looked familiar once
3. The learner has answered a question correctly
4. The exact authorized target contains no required data and is isolated from unintended systems

**Correct option(s):** 4

- Option 1: Incorrect. That could destroy required recovery data.
- Option 2: Incorrect. Stable identity and current use must be verified.
- Option 3: Incorrect. Knowledge alone does not authorize a target.
- Option 4: Correct. Destructive practice requires a verified disposable scope.

**HARDWARE-ENGINEERING-Q0174 · single · implementation**

Why is the offline temporary-file restoration demo not media sanitization evidence?

1. All temporary files are inherently encrypted with validated erase keys
2. A Python process automatically controls every flash spare block
3. It cannot demonstrate any hash comparison
4. File operations in a temporary workspace do not validate a device-level sanitization method

**Correct option(s):** 4

- Option 1: Incorrect. That is not established.
- Option 2: Incorrect. It does not.
- Option 3: Incorrect. It can verify file content within its scope.
- Option 4: Correct. Its demonstrated scope is file loss and restoration only.

**HARDWARE-ENGINEERING-Q0175 · single · implementation**

A device cannot complete the selected approved sanitization method. What should happen?

1. Hold disposition and select an appropriate approved alternative or escalation
2. Mark it sanitized because the attempt started
3. Remove errors from the certificate
4. Release it solely because it no longer mounts normally

**Correct option(s):** 1

- Option 1: Correct. A failed method cannot be recorded as successful.
- Option 2: Incorrect. Attempt and successful outcome differ.
- Option 3: Incorrect. That conceals material evidence.
- Option 4: Incorrect. Inaccessibility through one interface is not the full assurance claim.

**HARDWARE-ENGINEERING-Q0176 · single · implementation**

What additional condition matters to a cryptographic-erasure claim beyond deleting a current password?

1. Only whether the current user password was changed
2. Only whether the filesystem has free space
3. Suitable prior encryption and complete relevant key scope in the supported implementation
4. A belief that any encryption setting proves all historical data was protected

**Correct option(s):** 3

- Option 1: Incorrect. A password change need not destroy the underlying data-encryption keys.
- Option 2: Incorrect. Free space does not establish key destruction.
- Option 3: Correct. A password action alone may not eliminate all data access.
- Option 4: Incorrect. Earlier unencrypted data and implementation details need review.

#### Recall

**An SSD was quick-formatted before leaving organizational control. What is missing from a sanitization claim?**

An approved media-appropriate method and its execution/verification evidence. Correct. Formatting alone does not establish the required assurance.

**A cryptographic-erasure process leaves an exported usable key copy. What is the concern?**

Relevant key material remains outside the claimed deletion scope. Correct. Deleting one copy may not make protected data inaccessible.

**Why does host-visible overwrite alone need careful review on flash media?**

Mapping, remapped and spare areas can differ from the exposed logical address space. Correct. Visible addresses do not necessarily cover all relevant physical locations.

**A tool reports completion but the logged serial is wrong. What is the release decision?**

Hold until the actual target and outcome are reconciled. Correct. The result does not yet establish treatment of the intended asset.

**What must be true before a sacrificial-media sanitization exercise?**

The exact authorized target contains no required data and is isolated from unintended systems. Correct. Destructive practice requires a verified disposable scope.

#### References

- [NIST SP 800-88 Rev.2: Guidelines for Media Sanitization](https://csrc.nist.gov/pubs/sp/800/88/r2/final)
