# ISA-EXPERT — ISA Expert milestone: full-lifecycle integration and engineering assurance

Original independent instruction and practice. Read the teaching, work the demonstrations and guided exercise, then attempt questions before reading their explanations. Independent tasks require your own evidence.

Source baseline: [Original integration review across IC32, IC33, IC34 and IC37](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program) · Provider programme checked 2026-09-19; authored integration syllabus 1.0 · checked 2026-09-19

ISA awards Expert automatically after its four specialist certificates. These modules, objectives and 500 questions are original integration teaching and review, not a fifth official exam or provider exam blueprint.

## Scope and external requirements

ISA Expert is awarded through the four constituent provider certificates. This is an integration study bank, not an additional ISA examination.

- No official exam weighting, provider endorsement or pass guarantee is claimed.

- Licensed standards and applicable edition-specific clause review remain external.

- Synthetic laboratories do not establish vendor-device or physical commissioning competence.

- The official Expert milestone follows successful completion of the four provider specialist certificate requirements; this app does not award it and adds no official exam.

- Obtain applicable licensed standards and qualified edition-specific conformance review.

- Complete required supported vendor-tool, representative-device, calibrated instrumentation and authorized site practice before making the corresponding field-capability claims.

- The question bank is independently authored and structurally reviewed; independent psychometric calibration and provider equivalence are not claimed.

## Preparation

Prior courses: IC32, IC33, IC34, IC37

- Complete the prerequisite specialist learning and relevant network/control fundamentals.

- Use the broader controls and networking courses for deeper vendor and physical implementation preparation.

## ISA-EXPERT-M01 — Lifecycle boundaries, roles and assurance

### ISA-EXPERT-L01 — Define the service and its real boundaries

Estimated study time: 90 minutes before independent work. Prerequisite chapters: Use the course prerequisites.

An integration assessment begins with a service outcome and its operating envelope. “Secure the BMS” is too vague: identify which measurements must be current, which commands are permitted, which local functions continue without supervision, who must receive alarms, and how long degraded operation is allowed. Describe normal, maintenance, fault, restart, incident and recovery states. A component can be nonessential in one state and indispensable in another. An engineering licence may not affect today's cooling loop but can determine whether tomorrow's failed controller is recoverable.

Build three linked views. The physical-function view connects sensing, decisions, actuation and independent protection. The information view follows values, commands, time, identity and configuration through transformations. The authority view identifies who or what can alter each relevant state. A gateway can be a harmless-looking telemetry intermediary in the information view while holding administrator authority over every downstream controller. The linked views expose this difference.

A boundary does not make external dependencies disappear. Mark a corporate directory, supplier portal or cloud broker as external when appropriate, then record its interface, owner, trust assumption, outage behaviour and recovery role. Do not expand the system indiscriminately to include every connected corporate service; include the relationships that can affect the assessed function or authority. Conversely, do not remove a dependency merely because another team owns it.

Use observations to reconcile the as-designed and as-operated models. Inventory exports, approved passive traces, device configuration, work orders and operator knowledge provide different evidence. Record unresolved paths as hypotheses with a consequence and verification plan. A complete-looking diagram that silently excludes a vendor modem is weaker than a bounded model that identifies the uncertainty.

#### Worked demonstrations

**Define the service and its real boundaries — integrated worked case**

Synthetic teaching case; no live equipment was tested.

A cooling system can regulate locally for 45 minutes. Its required unattended alarm awareness is limited to 15 minutes. Engineering recovery depends on an external identity service and vault. A proposed cyber isolation removes BMS and identity access for 30 minutes.

**Reasoning:** The physical loop may survive, but the proposal violates the shorter awareness limit unless approved alternate coverage exists. The identity and vault are external dependencies that influence recovery. The boundary record must therefore include the alarm path, staffing alternative, isolation duration and bootstrap access. It should not claim that 45 minutes of local regulation authorizes 45 minutes of unattended operation.

#### Guided practice

A DCIM connector reads BMS telemetry and opens CMMS work orders. Its token also permits BMS configuration writes. Draw the data and authority boundaries and identify the mismatch.

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** Telemetry and work-order creation are intended functions. BMS configuration authority is a separate effective path that exceeds the declared connector role. Record and constrain that path, preserving required reads and work-order operations. Verify direct API writes are denied, not merely hidden in the interface.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Create a three-view system model for one representative hall. Include at least one maintenance path, one external recovery dependency and one unresolved assumption. Supply evidence or a bounded verification plan for each boundary crossing.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Construct a system-under-consideration model that preserves physical function, authority and external dependencies.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0001 · single · design**

Which boundary revision is needed before accepting the assessment?

SYNTHETIC ASSESSMENT EVIDENCE: The system under consideration contains cooling PLCs and the BMS. Remote engineering authenticates through a corporate directory excluded from the diagram. Local loops survive directory loss; recovery staff cannot obtain project credentials without it.

1. Move every corporate application into the cooling zone
2. Add the directory IP only to the asset spreadsheet
3. Record the directory as an external security and recovery dependency with defined interfaces and assumptions
4. Exclude the directory because local regulation continues

**Correct option(s):** 3

- Option 1: The directory dependency does not justify merging unrelated assets or trust requirements.
- Option 2: An address alone does not describe authority, failure behaviour or ownership.
- Option 3: A dependency need not be owned inside the system to influence its risk and restoration.
- Option 4: Local continuity does not resolve engineering-access and recovery consequences.

**ISA-EXPERT-Q0002 · single · diagnosis**

What invalidates the claimed independence of these recovery paths?

SYNTHETIC ASSESSMENT EVIDENCE: Path A uses a local engineering laptop. Path B uses a vendor jump host. Both retrieve the only PLC project and credentials from the same online vault.

1. Both paths share a required trust and availability dependency
2. Both paths use the same approved project version
3. Both paths restore the same controller model
4. Both paths are operated by qualified controls engineers

**Correct option(s):** 1

- Option 1: Different execution hosts do not provide independence when one vault failure defeats both.
- Option 2: Consistent intended logic is desirable and does not by itself create a single access dependency.
- Option 3: A common target is inherent to alternate recovery, not proof that the paths fail together.
- Option 4: Shared competence does not explain the common technical failure point.

**ISA-EXPERT-Q0003 · single · design**

How should the team scope an EPMS modernization?

SYNTHETIC ASSESSMENT EVIDENCE: The project replaces supervisory gateways and displays. Protection relays remain independently responsible for electrical protection; one gateway can also issue approved switching requests.

1. Include supervisory data and command interfaces, and explicitly analyze effects on the independent protection boundary
2. Declare protection out of scope and omit every relay interface
3. Treat successful EPMS polling as acceptance of protective relay settings
4. Assign the cyber integrator authority to approve electrical switching

**Correct option(s):** 1

- Option 1: The scope must distinguish responsibilities while examining actual interactions.
- Option 2: Excluding relay redesign does not remove gateway interactions from the assessment.
- Option 3: Supervisory communications do not establish protection correctness.
- Option 4: Technical integration responsibility does not confer site switching authority.

**ISA-EXPERT-Q0004 · single · diagnosis**

Which hidden system element must be added to this threat model?

SYNTHETIC ASSESSMENT EVIDENCE: A controller zone has no routed enterprise access. Technicians move projects through a shared engineering laptop that also connects to the supplier network.

1. Every unrelated supplier customer network
2. A rule declaring the controller zone air-gapped
3. An enterprise firewall rule that does not exist
4. The portable engineering workflow and its media, identity and project trust paths

**Correct option(s):** 4

- Option 1: Scope should follow credible dependencies and access, not indiscriminate expansion.
- Option 2: The label does not eliminate the described engineering transfer.
- Option 3: Inventing a routed connection misses the observed portable path.
- Option 4: An offline network diagram can omit a practical transfer route.

**ISA-EXPERT-Q0005 · single · design**

Which requirement correctly separates service and security boundaries?

SYNTHETIC ASSESSMENT EVIDENCE: The collector must read cooling values every five seconds. It must never change PLC logic. Reads and programming use different application operations over the same permitted TCP service.

1. Allow the port only during office hours
2. Specify only the permitted destination port and infer read-only access
3. Specify freshness and read operations separately from denied programming authority, with enforcement and tests for each
4. Block the service and declare programming prevented

**Correct option(s):** 3

- Option 1: Time restriction does not prevent an authorized-period programming operation.
- Option 2: The same service exposes operations beyond the intended collector role.
- Option 3: Port reachability cannot express the full application authorization requirement.
- Option 4: That also defeats required collection and does not satisfy the combined requirement.

**ISA-EXPERT-Q0006 · single · diagnosis**

Why is this asset criticality conclusion incomplete?

SYNTHETIC ASSESSMENT EVIDENCE: A historian is rated low because its failure does not stop local cooling. Operations uses its alarm history to diagnose repeated excursions and its only copy stores approved commissioning baselines.

1. The rating is correct because it is a supervisory asset
2. Criticality also includes decision, evidence and recovery dependencies
3. Every historian must automatically receive the highest rating
4. The rating should be based exclusively on replacement purchase price

**Correct option(s):** 2

- Option 1: Layer labels do not determine all operational dependencies.
- Option 2: Immediate process stoppage is only one consequence dimension.
- Option 3: Criticality must follow this system's actual functions and consequences.
- Option 4: Cost omits the stated diagnostic and baseline functions.

**ISA-EXPERT-Q0007 · single · design**

What additional operating state belongs in this system description?

SYNTHETIC ASSESSMENT EVIDENCE: The design documents automatic and manual modes. During firmware maintenance, one controller is unavailable and operators rely on a temporary local panel.

1. The maintenance configuration, its authority, visibility, duration and recovery conditions
2. A permanent broad panel privilege to simplify every mode
3. A duplicate description of automatic mode with a different title
4. A statement that maintenance occurs outside the system lifecycle

**Correct option(s):** 1

- Option 1: It changes both control dependencies and permitted operations.
- Option 2: Convenience does not establish a justified long-term authority boundary.
- Option 3: That would not model the missing maintenance behaviour.
- Option 4: Maintenance is a foreseeable system state that affects risk.

**ISA-EXPERT-Q0008 · single · diagnosis**

Which assumption needs explicit validation?

SYNTHETIC ASSESSMENT EVIDENCE: The risk workshop credits an independent leak alarm. Its sensor is separate, but both alarms reach operators through one BMS notification server and one power source.

1. Equality of the two displayed alarm descriptions
2. Different IP addresses on the alarm inputs
3. Separate ownership of the two sensor purchase orders
4. Independence of the complete detection and response paths

**Correct option(s):** 4

- Option 1: Text equality does not determine common-cause failure.
- Option 2: Address distinction does not remove the shared server and power dependencies.
- Option 3: Procurement separation does not prove operational independence.
- Option 4: Sensor separation alone does not establish independent notification or power.

**ISA-EXPERT-Q0009 · single · design**

How should a newly discovered vendor modem affect the approved architecture?

SYNTHETIC ASSESSMENT EVIDENCE: A site assessment finds a modem attached to the controller maintenance port. The design baseline has no remote path and the current support contract is unclear.

1. Remove it immediately without checking any required support or process dependency
2. Leave it because it is not connected to the routed network
3. Treat it as a material boundary discrepancy, establish authority and actual reach, then decide controlled treatment
4. Add it to the diagram and consider the finding closed

**Correct option(s):** 3

- Option 1: The discrepancy requires controlled action informed by operational effects.
- Option 2: A separate communications medium can still cross the security boundary.
- Option 3: The observation changes the documented access assumptions and may affect risk.
- Option 4: Documentation alone does not establish approved authority or adequate controls.

**ISA-EXPERT-Q0010 · single · calculation**

Which statement about degraded operation follows from these limits?

SYNTHETIC ASSESSMENT EVIDENCE: Local cooling can maintain the modeled load for 45 minutes without supervision. Required operator alarm awareness must be restored within 15 minutes. A proposed isolation lasts 25 minutes with no alternate coverage.

1. The proposal becomes acceptable if the security incident is rated critical
2. The proposal violates the awareness limit even though local cooling endurance is longer
3. The proposal fails because every supervisory interruption immediately stops cooling
4. The proposal is acceptable because 25 is less than 45

**Correct option(s):** 2

- Option 1: Incident severity does not automatically change the approved operational envelope.
- Option 2: The stricter applicable service requirement remains active.
- Option 3: The stated local control capability contradicts that claim.
- Option 4: That compares only the control-endurance constraint.

**ISA-EXPERT-Q0011 · single · design**

Which scope description is most useful for an outsourced DCIM integration?

SYNTHETIC ASSESSMENT EVIDENCE: DCIM receives BMS and EPMS data and opens CMMS work orders. The supplier proposes using one API token with both configuration-write and telemetry-read privileges.

1. Document each data and action flow, its business purpose, owner and minimum authority
2. Describe DCIM as monitoring-only because most transactions are reads
3. Place every connected application in one zone to avoid interface analysis
4. Approve the token because the supplier owns the software

**Correct option(s):** 1

- Option 1: The work-order and configuration paths have different consequences and should be explicit.
- Option 2: Rare write paths still create authority and risk.
- Option 3: Connectivity does not imply common security requirements.
- Option 4: Product ownership does not determine the asset owner's required authority.

**ISA-EXPERT-Q0012 · single · diagnosis**

What distinction is missing from this requirements review?

SYNTHETIC ASSESSMENT EVIDENCE: The BMS accepts a command and returns success, but a field actuator remains in local mode. The contract defines success only as a successful API response.

1. Primary versus standby server ownership
2. Static versus dynamically assigned addresses
3. Command acceptance versus execution and verified physical outcome
4. Encrypted versus unencrypted transport alone

**Correct option(s):** 3

- Option 1: Ownership is relevant but does not define physical completion.
- Option 2: Address assignment does not explain the semantic acceptance gap.
- Option 3: The interface response is an intermediate event, not the final service result.
- Option 4: Encryption does not determine local-mode actuation.

**ISA-EXPERT-Q0013 · single · design**

Which system boundary treatment best handles a cloud analytics service?

SYNTHETIC ASSESSMENT EVIDENCE: The service consumes replicated telemetry. It has no intended control role, but its connector currently stores a credential also accepted by the BMS configuration API.

1. Give the service its own controller zone without changing the credential
2. Exclude the cloud because control is not its advertised purpose
3. Disable all telemetry export permanently without evaluating scoped access
4. Analyze and remove or constrain the unintended authority path while retaining the declared data interface

**Correct option(s):** 4

- Option 1: A diagram change alone does not remove the shared authority.
- Option 2: Intent does not eliminate effective write authority.
- Option 3: That may discard required function when a narrower treatment is feasible.
- Option 4: Actual credentials define a broader path than the intended architecture.

**ISA-EXPERT-Q0014 · single · diagnosis**

Which risk register entry requires reassessment after this expansion?

SYNTHETIC ASSESSMENT EVIDENCE: A second hall shares the original engineering jump host, identity service and gateway template repository. Its process equipment is otherwise independent.

1. Every historical likelihood value must double automatically
2. Only scenarios involving direct cable failure between the halls
3. Scenarios involving shared engineering authority and propagated configuration defects
4. No scenario because the original servers are unchanged

**Correct option(s):** 3

- Option 1: The expansion requires analysis, not an unsupported numeric rule.
- Option 2: Shared authority can affect both halls without that cable failure.
- Option 3: The added hall changes consequence and common-cause scope.
- Option 4: Unchanged components can acquire materially broader consequences.

**ISA-EXPERT-Q0015 · single · design**

How should a physical maintenance interface be represented?

SYNTHETIC ASSESSMENT EVIDENCE: A locked panel contains an engineering port. Remote access is controlled, but a service technician can connect locally during instrument calibration.

1. Assume remote MFA automatically covers the local port
2. Prohibit calibration until every local interface is removed
3. Include physical access, local authentication, allowed operations and maintenance handback in the interface model
4. Ignore it because the panel is normally locked

**Correct option(s):** 3

- Option 1: The mechanisms may be independent.
- Option 2: The function may require a controlled interface rather than elimination.
- Option 3: The local path can bypass remote controls and has its own lifecycle.
- Option 4: Authorized maintenance opens a foreseeable access route.

**ISA-EXPERT-Q0016 · single · diagnosis**

Why does this scope statement fail the restoration objective?

SYNTHETIC ASSESSMENT EVIDENCE: The charter includes BMS recovery in two hours but excludes the licence service and vendor activation workflow. Replacement hardware needs activation before acquisition starts.

1. The vendor activation delay should be removed from measured time
2. The exclusion leaves an essential recovery dependency unanalyzed
3. The objective is satisfied when the replacement OS boots
4. Licence administration is never part of engineering assurance

**Correct option(s):** 2

- Option 1: Excluding a required wait would misrepresent restoration performance.
- Option 2: A scope boundary must still account for dependencies needed to meet its objective.
- Option 3: The required service is BMS acquisition, not bare-host startup.
- Option 4: It can determine whether the required service is recoverable.

**ISA-EXPERT-Q0017 · single · design**

Which document change best captures an uncertain legacy path?

SYNTHETIC ASSESSMENT EVIDENCE: Packet records suggest an old gateway forwards engineering traffic, but its configuration cannot yet be read safely. The project must issue an initial risk report.

1. Draw the path as confirmed and omit the uncertainty to simplify approval
2. Record the path as an unresolved hypothesis with supporting evidence, consequence and a bounded verification plan
3. Remove the path because configuration proof is missing
4. Assume all gateway traffic is malicious until disproved

**Correct option(s):** 2

- Option 1: That overstates the evidence.
- Option 2: Uncertainty should remain visible in decisions and follow-up work.
- Option 3: The credible observation should not disappear from the analysis.
- Option 4: The evidence supports investigation, not universal attribution.

#### Recall

**A DCIM connector reads BMS telemetry and opens CMMS work orders. Its token also permits BMS configuration writes. Draw the data and authority boundaries and identify the mismatch.**

Telemetry and work-order creation are intended functions. BMS configuration authority is a separate effective path that exceeds the declared connector role. Record and constrain that path, preserving required reads and work-order operations. Verify direct API writes are denied, not merely hidden in the interface.

**In this case, what is the justified integrated decision? A cooling system can regulate locally for 45 minutes. Its required unattended alarm awareness is limited to 15 minutes. Engineering recovery depends on an external identity service and vault. A proposed cyber isolation removes BMS and identity access for 30 minutes.**

The physical loop may survive, but the proposal violates the shorter awareness limit unless approved alternate coverage exists. The identity and vault are external dependencies that influence recovery. The boundary record must therefore include the alarm path, staffing alternative, isolation duration and bootstrap access. It should not claim that 45 minutes of local regulation authorizes 45 minutes of unattended operation.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)
- [ISA public standards-series scope and principal roles](https://www.isa.org/standards-and-publications/isa-standards/isa-iec-62443-series-of-standards)

### ISA-EXPERT-L02 — Allocate lifecycle obligations and testable requirements

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L01

Product assurance, integration assurance and operating assurance answer different questions. A supplier can show how a product was developed and which capabilities were assessed. An integrator configures products into a system and verifies the resulting interfaces. Operators sustain baselines, access, monitoring, maintenance and recovery. The asset owner establishes acceptable risk and the required service outcomes through its governance process. Work can be delegated, but a product certificate does not automatically transfer the owner's site-specific risk decision.

Construct a responsibility record around decisions and evidence, not only job titles. For each requirement, identify who defines it, implements it, verifies it, accepts its residual limitations and maintains it. A provider may perform both installation and technical checks, while the owner still requires an independently reviewable acceptance decision. Administrative privilege is not approval authority: someone who can change relay communications does not thereby gain electrical switching authority.

Write requirements in observable terms. For a read-only collector, specify identity, target set, allowed operations, prohibited programming operations, freshness, supporting dependencies and tests. “Use secure access” leaves too much undefined. Requirements also need lifecycle conditions: renewal, revocation, failover, emergency operation, restoration and retirement. A control that works only during normal operation is not sufficient for a claim covering the whole lifecycle.

Control the standards basis separately from this teaching. Public subject descriptions help organize learning; they do not reproduce licensed normative clauses or determine contractual precedence. Record the applicable parts, editions, scope and qualified clause-level review. Supplier claims should identify assessed versions, assumptions and exclusions. Use applicable evidence without extending it to untested custom scripts, unsupported firmware or site account practices.

#### Worked demonstrations

**Allocate lifecycle obligations and testable requirements — integrated worked case**

Synthetic teaching case; no live equipment was tested.

A certified gateway is supplied with a generic hardening checklist. The contract omits log fields, update support, recovery entitlements and credential handover. The integrator proposes signing off the entire site from the product certificate.

**Reasoning:** The certificate may support scoped product capability. The missing lifecycle outcomes require explicit system requirements and deliverables. The owner should assign implementation and maintenance duties, request applicable evidence and retain responsibility for residual-risk acceptance. The integrator cannot infer complete site achievement from the component claim.

#### Guided practice

Write an acceptance requirement for a two-hour supplier diagnostic session that must be read-only but permits a separately approved emergency engineering task.

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** Name the supplier identity, one target, diagnostic operations, approval and expiry, logging and session/token closure. State that engineering operations require a separate approved role or work order. Test allowed diagnostics, denied writes, expiry of new and established access, and the authorized escalation path.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Draft a requirement-and-responsibility matrix for five cross-team controls. Include one product limitation, one physical authority boundary and one continuing support obligation. Make every acceptance criterion observable.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Translate owner, integrator, supplier and operator responsibilities into executable requirements and acceptance duties.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0018 · single · design**

Which allocation correctly preserves the asset owner's responsibility?

SYNTHETIC ASSESSMENT EVIDENCE: A supplier provides a certified controller. An integrator configures it. The operations contractor maintains it. The owner proposes accepting the supplier certificate as the site's residual-risk decision.

1. The integrator owns risk indefinitely because it commissioned the system
2. The supplier accepts all site risk because its product is certified
3. The owner retains system risk acceptance while each party supplies evidence for its scoped obligations
4. The operations contractor can redefine the business risk criteria during maintenance

**Correct option(s):** 3

- Option 1: Lifecycle accountability and contracts must be explicit; commissioning alone does not transfer owner risk.
- Option 2: Product assurance has a defined scope and cannot cover every site consequence.
- Option 3: Product, integration and maintenance evidence support but do not replace owner acceptance.
- Option 4: Operational duties do not automatically grant that governance authority.

**ISA-EXPERT-Q0019 · single · diagnosis**

What contractual gap does this delivery expose?

SYNTHETIC ASSESSMENT EVIDENCE: The purchase specifies a hardened gateway but omits logging fields, update support, trust-store export and recovery procedures. The gateway passes its vendor feature checklist.

1. The supplier necessarily violated every cybersecurity obligation
2. The owner must accept all defaults because features passed
3. A higher product security-level claim automatically supplies missing operational procedures
4. Lifecycle evidence and support requirements were not made testable deliverables

**Correct option(s):** 4

- Option 1: The stated contract may be incomplete rather than proof of universal breach.
- Option 2: Feature availability does not establish system suitability.
- Option 3: A capability claim does not write or test site-specific lifecycle processes.
- Option 4: A generic hardening label does not define the needed integration outcomes.

**ISA-EXPERT-Q0020 · single · design**

Which requirement is most reviewable?

SYNTHETIC ASSESSMENT EVIDENCE: Engineering access is currently described as secure vendor support. The owner needs time-bounded read-only diagnostics with emergency escalation handled separately.

1. Require a complex shared password changed yearly
2. Require encryption and leave every authenticated action unrestricted
3. Require industry-leading security with annual supplier confirmation
4. Specify named roles, target operations, session approval and expiry, evidence retention and denial tests

**Correct option(s):** 4

- Option 1: That omits individual attribution, operation scope and session closure.
- Option 2: Confidential transport does not satisfy the read-only objective.
- Option 3: The phrase does not define measurable system behaviour.
- Option 4: These define observable authority and lifecycle behaviour.

**ISA-EXPERT-Q0021 · single · diagnosis**

Which handover responsibility is unresolved?

SYNTHETIC ASSESSMENT EVIDENCE: The integrator exports firewall rules. The owner assumes the operations contractor will maintain them. The contractor's scope covers hardware replacement only.

1. Ownership of policy intent, change review and effective-state verification after handover
2. Ownership of the original firewall purchase invoice
3. The product supplier's responsibility for all future route changes
4. The requirement to keep the integrator's temporary administrator indefinitely

**Correct option(s):** 1

- Option 1: A configuration file without an accountable lifecycle process will drift.
- Option 2: Procurement records do not assign ongoing policy control.
- Option 3: A generic supplier role does not automatically include site changes.
- Option 4: Persistent vendor access is not a sound substitute for assigned ownership.

**ISA-EXPERT-Q0022 · single · design**

What should the owner request when a supplier cites a product certificate?

SYNTHETIC ASSESSMENT EVIDENCE: The certificate concerns one firmware family and component type. The proposal uses a different hardware revision and adds custom integration scripts.

1. Removal of all certificate evidence because customization exists
2. The exact certified scope, applicable versions, assumptions and separate evidence for integration gaps
3. Confirmation that the supplier holds any certificate in the same standards family
4. A statement that every future firmware release inherits the certificate

**Correct option(s):** 2

- Option 1: Scoped evidence can remain useful while uncovered integration is assessed separately.
- Option 2: Assurance must be matched to the delivered configuration.
- Option 3: A general supplier association does not establish coverage of the delivered hardware, firmware and custom integration.
- Option 4: Applicability cannot be assumed across unsupported versions.

**ISA-EXPERT-Q0023 · single · diagnosis**

What is wrong with this responsibility matrix?

SYNTHETIC ASSESSMENT EVIDENCE: The service provider is assigned both implementation and acceptance of a high-consequence remote-access change. No owner authority is named for residual risk or physical operating constraints.

1. The matrix omits accountable owner decisions and independent acceptance boundaries
2. The provider must never perform its own technical verification
3. Every technical action must be performed personally by the asset owner
4. The matrix is valid because the provider has administrative access

**Correct option(s):** 1

- Option 1: Implementation privilege is not sufficient authority to accept all site consequences.
- Option 2: Implementers should verify their work, while acceptance responsibilities remain explicit.
- Option 3: Work can be delegated without abandoning accountability.
- Option 4: System privilege does not establish governance authority.

**ISA-EXPERT-Q0024 · single · design**

How should normative editions be controlled in the design basis?

SYNTHETIC ASSESSMENT EVIDENCE: Two contracts cite different editions of a relevant standard part. The requirements team has mapped only public summaries.

1. Select whichever edition yields fewer requirements without recording the choice
2. Resolve applicable editions and contractual precedence, then perform licensed clause-level review by qualified personnel
3. Combine isolated clauses from both editions and call the result certified
4. Treat publication year as irrelevant because all requirements are identical

**Correct option(s):** 2

- Option 1: That bypasses the contractual and technical basis.
- Option 2: Public summaries and mixed editions cannot establish precise conformance.
- Option 3: Uncontrolled mixing does not establish conformity to either edition.
- Option 4: Edition changes can affect obligations and evidence.

**ISA-EXPERT-Q0025 · single · diagnosis**

Which claim should the acceptance reviewer reject?

SYNTHETIC ASSESSMENT EVIDENCE: The integrator implemented every listed security feature but no one traced them to the owner's required functions, risk scenarios or test results.

1. The claim that feature completion establishes system risk treatment effectiveness
2. The claim that additional tests can improve assurance
3. The claim that the installed features may provide useful capability
4. The claim that the owner should review remaining uncertainty

**Correct option(s):** 1

- Option 1: Implementation must be connected to requirements and observed outcomes.
- Option 2: That is a valid next step.
- Option 3: They can be useful even though effectiveness remains unproven.
- Option 4: Owner review remains necessary.

**ISA-EXPERT-Q0026 · single · design**

Which supplier obligation supports a maintainable trust chain?

SYNTHETIC ASSESSMENT EVIDENCE: An appliance uses signed updates and a private trust store. Its signing key may eventually rotate and the appliance may be offline during the transition.

1. Promise that the current key will never change
2. Provide only the current public certificate file
3. Require operators to disable signature checks whenever rotation fails
4. Document supported key rotation, trust distribution, failure handling and offline recovery verification

**Correct option(s):** 4

- Option 1: Permanent-key assumptions are not a robust lifecycle plan.
- Option 2: A file alone does not explain transition, revocation or recovery behaviour.
- Option 3: That removes the intended trust control.
- Option 4: The mechanism must remain usable through foreseeable lifecycle changes.

**ISA-EXPERT-Q0027 · single · diagnosis**

What conflict must be resolved before accepting this support model?

SYNTHETIC ASSESSMENT EVIDENCE: The supplier requires unrestricted outbound access from every controller for diagnostics. The owner's risk-derived architecture permits only a controlled support broker.

1. A mismatch between the proposed support method and the approved system access requirements
2. A reason to waive segmentation because support is contractual
3. A requirement to block all future supplier communication without evaluating alternatives
4. Proof that the supplier is malicious

**Correct option(s):** 1

- Option 1: The parties need a feasible scoped design or explicit treatment decision.
- Option 2: A contract proposal does not silently override risk requirements.
- Option 3: A constrained broker or other supported method may satisfy both needs.
- Option 4: The mismatch may reflect product design or support limitations.

**ISA-EXPERT-Q0028 · single · design**

What should a commissioning contract say about temporary authority?

SYNTHETIC ASSESSMENT EVIDENCE: Factory testing uses broad accounts and permissive rules. The site operational baseline requires named accounts and narrow flows.

1. Remove temporary accounts only after the first annual audit
2. Require a documented transition, effective removal of temporary access and positive/negative site tests
3. Declare factory credentials acceptable if their passwords are long
4. Accept an account-deletion screenshot without checking sessions or alternate interfaces

**Correct option(s):** 2

- Option 1: That leaves an undefined exposure interval after handover.
- Option 2: Factory convenience must not become unreviewed operational authority.
- Option 3: Password strength does not justify broad shared authority.
- Option 4: The operational authority may persist through other mechanisms.

**ISA-EXPERT-Q0029 · single · diagnosis**

Which obligation is missing when a maintenance supplier changes?

SYNTHETIC ASSESSMENT EVIDENCE: The incoming supplier receives diagrams and source projects. The outgoing supplier retains VPN certificates, cloud accounts and BMC keys.

1. A requirement to rename every device at transfer
2. A claim that the outgoing contract's expiry automatically invalidates technical credentials
3. Revocation and verified transfer of effective authority across all access paths
4. A requirement to keep both suppliers permanently active for continuity

**Correct option(s):** 3

- Option 1: Names do not revoke old credentials.
- Option 2: Administrative expiry does not necessarily enforce revocation.
- Option 3: Technical documentation transfer does not close former privileges.
- Option 4: Continuity can be planned without indefinite excess authority.

**ISA-EXPERT-Q0030 · single · design**

Which change to the CRS best addresses this ambiguous requirement?

SYNTHETIC ASSESSMENT EVIDENCE: The cybersecurity requirements specification says unauthorized changes shall be detected promptly. It names no event source, deadline or responsible recipient.

1. Specify the brand of SIEM and assume detection follows
2. Define the changes in scope, evidence path, latency criterion, recipient and tested escalation behaviour
3. Require a daily PDF of all logs without assessing timeliness
4. Replace promptly with rapidly while retaining the same omission

**Correct option(s):** 2

- Option 1: A product choice does not establish coverage or response.
- Option 2: The requirement becomes measurable and operationally actionable.
- Option 3: A batch report may not meet the required consequence-driven response time.
- Option 4: A synonym does not define acceptance.

**ISA-EXPERT-Q0031 · single · diagnosis**

What does this procurement acceptance fail to demonstrate?

SYNTHETIC ASSESSMENT EVIDENCE: The supplier gives a vulnerability disclosure policy and a software bill of materials. No process exists to map advisories to the delivered running versions.

1. A guarantee that every listed component is vulnerable
2. Operational applicability assessment and treatment ownership
3. The impossibility of accepting the product under any treatment
4. The existence of supplier security information

**Correct option(s):** 2

- Option 1: Presence alone does not establish affected conditions.
- Option 2: Disclosure inputs are useful, but someone must connect them to the actual estate.
- Option 3: The missing lifecycle process may be remediable.
- Option 4: The policy and inventory do provide information.

**ISA-EXPERT-Q0032 · single · design**

How should a requirement handle an essential legacy controller without local user accounts?

SYNTHETIC ASSESSMENT EVIDENCE: The design needs accountable engineering changes. The controller cannot provide individual authentication, and replacement is not feasible during this phase.

1. Specify a scoped system-level treatment with controlled engineering access, attribution evidence, limitations and residual-risk review
2. Assign one shared password and describe it as individual attribution
3. Delete the accountability requirement permanently
4. Mark the controller as individually authenticated because the firewall has an administrator login

**Correct option(s):** 1

- Option 1: The implementation must address the objective without falsely claiming nonexistent native capability.
- Option 2: Shared credentials do not identify the actual actor.
- Option 3: A product limitation does not remove the consequence or governance need.
- Option 4: Firewall administration is not the controller's engineering identity mechanism.

**ISA-EXPERT-Q0033 · single · diagnosis**

Which lifecycle role distinction matters in this dispute?

SYNTHETIC ASSESSMENT EVIDENCE: The supplier says the software was securely developed. The integrator says it configured the product as instructed. The site still has an unowned emergency account after handover.

1. Product development, system integration and continuing operation supply different obligations and evidence
2. Secure development guarantees every site account is current
3. The existence of the account proves the product development process was absent
4. Configuration compliance transfers all future access review to the supplier

**Correct option(s):** 1

- Option 1: Success in one role does not automatically close another role's lifecycle gap.
- Option 2: Site identity state changes after product development.
- Option 3: The observed defect may arise in integration or operation.
- Option 4: Continuing responsibilities require explicit assignment.

**ISA-EXPERT-Q0034 · single · design**

Which contractual acceptance condition supports reproducible recovery?

SYNTHETIC ASSESSMENT EVIDENCE: The delivered PLC project depends on a proprietary library and licence available only on the integrator's personal workstation.

1. Require any future library version to compile without testing
2. Deliver controlled compatible dependencies and an authorized, tested recovery entitlement or agreed equivalent
3. Deliver the project filename and retain all dependencies with one individual
4. Exclude the library from recovery because it is proprietary

**Correct option(s):** 2

- Option 1: Compatibility cannot be assumed across versions.
- Option 2: A source file alone cannot reproduce the required application.
- Option 3: That preserves a fragile personal dependency.
- Option 4: Commercial licensing does not remove its technical necessity.

#### Recall

**Write an acceptance requirement for a two-hour supplier diagnostic session that must be read-only but permits a separately approved emergency engineering task.**

Name the supplier identity, one target, diagnostic operations, approval and expiry, logging and session/token closure. State that engineering operations require a separate approved role or work order. Test allowed diagnostics, denied writes, expiry of new and established access, and the authorized escalation path.

**In this case, what is the justified integrated decision? A certified gateway is supplied with a generic hardening checklist. The contract omits log fields, update support, recovery entitlements and credential handover. The integrator proposes signing off the entire site from the product certificate.**

The certificate may support scoped product capability. The missing lifecycle outcomes require explicit system requirements and deliverables. The owner should assign implementation and maintenance duties, request applicable evidence and retain responsibility for residual-risk acceptance. The integrator cannot infer complete site achievement from the component claim.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)
- [ISA public standards-series scope and principal roles](https://www.isa.org/standards-and-publications/isa-standards/isa-iec-62443-series-of-standards)

### ISA-EXPERT-L03 — Build a claim-to-evidence handover

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L02

A strong assurance argument is a chain: required outcome, implementation mechanism, observed test, interpretation, limitation and accountable decision. Breaking any link weakens the claim. A firewall screenshot can show intended text but may not identify the active device or policy. A successful ping can show reachability but not role authorization. A source hash can identify bytes but not prove physical I/O mapping or absence of runtime forces.

Keep evidence environment and scope explicit. Analytical calculations, synthetic records, software models, vendor emulators, representative hardware and field commissioning each establish different things. This is not a ranking in which the earlier forms are worthless. A model can expose a state-machine defect efficiently. It cannot prove an unmodeled electrical installation or physical timing requirement. A credible portfolio combines these forms without relabeling one as another.

Handover should transfer a usable operating capability: current effective baselines, compatible recovery material, credentials under organizational custody, tested procedures, support obligations, open limitations and named owners. Installation completion is not operating readiness if the only licence or recovery key remains with one departing engineer. Require positive and negative tests after temporary commissioning authority is removed.

A claim ages when its relevant system changes. Record the tested versions and conditions, then use change-impact analysis to select regression. Do not automatically repeat every historical test, but do not assume an unchanged document title preserves its evidence. If a limitation is accepted, keep the scope, assumptions, duration and review trigger visible. App completion and credential completion are additional evidence categories; neither automatically grants site-specific physical operating authority.

#### Worked demonstrations

**Build a claim-to-evidence handover — integrated worked case**

Synthetic teaching case; no live equipment was tested.

A lab accepts a segmented gateway using simulated I/O and a local directory. At the site, routing is different, the gateway firmware changed and the only recovery account belongs to the integrator. The project report calls the site fully accepted.

**Reasoning:** The lab results remain useful for the tested configuration. They do not establish the new routing, firmware behaviour or operational custody. Site-specific regression and organizational recovery access are required before the broader claim. The report should distinguish completed lab properties from open site and handover gates.

#### Guided practice

A test report is digitally signed after a technician enters estimated timings. No raw timing records exist. What does the signature establish?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** It can establish the signed document and signer under the signature scheme, but not that its estimated timings were measured. The timings must be labeled estimates, with their basis and uncertainty. A signature does not reconstruct absent observations.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Create an evidence index for one integrated service. For each claim, identify configuration, environment, source record, actual result, untested boundary and accepting role. Include a corrected failure as well as successful tests.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Evaluate whether an assurance claim is supported by the actual tested configuration, operating states and evidence provenance.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0035 · single · diagnosis**

Which claim is justified by this evidence package?

SYNTHETIC ASSESSMENT EVIDENCE: A lab firewall rejects the prohibited engineering flow and passes telemetry tests. Site routing, firmware and identity integration differ and have not been tested.

1. The lab result automatically waives site negative tests
2. No engineering knowledge was gained from the lab
3. The installed site's achieved security is fully established
4. The lab configuration satisfied the tested properties under its stated conditions

**Correct option(s):** 4

- Option 1: Different effective paths can invalidate that transfer.
- Option 2: The bounded test can provide useful design evidence.
- Option 3: Relevant site differences remain untested.
- Option 4: The claim must remain bounded until site-specific differences are verified.

**ISA-EXPERT-Q0036 · single · design**

Which handover package best supports daily ownership?

SYNTHETIC ASSESSMENT EVIDENCE: The project is technically complete, but the operations team has not seen the emergency access, patch, alarm-failure or recovery procedures.

1. An assertion that future problems belong to the warranty team
2. Administrator credentials sent informally to one technician
3. Versioned effective baselines, rehearsed procedures, access custody, open risks and service acceptance evidence
4. A final architecture poster and vendor brochures

**Correct option(s):** 3

- Option 1: Warranty support does not replace the operator's immediate responsibilities.
- Option 2: That creates weak custody and staffing dependence.
- Option 3: Operational capability depends on executable ownership, not installation alone.
- Option 4: These do not establish the procedures and custody needed during failure.

**ISA-EXPERT-Q0037 · single · diagnosis**

What invalidates this closure metric?

SYNTHETIC ASSESSMENT EVIDENCE: The project reports 100% of tests passed after removing four failed negative tests from the acceptance list. Their requirements remain in the approved CRS.

1. The successful positive tests are necessarily false
2. The failed tests can be ignored because they assess denied actions
3. The denominator was changed without resolving the requirements or defects
4. Any revision to a test plan is inherently prohibited

**Correct option(s):** 3

- Option 1: They may remain valid for their narrower properties.
- Option 2: Negative behaviour is part of the stated requirements.
- Option 3: The metric no longer represents the approved acceptance scope.
- Option 4: Plans can change through justified controlled review.

**ISA-EXPERT-Q0038 · single · design**

Which response best handles a late site dependency discovery?

SYNTHETIC ASSESSMENT EVIDENCE: Site acceptance finds that certificate renewal needs an outbound service omitted from the flow matrix. Adding it requires a new boundary crossing.

1. Leave renewal broken because initial certificates still work
2. Permit all outbound traffic to avoid another delay
3. Add the rule without changing documents because it is a support flow
4. Update the requirement and risk/interface analysis, implement the scoped flow and retest affected behaviour

**Correct option(s):** 4

- Option 1: The system would fail a foreseeable lifecycle requirement.
- Option 2: That exceeds the identified dependency.
- Option 3: Support flows can carry material authority and must remain traceable.
- Option 4: The discovery changes lifecycle connectivity and must be controlled.

**ISA-EXPERT-Q0039 · single · diagnosis**

Why is this training claim insufficient for site authority?

SYNTHETIC ASSESSMENT EVIDENCE: An engineer passes all four specialist knowledge exams and completes simulated switching scenarios. No employer authorization or physical switching assessment is recorded.

1. The credentials provide no evidence of any knowledge
2. Knowledge credentials and simulation do not themselves confer site-specific physical operating authority
3. A high app quiz score replaces the missing authorization
4. The engineer must repeat every unrelated entry-level course before any work

**Correct option(s):** 2

- Option 1: They are evidence within their assessed scope.
- Option 2: Competence and authorization require the applicable local gates.
- Option 3: An application cannot grant the employer's operational authority.
- Option 4: The missing gate is specific, not indiscriminate repetition.

**ISA-EXPERT-Q0040 · single · design**

Which evidence should be retained when an acceptance test fails and is corrected?

SYNTHETIC ASSESSMENT EVIDENCE: A failover test initially exceeded the freshness limit. A route change corrected it in the repeat run.

1. Original failure, causal analysis, approved correction and repeat results tied to the effective baseline
2. A generic note that the network was optimized
3. Only the failed run because later evidence is biased
4. Only the passing screenshot to avoid conflicting records

**Correct option(s):** 1

- Option 1: Keeping both runs makes the improvement and residual scope reviewable.
- Option 2: That does not identify the causal intervention or tested state.
- Option 3: The corrected result is relevant when its conditions and changes are documented.
- Option 4: That conceals the defect and correction history.

**ISA-EXPERT-Q0041 · single · diagnosis**

Which conclusion follows from this evidence mismatch?

SYNTHETIC ASSESSMENT EVIDENCE: The signed acceptance report names firmware 5.4. The running device reports 5.5, installed after testing to fix a minor defect.

1. The signature proves 5.5 was implicitly tested
2. The entire system must be rejected permanently
3. The current configuration needs an impact review and appropriate regression evidence
4. Minor release numbers guarantee unchanged security behaviour

**Correct option(s):** 3

- Option 1: A signature does not change the recorded test configuration.
- Option 2: The gap can be addressed through controlled assessment and testing.
- Option 3: A later change can affect the properties supported by the earlier tests.
- Option 4: Version labels are not evidence of impact absence.

**ISA-EXPERT-Q0042 · single · design**

What should an independent reviewer do with a vendor's unsupported recovery-time claim?

SYNTHETIC ASSESSMENT EVIDENCE: The vendor states restoration takes 20 minutes. Its demonstration excluded identity recovery, licence activation and physical handback required by the site objective.

1. Add an arbitrary fixed contingency and call it measured
2. Define the actual recovery boundary and measure the complete required sequence or qualify the narrower claim
3. Use 20 minutes because it is the only available number
4. Reject all vendor evidence as unusable

**Correct option(s):** 2

- Option 1: A contingency estimate is not an observed end-to-end result.
- Option 2: Timing must correspond to the service objective and dependencies.
- Option 3: Availability of a number does not establish applicability.
- Option 4: The demonstrated subtask timing may still inform the broader recovery model.

**ISA-EXPERT-Q0043 · single · diagnosis**

Which aspect of acceptance is missing?

SYNTHETIC ASSESSMENT EVIDENCE: The replacement gateway meets throughput and encryption tests. Operators cannot distinguish stale values from live data after an upstream outage.

1. Operational data semantics and failure indication
2. The gateway's total port count
3. A lower polling interval without quality handling
4. A second encryption layer alone

**Correct option(s):** 1

- Option 1: Secure transport and capacity do not establish useful process awareness.
- Option 2: That does not resolve freshness interpretation.
- Option 3: Faster polling can still display stale cached values.
- Option 4: More encryption does not mark stale data.

**ISA-EXPERT-Q0044 · single · design**

Which portfolio artifact most directly demonstrates lifecycle integration?

SYNTHETIC ASSESSMENT EVIDENCE: The learner has architecture diagrams, quiz results and isolated device configurations. The charter seeks diagnosis and recovery capability as well as design.

1. A certificate list with no implementation records
2. A simulated success relabeled as production validation
3. A traceable campaign linking a requirement to implementation, observed failure, diagnosis, controlled correction and trusted restoration
4. A larger collection of unrelated configuration screenshots

**Correct option(s):** 3

- Option 1: Credentials are useful but do not show the specific practical outcome.
- Option 2: Mislabeling would invalidate the evidence claim.
- Option 3: It connects the lifecycle responsibilities through evidence.
- Option 4: Volume alone does not establish integrated reasoning or recovery.

**ISA-EXPERT-Q0045 · single · diagnosis**

What must be qualified in this achieved-security statement?

SYNTHETIC ASSESSMENT EVIDENCE: The assessment covers normal operation and remote access. It excludes emergency local access, restored images and the standby management path.

1. The untested lifecycle states and interfaces remain outside the demonstrated claim
2. The product capability certificate proves the excluded paths
3. The target level should be automatically lowered to match the tests
4. All controls tested in normal operation should be ignored

**Correct option(s):** 1

- Option 1: Achieved assurance must state its actual coverage and gaps.
- Option 2: Component evidence does not replace installed lifecycle verification.
- Option 3: A testing gap does not justify silently changing risk-derived requirements.
- Option 4: Their bounded evidence can remain valid.

**ISA-EXPERT-Q0046 · single · design**

How should a project close an unresolved but accepted limitation?

SYNTHETIC ASSESSMENT EVIDENCE: A legacy device cannot emit individual-user logs. A controlled gateway provides partial attribution, and the owner approves the remaining risk for a defined period.

1. Mark the original native-logging requirement fully implemented
2. Record the limitation, treatment assumptions, accountable acceptance, review trigger and evidence needed for replacement
3. Delete the issue once the owner signs
4. Keep the issue open without an owner or expiry because it is legacy

**Correct option(s):** 2

- Option 1: The device still lacks that capability.
- Option 2: The gap remains visible and governed rather than disguised as compliance.
- Option 3: Acceptance does not eliminate the technical limitation or future review need.
- Option 4: That fails to sustain the accepted treatment.

**ISA-EXPERT-Q0047 · single · diagnosis**

Which transferability assumption fails here?

SYNTHETIC ASSESSMENT EVIDENCE: Two halls use the same controller model. Hall B has a different sensor range, library version and supervisory gateway mapping. The team reuses Hall A's complete test report unchanged.

1. Identical controller model names guarantee identical loaded applications
2. No test evidence can ever be reused between similar systems
3. The newer hall must necessarily perform better
4. Equivalent hardware does not establish equivalent integrated behaviour

**Correct option(s):** 4

- Option 1: The project and dependencies can differ.
- Option 2: Applicable portions may be reused with justified equivalence and regression scope.
- Option 3: Age does not establish correctness.
- Option 4: The listed differences affect measurement, execution and interface semantics.

**ISA-EXPERT-Q0048 · single · design**

Which acceptance condition should be added for an operational exception register?

SYNTHETIC ASSESSMENT EVIDENCE: Exceptions have approvals and dates but no link to technical rules, accounts or sessions. Several expired entries still permit access.

1. Add more approvers without mapping the actual access
2. Delete expired register rows automatically
3. Each exception must identify effective enforcement objects and demonstrate closure or renewed approval at expiry
4. Keep all technical permissions until the annual audit

**Correct option(s):** 3

- Option 1: Additional signatures do not locate or revoke authority.
- Option 2: That can hide permissions that remain active.
- Option 3: Administrative and technical state must be reconciled.
- Option 4: That defeats the stated expiry boundary.

**ISA-EXPERT-Q0049 · single · diagnosis**

What is the strongest conclusion after this tabletop?

SYNTHETIC ASSESSMENT EVIDENCE: Participants correctly describe a ransomware recovery sequence. No images were restored, no credentials retrieved and no timing measured.

1. The exercise supports procedural understanding and exposes discussion findings, while technical execution remains untested
2. The site can omit a restoration drill because every participant agreed
3. The team has demonstrated no useful capability at all
4. The RTO is achieved because the sequence sounds feasible

**Correct option(s):** 1

- Option 1: Tabletop evidence has a useful but limited scope.
- Option 2: Consensus does not validate recovery dependencies or media.
- Option 3: Reasoning and coordination can be assessed in a tabletop.
- Option 4: Feasibility discussion is not elapsed execution evidence.

**ISA-EXPERT-Q0050 · single · design**

Which final programme statement is accurate?

SYNTHETIC ASSESSMENT EVIDENCE: A learner completes the app's four specialist paths and integration bank but has not completed the provider's required official courses and exams.

1. The learner completed this app's preparation and integration work; provider credentials remain separate requirements
2. The learner should erase all preparation evidence until officially certified
3. The app completion automatically grants the official Expert certificate
4. The integration bank is a fifth mandatory ISA examination

**Correct option(s):** 1

- Option 1: The application does not award ISA certificates or the automatic Expert milestone.
- Option 2: The original learning and practical evidence remain useful within their stated scope.
- Option 3: Only the provider's stated certificate requirements establish that award.
- Option 4: The Expert milestone follows the four provider certificates without a separate exam.

#### Recall

**A test report is digitally signed after a technician enters estimated timings. No raw timing records exist. What does the signature establish?**

It can establish the signed document and signer under the signature scheme, but not that its estimated timings were measured. The timings must be labeled estimates, with their basis and uncertainty. A signature does not reconstruct absent observations.

**In this case, what is the justified integrated decision? A lab accepts a segmented gateway using simulated I/O and a local directory. At the site, routing is different, the gateway firmware changed and the only recovery account belongs to the integrator. The project report calls the site fully accepted.**

The lab results remain useful for the tested configuration. They do not establish the new routing, firmware behaviour or operational custody. Site-specific regression and organizational recovery access are required before the broader claim. The report should distinguish completed lab properties from open site and handover gates.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)
- [ISA public standards-series scope and principal roles](https://www.isa.org/standards-and-publications/isa-standards/isa-iec-62443-series-of-standards)

## ISA-EXPERT-M02 — Risk, security levels and requirements

### ISA-EXPERT-L04 — Reason from attack path to physical consequence

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L03

A useful scenario connects an initiating condition to a credible action, affected function and consequence. “Gateway vulnerability” is not yet a scenario. State how an actor reaches the affected service, what authority or behaviour becomes possible, how that affects sensing, control or supervision, and what happens under the relevant process conditions. Include ordinary mistakes and failures where they interact with the same requirements; an unauthorized but nonmalicious project download can produce the same harmful control state as deliberate misuse.

Separate likelihood, consequence and evidence confidence. Generic vulnerability severity is an input to technical understanding, not a complete site risk result. A flaw in an active engineering path can matter more operationally than a higher-scored flaw in a disabled optional service, but the disabled-state assumption must be sustained through maintenance. Sparse incident history does not make a credible path impossible. Where uncertainty crosses the acceptance boundary, expose the sensitivity rather than choosing the estimate that permits the desired decision.

Credit safeguards only with their prerequisites. A manual response needs timely detection, a reachable trained person, authority, access, tools and enough time. Redundant sensors can share a faulty reference, impulse line, power source or gateway mapping. Two recovery paths can share one vault. Avoid counting segmentation and its implementing firewall as two independent reductions of the same path without justification.

Quantitative calculations remain conditional models. If annual probability is p and event loss is L, p×L is an expected-loss estimate under those assumptions, not a prediction of a fixed yearly bill. Ordinal matrix categories usually do not support arbitrary averaging or addition. Maintain the approved decision rules and document uncertainty, dependencies and reassessment triggers. A treatment that adds an identity dependency or centralizes authority should be examined for new scenarios as well as its intended benefit.

#### Worked demonstrations

**Reason from attack path to physical consequence — integrated worked case**

Synthetic teaching case; no live equipment was tested.

An assessment credits independent high-temperature notification from two sensors. Both feed one BMS server, one notification account and an unstaffed overnight mailbox. The claimed manual response is five minutes.

**Reasoning:** The two sensing inputs do not establish independent end-to-end response. Server/account failure can defeat both, and overnight staffing makes the five-minute action unsupported. Rebuild the scenario around actual detection and intervention paths, then test or justify alternate coverage and timing before crediting the safeguard.

#### Guided practice

A residual-risk decision passes at likelihood category 2 and fails at category 3. Available evidence supports either category. What should the decision record say?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** The acceptance is sensitive to unresolved likelihood uncertainty. Record both plausible judgments, their basis and the boundary crossed. Obtain stronger discriminating evidence, additional treatment or an explicit authorized decision about the uncertainty; do not silently select category 2.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Develop three risk scenarios for one service: an unauthorized engineering action, a common-cause dependency loss and a maintenance error. Challenge each credited safeguard with one realistic failure of its prerequisites.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Construct and challenge consequence-linked risk scenarios using explicit assumptions, safeguard dependencies and uncertainty.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0051 · single · diagnosis**

Which step is missing from this risk scenario?

SYNTHETIC ASSESSMENT EVIDENCE: The register lists stolen vendor credentials and a vulnerable gateway. It does not describe the action, affected process or resulting harm.

1. A larger vulnerability score copied from a public advisory
2. A credible path from the threat conditions through unauthorized action to a defined consequence
3. A product replacement decision before the scenario is completed
4. A mandatory assumption that every compromise stops the whole site

**Correct option(s):** 2

- Option 1: Severity does not supply the missing site consequence chain.
- Option 2: Risk treatment needs more than a list of weaknesses.
- Option 3: Treatment selection is premature without understanding the risk path.
- Option 4: The consequence must follow credible process and dependency analysis.

**ISA-EXPERT-Q0052 · single · design**

How should conflicting consequence estimates be resolved?

SYNTHETIC ASSESSMENT EVIDENCE: Controls staff predict local cooling survives loss of supervision. Operations predicts loss of alarm awareness creates unacceptable unattended operation after ten minutes.

1. Separate the functions and time horizons, then evaluate both within the approved operating envelope
2. Accept the controls estimate because local regulation is the most technical function
3. Average the estimates into one moderate score
4. Accept the higher score without recording the causal basis

**Correct option(s):** 1

- Option 1: Both statements can be true for different consequences.
- Option 2: Operational awareness is also a required function.
- Option 3: Averaging unlike effects can conceal the limiting requirement.
- Option 4: Conservatism alone does not make the scenario traceable or testable.

**ISA-EXPERT-Q0053 · single · diagnosis**

What weakens the credited safeguard?

SYNTHETIC ASSESSMENT EVIDENCE: The assessment credits a manual response within five minutes. The alarm reaches an unstaffed mailbox overnight and the duty team lacks local access.

1. The risk should be scored lower because the site is quieter at night
2. Manual safeguards can never reduce cyber consequences
3. The alarm text is too short to count as a safeguard
4. The claimed response depends on unavailable detection, staffing and authority

**Correct option(s):** 4

- Option 1: Reduced activity does not establish timely response capability.
- Option 2: They can contribute when their prerequisites and performance are established.
- Option 3: The stated failure concerns delivery and ability to act, not text length alone.
- Option 4: A safeguard must be feasible in the assessed operating state.

**ISA-EXPERT-Q0054 · single · calculation**

What can be concluded from this sensitivity analysis?

SYNTHETIC ASSESSMENT EVIDENCE: Two credible estimates place residual likelihood in categories 2 and 3. Consequence remains category 4. The approved matrix accepts 2×4 but requires treatment for 3×4.

1. The consequence should be reduced until both estimates pass
2. The lower estimate must be used because it permits operation
3. The arithmetic mean proves category 2.5 is acceptable
4. The decision is sensitive to unresolved likelihood uncertainty and needs explicit treatment or stronger evidence

**Correct option(s):** 4

- Option 1: Changing consequence to fit a decision would undermine the scenario.
- Option 2: Desired outcome is not a basis for choosing uncertainty.
- Option 3: The matrix defines categories and rules, not an automatically valid continuous average.
- Option 4: The plausible range crosses the acceptance boundary.

**ISA-EXPERT-Q0055 · single · diagnosis**

Which common cause is overlooked?

SYNTHETIC ASSESSMENT EVIDENCE: Two cooling controllers are assessed as independent because they have separate CPUs and sensors. Both receive signed logic releases from one compromised engineering repository.

1. The presence of two distinct sensors
2. A shared trusted distribution source can propagate the same harmful application
3. Independent power supplies as a source of logical compromise
4. The use of the same engineering language alone

**Correct option(s):** 2

- Option 1: That is a potential independence feature, not the stated shared cause.
- Option 2: Physical separation does not remove a shared software-authority path.
- Option 3: Separate power does not explain the repository-driven path.
- Option 4: Language similarity does not establish a common failure source.

**ISA-EXPERT-Q0056 · single · design**

Which analysis best handles a low-frequency but severe process scenario?

SYNTHETIC ASSESSMENT EVIDENCE: There is limited site incident history for malicious setpoint changes. A credible access path exists and the possible thermal consequence is significant.

1. Copy another site's likelihood without comparing exposure and controls
2. Assign the maximum category solely because the outcome is severe
3. Assign zero likelihood because no local event has been recorded
4. Document the scenario, assumptions, uncertainty and safeguard evidence without treating no history as impossibility

**Correct option(s):** 4

- Option 1: Transfer requires relevant context and assumptions.
- Option 2: Likelihood and consequence should remain distinct judgments.
- Option 3: Absence of observed incidents is not proof of impossibility.
- Option 4: Sparse history limits estimation rather than eliminating a credible path.

**ISA-EXPERT-Q0057 · single · diagnosis**

Why is CVSS alone insufficient for this prioritization?

SYNTHETIC ASSESSMENT EVIDENCE: A high-scoring flaw affects a disabled optional web service. A lower-scoring flaw permits manipulation of the active engineering channel that can alter cooling logic.

1. The lower score always outranks the higher score in OT
2. Disabled features can never be re-enabled by another change
3. CVSS values are inherently random and should never be considered
4. Site applicability, exposure and consequence differ from generic technical severity

**Correct option(s):** 4

- Option 1: No universal reversal follows; context determines treatment priority.
- Option 2: Configuration assumptions must be maintained and reviewed.
- Option 3: They can provide useful technical input within their scope.
- Option 4: Prioritization needs the actual conditions and process path.

**ISA-EXPERT-Q0058 · single · design**

Which evidence most directly supports the consequence reduction claimed for local autonomy?

SYNTHETIC ASSESSMENT EVIDENCE: The risk treatment assumes local controllers hold required cooling through a thirty-minute supervisory outage.

1. The existence of a UPS on the BMS server
2. A successful ping to the controllers during normal operation
3. Representative tests or justified analysis of required modes, load, alarm coverage and the thirty-minute boundary
4. A generic vendor statement that the product supports standalone mode

**Correct option(s):** 3

- Option 1: Server power continuity does not establish controller autonomy during supervision loss.
- Option 2: Reachability does not establish autonomous process performance.
- Option 3: The autonomy claim depends on more than controller liveness.
- Option 4: Capability is not proof of this configured sequence and operating envelope.

**ISA-EXPERT-Q0059 · single · diagnosis**

What is wrong with this residual-risk calculation?

SYNTHETIC ASSESSMENT EVIDENCE: The team reduces likelihood for network segmentation, then reduces it again for a firewall rule implementing that same segmentation path, treating them as independent safeguards.

1. Segmentation automatically eliminates every non-network path
2. Multiple safeguards can never reduce the same scenario
3. Firewall controls affect consequence only and never likelihood
4. The same treatment effect may be counted twice

**Correct option(s):** 4

- Option 1: Portable media and local authority may remain.
- Option 2: They can, but their interaction and independence must be analyzed.
- Option 3: Their effect depends on the scenario and what they prevent or limit.
- Option 4: Independent credit requires distinct mechanisms and justified dependence assumptions.

**ISA-EXPERT-Q0060 · single · design**

Which scenario should be added after introducing centralized automation?

SYNTHETIC ASSESSMENT EVIDENCE: A configuration service can update every gateway in both halls using one privileged identity and one template.

1. Erroneous or compromised centralized authority propagating a harmful change across the estate
2. Only the service host's local disk failure
3. A separate identical scenario for every gateway name without shared-dependency analysis
4. No new scenario because automation reduces manual errors

**Correct option(s):** 1

- Option 1: Automation changes the reach and common-cause consequence of one action.
- Option 2: That omits its broad change authority.
- Option 3: That obscures the common mechanism and inflates records.
- Option 4: It may reduce some errors while creating different failure paths.

**ISA-EXPERT-Q0061 · single · diagnosis**

Which assumption fails when crediting a backup as a safeguard?

SYNTHETIC ASSESSMENT EVIDENCE: All backups are online and deletable by the same domain administrator whose compromise is the scenario initiating event.

1. Recovery availability is not independent of the compromised authority
2. Backups cannot reduce any incident consequence
3. The backup hardware is necessarily faulty
4. The backup interval is automatically too long

**Correct option(s):** 1

- Option 1: The attacker may affect both production and the credited recovery source.
- Option 2: Trustworthy usable recovery can reduce consequences in appropriate scenarios.
- Option 3: Hardware condition does not resolve the shared administrative path.
- Option 4: The stated defect concerns authority, not necessarily schedule.

**ISA-EXPERT-Q0062 · single · design**

How should a risk workshop handle a disputed fail-safe claim?

SYNTHETIC ASSESSMENT EVIDENCE: The gateway supplier calls communication loss fail-safe. The process engineer says holding the last valve command can be unsafe in one operating mode.

1. Accept the supplier term as a universal physical guarantee
2. Exclude communications loss from cyber analysis because it is an availability issue
3. Force every output off regardless of the process design
4. Translate the label into explicit outputs and mode-dependent process consequences, then verify the required fallback

**Correct option(s):** 4

- Option 1: The supplier may not know every site mode and consequence.
- Option 2: Availability can directly affect physical outcomes.
- Option 3: Off is not universally the safe state.
- Option 4: Safe behaviour is process-specific and cannot be inferred from a label.

**ISA-EXPERT-Q0063 · single · calculation**

Which statement about this expected-loss estimate is defensible?

SYNTHETIC ASSESSMENT EVIDENCE: A model uses a 0.02 annual event probability and a £4 million loss per event, producing £80,000 annual expected loss. The probability range is poorly supported and includes dependent scenarios.

1. The model becomes exact if currency values are rounded
2. £80,000 is a conditional model output, not a precise forecast or complete acceptance basis
3. The calculation proves the site will lose exactly £80,000 each year
4. Any treatment costing over £80,000 is automatically prohibited

**Correct option(s):** 2

- Option 1: Formatting does not improve uncertain assumptions.
- Option 2: Uncertain inputs and dependence limit interpretation.
- Option 3: Expected value is not a deterministic annual outcome.
- Option 4: Risk tolerance, severe outcomes and mandatory requirements also matter.

**ISA-EXPERT-Q0064 · single · diagnosis**

What should change when a treatment introduces a new operational dependency?

SYNTHETIC ASSESSMENT EVIDENCE: Remote MFA reduces unauthorized logins but relies on a single external identity service. No tested emergency route exists for a prolonged outage.

1. Ignore availability because authentication is a security control
2. Reassess access resilience and recovery scenarios alongside the reduced unauthorized-access path
3. Declare the identity service part of the supplier's risk only
4. Remove MFA immediately because all dependencies are unacceptable

**Correct option(s):** 2

- Option 1: Security mechanisms can affect required operational function.
- Option 2: Treatment can reduce one risk while creating or exposing another.
- Option 3: Its failure affects the owner's system and must be accounted for.
- Option 4: A supported resilient design may preserve its benefit.

**ISA-EXPERT-Q0065 · single · design**

Which risk record supports a defensible temporary deferral?

SYNTHETIC ASSESSMENT EVIDENCE: A vulnerable controller cannot be patched until a supported compatible release is tested. The current engineering path can be restricted and monitored.

1. Apply an unsupported update without testing to improve the patch percentage
2. Accept indefinitely because the device is in an OT zone
3. Record applicability, exposure, consequence, bounded compensating measures, owner acceptance and a review trigger
4. Close the vulnerability because a future patch is planned

**Correct option(s):** 3

- Option 1: That may create unacceptable functional or recovery risk.
- Option 2: Zone membership alone does not eliminate all access paths.
- Option 3: The deferral remains a governed treatment decision.
- Option 4: A plan does not remove the current condition.

**ISA-EXPERT-Q0066 · single · diagnosis**

Which evidence challenges the claimed risk reduction most directly?

SYNTHETIC ASSESSMENT EVIDENCE: The treatment depends on removing vendor write access after each session. Logs show established API tokens continue to perform writes after the VPN account is disabled.

1. The VPN account has a strong password
2. Effective authority survives the stated revocation mechanism
3. The vendor uses an encrypted session
4. The account-disable ticket was approved

**Correct option(s):** 2

- Option 1: Password strength does not revoke existing tokens.
- Option 2: The treatment assumption is false for the token path.
- Option 3: Encryption does not limit continued authorized-token operations.
- Option 4: Administrative authorization does not prove technical enforcement.

**ISA-EXPERT-Q0067 · single · design**

What should trigger reassessment of this accepted scenario?

SYNTHETIC ASSESSMENT EVIDENCE: Residual risk was accepted on the assumption that only one hall depended on the shared BMS and that local alarm coverage lasted twenty minutes.

1. Only a change in the risk register's document owner
2. Only a confirmed malicious incident
3. Adding another dependent hall or reducing alarm coverage changes the acceptance assumptions
4. Every routine sensor reading, regardless of relevance

**Correct option(s):** 3

- Option 1: Ownership changes can matter, but the stated technical assumptions are direct triggers.
- Option 2: Risk assumptions can change before an incident occurs.
- Option 3: The review trigger should follow the facts that support the decision.
- Option 4: Triggers should be meaningful and manageable rather than indiscriminate.

#### Recall

**A residual-risk decision passes at likelihood category 2 and fails at category 3. Available evidence supports either category. What should the decision record say?**

The acceptance is sensitive to unresolved likelihood uncertainty. Record both plausible judgments, their basis and the boundary crossed. Obtain stronger discriminating evidence, additional treatment or an explicit authorized decision about the uncertainty; do not silently select category 2.

**In this case, what is the justified integrated decision? An assessment credits independent high-temperature notification from two sensors. Both feed one BMS server, one notification account and an unstaffed overnight mailbox. The claimed manual response is five minutes.**

The two sensing inputs do not establish independent end-to-end response. Server/account failure can defeat both, and overnight staffing makes the five-minute action unsupported. Rebuild the scenario around actual detection and intervention paths, then test or justify alternate coverage and timing before crediting the safeguard.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)
- [ISA public standards-series scope and principal roles](https://www.isa.org/standards-and-publications/isa-standards/isa-iec-62443-series-of-standards)

### ISA-EXPERT-L05 — Keep target, capability and achievement distinct

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L04

Security-level reasoning connects risk-derived requirements, available capabilities and evidence of the integrated result. Keep three concepts separate. SL-T expresses a target for the assessed scope. SL-C concerns capability under a defined product or system scope and assumptions. SL-A concerns what is achieved in the implemented context. These labels must not be used as interchangeable marketing grades. The exact normative treatment and applicable requirements belong to the licensed edition and qualified assessment, not a shortcut invented by this app.

The seven foundational requirement families organize different security properties: identification and authentication control, use control, system integrity, data confidentiality, restricted data flow, timely response to events and resource availability. They are related but not substitutes. Strong authentication does not authorize every action. Encryption does not validate sensor calibration. Log storage does not establish timely response. A firewall cannot preserve resource availability if its configured inspection prevents a required control transaction from meeting its deadline.

A profile can preserve distinctions across requirement families rather than hiding them in an average. Do not average ordinal level entries or product claims into a system pass score. A gateway with a capability assessment can contribute to a legacy system's treatment, but its claim does not automatically transfer to every downstream device. Examine bypasses, local interfaces, management authority, failure behaviour and the actual configuration.

Compensating measures require a defensible system argument. If a controller lacks named authentication, a managed engineering gateway may constrain and attribute remote actions. A local shared port can still bypass it. State the covered path, remaining limitation, supporting procedures and evidence. When achieved evidence falls short of the target, correct and retest or route an explicit residual-risk decision through the owner's process. Silently lowering the target to match an implementation defect breaks the risk-to-design chain.

#### Worked demonstrations

**Keep target, capability and achievement distinct — integrated worked case**

Synthetic teaching case; no live equipment was tested.

A gateway has a scoped capability claim. The site disables logging, uses a shared engineering account and restores an old supplier tunnel after failure. Procurement says the entire site inherits the gateway level.

**Reasoning:** The product evidence can inform capability and selection within its assessed scope. The site's configuration and lifecycle paths require separate evaluation. Disabled logging, shared action attribution and restored excess authority challenge different foundational properties. None is removed by the component label.

#### Guided practice

An observer authenticates with a strong certificate and can write controller setpoints. Which property is missing, and what test isolates it?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** Use control is deficient for the observer role. Establish a valid authenticated session, prove approved reads, then attempt valid prohibited writes at the actual action interfaces. An expired certificate or malformed payload would fail earlier and would not isolate authorization.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Create a seven-family claim table for one zone or conduit. For every family, state the intended property, implementation evidence, lifecycle test and limitation. Keep target, capability input and observed achievement in separate columns.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Evaluate security-level and foundational-requirement claims without transferring product capability to unverified system achievement.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0068 · single · diagnosis**

Which security-level inference is invalid?

SYNTHETIC ASSESSMENT EVIDENCE: A component has a documented capability claim. The integrated site uses shared accounts, disabled logging and untested recovery configurations.

1. The site should assess its integrated configuration against its requirements
2. The risk-derived target remains distinct from observed achievement
3. The component claim automatically establishes the site's achieved security level
4. The capability evidence may inform product selection

**Correct option(s):** 3

- Option 1: That is necessary to establish implementation evidence.
- Option 2: Targets and achieved evidence serve different purposes.
- Option 3: Capability under a defined scope does not prove installed effective behaviour.
- Option 4: It can be relevant when its scope and assumptions match.

**ISA-EXPERT-Q0069 · single · design**

How should a target security-level decision be recorded?

SYNTHETIC ASSESSMENT EVIDENCE: Different zones face different credible adversary capabilities and consequences. Procurement wants one number for every product.

1. Set the target equal to the lowest product currently installed
2. Use the average capability level of all components
3. Assign every product the highest available number and skip scenario analysis
4. Tie the target to the assessed zone or conduit and its requirement basis, preserving relevant distinctions

**Correct option(s):** 4

- Option 1: Existing limitations do not determine acceptable risk requirements.
- Option 2: Averaging ordinal claims does not establish a system target.
- Option 3: Capability purchasing does not replace a risk-derived target or integration design.
- Option 4: A universal procurement label can hide different risks and obligations.

**ISA-EXPERT-Q0070 · single · diagnosis**

What is the problem with this SL statement?

SYNTHETIC ASSESSMENT EVIDENCE: The team says an SL-3-capable gateway makes every downstream legacy controller SL-3, without analyzing controller interfaces, system requirements or compensating measures.

1. A boundary component's capability is being transferred without a justified system argument
2. Any product capability statement is equivalent to asset-owner risk acceptance
3. Legacy components automatically prevent all meaningful risk reduction
4. A gateway can never contribute to system-level protection

**Correct option(s):** 1

- Option 1: Downstream properties require scoped requirements, implementation and evidence.
- Option 2: These are different evidence and decision roles.
- Option 3: System treatments may reduce risk while leaving explicit limitations.
- Option 4: It can provide important controls when properly integrated.

**ISA-EXPERT-Q0071 · single · design**

Which interpretation of a foundational-requirement profile is sound?

SYNTHETIC ASSESSMENT EVIDENCE: An engineering profile records distinct targets for identification/authentication, use control, integrity, confidentiality, restricted flow, event response and resource availability.

1. Use the confidentiality value for every dimension because encryption is strongest
2. Treat the profile as proof that all listed controls are already deployed
3. Treat the entries as distinct requirement dimensions and verify the applicable system measures for each
4. Average the seven values into one pass score

**Correct option(s):** 3

- Option 1: The families address different properties.
- Option 2: A target profile expresses intended requirements, not achieved state.
- Option 3: One strong dimension does not erase a weakness in another.
- Option 4: Averages can conceal unmet requirements and are not a substitute for conformance analysis.

**ISA-EXPERT-Q0072 · single · diagnosis**

Which family is most directly missing from this specific design objective?

SYNTHETIC ASSESSMENT EVIDENCE: Named users authenticate successfully, but every authenticated user can download controller logic regardless of role.

1. Identification and authentication alone
2. Data confidentiality alone
3. Resource availability alone
4. Use control governing permitted actions after authentication

**Correct option(s):** 4

- Option 1: The premise already establishes named authentication; action authority is the gap.
- Option 2: Encrypting the session would not restrict an authenticated user's actions.
- Option 3: Capacity and continuity do not supply role-based permission.
- Option 4: Knowing identity does not establish authorization to modify logic.

**ISA-EXPERT-Q0073 · single · diagnosis**

Which distinction best explains this failure?

SYNTHETIC ASSESSMENT EVIDENCE: Telemetry is confidential and authenticated in transit, but a trusted gateway applies the wrong engineering-unit conversion.

1. Transport protection does not establish correct application transformation or measurement integrity
2. The error proves the transport identity was forged
3. More frequent certificate renewal will correct the scale
4. Confidentiality guarantees the correctness of every numerical value

**Correct option(s):** 1

- Option 1: The trusted endpoint can faithfully encrypt incorrect semantics.
- Option 2: A correctly authenticated gateway can still be misconfigured.
- Option 3: Key lifecycle does not alter the conversion formula.
- Option 4: Secrecy is not semantic correctness.

**ISA-EXPERT-Q0074 · single · design**

What should be verified before claiming restricted data flow is effective?

SYNTHETIC ASSESSMENT EVIDENCE: Zone boundaries are enforced on the routed firewall. A dual-homed maintenance host bridges the same zones outside that path.

1. All credible paths, including the host bridge, must enforce the intended flow restrictions
2. Only the firewall's configured deny rule count
3. Only the routing table on the firewall
4. The host's antivirus status as equivalent segmentation evidence

**Correct option(s):** 1

- Option 1: The diagram's primary boundary is not the only effective route.
- Option 2: Rule count does not reveal bypass traffic.
- Option 3: The bypass may not traverse that device.
- Option 4: Malware protection does not establish cross-zone flow enforcement.

**ISA-EXPERT-Q0075 · single · diagnosis**

Which claim confuses event response with event storage?

SYNTHETIC ASSESSMENT EVIDENCE: Every device sends logs to an archive, but no required event is correlated, routed or reviewed within the defined response time.

1. The owner should assign operational responsibility for the alerts
2. Log collection alone establishes timely response to events
3. The archive may preserve useful investigation evidence
4. The response requirement needs an end-to-end test

**Correct option(s):** 2

- Option 1: A response process needs accountable recipients and authority.
- Option 2: Storage is an input; detection, escalation and action must also work.
- Option 3: That is a valid narrower capability.
- Option 4: Such a test can expose the missing stages.

**ISA-EXPERT-Q0076 · single · design**

How should resource availability requirements influence a hardening design?

SYNTHETIC ASSESSMENT EVIDENCE: A proposed inspection feature increases controller communication latency beyond a required sequence deadline under peak load.

1. Measure idle latency and use it to waive the peak-load failure
2. Disable all monitoring permanently to recover latency
3. Accept the delay because adding security always takes precedence over process timing
4. Evaluate a supported design that meets both protection and timing requirements, with representative tests

**Correct option(s):** 4

- Option 1: The failing required condition remains relevant.
- Option 2: That discards protection without investigating a scoped alternative.
- Option 3: An unqualified security feature can violate essential function.
- Option 4: Availability and performance constraints remain part of the security engineering problem.

**ISA-EXPERT-Q0077 · single · diagnosis**

What is wrong with declaring SL-A equal to SL-T immediately after design approval?

SYNTHETIC ASSESSMENT EVIDENCE: The risk target and proposed architecture are approved, but installation, configuration and acceptance testing have not occurred.

1. Targets cannot be documented until after commissioning
2. Design approval has no assurance value
3. A desired target and planned design do not establish achieved implementation
4. The target must be changed to zero during procurement

**Correct option(s):** 3

- Option 1: Targets guide design and can be established earlier.
- Option 2: It is useful evidence of review, but not deployment or achieved behaviour.
- Option 3: Achievement requires applicable evidence of the effective system.
- Option 4: Lifecycle stage does not automatically redefine the required target.

**ISA-EXPERT-Q0078 · single · design**

Which evidence can support a capability claim without proving site achievement?

SYNTHETIC ASSESSMENT EVIDENCE: A supplier provides a scoped component assessment with version, assumptions and tested functions.

1. Extend it automatically to unsupported firmware releases
2. Treat it as proof that the site's accounts and firewall rules are correct
3. Ignore it because only site tests ever matter
4. Use it as evidence of the assessed component capability and verify integration conditions separately

**Correct option(s):** 4

- Option 1: Version applicability must be established.
- Option 2: Those site states were not necessarily assessed.
- Option 3: Applicable component assurance can inform design and reduce uncertainty.
- Option 4: The scope is useful but narrower than the installed site claim.

**ISA-EXPERT-Q0079 · single · diagnosis**

Which error occurs when security levels are treated as staff seniority?

SYNTHETIC ASSESSMENT EVIDENCE: A manager labels the site SL-4 because four highly experienced engineers support it.

1. The site must therefore have the lowest possible target
2. Experienced staff cannot improve security outcomes
3. An engineering security-level concept is being replaced with a personnel-count claim
4. The certificate programme automatically defines a site's level

**Correct option(s):** 3

- Option 1: The target still requires actual risk analysis.
- Option 2: They can improve outcomes through effective processes and implementation.
- Option 3: Staff competence contributes to operation but is not the same measure.
- Option 4: Personal credentials do not classify an integrated system.

**ISA-EXPERT-Q0080 · single · design**

How should a compensating measure be assessed for a missing native control?

SYNTHETIC ASSESSMENT EVIDENCE: A controller lacks individual authentication. A managed engineering gateway supplies named access and records sessions, but local access bypasses it.

1. Reject any system-level measure merely because it is external to the controller
2. Credit complete individual accountability because one remote path is logged
3. Evaluate coverage, bypasses, failure modes and evidence before crediting the gateway toward the system objective
4. Treat the gateway's administrative login as proof of every controller action's attribution

**Correct option(s):** 3

- Option 1: External controls can contribute when appropriately justified.
- Option 2: The local bypass remains unresolved.
- Option 3: The measure's effectiveness depends on all relevant paths.
- Option 4: Administrative access and action attribution are different evidence.

**ISA-EXPERT-Q0081 · single · diagnosis**

Why is an SL target not a guarantee of physical safety?

SYNTHETIC ASSESSMENT EVIDENCE: A zone is designed toward its stated security requirements, but the cooling sequence has an incorrect fail-to-start timer and an uncalibrated pressure input.

1. A higher SL automatically corrects every application logic defect
2. The timer and calibration are irrelevant because they are not malware
3. Security requirements do not replace process design, functional verification and physical safety disciplines
4. All security work should stop until every process uncertainty disappears

**Correct option(s):** 3

- Option 1: The level does not rewrite the sequence.
- Option 2: They can affect required function and consequence.
- Option 3: Cybersecurity and control correctness interact but are not interchangeable.
- Option 4: The disciplines can progress together with explicit dependencies and limits.

**ISA-EXPERT-Q0082 · single · design**

Which review best prevents an overstated system security claim?

SYNTHETIC ASSESSMENT EVIDENCE: The report lists one scalar achieved level but omits untested families, component assumptions and maintenance states.

1. Increase the scalar value to account for planned future controls
2. Report only the lowest tested family value without documenting scope or excluded lifecycle states
3. Require the scope, applicable requirements, evidence, exclusions and unresolved gaps behind the claim
4. Remove every limitation from the executive summary

**Correct option(s):** 3

- Option 1: Plans do not increase current achievement.
- Option 2: A scalar summary still needs the underlying applicable requirements and evidence boundaries.
- Option 3: A concise label needs a defensible underlying assessment.
- Option 4: That would make the claim less accurate.

**ISA-EXPERT-Q0083 · single · diagnosis**

Which foundational-property tradeoff needs explicit treatment?

SYNTHETIC ASSESSMENT EVIDENCE: Logs are encrypted and tightly restricted. During an incident, no authorized responder can retrieve them within the response objective.

1. Encryption proves the response requirement is met
2. Confidentiality controls are obstructing required evidence availability and response
3. Responders should permanently share one administrator password
4. The only solution is public unauthenticated log access

**Correct option(s):** 2

- Option 1: Protection of stored data does not establish accessible evidence.
- Option 2: The design must permit controlled timely access while protecting the records.
- Option 3: A broad shared secret creates a different authority defect.
- Option 4: That would abandon confidentiality unnecessarily.

**ISA-EXPERT-Q0084 · single · design**

What should happen when achieved evidence falls short of a risk-derived target?

SYNTHETIC ASSESSMENT EVIDENCE: Site tests confirm most required controls, but the restored-image path revives prohibited supplier access.

1. Correct and retest the gap or obtain an explicit justified residual-risk decision under the owner's process
2. Average the passing tests with the failed one to claim conformance
3. Ignore recovery because normal operation passed
4. Lower the target silently until the report passes

**Correct option(s):** 1

- Option 1: The mismatch must remain visible and governed.
- Option 2: An average does not remove a required-control failure.
- Option 3: The lifecycle path can reintroduce the same exposure.
- Option 4: That changes the requirement to fit a defect.

#### Recall

**An observer authenticates with a strong certificate and can write controller setpoints. Which property is missing, and what test isolates it?**

Use control is deficient for the observer role. Establish a valid authenticated session, prove approved reads, then attempt valid prohibited writes at the actual action interfaces. An expired certificate or malformed payload would fail earlier and would not isolate authorization.

**In this case, what is the justified integrated decision? A gateway has a scoped capability claim. The site disables logging, uses a shared engineering account and restores an old supplier tunnel after failure. Procurement says the entire site inherits the gateway level.**

The product evidence can inform capability and selection within its assessed scope. The site's configuration and lifecycle paths require separate evaluation. Disabled logging, shared action attribution and restored excess authority challenge different foundational properties. None is removed by the component label.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)
- [ISA public standards-series scope and principal roles](https://www.isa.org/standards-and-publications/isa-standards/isa-iec-62443-series-of-standards)

### ISA-EXPERT-L06 — Translate treatment into a living CRS

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L05

A cybersecurity requirements specification should make the treatment executable. Start with the scenario and the required outcome, then identify identities, assets, operations, modes, performance limits, enforcement points, evidence and ownership. “Secure vendor access” is not enough. A requirement might permit named read-only diagnostics to one gateway during an approved window, deny programming, end both new and established authority at expiry, and preserve an independently controlled emergency path.

Trace requirement IDs to design mechanisms and tests, but do not confuse a link with proof. A firewall rule can be linked to the right requirement while matching the wrong post-NAT source. A negative test can be linked to authorization while actually failing because the server is offline. Review the semantic chain: does this implementation act on the scenario's real path, and does this test discriminate the required property from alternative causes?

Distinguish verification and validation. Verification checks the specified requirement. Validation asks whether the requirement and solution meet the intended operational need. A gateway can satisfy a five-second poll interval while omitting quality indication that operators need to detect stale data. The interval test may be correct and the requirement set still incomplete. Feed that discovery back into the risk and design basis.

Maintain the trace through change. A new API that combines formerly separate roles, an additional hall using a shared service, a changed sensor range or a different recovery image can invalidate assumptions. Accepted limitations need scope, owner, conditions and review triggers. Expiry is not a technical disappearance of risk; it is a boundary on the prior decision. A complete trace therefore includes sustaining checks and a recovery retest, not only the first commissioning result.

#### Worked demonstrations

**Translate treatment into a living CRS — integrated worked case**

Synthetic teaching case; no live equipment was tested.

Risk R12 concerns a collector changing logic. Requirement C9 says the collector must be read-only. The test sends an invalid programming payload to an offline controller and records a pass because no change occurs.

**Reasoning:** The test does not isolate C9. Both offline state and invalid syntax can prevent the change regardless of authorization. Use an authorized representative target, verify a permitted read, and issue a valid prohibited programming operation through the effective path. Record the enforcement result and relevant alternate interfaces.

#### Guided practice

A manual-response requirement specifies two minutes, but a realistic exercise shows qualified staff need six minutes to reach the equipment. How should the CRS change?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** First revisit the consequence model and treatment feasibility. A faster independent mechanism, different staffing or another design may be needed. Any revised timing needs owner-approved risk justification. Do not simply change the expected result to match the six-minute observation and call the original requirement satisfied.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Write a trace for four requirements including one functional timing constraint, one denied action, one maintenance dependency and one restoration property. For each, design a test that rules out a misleading accidental pass.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Build a risk-to-requirement-to-test trace and maintain it when assumptions, interfaces or operating conditions change.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0085 · single · design**

Which CRS entry best connects risk to implementation?

SYNTHETIC ASSESSMENT EVIDENCE: Scenario R12 permits a collector credential to alter cooling logic. Treatment requires collection to remain available while programming is denied.

1. Require a specific firewall model without defining its policy
2. Require secure communications without identifying operations
3. Require all collector traffic to be dropped
4. Define the collector identity, permitted reads, denied programming, enforcing interfaces and positive/negative tests

**Correct option(s):** 4

- Option 1: A product name does not establish the intended behaviour.
- Option 2: That leaves the relevant authority ambiguous.
- Option 3: That treats the attack path by violating required service.
- Option 4: The requirement directly addresses the scenario while preserving function.

**ISA-EXPERT-Q0086 · single · diagnosis**

What is missing from this treatment trace?

SYNTHETIC ASSESSMENT EVIDENCE: Risk R7 leads to requirement C9. A firewall rule is installed, but its tested destination differs from the actual controller address after NAT.

1. Evidence that the implemented and tested rule controls the real scenario path
2. Proof that NAT is always insecure
3. An automatic waiver because the rule syntax is valid
4. A larger list of unrelated requirements

**Correct option(s):** 1

- Option 1: Traceability must follow effective addressing and enforcement.
- Option 2: Translation can be used securely when its effects are understood.
- Option 3: Syntax does not establish scenario coverage.
- Option 4: Quantity does not repair the specific path mismatch.

**ISA-EXPERT-Q0087 · single · design**

How should uncertainty be represented in an acceptance recommendation?

SYNTHETIC ASSESSMENT EVIDENCE: The design passes all tested paths, but the team cannot safely inspect an old local maintenance interface before the scheduled outage.

1. Declare the path absent because no traffic was observed
2. Omit the issue because it would delay approval
3. State the unverified path, potential consequence, temporary treatment and required future verification
4. Treat the entire design as conclusively compromised

**Correct option(s):** 3

- Option 1: Unobserved does not mean nonexistent, especially for intermittent maintenance.
- Option 2: Schedule pressure does not improve the evidence.
- Option 3: The decision-maker needs the unresolved boundary and a controlled plan.
- Option 4: The uncertainty does not establish actual compromise.

**ISA-EXPERT-Q0088 · single · diagnosis**

Which requirement conflict must be resolved?

SYNTHETIC ASSESSMENT EVIDENCE: The CRS demands immediate revocation of every supplier session. The selected platform's tokens remain valid until expiry, and the proposed procedure disables only new logins.

1. Token expiry is always equivalent to immediate revocation
2. The requirement is met because the account database updates immediately
3. The implementation does not meet the stated effective-revocation behaviour
4. The platform's published limitation eliminates the owner's requirement

**Correct option(s):** 3

- Option 1: The permitted interval matters.
- Option 2: Database state is not the same as terminating existing authority.
- Option 3: The difference requires design treatment or a justified requirement/risk decision.
- Option 4: A limitation informs feasibility but does not silently change risk needs.

**ISA-EXPERT-Q0089 · single · design**

Which test design best validates a treatment against a command-replay scenario?

SYNTHETIC ASSESSMENT EVIDENCE: A broker can redeliver an old command after reconnect. The design adds command IDs and freshness checks.

1. Inject duplicate and expired commands across reconnect and verify one permitted execution or rejection as specified
2. Verify that TLS connects using a valid certificate
3. Disable reconnect during testing
4. Count delivered messages without observing application execution

**Correct option(s):** 1

- Option 1: The test exercises the actual replay conditions and physical/action semantics.
- Option 2: That tests transport identity, not command age or idempotency.
- Option 3: That removes the condition the treatment is meant to handle.
- Option 4: Delivery count does not establish repeated physical action.

**ISA-EXPERT-Q0090 · single · diagnosis**

What is wrong with this residual-risk acceptance?

SYNTHETIC ASSESSMENT EVIDENCE: An integrator signs that risk is accepted on behalf of the owner, but its contract authorizes implementation only and no delegated acceptance authority exists.

1. A strong digital signature creates the missing governance authority
2. The technical assessment must therefore contain no useful evidence
3. The signatory lacks the stated decision authority
4. Only a product supplier may accept residual risk

**Correct option(s):** 3

- Option 1: It authenticates a signature but does not confer decision rights.
- Option 2: Its evidence can remain useful despite the approval defect.
- Option 3: A technical implementer cannot invent delegation to accept owner risk.
- Option 4: The asset-owner governance process determines the accountable acceptance role.

**ISA-EXPERT-Q0091 · single · design**

Which change needs a risk-to-requirement impact review?

SYNTHETIC ASSESSMENT EVIDENCE: A gateway update combines telemetry reads and engineering writes into one new API identity, replacing two previously separated identities.

1. Only update the API documentation because the IP address is unchanged
2. Accept automatically because the update is signed
3. Re-run only a throughput benchmark
4. Review the authority separation requirement, attack paths, enforcement and affected tests

**Correct option(s):** 4

- Option 1: Address stability does not preserve authority semantics.
- Option 2: Origin assurance does not establish suitability.
- Option 3: Capacity does not prove the required permission separation.
- Option 4: The change alters the basis of the existing treatment.

**ISA-EXPERT-Q0092 · single · diagnosis**

Which weakness does this risk metric hide?

SYNTHETIC ASSESSMENT EVIDENCE: A programme reports that 98% of controls passed. The failed 2% include the sole backup's deletion protection and the only remote engineering boundary.

1. The aggregate obscures high-consequence unmet requirements and dependencies
2. Every aggregate metric is inherently useless
3. The percentage proves the failures are statistically insignificant
4. The two failures can be accepted because most controls work

**Correct option(s):** 1

- Option 1: Pass percentage does not weight or resolve critical failure paths.
- Option 2: Aggregates can help when their scope and limitations are clear.
- Option 3: Control counts are not a probability model of consequence.
- Option 4: Other controls do not automatically compensate for these paths.

**ISA-EXPERT-Q0093 · single · design**

How should a requirement be revised when testing exposes an unrealistic response time?

SYNTHETIC ASSESSMENT EVIDENCE: The original target requires a manual local action within two minutes. Authorized staff need at least six minutes to reach the equipment under realistic conditions.

1. Reassess the consequence model and treatment design, then approve a feasible requirement or add a faster protective mechanism
2. Change the report's measured time to two minutes
3. Keep the requirement unchanged and call the exercise a pass
4. Remove timing from all future tests

**Correct option(s):** 1

- Option 1: The failed assumption must be addressed through engineering and owner decision.
- Option 2: That would fabricate evidence.
- Option 3: A retained requirement still needs satisfaction.
- Option 4: That hides the condition driving the risk.

**ISA-EXPERT-Q0094 · single · diagnosis**

What distinguishes requirement verification from validating intended use here?

SYNTHETIC ASSESSMENT EVIDENCE: A gateway meets the specified five-second polling interval. Operators still cannot identify a dangerous stale-value condition because the requirement omitted quality indication.

1. The interval measurement must be false because operators are dissatisfied
2. A passing interval test proves all intended use is satisfied
3. Operational validation is unrelated to cybersecurity
4. The implemented interval may verify correctly while the intended operational need remains unmet

**Correct option(s):** 4

- Option 1: The measurement can be correct while the requirement set is incomplete.
- Option 2: It covers only the specified timing property.
- Option 3: Stale or misleading evidence can affect security decisions and process consequences.
- Option 4: Validation questions whether the requirements and solution serve the actual use.

**ISA-EXPERT-Q0095 · single · design**

Which evidence should support a decision to retire a risk scenario?

SYNTHETIC ASSESSMENT EVIDENCE: A legacy remote modem is removed, its account revoked and the maintenance procedure replaced by an approved broker path.

1. Verify physical removal, remaining alternate paths, effective credential closure and the replacement path's risk treatment
2. Delete the scenario when the removal purchase order is approved
3. Retire it because the modem no longer answers one ping
4. Leave all associated credentials active for convenience

**Correct option(s):** 1

- Option 1: Retirement should follow actual elimination or transformation of the scenario.
- Option 2: Approval is not completed removal.
- Option 3: The observation may not cover its medium or authority.
- Option 4: That can preserve another route to the original consequence.

**ISA-EXPERT-Q0096 · single · diagnosis**

Why does this evidence not establish treatment independence?

SYNTHETIC ASSESSMENT EVIDENCE: Two access controls are administered by the same unrestricted account. The assessment credits one surviving compromise of the other.

1. Different configuration filenames establish separation
2. The controls must use different vendors to be independent in every respect
3. Compromise of their shared administrative authority may alter both
4. Two controls can never form defense in depth

**Correct option(s):** 3

- Option 1: File names do not constrain administrative reach.
- Option 2: Vendor diversity alone does not remove shared authority.
- Option 3: The independence assumption must include management, not just data paths.
- Option 4: They can, but common dependencies must be accounted for.

**ISA-EXPERT-Q0097 · single · design**

Which review question best tests whether a treatment is sustainable?

SYNTHETIC ASSESSMENT EVIDENCE: A narrow manual rule review prevents excess engineering access today, but it relies on one specialist and has no handover or automation support.

1. Can the required review and effective closure continue through staffing changes, outages and recovery?
2. Can the review be skipped when work is urgent?
3. Does the specialist currently know the firewall command syntax?
4. Will a higher target level automatically provide another reviewer?

**Correct option(s):** 1

- Option 1: Lifecycle feasibility is part of treatment effectiveness.
- Option 2: Urgency needs a governed exception, not silent removal of the control.
- Option 3: That is useful but does not address the continuity dependency.
- Option 4: Targets do not supply resources or operating capability.

**ISA-EXPERT-Q0098 · single · diagnosis**

Which interpretation of a risk acceptance expiry is correct?

SYNTHETIC ASSESSMENT EVIDENCE: The owner approved a legacy exposure until replacement on 30 September. The replacement is delayed, and no new decision has been recorded.

1. The risk becomes technically impossible at the expiry date
2. The original acceptance remains permanent because the device is unchanged
3. The prior bounded acceptance does not automatically extend; the current condition needs authorized reassessment
4. Operations must improvise any replacement immediately regardless of process risk

**Correct option(s):** 3

- Option 1: An administrative date does not alter the vulnerability.
- Option 2: The explicit time boundary still matters.
- Option 3: Expiry is part of the decision's scope.
- Option 4: The next action requires a controlled feasible decision.

**ISA-EXPERT-Q0099 · single · design**

Which traceability record is strongest for an integrated capstone?

SYNTHETIC ASSESSMENT EVIDENCE: The learner must show how an unauthorized logic-change scenario was treated and sustained.

1. Provide a passing quiz score and a network diagram
2. Link scenario assumptions, target requirements, implemented controls, tests, operational checks and a recovery retest
3. List the standard part numbers without showing the implementation
4. Show a firewall screenshot with no target or test context

**Correct option(s):** 2

- Option 1: These are narrower knowledge and design artifacts.
- Option 2: This follows the same risk through the full lifecycle.
- Option 3: References alone do not establish behaviour.
- Option 4: The image cannot establish effective scenario treatment.

**ISA-EXPERT-Q0100 · single · diagnosis**

Which conclusion best handles two apparently conflicting assessment results?

SYNTHETIC ASSESSMENT EVIDENCE: One report finds low residual risk under a restricted local-only operating mode. Another finds unacceptable risk when remote vendor access is enabled.

1. The reports may assess different states; compare assumptions, paths and required controls before reconciling them
2. Average the risk ratings to obtain a site-wide answer
3. Choose the newer document without checking its scope
4. Reject both because valid assessments must always produce one invariant score

**Correct option(s):** 1

- Option 1: Risk conclusions are conditional on the defined operating context.
- Option 2: That can hide an unacceptable permitted mode.
- Option 3: Recency alone does not resolve state differences.
- Option 4: Different operating states can legitimately produce different results.

#### Recall

**A manual-response requirement specifies two minutes, but a realistic exercise shows qualified staff need six minutes to reach the equipment. How should the CRS change?**

First revisit the consequence model and treatment feasibility. A faster independent mechanism, different staffing or another design may be needed. Any revised timing needs owner-approved risk justification. Do not simply change the expected result to match the six-minute observation and call the original requirement satisfied.

**In this case, what is the justified integrated decision? Risk R12 concerns a collector changing logic. Requirement C9 says the collector must be read-only. The test sends an invalid programming payload to an offline controller and records a pass because no change occurs.**

The test does not isolate C9. Both offline state and invalid syntax can prevent the change regardless of authorization. Use an authorized representative target, verify a permitted read, and issue a valid prohibited programming operation through the effective path. Record the enforcement result and relevant alternate interfaces.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)
- [ISA public standards-series scope and principal roles](https://www.isa.org/standards-and-publications/isa-standards/isa-iec-62443-series-of-standards)

## ISA-EXPERT-M03 — Zones, conduits and controlled engineering access

### ISA-EXPERT-L07 — Engineer zones from authority and function

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L06

A zone groups assets with sufficiently common security requirements for the stated design. It is not automatically one vendor, one subnet or one cabinet. A collector that reads values and an engineering station that downloads logic have different authority even when they use the same protocol. A conduit represents the required communications and protection between zones. Its definition should identify source and destination roles, initiating direction, application operations, identity, supporting dependencies and lifecycle conditions.

Translate the flow matrix into actual enforcement semantics. A transport permit may expose several application operations. A Modbus service carrying reads can also expose writes unless the design enforces the required restriction at a suitable point. An OPC UA secure channel does not by itself prove the user cannot invoke a method. Follow the operation to the component that authorizes it. If a gateway translates an authenticated upstream request into an unauthenticated downstream protocol, that gateway becomes an important authority and evidence boundary.

Inspect every credible route. A dual-homed workstation, maintenance modem, BMC network, portable engineering workflow or recovery connection can bypass the prominent firewall. Separate management authority from data-plane rules: an unrestricted automation credential can change all boundaries even if today's ACLs are narrow. NAT, proxies and brokers can alter the source identity observed by enforcement and logging; tests must use the effective representation.

Supporting flows are part of the design. Time, naming, identity, certificate renewal, logging, backup and update services can be essential to continued operation. Document their required scope rather than solving each failure with any-to-any access. A well-designed boundary preserves required function and denies unnecessary authority in normal, degraded, maintenance and restored states.

#### Worked demonstrations

**Engineer zones from authority and function — integrated worked case**

Synthetic teaching case; no live equipment was tested.

A collector and engineering station share a subnet. The first firewall rule permits the collector to the PLC service; a later rule denies the same flow. Both reads and programming use the permitted service. A maintenance host also bridges the zones.

**Reasoning:** The later deny is shadowed under first-match processing. Even a corrected port rule may not separate reads from programming, and the host bridge is an alternate path. The design must assign the differing roles, enforce operations at a suitable point, remove or govern unnecessary forwarding, and test all effective paths.

#### Guided practice

Write a flow entry for a historian that subscribes to selected nodes, sends logs to one collector and must never invoke control methods.

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** List historian identity and target gateway, approved subscription/node scope, required trust/time dependencies and log destination. Deny methods, writes and unrelated destinations. Validate permitted collection and logging plus prohibited operations using the same effective identity and interfaces.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Build and review a flow matrix containing normal data, engineering, time, renewal, backup and emergency paths. Include one address translation and one alternate management interface, then design tests against the actual enforcement view.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Derive zone and conduit requirements from effective application authority, supporting services and alternate paths.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0101 · single · design**

Which zone grouping best fits these requirements?

SYNTHETIC ASSESSMENT EVIDENCE: Collectors need read-only access to process values. Engineering stations can modify logic under approval. Both use the same vendor software family and currently share a subnet.

1. Place collectors in the engineering zone because they require frequent access
2. Put every device in a unique zone without analyzing required exchanges
3. Separate the differing authority requirements and define their permitted conduits
4. Keep one zone solely because the software vendor is identical, then rely on operator care

**Correct option(s):** 3

- Option 1: Frequency does not justify programming authority.
- Option 2: Granularity alone does not create a justified or maintainable architecture.
- Option 3: Vendor similarity does not make read-only collection and engineering modification equivalent trust functions.
- Option 4: The grouping ignores materially different security requirements.

**ISA-EXPERT-Q0102 · single · diagnosis**

Which first-match policy defect permits the prohibited path?

SYNTHETIC ASSESSMENT EVIDENCE: Rule 10 permits collector C to controller P on TCP 502. Rule 20 denies C to P on TCP 502. The gateway allows programming operations through that service.

1. The collector cannot reach P because two contradictory rules cancel out
2. The port number itself guarantees read-only telemetry
3. The deny works because more restrictive rules always override permits
4. The earlier permit shadows the later deny, and the permitted service lacks operation restriction

**Correct option(s):** 4

- Option 1: First-match processing does not average or cancel rules.
- Option 2: A transport service can carry both permitted and prohibited operations.
- Option 3: The stated policy uses first-match semantics.
- Option 4: Both rule order and application authority matter.

**ISA-EXPERT-Q0103 · single · design**

Which flow-matrix entry is sufficiently precise for this integration?

SYNTHETIC ASSESSMENT EVIDENCE: A historian subscribes to selected OPC UA nodes through a gateway. It must not invoke methods or modify configuration.

1. Historian identity → gateway service: approved subscriptions/nodes; methods and writes denied; certificate and freshness dependencies recorded
2. Historian → gateway: encrypted traffic only, with all authenticated operations permitted
3. Historian subnet → any OT address: TCP allowed
4. Gateway → historian: all services because return traffic is needed

**Correct option(s):** 1

- Option 1: The entry describes the application authority and operational dependencies.
- Option 2: Encryption does not satisfy the read-only requirement.
- Option 3: That exceeds the stated target and operation scope.
- Option 4: Return state does not justify arbitrary independently initiated services.

**ISA-EXPERT-Q0104 · single · diagnosis**

Why does this VLAN design not establish the intended zone boundary?

SYNTHETIC ASSESSMENT EVIDENCE: Control and office hosts use different VLANs. A router permits unrestricted traffic between them and shared administrators can reconfigure both.

1. Logical separation exists, but required cross-boundary restrictions and management controls are absent
2. VLANs can never support a secure architecture
3. Different IP subnets automatically deny all communications
4. A broadcast boundary provides complete application authorization

**Correct option(s):** 1

- Option 1: VLAN membership alone does not define effective security policy.
- Option 2: They can contribute when routing, policy and management are properly controlled.
- Option 3: A router can connect them as described.
- Option 4: Application actions require additional controls.

**ISA-EXPERT-Q0105 · single · design**

How should a shared time service be represented in zone requirements?

SYNTHETIC ASSESSMENT EVIDENCE: Controllers and log collectors depend on a time source in a management zone. Segmentation initially blocks it.

1. Permit all management-zone traffic because time is essential
2. Define the approved time paths, source trust, failure behaviour and monitoring as explicit dependencies
3. Leave time blocked and discard every timestamped record
4. Move every controller into the time-server zone

**Correct option(s):** 2

- Option 1: One dependency does not justify unrestricted flows.
- Option 2: Supporting services must be included without opening unrelated access.
- Option 3: That fails the operational need rather than engineering the dependency.
- Option 4: Dependency does not require merging unlike security requirements.

**ISA-EXPERT-Q0106 · single · diagnosis**

What does this firewall test actually prove?

SYNTHETIC ASSESSMENT EVIDENCE: The team tests denied access from engineering address 10.8.1.20. Production traffic is source-NATed to 172.20.1.5 before the enforcement point.

1. NAT eliminates the need for source authorization
2. The production path is denied because the original host is the same
3. The test proves all engineering operations are blocked at the controller
4. Only the tested source representation was denied

**Correct option(s):** 4

- Option 1: Translation is not authorization.
- Option 2: The enforcement device may see a different source identity.
- Option 3: It does not establish application or alternate-path behaviour.
- Option 4: The real translated path needs its own applicable test.

**ISA-EXPERT-Q0107 · single · design**

Which treatment best addresses a dual-homed collector bypass?

SYNTHETIC ASSESSMENT EVIDENCE: The collector has one interface in the supervisory zone and one in the controller zone. IP forwarding is enabled although no forwarding function is required.

1. Disable and verify unnecessary forwarding, constrain host authority and reassess the required interface design
2. Document both interfaces and accept forwarding as an automatic collection requirement
3. Trust the host because antivirus is installed
4. Add a deny rule only on a firewall the bypass does not traverse

**Correct option(s):** 1

- Option 1: The host must not become an ungoverned conduit.
- Option 2: Collection does not necessarily require routing between zones.
- Option 3: Endpoint malware controls do not define permitted routing.
- Option 4: That cannot enforce the observed alternate path.

**ISA-EXPERT-Q0108 · single · diagnosis**

Which conclusion follows from a successful connection but denied method call?

SYNTHETIC ASSESSMENT EVIDENCE: TCP and TLS establish. The server returns an authorization denial for a write method requested by a telemetry account.

1. The server certificate is necessarily invalid
2. The path and session work; the requested operation violates application authorization
3. The firewall must allow more destination ports to authorize the method
4. The method should be allowed because the account authenticated

**Correct option(s):** 2

- Option 1: TLS establishment and the explicit method denial suggest a different layer.
- Option 2: The diagnosis should focus on intended client action and role, not broad connectivity.
- Option 3: Transport expansion does not grant the application's role permission.
- Option 4: Authentication does not approve every operation.

**ISA-EXPERT-Q0109 · single · design**

Which requirement limits a historian's lateral movement without breaking collection?

SYNTHETIC ASSESSMENT EVIDENCE: It must read six gateways and send logs to one collector. It has no required access to controller programming interfaces or other historians.

1. Restrict by business hours while leaving every destination reachable
2. Permit all traffic from the historian but block inbound sessions only
3. Permit the entire OT address range because all six gateways are inside it
4. Permit the explicit required transactions and deny unrelated destinations and operations

**Correct option(s):** 4

- Option 1: Time limits do not define the required destination and operation set.
- Option 2: Outbound authority can still enable lateral movement.
- Option 3: That broadens reach beyond the requirement.
- Option 4: The policy follows documented function and authority.

**ISA-EXPERT-Q0110 · single · diagnosis**

Which evidence challenges a claimed unidirectional architecture?

SYNTHETIC ASSESSMENT EVIDENCE: A telemetry appliance sends data outward. Its management interface accepts inbound remote shell sessions from the same enterprise network.

1. The management path is irrelevant because it carries no telemetry
2. The data path may be one-way while management creates a separate inbound authority path
3. Encryption of the shell makes the overall architecture unidirectional
4. Any outward data transfer proves a bidirectional physical channel

**Correct option(s):** 2

- Option 1: It can alter the appliance and influence the protected function.
- Option 2: The architecture claim must include all relevant interfaces.
- Option 3: Encryption does not change traffic direction or authority.
- Option 4: That does not follow from the premise.

**ISA-EXPERT-Q0111 · single · design**

Which zone decision handles an engineering workstation shared across two systems?

SYNTHETIC ASSESSMENT EVIDENCE: The workstation can change both cooling and EPMS gateway configurations. The systems have different owners and consequence models.

1. Require both systems to adopt identical risk criteria automatically
2. Model the shared engineering authority and constrain or separate its access according to both systems' requirements
3. Duplicate its name in two inventories and assume independence
4. Assign it to whichever subnet it uses most often and ignore its other access

**Correct option(s):** 2

- Option 1: Shared access does not erase their different operational contexts.
- Option 2: The workstation links trust domains and must be treated explicitly.
- Option 3: One compromised host can still affect both systems.
- Option 4: Usage frequency does not remove the second authority path.

**ISA-EXPERT-Q0112 · single · diagnosis**

Why is this conduit inventory incomplete?

SYNTHETIC ASSESSMENT EVIDENCE: It records BMS-to-controller telemetry but omits firmware transfers, certificate renewal, backups and vendor maintenance sessions.

1. The omitted flows are harmless because they are administrative
2. Only continuously active flows belong in a conduit inventory
3. The inventory can be replaced by a list of physical cables
4. It covers steady-state data but not lifecycle communications

**Correct option(s):** 4

- Option 1: Administrative paths can be highly privileged.
- Option 2: Intermittent but required exchanges still affect security.
- Option 3: Cables do not express applications, identities or permitted operations.
- Option 4: Unmodeled support paths can break maintenance or create unmanaged authority.

**ISA-EXPERT-Q0113 · single · design**

Which policy evidence is needed when an industrial gateway translates protocols?

SYNTHETIC ASSESSMENT EVIDENCE: An upstream authenticated client becomes an unauthenticated downstream Modbus request. The gateway serves both reads and writes.

1. Evaluate only the gateway's IP routing table
2. Allow all writes because the upstream link is encrypted
3. Assume downstream devices inherit the upstream certificate identity automatically
4. Verify upstream role-to-operation enforcement and downstream target/address mapping

**Correct option(s):** 4

- Option 1: Application transformation and authorization need separate evidence.
- Option 2: Confidentiality does not justify every translated operation.
- Option 3: The translated protocol path may not carry that identity.
- Option 4: Translation can concentrate authority at the gateway and lose upstream identity downstream.

**ISA-EXPERT-Q0114 · single · diagnosis**

Which requirement is violated by this rule optimization?

SYNTHETIC ASSESSMENT EVIDENCE: An administrator merges three narrow approved permits into a subnet-wide any-service permit to reduce rule count. Required transactions still pass.

1. Every rule merge is prohibited regardless of semantic equivalence
2. The effective authority boundary expanded beyond the approved flow set
3. The change necessarily reduces availability
4. No requirement is violated because fewer rules are easier to review

**Correct option(s):** 2

- Option 1: A merge can be valid if it preserves the exact required policy.
- Option 2: Passing required flows does not prove prohibited flows remain denied.
- Option 3: Availability may remain healthy while security scope worsens.
- Option 4: Maintainability does not justify unapproved access expansion.

**ISA-EXPERT-Q0115 · single · design**

What should a segmentation acceptance test include for a multicast-dependent service?

SYNTHETIC ASSESSMENT EVIDENCE: A control integration relies on approved multicast within a defined boundary. Ordinary unicast ping tests pass after a switch change.

1. Permit multicast across every zone to avoid discovery problems
2. Representative multicast delivery, containment and relevant failure behaviour under the actual topology
3. Disable the service's group management features without supported analysis
4. Only larger unicast pings

**Correct option(s):** 2

- Option 1: That abandons the stated boundary.
- Option 2: Unicast reachability does not establish multicast forwarding or restriction.
- Option 3: Unsupported changes can break the required protocol behaviour.
- Option 4: Packet size does not test group membership and multicast policy.

**ISA-EXPERT-Q0116 · single · diagnosis**

What is the key risk in this management-plane arrangement?

SYNTHETIC ASSESSMENT EVIDENCE: Data-plane ACLs separate zones, but one shared automation credential can alter routing and policy on every boundary device.

1. A stronger encryption algorithm alone removes the shared privilege
2. The shared management authority can defeat the enforced boundaries
3. Data-plane ACLs become useless in every circumstance
4. Separate rack locations make the shared credential independent

**Correct option(s):** 2

- Option 1: Encryption does not limit authorized configuration reach.
- Option 2: Segmentation assurance includes who can change the controls.
- Option 3: They still enforce their current policy against actors without that authority.
- Option 4: Physical placement does not change its authority.

**ISA-EXPERT-Q0117 · single · design**

Which review prevents a flow matrix from becoming stale after migration?

SYNTHETIC ASSESSMENT EVIDENCE: A gateway moves behind a proxy that changes source addresses and terminates client authentication.

1. Update effective identities, address transformations, trust termination and operation enforcement, then retest
2. Keep the old tests because the destination application is unchanged
3. Change only the gateway's display name in the inventory
4. Treat proxy authentication as proof of downstream least privilege

**Correct option(s):** 1

- Option 1: The logical transaction now crosses different enforcement and trust points.
- Option 2: The route and identity processing have materially changed.
- Option 3: That omits the changed security semantics.
- Option 4: The downstream operation mapping still needs verification.

#### Recall

**Write a flow entry for a historian that subscribes to selected nodes, sends logs to one collector and must never invoke control methods.**

List historian identity and target gateway, approved subscription/node scope, required trust/time dependencies and log destination. Deny methods, writes and unrelated destinations. Validate permitted collection and logging plus prohibited operations using the same effective identity and interfaces.

**In this case, what is the justified integrated decision? A collector and engineering station share a subnet. The first firewall rule permits the collector to the PLC service; a later rule denies the same flow. Both reads and programming use the permitted service. A maintenance host also bridges the zones.**

The later deny is shadowed under first-match processing. Even a corrected port rule may not separate reads from programming, and the host bridge is an alternate path. The design must assign the differing roles, enforce operations at a suitable point, remove or govern unnecessary forwarding, and test all effective paths.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)

### ISA-EXPERT-L08 — Constrain remote and emergency engineering

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L07

Remote support is an operational workflow, not merely a VPN feature. Define who is admitted, which target and task are approved, which operations are possible, how the session is observed, when it ends and how exceptions are controlled. MFA strengthens an authentication step; it does not approve the chosen project, target or engineering action. A valid supplier identity can still act outside a read-only work order.

Brokers and jump hosts can centralize control but also transform identity. A supplier may authenticate individually at the broker while the controller sees one service account. Preserve a reliable linkage between upstream actor, approved task, downstream target and actual operations. Interactive screen recording does not cover an independent API path unless the architecture routes and records that path appropriately. A read-only user interface is not a read-only token.

Treat revocation as a set of effective authority changes. Passwords, certificates, SSH keys, bearer tokens, local accounts and established sessions can have different lifetimes. Disabling a directory login may leave a valid token or stateful connection. Test expiry and closure using new authentication and already established operations on relevant interfaces. The required semantics must be supported by the chosen platforms; if immediate termination is unavailable, address the gap explicitly.

Emergency access must survive the dependency outage it is meant to address. A fallback stored only in the failed directory's vault is circular. Provide controlled independent custody, minimum feasible scope, logging or alternate evidence, qualified operators and post-use reconciliation. Do not let an emergency local account become a permanent remote bypass. Its actual accepted interfaces matter more than the label local.

#### Worked demonstrations

**Constrain remote and emergency engineering — integrated worked case**

Synthetic teaching case; no live equipment was tested.

A supplier receives two hours of read-only broker access. The broker token can also call the gateway configuration API, and its token remains valid for eight hours after the VPN account expires.

**Reasoning:** The design violates both operation scope and effective expiry. Restrict the API role and verify it server-side, then implement supported token/session closure or revise the design through a justified requirement decision. A screenshot of hidden write buttons and a failed new VPN login would not establish either property.

#### Guided practice

Central identity fails during a BMS recovery. The only emergency credential is inside a vault that requires the same identity service. Propose a bounded correction.

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** Create an independently controlled bootstrap mechanism with organizational custody, access criteria, logging/reconciliation and periodic tests. Limit its authority to the required recovery function. Demonstrate the dependency-outage path and rejection of ordinary unauthorized use, then reseal or rotate it after the exercise.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Design a remote-support and emergency-access workflow for one gateway. Supply an authority matrix, token/session lifecycle, evidence chain, expiry tests and a controlled escalation path for a separate engineering change.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Design support access whose identity, operation scope, duration and revocation remain effective across brokers and alternate interfaces.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0118 · single · design**

Which remote-support design fits the stated task?

SYNTHETIC ASSESSMENT EVIDENCE: A supplier needs a two-hour read-only diagnostic session on one gateway. Logic downloads require a separate owner-approved work order.

1. A permanent shared VPN account with controller-subnet access
2. A temporary account that has unrestricted writes during its two hours
3. A read-only user interface backed by an unrestricted API token
4. Named time-bounded access through the approved broker with read authority and separately gated engineering privilege

**Correct option(s):** 4

- Option 1: That exceeds identity, duration and target scope.
- Option 2: Expiry does not correct excessive authority while active.
- Option 3: The effective API path remains write-capable.
- Option 4: The design preserves the task and escalation distinction.

**ISA-EXPERT-Q0119 · single · diagnosis**

What remains after this remote session is administratively closed?

SYNTHETIC ASSESSMENT EVIDENCE: The support ticket closes and the VPN login is disabled. A bearer token issued earlier remains valid on the gateway API for eight hours.

1. No authority remains because the ticket state is closed
2. Only inbound firewall traffic matters now
3. An independent authorization artifact still permits actions
4. The token becomes invalid when the browser window is closed

**Correct option(s):** 3

- Option 1: Administrative state does not enforce the token's validity.
- Option 2: The token may be usable through an already permitted application path.
- Option 3: Session closure must account for token and API semantics.
- Option 4: Client UI closure does not necessarily revoke a bearer token.

**ISA-EXPERT-Q0120 · single · design**

Which emergency-access requirement is most defensible?

SYNTHETIC ASSESSMENT EVIDENCE: Normal support relies on a central identity service. During its outage, qualified local staff need bounded recovery access.

1. Publish a universal administrator password in the operations manual
2. Reuse the central service's unreachable password vault as the only fallback
3. Remove all emergency access because normal MFA is preferred
4. Independently controlled emergency credentials with limited scope, custody, logging and post-use reconciliation

**Correct option(s):** 4

- Option 1: Availability of access does not justify uncontrolled disclosure.
- Option 2: That preserves the failed dependency.
- Option 3: The stated recovery requirement still needs a feasible design.
- Option 4: The fallback must work without silently becoming permanent unrestricted access.

**ISA-EXPERT-Q0121 · single · diagnosis**

Why is MFA insufficient to approve this supplier session?

SYNTHETIC ASSESSMENT EVIDENCE: The supplier authenticates with MFA but connects to the wrong hall and uploads an unapproved project through an authorized engineering role.

1. MFA is ineffective at every purpose because the project was wrong
2. The project becomes approved because the role allows uploads
3. Strong authentication does not establish correct target or change authorization
4. The target is correct whenever the supplier recognizes the device model

**Correct option(s):** 3

- Option 1: It may still have authenticated the account correctly.
- Option 2: Technical permission is not the work-order decision.
- Option 3: Identity proof must be combined with task scope and release verification.
- Option 4: Identical models can serve different halls and process mappings.

**ISA-EXPERT-Q0122 · single · design**

What should be recorded at a remote-access trust boundary?

SYNTHETIC ASSESSMENT EVIDENCE: A broker terminates the supplier's encrypted session and opens a new session to a controller using a service identity.

1. Log only encrypted byte counts
2. Link supplier identity and approved task to the downstream identity, target operations and session evidence
3. Assume end-to-end individual attribution survives automatically through the service account
4. Share the controller service secret with every supplier engineer

**Correct option(s):** 2

- Option 1: Volume does not establish who requested which operation.
- Option 2: The broker changes identity context and concentrates authority.
- Option 3: The downstream record may show only the broker identity.
- Option 4: That bypasses the broker's attribution and scope controls.

**ISA-EXPERT-Q0123 · single · diagnosis**

Which test reveals a read-only boundary implemented only in the user interface?

SYNTHETIC ASSESSMENT EVIDENCE: The web page hides write buttons for observers. The same observer token can call the configuration API directly.

1. Confirm that the hidden button is absent at several screen sizes
2. Verify the login password meets complexity policy
3. Attempt the prohibited API operation using the observer identity in the authorized lab
4. Check that TLS encrypts the observer's traffic

**Correct option(s):** 3

- Option 1: Presentation is not server-side permission enforcement.
- Option 2: Authentication strength does not fix operation authorization.
- Option 3: Effective authorization must exist at the action interface.
- Option 4: Encryption can protect an unauthorized write as well as a read.

**ISA-EXPERT-Q0124 · single · design**

Which access pattern best limits supplier reach during a firmware campaign?

SYNTHETIC ASSESSMENT EVIDENCE: Only gateways G1 and G2 are in scope; controllers must remain protected from programming changes.

1. Grant the full OT subnet because gateway discovery is easier
2. Grant domain administrator and rely on a written instruction not to touch controllers
3. Grant the named campaign identity only the supported update operations on G1/G2, with monitored bounded access
4. Use a shared collector identity because it already reaches the gateways

**Correct option(s):** 3

- Option 1: Convenience expands the attack surface beyond the campaign.
- Option 2: A procedure does not replace feasible technical scope limits.
- Option 3: The scope follows the actual task and preserves adjacent controller restrictions.
- Option 4: That mixes telemetry and maintenance authority and weakens attribution.

**ISA-EXPERT-Q0125 · single · diagnosis**

Which assumption is false in this jump-host design?

SYNTHETIC ASSESSMENT EVIDENCE: The jump host records interactive desktop sessions, but supplier scripts can use an unrecorded API path with the same broad credential.

1. Interactive recording covers all supplier actions
2. Desktop recording can still provide evidence for desktop actions
3. A shared credential can weaken attribution across interfaces
4. The API needs its own authorization and audit coverage

**Correct option(s):** 1

- Option 1: The alternate programmatic interface falls outside the recorded path.
- Option 2: That narrower claim is valid.
- Option 3: The design makes actor linkage harder.
- Option 4: The observed path requires direct treatment.

**ISA-EXPERT-Q0126 · single · design**

How should loss of the support broker be tested?

SYNTHETIC ASSESSMENT EVIDENCE: The broker is the sole engineering route. Local control continues, but a required recovery procedure may need an engineering download during the outage.

1. Install an undocumented permanent bypass for convenience
2. Exercise the approved alternate or broker-restoration path and verify its authority and timing
3. Assume local control continuity proves all engineering needs are covered
4. Test only broker login while every dependency is healthy

**Correct option(s):** 2

- Option 1: That creates an unmanaged authority path.
- Option 2: Normal-path security must coexist with feasible recovery.
- Option 3: A later failure may require the unavailable recovery action.
- Option 4: That does not exercise the stated failure scenario.

**ISA-EXPERT-Q0127 · single · diagnosis**

What is the main issue with unrestricted outbound remote-support agents?

SYNTHETIC ASSESSMENT EVIDENCE: An agent initiates encrypted sessions to a supplier cloud, which can then issue engineering actions. Inbound firewall rules deny unsolicited traffic.

1. Inbound denial proves no external party can influence the host
2. The cloud hostname itself identifies every human operator
3. Encryption prevents the supplier from changing configuration
4. Outbound initiation does not make the resulting remote authority read-only or harmless

**Correct option(s):** 4

- Option 1: The agent creates an allowed control channel.
- Option 2: A service endpoint is not complete individual attribution.
- Option 3: Encryption protects communication, not action scope.
- Option 4: The established channel can carry privileged actions.

**ISA-EXPERT-Q0128 · single · design**

Which session-approval record is most useful after an incident?

SYNTHETIC ASSESSMENT EVIDENCE: A vendor action is suspected during a permitted maintenance window involving three gateways.

1. A supplier invoice showing total hours
2. The date and a generic statement that maintenance was allowed
3. A list of every account ever created on the broker
4. Named actor, exact targets, approved operations/release, start/end, downstream actions and deviations

**Correct option(s):** 4

- Option 1: Commercial duration does not establish technical events.
- Option 2: That is too broad for target and action attribution.
- Option 3: It lacks linkage to the specific session and task.
- Option 4: A window alone does not identify authorized content or actual execution.

**ISA-EXPERT-Q0129 · single · diagnosis**

Why does this local fallback weaken the remote-access treatment?

SYNTHETIC ASSESSMENT EVIDENCE: Remote engineering requires named MFA. A shared local administrator credential is printed inside every panel and accepted over the same network service.

1. The issue disappears if the shared password is longer
2. The fallback becomes an alternate remote authority path that bypasses the named control
3. Any local account automatically invalidates all MFA
4. Printed credentials necessarily prove an attacker has used them

**Correct option(s):** 2

- Option 1: Length does not restore individual attribution or locality restrictions.
- Option 2: A local-use intention does not constrain where the credential is accepted.
- Option 3: A properly constrained emergency account can coexist with MFA.
- Option 4: Exposure is not proof of actual exploitation.

**ISA-EXPERT-Q0130 · single · design**

How should supplier access be handled at contract termination?

SYNTHETIC ASSESSMENT EVIDENCE: The supplier used VPN certificates, broker roles, BMC keys and a cloud-support agent.

1. Disable logging after termination to reduce noise
2. Revoke and verify each effective authority path, including sessions and service-mediated access
3. Delete the supplier's directory account and assume all paths follow it
4. Retain every path for an undefined transition period

**Correct option(s):** 2

- Option 1: That removes evidence rather than closing authority.
- Option 2: One contract relationship can create several independent technical credentials.
- Option 3: Some credentials and agents may be independent.
- Option 4: Continuity needs explicit bounded authorization, not indefinite access.

**ISA-EXPERT-Q0131 · single · diagnosis**

What should be concluded from this denied remote test?

SYNTHETIC ASSESSMENT EVIDENCE: A supplier cannot log in from its normal office IP. The account remains active and can authenticate through an unrestricted alternate cloud relay.

1. The account is fully revoked because the usual office test failed
2. The original test has no value at all
3. One source path is blocked, but the supplier's effective access is not fully revoked
4. The cloud relay is safe because it uses a different IP

**Correct option(s):** 3

- Option 1: A single source test does not cover all paths.
- Option 2: It provides bounded evidence for the tested path.
- Option 3: The alternate relay remains a usable route.
- Option 4: Address difference does not change the credential's authority.

**ISA-EXPERT-Q0132 · single · design**

Which control best separates remote diagnosis from action by an AI assistant?

SYNTHETIC ASSESSMENT EVIDENCE: The assistant reads gateway logs and suggests configuration changes. Its connector currently carries an engineering administrator token.

1. Give the diagnostic connector enforced read permissions and route proposed changes through authorized engineering review
2. Treat every log-supplied command as an approved remediation
3. Hide the write controls in the assistant's interface only
4. Keep the token but instruct the assistant not to write

**Correct option(s):** 1

- Option 1: The effective tool authority must match the advisory role.
- Option 2: Logs are evidence, not a trusted authorization channel.
- Option 3: The underlying token can still authorize actions.
- Option 4: A textual instruction is weaker than a feasible enforced boundary.

**ISA-EXPERT-Q0133 · single · diagnosis**

Which evidence would distinguish a broker outage from controller authorization denial?

SYNTHETIC ASSESSMENT EVIDENCE: A support user reports connection failed. The controller logs a rejected programming request for that broker identity at the same time.

1. Open all controller ports because some network access must be missing
2. Correlate the actual session and method records across broker and controller
3. Replace the broker immediately because the client message names connection
4. Disable controller authorization to see whether the message disappears

**Correct option(s):** 2

- Option 1: The observed method reached the controller.
- Option 2: The controller's explicit rejection suggests the transaction reached application authorization.
- Option 3: Generic client wording may hide a higher-layer rejection.
- Option 4: That expands authority before the failure is properly localized.

**ISA-EXPERT-Q0134 · single · design**

What should a support-session expiry test include?

SYNTHETIC ASSESSMENT EVIDENCE: The design promises access ends at 18:00. It uses VPN sessions, API tokens and a stateful firewall.

1. Clear the browser history and consider the session closed
2. Check only the account's configured expiry field
3. Attempt one new VPN login at 18:01
4. Test new authentication and already established operations through every relevant credential/session path

**Correct option(s):** 4

- Option 1: Local history does not revoke server-side authority.
- Option 2: Configuration intent is not observed enforcement.
- Option 3: That omits existing tunnels and application tokens.
- Option 4: Expiry must constrain effective actions, not only new logins.

#### Recall

**Central identity fails during a BMS recovery. The only emergency credential is inside a vault that requires the same identity service. Propose a bounded correction.**

Create an independently controlled bootstrap mechanism with organizational custody, access criteria, logging/reconciliation and periodic tests. Limit its authority to the required recovery function. Demonstrate the dependency-outage path and rejection of ordinary unauthorized use, then reseal or rotate it after the exercise.

**In this case, what is the justified integrated decision? A supplier receives two hours of read-only broker access. The broker token can also call the gateway configuration API, and its token remains valid for eight hours after the VPN account expires.**

The design violates both operation scope and effective expiry. Restrict the API role and verify it server-side, then implement supported token/session closure or revise the design through a justified requirement decision. A screenshot of hidden write buttons and a failed new VPN login would not establish either property.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)

### ISA-EXPERT-L09 — Preserve boundaries through failures and restoration

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L08

A boundary that works only on the primary path is not fully tested for a resilient system. List the actual failover topology, routing changes, state synchronization, client reconnect behaviour and monitoring coverage. Identical static firewall rules do not guarantee that established sessions survive an asymmetric path. A route returning does not guarantee fresh application data. Observe the required transaction at its consumer and measure the relevant outage or age limit.

Replacement and restoration require policy reconciliation. An old backup may contain retired supplier tunnels, obsolete trust anchors or missing new alarm dependencies. A file's valid signature and checksum prove neither current authorization nor compatibility with a different firmware interpreter. Recover the supported configuration and management trust, compare it to current approved intent, and test required flows, prohibited paths and relevant failures.

Temporary troubleshooting access needs explicit technical closure. Removing a rule may not terminate established state; closing a ticket does not clear an API token. Record the exception's target, purpose, scope, owner and expiry. After correcting the cause, remove or replace the exception, handle surviving sessions, and test the final narrow policy. Keeping a broad bypass because it might help next time converts a diagnostic aid into permanent exposure.

Network acceptance also needs representative payload and load conditions. Encapsulation can create size-dependent MTU failures that small pings miss. Backup bursts can exceed a shared egress queue while average utilization looks low. Redundant links can share power or management causes. Diagnose the specific mechanism using bounded observations, then verify that the correction restores both service and the intended authority boundary.

#### Worked demonstrations

**Preserve boundaries through failures and restoration — integrated worked case**

Synthetic teaching case; no live equipment was tested.

Telemetry works through firewall A. During failover, a static route bypasses it through an older router. The IDS mirrors only A. A restore backup also contains a retired supplier tunnel.

**Reasoning:** Three lifecycle properties are unproven: restricted flow on the degraded route, detection on that route and current authority after restoration. Test actual failover transactions and prohibited operations, extend or qualify monitoring coverage, and reconcile the old tunnel before reconnecting the restored device.

#### Guided practice

Large historian records stall after a secure tunnel is introduced, while small ping and handshake tests pass. What should acceptance of the correction measure?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** Check effective path MTU and supported discovery/fragmentation behaviour, then transfer representative application sizes under the final narrow policy. Record retransmissions, latency and data freshness. Keep necessary control-message handling scoped; do not call an unrestricted bypass the final correction.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Create a boundary lifecycle test matrix for normal path, failover, temporary maintenance access and restored policy. Include one monitoring blind spot and one historical permission that must not return.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Verify that routing, session state, monitoring and management authority preserve required segmentation during lifecycle transitions.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0135 · single · diagnosis**

Why did segmentation appear correct until failover?

SYNTHETIC ASSESSMENT EVIDENCE: Normal traffic crosses firewall A. During failover, a static route sends controller traffic through an older router with broad permits.

1. The older router is secure if it has a different vendor
2. Failover should never be tested because it changes traffic paths
3. The degraded path does not preserve the approved boundary
4. The normal firewall's rule syntax is necessarily wrong

**Correct option(s):** 3

- Option 1: Vendor difference does not establish equivalent policy.
- Option 2: Those changes are precisely why representative testing is needed.
- Option 3: Acceptance must cover the actual failover topology and policy.
- Option 4: It may be correct on the path that was tested.

**ISA-EXPERT-Q0136 · single · design**

Which change avoids mistaking restored connectivity for restored security?

SYNTHETIC ASSESSMENT EVIDENCE: A failed firewall is replaced from an old backup that permits a retired supplier tunnel. Telemetry resumes.

1. Delete all rules to ensure no stale permission remains
2. Accept the restore because the file checksum matches the backup
3. Reconcile the historical policy with current authority, then test required and prohibited flows
4. Rename the tunnel object but retain its permit

**Correct option(s):** 3

- Option 1: That would also remove required service without a justified design.
- Option 2: Integrity of an old file does not make its policy current.
- Option 3: Functional recovery can revive obsolete permissions.
- Option 4: Naming does not revoke access.

**ISA-EXPERT-Q0137 · single · diagnosis**

What does this asymmetric trace suggest?

SYNTHETIC ASSESSMENT EVIDENCE: Outbound traffic traverses firewall A; replies traverse firewall B. No state synchronization exists. Both devices have matching static permits.

1. The application role is definitely wrong
2. Matching permits guarantee every established session will survive
3. Increasing the sensor range fixes the routing asymmetry
4. The session may fail because stateful paths are inconsistent

**Correct option(s):** 4

- Option 1: The trace supports a network-state hypothesis, not conclusive application denial.
- Option 2: State handling and path symmetry still matter.
- Option 3: Measurement configuration does not affect the stateful path.
- Option 4: Static policy equality does not supply shared connection state.

**ISA-EXPERT-Q0138 · single · design**

How should a temporary diagnostic permit be closed?

SYNTHETIC ASSESSMENT EVIDENCE: A broad permit restored service during an outage. The root cause is now corrected and the normal narrow policy is ready.

1. Remove only the rule comment
2. Remove the exception, handle established state as required and verify the final normal/denied transactions
3. Test required collection but omit the formerly exposed engineering path
4. Close the incident ticket and leave the rule for future convenience

**Correct option(s):** 2

- Option 1: The permit remains effective.
- Option 2: Technical closure must cover both new and surviving authority.
- Option 3: That fails to verify the risk introduced by the exception.
- Option 4: Administrative closure does not restore the intended boundary.

**ISA-EXPERT-Q0139 · single · diagnosis**

Which lifecycle gap does a renewal outage expose?

SYNTHETIC ASSESSMENT EVIDENCE: Initial TLS tests passed. Six months later a gateway certificate expires because its renewal path was blocked and no owner received an actionable warning.

1. The best correction is permanent trust of every certificate
2. The design validated initial trust but not continuing certificate lifecycle operation
3. The only issue is the expiry date's display format
4. TLS was never capable of providing security

**Correct option(s):** 2

- Option 1: That would abandon identity validation.
- Option 2: Renewal, distribution and response are part of sustained integration.
- Option 3: The blocked path and missing response are operational dependencies.
- Option 4: The mechanism can work when its lifecycle is engineered.

**ISA-EXPERT-Q0140 · single · design**

Which test best checks segmentation during recovery?

SYNTHETIC ASSESSMENT EVIDENCE: A recovery workstation temporarily joins the controller network to restore a project, then should return to a constrained maintenance zone.

1. Confirm only that the project download completes
2. Keep the workstation dual-homed indefinitely to simplify future recovery
3. Verify its permitted restoration actions, prohibited lateral paths and effective removal of temporary membership/authority
4. Delete the recovery record after success

**Correct option(s):** 3

- Option 1: That omits the boundary and cleanup conditions.
- Option 2: That changes the architecture beyond the temporary task.
- Option 3: Recovery must not leave a permanent bypass.
- Option 4: The record supports later authority and baseline review.

**ISA-EXPERT-Q0141 · single · diagnosis**

What is the significance of this monitoring blind spot?

SYNTHETIC ASSESSMENT EVIDENCE: The IDS observes the normal gateway uplink. During failover, engineering traffic uses a standby path outside the sensor's visibility.

1. The IDS signature database must be corrupt
2. Detection coverage differs by operating state
3. No malicious action is possible while the normal uplink is unused
4. All normal-path alerts should be discarded

**Correct option(s):** 2

- Option 1: The described topology already explains the visibility gap.
- Option 2: A quiet IDS during failover may reflect missing visibility.
- Option 3: The alternate path remains active.
- Option 4: They can remain valid for their observed scope.

**ISA-EXPERT-Q0142 · single · design**

What should a network replacement handback include beyond saved configuration?

SYNTHETIC ASSESSMENT EVIDENCE: A new switch imports the old file, but hardware port numbering and default management services differ.

1. Use the factory defaults because the hardware is newer
2. Accept file import as proof of equivalent forwarding
3. Verify actual port/VLAN mapping, effective services, authority, required flows, denial and failover behaviour
4. Test only the management login

**Correct option(s):** 3

- Option 1: Newer defaults may not satisfy the approved boundary.
- Option 2: Import success does not establish effective physical or logical mapping.
- Option 3: Configuration bytes may be interpreted or applied differently on the replacement.
- Option 4: That omits the process traffic and prohibited paths.

**ISA-EXPERT-Q0143 · single · diagnosis**

Which assumption fails in this availability design?

SYNTHETIC ASSESSMENT EVIDENCE: Two boundary appliances share one power feed, one management account and one incorrectly distributed policy package.

1. Device count alone establishes independent security and service resilience
2. Management and update dependencies belong in the resilience analysis
3. Redundancy can still protect against some single-device failures
4. Separate evidence is needed for failover and policy preservation

**Correct option(s):** 1

- Option 1: Several common causes can affect both appliances together.
- Option 2: They can create common failure paths.
- Option 3: That narrower claim may be valid.
- Option 4: Both are relevant acceptance properties.

**ISA-EXPERT-Q0144 · single · design**

How should an MTU correction be accepted after adding a secure tunnel?

SYNTHETIC ASSESSMENT EVIDENCE: Small pings pass, but large historian records stall. The proposed change adjusts tunnel MTU and necessary path-discovery handling.

1. Permit all control messages from every source without scope
2. Disable encryption permanently to avoid encapsulation overhead
3. Transfer representative application payloads under the final policy and verify latency, retransmission and security boundaries
4. Repeat only the same small ping

**Correct option(s):** 3

- Option 1: A correction should preserve the justified boundary.
- Option 2: That discards a requirement before evaluating the supported correction.
- Option 3: The test must cover the failing sizes and intended enforcement.
- Option 4: That already passes and does not challenge the defect.

**ISA-EXPERT-Q0145 · single · diagnosis**

Why does a gateway reboot not close this network incident?

SYNTHETIC ASSESSMENT EVIDENCE: Rebooting restores telemetry temporarily. Queue drops recur whenever backup traffic saturates the shared egress link.

1. A larger ping payload alone will prevent queue saturation
2. All backup traffic must be permanently prohibited
3. The gateway must be malicious because reboot helps
4. The recurring resource mechanism remains untreated

**Correct option(s):** 4

- Option 1: A diagnostic stimulus does not create capacity or scheduling control.
- Option 2: Backup is also a required lifecycle function.
- Option 3: Many operational faults respond temporarily to restart.
- Option 4: A transient reset is not evidence of a sustained capacity or scheduling correction.

**ISA-EXPERT-Q0146 · single · design**

Which acceptance evidence supports local autonomy during boundary isolation?

SYNTHETIC ASSESSMENT EVIDENCE: The cyber response plan may isolate BMS communications while cooling controllers continue locally.

1. Assume all controllers continue safely because the network is segmented
2. Show that controller power remains on
3. Observe one stable temperature value for a few seconds
4. Demonstrate required local modes, limits, alarms or alternate awareness, and bounded restoration under the isolation scenario

**Correct option(s):** 4

- Option 1: Segmentation does not define process fallback logic.
- Option 2: Power does not establish correct control or awareness.
- Option 3: That is too narrow for the stated failure envelope.
- Option 4: The isolation decision depends on actual operational endurance and visibility.

**ISA-EXPERT-Q0147 · single · diagnosis**

What is wrong with this emergency rule review?

SYNTHETIC ASSESSMENT EVIDENCE: The reviewer sees no new connection attempts after expiry and concludes the rule is unused. A long-lived established engineering session remains active.

1. Connection-attempt counts omit continuing established authority
2. The rule can be kept indefinitely because usage is low
3. No new attempts prove the account has been revoked
4. A long-lived session cannot carry configuration changes

**Correct option(s):** 1

- Option 1: The session can continue without a new setup event.
- Option 2: Low observed use does not justify unnecessary authority.
- Option 3: They show only absence of that observed event class.
- Option 4: Its capabilities depend on application permissions, not age.

**ISA-EXPERT-Q0148 · single · design**

How should service restoration be sequenced after boundary-device compromise?

SYNTHETIC ASSESSMENT EVIDENCE: The device's data-plane rules are backed up, but its local administrator, trust store and management automation were also exposed.

1. Delete logs before restoration to avoid replaying incident events
2. Recover supported firmware/configuration trust and current management authority before accepting the restored boundary
3. Change the management IP but retain all credentials
4. Restore only the ACL file and immediately reopen all links

**Correct option(s):** 2

- Option 1: Logs are evidence, not the identified persistence mechanism.
- Option 2: Data-plane rules alone do not remove the ability to alter them again.
- Option 3: Address changes do not revoke exposed authority.
- Option 4: The management compromise remains unresolved.

**ISA-EXPERT-Q0149 · single · diagnosis**

Which claim is supported by an offline flow-policy simulator?

SYNTHETIC ASSESSMENT EVIDENCE: The learner evaluates a first-match rule set against synthetic source/destination/service records. No device firmware or actual routing is exercised.

1. The exercise has no instructional value
2. The model's passing result guarantees all unlisted traffic is safe
3. The simulated rule semantics produce the reported outcomes for the supplied cases
4. The production firewall has passed site acceptance

**Correct option(s):** 3

- Option 1: It can reveal policy reasoning errors within its scope.
- Option 2: Unmodeled paths and operations remain outside the evidence.
- Option 3: The model does not prove installed routing, parser behaviour or application authorization.
- Option 4: No real enforcing instance was tested.

**ISA-EXPERT-Q0150 · single · design**

Which final review best sustains a conduit after handover?

SYNTHETIC ASSESSMENT EVIDENCE: The initial flow matrix and tests are correct. Future firmware, identity, routing and support changes can alter the path.

1. Assign ownership, change-impact triggers, effective-state checks and periodic relevant failure/recovery tests
2. Replace all review with a count of permitted ports
3. Freeze the diagram forever because it was approved
4. Assume supplier support renewals cannot affect architecture

**Correct option(s):** 1

- Option 1: The intended boundary must remain true as dependencies change.
- Option 2: Port count omits identity, operations, paths and lifecycle state.
- Option 3: Approval does not prevent later drift.
- Option 4: Support methods and authority can change during renewal.

#### Recall

**Large historian records stall after a secure tunnel is introduced, while small ping and handshake tests pass. What should acceptance of the correction measure?**

Check effective path MTU and supported discovery/fragmentation behaviour, then transfer representative application sizes under the final narrow policy. Record retransmissions, latency and data freshness. Keep necessary control-message handling scoped; do not call an unrestricted bypass the final correction.

**In this case, what is the justified integrated decision? Telemetry works through firewall A. During failover, a static route bypasses it through an older router. The IDS mirrors only A. A restore backup also contains a retired supplier tunnel.**

Three lifecycle properties are unproven: restricted flow on the degraded route, detection on that route and current authority after restoration. Test actual failover transactions and prohibited operations, extend or qualify monitoring coverage, and reconcile the old tunnel before reconnecting the restored device.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)

## ISA-EXPERT-M04 — Identity, product trust and release lifecycle

### ISA-EXPERT-L10 — Bind identities to intended authority

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L09

Identity assurance has several links: an asset or person is enrolled, a credential is issued under controlled authority, a peer verifies the credential and intended identity, and an application grants only the approved operations. A valid certificate chain does not by itself prove the peer is the intended gateway. An authenticated service account does not justify database ownership. An IP address reused after replacement does not automatically transfer the old device's cryptographic identity.

Model credentials as operational assets. Record owner, purpose, accepted interfaces, privileges, storage, renewal, revocation and recovery dependencies. Include tokens, local keys, BMC accounts and automated services, not only human directory users. A password reset can leave other artifacts valid. A service denied interactive login may still have powerful API rights. The relevant question is what actions an identity can actually perform through every supported interface.

Time and connectivity can influence trust decisions. Certificate validity and revocation checks need an explicit supported design for unreliable or unavailable dependencies. Define acceptable cached information, age limits and failure behaviour where applicable. Do not assume that permanent fail-open validation is the only way to preserve availability. Conversely, requiring an online service while claiming full isolation creates a hidden contradiction. Test the intended outage and bootstrap cases.

Key custody must support both protection and restoration. An encryption key stored only inside the encrypted backup set creates a cycle. A private key readable by every workstation user expands authority beyond the intended script. Organizational recovery custody should survive staff departure without resorting to informal shared personal accounts. Treat identity correctness, least privilege and sustainable access as connected but separately testable properties.

#### Worked demonstrations

**Bind identities to intended authority — integrated worked case**

Synthetic teaching case; no live equipment was tested.

A gateway is replaced at the same IP. The new certificate chains to a trusted CA but names another service. The old key remains accepted and the recovery vault depends on the failed directory.

**Reasoning:** The address does not establish replacement identity, and chain validity does not satisfy intended-service matching. Enroll and verify the correct replacement, retire the old credential and test peer acceptance/rejection. Separately repair the vault bootstrap cycle through controlled independent custody.

#### Guided practice

An ingestion account can append telemetry, alter schemas, add users and delete backups. Interactive login is disabled. Is its authority suitable?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** No. The relevant programmatic role includes administrative and recovery actions beyond ingestion. Derive a supported minimum role, verify required append behaviour and denied administrative operations, and evaluate any application compatibility constraints explicitly.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Create an identity lifecycle register for a human engineer, collector, gateway, BMC and emergency account. Include accepted interfaces, token/session semantics, renewal dependencies and positive/negative recovery tests.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Evaluate enrollment, peer identity, role scope, key custody and time-dependent trust as one integration chain.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0151 · single · diagnosis**

Which trust decision is missing despite successful certificate-chain validation?

SYNTHETIC ASSESSMENT EVIDENCE: A client accepts a certificate issued by its trusted CA, but the certificate identifies a different gateway than the intended endpoint.

1. Verification that the authenticated identity matches the intended service
2. Proof that the certificate's private key is necessarily compromised
3. A decision to trust every certificate from the CA for every role
4. A requirement to disable encryption and compare plaintext names

**Correct option(s):** 1

- Option 1: A valid chain alone does not bind the connection to the required endpoint.
- Option 2: An identity mismatch does not establish key theft.
- Option 3: Issuer trust is not universal service authorization.
- Option 4: Identity matching can be performed within the protected protocol.

**ISA-EXPERT-Q0152 · single · design**

Which enrollment method best establishes a replacement gateway's identity?

SYNTHETIC ASSESSMENT EVIDENCE: A failed gateway is replaced. The network address is reused, but the new device has a different cryptographic identity.

1. Copy the old private key to every spare without custody controls
2. Bind the approved replacement asset to its credential through controlled verification, then update peers and retire the old identity
3. Trust whichever certificate first appears at the old IP address
4. Disable identity checks until the next maintenance cycle

**Correct option(s):** 2

- Option 1: That weakens identity separation and key protection.
- Option 2: Address reuse should not silently confer trust.
- Option 3: That permits an unverified endpoint to inherit authority.
- Option 4: That leaves an undefined trust gap after replacement.

**ISA-EXPERT-Q0153 · single · diagnosis**

What is wrong with this role design?

SYNTHETIC ASSESSMENT EVIDENCE: An application service identity needs to append telemetry records. Its database role can also alter schemas, manage users and delete backups.

1. A longer password removes the excess operations
2. All service accounts must have full database ownership
3. The role combines required ingestion with unrelated administrative and recovery authority
4. The role is safe because interactive login is disabled

**Correct option(s):** 3

- Option 1: Credential strength does not limit an authenticated role.
- Option 2: Required permissions depend on the supported application design.
- Option 3: A compromised service can affect more than its intended function.
- Option 4: Programmatic privileges still apply.

**ISA-EXPERT-Q0154 · single · design**

How should an offline trust-validation dependency be engineered?

SYNTHETIC ASSESSMENT EVIDENCE: A controller must validate a peer certificate while the enterprise link may be unavailable for a day. The selected method normally fetches revocation information online.

1. Require the live online service while claiming complete enterprise independence
2. Define supported cached/offline validation, freshness limits, failure behaviour and operational alternatives, then test the outage
3. Disable all revocation handling permanently because outages occur
4. Accept any certificate during the outage without recording the changed risk

**Correct option(s):** 2

- Option 1: The dependency contradicts the independence claim.
- Option 2: The trust and availability requirements need a deliberate compatible design.
- Option 3: That abandons an important identity-lifecycle property.
- Option 4: Fail-open trust needs an explicit justified treatment, not an accidental default.

**ISA-EXPERT-Q0155 · single · calculation**

Which certificate-validity conclusion is supported?

SYNTHETIC ASSESSMENT EVIDENCE: Certificate validity begins at 12:00:00. Device time reads 11:59:58 with a known possible error of ±4 seconds. No better time evidence exists.

1. Adding milliseconds to the display resolves the uncertainty
2. The certificate is definitely valid because it is within four seconds
3. The certificate is definitely invalid because the displayed time is earlier
4. The actual validity state is uncertain within the stated clock bounds

**Correct option(s):** 4

- Option 1: Precision does not improve clock accuracy.
- Option 2: Possible validity is not proof of validity.
- Option 3: The uncertainty interval crosses the boundary.
- Option 4: True time could be before or after the validity start.

**ISA-EXPERT-Q0156 · single · diagnosis**

Which identity assumption fails in this audit trail?

SYNTHETIC ASSESSMENT EVIDENCE: A gateway records every controller action under service account gw_admin. Three suppliers and an internal engineer use that account through different tools.

1. The downstream account alone provides individual attribution
2. Different tools can produce actions under the same identity
3. The log establishes that an action used the gateway account
4. Additional broker and workstation records may help attribution

**Correct option(s):** 1

- Option 1: The common identity requires upstream linkage and controlled session evidence.
- Option 2: The stated design permits this.
- Option 3: That is a valid narrower observation.
- Option 4: They can connect upstream actors to downstream actions.

**ISA-EXPERT-Q0157 · single · design**

Which credential design supports bounded automation?

SYNTHETIC ASSESSMENT EVIDENCE: A configuration audit needs to read device state across two zones and store comparison results. It does not implement changes.

1. Use the existing deployment administrator token to avoid another account
2. Give the audit tool unrestricted writes but label its interface read-only
3. Use a shared human administrator password in the script
4. Use a dedicated read-scoped identity for the defined targets and a separate controlled path for approved changes

**Correct option(s):** 4

- Option 1: That grants unnecessary write capability.
- Option 2: The effective token still permits modification.
- Option 3: That mixes human and automation authority and exposes credentials.
- Option 4: Audit visibility should not automatically carry configuration authority.

**ISA-EXPERT-Q0158 · single · diagnosis**

What remains unresolved after rotating a compromised password?

SYNTHETIC ASSESSMENT EVIDENCE: The same account issued long-lived API tokens, an SSH key remains installed, and one active session continues.

1. Other independent credentials and sessions may retain the compromised authority
2. The account is fully remediated if its next password login fails
3. Every token must automatically derive validity from the current password
4. The active session is harmless because it predates discovery

**Correct option(s):** 1

- Option 1: Password rotation is only one part of revocation.
- Option 2: That test covers only one authentication path.
- Option 3: Many systems manage tokens independently.
- Option 4: Age does not remove its operation permissions.

**ISA-EXPERT-Q0159 · single · design**

Which trust-store change deserves independent review?

SYNTHETIC ASSESSMENT EVIDENCE: A supplier asks the owner to install a new root CA trusted for every management service, although the task requires one gateway integration.

1. Constrain and justify the trust scope to the intended identities and supported mechanism
2. Reject all new certificates regardless of legitimate integration needs
3. Install the root globally because a supplier request is sufficient authorization
4. Keep the old trust store and disable validation for the new gateway

**Correct option(s):** 1

- Option 1: A root-level trust addition can authorize far more than one service.
- Option 2: Trust can be added through controlled verification and scope.
- Option 3: The owner must assess the resulting authority.
- Option 4: That creates an unverified exception rather than a supported trust design.

**ISA-EXPERT-Q0160 · single · diagnosis**

Why is a device serial number insufficient as the sole remote identity proof?

SYNTHETIC ASSESSMENT EVIDENCE: The serial is visible on the management page and can be copied into a replacement device's description.

1. A copied identifier is not necessarily bound to possession of a protected credential
2. Changing the IP address always provides stronger identity
3. Every certificate containing a serial is automatically untrustworthy
4. Serial numbers have no inventory value

**Correct option(s):** 1

- Option 1: The identifier may aid inventory but does not alone authenticate the endpoint.
- Option 2: Address assignment is not equivalent to cryptographic authentication.
- Option 3: A certificate can bind an identifier through a trusted issuance process.
- Option 4: They can be useful identifiers within a controlled process.

**ISA-EXPERT-Q0161 · single · design**

How should account recovery be handled for a critical service owner?

SYNTHETIC ASSESSMENT EVIDENCE: The only administrator uses a personal authenticator and leaves the organization unexpectedly.

1. Share the personal account informally among the team
2. Provide controlled organizational recovery custody and tested delegated access without relying on that individual
3. Disable authentication on the service permanently
4. Wait indefinitely for the former employee to respond

**Correct option(s):** 2

- Option 1: That weakens attribution and custody.
- Option 2: Continuity and accountability must survive staff turnover.
- Option 3: That removes authority control rather than repairing ownership.
- Option 4: The service requires an organizational recovery capability.

**ISA-EXPERT-Q0162 · single · diagnosis**

Which boundary is crossed by this secret-handling practice?

SYNTHETIC ASSESSMENT EVIDENCE: A maintenance script embeds a controller administrator secret in a world-readable configuration file on a shared engineering host.

1. Only users who can edit the script can misuse the secret
2. Encryption of the controller session protects the stored plaintext secret
3. Any reader of the file can obtain the script's privileged controller authority
4. The secret is safe because the script is not currently running

**Correct option(s):** 3

- Option 1: Read access can be enough to copy credentials.
- Option 2: Transport protection does not control file access.
- Option 3: Host file permissions become part of the controller trust boundary.
- Option 4: The credential can remain valid independently of process execution.

**ISA-EXPERT-Q0163 · single · design**

Which test best validates role separation after a software upgrade?

SYNTHETIC ASSESSMENT EVIDENCE: The upgrade migrates observer and engineer roles into a new authorization model.

1. Check only the vendor's migration success message
2. Confirm both roles can log in
3. Compare only the displayed role names
4. Exercise required observer reads, denied writes, engineer actions under approval and alternate API interfaces

**Correct option(s):** 4

- Option 1: The result needs effective behavioural verification.
- Option 2: Authentication alone does not validate action separation.
- Option 3: Labels can remain while permissions change.
- Option 4: Migration can change effective permissions beyond normal login.

**ISA-EXPERT-Q0164 · single · diagnosis**

What is the key issue with this key-backup arrangement?

SYNTHETIC ASSESSMENT EVIDENCE: Recovery images are encrypted. The only decryption key is stored inside the same encrypted backup set.

1. Encryption inherently prevents recoverability
2. A backup checksum can replace the decryption key
3. The recovery process has an unsatisfied bootstrap dependency
4. Increasing storage capacity resolves the dependency

**Correct option(s):** 3

- Option 1: It can coexist with sound key custody and recovery.
- Option 2: Integrity verification does not decrypt content.
- Option 3: Available encrypted bytes are unusable without independently obtainable authorized key material.
- Option 4: Capacity does not provide the missing key.

**ISA-EXPERT-Q0165 · single · design**

Which identity evidence should accompany a physical controller replacement?

SYNTHETIC ASSESSMENT EVIDENCE: A new controller receives the approved project and occupies the old network address. Peers still trust the old device certificate.

1. Retain both identities indefinitely without ownership
2. Accept the old IP as proof of continuity
3. Verify replacement identity enrollment, revoke or retire the old credential, and test required peer trust
4. Copy the old certificate without confirming private-key custody or policy

**Correct option(s):** 3

- Option 1: That preserves potentially usable retired authority.
- Option 2: An address is not the device's cryptographic identity.
- Option 3: Functional project loading does not complete device identity lifecycle.
- Option 4: Credential reuse needs explicit support and risk treatment, not assumption.

**ISA-EXPERT-Q0166 · single · diagnosis**

Which claim overstates what authentication proves?

SYNTHETIC ASSESSMENT EVIDENCE: A signed sensor message passes origin and integrity checks. Its reported pressure disagrees with a calibrated independent gauge.

1. The message came through the validated identity path under the test assumptions
2. Calibration and scaling evidence are still relevant
3. The measurement is physically correct because its sender authenticated
4. The discrepancy needs investigation before relying on the value

**Correct option(s):** 3

- Option 1: That is the narrower supported claim.
- Option 2: They address measurement correctness.
- Option 3: An authentic sensor or mapping can still be faulty or misconfigured.
- Option 4: The independent disagreement challenges physical validity.

**ISA-EXPERT-Q0167 · single · design**

How should emergency credentials be restored after use?

SYNTHETIC ASSESSMENT EVIDENCE: A break-glass account was used during directory failure to recover the BMS. Normal identity service is now healthy.

1. Leave the account broadly available because it proved useful
2. Disable all future emergency access without reassessing recovery needs
3. Delete every record of its use to protect the secret
4. Review actions, rotate or reseal credentials as required, close temporary sessions and verify normal authority

**Correct option(s):** 4

- Option 1: A useful fallback still needs custody and scope.
- Option 2: The underlying dependency-outage scenario may remain.
- Option 3: Logs can be protected without erasing accountability.
- Option 4: Emergency access has a controlled lifecycle beyond successful login.

#### Recall

**An ingestion account can append telemetry, alter schemas, add users and delete backups. Interactive login is disabled. Is its authority suitable?**

No. The relevant programmatic role includes administrative and recovery actions beyond ingestion. Derive a supported minimum role, verify required append behaviour and denied administrative operations, and evaluate any application compatibility constraints explicitly.

**In this case, what is the justified integrated decision? A gateway is replaced at the same IP. The new certificate chains to a trusted CA but names another service. The old key remains accepted and the recovery vault depends on the failed directory.**

The address does not establish replacement identity, and chain validity does not satisfy intended-service matching. Enroll and verify the correct replacement, retire the old credential and test peer acceptance/rejection. Separately repair the vault bootstrap cycle through controlled independent custody.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)
- [ISA public standards-series scope and principal roles](https://www.isa.org/standards-and-publications/isa-standards/isa-iec-62443-series-of-standards)

### ISA-EXPERT-L11 — Trust the complete release chain

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L10

A trusted release chain includes more than the main image. Identify source or vendor release, build inputs, libraries, compiler/tool version, configuration, installer scripts, target hardware, activation steps and runtime state. A signature can establish origin and integrity under its trust assumptions; it does not prove the release is suitable for a different equipment variant or that an authorized author made no semantic error. A trusted package can enable an unwanted default support channel.

Reproducibility requires a compatible dependency set. PLC source may compile differently under another library or tool release. Automatic conversion can alter initialization, timers or supported instructions. A host may have the new package on disk while its process still executes the old binary. Record exact artifacts and use supported runtime observations plus behavioural tests. Hash comparisons are useful for bytes but cannot replace engineering interpretation of mappings, roles and physical I/O.

Supplier lifecycle evidence informs selection and maintenance. Applicable development-process assurance, vulnerability handling, software-component information, support periods and signed-update mechanisms can reduce uncertainty. Match their scope and versions to the delivered product. A software bill of materials is a starting point for advisory applicability, not proof that every listed component is exploitable. A generic compliance slogan cannot establish all owner, integrator and operational obligations.

The trust chain itself can change. If a signing key is reported compromised before a package date, a mathematically valid signature needs reassessment. Select a separately justified supported recovery source and preserve the evidence basis. Protect installation and recovery scripts as well as images. A writable wrapper can redirect a valid image, choose a wrong target or execute additional code without changing the image hash.

#### Worked demonstrations

**Trust the complete release chain — integrated worked case**

Synthetic teaching case; no live equipment was tested.

An approved project hash matches, but the engineering station uses a different compiler and library. The installer script comes from a writable share. The downloaded firmware is genuine but targets another hardware revision.

**Reasoning:** Three different properties are unresolved: build compatibility, execution-tool trust and target suitability. None is fixed by repeating the project hash check. Establish the supported dependency set, control the wrapper and select the correct target release, then test the resulting effective application.

#### Guided practice

A supplier says an update has no functional impact, but it changes the communications library used by polling, alarms and failover reconnects. Design the minimum relevant review.

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** Identify the exact changed dependency and supported combinations. Test representative normal polling, alarm delivery, timing under load and reconnect/failover behaviour with required security controls enabled. Record supplier evidence as an input, not a substitute for applicable integration tests.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Build a release manifest for one simulated controller or gateway integration. Include provenance, tool/library versions, configuration semantics, target identity, activation evidence and a compatible rollback set.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Assess product and configuration provenance together with compatibility, toolchain dependencies and effective execution.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0168 · single · diagnosis**

Which conclusion follows from this signed update?

SYNTHETIC ASSESSMENT EVIDENCE: The package signature is valid and its hash matches the vendor release. The package targets a different controller hardware revision.

1. The valid signature guarantees correct hardware compatibility
2. The package is necessarily malicious
3. Origin and integrity may be established while compatibility and suitability are not
4. The hash must be wrong because the hardware differs

**Correct option(s):** 3

- Option 1: Cryptographic verification does not evaluate the installation's engineering requirements.
- Option 2: Unsuitability is not proof of malicious intent.
- Option 3: A genuine package can still be wrong for the installed target.
- Option 4: The bytes can match an authentic but unsuitable release.

**ISA-EXPERT-Q0169 · single · design**

What should a secure release manifest identify for a PLC application?

SYNTHETIC ASSESSMENT EVIDENCE: The application depends on a project, function library, compiler/tool version, hardware configuration and retained-state policy.

1. The exact compatible dependency set, provenance, build/deployment identity and tested behaviour
2. Only the controller's commercial model number
3. Any latest library version available during download
4. Only the project archive name and modification date

**Correct option(s):** 1

- Option 1: A reproducible release extends beyond a single source filename.
- Option 2: The model does not define the loaded application and toolchain.
- Option 3: Uncontrolled dependencies can change compiled behaviour.
- Option 4: These do not identify content or execution dependencies.

**ISA-EXPERT-Q0170 · single · diagnosis**

Why does source equality not prove identical controller behaviour here?

SYNTHETIC ASSESSMENT EVIDENCE: The project text is unchanged, but a new library initializes a timer differently and the controller retains an old maintenance flag.

1. Every library update must change application source text
2. Dependencies and runtime state alter effective execution
3. Retained state is irrelevant after a download
4. The source comparison necessarily failed technically

**Correct option(s):** 2

- Option 1: Compiled dependencies can change independently.
- Option 2: The same source can behave differently under changed libraries or retained values.
- Option 3: Its persistence depends on the platform and procedure and must be checked.
- Option 4: It may accurately show identical source while omitting other state.

**ISA-EXPERT-Q0171 · single · design**

Which supplier-development evidence is useful at procurement?

SYNTHETIC ASSESSMENT EVIDENCE: The owner needs confidence that vulnerabilities and supported updates will be handled through the product lifecycle.

1. Only the current feature list
2. A site-specific achieved-security claim without knowledge of the future installation
3. A promise that the product will never contain any vulnerability
4. Applicable development-process assurance, vulnerability handling, support commitments and release-verification information

**Correct option(s):** 4

- Option 1: Features omit lifecycle processes and support obligations.
- Option 2: The supplier cannot establish every integration condition in advance.
- Option 3: That is not a credible assurance mechanism.
- Option 4: These inform product trust and maintainability within their scope.

**ISA-EXPERT-Q0172 · single · diagnosis**

What does this SBOM finding establish?

SYNTHETIC ASSESSMENT EVIDENCE: A software bill of materials lists library L. An advisory affects certain L versions and configurations, but the appliance's effective build is not yet known.

1. Every appliance containing the library is definitely exploitable
2. The appliance is safe because the library is embedded
3. The SBOM is useless until an exploit succeeds
4. A lead for applicability investigation, not confirmed exploitability

**Correct option(s):** 4

- Option 1: The advisory's scope is narrower than mere presence.
- Option 2: Embedded components can still carry relevant vulnerabilities.
- Option 3: It can guide inventory, supplier questions and treatment.
- Option 4: Component presence must be matched to affected versions and conditions.

**ISA-EXPERT-Q0173 · single · design**

Which acceptance test best challenges a signed-but-wrong configuration threat?

SYNTHETIC ASSESSMENT EVIDENCE: A release pipeline signs configuration packages, but a privileged author can change a gateway mapping to the wrong source point.

1. Assume author privilege is equivalent to change approval
2. Measure download speed only
3. Verify approved semantic intent and independent point-to-point behaviour in addition to package provenance
4. Repeat signature verification with a second copy of the same public key

**Correct option(s):** 3

- Option 1: Technical write access is not the full governance decision.
- Option 2: Transfer performance does not establish intended source binding.
- Option 3: Signing protects origin/integrity, not the correctness of authorized content.
- Option 4: That does not assess the mapping's meaning.

**ISA-EXPERT-Q0174 · single · diagnosis**

Which trust weakness remains in this update workflow?

SYNTHETIC ASSESSMENT EVIDENCE: The image is verified, but an unversioned installer script downloaded from a shared writable folder runs with administrator privileges.

1. The shared folder is safe because only employees can write it
2. Scripts cannot influence firmware installation
3. The execution wrapper can alter the trusted installation path
4. The verified image hash necessarily changes when the script is modified

**Correct option(s):** 3

- Option 1: Internal write authority still needs scope and provenance controls.
- Option 2: They can select targets, options, inputs or additional actions.
- Option 3: Image integrity does not authenticate every tool and script used around it.
- Option 4: The script can affect execution without changing the image file.

**ISA-EXPERT-Q0175 · single · design**

How should a compromised signing-key advisory affect recovery-source selection?

SYNTHETIC ASSESSMENT EVIDENCE: The supplier reports its key was exposed before the date of the stored recovery package. The package's signature remains mathematically valid.

1. Conclude every product from the supplier is certainly compromised
2. Use the package unchanged because valid mathematics proves trustworthy origin
3. Choose any older unsigned package without provenance review
4. Reassess the package's trust basis and use a separately justified supported source or recovery path

**Correct option(s):** 4

- Option 1: Scope and evidence must be assessed rather than assumed universally.
- Option 2: A compromised signing authority can produce valid signatures.
- Option 3: Age and lack of signature do not establish trust.
- Option 4: The new fact weakens the original authenticity assumption.

**ISA-EXPERT-Q0176 · single · diagnosis**

What is missing from this hardening acceptance?

SYNTHETIC ASSESSMENT EVIDENCE: A supplier checklist says remote shell is disabled. The running appliance listens on an alternate management interface and accepts the default key.

1. A statement that the appliance passed factory throughput tests
2. A new label on the checklist declaring it final
3. A higher password-complexity policy on the primary web interface
4. Effective-state and alternate-interface verification

**Correct option(s):** 4

- Option 1: Performance evidence does not address the management exposure.
- Option 2: Document status does not close the observed service.
- Option 3: The alternate key path remains independent.
- Option 4: A checklist statement does not establish enforcement on every relevant path.

**ISA-EXPERT-Q0177 · single · design**

Which dependency should be added before claiming long-term recoverability?

SYNTHETIC ASSESSMENT EVIDENCE: A controller project compiles only with a licensed tool release scheduled to become unavailable from the supplier portal.

1. Only a printed copy of the source logic
2. A bookmark to the supplier's current download page
3. A promise to use whichever tool release is newest later
4. Controlled legal access to compatible tools, licences and dependencies, with a tested restoration method

**Correct option(s):** 4

- Option 1: It may aid understanding but does not provide the executable build environment.
- Option 2: Future availability and entitlement are not guaranteed by a bookmark.
- Option 3: Newer tools may change compatibility or semantics.
- Option 4: Recoverability depends on being able to recreate the application environment.

**ISA-EXPERT-Q0178 · single · diagnosis**

Why is this product substitution not automatically equivalent?

SYNTHETIC ASSESSMENT EVIDENCE: A replacement gateway supports the same protocols but handles bad-quality points by substituting zero instead of propagating invalid status.

1. Zero is always a safer substitute than invalid status
2. Encryption strength alone determines equivalence
3. Protocol support does not establish equivalent application semantics
4. Both products must be equivalent because their protocol names match

**Correct option(s):** 3

- Option 1: The safe interpretation depends on the process and application.
- Option 2: Transport cryptography does not define data-quality handling.
- Option 3: The changed failure representation can alter alarms and control decisions.
- Option 4: Implementations and configuration behaviour can differ.

**ISA-EXPERT-Q0179 · single · design**

Which release gate catches a change in execution authority?

SYNTHETIC ASSESSMENT EVIDENCE: An HMI update adds a plugin loader whose configuration is writable by ordinary users. The main executable remains signed.

1. Increase logging retention without changing the loader's authority
2. Allow the update because the new feature is disabled in the UI
3. Review writable execution inputs, plugin trust and effective privileges, then test prohibited loading
4. Verify only the main executable's signature

**Correct option(s):** 3

- Option 1: Evidence retention does not prevent the unauthorized execution route.
- Option 2: The effective configuration and alternate paths must be established.
- Option 3: Signed main code can load attacker-controlled extensions through weaker inputs.
- Option 4: That does not constrain the plugin path.

**ISA-EXPERT-Q0180 · single · diagnosis**

Which supply-chain assumption is undermined by this recovery test?

SYNTHETIC ASSESSMENT EVIDENCE: A golden image is protected, but joining the restored host to central management immediately reinstalls an unauthorized startup task.

1. Repeated local reimaging alone removes the upstream cause
2. The image hash must have been false
3. The storage hardware is necessarily infected
4. The upstream configuration authority is outside the supposedly clean recovery boundary

**Correct option(s):** 4

- Option 1: The same dependency can reapply the task each time.
- Option 2: The image can be intact before management applies the task.
- Option 3: The observed mechanism points to policy distribution.
- Option 4: A trusted image can be altered by a compromised management dependency.

**ISA-EXPERT-Q0181 · single · design**

What should an update-support contract clarify for an isolated OT product?

SYNTHETIC ASSESSMENT EVIDENCE: The supplier requires internet activation for patches, but the approved site architecture has no direct controller internet path.

1. A supported offline or brokered update/activation method, its dependencies, trust checks and recovery limits
2. A permanent unrestricted controller internet exception without risk review
3. An assumption that the activation requirement will disappear in production
4. A rule forbidding every future patch

**Correct option(s):** 1

- Option 1: Support feasibility must fit the site's architecture and lifecycle.
- Option 2: That changes the security boundary beyond the stated need.
- Option 3: Unverified assumptions do not make the method executable.
- Option 4: That leaves vulnerability and support obligations unresolved.

**ISA-EXPERT-Q0182 · single · diagnosis**

What does this library conversion result require?

SYNTHETIC ASSESSMENT EVIDENCE: A supported engineering tool converts an old project without errors. The converted logic changes timer resolution and restart initialization.

1. Comparison only of the old source filename
2. Automatic rejection of all converted projects forever
3. Immediate acceptance because the tool is vendor-supported
4. Impact analysis and regression of affected timing and state behaviour

**Correct option(s):** 4

- Option 1: The deployed converted artifact and behaviour matter.
- Option 2: Conversion can be accepted with appropriate evidence.
- Option 3: Support does not guarantee every application requirement remains satisfied.
- Option 4: Tool completion is not proof of semantic equivalence.

**ISA-EXPERT-Q0183 · single · design**

Which independent evidence best tests a supplier's assertion of no functional impact?

SYNTHETIC ASSESSMENT EVIDENCE: A security update changes a communications library used by polling, alarms and failover reconnects.

1. An installer exit code of zero
2. Representative transaction, alarm, timing and degraded-state tests on the actual compatible baseline
3. A clean malware scan before the update
4. The supplier's marketing statement repeated in the site report

**Correct option(s):** 2

- Option 1: That establishes only a narrow installation result.
- Option 2: The claim concerns several operational behaviours, not just installation.
- Option 3: It does not measure the changed library's operational effect.
- Option 4: Repeating a claim is not independent validation.

**ISA-EXPERT-Q0184 · single · diagnosis**

Which claim about secure development and system operation is defensible?

SYNTHETIC ASSESSMENT EVIDENCE: A product supplier has applicable development-process assurance. The site disables recommended access controls and retains default accounts.

1. The supplier certificate transfers responsibility for every site configuration to the supplier
2. The supplier process evidence remains scoped; the site's effective operation still needs assessment
3. No product assurance evidence can be used once integration begins
4. The site's weak configuration proves the supplier never followed its development process

**Correct option(s):** 2

- Option 1: The roles and obligations remain distinct.
- Option 2: Product lifecycle assurance does not automatically validate site choices.
- Option 3: Applicable evidence can still inform the system argument.
- Option 4: That conclusion does not follow from site operation.

#### Recall

**A supplier says an update has no functional impact, but it changes the communications library used by polling, alarms and failover reconnects. Design the minimum relevant review.**

Identify the exact changed dependency and supported combinations. Test representative normal polling, alarm delivery, timing under load and reconnect/failover behaviour with required security controls enabled. Record supplier evidence as an input, not a substitute for applicable integration tests.

**In this case, what is the justified integrated decision? An approved project hash matches, but the engineering station uses a different compiler and library. The installer script comes from a writable share. The downloaded firmware is genuine but targets another hardware revision.**

Three different properties are unresolved: build compatibility, execution-tool trust and target suitability. None is fixed by repeating the project hash check. Establish the supported dependency set, control the wrapper and select the correct target release, then test the resulting effective application.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)
- [ISA public standards-series scope and principal roles](https://www.isa.org/standards-and-publications/isa-standards/isa-iec-62443-series-of-standards)

### ISA-EXPERT-L12 — Reconcile identity through recovery and retirement

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L11

Backups preserve historical state, while authorization decisions continue to change. Recovery must reconcile the two. A valid old snapshot may contain a departed engineer, retired supplier CA, expired service certificate or temporary administrator role. Conversely, it may omit a newly required service identity. Restoring every account exactly can revive obsolete access; deleting everything can prevent required function. Compare restored authority to current approved roles and treat each discrepancy deliberately.

Renewal is a distributed change. A gateway can load a new certificate while a standby consumer still trusts the old chain. A scheduled task can reference the previous private-key path. Initial handshake tests therefore do not establish the lifecycle. Include trust distribution, alternate paths, periodic jobs, expiry warnings, responsible recipients and supported rollback. A warning sent to a departed mailbox is not an actionable renewal process.

After compromise, review upstream authority before reconnecting rebuilt endpoints. A clean host joining a compromised policy service can receive the same malicious startup task again. OS restoration does not necessarily affect BMC firmware, keys or virtual-media rights. Current trust requires the controlling dependencies and alternate management paths to be included in the incident scope and acceptance evidence.

Retirement also closes authority. Physical removal should trigger controlled credential revocation, trust-store changes, route and integration cleanup, data preservation or sanitization, and asset-record updates. Retain required historical evidence without leaving the old device's private key usable. Evidence bundles need the same honesty: a digital signature can protect the later document but cannot prove that manually entered values were measured or that missing raw observations existed.

#### Worked demonstrations

**Reconcile identity through recovery and retirement — integrated worked case**

Synthetic teaching case; no live equipment was tested.

A restored BMS image works, but it trusts a retired gateway key and its scheduled export task uses an expired certificate. The old gateway has been removed from the rack but not from peer trust stores.

**Reasoning:** Reconcile both excess and missing current authority. Revoke the retired identity, install the supported current export credential and verify its dependent task. Test current gateway acceptance and old-key rejection. Record physical retirement and data disposition separately from the technical trust closure.

#### Guided practice

A clean host is rebuilt after credential theft, then receives an unauthorized startup task immediately after joining central management. What should change in the recovery sequence?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** Establish trustworthy identity and policy distribution, or an approved isolated alternative, before rejoining dependent hosts. Review exposed roles, tokens and policies. Repeating the local image restore alone leaves the upstream authority able to reintroduce the state.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Perform a synthetic restoration reconciliation with an old account list, current approved list, certificates and active sessions. Document required additions, removals, session handling and tests, then extend the record to retirement of the old platform.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Restore current legitimate authority while removing historical, compromised and retired credentials across all relevant interfaces.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0185 · single · design**

Which credential restoration sequence avoids reviving obsolete authority?

SYNTHETIC ASSESSMENT EVIDENCE: A backup contains a retired supplier account and an old trusted CA. Current policy uses new service identities and a replacement CA.

1. Restore everything exactly and defer access review for a month
2. Discard all certificates and disable validation until service returns
3. Reconcile restored identities and trust with current approved authority before reconnecting
4. Keep only account display names and ignore keys or tokens

**Correct option(s):** 3

- Option 1: That knowingly reintroduces obsolete authority.
- Option 2: That removes trust controls rather than restoring them coherently.
- Option 3: Historical usability must be combined with present authorization decisions.
- Option 4: Effective authority includes more than names.

**ISA-EXPERT-Q0186 · single · diagnosis**

What failed in this certificate-renewal campaign?

SYNTHETIC ASSESSMENT EVIDENCE: The gateway loads the new certificate, but one standby consumer still trusts only the old issuing chain. Normal active operation passes.

1. The new certificate is necessarily cryptographically invalid
2. Trust distribution and standby-path acceptance are incomplete
3. The gateway should trust the consumer's old certificate instead
4. The standby can be omitted because it carries no normal traffic

**Correct option(s):** 2

- Option 1: One consumer's trust configuration can explain rejection.
- Option 2: Local renewal success does not establish every required peer relationship.
- Option 3: The stated failure concerns the consumer validating the gateway.
- Option 4: Its failure matters when the declared redundant path is used.

**ISA-EXPERT-Q0187 · single · design**

Which evidence should close a privileged-account departure task?

SYNTHETIC ASSESSMENT EVIDENCE: An engineer leaves after holding directory roles, local device accounts, SSH keys, API tokens and recovery-vault access.

1. Change the engineer's display name to a generic service name
2. Keep access until every device is replaced
3. Verify revocation or reassignment across each path and review active sessions and shared secrets
4. Disable the corporate email account and assume all other access follows

**Correct option(s):** 3

- Option 1: Renaming does not remove their knowledge or credential access.
- Option 2: That prolongs unnecessary authority without a justified plan.
- Option 3: A personnel event spans multiple technical authority stores.
- Option 4: The listed paths can be independent.

**ISA-EXPERT-Q0188 · single · diagnosis**

Why is a restored clean image still not accepted?

SYNTHETIC ASSESSMENT EVIDENCE: The host runs approved software but its backup service credential can delete every recovery copy and is also used by normal administrators.

1. Normal administrator convenience overrides recovery separation
2. All backup deletion must be technically impossible under every circumstance
3. A clean image necessarily contains malware if privileges are broad
4. Recovery trust remains exposed to shared broad authority

**Correct option(s):** 4

- Option 1: Convenience does not satisfy the stated resilience requirement.
- Option 2: Authorized retention and lifecycle operations may require controlled deletion.
- Option 3: Excess authority is a risk even without current malware.
- Option 4: Image integrity does not establish separation of recovery administration.

**ISA-EXPERT-Q0189 · single · design**

Which test validates an emergency account without leaving routine excess access?

SYNTHETIC ASSESSMENT EVIDENCE: The account must work during directory loss, remain unavailable for ordinary remote work, and have auditable use.

1. Leave the account logged in permanently after the drill
2. Disable logging during emergency use to avoid dependency load
3. Test a normal online login only
4. Exercise the dependency-outage path, prohibited normal paths, custody and post-use closure

**Correct option(s):** 4

- Option 1: That creates continuing authority outside the test.
- Option 2: Accountability still requires a feasible supported evidence path.
- Option 3: That omits the failure condition and scope restriction.
- Option 4: The fallback's availability and limits must both be demonstrated.

**ISA-EXPERT-Q0190 · single · diagnosis**

What is the problem with this certificate expiry alert?

SYNTHETIC ASSESSMENT EVIDENCE: The alert arrives before expiry but is routed to a departed supplier's mailbox. No current owner has renewal access.

1. The certificate's cryptography must be weak
2. Expiry should be ignored because the alert technically fired
3. Monitoring exists without actionable ownership and execution capability
4. Increasing alert frequency alone guarantees renewal

**Correct option(s):** 3

- Option 1: The issue is lifecycle ownership, not algorithm strength.
- Option 2: The required service still faces a foreseeable failure.
- Option 3: An early warning cannot prevent outage if no authorized recipient can act.
- Option 4: More messages to an unusable route do not create access or responsibility.

**ISA-EXPERT-Q0191 · single · design**

How should a recovered trust store be tested?

SYNTHETIC ASSESSMENT EVIDENCE: The restoration source predates revocation of one device and enrollment of its replacement.

1. Verify acceptance of the current identity and rejection of the retired identity, including alternate interfaces
2. Verify only that the trust-store file parses
3. Compare only the number of stored certificates
4. Verify only that some device can connect

**Correct option(s):** 1

- Option 1: Both required continuity and revoked authority must hold.
- Option 2: Parsing does not establish current trust decisions.
- Option 3: Counts can match while identities differ.
- Option 4: That does not distinguish the correct and retired identities.

**ISA-EXPERT-Q0192 · single · diagnosis**

Which distinction explains this key-rotation failure?

SYNTHETIC ASSESSMENT EVIDENCE: The application certificate is renewed, but an unattended scheduled task still uses the old private-key path and fails during the next nightly run.

1. Nightly tasks cannot be tested before production
2. The task should receive every available private key to avoid future failures
3. Credential deployment and dependent runtime configuration were not coordinated
4. The renewal necessarily failed at the CA

**Correct option(s):** 3

- Option 1: Representative execution can be rehearsed under approved conditions.
- Option 2: That grants excessive key access and hides dependency control.
- Option 3: Renewing one object does not update every consumer.
- Option 4: The certificate may be valid while the task references the old material.

**ISA-EXPERT-Q0193 · single · design**

Which response fits an unknown credential discovered in a restored controller?

SYNTHETIC ASSESSMENT EVIDENCE: A local account exists in the recovery image but has no current owner or documented requirement. Removing it may affect a vendor service.

1. Delete it immediately without assessing the stated service dependency
2. Retain it indefinitely because it was in a valid backup
3. Rename it to approved_service and close the finding
4. Investigate effective use and dependency, then remove or explicitly govern it through controlled change

**Correct option(s):** 4

- Option 1: The operational effect must be understood and managed.
- Option 2: Historical presence does not prove current need or approval.
- Option 3: A name change does not establish legitimate ownership or scope.
- Option 4: Unknown authority requires treatment without blind disruption.

**ISA-EXPERT-Q0194 · single · diagnosis**

What remains unproven after this media verification?

SYNTHETIC ASSESSMENT EVIDENCE: A USB package passes malware scanning and matches the approved project hash. The engineering workstation's compiler and libraries differ from the tested release environment.

1. The resulting deployed build's compatibility and semantics
2. The possibility of resolving the gap through compatible tools and regression
3. The project file's byte identity
4. The scan outcome under its stated conditions

**Correct option(s):** 1

- Option 1: Verified input bytes do not fix an uncontrolled toolchain.
- Option 2: A controlled build and test can address it.
- Option 3: The matching hash supports that narrower property.
- Option 4: That is an observed result, although limited.

**ISA-EXPERT-Q0195 · single · design**

Which measure sustains least privilege after organizational changes?

SYNTHETIC ASSESSMENT EVIDENCE: Temporary engineers become permanent operators, but inherited project-download roles remain on their accounts.

1. Review passwords but ignore group and API permissions
2. Keep all accumulated roles because prior approval lasts forever
3. Reconcile role entitlements with current duties and test removal of obsolete operations
4. Replace named accounts with one shared operator administrator

**Correct option(s):** 3

- Option 1: Credential strength does not resolve excess entitlement.
- Option 2: Role changes can invalidate the original need.
- Option 3: Access should follow current approved responsibilities.
- Option 4: That expands authority and reduces attribution.

**ISA-EXPERT-Q0196 · single · diagnosis**

Why is this credential inventory insufficient for incident containment?

SYNTHETIC ASSESSMENT EVIDENCE: The inventory records account names and owners but omits tokens, certificates, local keys and active session mechanisms.

1. All authority artifacts necessarily expire when an account is deleted
2. Only credentials used in the last hour need review
3. Account inventories are useless for containment
4. It cannot identify every effective authority artifact needing revocation

**Correct option(s):** 4

- Option 1: Platform semantics differ and must be verified.
- Option 2: Unused valid credentials can still be abused later.
- Option 3: They remain a useful starting point within their scope.
- Option 4: An account can authorize through several independent mechanisms.

**ISA-EXPERT-Q0197 · single · design**

What should a decommissioning handback prove for an engineering server?

SYNTHETIC ASSESSMENT EVIDENCE: The server is removed from the rack but has controller keys, project archives, BMC access and trusted certificates.

1. Only that the OS user account is disabled
2. That every historical project is deleted regardless of retention needs
3. Only that the power cord is disconnected
4. Controlled preservation/sanitization plus revocation of the retired platform's identities and integrations

**Correct option(s):** 4

- Option 1: BMC, certificates and embedded secrets may be independent.
- Option 2: Records and recovery obligations need controlled disposition.
- Option 3: The credentials and data can remain usable elsewhere.
- Option 4: Physical removal alone does not end logical authority or protect stored material.

**ISA-EXPERT-Q0198 · single · diagnosis**

Which trust claim is limited by this recovery exercise?

SYNTHETIC ASSESSMENT EVIDENCE: Certificate validation was disabled to make the synthetic lab run because the lab had no representative time service.

1. The exercise does not demonstrate the intended authenticated integration under its real time dependency
2. The lab should be reported as a completed physical commissioning
3. The bypass proves production validation will work once time is added
4. Every non-authentication observation is automatically worthless

**Correct option(s):** 1

- Option 1: The bypass changes a relevant acceptance condition.
- Option 2: No physical or full trust validation occurred.
- Option 3: That still requires testing.
- Option 4: Some bounded functional results may remain useful.

**ISA-EXPERT-Q0199 · single · design**

Which post-incident identity check best prevents immediate re-compromise?

SYNTHETIC ASSESSMENT EVIDENCE: A host is rebuilt after an administrator credential theft. The directory and management platform may still contain attacker-added roles and startup policies.

1. Establish trustworthy upstream authority and current role/policy state before reconnecting the host
2. Change only the host's local hostname
3. Reconnect first and rely on the host's clean image hash
4. Disable every central service permanently without recovery analysis

**Correct option(s):** 1

- Option 1: A clean endpoint can be compromised again by an uncorrected control plane.
- Option 2: Naming does not remove stolen central authority.
- Option 3: The image does not constrain later policy delivery.
- Option 4: An approved trustworthy restoration or isolated alternative is needed.

**ISA-EXPERT-Q0200 · single · diagnosis**

What is the correct interpretation of this signed evidence bundle?

SYNTHETIC ASSESSMENT EVIDENCE: The bundle is digitally signed after a technician manually edits test results. The raw observations are not retained.

1. Every signed report necessarily contains accurate observations
2. The report has no identifiable author merely because raw data is missing
3. The signature authenticates the later bundle but does not establish the truth or original provenance of its contents
4. The signature reconstructs the missing raw observations

**Correct option(s):** 3

- Option 1: Signing does not validate the engineering facts.
- Option 2: The signature may identify the signer while factual assurance remains limited.
- Option 3: Integrity after signing is different from trustworthy measurement and handling.
- Option 4: Cryptography cannot recover unrecorded evidence.

#### Recall

**A clean host is rebuilt after credential theft, then receives an unauthorized startup task immediately after joining central management. What should change in the recovery sequence?**

Establish trustworthy identity and policy distribution, or an approved isolated alternative, before rejoining dependent hosts. Review exposed roles, tokens and policies. Repeating the local image restore alone leaves the upstream authority able to reintroduce the state.

**In this case, what is the justified integrated decision? A restored BMS image works, but it trusts a retired gateway key and its scheduled export task uses an expired certificate. The old gateway has been removed from the rack but not from peer trust stores.**

Reconcile both excess and missing current authority. Revoke the retired identity, install the supported current export credential and verify its dependent task. Test current gateway acceptance and old-key rejection. Record physical retirement and data disposition separately from the technical trust closure.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)
- [ISA public standards-series scope and principal roles](https://www.isa.org/standards-and-publications/isa-standards/isa-iec-62443-series-of-standards)

## ISA-EXPERT-M05 — Industrial protocol and point semantics

### ISA-EXPERT-L13 — Preserve protocol identity and measurement meaning

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L12

Follow one transaction through its layers: physical/link path, addressing/routing, transport, session security, application operation, point representation and physical meaning. A valid protocol exception tells you that some lower-layer work succeeded. A successful read tells you that a particular address responded; it does not establish that the address represents the intended sensor or that the sensor is accurate.

Modbus integration needs an explicit point definition. Record unit identity, function, protocol address, manual/API addressing convention, register count, signedness, scale, offset, engineering units and quality/freshness treatment. A manual reference such as 40021 may need translation to a zero-based protocol address, but the client may already perform that translation. Never apply a universal subtraction without checking both conventions. A documented signed raw value of -125 at 0.1 °C/count means -12.5 °C. Treating it as unsigned or omitting scale creates plausible-looking errors without corrupting transport.

Multi-register values need documented word ordering and coherent acquisition. Two separate reads of a changing 32-bit counter can combine words from different source instants. A supported multi-register or snapshot mechanism may be needed; do not invent universal atomicity. Write retries need special care: a lost acknowledgment does not prove the action failed. Define idempotency, command identity, feedback and retry behaviour according to the actual operation.

Serial gateways add downstream identity, baud/parity/framing, physical signal and scheduling dependencies. One failed unit can consume retries and delay healthy units in a sequential poll cycle. Compute the worst relevant cycle from normal transactions and bounded failure waits, then verify it under the required condition.

OPC UA separates channel/session security, user identity and operation authorization. A secure connection can still reject a method or expose too much role authority. Preserve node identity, namespace interpretation, value status and source time. A hard-coded namespace index can become wrong after a server migration even when the namespace URI remains the intended semantic identity. Test approved subscriptions and prohibited writes/methods at the real action interface. Use the official protocol sources and supported product documentation for exact version-specific behaviour.

#### Worked demonstrations

**Preserve protocol identity and measurement meaning — integrated worked case**

Synthetic teaching case; no live equipment was tested.

A client reads a meter through an IP-to-serial gateway. Other units respond, but the replacement meter uses a different unit address. Separately, a temperature register returns -125 and the display shows 6541.1 °C after unsigned conversion.

**Reasoning:** The first fault is localized toward replacement identity/framing rather than the healthy upstream route. The second is a representation error: under the documented signed 0.1 scale it should be -12.5 °C. Both illustrate that successful network operation does not prove correct endpoint selection or engineering interpretation.

#### Guided practice

Twenty sequential polls take at most 80 ms each. One failed unit adds two 500 ms retries. Does a two-second cycle requirement hold?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** The stated bound is 20×0.08 + 2×0.5 = 2.6 seconds, so it does not. Review supported scheduling, timeout/retry and fault-isolation choices while preserving required detection. Do not merely increase the freshness threshold without reassessing the operational requirement.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Create a versioned point table and transaction trace for five synthetic measurements, including signed scaling, multi-register representation, one failed serial unit and an OPC UA role denial. Show the evidence that separates each layer.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Diagnose Modbus and OPC UA integrations by separating transport, addressing, representation, authorization and source quality.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0201 · single · diagnosis**

Which interpretation fits this Modbus trace?

SYNTHETIC ASSESSMENT EVIDENCE: The TCP session is established. A read request receives an exception for an illegal data address. Other supported addresses respond normally.

1. The requested register range or device mapping needs investigation
2. The gateway's IP address is necessarily wrong
3. The requested measurement is zero
4. The firewall is definitely dropping all responses

**Correct option(s):** 1

- Option 1: The explicit application response narrows the failure beyond basic transport.
- Option 2: The responding device may be correct but reject that requested range.
- Option 3: An exception is not a valid zero-valued measurement.
- Option 4: A valid exception response arrived.

**ISA-EXPERT-Q0202 · single · design**

What should the integration record specify to avoid an addressing error?

SYNTHETIC ASSESSMENT EVIDENCE: A manual labels a holding register 40021. The client's API expects a zero-based protocol offset rather than the manual's display notation.

1. Record the documented reference convention and the exact PDU/API address mapping, then verify against a known point
2. Treat a successful response as proof the intended point was read
3. Send 40021 in every client because all software uses the manual label literally
4. Subtract one from every displayed number without checking its convention

**Correct option(s):** 1

- Option 1: Notation must be translated according to the actual device and client conventions.
- Option 2: A wrong but valid address can return plausible data.
- Option 3: Clients differ in reference-number handling.
- Option 4: Some software already applies an offset or uses another notation.

**ISA-EXPERT-Q0203 · single · diagnosis**

What is the likely source of this plausible but incorrect value?

SYNTHETIC ASSESSMENT EVIDENCE: Two consecutive 16-bit registers represent a vendor-documented 32-bit quantity. The client uses the opposite word order and transport checks pass.

1. A valid Modbus response guarantees every vendor's multiword encoding is identical
2. Multi-register representation is decoded incorrectly
3. The sensor must be physically miscalibrated
4. TCP necessarily reordered the application bytes

**Correct option(s):** 2

- Option 1: Multi-register data representation needs device-specific interpretation.
- Option 2: Register delivery can be correct while application assembly is wrong.
- Option 3: The known word-order mismatch should be resolved before that conclusion.
- Option 4: TCP supplies an ordered byte stream; the stated decoding choice is the direct issue.

**ISA-EXPERT-Q0204 · single · calculation**

What engineering value should this documented register produce?

SYNTHETIC ASSESSMENT EVIDENCE: The raw signed 16-bit value is -125. The point definition uses 0.1 °C per count with no offset.

1. -12.5 °C
2. 12.5 °C
3. -125 °C
4. 6541.1 °C

**Correct option(s):** 1

- Option 1: Apply the documented scale to the signed value.
- Option 2: That loses the sign.
- Option 3: That omits the scale factor.
- Option 4: That interprets the two's-complement representation as unsigned before scaling.

**ISA-EXPERT-Q0205 · single · design**

Which test distinguishes wrong unit addressing from a failed gateway?

SYNTHETIC ASSESSMENT EVIDENCE: The IP gateway responds, and serial units 1–4 are healthy. A replacement meter documented as unit 7 was installed using its default unit 1.

1. Assume every timeout proves a physical cable break
2. Permit more enterprise subnets through the firewall
3. Verify the replacement's effective unit identity and downstream communication settings through the approved method
4. Reboot all upstream switches before checking the replacement

**Correct option(s):** 3

- Option 1: Address conflicts can also prevent the intended transaction.
- Option 2: That does not correct the downstream unit identity.
- Option 3: The fault is localized to the replaced downstream addressing context.
- Option 4: The healthy gateway and other units argue for a narrower first test.

**ISA-EXPERT-Q0206 · single · diagnosis**

Which semantics are lost in this protocol gateway?

SYNTHETIC ASSESSMENT EVIDENCE: An authenticated upstream user performs a write. The downstream controller sees only a gateway-originated unauthenticated request and records no upstream identity.

1. A downstream IP address can uniquely identify the human user
2. Individual upstream attribution does not automatically survive translation
3. The downstream controller necessarily receives the upstream certificate
4. The write is read-only because the upstream connection was encrypted

**Correct option(s):** 2

- Option 1: Several users can act through one gateway.
- Option 2: The gateway needs controlled authorization and evidence linkage.
- Option 3: The translated path may carry no such identity.
- Option 4: Encryption does not change operation semantics.

**ISA-EXPERT-Q0207 · single · design**

How should a Modbus write restriction be validated?

SYNTHETIC ASSESSMENT EVIDENCE: The collector may read holding registers but must not write setpoints. The gateway claims operation filtering.

1. Assume that using function 03 in the collector's normal configuration prevents misuse of other functions
2. Test only one read response
3. Test approved reads and representative prohibited write operations at the effective gateway, including supported alternate write paths
4. Block all TCP traffic and count the write denial as complete acceptance

**Correct option(s):** 3

- Option 1: A compromised client may generate different supported requests.
- Option 2: It establishes no write restriction.
- Option 3: A port-level permit cannot alone prove application-operation control.
- Option 4: That also removes required reads.

**ISA-EXPERT-Q0208 · single · diagnosis**

Which polling design risk appears in this trace?

SYNTHETIC ASSESSMENT EVIDENCE: A gateway sends sequential requests to 30 devices. One unavailable device consumes the full retry budget each cycle, delaying fresh data from healthy devices.

1. Every healthy device must also be physically faulty
2. TLS certificate rotation is the primary mechanism
3. A slow or failed unit creates head-of-line delay in the polling schedule
4. Increasing every timeout necessarily improves freshness

**Correct option(s):** 3

- Option 1: The shared polling sequence can explain their delayed updates.
- Option 2: The stated serial polling behaviour is the relevant evidence.
- Option 3: The retry strategy couples otherwise healthy measurements to the failed unit.
- Option 4: Longer waits can worsen the cycle delay.

**ISA-EXPERT-Q0209 · single · calculation**

Does the specified worst-case polling cycle meet the requirement?

SYNTHETIC ASSESSMENT EVIDENCE: Twenty sequential polls each take at most 80 ms. One failed unit adds two 500 ms retries. The required cycle is under 2 seconds, excluding negligible local processing.

1. Yes; retries occur without consuming elapsed time
2. Yes; only the normal 1.6-second polling time matters
3. No; the cycle is necessarily 20 seconds
4. No; the stated bound is 2.6 seconds

**Correct option(s):** 4

- Option 1: Sequential retry waits add to the cycle.
- Option 2: The requirement includes the stated failure condition.
- Option 3: That does not follow from the supplied times.
- Option 4: Twenty times 0.08 plus two times 0.5 equals 2.6 seconds.

**ISA-EXPERT-Q0210 · single · diagnosis**

Why does this successful write response not establish actuator movement?

SYNTHETIC ASSESSMENT EVIDENCE: The gateway acknowledges a setpoint write. The controller is in local mode and its command arbitration ignores supervisory requests.

1. The actuator is necessarily damaged
2. Protocol acceptance is distinct from effective control authority and physical feedback
3. Every write acknowledgment guarantees the actuator reached the target
4. The network must be disconnected despite the response

**Correct option(s):** 2

- Option 1: Local-mode arbitration already provides a plausible non-hardware explanation.
- Option 2: The write can be accepted without being the active command.
- Option 3: The acknowledgment does not establish downstream process completion.
- Option 4: The transaction clearly reached a responding endpoint.

**ISA-EXPERT-Q0211 · single · design**

Which evidence should validate a serial-to-IP gateway replacement?

SYNTHETIC ASSESSMENT EVIDENCE: The replacement has the same IP but defaults to different parity and a different downstream timeout policy.

1. Verify serial framing/addressing, transaction timing, point interpretation and failed-unit behaviour
2. Verify only gateway ping and web login
3. Reduce security controls until polling starts
4. Import the old point names and assume values are equivalent

**Correct option(s):** 1

- Option 1: Address continuity does not preserve downstream communications semantics.
- Option 2: Those checks omit the serial path.
- Option 3: That does not address the known downstream configuration differences.
- Option 4: Names do not prove framing, source or scaling.

**ISA-EXPERT-Q0212 · single · diagnosis**

What is wrong with this multi-register snapshot assumption?

SYNTHETIC ASSESSMENT EVIDENCE: A client reads a changing 32-bit counter in two separate 16-bit requests. The low word rolls over between requests.

1. TCP corruption is the only possible explanation
2. Increasing display precision fixes the snapshot
3. Every pair of register reads is automatically atomic
4. The assembled value may combine two different source states

**Correct option(s):** 4

- Option 1: The stated timing can produce a torn application value without transport corruption.
- Option 2: Formatting cannot restore a coherent source instant.
- Option 3: Atomicity depends on device and operation semantics.
- Option 4: Separate reads need a supported coherent-snapshot method where consistency matters.

**ISA-EXPERT-Q0213 · single · design**

Which engineering decision is needed for a read timeout followed by retry?

SYNTHETIC ASSESSMENT EVIDENCE: The timed-out operation is an actuator command rather than a telemetry read. The first command may have executed before its response was lost.

1. Assume timeout proves the command never arrived
2. Retry indefinitely because all industrial requests are idempotent
3. Suppress all feedback to reduce ambiguity
4. Define command identity, acknowledgment and safe retry/idempotency behaviour

**Correct option(s):** 4

- Option 1: The response can be lost after execution.
- Option 2: Operation effects vary and may repeat physical actions.
- Option 3: Feedback is needed to determine actual state.
- Option 4: Repeating an action may differ from rereading a value.

**ISA-EXPERT-Q0214 · single · diagnosis**

Which layer explains this OPC UA failure?

SYNTHETIC ASSESSMENT EVIDENCE: Network connection succeeds, but the server rejects the client's selected security policy. No application read is attempted.

1. Session security negotiation is incompatible or disallowed
2. The server's data value is necessarily stale
3. The fix is an unrestricted routing rule
4. The sensor's scale factor is invalid

**Correct option(s):** 1

- Option 1: The server's explicit reason localizes the failure before the read.
- Option 2: The session never reached that evidence stage.
- Option 3: Routing already permits the negotiated exchange to reach the server.
- Option 4: No measurement operation occurred.

**ISA-EXPERT-Q0215 · single · design**

What should an OPC UA point mapping preserve?

SYNTHETIC ASSESSMENT EVIDENCE: The integration transfers numerical values but discards status codes and source timestamps.

1. Carry or explicitly translate value, quality/status and source-time semantics into the consumer
2. Drop all values during any status variation without considering the defined application behaviour
3. Replace every source timestamp with the dashboard refresh time
4. Mark every received value good because the secure session is healthy

**Correct option(s):** 1

- Option 1: Numbers alone can hide bad or stale data.
- Option 2: The treatment must follow the point's required semantics, not an arbitrary universal rule.
- Option 3: That conceals acquisition age.
- Option 4: Session health does not establish source measurement quality.

**ISA-EXPERT-Q0216 · single · diagnosis**

Which assumption fails after an OPC UA server migration?

SYNTHETIC ASSESSMENT EVIDENCE: A client uses hard-coded namespace indexes. The new server assigns different indexes to the same namespace URIs, and reads resolve incorrectly.

1. The namespace URI must be changed to match the old numeric index
2. TLS encryption changes the meaning of the node
3. The client treated a session/server-specific index as a stable semantic identity
4. Every NodeId is universally identical across all servers

**Correct option(s):** 3

- Option 1: The URI identifies the namespace; index assignment is a separate mapping.
- Option 2: The mapping issue is independent of transport encryption.
- Option 3: Namespace identity should be resolved according to the supported model.
- Option 4: Identifiers are scoped and must be interpreted correctly.

**ISA-EXPERT-Q0217 · single · design**

Which acceptance test verifies an OPC UA observer role?

SYNTHETIC ASSESSMENT EVIDENCE: The observer must subscribe to selected telemetry but cannot write variables or invoke control methods.

1. Confirm that the observer can establish a secure channel
2. Test the administrator role and infer observer behaviour
3. Hide control nodes in the client display only
4. Test the approved nodes and subscriptions plus denied write/method operations using that role

**Correct option(s):** 4

- Option 1: Channel establishment does not prove operation-level authorization.
- Option 2: Different roles can have different permissions.
- Option 3: A direct client may still request them unless the server enforces authorization.
- Option 4: The role's effective permissions must match both sides of the requirement.

#### Recall

**Twenty sequential polls take at most 80 ms each. One failed unit adds two 500 ms retries. Does a two-second cycle requirement hold?**

The stated bound is 20×0.08 + 2×0.5 = 2.6 seconds, so it does not. Review supported scheduling, timeout/retry and fault-isolation choices while preserving required detection. Do not merely increase the freshness threshold without reassessing the operational requirement.

**In this case, what is the justified integrated decision? A client reads a meter through an IP-to-serial gateway. Other units respond, but the replacement meter uses a different unit address. Separately, a temperature register returns -125 and the display shows 6541.1 °C after unsigned conversion.**

The first fault is localized toward replacement identity/framing rather than the healthy upstream route. The second is a representation error: under the documented signed 0.1 scale it should be -12.5 °C. Both illustrate that successful network operation does not prove correct endpoint selection or engineering interpretation.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)
- [Modbus Organization specification index](https://www.modbus.org/modbus-specifications)
- [OPC Foundation security model](https://reference.opcfoundation.org/specs/OPC-10000-2)
- [OASIS MQTT 5.0 specification](https://docs.oasis-open.org/mqtt/mqtt/v5.0/os/mqtt-v5.0-os.html)

### ISA-EXPERT-L14 — Control messaging and supervisory transformations

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L13

Command delivery is not command authority or physical completion. BACnet commandable properties can have priority arbitration: a lower-priority write may be accepted while a higher-priority entry remains effective. Maintenance handback should relinquish the intended override and verify normal authority resumes. Writing the normal value into the high-priority slot can leave the override active and block later scheduling. Device identity and discovery also need explicit scope; duplicate device instances or uncontrolled routed discovery can undermine binding and intended boundaries.

MQTT separates publish/subscribe permissions, delivery mechanisms and application meaning. Topic access should distinguish telemetry publication, required subscriptions and prohibited control topics. A retained message is stored state that a later subscriber may receive; it is not necessarily a fresh command. A Last Will indicates the broker's configured observation of a client session loss, not proof that physical cooling stopped. Preserve these distinctions in alarms and dashboards.

QoS delivery semantics do not solve every business-action duplication. Two separately published messages can represent the same intended command. Applications may restart, lose state or retry after uncertain execution. Use command identifiers, validity/freshness rules, state-aware execution and feedback appropriate to the process. Test duplicate and expired commands across reconnect rather than only a healthy broker connection.

Every gateway and platform transformation should preserve or explicitly translate source identity, units, value, status/quality, source time and command authority. An authenticated gateway can still map two names to one sensor, convert °C as though it were °F or mark a bad value good. Two dashboards consuming the same wrong source are not independent validation. Use distinct authorized stimuli or independent references to prove source binding.

Historians and CMMS workflows add further semantics. Interpolation across a gap is derived information, not observed measurement. Delayed samples should retain their source times. Alarm retries should not create duplicate work orders when they represent one event, but deduplication must not suppress genuinely new conditions. Define event identity, lifecycle state and idempotency at the receiving application, not merely at the transport.

#### Worked demonstrations

**Control messaging and supervisory transformations — integrated worked case**

Synthetic teaching case; no live equipment was tested.

A maintenance override remains in a high-priority BACnet entry. The BMS writes a normal lower-priority value and receives success. A separate MQTT actuator receives a retained start message when a replacement subscriber connects.

**Reasoning:** The BMS acknowledgment does not prove normal scheduling controls the property; inspect and relinquish the actual priority entry. The MQTT delivery does not prove a current authorized start; evaluate source age, command identity, current permissives and the designed startup policy. Both failures confuse accepted messaging with effective current authority.

#### Guided practice

BMS exports 30 °C. DCIM requires °F, and a historian fills a source outage with interpolation. State the correct value and the evidence labels.

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** The numerical conversion is 1.8×30+32 = 86 °F. Record the conversion and units explicitly. Keep observed samples, acquisition quality and gaps distinguishable from interpolated estimates; a smooth line is not proof of continuous physical observation.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Design a synthetic BMS-to-DCIM-to-CMMS integration with a point mapping, topic/API permission table, event identity and stale/duplicate handling. Demonstrate one accepted message that must not produce a physical action or duplicate work order.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Engineer BACnet, MQTT and cross-platform point handling so accepted messages do not become stale commands or misleading measurements.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0218 · single · diagnosis**

Why does this BACnet command not take effect?

SYNTHETIC ASSESSMENT EVIDENCE: A commandable property has an active higher-priority value. A lower-priority supervisory write is accepted but the present value follows the higher-priority entry.

1. The network necessarily lost the write request
2. Every BACnet write must override every earlier command
3. The device certificate must have expired
4. Command arbitration preserves the higher-priority authority

**Correct option(s):** 4

- Option 1: The accepted write can exist without becoming the winning command.
- Option 2: Priority arbitration determines the effective value.
- Option 3: The stated priority state explains the behaviour.
- Option 4: Acceptance of a lower-priority write does not make it effective.

**ISA-EXPERT-Q0219 · single · design**

Which handback verifies removal of a BACnet override?

SYNTHETIC ASSESSMENT EVIDENCE: Maintenance used a high-priority command. Normal scheduling should regain control after work.

1. Disable all lower-priority scheduling permanently
2. Relinquish the intended priority entry and verify the effective value follows the approved normal authority
3. Reset the HMI display without changing the device's priority state
4. Write the normal value into the high-priority slot and declare handback complete

**Correct option(s):** 2

- Option 1: That abandons the intended operating authority.
- Option 2: Writing another value at the same priority can leave the override active.
- Option 3: Presentation does not clear the command entry.
- Option 4: The high-priority authority remains and may block later schedule changes.

**ISA-EXPERT-Q0220 · single · diagnosis**

What does this duplicated BACnet device identifier threaten?

SYNTHETIC ASSESSMENT EVIDENCE: Two replacement controllers announce the same configured device instance on the integration network.

1. The devices necessarily share the same physical sensor
2. Discovery and binding may associate requests or points ambiguously
3. Encryption of all packets would assign unique instances automatically
4. Different MAC addresses guarantee every application binding is unambiguous

**Correct option(s):** 2

- Option 1: Identity collision does not prove shared wiring.
- Option 2: The logical identity collision needs controlled correction and verification.
- Option 3: Transport protection does not correct configured identifiers.
- Option 4: Higher-layer device identification can still conflict.

**ISA-EXPERT-Q0221 · single · design**

What should be reviewed when enabling BACnet discovery across a routed boundary?

SYNTHETIC ASSESSMENT EVIDENCE: The original zone design assumed local discovery only. A proposed forwarding mechanism would carry discovery traffic between several networks.

1. Assume routed unicast permits automatically validate discovery behaviour
2. Define the required discovery scope, forwarding configuration, exposure and regression tests
3. Forward discovery to every enterprise subnet for convenience
4. Treat discovery messages as incapable of affecting exposure

**Correct option(s):** 2

- Option 1: Broadcast/discovery handling can use different mechanisms.
- Option 2: Discovery reach is an architectural flow decision.
- Option 3: That exceeds the stated integration need.
- Option 4: They can reveal assets and enable unintended interactions.

**ISA-EXPERT-Q0222 · single · diagnosis**

What is the MQTT command risk in this reconnect trace?

SYNTHETIC ASSESSMENT EVIDENCE: A control topic stores a retained start command. A replacement subscriber connects later and receives that retained message before receiving current plant context.

1. TLS prevents the application from executing stale commands
2. Historical retained state can be mistaken for a new authorized command
3. The broker must have duplicated a physical actuator operation
4. Retained delivery proves the command was freshly issued at subscription time

**Correct option(s):** 2

- Option 1: Transport security does not establish command age.
- Option 2: Command freshness and startup semantics need explicit design.
- Option 3: Delivery alone does not prove execution; the risk is application interpretation.
- Option 4: Retention preserves an earlier publication.

**ISA-EXPERT-Q0223 · single · design**

Which MQTT design better supports safe command processing?

SYNTHETIC ASSESSMENT EVIDENCE: Commands can be delayed or redelivered across disconnects. The application must reject obsolete actions and avoid repeated effects.

1. Include application command identity, validity/freshness checks and state-aware execution acknowledgment
2. Use retained commands for every actuator without a startup policy
3. Rely only on the topic name and current broker uptime
4. Treat every reconnect as authorization to replay the entire command history

**Correct option(s):** 1

- Option 1: Messaging delivery guarantees alone do not define physical business semantics.
- Option 2: A new subscriber can receive an old command.
- Option 3: Neither establishes command age or prior execution.
- Option 4: That may repeat obsolete physical actions.

**ISA-EXPERT-Q0224 · single · diagnosis**

Which claim overstates MQTT QoS 2?

SYNTHETIC ASSESSMENT EVIDENCE: The client uses QoS 2, but two independently published messages contain the same business command without a shared command identifier.

1. Application command identity remains useful
2. Physical execution still needs feedback and state checks
3. QoS 2 has protocol-level delivery semantics
4. QoS 2 prevents every duplicate business action regardless of application publication

**Correct option(s):** 4

- Option 1: It can distinguish repeated intent across publications and restarts.
- Option 2: Message delivery is not actuator completion.
- Option 3: That is its relevant scope.
- Option 4: Protocol delivery handling does not merge two distinct publications into one business intent.

**ISA-EXPERT-Q0225 · single · design**

Which broker permission set fits a telemetry-only gateway?

SYNTHETIC ASSESSMENT EVIDENCE: The gateway publishes measurements under site/A/telemetry and subscribes only to its configuration-status acknowledgment topic. It must not publish control commands.

1. Allow all publishes but restrict subscriptions
2. Permit only the required publish and subscribe topic scopes and deny command topics
3. Grant read/write access to site/# because the site is trusted
4. Use one shared broker administrator identity for every gateway

**Correct option(s):** 2

- Option 1: Publishing can itself issue unauthorized commands.
- Option 2: Direction and topic authority should follow the integration requirements.
- Option 3: That includes unrelated and possibly control topics.
- Option 4: That broadens authority and weakens source attribution.

**ISA-EXPERT-Q0226 · single · diagnosis**

What does this Last Will signal actually establish?

SYNTHETIC ASSESSMENT EVIDENCE: The broker emits a configured offline message after detecting an abnormal client disconnect. The process controller may still be running locally.

1. The client intentionally completed an orderly shutdown
2. The cooling process has definitely stopped
3. All previously published measurements remain fresh
4. The broker observed loss of the client's messaging session under its configured detection behaviour

**Correct option(s):** 4

- Option 1: A Will commonly concerns abnormal loss rather than that specific conclusion.
- Option 2: Messaging and physical operation are distinct.
- Option 3: Session loss can make their age increase.
- Option 4: It does not directly prove physical process failure.

**ISA-EXPERT-Q0227 · single · design**

How should delayed MQTT telemetry be handled after a partition?

SYNTHETIC ASSESSMENT EVIDENCE: The broker forwards queued samples when the link returns. The dashboard otherwise stamps every arrival with the current time.

1. Execute control actions based on backlog without checking current plant state
2. Treat every queued value as a new current measurement
3. Preserve source times and quality, distinguish backlog from current state and apply the required freshness policy
4. Discard original timestamps because broker receipt is more recent

**Correct option(s):** 3

- Option 1: Historical telemetry may not justify current action.
- Option 2: Delivery delay does not refresh the physical observation.
- Option 3: Arrival time alone can misrepresent historical data as live.
- Option 4: That hides acquisition age.

**ISA-EXPERT-Q0228 · single · diagnosis**

Which data-model error creates this misleading comparison?

SYNTHETIC ASSESSMENT EVIDENCE: BMS exports chilled-water temperature in °C. DCIM labels the incoming values °F without conversion. Both systems have valid authenticated sessions.

1. Faster polling will make the units converge
2. The two systems need identical network addresses
3. The TLS session must have modified the numerical values
4. The integration's unit transformation and labeling are inconsistent

**Correct option(s):** 4

- Option 1: Frequency does not change the conversion relationship.
- Option 2: Addressing does not correct units.
- Option 3: The stated labeling error is sufficient without transport corruption.
- Option 4: Trustworthy transport can carry semantically wrong presentation.

**ISA-EXPERT-Q0229 · single · calculation**

What value should the receiving application display?

SYNTHETIC ASSESSMENT EVIDENCE: The approved interface converts a measured 30 °C to °F using F = 1.8C + 32.

1. 62 °F
2. 54 °F
3. 86 °F
4. 16.7 °F

**Correct option(s):** 3

- Option 1: That adds 32 without applying the scale.
- Option 2: That omits the offset.
- Option 3: 1.8 times 30 plus 32 equals 86.
- Option 4: That applies an inverse scale incorrectly and omits the offset.

**ISA-EXPERT-Q0230 · single · diagnosis**

Why are two agreeing dashboards not independent measurement validation?

SYNTHETIC ASSESSMENT EVIDENCE: Both BMS and DCIM read the same gateway register, which is mapped to the wrong sensor channel.

1. They share the same source and mapping error
2. The gateway must be unavailable
3. A second dashboard always provides independent redundancy
4. Agreement proves the physical sensor is calibrated

**Correct option(s):** 1

- Option 1: Agreement between consumers can reproduce one incorrect upstream value.
- Option 2: It can be available and consistently wrong.
- Option 3: Independence depends on the full data path.
- Option 4: Both displays can faithfully show the same wrong source.

**ISA-EXPERT-Q0231 · single · design**

Which historian policy preserves evidential meaning through a data gap?

SYNTHETIC ASSESSMENT EVIDENCE: A source is unavailable for ten minutes. The visualization interpolates a smooth line between the last and next samples.

1. Keep observed samples and gap/quality metadata distinct from derived interpolation
2. Store interpolated points as if the sensor actually measured them
3. Delete the gap indication once the source reconnects
4. Declare every sample before and after the gap invalid

**Correct option(s):** 1

- Option 1: A display estimate must not masquerade as a physical measurement.
- Option 2: That changes the meaning of the evidence.
- Option 3: Historical uncertainty remains relevant.
- Option 4: The known outage does not necessarily invalidate all surrounding observations.

**ISA-EXPERT-Q0232 · single · diagnosis**

What is missing from this BMS-to-CMMS alarm integration?

SYNTHETIC ASSESSMENT EVIDENCE: Every repeated alarm message creates a new work order, including retries of the same event after reconnect.

1. A rule suppressing all recurring alarms permanently
2. Stronger transport encryption alone
3. A faster polling interval
4. Event identity and idempotent workflow handling

**Correct option(s):** 4

- Option 1: That can hide genuine new events as well as retries.
- Option 2: Confidentiality does not deduplicate work orders.
- Option 3: More traffic can increase duplicates.
- Option 4: Message redelivery should not automatically create duplicate business work.

**ISA-EXPERT-Q0233 · single · design**

Which point acceptance test detects a duplicated source binding?

SYNTHETIC ASSESSMENT EVIDENCE: Two distinct pump pressure points have different names but may both map to channel A.

1. Apply distinct authorized stimuli or independent references to each source and verify each destination responds uniquely
2. Compare the point names for spelling differences
3. Verify that both sessions use valid certificates
4. Observe both values while the pumps happen to be at the same pressure

**Correct option(s):** 1

- Option 1: Different names and equal steady-state values cannot prove separate bindings.
- Option 2: Labels do not establish physical source identity.
- Option 3: Authentication does not validate the channel mapping.
- Option 4: That condition can conceal the duplication.

**ISA-EXPERT-Q0234 · single · diagnosis**

What is the effect of suppressing quality flags at a protocol boundary?

SYNTHETIC ASSESSMENT EVIDENCE: The gateway converts every upstream bad-quality sample into a numeric value marked good for the downstream consumer.

1. The conversion improves measurement accuracy
2. The consumer loses information needed to distinguish unreliable measurements from valid process states
3. The gateway is read-only, so quality loss cannot matter
4. The downstream consumer can always infer bad quality from the number alone

**Correct option(s):** 2

- Option 1: It changes metadata, not physical accuracy.
- Option 2: A plausible number can conceal an acquisition failure.
- Option 3: Misleading read data can affect decisions and control.
- Option 4: A plausible in-range value may not reveal failure.

#### Recall

**BMS exports 30 °C. DCIM requires °F, and a historian fills a source outage with interpolation. State the correct value and the evidence labels.**

The numerical conversion is 1.8×30+32 = 86 °F. Record the conversion and units explicitly. Keep observed samples, acquisition quality and gaps distinguishable from interpolated estimates; a smooth line is not proof of continuous physical observation.

**In this case, what is the justified integrated decision? A maintenance override remains in a high-priority BACnet entry. The BMS writes a normal lower-priority value and receives success. A separate MQTT actuator receives a retained start message when a replacement subscriber connects.**

The BMS acknowledgment does not prove normal scheduling controls the property; inspect and relinquish the actual priority entry. The MQTT delivery does not prove a current authorized start; evaluate source age, command identity, current permissives and the designed startup policy. Both failures confuse accepted messaging with effective current authority.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)
- [Modbus Organization specification index](https://www.modbus.org/modbus-specifications)
- [OPC Foundation security model](https://reference.opcfoundation.org/specs/OPC-10000-2)
- [OASIS MQTT 5.0 specification](https://docs.oasis-open.org/mqtt/mqtt/v5.0/os/mqtt-v5.0-os.html)

### ISA-EXPERT-L15 — Integrate time, event delivery and network resilience

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L14

Time evidence has multiple meanings. Preserve source occurrence time, collector receipt time and indexing time where available. A synchronized collector does not remove source clock error or queue delay. Represent uncertain occurrence time as an interval after applying justified offsets. If A lies in 19.8–20.2 seconds and B in 20.6–20.8, A preceded B under those bounds. If intervals overlap, order is unresolved without other evidence. More decimal places improve display precision, not clock accuracy.

Design time as a service dependency. Different applications may need different accuracy, trust, availability and loss behaviour. Certificate validation, event correlation and process synchronization are not identical uses. Record the supported source/path, client synchronization health, clock steps and uncertainty. During investigation, preserve original records and document any normalization. Do not overwrite inconvenient timestamps to make a preferred narrative fit.

Industrial protocol families contain distinct traffic patterns. Supervisory client/server exchanges, multicast event delivery and timing distribution need their actual flows and constraints documented; a generic family-wide allow rule is not a complete design. In EPMS, trustworthy communications and status mapping remain separate from protection-setting acceptance by qualified personnel. SNMP polling can retrieve counters while traps or escalation fail. Syslog can arrive while a parser drops identity or timezone fields. Test each required evidence path end to end.

Redundancy must be evaluated at the required application outcome. Duplicate-path mechanisms can protect delivery against defined failures while still sharing power, management or update causes. Capturing two frame copies does not prove two actuator operations; use message identity and receiver/application evidence. Conversely, a restored route does not guarantee subscription recovery or current data. Measure freshness and transaction completion through the actual failure and reconnect sequence.

A protocol emulator is valuable for logic and interpretation but excludes unmodeled device timing, firmware behaviour and physical signalling. State those limits and retain supported vendor and field gates. The integrated evidence package should follow the measurement or command from source through each transformation to the final operational decision.

#### Worked demonstrations

**Integrate time, event delivery and network resilience — integrated worked case**

Synthetic teaching case; no live equipment was tested.

Gateway ping and TCP state remain healthy. The source timestamp stopped updating, but the dashboard stamps every refresh with current time. During failover, the IDS misses the standby path and queued logs arrive late.

**Reasoning:** Transport and presentation liveness do not establish fresh acquisition. The dashboard must preserve source age and quality. Detection coverage is conditional on the observed path, and receipt order cannot be used as event order for the backlog. Acceptance should test source loss, failover visibility and delayed-record interpretation.

#### Guided practice

A capture shows two copies of one command on a redundant network. What evidence is needed before claiming the actuator operated twice?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** Correlate protocol/message identifiers, receiver duplicate handling, application execution records and physical feedback. Duplicate transmission may be intentional, while application execution depends on the receiving semantics. Preserve the original trace and state capture-point limitations.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Build a synthetic evidence timeline with uncertain clocks, a buffered log source, redundant delivery and a stale measurement. Produce only the ordering and operational conclusions supported by the data, then specify the missing field tests.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Evaluate chronology and end-to-end freshness while preserving the distinct requirements of industrial communications and monitoring services.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0235 · single · calculation**

Which event order is supported by these bounds?

SYNTHETIC ASSESSMENT EVIDENCE: Event A corrected time is 20.0±0.2 s. Event B corrected time is 20.7±0.1 s.

1. B preceded A
2. A preceded B
3. The order is unresolved
4. They occurred simultaneously

**Correct option(s):** 2

- Option 1: That contradicts the nonoverlapping intervals.
- Option 2: A's latest possible time 20.2 is before B's earliest 20.6.
- Option 3: These stated intervals do not overlap.
- Option 4: No common possible time exists under the bounds.

**ISA-EXPERT-Q0236 · single · diagnosis**

Why can receipt order differ from physical event order?

SYNTHETIC ASSESSMENT EVIDENCE: One source buffers logs during a link outage while another source sends immediately. Both collectors are synchronized.

1. Transport and queue delay can reorder arrival relative to occurrence
2. The delayed source necessarily fabricated its records
3. Synchronized collectors force every source event to arrive in order
4. Sorting by packet size reconstructs chronology

**Correct option(s):** 1

- Option 1: Source time and buffering context are needed.
- Option 2: Buffering provides a benign explanation that still needs provenance.
- Option 3: Collector clock alignment does not remove network delay.
- Option 4: Size does not establish occurrence time.

**ISA-EXPERT-Q0237 · single · design**

Which time-service requirement supports both control and investigation?

SYNTHETIC ASSESSMENT EVIDENCE: A site uses time-dependent certificates and correlates events from controllers, gateways and hosts.

1. Specify source trust, permitted paths, accuracy/uncertainty needs, loss behaviour and monitoring for each use
2. Assume one reachable time server proves all clients are synchronized
3. Require many decimal places in every timestamp
4. Disable certificate time checks whenever logs disagree

**Correct option(s):** 1

- Option 1: Different uses can have different tolerances but share dependencies.
- Option 2: Client state and offsets still need evidence.
- Option 3: Display precision does not guarantee accurate clocks.
- Option 4: That discards a trust property without resolving clock quality.

**ISA-EXPERT-Q0238 · single · diagnosis**

What must be investigated before attributing this apparent sequence?

SYNTHETIC ASSESSMENT EVIDENCE: A project change is timestamped before the engineer's login on another host. One clock stepped backward during resynchronization.

1. The clock discontinuity and source-time relationship
2. Rounding both times to the nearest minute removes the issue
3. The engineer conclusively bypassed authentication
4. The project record should be deleted because it conflicts

**Correct option(s):** 1

- Option 1: Raw timestamps may not support the apparent causal order.
- Option 2: Rounding hides precision without correcting the offset.
- Option 3: The time evidence is not yet reliable enough for that attribution.
- Option 4: Conflicting evidence should be preserved and explained.

**ISA-EXPERT-Q0239 · single · design**

Which acceptance test best verifies redundancy for a time-sensitive application?

SYNTHETIC ASSESSMENT EVIDENCE: Network failover restores IP reachability, but the application requires fresh values within a bounded interval.

1. Ping the standby device before the failure
2. Count redundant links in the diagram
3. Measure end-to-end application age and recovery across the actual failure, including session and subscription behaviour
4. Assume every protocol reconnects immediately after routing returns

**Correct option(s):** 3

- Option 1: That does not test the transition and application state.
- Option 2: Topology count is not measured continuity.
- Option 3: Route restoration alone does not establish usable current data.
- Option 4: Clients and servers can have independent timeouts and state.

**ISA-EXPERT-Q0240 · single · diagnosis**

What does this PRP-style dual-path design still need to assess?

SYNTHETIC ASSESSMENT EVIDENCE: An endpoint sends duplicate traffic over two separated LAN paths. Both LANs share the same power distribution and update administrator.

1. Common-cause power and management failures outside the duplicate-frame mechanism
2. Duplicate transmission guarantees independence from every failure
3. The presence of duplication proves a cyberattack
4. Both paths must carry different application values to be useful

**Correct option(s):** 1

- Option 1: Path redundancy does not eliminate shared dependencies.
- Option 2: It addresses a defined communications mechanism, not all site dependencies.
- Option 3: Duplication can be intentional protocol behaviour.
- Option 4: Redundant delivery normally aims to preserve the same intended information.

**ISA-EXPERT-Q0241 · single · design**

How should a packet-analysis exercise avoid confusing duplicate delivery with repeated action?

SYNTHETIC ASSESSMENT EVIDENCE: A redundant network capture shows two copies of one application command frame.

1. Count every captured frame as a separate actuator operation
2. Track protocol/message identity, receiver duplicate handling and physical execution evidence
3. Delete one copy before preserving the original trace
4. Assume duplication is harmless without checking endpoint behaviour

**Correct option(s):** 2

- Option 1: The receiver may discard duplicates.
- Option 2: Frame count alone does not establish how often the application acted.
- Option 3: That removes evidence of the network mechanism.
- Option 4: The deployed receiver and application still need validation.

**ISA-EXPERT-Q0242 · single · diagnosis**

Which distinction matters in an IEC 61850 integration review?

SYNTHETIC ASSESSMENT EVIDENCE: The project groups supervisory client/server exchanges and time-sensitive event traffic under one generic allow-all rule because both belong to IEC 61850.

1. The standard family label eliminates the need for a flow matrix
2. Every service in the family necessarily uses the same transport and destination pattern
3. Different services have distinct delivery, scope and timing requirements
4. Supervisory polling proves event-delivery timing

**Correct option(s):** 3

- Option 1: Actual required communications still need explicit definition.
- Option 2: That is not a safe integration assumption.
- Option 3: A family name does not define one identical network or security behaviour.
- Option 4: The tested service is different.

**ISA-EXPERT-Q0243 · single · design**

Which evidence is needed before relying on a protective status shown in EPMS?

SYNTHETIC ASSESSMENT EVIDENCE: EPMS receives a relay status point through a gateway. The cyber team has verified secure communications but has not checked point meaning or relay configuration.

1. Treat encrypted polling as proof of correct protective settings
2. Verify the source, mapping, quality and status semantics, while keeping protection-setting acceptance with qualified protection personnel
3. Authorize the cyber team to alter trip settings based on the dashboard alone
4. Ignore the status because independent protection exists

**Correct option(s):** 2

- Option 1: It does not validate the relay's protection function.
- Option 2: Supervisory data assurance and protection engineering have distinct scopes.
- Option 3: That exceeds the demonstrated evidence and authority.
- Option 4: Supervisory awareness may still be a required operational function.

**ISA-EXPERT-Q0244 · single · diagnosis**

Why is a successful SNMP poll insufficient for this monitoring claim?

SYNTHETIC ASSESSMENT EVIDENCE: A management platform polls interface counters but never tests trap delivery, collector failure or threshold escalation.

1. SNMP counters cannot provide any useful evidence
2. All monitoring should be replaced by manual inspection
3. Trap delivery is automatically guaranteed by successful polling
4. Polling health does not establish the separate event and response paths

**Correct option(s):** 4

- Option 1: They can support diagnosis within their observed scope.
- Option 2: The missing paths can be engineered and tested.
- Option 3: The direction, configuration and handling can differ.
- Option 4: The claimed monitoring function includes more than obtaining counters.

**ISA-EXPERT-Q0245 · single · design**

How should syslog evidence be validated after changing a collector?

SYNTHETIC ASSESSMENT EVIDENCE: Messages arrive, but the parser merges two device identities and drops the original timezone field.

1. Discard raw records once normalized events exist
2. Change every device clock to match the incorrect parser output
3. Check raw-to-normalized identity, timestamp interpretation and required event fields with known test records
4. Accept the collector because total message volume is unchanged

**Correct option(s):** 3

- Option 1: That removes the basis for checking the transformation.
- Option 2: The parser should be corrected against the intended time model.
- Option 3: Transport success does not prove usable evidence semantics.
- Option 4: Volume can hide parsing corruption.

**ISA-EXPERT-Q0246 · single · diagnosis**

Which failure mechanism is most consistent with this data-age pattern?

SYNTHETIC ASSESSMENT EVIDENCE: Gateway ping is stable. TCP remains established. The source counter stops changing and source timestamps remain old while dashboard refresh timestamps advance.

1. The application data path is stale despite healthy transport and presentation refresh
2. The network cable is conclusively disconnected
3. Every old timestamp proves malicious tampering
4. The dashboard is receiving fresh physical measurements because it redraws

**Correct option(s):** 1

- Option 1: Freshness must follow acquisition, not screen update.
- Option 2: The stated transport observations remain healthy.
- Option 3: Operational acquisition failures can also cause staleness.
- Option 4: Redraw time does not refresh source information.

**ISA-EXPERT-Q0247 · single · design**

Which protocol test should accompany a gateway firmware update?

SYNTHETIC ASSESSMENT EVIDENCE: The update changes retry, timeout and quality-propagation defaults. Normal reads still succeed.

1. Test only one normal read because the protocol version is unchanged
2. Exercise failed-device, delayed-response, reconnect and bad-quality cases with the approved timing semantics
3. Compare only the package hash
4. Disable retries and quality handling universally

**Correct option(s):** 2

- Option 1: Version naming does not cover changed operational behaviour.
- Option 2: The changed defaults matter primarily under degraded conditions.
- Option 3: Package identity does not establish runtime semantics.
- Option 4: The required design determines appropriate settings.

**ISA-EXPERT-Q0248 · single · diagnosis**

What is the risk of treating every lost response as a failed physical action?

SYNTHETIC ASSESSMENT EVIDENCE: A remote reset executes, but its acknowledgment is lost. The supervisory client retries and the process sequence treats a second reset differently.

1. The problem is solved solely by increasing the client timeout
2. Lost acknowledgment proves the first action never occurred
3. TCP always prevents any repeated business request
4. Communication uncertainty can cause unsafe or unintended repeated application effects

**Correct option(s):** 4

- Option 1: A longer wait does not identify prior execution or guarantee safe retry semantics.
- Option 2: Execution can precede response loss.
- Option 3: The application may submit a new request after timeout.
- Option 4: The design needs state-aware acknowledgment and retry semantics.

**ISA-EXPERT-Q0249 · single · design**

What should an end-to-end protocol evidence package contain?

SYNTHETIC ASSESSMENT EVIDENCE: A learner claims a secure and correct sensor-to-DCIM integration after configuring a gateway.

1. Source identity/reference, register/node/topic mapping, units, quality, time, operation permissions, normal/fault tests and explicit limits
2. Only a screenshot of plausible final values
3. Only a packet showing a successful handshake
4. Only a topology diagram naming the protocols

**Correct option(s):** 1

- Option 1: Correctness spans the physical meaning and each transformation, not just connectivity.
- Option 2: Plausibility can conceal common-source, scaling or freshness errors.
- Option 3: That is an intermediate communications result.
- Option 4: The diagram does not prove mapping or behaviour.

**ISA-EXPERT-Q0250 · single · diagnosis**

Which conclusion is appropriate when a protocol emulator passes all tests?

SYNTHETIC ASSESSMENT EVIDENCE: The emulator models register values and access rules but not real device timing, electrical serial behaviour or firmware-specific exceptions.

1. The modeled logic passed; excluded vendor and physical behaviours require separate validation
2. The physical installation is fully commissioned
3. The emulator result should be discarded because it is synthetic
4. The test proves every device implementing the protocol behaves identically

**Correct option(s):** 1

- Option 1: The evidence should follow the emulator's actual scope.
- Option 2: No physical behaviour was tested.
- Option 3: It can establish useful bounded reasoning and implementation behaviour.
- Option 4: Implementations and supported features differ.

#### Recall

**A capture shows two copies of one command on a redundant network. What evidence is needed before claiming the actuator operated twice?**

Correlate protocol/message identifiers, receiver duplicate handling, application execution records and physical feedback. Duplicate transmission may be intentional, while application execution depends on the receiving semantics. Preserve the original trace and state capture-point limitations.

**In this case, what is the justified integrated decision? Gateway ping and TCP state remain healthy. The source timestamp stopped updating, but the dashboard stamps every refresh with current time. During failover, the IDS misses the standby path and queued logs arrive late.**

Transport and presentation liveness do not establish fresh acquisition. The dashboard must preserve source age and quality. Detection coverage is conditional on the observed path, and receipt order cannot be used as event order for the backlog. Acceptance should test source loss, failover visibility and delayed-record interpretation.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)
- [Modbus Organization specification index](https://www.modbus.org/modbus-specifications)
- [OPC Foundation security model](https://reference.opcfoundation.org/specs/OPC-10000-2)
- [OASIS MQTT 5.0 specification](https://docs.oasis-open.org/mqtt/mqtt/v5.0/os/mqtt-v5.0-os.html)

## ISA-EXPERT-M06 — Controls and physical-process integration

### ISA-EXPERT-L16 — Verify the physical-to-logical measurement chain

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L15

A measurement chain includes process connection, sensor, transmitter, wiring, input module, conversion, controller point, gateway mapping and consumer. Each can preserve a plausible number while changing its meaning. An authenticated source can be miscalibrated. A current gateway timestamp can describe repeated acquisition of a frozen transmitter. Two agreeing dashboards can share one wrong mapping. Security assurance therefore needs explicit measurement semantics and appropriate physical reference evidence.

For a nominal linear 4–20 mA range, fraction = (I−4)/16 and engineering value = low + fraction×span. For 0–12 bar at 10 mA, the fraction is 0.375 and value is 4.5 bar. This calculation assumes the configured range and valid measurement conditions. Broken wire, over/underrange, bad quality and stale age are separate states. Clamping every invalid input into a valid range can hide the failure. Do not infer physical accuracy merely from a driver's good flag.

Calibration should distinguish offset, gain, repeatability and relevant nonlinear behaviour using an approved procedure and reference with suitable uncertainty. One midpoint comparison cannot characterize every range error. Record instrument identity, reference status, connection conditions, units and observations. Physical testing needs qualified authorization; software models can exercise conversions and fault handling but cannot certify wiring or calibration.

Digital inputs also have electrical and logical semantics: normal contact state, failure polarity, debounce, latching and reset. A normally closed fault circuit can expose a wire break differently from a replacement normally open contact. Filtering removes noise but can suppress valid short events or delay alarms. Every dependent threshold, historian calculation and permissive must be reviewed when units, range or filtering changes.

Use source-specific stimuli or independent references to prove point binding. Internal PLC forcing can test downstream logic and display paths while bypassing the field wiring. Label that boundary honestly and include physical source-to-terminal-to-point verification in the appropriate commissioning gate.

#### Worked demonstrations

**Verify the physical-to-logical measurement chain — integrated worked case**

Synthetic teaching case; no live equipment was tested.

A replacement pressure transmitter has the right nominal range but lower accuracy. The PLC scale is correct, the gateway marks every sample good and two dashboards agree because both read the same point. An independent calibrated reference exceeds the accepted tolerance.

**Reasoning:** The agreeing software chain does not override the physical discrepancy. Review replacement suitability, calibration, connection and uncertainty. Preserve quality and freshness separately from accuracy. Acceptance must address the actual measurement requirement, not only range and protocol compatibility.

#### Guided practice

A valid leak pulse can last 0.3 seconds. A new debounce suppresses any pulse shorter than 0.5 seconds. What changed?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** The filter now removes a required event, not only noise. Revisit the valid-event duration, noise mechanism and response budget, then test boundary cases using an authorized method. A quieter alarm display is not evidence of improved detection.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Create a measurement-chain dossier for one analog and one digital point. Include conversion calculations, quality/age policy, mapping evidence, reference uncertainty and simulated fault cases, with physical work explicitly gated.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Trace instrumentation identity, scaling, quality, freshness and uncertainty into dependable control and supervisory decisions.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0251 · single · calculation**

What nominal pressure does this configured loop represent?

SYNTHETIC ASSESSMENT EVIDENCE: A 4–20 mA transmitter represents 0–12 bar linearly. The measured input is 10 mA, with good quality and current calibration assumed.

1. 6 bar
2. 10 bar
3. 7.5 bar
4. 4.5 bar

**Correct option(s):** 4

- Option 1: The midpoint current would be 12 mA, not 10 mA.
- Option 2: Current units cannot be read directly as engineering pressure.
- Option 3: That treats 10 mA as a fraction of 16 without subtracting the live-zero offset.
- Option 4: The normalized fraction is (10−4)/16 = 0.375, multiplied by 12 bar.

**ISA-EXPERT-Q0252 · single · diagnosis**

Which condition is hidden by this input conversion?

SYNTHETIC ASSESSMENT EVIDENCE: The analog module reports a broken-wire current. The gateway clamps every out-of-range value to the nearest valid pressure and marks it good.

1. A measurement failure is converted into a plausible process value
2. The clamp improves calibration accuracy
3. The sensor's true pressure is proven to be at the lower limit
4. The network authentication guarantees the clamped value is physically correct

**Correct option(s):** 1

- Option 1: Clamping can erase the diagnostic distinction needed for safe decisions.
- Option 2: It changes reported data without establishing the physical value.
- Option 3: A broken-wire indication is not a valid low-process measurement.
- Option 4: Origin assurance does not repair a failed measurement chain.

**ISA-EXPERT-Q0253 · single · design**

Which calibration evidence distinguishes offset from span error?

SYNTHETIC ASSESSMENT EVIDENCE: A pressure loop is suspected of incorrect scaling. Only one midrange reference comparison has been recorded.

1. Change the scale until the current operating value matches the expected trend
2. Repeat the same midrange reading more often and infer the entire span
3. Compare two dashboards that consume the same gateway value
4. Compare multiple justified reference points across the range using the approved calibration procedure

**Correct option(s):** 4

- Option 1: That can hide the error rather than characterize it.
- Option 2: Repeatability at one point does not establish range accuracy.
- Option 3: They share the same conversion and source chain.
- Option 4: One point cannot generally distinguish offset, gain and nonlinear effects.

**ISA-EXPERT-Q0254 · single · diagnosis**

Why can two-out-of-three voting still fail together?

SYNTHETIC ASSESSMENT EVIDENCE: Three transmitters use independent channels but were all calibrated against the same faulty reference and share one impulse line.

1. Common calibration and process-connection failures can bias all three
2. Majority voting always identifies the physically correct value
3. Voting must therefore never be used
4. Different channel addresses eliminate common causes

**Correct option(s):** 1

- Option 1: Channel count alone does not establish independent measurements.
- Option 2: Correlated errors can form a wrong majority.
- Option 3: It can contribute when its assumptions and failure modes are properly addressed.
- Option 4: Logical addresses do not separate the stated physical dependencies.

**ISA-EXPERT-Q0255 · single · design**

Which point-to-point test addresses a swapped input mapping?

SYNTHETIC ASSESSMENT EVIDENCE: The PLC project is correct, but two similar temperature sensors may be wired to opposite channels.

1. Apply distinguishable authorized stimuli or references and trace each physical source to its intended logical point
2. Compare only the project file hash
3. Verify that both displayed temperatures are plausible
4. Rename the points until the current display looks reasonable

**Correct option(s):** 1

- Option 1: Source-specific evidence reveals a swap hidden by similar steady values.
- Option 2: The physical wiring can differ while the source file remains correct.
- Option 3: Similar environments can conceal swapped channels.
- Option 4: That does not establish the intended physical mapping.

**ISA-EXPERT-Q0256 · single · diagnosis**

What does good quality mean in this evidence set?

SYNTHETIC ASSESSMENT EVIDENCE: The acquisition driver marks a value good. An independent calibrated instrument disagrees beyond the accepted tolerance.

1. The driver considers its acquisition valid under its checks, but physical accuracy remains challenged
2. The physical reference must be wrong because software quality is good
3. The disagreement proves a cyberattack
4. The authenticated source cannot have a sensor fault

**Correct option(s):** 1

- Option 1: Quality flags do not universally encode calibration truth.
- Option 2: The flag is not independent metrology evidence.
- Option 3: An ordinary calibration or mapping defect remains plausible.
- Option 4: Identity does not prevent physical or configuration errors.

**ISA-EXPERT-Q0257 · single · design**

How should a permissive use stale measurement data?

SYNTHETIC ASSESSMENT EVIDENCE: The approved sequence requires a current valid pressure permissive before starting. A last-known good value remains cached after acquisition loss.

1. Treat the last good value as permanently valid until it changes
2. Evaluate quality and age with the pressure condition before authorizing the start
3. Refresh only the display timestamp while retaining the source value
4. Ignore quality because the network session is still established

**Correct option(s):** 2

- Option 1: Loss of updates would preserve authority indefinitely.
- Option 2: The cached numerical value alone does not satisfy the current-valid requirement.
- Option 3: That conceals age rather than restoring measurement.
- Option 4: Transport liveness does not establish fresh acquisition.

**ISA-EXPERT-Q0258 · single · diagnosis**

Which interface assumption causes this alarm inversion?

SYNTHETIC ASSESSMENT EVIDENCE: A replacement contact is configured normally open, while the original fail indication used a normally closed circuit that opened on fault or broken wire.

1. The IP subnet determines the contact polarity
2. The electrical and logical polarity/failure semantics changed
3. The replacement is equivalent because both devices have one digital output
4. Alarm acknowledgment can correct the wiring semantics

**Correct option(s):** 2

- Option 1: Network addressing does not define the electrical signal.
- Option 2: A matching label does not preserve the original fault interpretation.
- Option 3: The output's normal and failure behaviour matters.
- Option 4: Acknowledgment does not change the input's physical meaning.

**ISA-EXPERT-Q0259 · single · design**

Which debounce change needs consequence review?

SYNTHETIC ASSESSMENT EVIDENCE: A new filter removes short nuisance pulses but also suppresses the shortest valid leak-detection signal required by the approved design.

1. Retain the new filter because the trend looks smoother
2. Increase filtering until no alarms occur
3. Review the minimum valid event duration, noise mechanism and resulting detection delay/loss
4. Assume every short pulse is electrical noise

**Correct option(s):** 3

- Option 1: Visual smoothness does not establish detection adequacy.
- Option 2: That can eliminate essential detection.
- Option 3: Filtering must preserve required events while addressing noise.
- Option 4: The specification includes valid short events.

**ISA-EXPERT-Q0260 · single · calculation**

Is the stated alarm-latency budget met?

SYNTHETIC ASSESSMENT EVIDENCE: Sensor processing takes at most 0.4 s, controller filtering 1.2 s, gateway transfer 0.6 s and notification handling 0.5 s. The serial chain must alert within 2.5 s.

1. No; the total must be multiplied by four
2. Yes; the average of the four stages is below 2.5 s
3. Yes; only the largest single stage of 1.2 s matters
4. No; the stated total is 2.7 s

**Correct option(s):** 4

- Option 1: The listed contributions already represent the four stages.
- Option 2: Averaging does not represent end-to-end latency.
- Option 3: The stages occur in sequence under the stated model.
- Option 4: The serial worst-case contributions add beyond the 2.5-second limit.

**ISA-EXPERT-Q0261 · single · diagnosis**

What is wrong with this sensor replacement acceptance?

SYNTHETIC ASSESSMENT EVIDENCE: The replacement has the same nominal range and protocol but worse accuracy than the requirement used to set a narrow alarm threshold.

1. The threshold must be widened without owner review
2. Any replacement with the same range is automatically equivalent
3. A valid certificate compensates for lower accuracy
4. Range and connectivity do not establish required measurement performance

**Correct option(s):** 4

- Option 1: Changing the requirement needs process and risk justification.
- Option 2: Other measurement characteristics remain relevant.
- Option 3: Identity verification does not improve metrology.
- Option 4: The accuracy change can undermine the threshold's intended meaning.

**ISA-EXPERT-Q0262 · single · design**

Which evidence supports a claimed independent reference measurement?

SYNTHETIC ASSESSMENT EVIDENCE: An engineer compares a BMS value with a portable gauge whose calibration is current and whose connection measures the same physical point under the approved procedure.

1. Use the BMS gateway output as the portable gauge's input
2. Record reference identity, calibration status, connection conditions, units, uncertainty and observed comparison
3. Record only that a second number was close
4. Discard the reference uncertainty because the display has many digits

**Correct option(s):** 2

- Option 1: That would share the same measurement chain rather than provide an independent reference.
- Option 2: Independence and applicability need documented physical context.
- Option 3: That omits provenance and uncertainty.
- Option 4: Resolution does not eliminate measurement uncertainty.

**ISA-EXPERT-Q0263 · single · diagnosis**

Which fault is consistent with a fixed plausible value and advancing gateway timestamps?

SYNTHETIC ASSESSMENT EVIDENCE: A transmitter output freezes. The gateway continues polling and stamps each received unchanged value with its own current time.

1. Gateway receipt freshness can mask a stale physical measurement
2. Current gateway timestamps prove the physical sensor is changing correctly
3. Every constant process value is necessarily a frozen sensor
4. The value is trustworthy because it remains within range

**Correct option(s):** 1

- Option 1: The timestamp's meaning and source diagnostics matter.
- Option 2: They show acquisition activity, not physical responsiveness.
- Option 3: A truly stable process is also possible and needs discrimination.
- Option 4: Plausibility alone does not establish correctness.

**ISA-EXPERT-Q0264 · single · design**

How should a four-wire measurement upgrade be assessed in the cyber-integrated programme?

SYNTHETIC ASSESSMENT EVIDENCE: The instrumentation change improves accuracy but also changes I/O modules, driver versions and point scaling in the BMS.

1. Approve it solely from the sensor datasheet
2. Re-run only a remote-access login test
3. Trace physical measurement, controller configuration, software dependencies and supervisory semantics through one controlled change
4. Treat it as purely mechanical and exclude software regression

**Correct option(s):** 3

- Option 1: The installed chain determines the effective result.
- Option 2: That does not validate measurement or integration behaviour.
- Option 3: An instrumentation improvement can affect several lifecycle layers.
- Option 4: The stated modules and mappings change.

**ISA-EXPERT-Q0265 · single · diagnosis**

What is the risk of using a command signal as feedback?

SYNTHETIC ASSESSMENT EVIDENCE: EPMS displays breaker closed from the issued close-request bit rather than the breaker auxiliary contact.

1. A close request always guarantees closure if communications are secure
2. The auxiliary contact is irrelevant because the command is logged
3. The display can report intended action instead of observed equipment state
4. The problem is solved by retaining the request bit longer

**Correct option(s):** 3

- Option 1: Interlocks, local mode or equipment faults can prevent action.
- Option 2: The two signals answer different questions.
- Option 3: Command issuance does not prove mechanical completion.
- Option 4: Persistence does not create physical feedback.

**ISA-EXPERT-Q0266 · single · design**

Which fault-injection plan is appropriate for a measurement-chain lesson?

SYNTHETIC ASSESSMENT EVIDENCE: The learner has an isolated software model and no authorization to manipulate live plant instruments.

1. Mark all software outcomes as site commissioning results
2. Disconnect a production transmitter to obtain realistic evidence without approval
3. Skip fault cases because physical equipment is unavailable
4. Inject synthetic stale, bad-quality, out-of-range and swapped-source conditions, explicitly limiting claims to the model

**Correct option(s):** 4

- Option 1: The evidence is synthetic.
- Option 2: That exceeds the available authorization and can affect operation.
- Option 3: Modelled faults can still teach and verify defined logic properties.
- Option 4: The exercise can test reasoning without pretending to verify physical installation.

**ISA-EXPERT-Q0267 · single · diagnosis**

Why does changing engineering units require more than a display edit?

SYNTHETIC ASSESSMENT EVIDENCE: A pressure point changes from bar to kPa. Alarm thresholds, historian calculations and a control limit still use the old numeric values.

1. Dependent thresholds and calculations must be converted and validated consistently
2. The conversion should be applied independently by each operator during alarms
3. The old limits remain valid because the physical sensor is unchanged
4. Only the unit label matters if the source is authenticated

**Correct option(s):** 1

- Option 1: A unit change propagates through every consumer of the point.
- Option 2: That is not a reliable integrated control design.
- Option 3: The numerical representation changed even if the process did not.
- Option 4: Authentication does not reconcile numerical meaning.

#### Recall

**A valid leak pulse can last 0.3 seconds. A new debounce suppresses any pulse shorter than 0.5 seconds. What changed?**

The filter now removes a required event, not only noise. Revisit the valid-event duration, noise mechanism and response budget, then test boundary cases using an authorized method. A quieter alarm display is not evidence of improved detection.

**In this case, what is the justified integrated decision? A replacement pressure transmitter has the right nominal range but lower accuracy. The PLC scale is correct, the gateway marks every sample good and two dashboards agree because both read the same point. An independent calibrated reference exceeds the accepted tolerance.**

The agreeing software chain does not override the physical discrepancy. Review replacement suitability, calibration, connection and uncertainty. Preserve quality and freshness separately from accuracy. Acceptance must address the actual measurement requirement, not only range and protocol compatibility.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)

### ISA-EXPERT-L17 — Review sequence state and control dynamics

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L16

Use an explicit state model when reasoning about control authority. A simple illustrative pump sequence can distinguish STOPPED, STARTING, RUNNING and FAULT. STARTING begins only with current valid permissives and the approved mode. It needs a bounded deadline for run and process feedback; an output command is not proof of motor operation or flow. Reset can clear a latched fault under specified conditions without automatically issuing a new start. The actual process may require additional stopping, purge or recovery states.

Sequential code order matters. In one illustrative scan, setting RUN true when START is true and then setting RUN false when PERMISSIVE is false leaves RUN false under those stated sequential semantics. Do not infer physical output transitions without knowing the platform's task and I/O update model. Real vendor behaviour, task priorities and worst-case execution need supported tools and representative testing.

Effective runtime includes more than source. Retained values, online forces, mode bits, task periods, library versions and initialization can alter behaviour while the source checksum remains unchanged. Define warm and cold restart policies for each important state item. Retaining every old command is not universally safe; clearing every counter and setpoint is not universally correct. Maintenance handback must restore real input authority and test the relevant denied-permissive case.

Control dynamics also matter to cyber maintenance. A PID implementation can depend on sample time, action direction, output limits and actuator behaviour. Integral accumulation during saturation can create windup; filtering reduces noise while adding delay. A task reorganization or communications change can alter effective update timing even when displayed tuning constants are unchanged. Review the algorithm's implementation and process constraints before changing parameters.

Optimization should preserve constraints. Hysteresis can reduce threshold chatter but may permit a larger process excursion. Reduced pump speed can save energy while threatening minimum flow or standby response. Demonstrate both benefit and required bounds in representative models, then retain authorized physical validation. This teaching provides reasoning models, not universal vendor tuning or safe-output settings.

#### Worked demonstrations

**Review sequence state and control dynamics — integrated worked case**

Synthetic teaching case; no live equipment was tested.

After a diagnostic feature is added, average scan time remains low but occasional bursts miss a sequence deadline. A retained maintenance force also keeps a failed permissive true after a project restore.

**Reasoning:** The timing claim needs worst-case task and interference evidence, not only an average. The force is a separate runtime authority defect that source equality will not detect. Address scheduling through supported design and restore the real permissive path under controlled handback, then test timing and fault transitions.

#### Guided practice

An actuator saturates while error persists, then the process overshoots when the limit clears. What hypotheses and tests should precede tuning?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** Review integral windup, output limits, action direction, sample interval, sensor delay and actual actuator feedback. Use a representative model or authorized bounded experiment to distinguish them. Do not apply a universal gain change from the symptom alone.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Implement or model a versioned state sequence with start feedback, fault latching, reset separation, maintenance mode and restart policy. Supply boundary and failure tests, then analyze one timing or control-dynamic change without claiming field validation.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Evaluate initialization, feedback, retained state, timing and loop changes as part of secure controller integration.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0268 · single · diagnosis**

What does this illustrative scan logic do when START is true and PERMISSIVE is false?

SYNTHETIC ASSESSMENT EVIDENCE: Within one sequential scan: IF START THEN RUN := TRUE; END_IF; IF NOT PERMISSIVE THEN RUN := FALSE; END_IF.

1. RUN must end true because START is evaluated first
2. RUN ends false under the stated execution order
3. The output alternates physically twice regardless of output-update semantics
4. RUN is mathematically undefined in every sequential language

**Correct option(s):** 2

- Option 1: That ignores the subsequent assignment.
- Option 2: The later assignment overrides the earlier one in that scan.
- Option 3: Physical output behaviour depends on the execution platform and update model.
- Option 4: The stated order gives a determinate final value in this illustration.

**ISA-EXPERT-Q0269 · single · design**

Which state-machine rule prevents a reset from becoming an unintended start?

SYNTHETIC ASSESSMENT EVIDENCE: The approved sequence requires a separate deliberate start after a latched fault is cleared.

1. Every reset should clear all permissives to true
2. FAULT plus RESET transitions directly to RUNNING whenever the last command was START
3. FAULT plus valid RESET transitions to STOPPED; START is evaluated separately under current permissives
4. The reset button should directly energize the output for testing

**Correct option(s):** 3

- Option 1: That fabricates process authorization.
- Option 2: That revives old intent rather than requiring the specified deliberate start.
- Option 3: The transition preserves the required distinction between clearing a fault and initiating motion.
- Option 4: That bypasses the defined sequence and authority.

**ISA-EXPERT-Q0270 · single · diagnosis**

Which defect appears in this startup sequence?

SYNTHETIC ASSESSMENT EVIDENCE: The run output turns on and the software enters RUNNING immediately. No auxiliary contact or flow feedback is checked, and no start timeout exists.

1. The sequence is correct whenever the output coil is true
2. Encryption of the HMI command establishes pump flow
3. The sequence equates a command with successful physical operation
4. A faster PLC scan automatically supplies missing feedback

**Correct option(s):** 3

- Option 1: Output intent does not establish motor or process response.
- Option 2: Communications trust does not prove hydraulic performance.
- Option 3: It lacks bounded verification of the required outcome.
- Option 4: Execution speed does not create an observation.

**ISA-EXPERT-Q0271 · single · design**

What should determine retained-state treatment after controller restart?

SYNTHETIC ASSESSMENT EVIDENCE: A controller can retain the previous mode, setpoint, fault latch and last command. The process has different warm-start and cold-start requirements.

1. An explicit approved initialization policy for each state item and restart mode, verified by tests
2. Clear every variable because zero is always safe
3. Let the engineering tool's defaults define the policy without review
4. Retain every variable because continuity is always safer

**Correct option(s):** 1

- Option 1: Retention should follow process intent rather than a universal preserve-or-clear rule.
- Option 2: Some retained state is necessary, and zero is not universally safe.
- Option 3: Defaults may not satisfy the site's sequence requirements.
- Option 4: Stale commands and maintenance flags can be inappropriate.

**ISA-EXPERT-Q0272 · single · diagnosis**

Why does a source checksum comparison miss this control change?

SYNTHETIC ASSESSMENT EVIDENCE: The controller's source project matches the approved release, but an online force holds a failed permissive true.

1. The checksum algorithm must be broken
2. A force is automatically approved if the controller remains in RUN
3. The force alters effective runtime input independently of source bytes
4. The physical input is proven healthy because the logic sees true

**Correct option(s):** 3

- Option 1: It may correctly identify the unchanged source.
- Option 2: Execution mode does not confer change authority.
- Option 3: Runtime authority belongs in acceptance and handback.
- Option 4: The force disconnects that logic value from the actual condition.

**ISA-EXPERT-Q0273 · single · design**

Which watchdog response belongs in a process-specific requirement?

SYNTHETIC ASSESSMENT EVIDENCE: A communication watchdog can hold the last output, de-energize it or request a local fallback. Different actuators have different physical consequences.

1. Use the shortest possible timeout regardless of network jitter
2. Configure every actuator OFF without reviewing the process
3. Always hold the last command indefinitely
4. Specify and validate the required response by function and operating mode

**Correct option(s):** 4

- Option 1: Overly aggressive timing can cause unnecessary transitions.
- Option 2: Off can have different consequences for different devices.
- Option 3: The old command may become inappropriate as conditions change.
- Option 4: No one output convention is universally safe.

**ISA-EXPERT-Q0274 · single · diagnosis**

Which PID mechanism explains this overshoot?

SYNTHETIC ASSESSMENT EVIDENCE: An actuator remains at its upper limit while error persists. When the constraint clears, the output stays high and the process overshoots substantially.

1. Encryption delay necessarily causes every such overshoot
2. Integral accumulation during saturation may be driving windup
3. The proportional term must be zero
4. The sensor is definitely reversed

**Correct option(s):** 2

- Option 1: The stated saturation pattern directly supports a control-dynamic mechanism.
- Option 2: The observation warrants reviewing anti-windup and actuator constraints.
- Option 3: That does not follow from the evidence.
- Option 4: Reversed action is a different hypothesis requiring supporting observations.

**ISA-EXPERT-Q0275 · single · design**

What should be evaluated before changing a loop's sample interval?

SYNTHETIC ASSESSMENT EVIDENCE: The logic retains the same displayed PID constants but runs at half the previous update rate after a task reorganization.

1. Assume unchanged displayed constants guarantee identical behaviour
2. Validate only that the project compiles
3. The controller implementation's time scaling, dynamics, delay and relevant stability/performance tests
4. Double every constant without checking the implementation

**Correct option(s):** 3

- Option 1: The algorithm may use sample time explicitly or implicitly.
- Option 2: Compilation does not establish closed-loop performance.
- Option 3: Discrete control behaviour can depend on execution interval.
- Option 4: That is not a generally valid conversion.

**ISA-EXPERT-Q0276 · single · diagnosis**

Why can a smoothing filter degrade alarm performance?

SYNTHETIC ASSESSMENT EVIDENCE: Noise decreases after increasing the filter time constant, but detection of a rapid temperature excursion arrives too late.

1. The delay proves the network was attacked
2. Filtering adds dynamic delay as well as noise reduction
3. A smoother trace always represents a more current measurement
4. Alarm thresholds are unrelated to filtering

**Correct option(s):** 2

- Option 1: The intentional filter change provides a plausible mechanism.
- Option 2: The change must satisfy both measurement usability and response timing.
- Option 3: Smoothness can hide lag.
- Option 4: The filtered signal determines when a threshold is crossed.

**ISA-EXPERT-Q0277 · single · design**

Which test best checks lead/lag sequence behaviour during maintenance?

SYNTHETIC ASSESSMENT EVIDENCE: One unit is designated lead, the standby is in maintenance mode, and the lead receives a fail-to-start condition.

1. Force the maintenance unit to start regardless of its isolation
2. Accept repeated start commands to the failed lead as sufficient recovery
3. Verify the specified degraded response, inhibited standby selection, alarm/escalation and required operator action
4. Test only healthy automatic alternation with both units available

**Correct option(s):** 3

- Option 1: That violates the maintenance boundary.
- Option 2: Retry alone may not satisfy the required fallback or escalation.
- Option 3: The sequence must handle unavailable redundancy explicitly.
- Option 4: That omits the stated failure and maintenance combination.

**ISA-EXPERT-Q0278 · single · diagnosis**

What defect causes this threshold chatter?

SYNTHETIC ASSESSMENT EVIDENCE: A pump starts whenever pressure is below 5.0 bar and stops whenever it exceeds 5.0 bar. Noise repeatedly crosses that same threshold.

1. The design lacks an appropriate separation or timing mechanism for switching decisions
2. Increasing password length stabilizes the threshold
3. The sensor must be malicious because the value fluctuates
4. Every pressure-controlled pump must use exactly this threshold

**Correct option(s):** 1

- Option 1: Hysteresis or other justified sequence treatment can prevent rapid cycling.
- Option 2: Identity controls do not change switching logic.
- Option 3: Noise and process dynamics are plausible ordinary causes.
- Option 4: Setpoints and switching strategy are process-specific.

**ISA-EXPERT-Q0279 · single · design**

How should a hysteresis change be accepted?

SYNTHETIC ASSESSMENT EVIDENCE: A wider deadband reduces cycling but may let pressure fall closer to a minimum operating limit.

1. Widen the deadband until cycling disappears entirely
2. Accept based only on fewer starts per hour
3. Change only the displayed trend scale to make oscillation look smaller
4. Verify both cycling reduction and required process bounds under representative conditions

**Correct option(s):** 4

- Option 1: That can sacrifice required regulation.
- Option 2: That omits the minimum-pressure requirement.
- Option 3: Presentation does not improve control behaviour.
- Option 4: The optimization must preserve the constraint it could weaken.

**ISA-EXPERT-Q0280 · single · diagnosis**

Which scheduling issue matters after adding diagnostics to a PLC?

SYNTHETIC ASSESSMENT EVIDENCE: Average scan time remains acceptable, but occasional diagnostic bursts delay a time-critical task beyond its deadline.

1. The only correction is to remove all diagnostics permanently
2. Average scan time proves every task deadline is met
3. Worst-case task timing and interference need review
4. Diagnostics cannot influence control timing because they are read-only

**Correct option(s):** 3

- Option 1: A supported scheduling or resource design may satisfy both needs.
- Option 2: The premise includes a missed deadline.
- Option 3: Averages can conceal deadline violations.
- Option 4: Read-only processing can still consume shared CPU and I/O resources.

**ISA-EXPERT-Q0281 · single · design**

Which logic-release evidence supports reproducibility?

SYNTHETIC ASSESSMENT EVIDENCE: A release includes source, compiled load, library versions, hardware/I/O configuration, task settings and test records.

1. Retain only the source because compilation is always deterministic across tools
2. Allow libraries to update automatically after testing without impact review
3. Retain only the controller's current RUN status
4. Bind the exact artifacts and dependencies to the deployed target and observed acceptance state

**Correct option(s):** 4

- Option 1: Tool and dependency differences can change results.
- Option 2: That can invalidate the tested baseline.
- Option 3: That does not identify the application or its behaviour.
- Option 4: The relationship between inputs and effective execution must be traceable.

**ISA-EXPERT-Q0282 · single · diagnosis**

What should be investigated when manual local control works but supervisory control does not?

SYNTHETIC ASSESSMENT EVIDENCE: The actuator responds at the local panel. The BMS request is received, but a mode-arbitration flag selects LOCAL.

1. The effective control-authority mode and approved arbitration logic
2. Every network boundary should be opened
3. The actuator motor is conclusively failed
4. The BMS should bypass local mode automatically

**Correct option(s):** 1

- Option 1: The evidence indicates an intentional or misconfigured authority selection.
- Option 2: The request already arrives.
- Option 3: Local operation contradicts that simple explanation.
- Option 4: That may violate physical maintenance or operational authority.

**ISA-EXPERT-Q0283 · single · design**

Which test proves a temporary bypass was removed?

SYNTHETIC ASSESSMENT EVIDENCE: A maintenance bypass allowed operation despite an unavailable input. The source project is restored afterward.

1. Observe normal operation while the permissive is healthy
2. Restore the real input authority and challenge the failed-permissive case in the effective runtime
3. Compare only the restored source file name
4. Delete the bypass entry from the work order only

**Correct option(s):** 2

- Option 1: That condition cannot reveal a bypass that still forces true.
- Option 2: The prohibited operation must again be blocked by the actual input.
- Option 3: Runtime overrides may remain outside that file.
- Option 4: Documentation does not alter controller state.

**ISA-EXPERT-Q0284 · single · diagnosis**

Why is a logic simulator result insufficient for this timing claim?

SYNTHETIC ASSESSMENT EVIDENCE: The simulator executes a correct sequence but models neither real task scheduling nor field-device response. The report claims a five-second physical start time.

1. A faster laptop makes the physical claim valid
2. The model excludes the mechanisms needed to establish physical elapsed performance
3. The logical transition results are necessarily invalid
4. The missing timing can be filled with the desired requirement and labeled measured

**Correct option(s):** 2

- Option 1: Host simulation speed is not actuator response.
- Option 2: It can verify logical transitions without proving real timing.
- Option 3: They can be correct within the model.
- Option 4: A requirement is not an observation.

#### Recall

**An actuator saturates while error persists, then the process overshoots when the limit clears. What hypotheses and tests should precede tuning?**

Review integral windup, output limits, action direction, sample interval, sensor delay and actual actuator feedback. Use a representative model or authorized bounded experiment to distinguish them. Do not apply a universal gain change from the symptom alone.

**In this case, what is the justified integrated decision? After a diagnostic feature is added, average scan time remains low but occasional bursts miss a sequence deadline. A retained maintenance force also keeps a failed permissive true after a project restore.**

The timing claim needs worst-case task and interference evidence, not only an average. The force is a separate runtime authority defect that source equality will not detect. Address scheduling through supported design and restore the real permissive path under controlled handback, then test timing and fault transitions.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)

### ISA-EXPERT-L18 — Integrate BMS, EPMS, cooling and operational handback

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L17

Digital integration must preserve the distinction between command, status and physical function. An EPMS breaker-closed point sourced from a close-request bit reports intent, not auxiliary-contact feedback. Secure polling of a protection relay does not establish its trip settings. A BMS controller heartbeat establishes some liveness but not equipment readiness when a maintenance isolation or failed permissive remains. Define the actual operational meaning of every point used for decisions.

Cross-discipline interfaces require explicit responsibility. Cybersecurity engineers can assess authorized command paths, identity, network policy and evidence. Qualified electrical personnel retain the applicable switching and protection authority. Controls and mechanical owners establish process sequences, safe operating limits and physical handback. Scope boundaries should identify these dependencies rather than either claiming every discipline or ignoring consequences outside the primary study focus.

Cooling integration should include lead/lag selection, standby readiness, fail-to-start, flow/pressure conditions, leak response, local/supervisory mode and communication loss according to the approved design. Two pumps can share one faulty sensor or central decision path. Local control may continue during BMS isolation while required alarm awareness has a shorter endurance. A manual safeguard needs available trained staff, access and a defined duration.

After maintenance or cyber recovery, reconcile plant state with software assumptions. A valve can remain isolated while the controller project is correct. A high-priority override can block the normal schedule. A new sensor range can invalidate alarm thresholds and historian calculations. Link the work order to the physical asset, calibration, logic/mapping versions, tests, removed bypasses and accepting roles.

An integrated learning capstone can model these interactions in detail and expose errors safely. It must retain the distinction between simulated I/O, vendor implementation and physical commissioning. The intended professional identity is built from the combined evidence and appropriate external gates, not from relabeling one model as universal field competence.

#### Worked demonstrations

**Integrate BMS, EPMS, cooling and operational handback — integrated worked case**

Synthetic teaching case; no live equipment was tested.

A cooling branch is restored from approved software after an incident. A manual valve remains isolated, DCIM marks the standby available from a heartbeat, and BMS alarm suppression for the whole hall was never removed.

**Reasoning:** Three different handback gaps remain: physical process path, readiness semantics and operational awareness. Qualified owners must reconcile the valve and mode, define readiness from the necessary conditions, and remove or explicitly bound suppression with alternate coverage. A green CPU or fresh heartbeat does not close them.

#### Guided practice

A remotely controllable electrical gateway passes encrypted command tests. What additional boundaries must the acceptance record preserve?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** Identify command authorization, local interlocks, actual status feedback and the qualified electrical authority for switching and protection settings. The cyber test proves only its scoped path; it does not authorize defeating interlocks or certify relay protection performance.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Create a cross-discipline handback for a synthetic cooling or EPMS interface change. Include point semantics, physical-state checklist, authority allocation, failed-mode tests, temporary-control closure and specific vendor/field completion gates.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Verify cross-discipline interfaces and physical readiness while preserving qualified authority and bounded programme scope.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0285 · single · design**

Which EPMS integration boundary should remain explicit?

SYNTHETIC ASSESSMENT EVIDENCE: The monitoring system can show protective relay status and issue approved supervisory requests. Protection settings are controlled by a separate qualified team.

1. Distinguish data/command integration tests from protection-setting and electrical acceptance authority
2. Let the cyber integrator approve trip curves after a successful ping
3. Treat EPMS dashboard availability as proof of electrical protection availability
4. Exclude all relay interfaces from the cyber architecture

**Correct option(s):** 1

- Option 1: The interfaces interact, but one test does not confer the other's competence or approval.
- Option 2: Connectivity does not establish protection engineering.
- Option 3: The functions and failure paths are different.
- Option 4: Their communications and command paths still matter.

**ISA-EXPERT-Q0286 · single · diagnosis**

Which common dependency defeats this cooling redundancy claim?

SYNTHETIC ASSESSMENT EVIDENCE: Two pumps have separate controllers but both depend on one unmonitored flow transmitter for automatic selection and fault decisions.

1. A shared measurement failure can mislead both sequences
2. A second BMS display creates an independent sensor
3. The pumps must necessarily fail mechanically together
4. Different pump names establish functional independence

**Correct option(s):** 1

- Option 1: Redundant actuators do not eliminate common sensing dependencies.
- Option 2: It may show the same source value.
- Option 3: The concern is common decision input, not a proven mechanical failure.
- Option 4: Names do not change the shared input.

**ISA-EXPERT-Q0287 · single · design**

How should a leak-response sequence be reviewed before cybersecurity hardening?

SYNTHETIC ASSESSMENT EVIDENCE: Hardening changes service accounts and network paths used to route leak alarms and command a local response. Independent local interlocks also exist.

1. Assume local interlocks make every supervisory path optional
2. Trace detection, notification, command authority and local fallback, then test relevant failure combinations
3. Test only successful user login after hardening
4. Give all leak-alarm accounts administrator rights to avoid denial

**Correct option(s):** 2

- Option 1: Required notification and coordination may still matter.
- Option 2: The change can affect several layers while independent functions need explicit boundaries.
- Option 3: That does not verify the cause-and-effect chain.
- Option 4: That creates excess authority rather than a scoped functional design.

**ISA-EXPERT-Q0288 · single · diagnosis**

What is incomplete after this cyber recovery?

SYNTHETIC ASSESSMENT EVIDENCE: Controllers and BMS run approved software. A maintenance valve remains physically isolated, but restored logic assumes the branch is available.

1. A controller reboot necessarily opens the valve
2. The approved software image must be corrupt
3. Physical plant state has not been reconciled with the recovered control assumptions
4. The BMS should override every field isolation automatically

**Correct option(s):** 3

- Option 1: The valve's physical state may be independent of software restart.
- Option 2: The described mismatch is physical configuration.
- Option 3: Trusted software cannot guarantee the actual process path is ready.
- Option 4: Physical authority and approved handback govern those actions.

**ISA-EXPERT-Q0289 · single · design**

Which acceptance should follow a cooling optimization that reduces pump speed?

SYNTHETIC ASSESSMENT EVIDENCE: Energy use decreases, but minimum flow, differential pressure, standby transitions and high-load response remain requirements.

1. Remove the minimum-flow alarm to avoid new notifications
2. Accept the lower energy number alone
3. Assume cyber controls guarantee hydraulic performance
4. Measure energy benefit together with the operating constraints and degraded-mode behaviour

**Correct option(s):** 4

- Option 1: That hides a potentially violated constraint.
- Option 2: Savings do not establish cooling adequacy.
- Option 3: Security mechanisms do not replace process verification.
- Option 4: Optimization is acceptable only within the required envelope.

**ISA-EXPERT-Q0290 · single · diagnosis**

Why does a healthy DCIM connector not prove current capacity information?

SYNTHETIC ASSESSMENT EVIDENCE: The connector authenticates and sends messages, but it reads a stale BMS cache and CMMS equipment status was never updated after maintenance.

1. Capacity data cannot become stale when timestamps are present
2. The connector's authentication must have failed
3. Transport health is separate from source freshness and cross-system state consistency
4. The correct fix is to increase every displayed capacity value

**Correct option(s):** 3

- Option 1: The meaning and age of the source matter.
- Option 2: The premise says it succeeded.
- Option 3: The final decision can be wrong despite successful messaging.
- Option 4: That would invent state rather than reconcile evidence.

**ISA-EXPERT-Q0291 · single · design**

Which evidence links a work order to a trustworthy controls handback?

SYNTHETIC ASSESSMENT EVIDENCE: A transmitter is replaced, its scale is changed in the PLC and alarm thresholds are adjusted in the BMS.

1. Record only the new sensor serial number
2. Connect the physical asset, calibration, versioned logic/mapping changes, authorized tests and closure of overrides
3. Keep separate unlinked records because different teams did the work
4. Close the work order when the replacement part is installed

**Correct option(s):** 2

- Option 1: Identity omits configuration and observed behaviour.
- Option 2: The work crosses instrumentation, control and supervisory layers.
- Option 3: Unlinked evidence makes end-to-end acceptance difficult.
- Option 4: Installation alone does not prove integrated function.

**ISA-EXPERT-Q0292 · single · diagnosis**

Which interface causes this false availability report?

SYNTHETIC ASSESSMENT EVIDENCE: A standby cooling unit is marked available in DCIM from a controller heartbeat, although its maintenance isolation is active.

1. Liveness is being substituted for operational readiness
2. DCIM can never represent equipment readiness
3. The physical isolation should be ignored because telemetry is current
4. A heartbeat necessarily proves every permissive is true

**Correct option(s):** 1

- Option 1: Readiness must include relevant mode, permissives and physical constraints.
- Option 2: It can when the correct semantics and sources are integrated.
- Option 3: Current telemetry can still describe an unavailable unit.
- Option 4: It establishes only the monitored liveness condition.

**ISA-EXPERT-Q0293 · single · design**

How should a CDU integration be accepted in the study programme?

SYNTHETIC ASSESSMENT EVIDENCE: The learner models temperature, pressure, flow and leak conditions in an isolated simulator. Real equipment and vendor training remain unavailable.

1. Declare full site commissioning because every modeled case passes
2. Demonstrate the modeled sequence and failure handling, then retain explicit vendor, hydraulic and physical commissioning gates
3. Skip leak and low-flow cases because they require physical hardware
4. Replace process limits with arbitrary convenient values and call them vendor settings

**Correct option(s):** 2

- Option 1: The physical dependencies were not exercised.
- Option 2: The simulation supports bounded learning without overstating competence.
- Option 3: Their logic can be modeled while physical proof remains separate.
- Option 4: Illustrative assumptions must not masquerade as equipment requirements.

**ISA-EXPERT-Q0294 · single · diagnosis**

What must be reviewed when an EPMS time-source outage occurs?

SYNTHETIC ASSESSMENT EVIDENCE: Electrical event records remain available, but their clocks drift differently. Operators use their apparent order to infer the initiating event.

1. The first printed timestamp conclusively identifies the initiating device
2. Only the BMS display refresh interval matters
3. All records should be erased because their clocks are imperfect
4. Time uncertainty and alternate causal evidence before attributing sequence

**Correct option(s):** 4

- Option 1: Clock drift can reverse apparent order.
- Option 2: That does not establish relay event occurrence times.
- Option 3: They can retain other useful content and provenance.
- Option 4: Available records may still be useful with bounded chronology.

**ISA-EXPERT-Q0295 · single · design**

Which staffing requirement supports a bounded degraded operating mode?

SYNTHETIC ASSESSMENT EVIDENCE: The design permits local cooling without BMS for one hour only if qualified staff patrol and can act locally.

1. Extend the hour indefinitely if temperatures initially look stable
2. Count an unstaffed alarm mailbox as equivalent coverage
3. Ensure staffing, access, communications, procedures and escalation are actually available for that mode
4. Assume any nearby person can substitute for qualified operators

**Correct option(s):** 3

- Option 1: The approved bound needs reassessment, not assumption.
- Option 2: It does not provide the stated patrol and intervention.
- Option 3: A manual safeguard requires operational resources, not just a written allowance.
- Option 4: Competence and authority matter for the required actions.

**ISA-EXPERT-Q0296 · single · diagnosis**

Which lifecycle gap appears when a controller replacement changes its hardware clock?

SYNTHETIC ASSESSMENT EVIDENCE: The restored logic runs, but sequence event times and certificate validation fail because the device starts with an invalid date.

1. The project source must necessarily be wrong
2. Date errors cannot affect secure integration
3. Time initialization and trust dependencies were omitted from restoration acceptance
4. Disabling every time-dependent check establishes full recovery

**Correct option(s):** 3

- Option 1: The time dependency can fail independently.
- Option 2: Certificates and chronology can depend on time.
- Option 3: Application loading is not the whole effective runtime state.
- Option 4: That bypasses requirements rather than restoring them.

**ISA-EXPERT-Q0297 · single · design**

Which cross-discipline review is needed for a remotely controllable electrical interface?

SYNTHETIC ASSESSMENT EVIDENCE: The cyber design permits a gateway command that can request a breaker operation, subject to local electrical interlocks.

1. Allow the cyber team to defeat local interlocks during testing
2. Omit the command because the local interlock always guarantees safety
3. Treat a permitted TCP port as approval for every switching request
4. Jointly verify authorized command paths, interlock assumptions, feedback and qualified operating authority

**Correct option(s):** 4

- Option 1: That exceeds the bounded integration task and protection authority.
- Option 2: The interlock assumption and residual consequences still need review.
- Option 3: Network reachability is not physical authorization.
- Option 4: Cyber access and electrical consequence must be connected without merging responsibilities.

**ISA-EXPERT-Q0298 · single · diagnosis**

Why is this alarm suppression dangerous during maintenance?

SYNTHETIC ASSESSMENT EVIDENCE: All high-temperature notifications are suppressed for the whole hall while only one sensor is being calibrated. No alternate monitoring is assigned.

1. The calibration certificate compensates for missing hall alarms
2. Longer suppression reduces risk by avoiding operator distraction
3. Every suppression is inherently unacceptable
4. The suppression scope exceeds the maintenance need and removes unrelated required awareness

**Correct option(s):** 4

- Option 1: It addresses measurement quality, not current alarm visibility.
- Option 2: It can prolong undetected conditions beyond the allowed envelope.
- Option 3: Bounded authorized suppression can be necessary with appropriate coverage.
- Option 4: A narrow task should not silently disable wider protection or response evidence.

**ISA-EXPERT-Q0299 · single · design**

Which test best proves a local controller survives supervisory loss as intended?

SYNTHETIC ASSESSMENT EVIDENCE: The requirement includes maintaining a bounded process condition, rejecting stale commands and signaling loss of supervision.

1. Disconnect every protection interface simultaneously without an approved test model
2. Check only that the CPU remains in RUN
3. Restore the link and ignore events during the outage
4. Exercise the loss and restoration while observing process limits, command age handling, alarms and restart behaviour

**Correct option(s):** 4

- Option 1: That changes the scope and can invalidate the intended bounded test.
- Option 2: Execution mode does not establish the required process and command behaviour.
- Option 3: The degraded interval is part of the acceptance claim.
- Option 4: The complete requirement includes function, authority and recovery.

**ISA-EXPERT-Q0300 · single · diagnosis**

Which conclusion is warranted after a full software-only controls capstone?

SYNTHETIC ASSESSMENT EVIDENCE: The learner provides versioned logic, simulated fault traces, calculations and a recovery rehearsal using synthetic I/O.

1. The learner demonstrated the documented analytical and simulated implementation outcomes, with physical and vendor competence still separately assessed
2. The learner is automatically authorized to operate all real data-center plant
3. The work has no value because the I/O was synthetic
4. The simulated timing should be relabeled as measured field performance

**Correct option(s):** 1

- Option 1: The evidence is substantial but bounded by its environment.
- Option 2: A capstone does not confer universal site authority.
- Option 3: It can demonstrate meaningful reasoning and model behaviour.
- Option 4: That would misrepresent the evidence.

#### Recall

**A remotely controllable electrical gateway passes encrypted command tests. What additional boundaries must the acceptance record preserve?**

Identify command authorization, local interlocks, actual status feedback and the qualified electrical authority for switching and protection settings. The cyber test proves only its scoped path; it does not authorize defeating interlocks or certify relay protection performance.

**In this case, what is the justified integrated decision? A cooling branch is restored from approved software after an incident. A manual valve remains isolated, DCIM marks the standby available from a heartbeat, and BMS alarm suppression for the whole hall was never removed.**

Three different handback gaps remain: physical process path, readiness semantics and operational awareness. Qualified owners must reconcile the valve and mode, define readiness from the necessary conditions, and remove or explicitly bound suppression with alternate coverage. A green CPU or fresh heartbeat does not close them.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)

## ISA-EXPERT-M07 — Commissioning and evidence-based acceptance

### ISA-EXPERT-L19 — Design tests that distinguish the claimed property

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L18

A test is useful when its outcome discriminates the property under review. If an observer's write fails because its certificate is expired, the test demonstrates authentication rejection, not role-level write denial. If the controller is offline, a failed programming request does not prove the firewall blocked it. Establish the necessary preconditions, verify an allowed transaction, then challenge a valid prohibited operation so that the result can be attributed to the intended control.

Expected results need an independent basis. A gateway and its test script importing the same wrong conversion table can agree perfectly. Derive expected values from the requirement and an appropriate reference, and keep the oracle's assumptions visible. For a strict age <5 s condition, test just below, exactly at and just above five seconds. Distant normal and extreme values may miss an incorrect equality operator.

Coverage follows the claim. Normal reads repeated many times provide evidence for that transaction, not automatically for denied writes, stale data or restart. State combinations can matter: maintenance mode plus failed lead equipment differs from healthy automatic operation. If four modes and three communication states are all required, the stated cross-product has twelve combinations. Eight passing cases mean eight tested combinations, not full coverage. Where justified equivalence or combinatorial reduction is used, explain it rather than assuming untested states are identical.

Transition tests must preserve relevant initial state. Starting an application after the backup route is active does not test an established subscription through failover. Warm restart does not necessarily cover cold initialization. Peak-load requirements need representative competing workloads, not an idle benchmark. Measure the required endpoint: operator receipt of an actionable alarm is later than source logging or notification API acceptance.

Plan fault injection with scope, expected observations, operational limits, abort and restoration. Use safe synthetic or representative environments where live actions are not authorized. Label excluded physical and vendor behaviours. A modelled fault can teach and verify a defined logic property without pretending to prove field performance.

#### Worked demonstrations

**Design tests that distinguish the claimed property — integrated worked case**

Synthetic teaching case; no live equipment was tested.

An observer write-denial test passes against an offline server using an invalid payload. The team also runs 1,000 normal reads and claims full role and lifecycle coverage.

**Reasoning:** The denial has at least two alternative causes before authorization is reached, so it does not prove the intended role property. Repeated reads support only their tested normal path. Use a responsive authorized lab target, valid requests and separate positive/negative, boundary, stale-source and restart cases with explicit coverage.

#### Guided practice

A requirement limits alarm delivery to 2.5 seconds. Four sequential stages have bounds 0.4, 1.2, 0.6 and 0.5 seconds. Define the conclusion and a useful test.

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** The stated sum is 2.7 seconds, so the design bound exceeds the requirement. Test the actual end-to-end initiating event to actionable recipient under representative load, retaining stage times to locate delay. Averaging the stages or measuring only source logging would not test the requirement.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Write six discriminating tests for one integration: normal operation, valid denied action, exact boundary, failed dependency, state transition and restoration. For each, identify one accidental pass and how the test prevents it.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Construct positive, negative, boundary and transition tests with independent expected results and representative conditions.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0301 · single · design**

Which test oracle can independently verify this gateway scale?

SYNTHETIC ASSESSMENT EVIDENCE: The gateway and its automated test script both import the same conversion table. A defect in that table would affect both outputs.

1. Compare the gateway output with the script more frequently
2. Accept the test because automation cannot make arithmetic mistakes
3. Use a second copy of the same table under another filename
4. Use an independently derived expected result and an approved reference input

**Correct option(s):** 4

- Option 1: Repeated agreement does not remove the shared error.
- Option 2: Automated expectations can encode the same wrong assumption.
- Option 3: That preserves the common defect.
- Option 4: A shared implementation source can make an incorrect output agree with its test.

**ISA-EXPERT-Q0302 · single · diagnosis**

What is missing from this negative test?

SYNTHETIC ASSESSMENT EVIDENCE: The requirement denies observer writes. The tester submits an invalid write payload that every role rejects, including administrators.

1. A larger number of malformed requests
2. A valid operation attempted under the prohibited role
3. A longer wait for the same rejection
4. An observer password change before the test

**Correct option(s):** 2

- Option 1: That still does not isolate authorization.
- Option 2: The malformed request tests syntax rejection, not role-based denial.
- Option 3: Timing does not distinguish parser and authorization failures.
- Option 4: Credential rotation does not make the payload valid.

**ISA-EXPERT-Q0303 · single · design**

Which boundary tests fit this freshness rule?

SYNTHETIC ASSESSMENT EVIDENCE: An illustrative requirement accepts data only when age is strictly less than 5 seconds; age is measured without uncertainty in this model.

1. Test just below 5, exactly 5 and just above 5 seconds
2. Round every age to whole minutes before testing
3. Test only 1 second and 60 seconds
4. Test only exactly 5 and expect acceptance

**Correct option(s):** 1

- Option 1: The boundary cases establish strict inequality behaviour.
- Option 2: That destroys the resolution needed for the requirement.
- Option 3: Those cases can pass with an incorrect boundary operator.
- Option 4: That contradicts the stated strictly-less-than rule.

**ISA-EXPERT-Q0304 · single · diagnosis**

Why does this failover test not prove the declared requirement?

SYNTHETIC ASSESSMENT EVIDENCE: The requirement concerns an active link failure while the application has an established subscription. The test starts the application only after the backup path is already active.

1. An extra ping after startup reproduces the missing session state
2. The backup path can never support the application
3. The transition and established application state were not exercised
4. The requirement should be removed because startup passed

**Correct option(s):** 3

- Option 1: It does not recreate the active-session transition.
- Option 2: The test may prove that narrower startup capability.
- Option 3: Cold startup on the backup path is a different condition.
- Option 4: The failure transition remains required.

**ISA-EXPERT-Q0305 · single · design**

Which stimulus best tests a denied programming path without relying on accidental failure?

SYNTHETIC ASSESSMENT EVIDENCE: The lab controller is currently offline. A programming attempt fails, and the team wants to claim the gateway blocks downloads.

1. Count the offline timeout as a successful access-control test
2. Disconnect the gateway as well to make denial more certain
3. Use an unsupported programming operation the controller never implements
4. Bring the authorized lab target to a known responsive state, verify a permitted operation, then challenge the prohibited programming operation

**Correct option(s):** 4

- Option 1: An unavailable target cannot prove the intended enforcement.
- Option 2: That further obscures the cause.
- Option 3: That tests capability absence, not the specified authorization boundary.
- Option 4: The result must distinguish policy denial from unavailable equipment.

**ISA-EXPERT-Q0306 · single · calculation**

What test-coverage claim is supported?

SYNTHETIC ASSESSMENT EVIDENCE: A matrix defines 4 operating modes and 3 relevant communication states, all combinations required. Eight distinct combinations were executed successfully.

1. 8 of 12 required combinations were tested; four remain untested
2. The four missing cases are automatically covered by similarity
3. 100% coverage because all executed tests passed
4. 8 of 7 combinations were tested

**Correct option(s):** 1

- Option 1: The denominator follows the declared cross-product coverage.
- Option 2: Equivalence needs justification, not assumption.
- Option 3: Pass rate among executed tests is not required-state coverage.
- Option 4: The dimensions combine multiplicatively under the stated matrix.

**ISA-EXPERT-Q0307 · single · design**

How should an alarm-delivery test measure its endpoint?

SYNTHETIC ASSESSMENT EVIDENCE: The requirement is that the duty operator receives an actionable high-temperature alarm within the limit.

1. Stop timing when the source creates a log entry
2. Measure only the operator's reading speed after opening the message
3. Stop timing when the notification API accepts a request
4. Measure from the defined initiating event to delivery at the actual required recipient, preserving intermediate times

**Correct option(s):** 4

- Option 1: That omits transport, routing and notification.
- Option 2: That omits earlier system latency.
- Option 3: Downstream delivery can still fail.
- Option 4: Collector receipt alone is not the operational endpoint.

**ISA-EXPERT-Q0308 · single · diagnosis**

What is wrong with this availability test load?

SYNTHETIC ASSESSMENT EVIDENCE: The application must operate during peak ingestion plus backup. Acceptance uses idle hosts and disables backup to reduce noise.

1. All idle tests are useless
2. The backup should be removed from the requirement without review
3. The system necessarily fails under production load
4. The tested resource condition does not represent the required contention state

**Correct option(s):** 4

- Option 1: They can establish baseline function, but not the stated load requirement.
- Option 2: It is a stated lifecycle function that needs compatible design.
- Option 3: The gap is unproven performance, not a confirmed failure.
- Option 4: A quiet environment may conceal capacity and scheduling failures.

**ISA-EXPERT-Q0309 · single · design**

Which test sequence verifies a latched-fault reset requirement?

SYNTHETIC ASSESSMENT EVIDENCE: The fault must remain latched until the initiating condition clears and an authorized reset occurs; reset must not start the pump.

1. Test reset only from a healthy RUNNING state
2. Cause the fault and immediately issue START until it runs
3. Cause the fault, attempt reset while active, clear the cause without reset, then reset and verify STOPPED
4. Clear the displayed banner and assume the latch cleared correctly

**Correct option(s):** 3

- Option 1: That misses the fault conditions driving the requirement.
- Option 2: That does not verify the required reset behaviour.
- Option 3: Each step distinguishes cause state, latch state and start authority.
- Option 4: Presentation is not the state machine.

**ISA-EXPERT-Q0310 · single · diagnosis**

Which observation makes this test nondiagnostic?

SYNTHETIC ASSESSMENT EVIDENCE: A new firewall rule and an application-role change are applied together. Access begins working, but no intermediate evidence is recorded.

1. The cause can be established by choosing the more complex change
2. The successful transaction proves each change was independently necessary
3. The result cannot isolate which change corrected the original failure
4. Both changes are necessarily wrong because they were simultaneous

**Correct option(s):** 3

- Option 1: Complexity is not evidence of causation.
- Option 2: One or neither may have been necessary.
- Option 3: Coupled changes increase causal ambiguity.
- Option 4: They may be correct, but the explanation is weaker.

**ISA-EXPERT-Q0311 · single · design**

What should a safe fault-injection plan specify?

SYNTHETIC ASSESSMENT EVIDENCE: A representative lab models gateway loss and stale telemetry before a site commissioning window.

1. A promise that every fault injection is harmless because it is a cyber test
2. A general instruction to break something and observe
3. Permission to repeat the same fault on production without site authorization
4. Exact fault, scope, expected observations, abort conditions, restoration and excluded physical claims

**Correct option(s):** 4

- Option 1: Cyber actions can affect operational function.
- Option 2: That is not reproducible or bounded.
- Option 3: Lab success does not confer live-test authority.
- Option 4: The exercise needs controlled conditions and honest boundaries.

**ISA-EXPERT-Q0312 · single · diagnosis**

What does this repeated successful test fail to establish?

SYNTHETIC ASSESSMENT EVIDENCE: The team runs the same normal read operation 1,000 times. No denied write, stale-source or restart case is tested.

1. A guarantee that the system contains no defects of any kind
2. Coverage of the unexercised authority and lifecycle behaviours
3. Any evidence about the normal read operation
4. The exact cause of a future physical actuator failure

**Correct option(s):** 2

- Option 1: No finite narrow test supports that universal claim.
- Option 2: Repeated normal success can support reliability for that case, not unrelated properties.
- Option 3: The repeated observations do provide bounded evidence.
- Option 4: That mechanism was not examined.

**ISA-EXPERT-Q0313 · single · design**

Which evidence makes a timeout test reproducible?

SYNTHETIC ASSESSMENT EVIDENCE: The expected result depends on poll period, retry count, communication timeout and source update interval.

1. Record only the wall-clock date
2. Record the effective timing parameters, stimulus time, source/receipt times and observed transition
3. Use the nominal vendor defaults without checking the configured values
4. Record only the final error message

**Correct option(s):** 2

- Option 1: Date alone cannot reconstruct the timing.
- Option 2: Another engineer needs the relevant configuration and time basis.
- Option 3: Effective settings may differ.
- Option 4: That omits the conditions determining elapsed behaviour.

**ISA-EXPERT-Q0314 · single · diagnosis**

Why is this test's apparent pass misleading?

SYNTHETIC ASSESSMENT EVIDENCE: A required write-denial test runs with an expired client certificate. The session fails before application authorization is evaluated.

1. The observer role is therefore proven least privileged
2. The failure demonstrates certificate rejection, not the intended role-level write denial
3. Expired certificates should be accepted for every negative test
4. The application has no need for authorization because TLS exists

**Correct option(s):** 2

- Option 1: Its action permissions were never reached.
- Option 2: A valid authenticated session is needed to isolate the authorization property.
- Option 3: That would change the intended trust requirement.
- Option 4: Authenticated users still need operation restrictions.

**ISA-EXPERT-Q0315 · single · design**

How should a test cover cached credentials during identity loss?

SYNTHETIC ASSESSMENT EVIDENCE: The design permits a defined emergency workflow when central identity is unavailable. Normal cached logins may behave differently from new logins.

1. Test relevant cached and uncached states, required emergency access and prohibited authority under the outage
2. Clear every cache without recording it and assume the result applies to all users
3. Test only a currently logged-in administrator
4. Infer behaviour from the login-screen appearance

**Correct option(s):** 1

- Option 1: Cache state can change effective availability and permissions.
- Option 2: The test state must be explicit.
- Option 3: That may conceal dependence on cached authority.
- Option 4: Presentation does not reveal credential or token state.

**ISA-EXPERT-Q0316 · single · diagnosis**

Which test-data problem affects this alarm threshold validation?

SYNTHETIC ASSESSMENT EVIDENCE: All injected temperatures are far below or far above the threshold. The implementation mistakenly uses the wrong equality condition at the exact limit.

1. A signed test script guarantees complete boundary coverage
2. The chosen values do not challenge the decision boundary
3. More extreme temperatures necessarily reveal equality errors
4. The threshold requirement is unnecessary if alarms work somewhere

**Correct option(s):** 2

- Option 1: Provenance does not determine the adequacy of test values.
- Option 2: Extreme cases can pass despite an incorrect comparison operator.
- Option 3: They still avoid the boundary.
- Option 4: Exact required behaviour remains important.

**ISA-EXPERT-Q0317 · single · design**

Which test demonstrates restoration of prohibited authority after a rollback?

SYNTHETIC ASSESSMENT EVIDENCE: A rollback returns the old application and database. The old database includes an administrator removed before the update.

1. Verify only the database schema version
2. Confirm the administrator row exists and call it successful rollback
3. Delete all accounts without checking required service
4. Attempt the retired identity's relevant operations and verify current required accounts after reconciliation

**Correct option(s):** 4

- Option 1: That does not establish current identity decisions.
- Option 2: Historical completeness may conflict with current authorization.
- Option 3: That can satisfy denial while destroying required operation.
- Option 4: Rollback must restore usable function without reviving obsolete privilege.

#### Recall

**A requirement limits alarm delivery to 2.5 seconds. Four sequential stages have bounds 0.4, 1.2, 0.6 and 0.5 seconds. Define the conclusion and a useful test.**

The stated sum is 2.7 seconds, so the design bound exceeds the requirement. Test the actual end-to-end initiating event to actionable recipient under representative load, retaining stage times to locate delay. Averaging the stages or measuring only source logging would not test the requirement.

**In this case, what is the justified integrated decision? An observer write-denial test passes against an offline server using an invalid payload. The team also runs 1,000 normal reads and claims full role and lifecycle coverage.**

The denial has at least two alternative causes before authorization is reached, so it does not prove the intended role property. Repeated reads support only their tested normal path. Use a responsive authorized lab target, valid requests and separate positive/negative, boundary, stale-source and restart cases with explicit coverage.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)

### ISA-EXPERT-L20 — Transfer factory evidence to site acceptance

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L19

Factory and site evidence complement each other. Factory testing can establish software logic, configuration and simulated interface behaviour. Site acceptance must address the actual field wiring, physical sources, production identity, network paths, operational modes and local authority. Reuse applicable evidence through a documented equivalence argument; neither discard all factory work nor treat it as automatic proof of every site condition.

Temporary commissioning infrastructure can create false success. A supplier laptop may supply naming, time, licence activation or a routing bridge that disappears at handover. Record these dependencies and test affected functions after their removal. Internal input forcing can verify downstream logic and HMI mapping while bypassing field terminals and sensor behaviour. The report should name that boundary and require appropriate physical point-to-point work.

Stage consequential changes with hold points. A database migration may be irreversible without restoring a paired application/data snapshot. Supported mixed-version operation may exist only before that migration. Check recovery material, current prerequisites and operational authorization before crossing the point where simple rollback stops being possible. A rehearsal should exercise abort and restoration branches, not only the successful path.

Recheck site conditions immediately before testing. An unavailable standby, active mechanical isolation or changed load can invalidate an earlier approval's assumptions. Hold or revise the test through the authorized process. Do not remove a physical isolation merely to make a cyber test pass. Qualified discipline owners retain their operating authority.

At handback, remove temporary accounts, rules, overrides and test dependencies, then verify the final operational baseline. Required function and prohibited authority must both hold. A system that meets timing only with required protection disabled is not accepted under the original protected configuration. Resolve compatibility or explicitly approve a justified alternative rather than hiding the changed test state.

#### Worked demonstrations

**Transfer factory evidence to site acceptance — integrated worked case**

Synthetic teaching case; no live equipment was tested.

A gateway passes factory tests using simulated sensors and a local directory. Site tests rely on a supplier laptop for time and licensing. Before failover testing, the standby unit is isolated for mechanical work.

**Reasoning:** The factory results remain scoped inputs. The site must test real identity and field dependencies, and it must work without the departing laptop. The failover precondition is false, so the team should hold or revise the test with operations rather than forcing the standby into service. Record each open site gate.

#### Guided practice

An application upgrade supports mixed versions until an irreversible schema migration. Where should the principal hold point be, and what should be checked?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** Place it before migration. Verify compatible applications, valid paired recovery material, restore entitlements, current operating prerequisites, authorized staff, outage/fallback decision and abort path. Restoring only the old executable afterward cannot undo an incompatible schema.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Prepare a staged commissioning plan for a gateway/controller/supervisory change. Distinguish reusable factory evidence, site-specific tests, temporary dependencies, physical authority, irreversible steps and final handback checks.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Plan staged commissioning and migration using explicit equivalence, physical interfaces, dependency removal and controlled hold points.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0318 · single · design**

Which FAT-to-SAT transfer is justified?

SYNTHETIC ASSESSMENT EVIDENCE: Factory tests use simulated I/O and a lab directory. Site acceptance uses actual sensors, field wiring, production identity and real network paths.

1. Treat factory success as automatic acceptance of every site dependency
2. Discard all factory evidence because simulation was used
3. Repeat every factory test regardless of relevance while omitting field tests
4. Reuse applicable factory evidence, then test site-specific physical, identity, routing and operational differences

**Correct option(s):** 4

- Option 1: Those dependencies were not exercised.
- Option 2: It can establish useful software and design properties within its scope.
- Option 3: Repetition does not compensate for missing site conditions.
- Option 4: Evidence transfer requires explicit equivalence and remaining scope.

**ISA-EXPERT-Q0319 · single · diagnosis**

What acceptance gap is revealed by a commissioning laptop?

SYNTHETIC ASSESSMENT EVIDENCE: The plant passes tests only while the integrator's laptop supplies DNS and time. The laptop will leave after handover.

1. DNS and time never affect OT service
2. The laptop should remain indefinitely without ownership or hardening
3. The plant is fully accepted because the test values were correct
4. A temporary test dependency is being mistaken for an operational service

**Correct option(s):** 4

- Option 1: They can support identities, naming and chronology.
- Option 2: A permanent dependency needs explicit design and lifecycle control.
- Option 3: They were obtained under an unsustainable configuration.
- Option 4: The installed system lacks or has not demonstrated its permanent dependency path.

**ISA-EXPERT-Q0320 · single · design**

Which migration hold point best protects a dual-server supervisory system?

SYNTHETIC ASSESSMENT EVIDENCE: The supported upgrade permits mixed versions only until database migration. Migration is irreversible without restoring a paired backup.

1. Proceed with migration and check backup availability afterward
2. Assume reinstalling the old executable reverses the schema
3. Update both servers simultaneously because redundancy removes rollback needs
4. Stop before migration to verify recovery material, compatibility, authority and the approved outage/fallback decision

**Correct option(s):** 4

- Option 1: That discovers recovery gaps too late.
- Option 2: The stated migration constraint contradicts that.
- Option 3: Redundancy does not make an incompatible migration reversible.
- Option 4: The hold point precedes the consequential irreversible step.

**ISA-EXPERT-Q0321 · single · diagnosis**

Why does this site test fail to prove physical point mapping?

SYNTHETIC ASSESSMENT EVIDENCE: The engineer forces each PLC input internally and sees the correct HMI value. Field terminals and sensor wiring are never exercised.

1. Internal forcing bypasses the physical source-to-input path
2. Forcing automatically calibrates the sensor
3. The HMI mapping result has no value
4. The field wiring is proven because the point names match

**Correct option(s):** 1

- Option 1: It can test downstream logic and display mapping, not actual wiring.
- Option 2: It substitutes a software value rather than measuring the instrument.
- Option 3: It is useful for the downstream portion tested.
- Option 4: Names do not establish physical continuity or polarity.

**ISA-EXPERT-Q0322 · single · design**

What should happen when site conditions differ from the approved test preconditions?

SYNTHETIC ASSESSMENT EVIDENCE: A standby pump is isolated for mechanical work just before a failover test that assumes it is available.

1. Mark failover passed because the primary remains healthy
2. Hold or revise the test through the authorized process, reassessing consequence and acceptance scope
3. Run unchanged because the test was approved last week
4. Remove the physical isolation without the responsible authority

**Correct option(s):** 2

- Option 1: The required transition has not occurred.
- Option 2: The changed prerequisite can invalidate both safety and the intended result.
- Option 3: Approval was conditional on the documented state.
- Option 4: That exceeds the test team's decision boundary.

**ISA-EXPERT-Q0323 · single · diagnosis**

Which defect can a cold-start test reveal that a warm restart may not?

SYNTHETIC ASSESSMENT EVIDENCE: The application depends on nonretained initialization, device discovery and external identity availability. Warm restart preserves much of the previous state.

1. A guarantee that every warm-start result is invalid
2. The physical sensor calibration drift over years
3. The exact probability of every future outage
4. Failure to establish required state and dependencies from a fully initialized condition

**Correct option(s):** 4

- Option 1: Warm-start evidence remains relevant to that mode.
- Option 2: A cold start is not inherently a calibration test.
- Option 3: A functional test does not directly establish that probability.
- Option 4: Different restart modes can exercise different paths.

**ISA-EXPERT-Q0324 · single · design**

Which staged reconnection plan is strongest after replacing a boundary device?

SYNTHETIC ASSESSMENT EVIDENCE: The replacement must restore telemetry, management and approved support while excluding an obsolete tunnel.

1. Verify local baseline and authority, then required paths in controlled stages, with denial and rollback checks
2. Keep every interface disconnected and declare security acceptance complete
3. Reconnect all historical interfaces before checking the running policy
4. Test only the easiest telemetry path and assume the rest

**Correct option(s):** 1

- Option 1: Staging exposes defects without immediately restoring every historical connection.
- Option 2: Required function is part of the acceptance criteria.
- Option 3: That can expose obsolete authority during validation.
- Option 4: Different services and identities may behave differently.

**ISA-EXPERT-Q0325 · single · diagnosis**

What does this witness signature actually attest?

SYNTHETIC ASSESSMENT EVIDENCE: A witness signs a test sheet prepared by the integrator but did not observe the test or inspect raw evidence. The signature field says witnessed execution.

1. A signature always proves physical attendance
2. The signer can repair provenance by backdating a new signature
3. The recorded attestation exceeds what the witness actually observed
4. The test necessarily never occurred

**Correct option(s):** 3

- Option 1: The statement needs a truthful basis.
- Option 2: Backdating would worsen the accuracy of the record.
- Option 3: Review or document receipt should not be mislabeled as witnessed execution.
- Option 4: The witness gap does not establish that broader conclusion.

**ISA-EXPERT-Q0326 · single · design**

Which acceptance covers a controller replacement's physical and logical identity?

SYNTHETIC ASSESSMENT EVIDENCE: The replacement has the correct model but different channel terminal assignments and a new certificate.

1. Verify hardware/channel mapping, loaded release/runtime state, new trust enrollment and required sequence behaviour
2. Copy the old serial number into a label and treat it as the same device
3. Import the project and reuse the old IP, then stop testing
4. Verify only the certificate chain

**Correct option(s):** 1

- Option 1: Both physical connections and logical authority changed.
- Option 2: A label does not establish the replacement's actual identity.
- Option 3: Those steps do not establish wiring or cryptographic identity.
- Option 4: That omits physical mapping and control function.

**ISA-EXPERT-Q0327 · single · diagnosis**

Why is this cutover rehearsal incomplete?

SYNTHETIC ASSESSMENT EVIDENCE: The team rehearses the successful migration path but not the abort decision, old-state restoration or data reconciliation after a partial cutover.

1. The rollback plan can consist solely of a meeting invitation
2. A successful rehearsal guarantees production cannot fail
3. Rehearsals can never test rollback
4. The recovery branch of the change remains untested

**Correct option(s):** 4

- Option 1: Coordination does not provide technical restoration steps.
- Option 2: Production conditions and execution can differ.
- Option 3: Representative environments can exercise relevant recovery behaviour.
- Option 4: A migration plan needs a feasible response when success assumptions fail.

**ISA-EXPERT-Q0328 · single · design**

How should commissioning handle a failed denial test with normal service healthy?

SYNTHETIC ASSESSMENT EVIDENCE: Telemetry works, but a collector can still invoke an engineering method that the CRS prohibits.

1. Classify the result as purely cosmetic
2. Record the unmet requirement, correct or formally treat it, and retest before claiming the boundary accepted
3. Remove the test from the plan without requirement review
4. Accept because operators can monitor the process

**Correct option(s):** 2

- Option 1: The observed method can change controller state.
- Option 2: Normal function does not offset excessive authority.
- Option 3: That hides the defect.
- Option 4: The denied-operation requirement remains unmet.

**ISA-EXPERT-Q0329 · single · diagnosis**

What should be checked when acceptance passes only with security agents disabled?

SYNTHETIC ASSESSMENT EVIDENCE: The required application workload meets timing after endpoint inspection is turned off. The operational baseline requires that inspection or an approved alternative.

1. The tested configuration differs from the required protected state
2. The agent should be disabled permanently without treatment review
3. The original protected configuration is proven to meet timing
4. The application test must have used incorrect timestamps

**Correct option(s):** 1

- Option 1: Compatibility must be resolved or the alternative explicitly assessed and approved.
- Option 2: That silently removes a required control.
- Option 3: It was not the passing condition.
- Option 4: The configuration difference already explains the acceptance gap.

**ISA-EXPERT-Q0330 · single · design**

Which commissioning observation supports command-authority arbitration?

SYNTHETIC ASSESSMENT EVIDENCE: Local maintenance mode must reject supervisory start while permitting authorized local diagnostics.

1. Force the mode bit remotely to bypass the local condition
2. Test only automatic mode with all controls enabled
3. Confirm that the HMI button is greyed out
4. Test supervisory denial and allowed local actions in the actual maintenance state, then verify controlled return to automatic

**Correct option(s):** 4

- Option 1: That defeats the property being tested.
- Option 2: That misses the mode-specific requirement.
- Option 3: A hidden UI action does not prove backend or controller enforcement.
- Option 4: Both sides of the authority boundary need evidence.

**ISA-EXPERT-Q0331 · single · diagnosis**

Which evidence is absent from a network-only site acceptance?

SYNTHETIC ASSESSMENT EVIDENCE: Packet delivery, firewall denial and host authentication pass. No one tests alarm routing, stale data or actuator feedback.

1. A higher link speed would prove the missing semantics
2. All network evidence is invalid
3. End-to-end operational meaning and outcome
4. The missing tests are automatically covered by the product datasheet

**Correct option(s):** 3

- Option 1: Bandwidth does not validate alarms, quality or feedback.
- Option 2: It can be valid within its tested scope.
- Option 3: A secure communications path is only part of the required service chain.
- Option 4: Product capability does not establish the integrated site behaviour.

**ISA-EXPERT-Q0332 · single · design**

What should a site acceptance deviation record contain?

SYNTHETIC ASSESSMENT EVIDENCE: The team substitutes a simulator for one unavailable physical meter during a required integration test.

1. Assume the same protocol name makes the substitution fully equivalent
2. Identify the substituted boundary, reason, tested properties, excluded physical claims and planned completion gate
3. Remove every successful result from the project
4. Call the simulator the real meter in the final report

**Correct option(s):** 2

- Option 1: Timing, electrical and firmware behaviours can differ.
- Option 2: The deviation must preserve the distinction between modeled and field evidence.
- Option 3: The simulated portion can remain useful if bounded honestly.
- Option 4: That misrepresents the test environment.

**ISA-EXPERT-Q0333 · single · diagnosis**

What is the consequence of retaining factory credentials after site acceptance?

SYNTHETIC ASSESSMENT EVIDENCE: Factory tests use a shared engineering account. Site tests pass, but the account remains active alongside the new named users.

1. The operational baseline retains an unapproved alternate authority path
2. The shared account is harmless because named accounts also exist
3. The site tests prove the shared account can never be misused
4. Factory credentials automatically expire at physical shipment

**Correct option(s):** 1

- Option 1: Named accounts do not cancel the shared credential's permissions.
- Option 2: Either path may remain usable.
- Option 3: Passing normal tests does not establish that restriction.
- Option 4: Technical expiry must be implemented and verified.

**ISA-EXPERT-Q0334 · single · design**

Which final test should follow removal of temporary commissioning infrastructure?

SYNTHETIC ASSESSMENT EVIDENCE: A test switch and supplier laptop supplied routing, licences and diagnostic access during commissioning.

1. Leave undocumented substitutes connected to preserve the pass
2. Keep the prior results without checking the removed dependencies
3. Remove all logs of the temporary infrastructure
4. Re-run affected required functions and recovery/access checks using only the intended operational dependencies

**Correct option(s):** 4

- Option 1: That creates an unowned permanent architecture.
- Option 2: Those results may rely on equipment no longer present.
- Option 3: The records help explain the tested and final states.
- Option 4: The handover configuration must work without temporary helpers.

#### Recall

**An application upgrade supports mixed versions until an irreversible schema migration. Where should the principal hold point be, and what should be checked?**

Place it before migration. Verify compatible applications, valid paired recovery material, restore entitlements, current operating prerequisites, authorized staff, outage/fallback decision and abort path. Restoring only the old executable afterward cannot undo an incompatible schema.

**In this case, what is the justified integrated decision? A gateway passes factory tests using simulated sensors and a local directory. Site tests rely on a supplier laptop for time and licensing. Before failover testing, the standby unit is isolated for mechanical work.**

The factory results remain scoped inputs. The site must test real identity and field dependencies, and it must work without the departing laptop. The failover precondition is false, so the team should hold or revise the test with operations rather than forcing the standby into service. Record each open site gate.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)

### ISA-EXPERT-L21 — Review evidence without overstating acceptance

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L20

Evidence must identify what was tested, where, with which effective versions and preconditions, by what method and with what result. Preserve raw records when feasible and protect their handling. A polished summary can aid review but should not erase timestamps, event IDs or uncertainty needed to check its interpretation. A witness should attest only what was actually observed or reviewed, not imply physical attendance from a later signature.

Separate planned, executed, passed, failed and untested states. A 100% execution rate can coexist with failed mandatory requirements. Removing failures from the denominator does not improve the system. If an expected result changes after a failure, preserve the original requirement and observation, then document the justified approval for any revision. Do not redefine the criterion merely to manufacture a pass.

Measured performance needs an honest boundary. RTO may include preparation, licence/identity recovery and physical handback, not only image copying. A best-case run does not establish consistent compliance when other representative runs exceed the objective. Report variation, conditions and causes. Partial service can be recognized without calling the whole required service restored when history, alarms or authority remain incomplete.

Evidence applicability changes with configuration. A signed report for firmware 5.4 does not automatically cover a later 5.5 release. A point-unit change affects thresholds, calculations and permissives even if network connectivity is unchanged. Use impact analysis to select regression that addresses the changed mechanism. Preserve earlier failed evidence and the approved correction so that reviewers can understand the improvement.

Conditional acceptance should be executable. State the defect, substitute control, owner, duration, observations and closure trigger. Untested high-consequence modes need explicit limits and a completion plan. The purpose is a reviewable engineering decision, not a collection of green screenshots. This distinction is central to an honest full-lifecycle portfolio.

#### Worked demonstrations

**Review evidence without overstating acceptance — integrated worked case**

Synthetic teaching case; no live equipment was tested.

A recovery report cites a 40-minute best run against a 60-minute objective. Another representative run took 95 minutes because licence activation failed. The report omits that run and starts timing only after credentials were retrieved.

**Reasoning:** The report overstates achieved readiness. Preserve both runs, the objective's true start/end boundary, dependency waits and the reasons for variation. The 40-minute result remains a valid bounded observation; it does not erase the 95-minute failure or omitted preparation time. Correct the dependency and retest relevant conditions.

#### Guided practice

A test sheet lists thirty sequential field tests with one manually entered timestamp and no raw timing. What can an independent reviewer conclude?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** The timestamp may represent batch documentation rather than actual execution times. It cannot establish precise sequence or durations. Clarify provenance and retain any other valid observations without inventing missing timing or declaring every functional result false solely from this gap.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Review a synthetic acceptance bundle containing one configuration mismatch, one missing raw record, one failed requirement and one conditional acceptance. Write a bounded decision identifying valid evidence, unsupported claims and concrete completion gates.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Assess provenance, configuration applicability, failed-test disposition and measured performance against the actual acceptance boundary.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0335 · single · diagnosis**

Which evidence claim is unsupported by this screenshot?

SYNTHETIC ASSESSMENT EVIDENCE: A configuration editor shows the approved deny rule. The screenshot does not identify the device, active revision or deployment status.

1. Deployment evidence and an observed transaction would strengthen the claim
2. The editor displayed a deny-rule entry
3. The reviewer should identify the screenshot's source and time
4. The running boundary enforces that rule

**Correct option(s):** 4

- Option 1: They connect intent to execution.
- Option 2: That is the limited visible observation.
- Option 3: Those are relevant provenance details.
- Option 4: The image establishes candidate content at most, not effective behaviour.

**ISA-EXPERT-Q0336 · single · design**

Which evidence package best supports independent reconstruction of a failed test?

SYNTHETIC ASSESSMENT EVIDENCE: An application fails during a controlled gateway restart.

1. Retain only the final pass after a later fix
2. Preserve the test baseline, stimulus, raw logs/traces, clock assumptions, expected result and actual result
3. Replace raw records with a polished timeline that omits uncertainty
4. Keep only a narrative saying communications failed

**Correct option(s):** 2

- Option 1: That hides the initial defect and its treatment.
- Option 2: These let another reviewer follow the causal and acceptance reasoning.
- Option 3: That removes the basis for checking the interpretation.
- Option 4: It lacks the observations needed to localize the failure.

**ISA-EXPERT-Q0337 · single · diagnosis**

What is wrong with editing the expected result after seeing a failure?

SYNTHETIC ASSESSMENT EVIDENCE: The original requirement limits recovery to 60 seconds. A test takes 95 seconds, and the tester changes the expected result to 100 seconds without approval.

1. The system automatically meets the original limit because the new sheet says pass
2. The 95-second measurement must be discarded
3. Any requirement can never be revised after testing
4. The test criterion was changed to fit the observation rather than resolving the requirement

**Correct option(s):** 4

- Option 1: Document editing does not change elapsed behaviour.
- Option 2: It remains evidence of the tested performance.
- Option 3: Revisions can be appropriate through analysis and approval.
- Option 4: A valid revision needs a justified controlled decision.

**ISA-EXPERT-Q0338 · single · design**

How should an evidence bundle distinguish simulated from measured data?

SYNTHETIC ASSESSMENT EVIDENCE: A capstone combines synthetic packet traces, emulator results and one physical reference measurement.

1. Label each source and method, retain provenance and limit claims to the relevant environment
2. Present every artifact under a single production-tested label
3. Exclude synthetic evidence from all learning review
4. Use identical timestamps to make all sources appear coordinated

**Correct option(s):** 1

- Option 1: Mixed evidence can be useful when its origin and scope are explicit.
- Option 2: That overstates the synthetic portions.
- Option 3: It can demonstrate analytical and modeled implementation outcomes.
- Option 4: Artificial alignment would conceal their real basis.

**ISA-EXPERT-Q0339 · single · diagnosis**

Which acceptance statement is most accurate after partial service restoration?

SYNTHETIC ASSESSMENT EVIDENCE: Telemetry is current and roles are correct, but historical alarms remain unavailable and the approved recovery objective includes them.

1. The whole service is fully restored because live values matter most
2. Current telemetry is restored; full required service acceptance remains incomplete
3. No restoration progress occurred at all
4. Delete the historical-alarm requirement because recovery is inconvenient

**Correct option(s):** 2

- Option 1: The approved objective includes additional required functionality.
- Option 2: The missing historical function is still within scope.
- Option 3: The live function and roles are meaningful partial progress.
- Option 4: Scope changes need a justified owner decision.

**ISA-EXPERT-Q0340 · single · design**

Which regression scope follows a point-unit change?

SYNTHETIC ASSESSMENT EVIDENCE: A pressure point changes representation and feeds alarms, historian calculations and a pump permissive.

1. Re-run only network ping tests
2. Repeat every unrelated user-interface test but omit the permissive
3. Retest the changed conversion and all affected consumers, including boundary/fault cases
4. Assume unchanged source hardware means no regression is needed

**Correct option(s):** 3

- Option 1: Connectivity does not validate numerical semantics.
- Option 2: Broad activity does not cover the relevant consequence.
- Option 3: Impact analysis identifies the dependent behaviours that may change.
- Option 4: Representation changes can alter downstream decisions.

**ISA-EXPERT-Q0341 · single · diagnosis**

What limitation belongs on a vendor's benchmark result?

SYNTHETIC ASSESSMENT EVIDENCE: The vendor demonstrates throughput with logging disabled and no certificate validation. The site's required baseline enables both.

1. The benchmark applies to a different configuration and cannot alone establish site performance
2. The product necessarily cannot meet the site requirement
3. The site should disable required controls to match the benchmark
4. Logging and certificate validation never consume resources

**Correct option(s):** 1

- Option 1: Security features can change the workload and resource use.
- Option 2: The benchmark gap requires representative testing, not a conclusive failure claim.
- Option 3: That changes the requirement rather than demonstrating compliance.
- Option 4: They can affect processing and I/O.

**ISA-EXPERT-Q0342 · single · design**

Which review checks whether acceptance evidence is still current?

SYNTHETIC ASSESSMENT EVIDENCE: A system passed SAT, then its gateway firmware, routing and identity roles changed over six months.

1. Assume minor maintenance can never affect security or function
2. Trace each change to affected requirements and obtain appropriate current-state regression evidence
3. Rely indefinitely on the original report because it is signed
4. Repeat only the report's cover-page approval

**Correct option(s):** 2

- Option 1: The listed changes directly influence both.
- Option 2: Assurance must follow the effective system, not only the historical handover.
- Option 3: A signature does not cover later configurations.
- Option 4: Administrative repetition does not test changed behaviour.

**ISA-EXPERT-Q0343 · single · diagnosis**

What is the weakness in this defect-closure record?

SYNTHETIC ASSESSMENT EVIDENCE: The ticket says fixed by restarting. No root cause, final configuration or recurrence test is recorded after an intermittent outage.

1. The absence of a root cause proves malicious activity
2. Restarting is never a legitimate response
3. The record shows a recovery action but not a sustained correction or its evidence
4. A closed ticket guarantees the defect cannot recur

**Correct option(s):** 3

- Option 1: Uncertainty does not establish attribution.
- Option 2: It may be appropriate under the operating procedure, but its claim must be bounded.
- Option 3: A restart can restore service temporarily without removing the mechanism.
- Option 4: Administrative status is not a technical guarantee.

**ISA-EXPERT-Q0344 · single · design**

Which measure better distinguishes test completion from risk acceptance?

SYNTHETIC ASSESSMENT EVIDENCE: All planned tests ran, but two mandatory security properties failed and an untested local path remains.

1. Report 100% complete without the failed-property detail
2. Report executed/pass/fail/untested status separately and route residual decisions to the accountable owner
3. Declare every failed test a false positive by default
4. Ask the test tool to grant owner risk acceptance automatically

**Correct option(s):** 2

- Option 1: That can imply acceptance where requirements remain unmet.
- Option 2: Execution completeness and acceptable outcomes are different facts.
- Option 3: Failures need investigation and justified disposition.
- Option 4: A tool result does not supply governance authority.

**ISA-EXPERT-Q0345 · single · diagnosis**

Why does this test report's hash not prove authentic field observations?

SYNTHETIC ASSESSMENT EVIDENCE: The report was hashed after manually invented values were entered; no raw measurements exist.

1. The report's exact bytes cannot be identified because values are invented
2. The hash protects later byte identity, not the truth of the entered observations
3. Hashing automatically verifies the physical instrument
4. A longer hash would convert estimates into measurements

**Correct option(s):** 2

- Option 1: The hash may identify the bytes while their claims remain false.
- Option 2: Integrity of a document is different from evidential validity.
- Option 3: It does not interact with the measurement chain.
- Option 4: Digest length does not establish observation provenance.

**ISA-EXPERT-Q0346 · single · design**

What should an acceptance reviewer require for an untested high-consequence mode?

SYNTHETIC ASSESSMENT EVIDENCE: Normal and maintenance modes pass. Emergency restart was omitted because the team lacked a representative safe environment.

1. An explicit gap, consequence review, interim restrictions or treatment and a defined authorized completion plan
2. Perform the test live immediately without process authorization
3. Assume emergency mode matches normal mode
4. Remove every normal-mode pass from the record

**Correct option(s):** 1

- Option 1: The missing mode cannot be silently included in the achieved claim.
- Option 2: The lack of a safe environment does not authorize uncontrolled action.
- Option 3: Its initialization and authority may differ.
- Option 4: Those results remain valid within their scope.

**ISA-EXPERT-Q0347 · single · diagnosis**

Which performance conclusion is invalid?

SYNTHETIC ASSESSMENT EVIDENCE: The best recovery run took 40 minutes, the worst took 95, and the objective is 60. The report cites only the best run as achieved capability.

1. A 40-minute recovery occurred in one run
2. The test conditions should be compared across runs
3. The service has demonstrated reliable compliance with the 60-minute objective under the tested conditions
4. Variation and failure causes should be investigated

**Correct option(s):** 3

- Option 1: That narrower statement is supported.
- Option 2: Differences may explain performance and define scope.
- Option 3: The omitted overrun materially limits that claim.
- Option 4: They affect operational readiness.

**ISA-EXPERT-Q0348 · single · design**

Which acceptance record supports a bounded conditional handover?

SYNTHETIC ASSESSMENT EVIDENCE: A minor monitoring defect is accepted temporarily because an independent manual process provides required coverage for one month.

1. Mark the monitoring feature fully functional
2. Leave the manual process unnamed because it is temporary
3. Let the condition renew automatically forever
4. Document the exact defect, substitute coverage, owner, duration, verification and closure trigger

**Correct option(s):** 4

- Option 1: The defect still exists.
- Option 2: Temporary coverage still needs ownership and evidence.
- Option 3: The bounded decision requires reassessment or completion.
- Option 4: Conditional acceptance needs executable conditions and a time boundary.

**ISA-EXPERT-Q0349 · single · diagnosis**

What should a reviewer infer from identical timestamps on every test result?

SYNTHETIC ASSESSMENT EVIDENCE: Thirty sequential physical tests all carry the same manually entered completion time, and no raw time records are retained.

1. The timestamps may be batch documentation and cannot establish the actual sequence or durations
2. The report proves exact end-to-end latency for each case
3. Every test definitely occurred simultaneously
4. Every functional result is necessarily false

**Correct option(s):** 1

- Option 1: The evidence needs clarification rather than invented precision.
- Option 2: The timestamps lack that resolution and provenance.
- Option 3: The data does not establish that physical claim.
- Option 4: The time weakness does not alone disprove all other observations.

**ISA-EXPERT-Q0350 · single · design**

Which final capstone assessment best reflects the intended engineering identity?

SYNTHETIC ASSESSMENT EVIDENCE: The learner can explain standards and configure a lab, but the programme also seeks sustained operation, diagnosis and recovery evidence.

1. Treat official credentials as a substitute for all site-specific practice
2. Require only an attractive architecture diagram
3. Require an integrated requirement-to-evidence campaign with failures, controlled changes, handback and honest external gates
4. Count question answers alone as proof of every practical capability

**Correct option(s):** 3

- Option 1: Credentials and contextual practical evidence serve complementary purposes.
- Option 2: Design representation is narrower than full lifecycle execution.
- Option 3: The assessment should demonstrate the lifecycle claims it makes.
- Option 4: Knowledge assessment does not exercise all implementation and physical skills.

#### Recall

**A test sheet lists thirty sequential field tests with one manually entered timestamp and no raw timing. What can an independent reviewer conclude?**

The timestamp may represent batch documentation rather than actual execution times. It cannot establish precise sequence or durations. Clarify provenance and retain any other valid observations without inventing missing timing or declaring every functional result false solely from this gap.

**In this case, what is the justified integrated decision? A recovery report cites a 40-minute best run against a 60-minute objective. Another representative run took 95 minutes because licence activation failed. The report omits that run and starts timing only after credentials were retrieved.**

The report overstates achieved readiness. Preserve both runs, the objective's true start/end boundary, dependency waits and the reasons for variation. The 40-minute result remains a valid bounded observation; it does not erase the 95-minute failure or omitted preparation time. Correct the dependency and retest relevant conditions.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)

## ISA-EXPERT-M08 — Sustained maintenance and operating campaigns

### ISA-EXPERT-L22 — Operate an evidence pipeline

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L21

Monitoring is a pipeline: source event generation, transport, parsing, identity/time normalization, storage, analytic decision, notification and operational response. A healthy agent heartbeat does not establish every stage. A parser can drop user fields while message volume remains unchanged. Two source IDs can be merged into one asset. An alert can reach a notification API but never reach the duty recipient. Validate known benign records through the complete required path.

Counter reasoning needs time and generation. For a monotonic counter, rate = (C2−C1)/(t2−t1) only when the samples share a continuous counter lifetime and the interval is valid. A restart, reset or wrap needs explicit treatment. A large historical CRC total may be irrelevant to today's outage if it does not increase, while queue drops rise during backup. Choose observation resolution that can reveal bursts rather than relying only on long averages.

Queues connect collection to availability. With capacity K and constant input/output rates rin and rout, an initially empty queue fills in K/(rin−rout) when input exceeds output. State units, initial occupancy and assumptions. A 180,000-event queue growing at 300 events/s lasts 600 seconds. Real bursts, variable sizes, indexing and persistence behaviour need additional evidence. After a partition, preserve occurrence times so delayed records are not all interpreted as current simultaneous activity.

Detection needs context without blanket suppression. An approved maintenance window does not authorize every target or project. Correlate actor, work order, artifact and action where feasible. Distinguish alarm acknowledgment from condition clearance. Monitor loss of expected health evidence so a failed collector does not make the site appear quiet. Measure usable end-to-end freshness and response latency, not only server uptime or rule execution time.

Keep alternative explanations alive. Low flow can follow hardware failure, isolation, wrong logic or unauthorized command. Correlate process, network, identity and change evidence before attributing cause. A supported benign explanation does not prove the absence of all malicious activity; state the visibility and time limits of the conclusion.

#### Worked demonstrations

**Operate an evidence pipeline — integrated worked case**

Synthetic teaching case; no live equipment was tested.

Raw controller events arrive with user IDs, but normalized SIEM records lose them after a parser update. Meanwhile a backup window produces rising queue drops and stale telemetry even though average CPU remains low.

**Reasoning:** The identity loss localizes to parsing or normalization, so compare matched raw and normalized events. The telemetry symptom supports a resource-path investigation; low CPU does not exclude network or storage contention. Use interval counters and representative load, then verify corrected semantics and freshness rather than only a green service state.

#### Guided practice

A forwarder emits no security events overnight but should send a health record every minute. How can the operating team distinguish legitimate quiet from lost collection?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** Monitor the age and integrity of the expected health path, separately from incident volume, and test its end-to-end arrival. A stale last-green indicator must not remain healthy indefinitely. Retain the limit that one health event does not prove every required security event is parsed correctly.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Create a synthetic monitoring campaign with raw/normalized records, counter snapshots, backlog and one silent-source failure. Diagnose each stage, quantify the relevant limits and write an actionable operator handover.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Diagnose data collection, parsing, time, queueing and alerting failures while measuring the required end-to-end service.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0351 · single · calculation**

What current interface error rate is supported?

SYNTHETIC ASSESSMENT EVIDENCE: Counter generation is unchanged. At 10:00:00 the counter is 12,000; at 10:00:30 it is 12,090. No reset or wrap occurred.

1. Zero because the cumulative total is old
2. 400 errors per second
3. 3 errors per second
4. 90 errors per second

**Correct option(s):** 3

- Option 1: The observed increment establishes current activity.
- Option 2: That divides the historical total by the interval rather than using its delta.
- Option 3: The interval delta is 90 over 30 seconds.
- Option 4: That omits division by elapsed time.

**ISA-EXPERT-Q0352 · single · diagnosis**

Why should these counter samples not be subtracted directly?

SYNTHETIC ASSESSMENT EVIDENCE: The first sample is from boot generation A. The second is from boot generation B after a restart and has a smaller value.

1. They do not share a continuous counter lifetime
2. The second sample should be increased until the desired rate appears
3. A smaller value proves negative traffic occurred
4. Every restart makes all future counters useless

**Correct option(s):** 1

- Option 1: A reset changes the baseline and invalidates the naive delta.
- Option 2: That invents evidence.
- Option 3: Counters do not represent negative physical events.
- Option 4: New-generation measurements can be useful with their own baseline.

**ISA-EXPERT-Q0353 · single · calculation**

How long can this collector absorb the stated backlog?

SYNTHETIC ASSESSMENT EVIDENCE: Usable queue capacity is 180,000 events. Input is 1,400 events/s and output is 1,100 events/s. The queue starts empty and rates remain constant.

1. The queue never fills because output remains nonzero
2. 128.6 seconds
3. 600 seconds
4. 163.6 seconds

**Correct option(s):** 3

- Option 1: Input exceeds output, so backlog grows.
- Option 2: That ignores continuing output and uses input alone.
- Option 3: Net growth is 300 events/s; 180,000 divided by 300 is 600.
- Option 4: That divides by output rather than net accumulation.

**ISA-EXPERT-Q0354 · single · diagnosis**

Which evidence most directly supports a parser regression?

SYNTHETIC ASSESSMENT EVIDENCE: Raw source events still arrive with user IDs. After a parser update, normalized records retain timestamps and actions but user fields are empty.

1. Assume users stopped authenticating at exactly the update time
2. Replace the controller's network cable before checking parsing
3. Compare raw and normalized records for the same event identifiers under the new parser
4. Increase firewall permits to the source

**Correct option(s):** 3

- Option 1: The raw records contain their IDs.
- Option 2: The specific field loss is not explained by basic link failure.
- Option 3: The loss appears at transformation rather than source generation.
- Option 4: The raw events already arrive.

**ISA-EXPERT-Q0355 · single · design**

Which alert detects collection silence without confusing it with inactivity?

SYNTHETIC ASSESSMENT EVIDENCE: A controller may produce no security events for hours, but a benign heartbeat or health record is expected every minute.

1. Alert whenever no security incident occurs for a minute
2. Use the last green health value indefinitely
3. Monitor the age of that expected health evidence and distinguish it from security-event volume
4. Treat zero events as proof the system is secure

**Correct option(s):** 3

- Option 1: Legitimate quiet periods would create false alarms.
- Option 2: Health data can itself become stale.
- Option 3: A known expected signal supports detection of lost visibility.
- Option 4: Silence can reflect either inactivity or failure.

**ISA-EXPERT-Q0356 · single · diagnosis**

What explains this alert flood after reconnection?

SYNTHETIC ASSESSMENT EVIDENCE: A forwarder queues events during an outage. On reconnect, the SIEM assigns receipt time as occurrence time and triggers a burst rule.

1. The rule is correct because the collector's clock is accurate
2. The forwarder should delete all delayed records without retention
3. Historical backlog is being interpreted as simultaneous current activity
4. Every queued event must represent a new attack at reconnect

**Correct option(s):** 3

- Option 1: Accurate receipt time is still not source occurrence time.
- Option 2: That loses potentially useful evidence.
- Option 3: Original event times and backlog context are needed.
- Option 4: Delivery time does not establish occurrence time.

**ISA-EXPERT-Q0357 · single · design**

Which detection test challenges a maintenance-window blind spot?

SYNTHETIC ASSESSMENT EVIDENCE: A rule suppresses every engineering action during an approved window, regardless of target or project.

1. Perform an approved benign action and a synthetic out-of-scope action within the window, checking differentiated handling
2. Test only an action outside the window
3. Accept zero alerts during the window as proof of successful tuning
4. Remove all maintenance context from detection permanently

**Correct option(s):** 1

- Option 1: Time alone does not authorize every target and content.
- Option 2: That does not expose overbroad suppression within it.
- Option 3: It may indicate loss of relevant coverage.
- Option 4: Context is useful when it is specific and controlled.

**ISA-EXPERT-Q0358 · single · diagnosis**

Which metric reveals unusable evidence despite healthy ingestion?

SYNTHETIC ASSESSMENT EVIDENCE: The SIEM receives all events, but asset identifiers map two different gateways to one normalized object.

1. Number of dashboard users
2. Total bytes ingested per day
3. Identity-mapping accuracy for known source events
4. Collector CPU utilization alone

**Correct option(s):** 3

- Option 1: User count does not validate source identity.
- Option 2: Volume can remain unchanged despite misidentification.
- Option 3: Complete volume does not establish correct attribution.
- Option 4: Resource health does not prove semantic mapping.

**ISA-EXPERT-Q0359 · single · design**

How should an operational alarm be distinguished from a security detection?

SYNTHETIC ASSESSMENT EVIDENCE: Low flow can arise from a failed pump, a closed valve, a wrong command or malicious logic. The cyber alert sees only the low-flow value.

1. Correlate process, command, logic/change and authority evidence before assigning cause
2. Classify every low-flow alarm as confirmed compromise
3. Suppress the alarm until attribution is complete
4. Exclude low flow from security review because it is physical

**Correct option(s):** 1

- Option 1: The same symptom can arise from different mechanisms.
- Option 2: The observation alone does not establish malicious action.
- Option 3: Operational response may be needed before cause is settled.
- Option 4: Cyber actions can affect the physical process.

**ISA-EXPERT-Q0360 · single · diagnosis**

What does this latency distribution show?

SYNTHETIC ASSESSMENT EVIDENCE: Average telemetry delay is 0.4 s, but 2% of samples exceed the required maximum age of 3 s during a backup window.

1. The requirement is met because the mean is low
2. The entire measurement set is invalid because some samples are late
3. The average hides violations of the stated maximum-age requirement
4. Increasing display precision reduces the late-sample rate

**Correct option(s):** 3

- Option 1: A mean does not prove every required deadline.
- Option 2: It contains useful evidence of both normal and failing conditions.
- Option 3: Tail behaviour matters when the requirement is a bound.
- Option 4: Formatting does not change transport or processing delay.

**ISA-EXPERT-Q0361 · single · design**

Which diagnosis best separates congestion from authentication failure?

SYNTHETIC ASSESSMENT EVIDENCE: Outages coincide with queue drops and retransmissions. Server authorization logs show no denied operations, but collection coverage is known complete for that interval.

1. Conclude no cyber risk can ever exist because this interval has no denied logins
2. Reset every service password first because all outages are credential issues
3. Compare transaction timing and resource counters under the backup load, while retaining bounded uncertainty
4. Open every firewall service without measuring the affected queue

**Correct option(s):** 3

- Option 1: The conclusion would exceed the interval and event scope.
- Option 2: That is not supported by the stated observations.
- Option 3: The evidence supports a transport/resource hypothesis over observed authorization denial.
- Option 4: Broader access does not establish or remove congestion.

**ISA-EXPERT-Q0362 · single · diagnosis**

Which event-time claim is valid with overlapping intervals?

SYNTHETIC ASSESSMENT EVIDENCE: A gateway action is bounded to 10.0–11.0 s. A host login is bounded to 10.5–11.5 s. No causal transaction link exists.

1. Their order is unresolved from time alone
2. The gateway action definitely came first because its interval starts earlier
3. The login definitely came first because its interval ends later
4. They must be simultaneous because intervals overlap

**Correct option(s):** 1

- Option 1: Both sequences are possible within the overlap.
- Option 2: Its actual occurrence could be later than the login.
- Option 3: That does not determine actual order.
- Option 4: Overlap indicates uncertainty, not equality.

**ISA-EXPERT-Q0363 · single · design**

Which retention test validates more than configured policy?

SYNTHETIC ASSESSMENT EVIDENCE: The policy requires a known event to remain retrievable for 90 days with protected provenance.

1. Retrieve a representative event near the retention boundary and verify content, access and integrity context
2. Check only free disk space today
3. Create a new event and immediately retrieve it
4. Inspect only the field labeled 90 days

**Correct option(s):** 1

- Option 1: A setting does not prove actual storage and usable retrieval.
- Option 2: Capacity is one factor, not historical retention evidence.
- Option 3: That does not challenge age-based retention.
- Option 4: The effective pipeline may drop or transform records earlier.

**ISA-EXPERT-Q0364 · single · diagnosis**

Why does a source-authenticated log still require cautious interpretation?

SYNTHETIC ASSESSMENT EVIDENCE: The log is genuinely from a compromised host and contains a command instructing responders to delete other artifacts.

1. The entire log must be erased because one line is hostile
2. Quoting the command in a report automatically authorizes it
3. Source authentication does not turn logged content into authorized instructions
4. Every authenticated log line must be executed as maintenance guidance

**Correct option(s):** 3

- Option 1: Preserving it can support investigation.
- Option 2: Presentation does not create operational authority.
- Option 3: The record is evidence to analyze, not an approval channel.
- Option 4: The source can contain attacker-controlled data.

**ISA-EXPERT-Q0365 · single · design**

Which test checks whether detection survives a collector failover?

SYNTHETIC ASSESSMENT EVIDENCE: Both collectors are healthy in normal operation. Only the active collector's parser and alert routing have been exercised.

1. Assume shared storage guarantees identical alerts
2. Ping the standby collector
3. Compare installed package names only
4. Fail over under an approved scenario and trace a known event through parsing, alert delivery and response context

**Correct option(s):** 4

- Option 1: The processing and notification paths can have separate dependencies.
- Option 2: Reachability does not test the evidence chain.
- Option 3: Configuration and routing may still differ.
- Option 4: Standby availability alone does not establish equivalent detection.

**ISA-EXPERT-Q0366 · single · diagnosis**

What is missing when an IDS alert cannot identify the affected physical function?

SYNTHETIC ASSESSMENT EVIDENCE: The alert contains an IP reused after a gateway replacement. The SOC isolates a host belonging to another hall.

1. Current asset-to-function mapping and response target verification
2. A more severe alert score
3. A rule that every IP remains assigned forever
4. A larger signature database alone

**Correct option(s):** 1

- Option 1: Technical indicators must be connected to actual operational identity.
- Option 2: Severity does not correct the wrong target mapping.
- Option 3: Lifecycle changes must be handled rather than denied by assumption.
- Option 4: More signatures do not reconcile address reuse.

**ISA-EXPERT-Q0367 · single · design**

Which operating measure better reflects useful telemetry service?

SYNTHETIC ASSESSMENT EVIDENCE: Servers are up 99.99% of the time, but stale-source incidents leave operators with old values.

1. Measure required point freshness, quality and availability at the consumer, alongside platform health
2. Measure only the number of configured points
3. Use server uptime alone because applications run on servers
4. Count successful dashboard refreshes only

**Correct option(s):** 1

- Option 1: The service outcome is more specific than server uptime.
- Option 2: Configuration count is not current usable information.
- Option 3: A live server can deliver stale or wrong data.
- Option 4: Redrawing can repeat old values.

#### Recall

**A forwarder emits no security events overnight but should send a health record every minute. How can the operating team distinguish legitimate quiet from lost collection?**

Monitor the age and integrity of the expected health path, separately from incident volume, and test its end-to-end arrival. A stale last-green indicator must not remain healthy indefinitely. Retain the limit that one health event does not prove every required security event is parsed correctly.

**In this case, what is the justified integrated decision? Raw controller events arrive with user IDs, but normalized SIEM records lose them after a parser update. Meanwhile a backup window produces rising queue drops and stale telemetry even though average CPU remains low.**

The identity loss localizes to parsing or normalization, so compare matched raw and normalized events. The telemetry symptom supports a resource-path investigation; low CPU does not exclude network or storage contention. Use interval counters and representative load, then verify corrected semantics and freshness rather than only a green service state.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)

### ISA-EXPERT-L23 — Sustain compatible protected baselines

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L22

Vulnerability treatment begins with applicability: exact product/component, effective version, feature state and credible access path. Inventory should include active peers, standby systems, spares, golden images and recovery automation. A service stopped today can be enabled during maintenance. A package installed on disk may not be the running release. Track evaluated, tested, deployed, activated and verified states separately.

Plan updates as dependency changes. Operating systems, drivers, firmware, libraries, schemas, tools and licences can constrain sequence and rollback. Supported mixed-version operation is a fact to establish, not a universal assumption. An irreversible migration needs a hold point before crossing it and a consistent recovery set. Test required workloads, role denial, alarms, timing, failover and restoration with the intended security controls enabled.

Endpoint protection is part of the same compatibility problem. Application control must cover relevant scripts, libraries, child processes and recovery tools. A permitted directory writable by ordinary users is a weak execution boundary. A publisher rule can be broader than one tested release. Antimalware exclusions should be narrow, documented, supported and reviewed; excluding an entire volume to protect one working directory grants more than the compatibility need. Read-only scanning can still consume CPU, storage or network resources.

If a tested patch breaks required function, use a justified bounded decision: supported alternative, feasible compensating measures, monitoring, accountable acceptance and retest trigger. Do not deploy a known-breaking update merely to improve a percentage, and do not turn one failed pilot into indefinite exemption. Preserve the pilot evidence and its exact baseline.

Close the whole campaign. Verify runtime activation, current privileges and configuration, delayed periodic workflows, standby readiness and recovery images. Queued jobs are not completed remediation. A delayed job should revalidate its authorization and prerequisites when the device returns, rather than executing days outside its approved window.

#### Worked demonstrations

**Sustain compatible protected baselines — integrated worked case**

Synthetic teaching case; no live equipment was tested.

Active servers run the fixed release. Standby hosts have the package installed but still execute the old driver. Recovery automation rebuilds from the old image, and a wildcard exclusion covers all executable scripts on the data volume.

**Reasoning:** The active state is only one part of the campaign. Activate and verify standbys under the supported sequence, update and test recovery sources, and narrow the exclusion to its justified scope. Report each incomplete target honestly. A count of successful installers cannot establish sustained remediation.

#### Guided practice

A patch pilot breaks acquisition, but a tested narrow access restriction reduces the known exploit path. Write a defensible temporary decision.

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** Record affected versions and exposure, the compatibility failure, required function, compensating restriction, monitoring, accountable owner acceptance, expiry/review trigger and the plan for a compatible fix. Verify the restriction and retained service. The vulnerability remains tracked rather than falsely marked removed.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Build a campaign plan for a synthetic redundant gateway service. Include dependency order, activation checks, endpoint policy compatibility, a failed pilot, bounded deferral, queued-target guards and recovery-image closure.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Plan vulnerability, patch and endpoint-control campaigns that preserve required function, current authority and future recovery state.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0368 · single · diagnosis**

Which target remains unremediated?

SYNTHETIC ASSESSMENT EVIDENCE: Active host runs fixed release 7.2. Standby has 7.2 installed but still executes 7.1. The golden recovery image also contains 7.1.

1. Only the active host needs review because it serves traffic today
2. The standby runtime and recovery image remain within the old release state
3. The recovery image cannot matter until it is used
4. The standby is fixed because the installer returned success

**Correct option(s):** 2

- Option 1: Failover and restoration can reintroduce the condition.
- Option 2: Installed packages and current active service do not cover the whole lifecycle population.
- Option 3: Prepared restoration material affects future exposure and readiness.
- Option 4: Activation has not occurred.

**ISA-EXPERT-Q0369 · single · design**

Which campaign order fits this compatibility constraint?

SYNTHETIC ASSESSMENT EVIDENCE: Database migration requires application 4.0. Version 3.0 cannot read the new schema. Mixed application versions are supported only before migration.

1. Migrate first and test the old application afterward
2. Verify backups and compatibility, update applications under the supported sequence, then migrate at the approved hold point
3. Update both peers and delete the old database immediately
4. Roll back only the executable if migration fails

**Correct option(s):** 2

- Option 1: The stated incompatibility predicts failure.
- Option 2: The irreversible dependency constrains the order.
- Option 3: That removes recovery before acceptance.
- Option 4: A consistent application/data restoration path is required.

**ISA-EXPERT-Q0370 · single · diagnosis**

What is the flaw in this vulnerability closure?

SYNTHETIC ASSESSMENT EVIDENCE: An advisory affects a service enabled only during maintenance. The service is currently stopped, so the finding is permanently closed without changing the maintenance procedure.

1. Every temporary service must be removed from all products
2. The advisory's severity score alone resolves future applicability
3. The assessed exposure condition can return in a foreseeable lifecycle state
4. A stopped service is necessarily exploitable remotely at that moment

**Correct option(s):** 3

- Option 1: Some may be required under bounded controls.
- Option 2: Version and configuration state determine the condition.
- Option 3: Current inactivity is not permanent remediation.
- Option 4: The actual current path still needs analysis.

**ISA-EXPERT-Q0371 · single · design**

How should an endpoint-protection pilot cover an engineering workstation?

SYNTHETIC ASSESSMENT EVIDENCE: Normal project editing works, but recovery requires a rarely used compiler helper and a controller download tool.

1. Test only login and text editing
2. Test normal, build, download, recovery and supported update workflows with enforcement enabled
3. Disable application control permanently for all engineers
4. Approve every executable ever observed during the pilot

**Correct option(s):** 2

- Option 1: Those omit the critical engineering functions.
- Option 2: Steady-state observation may miss essential lifecycle executables.
- Option 3: That abandons a feasible scoped protection design.
- Option 4: Observed presence does not establish legitimate need or trust.

**ISA-EXPERT-Q0372 · single · diagnosis**

Which allowlist rule is weakened by file-system permissions?

SYNTHETIC ASSESSMENT EVIDENCE: Execution is permitted from a maintenance directory. Ordinary users can replace files in that directory.

1. A signed parent application prevents every replaced child from running
2. Read-only network access to controllers fixes the host execution rule
3. The path remains trustworthy because its name says approved
4. The trusted path is writable by identities that can introduce executable content

**Correct option(s):** 4

- Option 1: That depends on policy coverage and process behaviour.
- Option 2: The host trust defect remains even if some downstream effects are constrained.
- Option 3: Naming does not constrain writes.
- Option 4: Path allowance depends on the directory's integrity controls.

**ISA-EXPERT-Q0373 · single · design**

Which patch test checks more than installer success?

SYNTHETIC ASSESSMENT EVIDENCE: The update replaces a communications driver and requires a reboot before the new driver loads.

1. Read the installed-package list before reboot
2. Check only the downloaded package hash
3. Count the number of updated hosts without inspecting failed activation
4. Verify active runtime version after reboot and test required transactions, timing, denial and recovery

**Correct option(s):** 4

- Option 1: The old driver may still be executing.
- Option 2: That establishes input identity, not activation.
- Option 3: A campaign total can hide unremediated instances.
- Option 4: The relevant claim concerns running behaviour, not copied files.

**ISA-EXPERT-Q0374 · single · diagnosis**

Why is a blanket antivirus exclusion problematic here?

SYNTHETIC ASSESSMENT EVIDENCE: The supplier recommends excluding one database working directory. The deployed wildcard excludes the entire data volume, including executable scripts.

1. The implemented exception exceeds the justified compatibility need
2. The wildcard improves security because it reduces scan load
3. All supplier exclusions are automatically unacceptable
4. The exception is harmless because the volume is not the OS disk

**Correct option(s):** 1

- Option 1: Broader exclusion exposes unrelated execution content.
- Option 2: Performance benefit does not justify unbounded excluded content.
- Option 3: A narrow supported exclusion may be justified with controls and review.
- Option 4: Executable and sensitive content can reside elsewhere.

**ISA-EXPERT-Q0375 · single · design**

Which deferral decision is supported by these conditions?

SYNTHETIC ASSESSMENT EVIDENCE: A patch causes loss of required controller communications in a representative pilot. A tested narrow access restriction reduces the known exploit path while a compatible fix is developed.

1. Use a bounded owner-approved deferral with the restriction, monitoring and a defined retest/review trigger
2. Remove the failed pilot evidence from the record
3. Ignore the vulnerability indefinitely because the first patch failed
4. Deploy the failing patch everywhere to improve compliance numbers

**Correct option(s):** 1

- Option 1: The decision preserves function while explicitly treating current exposure.
- Option 2: It explains the compatibility constraint and treatment choice.
- Option 3: The exposure and support obligation remain.
- Option 4: That knowingly violates required service.

**ISA-EXPERT-Q0376 · single · diagnosis**

Which rollback gap appears after an HMI update?

SYNTHETIC ASSESSMENT EVIDENCE: The old executable is restored, but the new configuration schema and certificate-store format remain. Startup fails.

1. The backup job's success status proves compatibility
2. The old executable is necessarily malicious
3. Rollback did not restore a compatible dependency set
4. A reboot always converts schemas backward

**Correct option(s):** 3

- Option 1: Backup creation does not prove restored combinations work.
- Option 2: The stated format incompatibility explains the failure.
- Option 3: Code alone does not define the application state.
- Option 4: No such supported mechanism is established.

**ISA-EXPERT-Q0377 · single · design**

Which change should be made to a supplier update package review?

SYNTHETIC ASSESSMENT EVIDENCE: The signed installer enables a remote support agent by default, creating a new outbound control channel.

1. Accept every default because the installer is signed
2. Block all updates from the supplier permanently without analyzing support consequences
3. Check only whether the old application still launches
4. Assess and configure the resulting services and authority against the approved architecture before acceptance

**Correct option(s):** 4

- Option 1: Origin does not establish site suitability.
- Option 2: The specific change needs treatment rather than indiscriminate abandonment.
- Option 3: That misses the new authority path.
- Option 4: Authentic installation can change the effective security boundary.

**ISA-EXPERT-Q0378 · single · diagnosis**

What explains a security scan that degrades historian ingestion while CPU remains low?

SYNTHETIC ASSESSMENT EVIDENCE: During scanning, disk latency rises and the historian input queue grows. CPU utilization stays below 20%.

1. Every queued event is necessarily malicious
2. Storage contention is a supported resource hypothesis
3. The historian's encryption keys must be invalid
4. Resource contention is impossible unless CPU is saturated

**Correct option(s):** 2

- Option 1: Queue growth can follow reduced processing capacity.
- Option 2: Low CPU does not exclude I/O bottlenecks.
- Option 3: The timing and disk evidence point elsewhere.
- Option 4: Different resources can limit service.

**ISA-EXPERT-Q0379 · single · design**

How should a disconnected spare be included in vulnerability treatment?

SYNTHETIC ASSESSMENT EVIDENCE: The spare is stored offline and may replace an active gateway during an emergency. Its firmware is affected by a known advisory.

1. Destroy it without reviewing replacement and recovery needs
2. Deploy it immediately during any outage without checking version
3. Exclude it permanently because it sends no current traffic
4. Track its version and update or constrain its deployment through a verified readiness procedure

**Correct option(s):** 4

- Option 1: Treatment should preserve required recoverability through a justified plan.
- Option 2: That can restore a known exposure.
- Option 3: Its intended lifecycle role matters.
- Option 4: Offline storage does not prevent future reintroduction.

**ISA-EXPERT-Q0380 · single · diagnosis**

What makes this update success metric misleading?

SYNTHETIC ASSESSMENT EVIDENCE: The dashboard counts a device complete when a deployment job is queued. Half the devices were offline and have not received it.

1. Every offline device is necessarily compromised
2. The metric measures scheduled intent rather than effective installation and verification
3. The package's signature proves it reached every target
4. Queued jobs can never be useful

**Correct option(s):** 2

- Option 1: Missing deployment is not evidence of actual compromise.
- Option 2: Queued work is not remediation.
- Option 3: Input authenticity does not establish distribution.
- Option 4: They are useful operational state when labeled accurately.

**ISA-EXPERT-Q0381 · single · design**

Which guard prevents stale queued authorization from becoming an unexpected change?

SYNTHETIC ASSESSMENT EVIDENCE: An automation job may execute when a device reconnects days after the approved maintenance window.

1. Revalidate target, authorization window and current prerequisites before execution
2. Run the change automatically whenever network reachability returns
3. Disable all logging for delayed jobs to avoid confusion
4. Treat the original queue time as permanent approval

**Correct option(s):** 1

- Option 1: The original conditions may no longer hold.
- Option 2: Reachability is not operational readiness or permission.
- Option 3: That removes accountability.
- Option 4: A bounded work order does not authorize any future state.

**ISA-EXPERT-Q0382 · single · diagnosis**

Which evidence supports an update-related authority regression?

SYNTHETIC ASSESSMENT EVIDENCE: Before the update, observers could read but not write. After the update, the same role can modify gateway mappings through a new API endpoint.

1. The mapping change is irrelevant because it is not PLC logic
2. The observers must have stolen administrator passwords
3. The update is safe because old endpoints still deny writes
4. The effective authorization model expanded through the new interface

**Correct option(s):** 4

- Option 1: Gateway mappings can affect operational data and decisions.
- Option 2: The described role behaviour is sufficient without that assumption.
- Option 3: The new path defeats the intended boundary.
- Option 4: A role name can remain unchanged while permissions broaden.

**ISA-EXPERT-Q0383 · single · design**

What should a maintenance release include when replacing a control library?

SYNTHETIC ASSESSMENT EVIDENCE: The library changes initialization and timing while the application's top-level source is unchanged.

1. A statement that libraries are outside the control application
2. Compatibility basis, exact library/tool versions, affected sequence tests, deployment identity and rollback dependencies
3. Only the unchanged top-level source checksum
4. Automatic deployment to both redundant controllers before testing

**Correct option(s):** 2

- Option 1: They participate in execution.
- Option 2: The changed dependency can alter effective behaviour.
- Option 3: That does not identify the new implementation below it.
- Option 4: That risks a common application failure without a verified fallback.

**ISA-EXPERT-Q0384 · single · diagnosis**

Which condition prevents accepting the patch campaign as complete?

SYNTHETIC ASSESSMENT EVIDENCE: Every active endpoint is updated, but the recovery procedure still automatically rebuilds hosts from an unpatched image and reinstalls the old agent.

1. Recovery procedures never affect vulnerability management
2. The old image is safe because its hash is known
3. The normal restoration path reintroduces the treated condition
4. The active endpoints cannot be considered updated at all

**Correct option(s):** 3

- Option 1: They can re-create effective software state.
- Option 2: Known integrity does not remove a known vulnerable version.
- Option 3: Sustained remediation must include recovery sources and deployment automation.
- Option 4: Their current fixed state can be valid, while campaign closure remains incomplete.

#### Recall

**A patch pilot breaks acquisition, but a tested narrow access restriction reduces the known exploit path. Write a defensible temporary decision.**

Record affected versions and exposure, the compatibility failure, required function, compensating restriction, monitoring, accountable owner acceptance, expiry/review trigger and the plan for a compatible fix. Verify the restriction and retained service. The vulnerability remains tracked rather than falsely marked removed.

**In this case, what is the justified integrated decision? Active servers run the fixed release. Standby hosts have the package installed but still execute the old driver. Recovery automation rebuilds from the old image, and a wildcard exclusion covers all executable scripts on the data volume.**

The active state is only one part of the campaign. Activate and verify standbys under the supported sequence, update and test recovery sources, and narrow the exclusion to its justified scope. Report each incomplete target honestly. A count of successful installers cannot establish sustained remediation.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)

### ISA-EXPERT-L24 — Make maintenance ownership executable

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L23

An operating baseline has several representations: approved intent, staged candidate, effective running state and recovery copy. Compare them for different reasons. Approved versus effective reveals drift; candidate versus approved reveals intended change; recovery versus current service reveals whether restoration can reproduce the accepted state. Use semantic comparison where harmless generated fields differ, but never normalize away permissions or services that matter to the requirement.

A change is a guarded transaction. Recheck target identity, operating mode, standby health, recovery material, staffing and permission immediately before action. An earlier approval does not make a newly failed prerequisite true. Define abort conditions and a feasible next state. Record deviations and actual results, then verify service, denied authority and recoverability before closure. A ticket does not clear PLC forces, BMS priority entries or established administrator sessions.

Exceptions accumulate operational debt when their promised replacement never arrives. Review scope, assumptions, compensating measures and ownership, not merely the renewal date. If a temporary broad rule becomes necessary every week, investigate the workflow or architecture that creates the recurring demand. A lasting redesign should demonstrate equivalent or better service with reduced authority and tested recovery.

Bound automation by its role. A diagnostic reader should not carry a deployment administrator token. Treat asset notes and logs as untrusted data, not instructions for privileged commands. Record input provenance, proposed action, authorized execution and effective results. A checker that reaches eight of ten devices should report eight observations and two unresolved targets, not estate-wide compliance.

Service ownership spans team boundaries. Packet delivery and a running process do not establish current usable telemetry. Assign responsibility for the end-to-end outcome and its degraded modes. Maintain supplier support, entitlements, credentials and competence through staff turnover. Retirement removes logical authority and dependencies as well as hardware, while preserving required evidence and data disposition records.

#### Worked demonstrations

**Make maintenance ownership executable — integrated worked case**

Synthetic teaching case; no live equipment was tested.

A monthly review approves every account row by clicking a box. A departed engineer's local keys remain active, and a restored gateway still contains a temporary supplier rule from an old incident.

**Reasoning:** The review measures workflow activity rather than current authority. Reconcile actual duties and all credential paths, compare effective and restored policy to current approval, and test closure. Assign owners to the missing lifecycle actions instead of declaring the register complete from click counts.

#### Guided practice

A configuration assistant identifies a risky rule in last month's export but cannot inspect the running device. What can it report?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** It can identify and explain the risk in that snapshot, state the source date and assumptions, and propose current verification. It cannot claim the rule is definitely active now or that a drafted correction was deployed. Preserve the distinction between evidence, inference and action.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Run a documented synthetic operating campaign with baseline checks, one approved change, one failed prerequisite, an expiring exception and a retirement action. Show effective closure and the next team's usable handover.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Sustain approved state through change control, exception closure, supplier transitions, bounded automation and retirement.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0385 · single · design**

Which baseline comparison best supports a monthly operating review?

SYNTHETIC ASSESSMENT EVIDENCE: The repository contains approved policy, devices hold active policy, and backup storage contains restoration copies.

1. Compare only filenames across storage locations
2. Treat the repository as proof of deployment
3. Compare all three relationships and classify semantic differences by consequence
4. Treat every byte difference as malicious drift

**Correct option(s):** 3

- Option 1: Names do not establish content or meaning.
- Option 2: Approved intent may not be active.
- Option 3: Intent, effective state and recoverable state answer different lifecycle questions.
- Option 4: Generated timestamps or ordering can be harmless while semantic changes matter.

**ISA-EXPERT-Q0386 · single · diagnosis**

What is the sustaining defect in repeated emergency-access extensions?

SYNTHETIC ASSESSMENT EVIDENCE: A broad supplier rule is renewed monthly because the promised broker replacement is never delivered. No one reviews whether the original assumptions still hold.

1. Every extension is automatically invalid regardless of review
2. The temporary treatment has become indefinite without renewed engineering justification
3. The broad rule becomes least privilege after enough months
4. The supplier's continued convenience proves risk acceptance

**Correct option(s):** 2

- Option 1: A justified bounded extension may be possible.
- Option 2: Repeated paperwork does not establish sustainable risk treatment.
- Option 3: Duration does not narrow its authority.
- Option 4: Owner governance and evidence remain required.

**ISA-EXPERT-Q0387 · single · design**

Which work-order field helps prevent a wrong-device change?

SYNTHETIC ASSESSMENT EVIDENCE: Two gateways have identical models and similar names but serve different halls.

1. Durable target identity plus verified physical/function context and expected connected-device confirmation
2. Only the technician's recollection of the rack
3. Only the generic model number
4. A broad instruction to update all similar devices

**Correct option(s):** 1

- Option 1: Names and model similarity need stronger target binding.
- Option 2: Memory is not a robust execution check.
- Option 3: That cannot distinguish the two instances.
- Option 4: That changes the authorized scope.

**ISA-EXPERT-Q0388 · single · diagnosis**

Why does closing a maintenance ticket not prove handback?

SYNTHETIC ASSESSMENT EVIDENCE: The ticket is closed while a PLC force, a high-priority BMS override and a temporary administrator session remain active.

1. Administrative closure is disconnected from effective runtime and authority cleanup
2. The remaining states are harmless because the original task succeeded
3. Only the PLC source version matters at handback
4. A closed ticket automatically clears all technical overrides

**Correct option(s):** 1

- Option 1: The next operator inherits altered control and access state.
- Option 2: Their consequences must be reconciled with normal operation.
- Option 3: Effective forces and external command authority can alter behaviour.
- Option 4: Tools do not necessarily implement such coupling.

**ISA-EXPERT-Q0389 · single · design**

Which procedure supports safe investigation before a disruptive restart?

SYNTHETIC ASSESSMENT EVIDENCE: An HMI is stable but suspected of compromise. Approved tools can collect relevant volatile state without exceeding current operating limits.

1. Always delay every operational action until exhaustive forensics finish
2. Collect the authorized bounded evidence first, then execute the approved response path while recording tradeoffs
3. Reboot immediately in every case because it is simplest
4. Run arbitrary untested forensic tools on the live HMI

**Correct option(s):** 2

- Option 1: Physical conditions may require earlier action.
- Option 2: The available stable window can preserve information lost by reboot.
- Option 3: That can unnecessarily destroy feasible evidence.
- Option 4: Collection must respect supported tools and operational constraints.

**ISA-EXPERT-Q0390 · single · diagnosis**

Which ownership gap appears in this service report?

SYNTHETIC ASSESSMENT EVIDENCE: Network staff prove packet delivery; application staff prove the process runs. Operators still receive stale values, and neither team owns end-to-end freshness.

1. The operator should manually correct every value indefinitely
2. Both teams' evidence must be fabricated
3. Component responsibilities lack an accountable service outcome owner
4. The service should be measured only by whichever component looks healthiest

**Correct option(s):** 3

- Option 1: That does not repair the integration or ownership.
- Option 2: Each can have a valid narrow result.
- Option 3: The useful function spans both teams' boundaries.
- Option 4: That hides the actual user-facing failure.

**ISA-EXPERT-Q0391 · single · design**

What should an optimization proposal preserve?

SYNTHETIC ASSESSMENT EVIDENCE: A new maintenance schedule lowers operating cost by reducing restore drills and removing the only independently accessible backup copy.

1. Reject every cost reduction in cybersecurity
2. Treat a second online folder under the same administrator as automatically independent
3. Accept the saving because the backup has not been used recently
4. Evaluate cost benefit against required recovery objectives, common causes and evidence of readiness

**Correct option(s):** 4

- Option 1: Some changes can improve efficiency while preserving requirements.
- Option 2: Shared authority can defeat both copies.
- Option 3: Rare-use capability exists for failure scenarios.
- Option 4: Savings cannot silently remove a critical constraint.

**ISA-EXPERT-Q0392 · single · diagnosis**

What is the issue with this configuration-comparison assistant?

SYNTHETIC ASSESSMENT EVIDENCE: The assistant correctly identifies a risky rule in an exported file, but the file predates the last deployment and it cannot inspect the running device.

1. Its conclusion applies to the supplied snapshot, not necessarily current effective policy
2. A confident explanation removes the need to verify the active state
3. The finding must be false because the snapshot is old
4. The assistant can claim it fixed the device after describing a correction

**Correct option(s):** 1

- Option 1: Provenance and age constrain the claim.
- Option 2: Confidence does not supply missing evidence.
- Option 3: The risky rule may still exist; current verification is needed.
- Option 4: Advice is not deployment.

**ISA-EXPERT-Q0393 · single · design**

Which automation design preserves an evidence-versus-instruction boundary?

SYNTHETIC ASSESSMENT EVIDENCE: A diagnostic workflow reads operator notes and device logs that may contain arbitrary text.

1. Parse them as untrusted data, constrain tools by authorized schemas/roles and separately approve consequential actions
2. Disable logging of automated actions to avoid exposing implementation details
3. Trust any instruction carrying a device name
4. Concatenate every note into a privileged shell command

**Correct option(s):** 1

- Option 1: Content from evidence sources must not acquire execution authority.
- Option 2: Accountable operation needs protected action evidence.
- Option 3: A name does not prove authorization.
- Option 4: That lets untrusted text influence execution directly.

**ISA-EXPERT-Q0394 · single · diagnosis**

Which maintenance handover is fragile despite correct documentation?

SYNTHETIC ASSESSMENT EVIDENCE: The procedure works only when one engineer's personal account and undocumented licence activation are available.

1. The technical procedure is necessarily incorrect
2. The dependency can be ignored until the engineer leaves
3. Execution depends on individual custody outside the controlled service process
4. The problem is solved by adding more pages

**Correct option(s):** 3

- Option 1: It may work but remain operationally unsustainable.
- Option 2: Foreseeable absence should be addressed before an outage.
- Option 3: Documentation alone does not establish organizational readiness.
- Option 4: Length does not transfer credentials or entitlements.

**ISA-EXPERT-Q0395 · single · design**

What should a decommissioning review include for a replaced gateway?

SYNTHETIC ASSESSMENT EVIDENCE: The old gateway is powered off, but its certificate, firewall objects, monitoring rules and cloud-support registration remain.

1. Reconcile logical authority, dependencies, retained data and records through controlled retirement
2. Erase all historical evidence regardless of retention needs
3. Delete the inventory row and leave every technical object
4. Keep all credentials active in case someone reconnects it

**Correct option(s):** 1

- Option 1: Physical removal is only one lifecycle action.
- Option 2: Required records need deliberate preservation or disposal.
- Option 3: That can hide stale authority and misleading monitoring.
- Option 4: Reconnection should require explicit approved identity and purpose.

**ISA-EXPERT-Q0396 · single · diagnosis**

Why is this access-review metric weak?

SYNTHETIC ASSESSMENT EVIDENCE: The report counts every account row that a manager clicked approve. It does not compare duties, effective privileges, departed users or alternate tokens.

1. More frequent identical clicks necessarily fix the problem
2. Manager participation has no value
3. The metric measures workflow clicks rather than correctness of current authority
4. The click count proves all accounts are malicious

**Correct option(s):** 3

- Option 1: Frequency does not correct an incomplete review method.
- Option 2: It is useful when informed by relevant evidence and decision criteria.
- Option 3: An effective review must evaluate actual need and access paths.
- Option 4: The evidence only shows review weakness.

**ISA-EXPERT-Q0397 · single · design**

Which operating campaign provides stronger evidence than one successful demonstration?

SYNTHETIC ASSESSMENT EVIDENCE: The learner must show sustained BMS integration ownership over a defined study period.

1. Count elapsed calendar days without recording any operational outcomes
2. Repeat one normal dashboard screenshot each day
3. Invent historical incidents to make the portfolio look complete
4. Run planned normal checks, a justified change, bounded fault diagnosis, backup restoration and authority handback with versioned records

**Correct option(s):** 4

- Option 1: Time alone does not establish capability.
- Option 2: That adds observations but little coverage of maintenance or recovery.
- Option 3: Evidence must remain truthful and synthetic exercises labeled.
- Option 4: The campaign exercises continuing lifecycle responsibilities.

**ISA-EXPERT-Q0398 · single · diagnosis**

What is missing from a supplier end-of-support plan?

SYNTHETIC ASSESSMENT EVIDENCE: The owner knows the retirement date but has no compatible replacement, spare strategy, migration test or interim treatment for the essential device.

1. Permanent broad remote access guarantees support after retirement
2. Every unsupported device immediately stops functioning
3. A feasible lifecycle transition and risk treatment
4. The date can be deleted to remove the risk

**Correct option(s):** 3

- Option 1: It creates exposure without a supplier obligation or technical capability.
- Option 2: Support status and physical operation are different.
- Option 3: A date in the inventory does not maintain required service.
- Option 4: Documentation does not change support availability.

**ISA-EXPERT-Q0399 · single · design**

Which post-change observation period is justified?

SYNTHETIC ASSESSMENT EVIDENCE: An update passes immediate tests, but the application has nightly batch processing and weekly failover tasks that use changed components.

1. Disable the periodic tasks so no delayed failures can occur
2. Declare full success after one idle minute
3. Observe or exercise the relevant deferred workflows before making an unqualified sustained-performance claim
4. Wait an arbitrary year without any targeted checks

**Correct option(s):** 3

- Option 1: That removes required function instead of validating it.
- Option 2: That omits known relevant workloads.
- Option 3: Immediate checks may not cover periodic behaviours.
- Option 4: Elapsed time alone is not efficient or specific evidence.

**ISA-EXPERT-Q0400 · single · diagnosis**

What makes this maintenance improvement claim credible?

SYNTHETIC ASSESSMENT EVIDENCE: Before-and-after records show fewer stale-data incidents after a scoped polling change, using comparable loads and unchanged freshness criteria, with limits disclosed.

1. The team may now claim universal prevention under every future workload
2. Every remaining incident proves the change had no benefit
3. The claim connects a controlled intervention to comparable observed outcomes and preserved constraints
4. The new product name alone explains the improvement

**Correct option(s):** 3

- Option 1: The evidence remains bounded by tested conditions and uncertainty.
- Option 2: Improvement can be real without eliminating all failures.
- Option 3: It has a reviewable causal and practical basis.
- Option 4: Branding is not the evidence offered.

#### Recall

**A configuration assistant identifies a risky rule in last month's export but cannot inspect the running device. What can it report?**

It can identify and explain the risk in that snapshot, state the source date and assumptions, and propose current verification. It cannot claim the rule is definitely active now or that a drafted correction was deployed. Preserve the distinction between evidence, inference and action.

**In this case, what is the justified integrated decision? A monthly review approves every account row by clicking a box. A departed engineer's local keys remain active, and a restored gateway still contains a temporary supplier rule from an old incident.**

The review measures workflow activity rather than current authority. Reconcile actual duties and all credential paths, compare effective and restored policy to current approval, and test closure. Assign owners to the missing lifecycle actions instead of declaring the register complete from click counts.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)

## ISA-EXPERT-M09 — Incident response and trusted recovery

### ISA-EXPERT-L25 — Contain incidents without losing the process

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L24

An incident record should distinguish observation, inference and decision. “Account X authenticated,” “the project changed,” and “person X maliciously changed it” are not equivalent statements. Shared credentials, incomplete session linkage and clock uncertainty can limit attribution while leaving a clear authorization concern. Preserve the useful bounded finding instead of either overstating blame or refusing to act until every uncertainty is resolved.

Containment targets a credible path within the physical operating envelope. Isolating an unnecessary engineering workstation can remove change authority while local loops continue. Disabling a shared identity or alarm service can affect many healthy functions. Map the dependencies, coordinate qualified operations and define alternate coverage or time limits. A critical incident does not automatically transfer electrical switching authority to the cyber team.

Evidence preservation also has an operating boundary. A reboot can destroy active processes, connections and memory context. If the host is stable and approved collection is feasible, preserve relevant volatile state first. If physical safety or required continuity demands immediate action, act under the appropriate authority and record the tradeoff. There is no universal rule that exhaustive forensics always precedes operation or that every suspect device should immediately reboot.

Scope investigation across effective authority. BMC access can influence the platform outside OS login records. Central policy can reintroduce a startup task after a clean rebuild. A stolen token may survive account disablement. Controller logic, forces and retained values can remain altered after the original host is disconnected. Containment of one route is not eradication of every effect.

Protect provenance and analytical boundaries. Record source, collector, method, time, integrity checks, transfers and known alterations. A later hash does not prove pre-hash editing never occurred. Treat commands embedded in logs or recovered scripts as untrusted content, not approved remediation. Use independent authorization and controlled tools throughout the response.

#### Worked demonstrations

**Contain incidents without losing the process — integrated worked case**

Synthetic teaching case; no live equipment was tested.

A supplier account authenticates during a read-only task, then a PLC project checksum changes. The account was shared and video is missing. Local loops are healthy, and the approved procedure permits isolating the suspect jump host without disrupting current control.

**Reasoning:** The evidence supports an out-of-scope project change but not conclusive personal attribution. Restrict the suspect path within the approved envelope, preserve feasible host/controller evidence and verify local service. Investigate changed logic, other credentials and persistence; host isolation alone does not establish eradication.

#### Guided practice

Endpoint response isolates the only alarm gateway. Local DDC regulation continues, but unattended operation is allowed for only twenty minutes. What must incident leadership coordinate?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** Provide authorized alternate awareness or staffing and manage the isolation duration against the approved limit while treating the gateway's trust. Neither immediate unverified reconnection nor indefinite reliance on local regulation is automatically acceptable. Record the operational decision and restoration criteria.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Conduct a tabletop using a synthetic incident timeline with a shared credential, uncertain clocks, an out-of-band event and an alarm dependency. Produce bounded findings, containment choices, evidence priorities and qualified decision owners.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Separate facts, hypotheses and authority while coordinating evidence preservation and operationally feasible containment.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0401 · single · diagnosis**

Which incident conclusion is supported by these records?

SYNTHETIC ASSESSMENT EVIDENCE: An engineering account logs in during an approved read-only task. A controller records a project change. The session recording is unavailable and the account may have been shared.

1. No incident exists because the login was authorized
2. The missing recording proves no project change occurred
3. The named account owner is conclusively the attacker
4. A project change exceeded the documented task scope, while actor attribution remains limited

**Correct option(s):** 4

- Option 1: A valid login does not approve an out-of-scope action.
- Option 2: The controller's observed change remains evidence.
- Option 3: Shared credentials and missing linkage limit that conclusion.
- Option 4: The action and authorization mismatch are supported without proving a particular person's intent.

**ISA-EXPERT-Q0402 · single · design**

Which first response fits these operating facts?

SYNTHETIC ASSESSMENT EVIDENCE: A suspect engineering host is not required for current local control. The approved response permits isolating its management path. Controllers show no abnormal physical behaviour yet.

1. Reboot every controller before gathering any context
2. Restrict the suspect path, preserve feasible evidence and verify continued required local service
3. Wait for complete attribution while leaving all engineering authority active
4. Disable independent electrical protection to simplify the network

**Correct option(s):** 2

- Option 1: That unnecessarily expands impact beyond the known host path.
- Option 2: The action targets the credible route within the stated operational envelope.
- Option 3: Containment need not wait for final actor identification.
- Option 4: That is unrelated to the suspect host and violates a separate safety boundary.

**ISA-EXPERT-Q0403 · single · diagnosis**

What must be investigated when symptoms persist after host isolation?

SYNTHETIC ASSESSMENT EVIDENCE: The engineering host is disconnected, but a controller's setpoint continues changing through an active local script and a retained privileged token.

1. Other effective authority and execution paths remain
2. Every controller must be physically damaged
3. The isolation necessarily failed at the switch
4. The incident is eradicated because the original source is offline

**Correct option(s):** 1

- Option 1: Isolating one host does not remove all prior changes or credentials.
- Option 2: The evidence points to continuing logic or authority.
- Option 3: The stated local script/token can explain persistence without that failure.
- Option 4: Containment of one source is narrower than eradication.

**ISA-EXPERT-Q0404 · single · design**

How should responders handle a shared service account implicated in an incident?

SYNTHETIC ASSESSMENT EVIDENCE: The account can modify the BMS and also supports required alarm forwarding. Immediate blanket disablement would remove the only notification path.

1. Reset only the account description
2. Disable it without informing operations or considering alarm loss
3. Leave the account unrestricted indefinitely to preserve alarms
4. Coordinate a bounded containment and alternate alarm capability before or alongside revocation, according to process urgency

**Correct option(s):** 4

- Option 1: A label change does not remove authority.
- Option 2: That can create an unmanaged physical-awareness gap.
- Option 3: That retains the incident path without a treatment decision.
- Option 4: Both compromised authority and required awareness must be treated.

**ISA-EXPERT-Q0405 · single · diagnosis**

Which evidence differentiates unauthorized logic change from stale visualization?

SYNTHETIC ASSESSMENT EVIDENCE: The HMI shows unexpected pump state. Controller project comparison is unchanged, physical feedback is normal, and the HMI source timestamp stopped before the anomaly.

1. The observations support a stale supervisory-data hypothesis
2. All security investigation can be closed permanently
3. The controller is conclusively compromised because the HMI looks wrong
4. The physical feedback must be false because it conflicts with the HMI

**Correct option(s):** 1

- Option 1: They do not establish altered controller logic as the cause.
- Option 2: The conclusion is bounded to the observed mechanism and available evidence.
- Option 3: The independent evidence points to a different layer.
- Option 4: The stale timestamp weakens the display's currency.

**ISA-EXPERT-Q0406 · single · design**

Which volatile evidence is most relevant before a justified stable-host reboot?

SYNTHETIC ASSESSMENT EVIDENCE: A suspect host may hold active remote sessions and an in-memory script. Approved collection is feasible without exceeding operational limits.

1. Collect only the installed-software list after reboot
2. Run untrusted tools copied from the suspect host without verification
3. Delay every possible safety action until a complete disk image exists
4. Capture the relevant processes, connections and memory context using the approved method, preserving provenance

**Correct option(s):** 4

- Option 1: That can miss transient execution and sessions.
- Option 2: Collection tools themselves need a controlled trust basis.
- Option 3: Operational urgency may override ideal collection.
- Option 4: The reboot may remove evidence needed to understand the active mechanism.

**ISA-EXPERT-Q0407 · single · diagnosis**

What does this custody gap limit?

SYNTHETIC ASSESSMENT EVIDENCE: Responders edited an exported log before recording its first hash. The original device buffer has since rolled over.

1. Every other independent log is automatically invalid
2. The hash reconstructs the overwritten source buffer
3. The later hash does not prove the original exported content was preserved
4. The edited record must be accepted as original because it is useful

**Correct option(s):** 3

- Option 1: The gap affects the specific artifact and related claims.
- Option 2: A digest cannot recover missing records.
- Option 3: It identifies the post-edit artifact within a weaker provenance chain.
- Option 4: Usefulness does not repair provenance.

**ISA-EXPERT-Q0408 · single · design**

Which evidence plan best investigates an out-of-band path?

SYNTHETIC ASSESSMENT EVIDENCE: Host logs show no interactive login, but BMC records show unexpected virtual media and remote console use.

1. Collect and correlate BMC identity/actions, firmware/configuration state, boot evidence and host effects
2. Limit investigation to the OS user login list
3. Reimage the OS and discard BMC records immediately
4. Assume no action occurred because the host login log is quiet

**Correct option(s):** 1

- Option 1: The management plane can act outside ordinary OS login records.
- Option 2: That omits the observed authority path.
- Option 3: That can leave the cause unresolved and lose evidence.
- Option 4: The BMC evidence contradicts that narrow inference.

**ISA-EXPERT-Q0409 · single · diagnosis**

Which interpretation avoids confusing detection with attribution?

SYNTHETIC ASSESSMENT EVIDENCE: An IDS flags a write operation from a known engineering subnet. The operation is outside the usual schedule, but emergency work may have been authorized by phone.

1. Every off-hours write is automatically legitimate in OT
2. The IDS result should be deleted if authorization is later found
3. The source subnet conclusively identifies a malicious person
4. The write and timing anomaly require correlation with task, identity and change evidence

**Correct option(s):** 4

- Option 1: Timing exceptions still need authority and evidence.
- Option 2: The event remains part of the operational record and tuning context.
- Option 3: Subnets do not uniquely establish actor or intent.
- Option 4: An alert is a lead, not complete malicious-intent proof.

**ISA-EXPERT-Q0410 · single · design**

How should containment handle a compromised central deployment service?

SYNTHETIC ASSESSMENT EVIDENCE: The service can push configuration to both halls. Some local controllers are operating correctly and do not need new deployments.

1. Restrict the deployment authority and investigate distributed changes while preserving required local operation
2. Rebuild only one affected endpoint and immediately re-enroll it
3. Assume valid package signatures prove every pushed configuration is approved
4. Disable all local control merely because central management is suspect

**Correct option(s):** 1

- Option 1: The common control plane is the relevant propagation path.
- Option 2: The upstream service can reapply harmful state.
- Option 3: A privileged source can distribute signed but unsuitable content.
- Option 4: The physical effect needs a justified operating decision.

**ISA-EXPERT-Q0411 · single · diagnosis**

What should the report say about this failed attribution attempt?

SYNTHETIC ASSESSMENT EVIDENCE: The attacker used a shared maintenance credential. Network records identify the jump host but no reliable upstream individual session linkage exists.

1. The action is linked to the shared credential and host, with individual attribution unresolved
2. The last person who used the account is conclusively responsible
3. The account name itself is a verified human identity
4. The incident cannot be described at all without a named person

**Correct option(s):** 1

- Option 1: The evidence supports a bounded technical path.
- Option 2: That inference lacks the needed linkage.
- Option 3: Shared account use breaks that equivalence.
- Option 4: Technical findings can remain useful without individual attribution.

**ISA-EXPERT-Q0412 · single · design**

Which response preserves the distinction between alarm acknowledgment and physical recovery?

SYNTHETIC ASSESSMENT EVIDENCE: During an incident, operators acknowledge a high-temperature alarm to manage the console. The temperature remains above the permitted limit.

1. Close the physical incident because the banner is acknowledged
2. Disable temperature collection to prevent repeated notifications
3. Treat acknowledgment as permission to exceed the operating limit indefinitely
4. Continue the required process response and track the active condition separately from acknowledgment

**Correct option(s):** 4

- Option 1: That confuses operator action with return to normal.
- Option 2: That removes visibility without restoring conditions.
- Option 3: It does not change the approved envelope.
- Option 4: Awareness does not remove the initiating hazard or service deviation.

**ISA-EXPERT-Q0413 · single · diagnosis**

Which hypothesis deserves priority from this combined evidence?

SYNTHETIC ASSESSMENT EVIDENCE: Telemetry fails only during backup, queue drops rise sharply, controller projects remain unchanged and authenticated operations match approved tasks.

1. Sensor calibration must change at the same time every night
2. The absence of project changes proves all security controls are perfect
3. Shared-resource contention is a supported leading cause
4. Every outage during backup proves data exfiltration

**Correct option(s):** 3

- Option 1: The known network/load correlation is more direct.
- Option 2: That is a much broader claim than the evidence supports.
- Option 3: The evidence points to a testable operational mechanism while retaining visibility limits.
- Option 4: Scheduled legitimate load can explain the pattern.

**ISA-EXPERT-Q0414 · single · design**

How should an incident team preserve trustworthy decision records across shifts?

SYNTHETIC ASSESSMENT EVIDENCE: Containment uses temporary routes, alternate alarm coverage and a time-limited local operating mode.

1. Wait until the incident ends before documenting any decisions
2. Copy every raw log without identifying the current operating state
3. Record effective state, rationale, authority, expiry, evidence and next decision triggers in a controlled handover
4. Transfer only a verbal summary that the site is stable

**Correct option(s):** 3

- Option 1: Critical context may be lost during execution.
- Option 2: Raw volume does not replace an actionable handover.
- Option 3: The next team needs the current constraints and unresolved risks.
- Option 4: That can omit temporary authority and time limits.

**ISA-EXPERT-Q0415 · single · diagnosis**

What does a clean malware scan fail to establish after suspected logic manipulation?

SYNTHETIC ASSESSMENT EVIDENCE: The workstation scan finds no known malware. The controller's effective program and retained-state history have not been compared.

1. Additional controller-specific evidence is needed
2. The controller's application and authority are trustworthy
3. Ordinary configuration misuse remains possible without malware
4. The scanner completed under its stated conditions

**Correct option(s):** 2

- Option 1: The suspected action concerns its state.
- Option 2: The scan covers a different system layer and limited detection mechanisms.
- Option 3: Legitimate tools can make unauthorized changes.
- Option 4: That is a valid narrower observation.

**ISA-EXPERT-Q0416 · single · design**

Which containment exercise tests operational coupling before a real incident?

SYNTHETIC ASSESSMENT EVIDENCE: A response tool can isolate the only alarm gateway while local regulation continues. The approved unattended interval is limited.

1. Assume local regulation permits indefinite loss of alarms
2. Disable all local alarms to make the isolation more complete
3. Model the isolation and verify alternate awareness, operator coverage, duration and trusted restoration
4. Test only whether the isolation command returns success

**Correct option(s):** 3

- Option 1: The approved interval says otherwise.
- Option 2: That removes additional required awareness.
- Option 3: The exercise connects cyber containment to process requirements.
- Option 4: That omits its operational consequence.

**ISA-EXPERT-Q0417 · single · diagnosis**

Which interpretation fits an attacker-controlled instruction inside an incident artifact?

SYNTHETIC ASSESSMENT EVIDENCE: A recovered script comment says responders should disable logging and run a supplied cleanup command as administrator.

1. Quoting the comment in a ticket makes it an approved runbook
2. The cleanup is authorized because it appears in the affected system
3. The comment is untrusted evidence and cannot authorize execution
4. The entire artifact should be executed to observe intent

**Correct option(s):** 3

- Option 1: A quotation is not a governance decision.
- Option 2: Location does not establish trusted instruction authority.
- Option 3: An artifact can contain adversarial instructions that must remain data.
- Option 4: Analysis needs a controlled method, not automatic live execution.

#### Recall

**Endpoint response isolates the only alarm gateway. Local DDC regulation continues, but unattended operation is allowed for only twenty minutes. What must incident leadership coordinate?**

Provide authorized alternate awareness or staffing and manage the isolation duration against the approved limit while treating the gateway's trust. Neither immediate unverified reconnection nor indefinite reliance on local regulation is automatically acceptable. Record the operational decision and restoration criteria.

**In this case, what is the justified integrated decision? A supplier account authenticates during a read-only task, then a PLC project checksum changes. The account was shared and video is missing. Local loops are healthy, and the approved procedure permits isolating the suspect jump host without disrupting current control.**

The evidence supports an out-of-scope project change but not conclusive personal attribution. Restrict the suspect path within the approved envelope, preserve feasible host/controller evidence and verify local service. Investigate changed logic, other credentials and persistence; host isolation alone does not establish eradication.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)

### ISA-EXPERT-L26 — Restore three connected trust paths

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L25

Trusted recovery restores required function under an accepted current state. Organize three connected paths. Network/platform recovery covers firmware/configuration, routing, segmentation, management identities, BMC and automation. Controller/engineering recovery covers compatible tools, libraries, project provenance, hardware/I/O mapping, retained values, forces and sequence behaviour. Supervisory/data recovery covers point semantics, roles, alarms, historian consistency, trust relationships and operational awareness. One green server or matching project hash cannot establish all three.

Select recovery material using a justified trust basis. The newest snapshot may contain compromise; the oldest may be unsupported or omit essential changes. Detection date is not necessarily compromise start. Use independent logs, configuration history and provenance to justify selection, state uncertainty and plan reconciliation. Immutability protects a captured state from later alteration; it does not make an already compromised snapshot clean.

Recovery tools and dependencies belong in the trust boundary. A verified image used by an untrusted script can still produce a harmful installation. A licence service can determine whether restored software operates. A vault depending on the directory whose recovery credentials it holds needs an independent bootstrap path. Establish trustworthy upstream identity and policy before reconnecting dependent hosts, or use an approved isolated alternative.

Reconcile historical state with current authorization. Remove retired and compromised identities, tokens, certificates and tunnels; restore required current service accounts; verify both acceptance and rejection. An approved PLC project with a retained force or still-valid stolen engineering credential is not a stable trusted result. Physical isolation and equipment readiness also need qualified handback.

Reconnect in controlled stages with hold points. Verify local trust and function, then required dependencies, then boundary transactions and operational outcomes. Preserve evidence and avoid broad permits merely to make applications work. Diagnose the missing dependency and authorize the scoped correction. Continue to distinguish partial function, full required service and unresolved trust limitations.

#### Worked demonstrations

**Restore three connected trust paths — integrated worked case**

Synthetic teaching case; no live equipment was tested.

A clean engineering host image is available, but its BMC key is exposed, the directory still distributes a malicious task and the controller backup contains a forced permissive. The firewall backup also restores a retired supplier tunnel.

**Reasoning:** Four independent restoration gaps exist across the three paths. Re-establish platform/BMC trust, correct upstream identity/policy, reconcile controller runtime state and restore current boundary authority. Then validate required function and denied old paths. Reimaging the host repeatedly will not address the other layers.

#### Guided practice

A historian restore lacks two hours of data. Some gateways hold genuine buffered samples; other values can only be interpolated. How should the restored history be represented?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** Import supported observed backlog with original identity/time/quality and provenance. Preserve known gaps and distinguish derived estimates from measured samples. Do not shift timestamps or label interpolation as physical observation merely to make the trend continuous.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Create a three-path recovery graph with trusted sources, tools, bootstrap dependencies, current-authority reconciliation and staged reconnection. Include one historical permission that must not return and one physical handback dependency.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Rebuild network/platform, controller and supervisory services while reconciling current authority, source provenance and recovery dependencies.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0418 · single · design**

Which recovery source is strongest after uncertain management-plane compromise?

SYNTHETIC ASSESSMENT EVIDENCE: The newest image was captured after suspicious activity. An older independently protected image has known provenance but needs current patches and identity reconciliation.

1. Use whichever image restores fastest and ignore provenance
2. Use a justified trusted base and controlled current-state reconciliation, with explicit data-loss and compatibility decisions
3. Always choose the oldest image regardless of support and dependencies
4. Always choose the newest image because it minimizes data loss

**Correct option(s):** 2

- Option 1: Speed does not satisfy trusted recovery.
- Option 2: Recency alone is not trust, and older sources still need updating.
- Option 3: Age does not automatically establish usable trust.
- Option 4: It may preserve compromise.

**ISA-EXPERT-Q0419 · single · diagnosis**

What remains after restoring approved controller logic?

SYNTHETIC ASSESSMENT EVIDENCE: The controller runs the correct project, but a stolen engineering account can still download a new one.

1. The prior attack path can modify the restored state again
2. A matching source hash revokes the stolen account
3. The controller must run without any maintenance account ever
4. The approved project is necessarily already corrupt

**Correct option(s):** 1

- Option 1: Functional restoration without authority treatment is unstable.
- Option 2: Content verification does not change permissions.
- Option 3: Authorized maintenance can use controlled current identities.
- Option 4: It can be correct at the observed moment.

**ISA-EXPERT-Q0420 · single · design**

Which platform recovery scope follows confirmed BMC credential compromise?

SYNTHETIC ASSESSMENT EVIDENCE: The attacker could mount media and alter platform settings through BMC access. The OS has been reinstalled from approved media.

1. Repeat the same OS reinstall and ignore BMC state
2. Change only the ordinary operator password
3. Assess and restore BMC firmware/configuration trust and authority, then validate host function and denied old access
4. Accept because the server boots normally

**Correct option(s):** 3

- Option 1: That may leave the observed path intact.
- Option 2: It does not revoke the BMC credential.
- Option 3: The independent management plane needs direct treatment.
- Option 4: Boot success does not establish management trust.

**ISA-EXPERT-Q0421 · single · diagnosis**

Why is this immutable backup not automatically a trusted recovery source?

SYNTHETIC ASSESSMENT EVIDENCE: The backup was captured after a malicious privileged account and startup task were introduced. Storage immutability prevents later modification.

1. Immutability guarantees all captured applications were benign
2. The backup cannot contain any useful evidence
3. Immutability preserves the captured compromised state as well as legitimate data
4. Disabling immutability would remove the malicious account

**Correct option(s):** 3

- Option 1: That is outside its mechanism.
- Option 2: It may be valuable for investigation and selective recovery.
- Option 3: It protects against later alteration, not prior content defects.
- Option 4: Storage policy does not edit the captured system state.

**ISA-EXPERT-Q0422 · single · design**

Which dependency should be restored before reconnecting rebuilt hosts?

SYNTHETIC ASSESSMENT EVIDENCE: Central identity and policy distribution were compromised and can issue roles and startup tasks to members.

1. Trust the directory because its service process is running
2. Use a new local administrator password while immediately accepting the unchanged central policy
3. Reconnect every host first so the directory can configure it
4. Re-establish trustworthy identity/policy authority or an approved isolated alternative

**Correct option(s):** 4

- Option 1: Liveness is not proof of trustworthy configuration and authority.
- Option 2: Local credential rotation does not make the compromised policy source trustworthy.
- Option 3: That uses the suspect authority before treatment.
- Option 4: Otherwise the clean hosts can inherit harmful state again.

**ISA-EXPERT-Q0423 · single · diagnosis**

What is wrong with restoring a firewall's old signed configuration unchanged?

SYNTHETIC ASSESSMENT EVIDENCE: The backup predates retirement of a supplier tunnel and a routing change needed for the new alarm service.

1. Historical integrity does not establish current authority or functional dependencies
2. The current alarm requirement should be removed to fit the backup
3. The backup is useless for every purpose
4. A signed file cannot be old

**Correct option(s):** 1

- Option 1: The restore can revive excess access and omit required paths.
- Option 2: Recovery should restore the approved service, not redefine it casually.
- Option 3: It can be a controlled input after reconciliation.
- Option 4: Signatures do not make content current.

**ISA-EXPERT-Q0424 · single · design**

How should controller recovery address retained values?

SYNTHETIC ASSESSMENT EVIDENCE: The application needs some production counters retained, but old start commands and maintenance overrides must not resume automatically.

1. Clear every retained value without reviewing process needs
2. Restore every retained value because it was backed up
3. Use the HMI's last screenshot as the sole retained-state source
4. Classify retained items by approved semantics and restore or initialize each with tests

**Correct option(s):** 4

- Option 1: That can lose necessary state and alter behaviour.
- Option 2: Historical state may be unsafe or obsolete in the current conditions.
- Option 3: It may omit internal state and quality context.
- Option 4: A selective policy preserves required state without reviving inappropriate authority.

**ISA-EXPERT-Q0425 · single · diagnosis**

Which defect remains when a restored HMI shows normal values but quality is forced good?

SYNTHETIC ASSESSMENT EVIDENCE: Source loss and stale timestamps no longer affect the display's status because the recovery template overrides quality.

1. Only login permissions matter during HMI recovery
2. The restored supervision cannot represent measurement failure correctly
3. The template is correct because it reduces alarm noise
4. Normal-looking values prove the source is healthy

**Correct option(s):** 2

- Option 1: Operational semantics are also required.
- Option 2: Plausible live-looking values do not establish trustworthy awareness.
- Option 3: Noise reduction does not justify hiding invalid data.
- Option 4: The override can conceal failure.

**ISA-EXPERT-Q0426 · single · design**

Which test validates network recovery after administrator compromise?

SYNTHETIC ASSESSMENT EVIDENCE: The administrator could change routing, local accounts, AAA, certificates, automation and ACLs.

1. Rename the administrator account but retain its keys
2. Verify the relevant management and forwarding state against current approved baselines, including denied old authority
3. Test only internet reachability
4. Restore only production ACLs and assume all other state is unaffected

**Correct option(s):** 2

- Option 1: Renaming does not revoke known credentials.
- Option 2: Administrative scope extends beyond one data-plane rule set.
- Option 3: That is not the required OT boundary or authority set.
- Option 4: The compromised role could alter the listed control-plane objects.

**ISA-EXPERT-Q0427 · single · diagnosis**

What does this trusted-image test omit?

SYNTHETIC ASSESSMENT EVIDENCE: The image is verified, but restoration uses a script from a writable share and a licence service whose integrity is unknown.

1. Recovery tools and enabling dependencies are outside the verified trust claim
2. The script is safe because it is used only during emergencies
3. The image hash necessarily proves the script's integrity
4. Licensing can never affect restoration

**Correct option(s):** 1

- Option 1: A trusted image alone does not secure every execution step.
- Option 2: Emergency timing does not confer provenance or authorization.
- Option 3: They are separate artifacts.
- Option 4: The service may be needed to activate required function.

**ISA-EXPERT-Q0428 · single · design**

Which recovery plan handles an encrypted-vault bootstrap cycle?

SYNTHETIC ASSESSMENT EVIDENCE: Directory recovery credentials are inside a vault that authenticates only through that same directory.

1. Remove encryption from all backups as the only possible solution
2. Store every privileged password publicly to avoid dependency problems
3. Provide an independently controlled, tested bootstrap access path with defined custody and audit
4. Restore the directory using the unavailable vault without further preparation

**Correct option(s):** 3

- Option 1: A scoped key/access recovery design can preserve protection.
- Option 2: Availability does not justify uncontrolled disclosure.
- Option 3: The cycle needs a feasible authorized starting point.
- Option 4: That assumes the missing dependency is already solved.

**ISA-EXPERT-Q0429 · single · diagnosis**

What is incomplete after replacing a compromised gateway with new hardware?

SYNTHETIC ASSESSMENT EVIDENCE: The new gateway works and has a new certificate. The old private key remains accepted by peers and the retired device is unaccounted for.

1. Successful telemetry automatically revokes the prior key
2. Retired identity authority remains valid
3. The old device cannot authenticate because its IP changed
4. The new gateway's certificate must be invalid

**Correct option(s):** 2

- Option 1: Function does not enforce trust-store cleanup.
- Option 2: Replacement enrollment should include closure of the old trust path.
- Option 3: Identity may be usable from another allowed path.
- Option 4: Its validity is separate from the obsolete credential.

**ISA-EXPERT-Q0430 · single · design**

How should supervisory data be reconciled after restoring an older database?

SYNTHETIC ASSESSMENT EVIDENCE: The restored historian lacks two hours of samples. Some gateway buffers contain genuine delayed data; other values can only be estimated.

1. Shift the remaining timestamps to hide the gap
2. Discard all buffered observations because they arrived late
3. Import supported observed backlog with provenance and mark estimates/gaps distinctly
4. Fill every gap with interpolated values labeled as original measurements

**Correct option(s):** 3

- Option 1: That corrupts chronology.
- Option 2: Late genuine data can remain useful if correctly timestamped.
- Option 3: Recovery must preserve the difference between measured and derived information.
- Option 4: That falsifies the evidential meaning.

**ISA-EXPERT-Q0431 · single · diagnosis**

Why does a successful project compilation not complete controller recovery?

SYNTHETIC ASSESSMENT EVIDENCE: The project compiles with the available tool, but its I/O mapping, task period and force table have not been checked on the replacement.

1. Effective runtime and physical interface state remain unverified
2. A compiler success guarantees correct wiring
3. The application cannot run under any circumstance
4. The force table is irrelevant if the source is approved

**Correct option(s):** 1

- Option 1: Compilation is an intermediate software result.
- Option 2: The compiler does not observe field terminals.
- Option 3: It may run while still being unaccepted.
- Option 4: Forces can alter the inputs seen by approved logic.

**ISA-EXPERT-Q0432 · single · design**

Which staged return best preserves containment?

SYNTHETIC ASSESSMENT EVIDENCE: A rebuilt supervisory server needs database, time and identity services, but broad unrestricted access would also reopen the incident path.

1. Keep the server isolated forever despite a required service objective
2. Open all historical routes first and narrow them after normal operations resume
3. Use the compromised administrator's token because it is convenient
4. Enable verified required dependencies in controlled stages, observe behaviour and retain explicit hold/rollback criteria

**Correct option(s):** 4

- Option 1: Recovery needs a feasible controlled reconnection plan.
- Option 2: That exposes the recovered system before boundary verification.
- Option 3: That reintroduces known untrusted authority.
- Option 4: Function can be restored while constraining unnecessary authority.

**ISA-EXPERT-Q0433 · single · diagnosis**

Which supplier assurance is insufficient for accepting firmware recovery?

SYNTHETIC ASSESSMENT EVIDENCE: The supplier says the appliance is clean but provides no applicable version, procedure scope, provenance or verification evidence.

1. The supplier statement proves deliberate deception
2. The owner must invent missing test results to complete the report
3. The owner lacks a reviewable basis for the claimed restored trust
4. All supplier-assisted recovery is inherently unacceptable

**Correct option(s):** 3

- Option 1: Insufficient evidence is not proof of intent.
- Option 2: That would falsify assurance.
- Option 3: A generic statement does not establish what was treated or tested.
- Option 4: It can be valuable with applicable evidence and defined responsibilities.

**ISA-EXPERT-Q0434 · single · design**

Which eradication checklist best fits a credential-and-policy incident?

SYNTHETIC ASSESSMENT EVIDENCE: Evidence identifies stolen administrator credentials, new API tokens, altered startup policy and one changed gateway mapping.

1. Address each observed authority/persistence path and verify current function plus denial of old access
2. Reimage every device indiscriminately without dependency planning
3. Clear the SIEM alert and declare eradication complete
4. Delete the originally detected file only

**Correct option(s):** 1

- Option 1: The checklist follows the actual mechanism and affected state.
- Option 2: That can expand operational impact and still miss upstream authority.
- Option 3: Alert state is not system state.
- Option 4: That omits credentials and policy persistence.

#### Recall

**A historian restore lacks two hours of data. Some gateways hold genuine buffered samples; other values can only be interpolated. How should the restored history be represented?**

Import supported observed backlog with original identity/time/quality and provenance. Preserve known gaps and distinguish derived estimates from measured samples. Do not shift timestamps or label interpolation as physical observation merely to make the trend continuous.

**In this case, what is the justified integrated decision? A clean engineering host image is available, but its BMC key is exposed, the directory still distributes a malicious task and the controller backup contains a forced permissive. The firewall backup also restores a retired supplier tunnel.**

Four independent restoration gaps exist across the three paths. Re-establish platform/BMC trust, correct upstream identity/policy, reconcile controller runtime state and restore current boundary authority. Then validate required function and denied old paths. Reimaging the host repeatedly will not address the other layers.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)

### ISA-EXPERT-L27 — Measure recovery and return service honestly

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L26

Define recovery objectives by their actual service boundary. RPO concerns the tolerable loss of required data or state. RTO concerns elapsed restoration to the defined required service. An hourly schedule does not achieve a one-hour RPO when the last three jobs failed. A 55-minute image copy does not achieve a two-hour RTO if preparation, identity, licences and acceptance add another 75 minutes. State start and end points before the exercise.

A drill should represent the failure scenario it claims. If shared storage remains healthy, the exercise does not demonstrate recovery from its loss. If certificate validation is disabled because the lab lacks time service, authenticated integration remains untested. If the only administrator and online vault are assumed available, a shared identity outage remains an open scenario. Use risk-informed representative exercises and label models and substitutions explicitly.

Measure and report partial outcomes. Live telemetry can return while required historical alarms remain unavailable. Current accounts can work while revoked credentials are still accepted. A recovery can meet time but exceed data-loss limits. These are different acceptance dimensions, not a single green status. Preserve failed runs and variation; a best case does not erase a representative overrun.

Return-to-service authority includes physical readiness. A manual valve left isolated, an unavailable standby or an active maintenance override can contradict recovered software assumptions. Qualified owners must accept the actual operating conditions. Cyber trust checks and process functional checks complement each other without substituting for each other's evidence.

After acceptance, define heightened observation based on the incident path and delayed effects, then transfer ownership. Close temporary routes, credentials and sessions, update baselines and recovery material, and assign open limitations with triggers. A failed drill that reveals a vault cycle is valuable if the team records it, implements a controlled bootstrap and retests. It is not legitimate to rewrite the earlier result as a pass.

#### Worked demonstrations

**Measure recovery and return service honestly — integrated worked case**

Synthetic teaching case; no live equipment was tested.

A declared 120-minute RTO includes preparation, image restoration, identity/licence recovery and acceptance. The measured sequential stages take 25, 55, 30 and 20 minutes. Live values return earlier, but full required operation is accepted only after the final stage.

**Reasoning:** The complete measured result is 130 minutes, so the stated RTO is not met. Report earlier partial-service milestones separately. Investigate the limiting dependencies or procedure and retest comparable conditions; do not start the clock after preparation or omit acceptance to manufacture compliance.

#### Guided practice

A 30-minute image has uncertain compromise provenance. A justified clean source takes 70 minutes and the RTO is 90 minutes. Which path better fits the combined requirements?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** The 70-minute trusted path is preferable under these stated constraints, subject to complete functional and authority validation. The faster option does not satisfy trust merely because it saves time. Preserve the assumptions and any remaining source uncertainty.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Run a synthetic recovery exercise with a declared RPO/RTO, dependency waits, partial-service checkpoints and final acceptance. Record actual model results, failed objectives, corrective actions and the separate vendor/field timing gates.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Evaluate RPO, RTO, representative drill scope, partial restoration and post-incident ownership against declared objectives.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0435 · single · calculation**

Does this recovery exercise meet the declared RTO?

SYNTHETIC ASSESSMENT EVIDENCE: RTO is 120 minutes from service loss to validated required operation. Preparation takes 25 minutes, restore 55, identity/licence recovery 30 and functional/security acceptance 20, all sequential.

1. Yes; image restoration takes only 55 minutes
2. No; the total is 230 minutes
3. Yes; preparation should always be excluded
4. No; total recovery is 130 minutes

**Correct option(s):** 4

- Option 1: That is a subtask, not the required service endpoint.
- Option 2: The supplied durations sum to 130.
- Option 3: The objective starts at service loss under the stated definition.
- Option 4: The declared endpoint includes all four required stages.

**ISA-EXPERT-Q0436 · single · diagnosis**

Which RPO claim is unsupported?

SYNTHETIC ASSESSMENT EVIDENCE: Backups are scheduled every hour, but the last three jobs failed. The newest usable consistent backup is four hours old.

1. The achieved recoverable state is within a one-hour RPO
2. Job failures and usability need review
3. Data after the usable point may require a separate replay source
4. The backup process is configured hourly

**Correct option(s):** 1

- Option 1: Schedule alone does not establish a usable recent recovery point.
- Option 2: They determine actual recoverability.
- Option 3: Such evidence could reduce loss if supported.
- Option 4: That narrower statement is true.

**ISA-EXPERT-Q0437 · single · design**

Which recovery drill scenario tests a meaningful common cause?

SYNTHETIC ASSESSMENT EVIDENCE: The normal plan assumes the directory, vault, backup console and primary administrator workstation are all healthy.

1. Assume separate product names mean the tools cannot fail together
2. Disable every unrelated site service without a bounded plan
3. Repeat only a file restore using all normal services
4. Exercise a justified loss of shared identity or management authority while verifying independent bootstrap and restoration

**Correct option(s):** 4

- Option 1: Shared identity and management can couple them.
- Option 2: A useful drill needs controlled scope and consequence limits.
- Option 3: That does not challenge the shared failure.
- Option 4: The scenario tests whether recovery survives the dependencies it may lose.

**ISA-EXPERT-Q0438 · single · diagnosis**

Why is this RTO measurement misleading?

SYNTHETIC ASSESSMENT EVIDENCE: The timer starts only after vendor activation finishes, although activation takes 18 hours and is required before the application can operate.

1. A required dependency delay was excluded from the declared recovery boundary
2. The image-copy duration is necessarily incorrect
3. A paid support contract guarantees activation is instantaneous
4. Vendor waiting time can never count in recovery

**Correct option(s):** 1

- Option 1: The reported duration understates service restoration.
- Option 2: It may be accurate for that narrower step.
- Option 3: Actual terms and tested performance determine readiness.
- Option 4: If required after service loss, it affects the objective.

**ISA-EXPERT-Q0439 · single · design**

Which functional acceptance complements credential revocation after a controller incident?

SYNTHETIC ASSESSMENT EVIDENCE: The stolen account is rejected and the approved project is loaded. Operators still need proof of required process behaviour.

1. Stop after the denied-login test
2. Verify relevant I/O, modes, permissives, feedback, alarms and restart/failure sequences under authorized conditions
3. Disable every interlock to simplify the functional run
4. Assume RUN mode establishes every required sequence

**Correct option(s):** 2

- Option 1: That covers access but not control function.
- Option 2: Removal of attacker authority does not prove the process application works.
- Option 3: That changes the system being accepted and can violate physical constraints.
- Option 4: Execution status is not complete behavioural proof.

**ISA-EXPERT-Q0440 · single · diagnosis**

What must remain explicit when a recovery meets time but misses data objectives?

SYNTHETIC ASSESSMENT EVIDENCE: Required live service returns within RTO, but the recovered database loses more history than the approved RPO permits.

1. Historical loss can be hidden by changing display dates
2. Meeting RTO automatically waives RPO
3. Recovery is partially successful and the data-loss objective remains unmet
4. The live service should be described as still completely unavailable

**Correct option(s):** 3

- Option 1: That would corrupt the evidence.
- Option 2: One objective does not cancel the other.
- Option 3: Time and recoverable-state objectives are separate.
- Option 4: It may be operating while data acceptance is incomplete.

**ISA-EXPERT-Q0441 · single · design**

How should a recovery team choose between fast and trusted options?

SYNTHETIC ASSESSMENT EVIDENCE: Option A restores in 30 minutes from a source with unresolved compromise. Option B uses justified clean material but needs 70 minutes; the RTO is 90 minutes.

1. Prefer the feasible trusted path B while validating its complete service and authority state
2. Choose A solely because it is faster
3. Restore both sources simultaneously into the production zone
4. Reject B because every slower option is operationally worse

**Correct option(s):** 1

- Option 1: It fits the time constraint without relying on disputed material.
- Option 2: Speed does not satisfy the trust requirement.
- Option 3: That can reintroduce the unresolved compromise.
- Option 4: Both time and trust constraints matter, and B remains within RTO.

**ISA-EXPERT-Q0442 · single · diagnosis**

Which recovery conclusion is limited by a physically unrealistic test?

SYNTHETIC ASSESSMENT EVIDENCE: The drill claims recovery from a failed storage controller, but all data remained on healthy shared storage throughout the test.

1. The stated storage-loss scenario was not actually represented
2. The requirement can be assumed satisfied because storage rarely fails
3. Every host restoration observation is false
4. A simulation label would automatically prove production timing

**Correct option(s):** 1

- Option 1: The drill may prove other steps but not the missing dependency recovery.
- Option 2: Likelihood does not substitute for the claimed test.
- Option 3: Some narrower results may remain valid.
- Option 4: Labeling preserves honesty, not physical equivalence.

**ISA-EXPERT-Q0443 · single · design**

Which post-recovery monitoring is most relevant to the incident path?

SYNTHETIC ASSESSMENT EVIDENCE: The incident used a retired supplier identity and an unauthorized project download through a maintenance gateway.

1. Treat every supplier connection as malicious without task context
2. Watch for reappearance of that authority, related gateway operations, project drift and required process health
3. Stop logging after the first clean boot
4. Monitor only total network bytes

**Correct option(s):** 2

- Option 1: Legitimate support still needs specific authorization and evidence.
- Option 2: Monitoring should test recurrence and sustained service, not only generic volume.
- Option 3: Later reintroduction remains possible.
- Option 4: Low-volume privileged actions may be missed.

**ISA-EXPERT-Q0444 · single · diagnosis**

What is wrong with this return-to-service approval?

SYNTHETIC ASSESSMENT EVIDENCE: The cyber team confirms clean software. The process owner has not verified a manual isolation left during response, and automatic operation assumes that path is open.

1. The process owner should accept without evidence because recovery is urgent
2. The cyber findings have no value until the valve opens
3. The physical operating condition is not accepted by the responsible authority
4. Clean software automatically changes the manual valve position

**Correct option(s):** 3

- Option 1: Urgency needs a controlled decision, not assumed readiness.
- Option 2: They remain valid for their scoped trust properties.
- Option 3: Cyber trust evidence does not establish plant readiness.
- Option 4: The physical state is independent.

**ISA-EXPERT-Q0445 · single · design**

Which evidence should close an emergency operating mode?

SYNTHETIC ASSESSMENT EVIDENCE: The site used local manual supervision and temporary broad access during recovery. Normal service is now available.

1. Announce service restored and leave all temporary measures indefinitely
2. Verify normal function, remove temporary authority, terminate relevant sessions, reconcile physical modes and hand over current records
3. Delete the emergency logs to avoid confusion with normal operation
4. Change only the incident severity to low

**Correct option(s):** 2

- Option 1: That can preserve unnecessary exposure and altered control.
- Option 2: Closing the mode includes both operational and security state.
- Option 3: Those records explain actions and remaining obligations.
- Option 4: Severity does not perform technical closure.

**ISA-EXPERT-Q0446 · single · diagnosis**

What does a recovery exercise reveal if a required licence is tied to failed hardware?

SYNTHETIC ASSESSMENT EVIDENCE: The backup restores correctly, but the application cannot acquire data until a supplier issues a replacement entitlement.

1. A licence/activation dependency limits recoverability
2. The backup must be corrupted
3. Licensing is outside every recovery objective by definition
4. The operator should bypass licensing controls without authorization

**Correct option(s):** 1

- Option 1: Image availability alone does not establish service restoration.
- Option 2: The stated entitlement failure is a separate mechanism.
- Option 3: Required activation affects the service endpoint.
- Option 4: A supported lawful recovery arrangement is needed.

**ISA-EXPERT-Q0447 · single · design**

How should recovery-source trust be documented when compromise timing is uncertain?

SYNTHETIC ASSESSMENT EVIDENCE: Several backups predate detection, but the initial compromise time is unknown. Independent logs and configuration history narrow the likely interval.

1. Choose the source with the most familiar filename
2. Record the selection rationale, corroborating evidence, uncertainty, reconciliation and additional monitoring
3. Declare every pre-detection backup clean automatically
4. Declare every historical backup unusable without analysis

**Correct option(s):** 2

- Option 1: Naming does not establish provenance or clean state.
- Option 2: Detection date alone does not establish a clean cutoff.
- Option 3: Compromise can precede detection.
- Option 4: Some may have a justified trust basis.

**ISA-EXPERT-Q0448 · single · diagnosis**

Which learning outcome follows from a failed restoration drill?

SYNTHETIC ASSESSMENT EVIDENCE: The drill misses RTO because a vault dependency was unavailable. The team records the failure and adds a tested independent bootstrap procedure.

1. The original RTO was achieved retrospectively because the procedure improved
2. The drill exposed and then tested a concrete recovery-readiness improvement
3. The failure should be removed from the portfolio once corrected
4. The corrected procedure guarantees every future recovery scenario

**Correct option(s):** 2

- Option 1: Later improvement does not change the earlier measured result.
- Option 2: A failed exercise can produce valuable evidence and correction.
- Option 3: Keeping it shows diagnosis and the basis of improvement.
- Option 4: The evidence remains bounded to tested conditions.

**ISA-EXPERT-Q0449 · single · design**

Which recovery handover best supports sustained ownership?

SYNTHETIC ASSESSMENT EVIDENCE: The incident team is leaving after service restoration, with one accepted monitoring limitation and a planned firmware replacement.

1. Leave all follow-up tasks assigned to the departing incident team indefinitely
2. Transfer current baselines, restored authority, open limitations, observation tasks, owners and completion triggers
3. Transfer only the statement all systems green
4. Close the risk register because the incident ticket ended

**Correct option(s):** 2

- Option 1: Ownership must remain executable after transition.
- Option 2: The normal team must sustain the accepted state and remaining treatment.
- Option 3: That hides the unresolved obligation.
- Option 4: Remaining accepted limitations still need governance.

**ISA-EXPERT-Q0450 · single · diagnosis**

Which statement accurately describes an offline recovery capstone?

SYNTHETIC ASSESSMENT EVIDENCE: The learner restores synthetic configurations, reconciles identities and measures model execution on a laptop. No real controller or physical process is exercised.

1. The exercise counts as an additional official ISA Expert exam
2. The learner demonstrated the recorded model and analytical recovery outcomes; vendor and field recovery remain separate gates
3. The learner achieved the production site's RTO
4. No recovery reasoning can be assessed without live plant access

**Correct option(s):** 2

- Option 1: The Expert credential is an automatic provider milestone after four certificates.
- Option 2: The claim follows the actual evidence environment.
- Option 3: Laptop model timing does not establish site restoration.
- Option 4: Synthetic environments can test substantial bounded knowledge and implementation logic.

#### Recall

**A 30-minute image has uncertain compromise provenance. A justified clean source takes 70 minutes and the RTO is 90 minutes. Which path better fits the combined requirements?**

The 70-minute trusted path is preferable under these stated constraints, subject to complete functional and authority validation. The faster option does not satisfy trust merely because it saves time. Preserve the assumptions and any remaining source uncertainty.

**In this case, what is the justified integrated decision? A declared 120-minute RTO includes preparation, image restoration, identity/licence recovery and acceptance. The measured sequential stages take 25, 55, 30 and 20 minutes. Live values return earlier, but full required operation is accepted only after the final stage.**

The complete measured result is 130 minutes, so the stated RTO is not met. Report earlier partial-service milestones separately. Investigate the limiting dependencies or procedure and retest comparable conditions; do not start the clock after preparation or omit acceptance to manufacture compliance.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)

## ISA-EXPERT-M10 — Programme architecture and lifecycle identity

### ISA-EXPERT-L28 — Scale a programme without copying hidden assumptions

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L27

Scaling an architecture changes more than device count. A second hall may share engineering authority, identity, update templates, alarm queues and recovery resources with the first. One compromised service or mistaken template can therefore have a larger consequence. A one-hall restoration time does not automatically prove simultaneous recovery when the same workstation, licence and specialist are needed by several halls. Model resource contention and priorities explicitly.

Start brownfield expansion from observed current state. Original diagrams may omit a vendor modem, temporary route or changed gateway mapping. Reconcile effective authority before copying templates. Parameterize legitimate site differences, review trust anchors and roles, and verify the resulting instance. Identical models can have different firmware, sensor ranges, libraries and physical mappings. Reuse evidence through justified equivalence, not through renaming.

Procurement should assess lifecycle feasibility alongside initial capability and price. Consider supported updates, offline activation, tool/library availability, credential custody, spare readiness, restoration evidence and exit arrangements. A cheaper product may require scarce manual certificate work; a spare may be unusable without compatible firmware and entitlements. A generic standards-compliance claim needs parts, editions, scope, versions and assessed conditions before it can support assurance.

Keep discipline scope honest while accounting for interfaces. A network/controls/cybersecurity programme can analyze a command path affecting cooling or electrical equipment without claiming every mechanical or protection competency. Assign physical design, commissioning and switching authority to qualified owners and retain the relevant external gates. Excluding a discipline from primary study does not justify ignoring the consequences of its interface.

Programme decisions should preserve constraints while pursuing efficiency. Consolidation may reduce licences and hardware while increasing common-cause dependence on one identity cluster or vault. Compare those effects against required resilience and recovery, not a single cost line or product count. A controlled transition can combine interim risk treatment with tested replacement rather than forcing an unsupported immediate migration or indefinite legacy exception.

#### Worked demonstrations

**Scale a programme without copying hidden assumptions — integrated worked case**

Synthetic teaching case; no live equipment was tested.

Three halls share one recovery workstation. Each requires 70 minutes of exclusive use after a common outage, and all must recover within 120 minutes. The programme cites a successful 70-minute single-hall drill as proof.

**Reasoning:** The shared resource makes that inference invalid. Under the simplified exclusive-use model, completion times would be 70, 140 and 210 minutes. The programme needs additional justified resources, a different sequence or an owner-approved service prioritization/design that meets the actual objectives. The original drill remains useful for one task duration.

#### Guided practice

A new gateway template copies a temporary engineering account, an old supplier CA and Hall A sensor ranges into Hall B. What should be reviewed before reuse?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** Reconcile the source baseline, remove or govern temporary authority, establish the current supplier trust and verify Hall B mappings and ranges. Test the instantiated configuration, not only the template's prior approval. Record which evidence transfers and which site-specific properties remain new.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Prepare a brownfield expansion or supplier-transition dossier. Include shared-failure scenarios, recovery resource scheduling, template review, lifecycle support and explicit physical-discipline ownership boundaries.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Evaluate expansion, procurement and supplier transitions using shared dependencies, lifecycle feasibility and bounded discipline responsibilities.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0451 · single · design**

Which first deliverable best prevents a brownfield expansion from inheriting undocumented authority?

SYNTHETIC ASSESSMENT EVIDENCE: Hall B will copy Hall A's gateway templates and use its engineering service. Hall A's as-built access paths differ from its original drawings.

1. An observed current-state dependency and authority model, reconciled with approved requirements
2. A rule allowing every Hall B address through Hall A's boundary
3. A purchase order for identical gateway models
4. A direct copy of the original Hall A drawing labeled Hall B

**Correct option(s):** 1

- Option 1: Copying an unreconciled design can propagate hidden paths into the new hall.
- Option 2: That creates broad access before requirements are defined.
- Option 3: Hardware similarity does not establish current architecture or permission scope.
- Option 4: The drawing is known to differ from effective state.

**ISA-EXPERT-Q0452 · single · diagnosis**

Which expansion assumption is invalid?

SYNTHETIC ASSESSMENT EVIDENCE: The original recovery test restored one hall within two hours. The new plan shares the same engineer, licence pool and restore server across three halls after a common incident.

1. The new plan should assess resource scheduling and priorities
2. The original test can still inform one restoration task's duration
3. The one-hall timing automatically proves simultaneous three-hall recovery
4. Common-cause incidents deserve a distinct recovery scenario

**Correct option(s):** 3

- Option 1: The shared dependencies make this relevant.
- Option 2: That narrower evidence remains useful.
- Option 3: Shared resources and concurrency constraints change the scenario.
- Option 4: They differ from one isolated hall failure.

**ISA-EXPERT-Q0453 · single · design**

Which requirement should govern reuse of a gateway template?

SYNTHETIC ASSESSMENT EVIDENCE: The template contains telemetry mappings, vendor trust anchors and a broad temporary engineering account. Hall B needs different source ranges and a new supplier.

1. Reuse only justified components after parameter, identity and authority review, then verify the resulting instance
2. Reuse the complete template because it passed once in Hall A
3. Delete every setting and use factory defaults without requirements
4. Change only the hall name in the user interface

**Correct option(s):** 1

- Option 1: A template is an engineering input, not automatic acceptance.
- Option 2: Its site-specific values and temporary authority may be unsuitable.
- Option 3: That discards useful controlled information while adding uncertainty.
- Option 4: Labels do not update mappings or trust relationships.

**ISA-EXPERT-Q0454 · single · calculation**

Can the proposed single recovery workstation meet this simultaneous objective?

SYNTHETIC ASSESSMENT EVIDENCE: Two halls each require 70 minutes of exclusive workstation use. Both must complete within 120 minutes of a common outage; no overlap is possible and other tasks are ignored.

1. No; the total must be 240 minutes
2. Yes; each individual job is below 120 minutes
3. No; the second completion is at 140 minutes under the stated resource constraint
4. Yes; average completion time is 105 minutes

**Correct option(s):** 3

- Option 1: The supplied work adds to 140 minutes.
- Option 2: That ignores contention for the shared workstation.
- Option 3: Two exclusive 70-minute jobs exceed the common deadline.
- Option 4: The objective applies to both halls, not their average.

**ISA-EXPERT-Q0455 · single · diagnosis**

Which architectural gap appears when a central alarm service is scaled?

SYNTHETIC ASSESSMENT EVIDENCE: A new hall adds twice the event rate. Normal traffic passes, but a single alarm burst exhausts the shared queue and delays both halls' critical notifications.

1. The shared service needs burst-capacity and prioritization analysis tied to response requirements
2. Adding more dashboard users necessarily increases notification capacity
3. Each hall's sensors must all be defective
4. The existing tests prove the service can accept unlimited growth

**Correct option(s):** 1

- Option 1: Average successful delivery does not establish peak event performance.
- Option 2: User count is not the bottleneck mechanism.
- Option 3: The common queue can explain the cross-hall delay.
- Option 4: They covered a different workload.

**ISA-EXPERT-Q0456 · single · design**

How should an expansion review handle an initially excluded physical system?

SYNTHETIC ASSESSMENT EVIDENCE: The near-term programme focuses on network, controls, cybersecurity and digital integration. A new cooling interface introduces a command affecting physical flow.

1. Keep the stated programme boundary while explicitly assigning physical design, acceptance and authorization dependencies to qualified owners
2. Omit the physical effect because it lies outside the primary study scope
3. Claim full mechanical engineering competence because the command uses an IP network
4. Add every possible engineering discipline to the scope without resources or gates

**Correct option(s):** 1

- Option 1: Scope discipline must still account for interfaces and consequences.
- Option 2: The interface consequence remains relevant to cyber-integrated design.
- Option 3: A digital interface does not confer the underlying discipline's competence.
- Option 4: Uncontrolled scope expansion does not establish competence.

**ISA-EXPERT-Q0457 · single · diagnosis**

What is wrong with comparing risk scores across halls without their scales?

SYNTHETIC ASSESSMENT EVIDENCE: Hall A uses likelihood categories based on exposure opportunity. Hall B uses categories based on annual probability ranges. Both report a score of 12.

1. The halls have exactly equal risk because the scores match
2. Adding the two scores gives a meaningful site probability
3. Equal numbers may not represent comparable risk judgments
4. One assessment must necessarily be fraudulent

**Correct option(s):** 3

- Option 1: Numeric equality is not semantic equivalence.
- Option 2: Ordinal or differently defined scores cannot be summed that way.
- Option 3: The scales, assumptions and decision rules differ.
- Option 4: Different methods can be legitimate but need reconciliation.

**ISA-EXPERT-Q0458 · single · design**

Which handover supports ownership of a shared engineering service?

SYNTHETIC ASSESSMENT EVIDENCE: Network, controls and security teams each own part of the service. No one currently approves its end-to-end degraded-mode behaviour.

1. Use a generic shared mailbox as the only ownership record
2. Assign an accountable service owner and explicit cross-team decisions, dependencies and acceptance criteria
3. Let the team with the most administrator accounts decide by default
4. Remove all team responsibilities and rely on the supplier

**Correct option(s):** 2

- Option 1: A mailbox does not define authority or required outcomes.
- Option 2: Component ownership needs a coordinated outcome boundary.
- Option 3: Privilege count is not governance authority.
- Option 4: The owner still needs accountable integration and operational decisions.

**ISA-EXPERT-Q0459 · single · diagnosis**

Which evidence would challenge the claimed benefit of architecture consolidation?

SYNTHETIC ASSESSMENT EVIDENCE: Consolidation reduces server count but makes all halls depend on one identity cluster and one recovery vault. The report counts only licence savings.

1. Licence savings are never relevant to engineering decisions
2. The report omits common-cause exposure and restoration consequences
3. More servers always means better security
4. Fewer servers always means lower total risk

**Correct option(s):** 2

- Option 1: They matter within a complete lifecycle evaluation.
- Option 2: Efficiency needs to be assessed against the required resilience envelope.
- Option 3: Complexity can introduce other risks; count alone is insufficient.
- Option 4: The dependency structure can become more concentrated.

**ISA-EXPERT-Q0460 · single · design**

What should an expansion capstone prove before claiming transferable competence?

SYNTHETIC ASSESSMENT EVIDENCE: The learner successfully integrated one simulated cooling cell and now proposes a multi-hall architecture.

1. Demonstrate how requirements, shared dependencies, scale, authority and recovery change across the expanded design
2. Claim site-wide physical competence from the original emulator
3. Duplicate the same cell diagram and multiply the quiz score
4. Discard the original cell work entirely

**Correct option(s):** 1

- Option 1: Transfer requires reasoning about new conditions, not just duplication.
- Option 2: The environment did not establish that gate.
- Option 3: That does not examine common services or cross-hall consequences.
- Option 4: It remains useful as a bounded component of the expanded evidence.

**ISA-EXPERT-Q0461 · single · diagnosis**

Which lifecycle cost assumption is missing from this product comparison?

SYNTHETIC ASSESSMENT EVIDENCE: Gateway A costs less initially but requires annual manual certificate replacement by a scarce specialist. Gateway B supports an approved automated renewal workflow.

1. Manual processes cannot ever be acceptable
2. The cost and feasibility of sustaining the required trust lifecycle
3. The more expensive product is automatically better in every respect
4. Certificate renewal has no operational consequence

**Correct option(s):** 2

- Option 1: They can be feasible with sufficient resources and controls.
- Option 2: Purchase price alone omits recurring operational work and failure exposure.
- Option 3: The complete requirements and evidence still matter.
- Option 4: Failed renewal can interrupt required authenticated service.

**ISA-EXPERT-Q0462 · single · design**

Which replacement decision respects both support and process constraints?

SYNTHETIC ASSESSMENT EVIDENCE: A legacy device is unsupported, but immediate replacement would require an untested control migration during peak load. A bounded exposure reduction is feasible.

1. Retain the device forever because migration is difficult
2. Plan a tested transition with interim risk treatment and explicit owner decisions for the current period
3. Replace immediately without compatibility or operational review
4. Declare unsupported status irrelevant if the device still responds

**Correct option(s):** 2

- Option 1: The support and vulnerability risks remain.
- Option 2: Support risk and migration consequence must be managed together.
- Option 3: That can create a preventable service failure.
- Option 4: Functioning today does not provide future support or trustworthy recovery.

**ISA-EXPERT-Q0463 · single · diagnosis**

What is the issue with a supplier's universal compliance statement?

SYNTHETIC ASSESSMENT EVIDENCE: The proposal says all products are compliant with IEC 62443 but names no parts, editions, scope, versions or assessed conditions.

1. Any reference to the standard automatically covers asset-owner processes
2. The statement proves every system integration will fail
3. The statement is too unspecific to support the required assurance claim
4. A certificate for one unrelated component establishes every product and owner-process claim

**Correct option(s):** 3

- Option 1: Product and owner obligations differ.
- Option 2: Insufficient specificity is not proof of failure.
- Option 3: Applicability requires identifiable requirements and evidence boundaries.
- Option 4: Assurance must match the specific assessed scope rather than transfer by association.

**ISA-EXPERT-Q0464 · single · design**

Which procurement criterion reduces future vendor lock-in risk for recovery?

SYNTHETIC ASSESSMENT EVIDENCE: The application can be restored only by one supplier using undisclosed configurations and a proprietary activation process.

1. Require disclosure of every unrelated supplier trade secret
2. Store only the sales contact's phone number
3. Require agreed access to necessary artifacts, supported recovery procedures, entitlements and evidence, with clear limits
4. Assume a warranty guarantees any recovery time requested later

**Correct option(s):** 3

- Option 1: The requirement should be scoped to the service and authorized evidence need.
- Option 2: Contact information alone does not establish a restoration method.
- Option 3: Recoverability needs feasible contractual and technical arrangements.
- Option 4: Terms and demonstrated dependencies matter.

**ISA-EXPERT-Q0465 · single · diagnosis**

Which assumption weakens this spare strategy?

SYNTHETIC ASSESSMENT EVIDENCE: The spare is the same model but has incompatible firmware, missing licences and no tested project conversion path.

1. The inventory entry alone proves readiness
2. The spare cannot ever be made useful
3. Physical model equivalence does not establish operational readiness
4. A successful power-on self-test proves the spare can execute the required restored application

**Correct option(s):** 3

- Option 1: A recorded asset is not a tested recovery capability.
- Option 2: It may be prepared through supported updates and testing.
- Option 3: A usable spare requires a compatible and authorized restoration environment.
- Option 4: Basic hardware startup does not establish firmware, licence or project compatibility.

**ISA-EXPERT-Q0466 · single · design**

How should a supplier transition verify the loss of former authority?

SYNTHETIC ASSESSMENT EVIDENCE: The outgoing supplier used direct VPN, broker access and BMC keys. The incoming supplier uses a new controlled route.

1. Keep both routes indefinitely without a current owner decision
2. Verify only that the new supplier can connect
3. Test rejection of the outgoing credentials on each former path while verifying the new approved workflow
4. Trust the contract end date to revoke every key automatically

**Correct option(s):** 3

- Option 1: That preserves unnecessary exposure.
- Option 2: That does not establish removal of the old paths.
- Option 3: The transition needs effective closure and continuity.
- Option 4: Technical credentials can outlive contracts.

**ISA-EXPERT-Q0467 · single · diagnosis**

What should the owner infer when replacement acceptance uses only vendor demonstrations?

SYNTHETIC ASSESSMENT EVIDENCE: The demonstration uses the supplier's lab, generic points and unrestricted administrator access. Site-specific roles, mappings and recovery dependencies are absent.

1. The demonstration establishes limited product capability, not full site suitability or achieved behaviour
2. Every site will behave identically if it buys the same model
3. The owner should label the demonstration as site acceptance
4. The product has no useful capability because the test was not on site

**Correct option(s):** 1

- Option 1: The integration conditions need separate evidence.
- Option 2: Configuration and dependencies differ.
- Option 3: That would misstate the environment and scope.
- Option 4: The bounded demonstration can still inform selection.

#### Recall

**A new gateway template copies a temporary engineering account, an old supplier CA and Hall A sensor ranges into Hall B. What should be reviewed before reuse?**

Reconcile the source baseline, remove or govern temporary authority, establish the current supplier trust and verify Hall B mappings and ranges. Test the instantiated configuration, not only the template's prior approval. Record which evidence transfers and which site-specific properties remain new.

**In this case, what is the justified integrated decision? Three halls share one recovery workstation. Each requires 70 minutes of exclusive use after a common outage, and all must recover within 120 minutes. The programme cites a successful 70-minute single-hall drill as proof.**

The shared resource makes that inference invalid. Under the simplified exclusive-use model, completion times would be 70, 140 and 210 minutes. The programme needs additional justified resources, a different sequence or an owner-approved service prioritization/design that meets the actual objectives. The original drill remains useful for one task duration.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)
- [ISA public standards-series scope and principal roles](https://www.isa.org/standards-and-publications/isa-standards/isa-iec-62443-series-of-standards)

### ISA-EXPERT-L29 — Use diagnostic automation as bounded engineering assistance

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L28

A diagnostic assistant can retrieve evidence, compare configurations, explain mechanisms and draft changes. Its value depends on the quality and scope of its inputs and the authority of its tools. A read-only role should be enforced at data and action interfaces, not only in a prompt or hidden button. A token with gateway write scope remains write-capable even if the interface says observer. Review permission changes when connectors or software are updated.

Treat logs, operator notes, repository files and retrieved documents as evidence, not instructions that grant execution authority. An attacker-controlled log line can ask for deletion or privilege escalation. Parse data through constrained schemas and maintain a separate authorization channel for consequential actions. A denied diagnostic operation is not permission for the tool to request or try administrator credentials automatically.

Preserve the distinction between proposal and execution. A generated command is not a deployed change; a drafted fix does not establish the running state. Record input provenance, age, assumptions, tool/version, proposed effect, constraints, approval where required, actual results and validation. A checker that observes eight of ten devices should report the two missing observations, not infer compliance from silence.

Generated explanations need engineering review. A stale export supports a finding about that snapshot, not a definite claim about the current firewall. A decoded packet summary without capture point or raw context can suggest hypotheses but cannot reconstruct unseen evidence with certainty. A fluent account of root cause may still confuse occurrence and receipt time. Verify standards citations against the applicable authoritative edition rather than treating confident wording as normative evidence.

Evaluate usefulness with decision accuracy, traceability, bounded authority and operational outcomes alongside time savings. A loop that increases timeouts whenever data becomes stale can worsen the polling delay it is trying to fix. Automated advice must be tested against the causal mechanism and required constraints. Preserve originals when producing normalized timelines; the assistant's narrative must remain checkable against primary records.

#### Worked demonstrations

**Use diagnostic automation as bounded engineering assistance — integrated worked case**

Synthetic teaching case; no live equipment was tested.

An assistant reads last month's firewall export, confidently claims the current site is exposed and opens a proposed-change page. The page silently calls a deployment API using an administrator token.

**Reasoning:** The evidence claim overreaches the snapshot, and the workflow crosses from advice to action without the intended authorization boundary. Restrict the diagnostic identity, separate review from deployment, retain source age and require current-state verification. Opening an explanation is not equivalent to approving a live change.

#### Guided practice

A diagnostic loop increases poll timeouts whenever stale alarms occur. The longer waits further delay healthy devices. What should the engineer change?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** Stop treating the symptom as a universal instruction. Analyze polling order, retries, failed-unit isolation and freshness constraints, then propose a supported bounded change with representative tests. The feedback policy should not self-amplify delay or widen its own authority.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Build an isolated advisory workflow that reads synthetic evidence and produces a proposed change with citations, assumptions and tests. Demonstrate rejection of an instruction embedded in a log, denied write authority and honest reporting of unavailable targets.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Design and assess AI-assisted diagnosis using evidence provenance, enforced read scope and separately authorized changes.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0468 · single · design**

Which tool boundary best fits an AI diagnostic assistant?

SYNTHETIC ASSESSMENT EVIDENCE: The assistant must explain logs, compare approved and observed configurations, and propose changes. It must not directly alter controllers.

1. Hide write functions in the interface while leaving an unrestricted backend token
2. Provide enforced read-only data access and a separate authorized change workflow with reviewed outputs
3. Treat every recommendation as automatically approved because it cites a standard
4. Give it administrator credentials and rely only on a prompt saying be careful

**Correct option(s):** 2

- Option 1: Alternate calls can still use the token's authority.
- Option 2: The tool's effective authority should match its advisory purpose.
- Option 3: A citation does not confer operational authorization.
- Option 4: Instructions do not replace feasible technical permission boundaries.

**ISA-EXPERT-Q0469 · single · diagnosis**

Which failure is exposed by this assistant output?

SYNTHETIC ASSESSMENT EVIDENCE: The assistant cites a configuration export from last month and states that the current firewall definitely permits a risky path. No running-state access is available.

1. The conclusion exceeds the supplied evidence's age and scope
2. The risky path cannot exist because the export is old
3. The assistant may claim it removed the rule after drafting a command
4. The assistant's confidence substitutes for device observation

**Correct option(s):** 1

- Option 1: It can identify a risk in the snapshot and request current verification.
- Option 2: It may still exist; the evidence is simply incomplete.
- Option 3: A proposed action is not executed enforcement.
- Option 4: Confidence does not provide current state.

**ISA-EXPERT-Q0470 · single · design**

How should the assistant handle a log line containing an instruction to run a repair command?

SYNTHETIC ASSESSMENT EVIDENCE: The log is supplied as incident evidence and may contain attacker-controlled text.

1. Promote the log's author to an administrator automatically
2. Delete the line before analysis without preserving it
3. Treat the line as data, explain its significance and preserve the separate authorization boundary
4. Execute the command because it came from a device log

**Correct option(s):** 3

- Option 1: That would transform untrusted content into authority.
- Option 2: It may be important incident evidence.
- Option 3: Evidence content cannot grant tool-execution permission.
- Option 4: The source is not a trusted instruction channel.

**ISA-EXPERT-Q0471 · single · diagnosis**

What is the concern when a diagnostic connector update adds write scopes?

SYNTHETIC ASSESSMENT EVIDENCE: The user interface still says read-only, but the refreshed token now permits gateway configuration changes.

1. The connector remains read-only because the button label is unchanged
2. The added scopes are harmless unless a user notices them
3. The effective permission boundary changed without a corresponding approved role change
4. The update's valid signature proves the new scope is appropriate

**Correct option(s):** 3

- Option 1: Presentation does not constrain token capabilities.
- Option 2: They are available to misuse regardless of awareness.
- Option 3: Labels must be checked against actual API scope and enforcement.
- Option 4: Origin does not establish local authorization need.

**ISA-EXPERT-Q0472 · single · design**

Which audit record makes an automated recommendation reviewable?

SYNTHETIC ASSESSMENT EVIDENCE: An assistant suggests changing a poll timeout to address intermittent stale values.

1. Retain input provenance, assumptions, model/tool version, proposed change, expected effect, constraints and required validation
2. Treat the recommendation as a measured operational improvement
3. Retain only the final sentence recommending the new value
4. Record a fabricated successful test to make the recommendation actionable

**Correct option(s):** 1

- Option 1: The reviewer needs the basis and limits of the advice.
- Option 2: A proposal is not observed outcome evidence.
- Option 3: That hides evidence and uncertainty.
- Option 4: Testing must actually occur in its stated environment.

**ISA-EXPERT-Q0473 · single · diagnosis**

Why is this automated remediation loop unstable?

SYNTHETIC ASSESSMENT EVIDENCE: A script increases timeouts whenever it sees a communications alarm. Longer timeouts worsen polling delay, causing more stale-data alarms and further increases.

1. More automation iterations guarantee convergence
2. Every timeout alarm proves a device needs a longer timeout
3. The feedback rule treats the symptom without modeling its causal effect on freshness
4. The loop is safe because it changes no physical output directly

**Correct option(s):** 3

- Option 1: The feedback sign and constraints matter.
- Option 2: Congestion, scheduling and other failures can produce similar symptoms.
- Option 3: The intervention reinforces the observed problem.
- Option 4: Delayed or misleading telemetry can affect operation and response.

**ISA-EXPERT-Q0474 · single · design**

Which review should precede deploying a generated PLC code suggestion?

SYNTHETIC ASSESSMENT EVIDENCE: The assistant proposes a timer change based on an incomplete excerpt and has not seen the retained-state policy or library version.

1. Reject all generated suggestions without examining any evidence
2. Qualified review of the full applicable logic, dependencies, process requirement and representative tests under change authority
3. Treat fluent explanation as equivalent to vendor validation
4. Download it directly because the code compiles in the assistant's example

**Correct option(s):** 2

- Option 1: Suggestions can be useful inputs when critically reviewed and tested.
- Option 2: The suggestion lacks context needed for safe implementation.
- Option 3: Clarity does not prove compatibility or correctness.
- Option 4: Compilation of an excerpt does not establish system behaviour.

**ISA-EXPERT-Q0475 · single · diagnosis**

What is wrong with this assistant-generated root-cause report?

SYNTHETIC ASSESSMENT EVIDENCE: It describes a controller reboot as the cause of an outage, but the only source is a later operator note and the device log is missing.

1. A more detailed narrative would make the causal claim certain
2. Operator notes never have investigative value
3. The report presents an uncorroborated account as a confirmed causal finding
4. The reboot definitely did not occur because the device log is missing

**Correct option(s):** 3

- Option 1: Detail does not replace corroboration.
- Option 2: They can be useful evidence with appropriate provenance and limits.
- Option 3: It should distinguish the note, inference and evidence gap.
- Option 4: Absence of a log does not prove absence of the event.

**ISA-EXPERT-Q0476 · single · design**

How should an evidence-retrieval assistant protect sensitive operational records?

SYNTHETIC ASSESSMENT EVIDENCE: Authorized engineers need logs for diagnosis, but the records include credentials, personal identifiers and critical topology details.

1. Let the assistant decide its own access level from the log content
2. Remove every technical field so no diagnosis is possible
3. Use scoped access, appropriate redaction/minimization, protected storage and auditable retrieval while preserving necessary evidence
4. Publish every raw record to simplify collaboration

**Correct option(s):** 3

- Option 1: Data cannot grant authority to itself.
- Option 2: Protection should preserve necessary authorized utility.
- Option 3: Usability and confidentiality must be designed together.
- Option 4: That exceeds the intended audience and exposure need.

**ISA-EXPERT-Q0477 · single · diagnosis**

Which test reveals overreach in a supposedly advisory workflow?

SYNTHETIC ASSESSMENT EVIDENCE: A recommendation page silently calls a deployment API when the user opens the explanation, using a service administrator identity.

1. The user approved all changes by opening a report
2. Logging the deployment afterward creates prior authorization
3. Viewing advice triggers an unintended state-changing action
4. The action is harmless because it is initiated by page rendering

**Correct option(s):** 3

- Option 1: Reading information is not the same as authorizing deployment.
- Option 2: Audit evidence does not retroactively grant permission.
- Option 3: The workflow crosses the advisory/action boundary without explicit authorized execution.
- Option 4: Trigger type does not reduce its authority or consequence.

**ISA-EXPERT-Q0478 · single · design**

Which automation result should be reported after partial target failure?

SYNTHETIC ASSESSMENT EVIDENCE: A baseline checker reads eight gateways successfully and cannot reach two. It detects no drift among the eight.

1. Report all ten compliant because no failure response was received
2. Report the eight observed results and the two unresolved targets separately
3. Reuse last year's results without identifying their age
4. Mark every gateway noncompliant automatically

**Correct option(s):** 2

- Option 1: No response is not evidence of compliance.
- Option 2: A partial observation cannot support an estate-wide no-drift claim.
- Option 3: That conceals the observation gap.
- Option 4: Unreachable and observed drift are different states.

**ISA-EXPERT-Q0479 · single · diagnosis**

What limits a language model's protocol diagnosis here?

SYNTHETIC ASSESSMENT EVIDENCE: The model sees a decoded summary but not the raw capture, capture point, filters or clock assumptions.

1. A fluent explanation proves the packet path exactly
2. Its inference is constrained by missing observation context and possible decoding errors
3. The summary has no possible value
4. The model can reconstruct every missing byte with certainty

**Correct option(s):** 2

- Option 1: The missing context can change interpretation.
- Option 2: A plausible explanation needs validation against primary evidence.
- Option 3: It can guide hypotheses within its scope.
- Option 4: Unseen data cannot be reliably invented.

**ISA-EXPERT-Q0480 · single · design**

Which operating rule prevents automation from widening its own authority?

SYNTHETIC ASSESSMENT EVIDENCE: A diagnostic tool encounters a denied API operation and proposes requesting an administrator token automatically.

1. Keep privilege changes subject to separately authorized role review and defined scope
2. Automatically grant the requested token whenever a diagnostic fails
3. Retry with every stored secret until one works
4. Disable all auditing of denied requests to reduce noise

**Correct option(s):** 1

- Option 1: A denied action is not permission for self-escalation.
- Option 2: That turns errors into privilege expansion.
- Option 3: That bypasses intended access control.
- Option 4: Denials can reveal both defects and overreach.

**ISA-EXPERT-Q0481 · single · diagnosis**

Why is a generated standards citation insufficient for a conformance claim?

SYNTHETIC ASSESSMENT EVIDENCE: An assistant cites a clause number from memory, but the project has not checked the applicable licensed edition or exact requirement.

1. The owner can replace licensed review with the assistant's confidence score
2. The normative reference and applicability are unverified
3. A citation's presence proves implementation and testing
4. Every generated citation is necessarily false

**Correct option(s):** 2

- Option 1: Confidence does not establish authoritative requirements.
- Option 2: Conformance needs authoritative edition-specific review and evidence.
- Option 3: Reference text is not deployed behaviour.
- Option 4: It may be correct but must be checked.

**ISA-EXPERT-Q0482 · single · design**

How should a programme evaluate diagnostic-assistant usefulness?

SYNTHETIC ASSESSMENT EVIDENCE: The tool reduces report-writing time but sometimes confuses source and receipt timestamps and proposes broad firewall permits.

1. Count the number of words in each explanation
2. Use response speed as the sole success measure
3. Measure decision accuracy, evidence traceability, constrained authority and operational outcomes alongside time savings
4. Approve every recommendation because the average user rating is high

**Correct option(s):** 3

- Option 1: Length does not establish correctness or utility.
- Option 2: Fast incorrect advice can increase risk.
- Option 3: Efficiency must not conceal degraded engineering judgment.
- Option 4: Satisfaction is not sufficient technical validation.

**ISA-EXPERT-Q0483 · single · diagnosis**

What is the issue with an assistant that rewrites raw incident evidence to match its narrative?

SYNTHETIC ASSESSMENT EVIDENCE: Original timestamps and event IDs are replaced by a normalized story, and the source records are deleted.

1. A coherent narrative proves the edited data is accurate
2. The workflow destroys provenance and makes its interpretation difficult to verify
3. Normalization always requires deletion of originals
4. The final document's signature restores the missing originals

**Correct option(s):** 2

- Option 1: Consistency can be manufactured by removing contradictions.
- Option 2: Derived analysis should preserve originals and transformation assumptions.
- Option 3: A derived view can coexist with retained source evidence.
- Option 4: Signing the derivative cannot reconstruct lost provenance.

**ISA-EXPERT-Q0484 · single · design**

Which competence claim is reasonable after building a read-only diagnostic prototype?

SYNTHETIC ASSESSMENT EVIDENCE: The learner implements scoped retrieval, evidence citations and a separate proposed-change queue in an isolated lab.

1. The learner has proven autonomous plant operation is safe
2. The learner demonstrated the tested advisory architecture and boundaries, with production access and field effects still unassessed
3. The app should issue an official professional licence
4. The prototype replaces the need for controls and network expertise

**Correct option(s):** 2

- Option 1: The prototype was advisory and isolated.
- Option 2: The claim matches the environment and implemented controls.
- Option 3: A study application has no such authority.
- Option 4: Its outputs still require informed interpretation.

#### Recall

**A diagnostic loop increases poll timeouts whenever stale alarms occur. The longer waits further delay healthy devices. What should the engineer change?**

Stop treating the symptom as a universal instruction. Analyze polling order, retries, failed-unit isolation and freshness constraints, then propose a supported bounded change with representative tests. The feedback policy should not self-amplify delay or widen its own authority.

**In this case, what is the justified integrated decision? An assistant reads last month's firewall export, confidently claims the current site is exposed and opens a proposed-change page. The page silently calls a deployment API using an administrator token.**

The evidence claim overreaches the snapshot, and the workflow crosses from advice to action without the intended authorization boundary. Restrict the diagnostic identity, separate review from deployment, retain source age and require current-state verification. Opening an explanation is not equivalent to approving a live change.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)
- [ISA public standards-series scope and principal roles](https://www.isa.org/standards-and-publications/isa-standards/isa-iec-62443-series-of-standards)

### ISA-EXPERT-L30 — Demonstrate the intended lifecycle identity

Estimated study time: 90 minutes before independent work. Prerequisite chapters: ISA-EXPERT-L29

The intended identity is demonstrated by connected capability, not by a list of labels. Organize the portfolio around requirements and lifecycle outcomes: understand a process, assess its risk, design interfaces and authority, implement a supported baseline, commission it, operate and maintain it, diagnose failures, respond to incidents and restore trustworthy service. Certificate paths can map into that structure without becoming the only organizing principle.

A discriminating capstone supplies unfamiliar evidence: system diagrams, point tables, flow policies, identities, release history and incident records with conflicting clues. The learner should state what is known, compare hypotheses, identify a discriminating test, propose a scoped correction, preserve required physical function and define acceptance and recovery. Normal success alone does not demonstrate denied authority, failure handling or restoration. Include a documented failed attempt and its justified correction.

Keep evidence categories explicit. Knowledge questions assess recall and reasoning under their conditions. Safe scripts and emulators demonstrate modeled implementation. Vendor tools and representative hardware establish additional product-specific behaviour. Calibrated field work and authorized operations establish physical and site-specific competence. Existing verified experience can satisfy applicable gates, but an app score cannot create employer switching authority or replace every vendor practical.

This integration bank is original instructional assessment. Its quantity does not guarantee breadth, psychometric calibration or an examination pass. Repeated superficial variants should not be counted as new engineering decisions. Review items for distinct objectives, plausible alternatives, self-contained evidence and unambiguous reasoning. Maintain public-source dates and revise mappings when provider requirements change; do not invent private blueprint weightings or reproduce actual examinations.

ISA's Expert milestone is awarded through the provider's four specialist certificate requirements, not an additional official exam created here. This course supplies an authored integration review and portfolio path. Official training/exams, licensed normative review and required real-world competence checks remain separately tracked. A strong final readiness statement names substantial demonstrated outcomes and the specific remaining gates without either overstating completion or dismissing useful learning.

#### Worked demonstrations

**Demonstrate the intended lifecycle identity — integrated worked case**

Synthetic teaching case; no live equipment was tested.

A learner has passed the app banks, built a read-only diagnostic prototype, completed simulated controller recovery and produced a detailed architecture. No actual vendor engineering download, calibrated field measurement or production recovery has been verified.

**Reasoning:** The learner has meaningful knowledge, design and simulated implementation evidence. The readiness report should state those achievements and map the unverified vendor, physical and operational gates to concrete tasks and acceptance criteria. It should not claim universal field authority or an automatic provider credential from app completion.

#### Guided practice

A portfolio contains 200 questions that differ only in product name while asking the same signed-image trust decision. How should breadth be assessed?

**Hint:** Identify the requirement, effective mechanism and evidence boundary before choosing an intervention. Distinguish what is observed from what remains an assumption.

**Worked solution:** Count the underlying mechanisms and decisions, not renamed stems. Repetition can support memory, but it should not inflate distinct coverage. Add genuinely different evidence interpretation, implementation, failure, constraint and recovery decisions, with plausible alternatives and specific explanations.

#### Independent task

Environment: analytical / local synthetic / supported vendor or authorized physical extension

Complete an integrated evidence dossier for an unfamiliar synthetic hall. Include scope, risk/CRS trace, architecture, versioned implementation model, commissioning plan, operating campaign, incident diagnosis, trusted recovery and a final readiness map with official/vendor/physical gates.

**Packaged starter material**

- course_labs/ISA-EXPERT/README.md
- course_labs/ISA-EXPERT/capstone.py
- course_labs/ISA-EXPERT/starter.json
- course_labs/ISA-EXPERT/evidence_template.md

**Evidence to produce**

- Versioned requirement and dependency model
- Authored implementation or analytical artifact appropriate to the task
- Positive, negative, degraded and recovery evidence with provenance
- Decision record, limitations and remaining vendor/physical gates

**Acceptance criteria**

- Assemble a capability-based portfolio that distinguishes learning, original assessments, vendor practice, physical evidence and official credential requirements.
- Every claimed outcome is linked to the actual supplied or observed evidence and configuration.
- Required function and prohibited authority are assessed separately.
- Synthetic, analytical, vendor and field observations remain clearly distinguished.

The supplied tools are offline synthetic models. They perform no device access, official conformance assessment, physical safety verification or production operation.

#### Chapter practice

**ISA-EXPERT-Q0485 · single · design**

Which portfolio structure best supports an independent reviewer?

SYNTHETIC ASSESSMENT EVIDENCE: The programme aims for lifecycle engineering identity across network, controls, cybersecurity and digital integration.

1. Organize only by certificate logos and exam dates
2. Store every screenshot in one folder without context
3. Treat a high question count as evidence of physical commissioning
4. Organize evidence by capability and lifecycle claim, with links to requirements, versions, observations and external gates

**Correct option(s):** 4

- Option 1: That omits how practical capabilities were demonstrated.
- Option 2: The reviewer cannot reliably reconstruct scope or meaning.
- Option 3: Assessment volume does not establish field execution.
- Option 4: Certificates can map into this structure without becoming the sole proof.

**ISA-EXPERT-Q0486 · single · diagnosis**

What is the weakness in a capstone that contains only successful scenarios?

SYNTHETIC ASSESSMENT EVIDENCE: The learner demonstrates normal telemetry, approved login and healthy automatic operation, but no failures, denied actions or restoration.

1. The evidence covers normal function but not the stated resilience and authority claims
2. Successful normal scenarios have no value
3. Every possible fault must be physically injected into production
4. The missing cases can be marked passed from design intent

**Correct option(s):** 1

- Option 1: Full lifecycle capability needs relevant adverse and recovery conditions.
- Option 2: They are a necessary but incomplete part of acceptance.
- Option 3: Coverage should be risk-based, authorized and appropriately modeled.
- Option 4: Planned behaviour is not observed evidence.

**ISA-EXPERT-Q0487 · single · design**

Which learning progression reduces false confidence from memorized answers?

SYNTHETIC ASSESSMENT EVIDENCE: A learner scores highly on familiar questions but struggles to diagnose a new gateway trace.

1. Award practical competence automatically from the quiz average
2. Repeat the same questions until the score reaches 100%
3. Replace all theory with random command memorization
4. Add unfamiliar evidence-based cases, implementation tasks and explanation of discriminating tests

**Correct option(s):** 4

- Option 1: The observed performance contradicts that inference.
- Option 2: That may improve recall without resolving transfer.
- Option 3: Mechanistic understanding remains necessary.
- Option 4: Transfer requires applying mechanisms beyond recognizing repeated wording.

**ISA-EXPERT-Q0488 · single · diagnosis**

What should be said about this course's 500-question bank?

SYNTHETIC ASSESSMENT EVIDENCE: The bank is original instructional material with per-option reasoning. It has not undergone independent psychometric calibration or provider endorsement.

1. The bank has no educational value without provider endorsement
2. It is a reproduction of the official provider exam
3. It supports structured practice within its authored scope, without a guaranteed pass prediction or official exam equivalence
4. A score of 80% guarantees the credential

**Correct option(s):** 3

- Option 1: Original practice can be useful with honest scope and quality review.
- Option 2: The material is independently authored and must not make that claim.
- Option 3: Question count and explanations do not establish those external validations.
- Option 4: No such validated predictive relationship is established.

**ISA-EXPERT-Q0489 · single · design**

Which record best connects a certificate path to the user's charter?

SYNTHETIC ASSESSMENT EVIDENCE: The charter requires full lifecycle capability, while a certificate emphasizes one subset such as network implementation or OT maintenance.

1. Declare the charter complete when the first certificate is passed
2. Remove capabilities that lack a convenient certificate label
3. Assume certificates with similar titles teach identical depth
4. Map taught and assessed outcomes to charter capabilities, and retain practical/vendor/physical gaps explicitly

**Correct option(s):** 4

- Option 1: One subset does not cover every required lifecycle capability.
- Option 2: The professional objective is broader than credential organization.
- Option 3: Actual objectives and assessment modes differ.
- Option 4: Coverage should follow both credential scope and intended professional function.

**ISA-EXPERT-Q0490 · single · diagnosis**

What does an advanced label fail to prove?

SYNTHETIC ASSESSMENT EVIDENCE: A module is named advanced but contains only definitions and one normal-state example.

1. The label establishes advanced applied competence
2. Additional complex cases and implementation work could improve depth
3. The module should be assessed by its content rather than its title
4. The definitions can still support foundational learning

**Correct option(s):** 1

- Option 1: Depth depends on mechanisms, scenarios, decisions and demonstrated tasks.
- Option 2: Those address the actual gap.
- Option 3: That is the sound review principle.
- Option 4: They may be useful at the appropriate level.

**ISA-EXPERT-Q0491 · single · design**

Which capstone constraint prevents an attractive but impractical architecture?

SYNTHETIC ASSESSMENT EVIDENCE: A proposed design uses strong controls but requires unsupported firmware, unavailable licences and a recovery sequence longer than the required service objective.

1. Require supported compatibility, executable dependencies and measured or justified lifecycle feasibility alongside security properties
2. Assume all vendor constraints disappear in an emulator
3. Accept it because the diagram has more security layers
4. Remove the recovery objective from the report without owner review

**Correct option(s):** 1

- Option 1: An architecture must function and be sustainable under its real constraints.
- Option 2: Simulation does not alter production support or entitlements.
- Option 3: Layer count does not establish feasibility.
- Option 4: That changes the required outcome to fit the design.

**ISA-EXPERT-Q0492 · single · diagnosis**

What is wrong with this external-gate statement?

SYNTHETIC ASSESSMENT EVIDENCE: The app says vendor training and field practice are optional extras even though the learner has never used the required engineering tool or calibrated an instrument.

1. Every learner must repeat identical field work regardless of prior verified evidence
2. A simulated calibration proves traceable instrument handling
3. It understates unproven implementation and physical competence
4. Theory should be omitted until hardware is available

**Correct option(s):** 3

- Option 1: Existing applicable competence can be recognized through review.
- Option 2: Physical metrology involves additional procedures and evidence.
- Option 3: The programme must retain the relevant practical gates for its claimed identity.
- Option 4: Theory and simulation can progress while gates remain explicit.

**ISA-EXPERT-Q0493 · single · design**

Which review distinguishes breadth from redundant volume?

SYNTHETIC ASSESSMENT EVIDENCE: Two hundred questions ask whether a signed image is trustworthy, changing only product names and version numbers.

1. Count genuinely different mechanisms, evidence interpretations and engineering decisions, then replace superficial variants
2. Use longer explanations as the sole measure of breadth
3. Count every renamed item as a new competence objective
4. Delete all repeated exposure to important concepts

**Correct option(s):** 1

- Option 1: Volume should represent meaningful coverage.
- Option 2: Length does not determine whether decisions differ.
- Option 3: Renaming does not create new learning depth.
- Option 4: Spaced practice can repeat concepts, but should not inflate claimed distinct coverage.

**ISA-EXPERT-Q0494 · single · diagnosis**

What is the evidence gap in a claimed improvement of recovery readiness?

SYNTHETIC ASSESSMENT EVIDENCE: The team bought a backup appliance and updated a diagram but has not restored any required service or tested credential access.

1. The appliance can provide no benefit
2. The diagram's approval replaces restoration testing
3. Procurement and design intent do not demonstrate usable recovery capability
4. A larger storage capacity automatically establishes RTO

**Correct option(s):** 3

- Option 1: It may contribute once configured and validated.
- Option 2: Approval is not observed recovery behaviour.
- Option 3: The complete path needs execution evidence or clearly bounded analysis.
- Option 4: Capacity does not determine the full restoration sequence.

**ISA-EXPERT-Q0495 · single · design**

Which independent review question most directly tests a security claim?

SYNTHETIC ASSESSMENT EVIDENCE: The author says a collector is read-only across the lifecycle.

1. Are all configured source addresses listed, without examining application permissions?
2. Is the observer role labeled read-only in the user interface?
3. Where is the restriction enforced, what alternate paths exist, and what evidence proves it after failover and restoration?
4. Does the vendor support the required protocol and does one normal poll succeed?

**Correct option(s):** 3

- Option 1: Address inventory alone does not establish which operations an allowed source can perform.
- Option 2: The label does not establish effective API or controller authorization.
- Option 3: The questions trace the claim to mechanism, scope and lifecycle behaviour.
- Option 4: Capability and one permitted transaction do not prove denied authority across lifecycle states.

**ISA-EXPERT-Q0496 · single · diagnosis**

Which distinction matters when the learner achieves the provider's Expert milestone?

SYNTHETIC ASSESSMENT EVIDENCE: All four official specialist certificates have been earned. The learner still lacks site-specific switching authorization and some vendor tool practice.

1. The learner can now perform any live electrical operation anywhere
2. The four certificates provide no evidence because gaps remain
3. The provider milestone recognizes its certificate requirements; additional site and practical gates remain separate
4. The milestone is invalid unless the app creates a fifth exam

**Correct option(s):** 3

- Option 1: Site authority and discipline competence remain bounded.
- Option 2: They are meaningful within their assessed scope.
- Option 3: The credential does not grant every operational authority.
- Option 4: The provider awards Expert automatically after the four certificates.

**ISA-EXPERT-Q0497 · single · design**

How should an evolving programme preserve source accuracy?

SYNTHETIC ASSESSMENT EVIDENCE: Provider objectives, supported software and public guidance may change after the app's checked date.

1. Record source versions/dates, review material changes and update mappings and affected instruction without inventing private blueprints
2. Remove every source link so changes cannot be noticed
3. Claim the current course will remain perfectly aligned forever
4. Copy paid training or actual exam items to avoid authoring work

**Correct option(s):** 1

- Option 1: The programme needs a controlled content lifecycle.
- Option 2: That reduces traceability and reviewability.
- Option 3: External requirements can change.
- Option 4: That is not an appropriate original-content method.

**ISA-EXPERT-Q0498 · single · diagnosis**

What should a final readiness report avoid?

SYNTHETIC ASSESSMENT EVIDENCE: The learner has strong theory, several safe labs and some vendor practice, but no verified production recovery or physical commissioning evidence.

1. A distinction between knowledge, simulated implementation and field evidence
2. Recognition of the substantial completed learning
3. A plan linking remaining field tasks to explicit acceptance criteria
4. A universal claim that the entire intended identity is already proven

**Correct option(s):** 4

- Option 1: The distinction prevents overstatement.
- Option 2: That can be stated accurately.
- Option 3: That makes the next stage concrete.
- Option 4: Readiness should identify demonstrated capability and remaining specific gates.

**ISA-EXPERT-Q0499 · single · design**

Which final integrated assessment is most discriminating?

SYNTHETIC ASSESSMENT EVIDENCE: The learner receives an unfamiliar system diagram, point table, flow rules, identity records, update history and incident trace containing several conflicting clues.

1. Require a justified diagnosis, risk/requirement update, scoped correction, acceptance plan and trusted recovery with explicit uncertainty
2. Score only the number of pages submitted
3. Ask only for the names of the four specialist courses
4. Provide the correct root cause in the question title

**Correct option(s):** 1

- Option 1: The task joins the lifecycle decisions rather than rewarding one memorized label.
- Option 2: Volume does not establish the correctness or sufficiency of reasoning.
- Option 3: That tests recall of programme structure, not engineering integration.
- Option 4: That removes the diagnostic challenge.

**ISA-EXPERT-Q0500 · single · diagnosis**

Which completion statement is accurate for this integrated study programme?

SYNTHETIC ASSESSMENT EVIDENCE: The app contains original teaching, practice, question banks and portfolio tasks mapped to the intended capability areas. Official exams, licensed normative review and required real-world competence checks remain external.

1. External gates mean the authored programme cannot teach anything substantial
2. The app guarantees all certificates after its final quiz
3. The ISA-EXPERT integration bank is an additional official qualification
4. The app provides a structured preparation and evidence-building programme; completion alone does not guarantee every credential or authorize site operations

**Correct option(s):** 4

- Option 1: Teaching and practice remain valuable even when some assessments require other environments.
- Option 2: No application score establishes that outcome.
- Option 3: It is an authored review, while the provider milestone follows the four specialist certificates.
- Option 4: The claim recognizes substantial scope while preserving external requirements.

#### Recall

**A portfolio contains 200 questions that differ only in product name while asking the same signed-image trust decision. How should breadth be assessed?**

Count the underlying mechanisms and decisions, not renamed stems. Repetition can support memory, but it should not inflate distinct coverage. Add genuinely different evidence interpretation, implementation, failure, constraint and recovery decisions, with plausible alternatives and specific explanations.

**In this case, what is the justified integrated decision? A learner has passed the app banks, built a read-only diagnostic prototype, completed simulated controller recovery and produced a detailed architecture. No actual vendor engineering download, calibrated field measurement or production recovery has been verified.**

The learner has meaningful knowledge, design and simulated implementation evidence. The readiness report should state those achievements and map the unverified vendor, physical and operational gates to concrete tasks and acceptance criteria. It should not claim universal field authority or an automatic provider credential from app completion.

#### References

- [NIST SP 800-82 Rev. 3 final: OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [ISA certificate programme: four specialist certificates and automatic Expert milestone](https://www.isa.org/certification/certificate-programs/isa-iec-62443-cybersecurity-certificate-program)
- [ISA public standards-series scope and principal roles](https://www.isa.org/standards-and-publications/isa-standards/isa-iec-62443-series-of-standards)
