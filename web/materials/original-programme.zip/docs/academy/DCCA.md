# DCCA — DCCA — Critical physical infrastructure foundations

Original independent instruction and practice. Read the teaching, work the demonstrations and guided exercise, then attempt questions before reading their explanations. Independent tasks require your own evidence.

Source baseline: [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/) · Public scope checked 2026-09-19; author-defined chapter identifiers · checked 2026-09-19

Original instruction mapped to public subject areas. Public information is not an item-level examination specification; no claim of provider endorsement or actual examination replication.

## Scope and external requirements

- Detailed examination weighting and proprietary learning materials are not publicly verified.

- National requirements and equipment-specific limits must be supplied for actual installation.

- This author-reviewed bank has not been psychometrically calibrated or independently certified as equivalent to the provider examination.

- Complete the current provider learning and examination requirements; this independently authored course does not award a credential.

- Electrical switching, fire-system intervention and mechanical installation require approved site procedures, appropriate competence and authorization.

- D1 building content is interface and examination literacy only. Power and cooling are integrated facility dependencies in the near-term programme; complete specialist engineering is a later development horizon.

## Preparation

Prior courses: See the knowledge prerequisites below.

- Basic arithmetic, unit conversion and proportional reasoning.

## DCCA-M01 — Service requirements, dependencies and availability

### DCCA-L01 — Service requirements, dependencies and availability

Estimated study time: 55 minutes before independent work. Prerequisite chapters: Use the course prerequisites.

A data center delivers an IT service through a chain of supporting functions. Begin with the service: who uses it, what performance they need, which interruptions matter, how much data loss is tolerable, and how quickly capacity must grow. A device being powered does not establish that the application is usable. Conversely, an application may remain available during a component failure because another component carries the work.

Map dependencies from the application downward: compute and storage, network paths and name services, rack power, upstream distribution, heat removal, controls, utilities and people. Draw a separate line for each required function and mark AND dependencies (all needed) and OR alternatives (at least one sufficient). A second pump supplies redundancy only if its electrical supply, suction, discharge path and control authority remain available when the first path fails. This functional map reveals common-cause failures that a count of devices hides.

Availability is an observed proportion over a stated service and interval: available time divided by scheduled service time. A commonly used repairable-system approximation is MTBF/(MTBF+MTTR), under restrictive steady-state assumptions. Neither expression guarantees future reliability. Report excluded maintenance, partial degradation and measurement location explicitly. Reliability concerns successful operation over a mission; maintainability concerns restoration; resilience also concerns adaptation and recovery under disruption.

A service-level objective is a target. A service-level indicator is what you measure. An agreement adds agreed responsibilities and consequences. Translate a business statement into testable conditions: after loss of either rack feed, the named service must remain responsive at the specified load, with response time below its limit. Define permitted degraded modes, owner, escalation and recovery evidence before testing.

Capacity is multidimensional: free rack units cannot compensate for exhausted cooling or a full network port allocation. A responsible capacity statement identifies the limiting constraint in the required failure state. Commissioning compares implementation with design intent; operations continually checks that effective state still matches that intent after maintenance, growth and incidents.

### Work through a dependency failure
Consider a historian that needs a virtual machine, a database volume, DNS and a controls-network path. Two switches are installed, but the DNS resolver is hosted on the same storage volume as the historian. Draw the historian and resolver as separate functions, then connect both to the volume. Losing that volume now removes two functions through one cause. Adding a third switch cannot correct this dependency.

Test design follows the graph. First establish a baseline query at a specified sample rate. Next make the selected dependency unavailable through an approved isolated test. Observe whether queries continue, whether stale values are distinguished from fresh ones, and whether alarms reach the operator. Finally restore the dependency and check that queued records reconcile without unexplained gaps or duplicates. The pass criterion is a useful historian function, not merely successful VM startup.

For a series chain of independent components, a simple analytical availability model multiplies their availabilities. Two required components each at 0.99 produce 0.9801, not 0.99. Independence is a strong assumption: common power, software or maintenance can make the model optimistic. Use this equation to understand the chain, not to promise a production uptime figure.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A month has 43,200 scheduled minutes. An application is unusable for 18 minutes; a redundant switch is failed for 240 minutes with no service impact.

**Reasoning:** Service availability is (43,200−18)/43,200 = 99.9583%. The switch repair interval is an equipment observation, not an additional 240 minutes of application downtime. Both belong in the operating record because the failed switch reduced resilience.

#### Guided practice

Map an application that requires one storage cluster, either of two network paths and either rack feed. Both network paths share one DNS service. Identify the hidden dependency.

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** DNS is an AND dependency common to both network alternatives. Test its failure or prove an independent resolution path; counting two switches does not address it.

#### Independent task

Environment: analytical

Create a dependency map for a synthetic controls historian service and define a measured availability boundary.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Include power, cooling, network, storage, identity and time dependencies.
- Identify at least two common dependencies.
- Provide a measurable service test and honest downtime denominator.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0001 · single · mechanism**

A historian responds to ping but rejects every query. Which availability boundary is most useful?

1. Rack occupancy
2. Server LEDs
3. Successful historian transactions
4. ICMP replies

**Correct option(s):** 3

- Option 1: Incorrect. Occupied space is unrelated to transaction success.
- Option 2: Incorrect. Power indicators do not establish service delivery.
- Option 3: Correct. Users require the application function.
- Option 4: Incorrect. Transport response does not establish query success.

**DCCA-Q0002 · single · mechanism**

Two pumps share a closed isolation valve. What defeats the apparent redundancy?

1. Excess pump count
2. Different serial numbers
3. Separate labels
4. Common hydraulic dependency

**Correct option(s):** 4

- Option 1: Incorrect. The count alone is not the failure.
- Option 2: Incorrect. Unique identities do not create independent flow.
- Option 3: Incorrect. Labels do not change the shared valve.
- Option 4: Correct. Both flow paths depend on the valve.

**DCCA-Q0003 · single · diagnosis**

A 24-hour service is unavailable for 12 minutes. What is its observed daily availability?

Synthetic educational evidence; not field measurements.

Scheduled service: 1440 minutes
Unavailable service: 12 minutes
No exclusions apply.

1. 98%
2. 99.9917%
3. 99.1667%
4. 100%

**Correct option(s):** 3

- Option 1: Incorrect. Twelve minutes is not two percent of a day.
- Option 2: Incorrect. This confuses minutes with a much longer denominator.
- Option 3: Correct. Availability is 1428 divided by 1440.
- Option 4: Incorrect. The measured interruption must be counted.

**DCCA-Q0004 · single · mechanism**

What does an availability target describe?

1. Guaranteed future uptime
2. Mean repair labor cost
3. Required performance over a defined interval
4. Number of installed UPS units

**Correct option(s):** 3

- Option 1: Incorrect. A target cannot guarantee future operation.
- Option 2: Incorrect. Cost is a different metric.
- Option 3: Correct. It is an objective rather than an observation.
- Option 4: Incorrect. Equipment count is not an availability target.

**DCCA-Q0005 · single · mechanism**

Which statement distinguishes reliability from maintainability?

1. Reliability concerns successful operation; maintainability concerns restoration
2. Reliability measures only repair speed
3. Maintainability eliminates all faults
4. Both mean installed spare count

**Correct option(s):** 1

- Option 1: Correct. These address different phases of a failure.
- Option 2: Incorrect. Repair speed belongs to maintainability.
- Option 3: Incorrect. It improves restoration rather than eliminating every fault.
- Option 4: Incorrect. Spare count alone measures neither property.

**DCCA-Q0006 · single · mechanism**

One network component fails with no application interruption. What should the operating record show?

1. Full application downtime until repair
2. Reduced redundancy without service downtime
3. No event because users were unaffected
4. A higher service availability denominator

**Correct option(s):** 2

- Option 1: Incorrect. That would misstate measured service.
- Option 2: Correct. The event affects resilience even though service continues.
- Option 3: Incorrect. Loss of a protective margin still matters.
- Option 4: Incorrect. The scheduled service interval is unchanged.

**DCCA-Q0007 · single · mechanism**

A rack has free U-space but no spare branch capacity. Which resource limits installation?

1. Number of blanking panels
2. Server purchase budget alone
3. Rack height alone
4. Electrical capacity

**Correct option(s):** 4

- Option 1: Incorrect. Panels do not increase circuit capacity.
- Option 2: Incorrect. A funded server can still exceed facility limits.
- Option 3: Incorrect. Space does not create electrical headroom.
- Option 4: Correct. All simultaneous constraints must be satisfied.

**DCCA-Q0008 · single · mechanism**

What makes a failover acceptance requirement testable?

1. A photograph of both feeds
2. The phrase highly available
3. Named failure, load and measurable service limit
4. A vendor reputation statement

**Correct option(s):** 3

- Option 1: Incorrect. A photograph does not exercise failover.
- Option 2: Incorrect. It lacks a measurable condition.
- Option 3: Correct. These specify stimulus and observable pass criteria.
- Option 4: Incorrect. Reputation is not acceptance evidence.

**DCCA-Q0009 · single · mechanism**

Which is a service-level indicator?

1. Future upgrade proposal
2. Desired monthly target
3. Signed penalty clause
4. Measured successful transaction percentage

**Correct option(s):** 4

- Option 1: Incorrect. That is a plan.
- Option 2: Incorrect. That is an objective.
- Option 3: Incorrect. That is an agreement term.
- Option 4: Correct. It is an observed service quantity.

**DCCA-Q0010 · single · mechanism**

Why identify AND dependencies in a service map?

1. Any required element can interrupt the function
2. They prove fault tolerance
3. They eliminate maintenance needs
4. They are optional alternatives

**Correct option(s):** 1

- Option 1: Correct. AND means all listed inputs are necessary.
- Option 2: Incorrect. A required single input can be a single point of failure.
- Option 3: Incorrect. Dependency logic does not eliminate wear.
- Option 4: Incorrect. Alternatives are represented differently.

**DCCA-Q0011 · single · mechanism**

What is the main purpose of commissioning?

1. Prove no future failure can occur
2. Replace all operating procedures
3. Award an availability rating automatically
4. Demonstrate implementation against requirements

**Correct option(s):** 4

- Option 1: Incorrect. Finite tests cannot establish that claim.
- Option 2: Incorrect. Operations still needs controlled procedures.
- Option 3: Incorrect. Certification has separate rules.
- Option 4: Correct. Commissioning connects design intent to tested behavior.

**DCCA-Q0012 · single · mechanism**

A monitoring interval excludes planned downtime. What must accompany its availability figure?

1. A claim of continuous operation
2. The exclusion and denominator
3. Only the rounded percentage
4. The server model only

**Correct option(s):** 2

- Option 1: Incorrect. That conflicts with excluded downtime.
- Option 2: Correct. Readers need the actual measurement boundary.
- Option 3: Incorrect. Rounding hides the exclusion.
- Option 4: Incorrect. Model information does not explain the calculation.

**DCCA-Q0013 · single · mechanism**

What distinguishes a service agreement from a measurement?

1. More decimal places
2. A longer cable
3. A monthly uptime observation without agreed obligations
4. Agreed responsibilities and terms

**Correct option(s):** 4

- Option 1: Incorrect. Precision does not create an agreement.
- Option 2: Incorrect. Physical length is unrelated.
- Option 3: Incorrect. A measurement describes observed performance but does not establish an agreement.
- Option 4: Correct. An agreement defines obligations, not just observations.

**DCCA-Q0014 · single · mechanism**

Why test a degraded operating state?

1. It replaces normal-state testing
2. Requirements must hold when specified components are unavailable
3. It guarantees all possible failures
4. It eliminates shared dependencies

**Correct option(s):** 2

- Option 1: Incorrect. Both states need evaluation.
- Option 2: Correct. Normal-state capacity can conceal failure-state limits.
- Option 3: Incorrect. A test covers defined conditions only.
- Option 4: Incorrect. Dependencies must be engineered separately.

**DCCA-Q0015 · single · diagnosis**

The same switch powers both monitoring paths through PoE. What is the hidden risk?

Synthetic educational evidence; not field measurements.

Monitor A power: PoE switch S1
Monitor B power: PoE switch S1
Separate network VLANs are configured.

1. One switch power failure removes both observations
2. Monitoring always requires fiber
3. Two IP addresses are inherently unsafe
4. Different monitoring VLANs make the power supplies independent

**Correct option(s):** 1

- Option 1: Correct. Shared supply creates a common cause.
- Option 2: Incorrect. The medium does not remove a shared supply.
- Option 3: Incorrect. Address count is not the described cause.
- Option 4: Incorrect. Logical traffic separation does not remove the common PoE source.

**DCCA-Q0016 · single · mechanism**

Which evidence supports a recoverability claim?

1. A published MTBF number
2. A backup job marked complete
3. Timed restoration with functional validation
4. Purchase of a spare disk

**Correct option(s):** 3

- Option 1: Incorrect. Component reliability does not prove service recovery.
- Option 2: Incorrect. That does not prove usable restoration.
- Option 3: Correct. Recovery must restore required service, not just start hardware.
- Option 4: Incorrect. A spare is an input, not a recovery demonstration.

**DCCA-Q0017 · single · mechanism**

What is the most defensible capacity statement?

1. Number of empty cabinets
2. Floor area multiplied by a sales estimate
3. Total nameplate power of all units
4. Supported load under named normal and failure constraints

**Correct option(s):** 4

- Option 1: Incorrect. Empty cabinets do not prove usable capacity.
- Option 2: Incorrect. That omits actual limiting resources.
- Option 3: Incorrect. Installed power may include redundancy or shared bottlenecks.
- Option 4: Correct. Capacity must include the states the service promises.

**DCCA-Q0018 · single · mechanism**

Who should accept residual operational risk?

1. Whoever dismisses the alarm first
2. The newest contractor automatically
3. The designated accountable owner
4. The monitoring software

**Correct option(s):** 3

- Option 1: Incorrect. Acknowledgment is not risk acceptance.
- Option 2: Incorrect. Proximity to work does not establish authority.
- Option 3: Correct. Acceptance requires authority over the affected service and consequences.
- Option 4: Incorrect. Software reports state but does not own business risk.

**DCCA-Q0019 · single · mechanism**

Why distinguish implementation from demonstrated capability?

1. An installed feature may not behave correctly under load or failure
2. A configuration file guarantees behavior
3. Commissioning removes the need for maintenance
4. Installation is always harder than operation

**Correct option(s):** 1

- Option 1: Correct. Verification requires observed function.
- Option 2: Incorrect. Dependencies and effective state can differ.
- Option 3: Incorrect. Capability must be sustained.
- Option 4: Incorrect. Difficulty does not establish evidence.

**DCCA-Q0020 · single · mechanism**

Which document best connects a requirement to evidence?

1. A traceability record linking requirement, test and result
2. An unlabelled screenshot
3. A requirements list with no linked test results
4. A list of equipment prices

**Correct option(s):** 1

- Option 1: Correct. It makes acceptance auditable.
- Option 2: Incorrect. Without context it cannot show which requirement passed.
- Option 3: Incorrect. The requirements are identified, but compliance evidence remains unconnected.
- Option 4: Incorrect. Prices do not demonstrate behavior.

#### Recall

**A historian responds to ping but rejects every query. Which availability boundary is most useful?**

Successful historian transactions Correct. Users require the application function.

**Two pumps share a closed isolation valve. What defeats the apparent redundancy?**

Common hydraulic dependency Correct. Both flow paths depend on the valve.

**A 24-hour service is unavailable for 12 minutes. What is its observed daily availability?**

99.1667% Correct. Availability is 1428 divided by 1440.

**What does an availability target describe?**

Required performance over a defined interval Correct. It is an objective rather than an observation.

**Which statement distinguishes reliability from maintainability?**

Reliability concerns successful operation; maintainability concerns restoration Correct. These address different phases of a failure.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DCCA-M02 — Electrical quantities, phase and power factor

### DCCA-L02 — Electrical quantities, phase and power factor

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L01

Electrical design starts by distinguishing energy from its rate of transfer. Real power P, measured in watts, performs useful work or becomes heat. Energy is the integral of power over time; a steady 12 kW load operating for five hours consumes 60 kWh. Apparent power S, measured in VA, describes the RMS voltage-current product that equipment and conductors must carry. Power factor is P/S; therefore both a kW limit and a kVA/current limit can constrain a UPS.

For single-phase AC, S = V_rms I_rms and P = V_rms I_rms PF. For a balanced three-phase system, S = sqrt(3) V_LL I_line and P = sqrt(3) V_LL I_line PF. These formulas require consistent units and the stated balance assumptions. Line-to-line voltage is not interchangeable with line-to-neutral voltage. Real loads can be unbalanced and nonlinear; measure phases individually and use appropriate true-RMS instruments.

A power supply nameplate describes a rating, not necessarily its present consumption. Two 1 kW supplies in a redundant server do not imply a continuous 2 kW load. Equally, a 500 W observation at idle does not justify a 500 W facility allocation under a later AI workload. Establish an envelope including normal workload, peak, startup, failover and growth.

Reactive power exchanges stored electromagnetic energy with the source. Nonlinear loads also distort current. Displacement power factor alone can miss distortion; true power factor reflects the complete RMS relationship. Resistive loss is I²R, so doubling current through unchanged resistance quadruples that component of heating. Long conductors, connections, ambient conditions and grouping affect voltage drop and thermal suitability.

At a foundation level, calculate load and identify missing data rather than selecting protective devices from a universal rule. Applicable electrical code, installation method, equipment instructions, prospective fault current and coordination require qualified design. Operationally, trend kW, kVA, currents, voltage, frequency and imbalance together so that a favorable single metric cannot conceal another limit.

### Derive the units before selecting equipment
Suppose six servers each consume 700 W under the required workload. Their total real demand is 4.2 kW. On a 230 V single-phase source at PF 0.95, current is 4200/(230×0.95)=19.22 A. At PF 0.70, the same real demand requires 26.09 A. The computing heat load remains approximately 4.2 kW, while the distribution current and resistive losses increase.

Now separate demand from rating. A 32 A connector does not prove the upstream branch supports this installation, and a 20 A observed current does not establish the peak during startup or feed loss. Record the measurement interval and workload, compare with supported peak behavior, and identify all path limits. If one limit is unknown, report an unresolved constraint rather than rounding the load down.

For energy accounting, integrate changing power. Two hours at 4 kW followed by three hours at 6 kW consume 2×4+3×6=26 kWh. The arithmetic mean of the two power values, 5 kW, multiplied by five hours would incorrectly give 25 kWh because the intervals are unequal. This is why logged energy or time-weighted integration matters.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A balanced 400 V three-phase load draws 100 A at true PF 0.90. A UPS is rated 80 kVA and 72 kW.

**Reasoning:** S = 1.732×400×100/1000 = 69.28 kVA. P = 69.28×0.90 = 62.35 kW. Both steady-state ratings are satisfied, before environmental derating or reserve requirements.

#### Guided practice

A 60 kW load operates at PF 0.75. Can a 75 kVA/75 kW UPS supply it within both nameplate limits?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** It requires 80 kVA, so the apparent-power limit is exceeded despite sufficient kW.

#### Independent task

Environment: analytical

Build a load schedule separating measured, rated, projected peak and failover currents.

**Packaged starter material**

- course_labs/DCCA/README.md
- course_labs/DCCA/scenario.json
- course_labs/DCCA/answers-template.json

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Show units and formula assumptions.
- Check both real and apparent power.
- Flag uncertainty rather than inventing a universal circuit derating rule.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0021 · single · calculation**

A steady 8 kW load runs for 6 hours. How much energy is used?

Synthetic educational evidence; not field measurements.

Constant load: 8 kW
Operating duration: 6 h

1. 48 kWh
2. 1.33 kWh
3. 48 kW
4. 14 kWh

**Correct option(s):** 1

- Option 1: Correct. Energy equals power multiplied by time.
- Option 2: Incorrect. Dividing reverses the relationship.
- Option 3: Incorrect. This is a power unit rather than energy.
- Option 4: Incorrect. Adding power and time is dimensionally invalid.

**DCCA-Q0022 · single · calculation**

A 50 kW load has PF 0.8. What apparent power is required?

Synthetic educational evidence; not field measurements.

Real demand: 50 kW
True power factor: 0.80

1. 62.5 kVA
2. 80 kVA
3. 50 kVA
4. 40 kVA

**Correct option(s):** 1

- Option 1: Correct. S equals P divided by PF.
- Option 2: Incorrect. The value does not follow from P divided by PF.
- Option 3: Incorrect. This assumes unity power factor.
- Option 4: Incorrect. Multiplication gives the wrong relationship.

**DCCA-Q0023 · single · mechanism**

Which quantity is measured in amperes?

1. Frequency
2. Energy
3. Electric current
4. Apparent power

**Correct option(s):** 3

- Option 1: Incorrect. Frequency is measured in hertz.
- Option 2: Incorrect. Energy is measured in joules or watt-hours.
- Option 3: Correct. Amperes measure charge flow rate.
- Option 4: Incorrect. Apparent power is measured in VA.

**DCCA-Q0024 · single · mechanism**

For balanced three-phase power using line-to-line voltage, which factor appears?

1. Square root of three
2. Three squared
3. Two pi
4. One-half

**Correct option(s):** 1

- Option 1: Correct. The phase relationship gives this factor.
- Option 2: Incorrect. This overstates total power.
- Option 3: Incorrect. That factor is not the balanced power conversion.
- Option 4: Incorrect. This is not the three-phase relationship.

**DCCA-Q0025 · single · diagnosis**

A 230 V single-phase load draws 10 A at PF 1. What is its real power?

Synthetic educational evidence; not field measurements.

Single-phase source: 230 V RMS
Current: 10 A RMS
True power factor: 1.00

1. 0.23 kW
2. 2.3 kWh
3. 23 kW
4. 2.3 kW

**Correct option(s):** 4

- Option 1: Incorrect. This loses a factor of ten.
- Option 2: Incorrect. Energy needs a duration.
- Option 3: Incorrect. This introduces a tenfold unit error.
- Option 4: Correct. 230 times 10 equals 2300 W.

**DCCA-Q0026 · single · calculation**

A UPS supports 100 kVA but only 90 kW. Which load violates a rating?

Synthetic educational evidence; not field measurements.

UPS rating: 100 kVA / 90 kW
Evaluate each proposed load against both limits.

1. 60 kW at PF 0.8
2. 95 kW at unity PF
3. 80 kW at unity PF
4. 72 kW at PF 0.9

**Correct option(s):** 2

- Option 1: Incorrect. This is 75 kVA and below both ratings.
- Option 2: Correct. Real power exceeds 90 kW.
- Option 3: Incorrect. Both ratings are satisfied.
- Option 4: Incorrect. This is 80 kVA and below both ratings.

**DCCA-Q0027 · single · calculation**

Two redundant 1 kW server supplies are installed. What can be concluded about actual draw?

1. It must be measured or modeled for the workload
2. It is always exactly 1 kW
3. It is always exactly 2 kW
4. It is zero until a supply fails

**Correct option(s):** 1

- Option 1: Correct. Supply rating alone does not establish consumption.
- Option 2: Incorrect. The workload can draw less or approach another envelope.
- Option 3: Incorrect. Redundant supplies do not necessarily draw their full ratings.
- Option 4: Incorrect. Both supplies may operate during normal service.

**DCCA-Q0028 · single · mechanism**

Why does low power factor matter for distribution capacity?

1. It removes real heat from the IT load
2. It changes frequency automatically
3. It lowers energy to zero
4. More current is needed for the same real power

**Correct option(s):** 4

- Option 1: Incorrect. Real consumed power still becomes work and heat.
- Option 2: Incorrect. Frequency is not set by this ratio.
- Option 3: Incorrect. A nonzero real load still consumes energy.
- Option 4: Correct. The conductors carry the larger apparent-power demand.

**DCCA-Q0029 · single · mechanism**

Current doubles through unchanged resistance. What happens to resistive heating?

1. It halves
2. It becomes four times larger
3. It is unchanged
4. It doubles

**Correct option(s):** 2

- Option 1: Incorrect. Higher current increases heating.
- Option 2: Correct. I squared R gives a factor of four.
- Option 3: Incorrect. Resistance alone does not determine loss.
- Option 4: Incorrect. The current is squared.

**DCCA-Q0030 · single · mechanism**

Which measurement best detects phase imbalance?

1. Rack height
2. Individual phase currents under representative load
3. Total monthly energy alone
4. Battery age

**Correct option(s):** 2

- Option 1: Incorrect. Mechanical height does not measure current.
- Option 2: Correct. An aggregate can hide unequal loading.
- Option 3: Incorrect. Energy total does not expose phase allocation.
- Option 4: Incorrect. Battery age is unrelated to phase distribution.

**DCCA-Q0031 · single · calculation**

A constant 2 MW load runs for 30 minutes. What energy is consumed?

Synthetic educational evidence; not field measurements.

Constant load: 2 MW
Duration: 30 min

1. 4 MWh
2. 60 MWh
3. 1 MW
4. 1 MWh

**Correct option(s):** 4

- Option 1: Incorrect. Dividing by half an hour is incorrect.
- Option 2: Incorrect. Minutes must first be converted to hours.
- Option 3: Incorrect. This is not an energy unit.
- Option 4: Correct. Half an hour at 2 MW is 1 MWh.

**DCCA-Q0032 · single · mechanism**

What is true power factor?

1. Real power divided by apparent power
2. Frequency divided by voltage
3. Voltage divided by current
4. Energy divided by floor area

**Correct option(s):** 1

- Option 1: Correct. This includes the complete RMS relationship.
- Option 2: Incorrect. That is not a power factor.
- Option 3: Incorrect. That ratio has impedance units.
- Option 4: Incorrect. That is a different intensity metric.

**DCCA-Q0033 · single · mechanism**

Why can an idle measurement underestimate facility demand?

1. Current is independent of computation
2. Nameplate values never matter
3. A meter measures only apparent power
4. Workload and failover can increase draw

**Correct option(s):** 4

- Option 1: Incorrect. Computing activity can change power.
- Option 2: Incorrect. Ratings still constrain supported operation.
- Option 3: Incorrect. Meters can measure several quantities.
- Option 4: Correct. Capacity must account for the required operating envelope.

**DCCA-Q0034 · single · mechanism**

Which is a valid single-phase apparent-power calculation?

1. Real power multiplied by power factor
2. Voltage divided by time
3. Current squared divided by voltage
4. RMS voltage multiplied by RMS current

**Correct option(s):** 4

- Option 1: Incorrect. Apparent power is real power divided by PF.
- Option 2: Incorrect. The dimensions are wrong.
- Option 3: Incorrect. That is not apparent power.
- Option 4: Correct. This defines apparent power.

**DCCA-Q0035 · single · mechanism**

What must be stated before using the simple balanced three-phase formula?

1. Every server has one supply
2. All loads are DC
3. Energy price is constant
4. The load is adequately balanced and voltage is line-to-line

**Correct option(s):** 4

- Option 1: Incorrect. Server supply count is not the mathematical assumption.
- Option 2: Incorrect. The formula is for three-phase AC.
- Option 3: Incorrect. Price does not affect electrical power.
- Option 4: Correct. These are the formula assumptions.

**DCCA-Q0036 · single · mechanism**

Which quantity describes cycles per second?

1. Resistance
2. Frequency
3. Energy
4. Power factor

**Correct option(s):** 2

- Option 1: Incorrect. Resistance opposes current.
- Option 2: Correct. Hertz measures periodic cycles per second.
- Option 3: Incorrect. Energy accumulates transferred work.
- Option 4: Incorrect. Power factor is a dimensionless ratio.

**DCCA-Q0037 · single · calculation**

A 10 kWh battery claim is compared with a 10 kW load. What is still missing for runtime?

1. Number of Ethernet ports
2. Usable energy, conversion losses and discharge limits
3. Only the nominal inverter kVA
4. Monthly rent

**Correct option(s):** 2

- Option 1: Incorrect. Port count does not establish the electrical discharge curve.
- Option 2: Correct. Nominal energy alone does not establish delivered runtime.
- Option 3: Incorrect. Power rating alone does not establish usable stored energy or discharge duration.
- Option 4: Incorrect. Rent does not affect electrical runtime.

**DCCA-Q0038 · single · mechanism**

Why is displacement power factor insufficient for some IT loads?

1. Displacement power factor measures cable length
2. IT equipment cannot draw AC
3. Harmonics are measured only in kWh
4. Current distortion also affects true power factor

**Correct option(s):** 4

- Option 1: Incorrect. It describes phase relation.
- Option 2: Incorrect. Most facility-fed IT supplies accept AC.
- Option 3: Incorrect. Harmonics are waveform components.
- Option 4: Correct. Phase shift alone omits harmonic distortion.

**DCCA-Q0039 · single · calculation**

A branch remains below its aggregate kW allocation but one phase exceeds its current limit. What is appropriate?

Synthetic educational evidence; not field measurements.

Aggregate rack kW: below allocation
Phase L2 current: above its applicable limit

1. Treat the phase limit as a real constraint
2. Ignore the phase measurement
3. Increase voltage without review
4. Approve because total kW is low

**Correct option(s):** 1

- Option 1: Correct. Aggregate power does not override individual limits.
- Option 2: Incorrect. It addresses a relevant constraint.
- Option 3: Incorrect. Voltage changes require design and equipment compatibility.
- Option 4: Incorrect. A phase conductor can still be overloaded.

**DCCA-Q0040 · single · mechanism**

What distinguishes a design load schedule from a nameplate list?

1. It documents operating states, diversity assumptions and constraints
2. It reports only purchase prices
3. It guarantees future workloads
4. It excludes all ratings

**Correct option(s):** 1

- Option 1: Correct. Engineering needs the expected demand envelope.
- Option 2: Incorrect. Cost does not establish load.
- Option 3: Incorrect. A schedule relies on stated assumptions.
- Option 4: Incorrect. Ratings remain necessary limits.

#### Recall

**A steady 8 kW load runs for 6 hours. How much energy is used?**

48 kWh Correct. Energy equals power multiplied by time.

**A 50 kW load has PF 0.8. What apparent power is required?**

62.5 kVA Correct. S equals P divided by PF.

**Which quantity is measured in amperes?**

Electric current Correct. Amperes measure charge flow rate.

**For balanced three-phase power using line-to-line voltage, which factor appears?**

Square root of three Correct. The phase relationship gives this factor.

**A 230 V single-phase load draws 10 A at PF 1. What is its real power?**

2.3 kW Correct. 230 times 10 equals 2300 W.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DCCA-M03 — The power chain: utility, transformer and distribution

### DCCA-L03 — The power chain: utility, transformer and distribution

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L02

Trace power from the utility service to the IT inlet. A typical chain includes incoming switchgear, transformers, distribution boards, UPS equipment, downstream distribution and rack PDUs. Actual order and voltage levels vary. A single-line diagram compresses three-phase equipment into a functional representation: sources, switching devices, buses, transformers, protective devices and loads. Read its legend and normal switch states before interpreting connectivity.

A transformer changes voltage through electromagnetic coupling. It does not generate energy; output power is input power minus losses. Isolation depends on winding arrangement and the actual grounding design. A distribution board divides a source into protected branches. A rack PDU is a distribution assembly; some versions also meter or switch outlets, but it does not automatically provide battery ride-through or voltage conversion.

Protection must clear faults while limiting harm. The interrupting rating describes a device's ability to interrupt a specified fault current. The continuous-current rating addresses normal loading. Selectivity or coordination aims to disconnect the nearest suitable protective device so that a local fault does not unnecessarily interrupt healthy branches. A larger upstream breaker is not proof of coordination: time-current behavior, available fault current and equipment combinations matter.

Protective bonding connects exposed conductive parts into the protective scheme. The neutral is a current-carrying conductor in relevant systems; it is not a substitute for a protective conductor. Grounding and bonding are engineered arrangements with safety and power-quality consequences. Never interpret this learning material as an electrical switching or live-work authorization.

Distribution must also remain operable. Labels should let an operator trace a rack outlet to its branch, panel, upstream source and associated alternative path. Maintain up-to-date as-built records and verify them through approved tracing methods. A change that moves both server cords onto one source can silently remove the intended independence even while every light remains green.

At each step ask four questions: what normal current passes, what fault energy is possible, what may be isolated for maintenance, and which downstream services disappear? The answer supports capacity planning, safe work planning, failure response and acceptance testing.

### Read a path in normal and maintenance states
A simplified path is utility → transformer → main board → UPS → branch panel → rack PDU → server inlet. Add a maintenance bypass around the UPS. In normal operation, trace current through the conversion path. In bypass, trace it through the alternate switching path and mark every shared upstream component. The server can remain powered in both states while its disturbance protection changes.

Next consider a short circuit on one rack branch. The desired protective response is defined by the electrical design, often aiming to isolate the affected branch without unnecessarily opening the common source. A normal-load calculation cannot predict this sequence; the time-current and fault-duty study supplies that evidence. Record which specialist document supports the installed device combination.

An operator-facing source table should include the physical outlet, branch identifier, panel, UPS or bypass state and upstream source. During a change, verify the actual label against the current diagram and approved tracing evidence. If two labels disagree, the correct action is a controlled hold. Guessing from cable direction converts a documentation defect into a possible wrong-source intervention.

### Enclosure ingress protection is a scoped rating
An IP code describes protection provided by an enclosure against specified access/solid-object and water-ingress conditions. The first characteristic digit concerns access and solid ingress; the second concerns water. An X means that the particular characteristic is not specified in that code, not a claim of the maximum level. Read the actual standard and product test conditions rather than translating the code into the unbounded word waterproof.

The installed enclosure must preserve the rated arrangement. Cable glands, unused openings, doors, seals and mounting orientation can change the effective protection. A highly rated empty box can lose its intended performance after an unapproved hole is cut. Ingress rating also does not establish fire resistance, fault-current withstand, corrosion suitability or thermal capacity. A tightly sealed enclosure may require additional thermal review because reducing ventilation can increase internal temperature.

In a proposal review, identify the actual exposure, select the applicable required protection through the qualified design, and verify the complete installed assembly. Do not assume that passing one water test proves every other water exposure or indefinite immersion. Keep the current product documentation and installation conditions with the acceptance record.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. Rack outlet A traces to panel PA, UPS-A and transformer T1. Outlet B traces to panel PB, UPS-B but also transformer T1.

**Reasoning:** The downstream UPS paths differ, but the transformer is a shared upstream dependency. Their batteries may bridge a defined interruption; they do not make unlimited independence from T1.

#### Guided practice

A rack PDU label says 32 A, while its feeding branch is limited to 25 A. What constrains the path?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** The feeding branch is the smaller applicable current limit, subject also to other equipment and installation constraints.

#### Independent task

Environment: analytical

Annotate a synthetic single-line diagram and produce an outlet-to-source tracing table.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Identify normal switch positions.
- Locate one common source and one maintainable isolation boundary.
- Separate continuous ratings from fault-interrupting capability.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0041 · single · mechanism**

What does a single-line diagram primarily represent?

1. Battery chemistry alone
2. Only network IP addressing
3. Every physical conductor bend
4. Functional electrical connectivity

**Correct option(s):** 4

- Option 1: Incorrect. The diagram covers the electrical system.
- Option 2: Incorrect. That belongs to network documentation.
- Option 3: Incorrect. It is not a detailed routing drawing.
- Option 4: Correct. It abstracts the power path and major devices.

**DCCA-Q0042 · single · mechanism**

A rack PDU has current metering. What should not be assumed?

1. Its measurements require interpretation
2. It provides battery ride-through
3. It has a specified input rating
4. It distributes power to outlets

**Correct option(s):** 2

- Option 1: Incorrect. Meter values need a boundary and units.
- Option 2: Correct. Metering does not imply stored energy.
- Option 3: Incorrect. Its supported input must be rated.
- Option 4: Incorrect. That is its basic function.

**DCCA-Q0043 · single · mechanism**

Which transformer statement is correct?

1. It always includes batteries
2. It guarantees independent utility feeds
3. It changes voltage while incurring losses
4. It creates net energy

**Correct option(s):** 3

- Option 1: Incorrect. Storage is not inherent to a transformer.
- Option 2: Incorrect. Upstream source independence is separate.
- Option 3: Correct. Energy is transferred rather than created.
- Option 4: Incorrect. That violates conservation of energy.

**DCCA-Q0044 · single · diagnosis**

Two rack feeds terminate at one transformer. What remains shared?

Synthetic educational evidence; not field measurements.

Feed A: panel PA → UPS-A → T1
Feed B: panel PB → UPS-B → T1

1. The server operating system license
2. The transformer failure domain
3. All network addresses
4. Every downstream breaker necessarily

**Correct option(s):** 2

- Option 1: Incorrect. Licensing is unrelated to the source path.
- Option 2: Correct. Both paths depend on that equipment.
- Option 3: Incorrect. Electrical topology does not establish addressing.
- Option 4: Incorrect. Those may be separate.

**DCCA-Q0045 · single · mechanism**

What does a breaker interrupting rating address?

1. Fault-current interruption capability
2. Cabinet static load
3. Maximum Ethernet throughput
4. Daily energy consumption

**Correct option(s):** 1

- Option 1: Correct. It concerns safely interrupting specified fault conditions.
- Option 2: Incorrect. That is mechanical capacity.
- Option 3: Incorrect. That is a network property.
- Option 4: Incorrect. Energy is not an interruption rating.

**DCCA-Q0046 · single · mechanism**

Why is a larger upstream breaker not enough to prove selectivity?

1. Device time-current behavior and fault conditions matter
2. All breakers trip at identical times
3. Selectivity concerns only cable labels
4. Upstream breakers never trip

**Correct option(s):** 1

- Option 1: Correct. Rating size alone does not establish coordinated operation.
- Option 2: Incorrect. Their characteristics can differ.
- Option 3: Incorrect. It concerns protective operation.
- Option 4: Incorrect. They operate for conditions in their protection range.

**DCCA-Q0047 · single · mechanism**

What is protective bonding intended to support?

1. Increased application storage
2. The electrical protective scheme for exposed conductive parts
3. Automatic battery recharge
4. Normal packet forwarding

**Correct option(s):** 2

- Option 1: Incorrect. Bonding does not add storage.
- Option 2: Correct. Bonding is a safety-related connection.
- Option 3: Incorrect. That requires charging equipment.
- Option 4: Incorrect. It does not replace network connectivity.

**DCCA-Q0048 · single · mechanism**

Which conductor should not be casually substituted for protective earth?

1. Neutral
2. An approved bonding conductor
3. A designated protective conductor
4. An engineered grounding connection

**Correct option(s):** 1

- Option 1: Correct. Its function and current behavior differ.
- Option 2: Incorrect. Its specified role is protective bonding.
- Option 3: Incorrect. That is intended for the protective scheme.
- Option 4: Incorrect. It may be part of the required protective arrangement.

**DCCA-Q0049 · single · mechanism**

What is the best outlet label relationship?

1. Outlet to purchase date only
2. Outlet to server hostname only
3. Outlet to the nearest panel by physical distance
4. Outlet to branch to panel to source

**Correct option(s):** 4

- Option 1: Incorrect. Date does not identify the feed.
- Option 2: Incorrect. The hostname does not establish upstream supply.
- Option 3: Incorrect. The nearest panel is not necessarily the actual electrical source.
- Option 4: Correct. It supports source tracing and work planning.

**DCCA-Q0050 · single · diagnosis**

Both server cords are moved to UPS-A while service stays online. What changed?

Synthetic educational evidence; not field measurements.

Before: cord1→UPS-A; cord2→UPS-B
After: cord1→UPS-A; cord2→UPS-A
Application remains online.

1. Server energy consumption must double
2. The application became geographically redundant
3. Redundancy improved automatically
4. Feed independence was lost

**Correct option(s):** 4

- Option 1: Incorrect. Cord placement does not imply doubled consumption.
- Option 2: Incorrect. Electrical reconnection does not add a site.
- Option 3: Incorrect. Both now share one source.
- Option 4: Correct. Normal operation can conceal a weakened failure state.

**DCCA-Q0051 · single · diagnosis**

A 32 A rack PDU is fed by a branch limited to 25 A. Which limit constrains the path?

Synthetic educational evidence; not field measurements.

Rack PDU input rating: 32 A
Approved feeding-branch limit: 25 A

1. The sum of both ratings
2. The 32 A label alone
3. Neither limit below full rack occupancy
4. The 25 A branch limit

**Correct option(s):** 4

- Option 1: Incorrect. Series path ratings are not additive.
- Option 2: Incorrect. The PDU rating does not raise the branch limit.
- Option 3: Incorrect. Electrical limits apply regardless of occupancy.
- Option 4: Correct. The upstream path cannot be ignored.

**DCCA-Q0052 · single · mechanism**

What must be read before interpreting a switch symbol's connectivity?

1. Only the downstream load total
2. Server warranty length
3. Only the breaker current rating
4. Diagram legend and normal state

**Correct option(s):** 4

- Option 1: Incorrect. Load magnitude does not establish the depicted connectivity.
- Option 2: Incorrect. Warranty does not define connectivity.
- Option 3: Incorrect. Rating does not reveal whether a switch is normally open or closed.
- Option 4: Correct. Symbols and switch positions define the path.

**DCCA-Q0053 · single · mechanism**

Why keep as-built diagrams current after a change?

1. Drawings replace all testing
2. Only auditors use drawings
3. Old diagrams automatically update themselves
4. Effective connectivity may differ from original design

**Correct option(s):** 4

- Option 1: Incorrect. Documentation cannot demonstrate every behavior.
- Option 2: Incorrect. Operators rely on them for safe decisions.
- Option 3: Incorrect. Physical changes require controlled record updates.
- Option 4: Correct. Operators need the actual system arrangement.

**DCCA-Q0054 · single · mechanism**

Which event illustrates poor fault containment?

1. Only the affected branch is isolated
2. A meter reports the branch current
3. A label records the branch identifier
4. A local branch fault trips the shared upstream supply

**Correct option(s):** 4

- Option 1: Incorrect. That is the desired local containment pattern.
- Option 2: Incorrect. Observation is not loss of containment.
- Option 3: Incorrect. Identification supports containment planning.
- Option 4: Correct. Healthy branches lose power unnecessarily.

**DCCA-Q0055 · single · calculation**

A transformer has 100 kW input and 97 kW output. What is its loss?

Synthetic educational evidence; not field measurements.

Transformer input: 100 kW
Transformer output: 97 kW

1. 3 kWh
2. 197 kW
3. 3 kW
4. 97 kW

**Correct option(s):** 3

- Option 1: Incorrect. A duration is needed for energy loss.
- Option 2: Incorrect. Adding input and output is not loss.
- Option 3: Correct. Input minus output gives the loss.
- Option 4: Incorrect. That is useful output.

**DCCA-Q0056 · single · mechanism**

What does a continuous-current rating describe?

1. Every possible short-circuit current
2. Supported normal current under stated conditions
3. Maintenance frequency
4. Annual energy use

**Correct option(s):** 2

- Option 1: Incorrect. Fault capability has separate ratings.
- Option 2: Correct. It is distinct from fault interruption.
- Option 3: Incorrect. The rating does not define a complete maintenance schedule.
- Option 4: Incorrect. Current is not energy.

**DCCA-Q0057 · single · mechanism**

Why trace both normal and bypass paths?

1. Only normal operation matters
2. Bypass always improves independence
3. Bypass has no electrical connection
4. Maintenance configurations can change dependencies

**Correct option(s):** 4

- Option 1: Incorrect. The service must also be assessed during maintenance.
- Option 2: Incorrect. It may introduce shared dependencies.
- Option 3: Incorrect. It is a real alternate power path.
- Option 4: Correct. Bypass may place loads on a different source.

**DCCA-Q0058 · single · mechanism**

Which action is appropriate when field labels conflict with an approved diagram?

1. Remove both labels
2. Proceed using memory
3. Hold affected work and resolve the discrepancy
4. Assume the newest-looking label is right

**Correct option(s):** 3

- Option 1: Incorrect. That worsens identification.
- Option 2: Incorrect. Memory does not resolve conflicting evidence.
- Option 3: Correct. Uncertain isolation boundaries undermine safe execution.
- Option 4: Incorrect. Appearance is not authoritative verification.

**DCCA-Q0059 · single · mechanism**

What is the distinction between a branch circuit and a rack outlet?

1. A branch can supply multiple outlets
2. An outlet contains a generator
3. A branch is an IP subnet
4. Each outlet guarantees a separate utility

**Correct option(s):** 1

- Option 1: Correct. Outlet count is not independent source count.
- Option 2: Incorrect. Generation is not inherent to an outlet.
- Option 3: Incorrect. This is an electrical concept.
- Option 4: Incorrect. That is not inherent.

**DCCA-Q0060 · single · diagnosis**

A rated enclosure receives an unapproved cable opening. Which claim now needs re-evaluation?

Synthetic educational evidence.

Enclosure: documented ingress rating
Modification: unapproved unsealed cable opening
No installed re-evaluation recorded.

1. The installed assembly still provides its required ingress protection
2. The enclosure's original product model no longer exists
3. Every upstream breaker is now uncoordinated
4. The branch current must have doubled

**Correct option(s):** 1

- Option 1: Correct. The opening can change the enclosure's tested boundary.
- Option 2: Incorrect. The model remains identifiable; the installed condition changed.
- Option 3: Incorrect. Ingress modification does not by itself establish that protection result.
- Option 4: Incorrect. The opening does not establish a load-current change.

#### Recall

**What does a single-line diagram primarily represent?**

Functional electrical connectivity Correct. It abstracts the power path and major devices.

**A rack PDU has current metering. What should not be assumed?**

It provides battery ride-through Correct. Metering does not imply stored energy.

**Which transformer statement is correct?**

It changes voltage while incurring losses Correct. Energy is transferred rather than created.

**Two rack feeds terminate at one transformer. What remains shared?**

The transformer failure domain Correct. Both paths depend on that equipment.

**What does a breaker interrupting rating address?**

Fault-current interruption capability Correct. It concerns safely interrupting specified fault conditions.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DCCA-M04 — UPS operating modes and bypass

### DCCA-L04 — UPS operating modes and bypass

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L03

An uninterruptible power supply bridges or conditions power disturbances within a defined envelope. In an online double-conversion architecture, a rectifier supplies a DC link and an inverter supplies the load. Stored energy supports the DC link during an input interruption. Other topologies use different normal and transfer paths. Name the topology and the specific mode; the word UPS does not establish zero interruption under every fault.

The static bypass is a power-electronic route around the inverter, commonly used for overload or inverter trouble when bypass conditions permit. Transfer depends on equipment behavior, synchronization and acceptable source voltage/frequency. A maintenance bypass allows service work through a different switching arrangement; it may remove both conditioning and battery support from the protected path. Static bypass and maintenance bypass are not interchangeable terms.

A UPS has multiple limits: kW, kVA, current, overload duration, environmental rating, battery runtime and recharge capability. Parallel modules may provide capacity, redundancy or both. With three 100 kW modules carrying 180 kW, one failed module leaves 200 kW of nameplate capacity; two failed modules leave only 100 kW. That arithmetic is necessary but does not prove independent controls, switchgear or bypass paths.

Normal-mode efficiency is output real power divided by input real power for the same interval. Part-load behavior and fixed losses matter. Economy modes can reduce conversion losses but change disturbance exposure and transfer behavior. Select modes against required ride-through, power quality and service evidence instead of choosing the highest advertised efficiency in isolation.

During commissioning, verify source loss, restoration, overload behavior, alarms, bypass availability, battery discharge and the permitted maintenance sequence. A successful display self-test does not replace a representative load test. In operation, trend load, mode, alarms, battery state and redundancy. A UPS in bypass may continue powering the service while silently reducing its protection; that state needs an owner, duration and recovery plan.

### Follow the energy through four UPS states
In normal double-conversion operation, source energy passes through rectification to the DC link and through inversion to the load. During source loss, stored energy replaces the rectifier input to that link. On static bypass, the load follows the bypass source within the device's permitted transfer conditions. On maintenance bypass, the isolated UPS may be completely outside the load path.

A mode table should therefore record four separate properties: the source carrying current, whether stored energy can support that path, which conditioning remains, and which components can be safely maintained under the approved procedure. A single green status indicator cannot communicate all four.

Consider three 100 kW modules supplying 180 kW. Normal module loading is about 60 kW each if sharing is equal. With one unavailable, each survivor carries about 90 kW. The sum passes a 100 kW-per-module check, but the common output bus, bypass and environment still need review. With one module already failed, removing another for maintenance leaves only 100 kW and is infeasible at the stated load. The work plan must use effective available state.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A UPS supplies 90 kW while consuming 95 kW. Its maintenance bypass feeds the rack directly from utility.

**Reasoning:** Efficiency is 90/95 = 94.74%; loss is 5 kW. Moving to maintenance bypass changes the load path and may remove battery ride-through. The UPS efficiency calculation does not establish protection in that state.

#### Guided practice

Three 120 kW modules carry 210 kW. What nameplate capacity remains after one module is unavailable?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** 240 kW remains, leaving 30 kW nominal headroom before derating and other system constraints.

#### Independent task

Environment: analytical

Prepare a UPS mode-transition table covering normal, battery, static bypass and maintenance bypass.

**Packaged starter material**

- course_labs/DCCA/README.md
- course_labs/DCCA/scenario.json
- course_labs/DCCA/answers-template.json

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Describe which path carries the load in each mode.
- Identify lost protection and abort conditions.
- Define functional load and alarm evidence for each tested transition.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0061 · single · mechanism**

What supports the DC link during loss of UPS input?

1. Stored energy
2. An Ethernet heartbeat
3. Rack blanking panels
4. The maintenance label

**Correct option(s):** 1

- Option 1: Correct. The battery or other store supplies the inverter path.
- Option 2: Incorrect. Communication does not supply load energy.
- Option 3: Incorrect. Panels manage airflow rather than electricity.
- Option 4: Incorrect. A label stores no energy.

**DCCA-Q0062 · single · mechanism**

In double conversion, which stage supplies normal AC output?

1. Static bypass in every normal state
2. Inverter
3. Rectifier alone
4. Battery enclosure alone

**Correct option(s):** 2

- Option 1: Incorrect. Double-conversion normal operation uses the inverter path.
- Option 2: Correct. It converts the DC-link energy to AC.
- Option 3: Incorrect. The rectifier produces DC.
- Option 4: Incorrect. The enclosure is not an AC conversion stage.

**DCCA-Q0063 · single · mechanism**

What differentiates maintenance bypass from static bypass?

1. Static bypass guarantees unlimited runtime
2. Maintenance bypass supports equipment isolation through its own arrangement
3. They are identical names for the battery
4. Maintenance bypass always adds conditioning

**Correct option(s):** 2

- Option 1: Incorrect. It depends on an available bypass source.
- Option 2: Correct. Its purpose and switching path differ.
- Option 3: Incorrect. Neither term names the battery.
- Option 4: Incorrect. It can remove UPS conditioning from the path.

**DCCA-Q0064 · single · mechanism**

A UPS on bypass still powers its load. What must be assessed?

1. Only the battery charge percentage
2. Whether rack doors are closed
3. The protection lost in the current mode
4. Only whether the display is lit

**Correct option(s):** 3

- Option 1: Incorrect. Battery charge does not establish whether the current bypass path can use that energy.
- Option 2: Incorrect. That does not determine bypass ride-through.
- Option 3: Correct. Powered service does not imply normal UPS protection.
- Option 4: Incorrect. A lit display does not reveal the full power path.

**DCCA-Q0065 · single · calculation**

Three 100 kW UPS modules carry 180 kW. After one module fails, what nominal capacity remains?

Synthetic educational evidence; not field measurements.

Installed modules: 3 × 100 kW
Load: 180 kW
Unavailable modules: 1

1. 300 kW
2. 200 kW
3. 180 kW
4. 100 kW

**Correct option(s):** 2

- Option 1: Incorrect. The failed module is unavailable.
- Option 2: Correct. Two remaining modules provide 200 kW.
- Option 3: Incorrect. That is the load rather than installed remaining capacity.
- Option 4: Incorrect. Two modules remain, not one.

**DCCA-Q0066 · single · mechanism**

What does an N+1 module count fail to establish by itself?

1. The existence of a normal load
2. The number of modules
3. A possible capacity spare
4. Independence of shared bypass and controls

**Correct option(s):** 4

- Option 1: Incorrect. N is based on a load requirement.
- Option 2: Incorrect. The count explicitly describes modules.
- Option 3: Incorrect. One extra unit can provide capacity reserve.
- Option 4: Correct. Common dependencies require separate analysis.

**DCCA-Q0067 · single · calculation**

A UPS outputs 80 kW and inputs 84 kW. What is its loss?

Synthetic educational evidence; not field measurements.

UPS input: 84 kW
UPS output: 80 kW

1. 4 kW
2. 164 kW
3. 4 kWh
4. 95.2 kW

**Correct option(s):** 1

- Option 1: Correct. Input minus output is the loss.
- Option 2: Incorrect. Adding both values is not loss.
- Option 3: Incorrect. A time interval is required for energy.
- Option 4: Incorrect. That resembles a percentage, not the loss.

**DCCA-Q0068 · single · calculation**

Why compare UPS kW and kVA limits?

1. Either can be the binding constraint
2. They always have identical values
3. kW measures only floor loading
4. kVA measures battery age

**Correct option(s):** 1

- Option 1: Correct. Power factor separates real and apparent demand.
- Option 2: Incorrect. Many devices have different limits.
- Option 3: Incorrect. It measures real power.
- Option 4: Incorrect. It measures apparent power.

**DCCA-Q0069 · single · mechanism**

What can constrain transfer to static bypass?

1. Office lighting brightness
2. Source voltage, frequency and synchronization conditions
3. Only the UPS battery ampere-hour rating
4. Number of fiber strands

**Correct option(s):** 2

- Option 1: Incorrect. That is not the bypass acceptance condition.
- Option 2: Correct. The alternate source must satisfy the equipment's transfer envelope.
- Option 3: Incorrect. Stored charge does not establish bypass-source synchronization or quality.
- Option 4: Incorrect. Fiber count does not establish source suitability.

**DCCA-Q0070 · single · mechanism**

Why test a UPS with representative load?

1. A representative load guarantees all future loads
2. Behavior under demand can differ from a display self-test
3. Load tests replace battery maintenance
4. Self-tests measure all downstream services

**Correct option(s):** 2

- Option 1: Incorrect. It demonstrates only tested conditions.
- Option 2: Correct. The actual power path and transfer need evidence.
- Option 3: Incorrect. Maintenance remains necessary.
- Option 4: Incorrect. They may not exercise the complete chain.

**DCCA-Q0071 · single · mechanism**

Which factor matters when selecting an economy mode?

1. Required disturbance tolerance and transfer behavior
2. Number of sales awards
3. Advertised efficiency alone
4. Cabinet appearance

**Correct option(s):** 1

- Option 1: Correct. Efficiency must be evaluated with service constraints.
- Option 2: Incorrect. Awards are not acceptance evidence.
- Option 3: Incorrect. A single metric omits protection behavior.
- Option 4: Incorrect. Appearance does not establish electrical performance.

**DCCA-Q0072 · single · mechanism**

What should a UPS mode alarm include operationally?

1. Only a decorative icon
2. Automatic dismissal after one second
3. A response owner and defined restoration path
4. A claim that all loads stopped

**Correct option(s):** 3

- Option 1: Incorrect. That does not establish response.
- Option 2: Incorrect. That can conceal persistent risk.
- Option 3: Correct. An alarm needs an actionable consequence.
- Option 4: Incorrect. Mode changes do not always interrupt service.

**DCCA-Q0073 · single · diagnosis**

A UPS has sufficient power rating but only two minutes of proven runtime; generator startup needs five. What is the issue?

Synthetic educational evidence; not field measurements.

Proven battery duration at load: 2 min
Required generator sequence: 5 min

1. The generator is unnecessary
2. kW automatically implies five-minute runtime
3. The energy bridge is insufficient
4. More Ethernet bandwidth solves it

**Correct option(s):** 3

- Option 1: Incorrect. The design requires a longer-duration source.
- Option 2: Incorrect. It does not specify stored energy.
- Option 3: Correct. Power capacity and duration are separate constraints.
- Option 4: Incorrect. Communication bandwidth does not provide energy.

**DCCA-Q0074 · single · mechanism**

What is a rectifier's role?

1. Store unlimited energy
2. Convert AC input to DC
3. Remove all downstream faults
4. Convert optical light to data

**Correct option(s):** 2

- Option 1: Incorrect. Conversion is not storage.
- Option 2: Correct. It supplies the DC side of the conversion chain.
- Option 3: Incorrect. Protection requires other mechanisms.
- Option 4: Incorrect. That is not its UPS function.

**DCCA-Q0075 · single · mechanism**

Why record UPS loading by operating state?

1. Battery chemistry determines every downstream current
2. Load never changes after installation
3. Only annual averages matter
4. Loss of modules or bypass can change the limiting capacity

**Correct option(s):** 4

- Option 1: Incorrect. Actual loads determine demand.
- Option 2: Incorrect. Growth and failures change demand and paths.
- Option 3: Incorrect. Short peaks and failures can exceed limits.
- Option 4: Correct. Normal operation can hide reduced-state overload.

**DCCA-Q0076 · single · calculation**

A UPS outputs 90 kW from 100 kW input. What efficiency is observed?

Synthetic educational evidence; not field measurements.

Input real power: 100 kW
Output real power: 90 kW

1. 90%
2. 190%
3. 111%
4. 10%

**Correct option(s):** 1

- Option 1: Correct. Output divided by input is 0.9.
- Option 2: Incorrect. Adding the values is not efficiency.
- Option 3: Incorrect. The ratio was reversed.
- Option 4: Incorrect. That is the loss fraction.

**DCCA-Q0077 · single · mechanism**

What is needed before a maintenance-bypass transition?

1. A dashboard screenshot only
2. A higher application timeout
3. An approved sequence with verified prerequisites
4. A generic internet sequence

**Correct option(s):** 3

- Option 1: Incorrect. That is not a switching procedure.
- Option 2: Incorrect. Timeouts do not establish safe electrical transitions.
- Option 3: Correct. Switching state and permitted load path must be controlled.
- Option 4: Incorrect. Equipment arrangements differ.

**DCCA-Q0078 · single · mechanism**

Which statement about UPS overload capability is sound?

1. It can be used indefinitely
2. It replaces downstream protection
3. It is the same for every model
4. It is bounded by magnitude, duration and operating conditions

**Correct option(s):** 4

- Option 1: Incorrect. That ignores duration limits.
- Option 2: Incorrect. Fault protection remains necessary.
- Option 3: Incorrect. Equipment characteristics differ.
- Option 4: Correct. Temporary capability is not unlimited continuous capacity.

**DCCA-Q0079 · single · mechanism**

What should be checked after utility restoration?

1. That all maintenance records are deleted
2. Battery runtime without waiting or testing
3. Stable source, correct UPS mode and controlled recharge
4. Only that the alarm banner disappeared

**Correct option(s):** 3

- Option 1: Incorrect. Records must be retained.
- Option 2: Incorrect. Recharge state may still be incomplete.
- Option 3: Correct. Restoration can introduce load and mode changes.
- Option 4: Incorrect. A cleared banner is not complete evidence.

**DCCA-Q0080 · single · mechanism**

Which observation best verifies inverter-to-battery continuity?

1. The UPS model name
2. A green network link
3. The battery purchase invoice
4. Load-side voltage and service behavior during an approved source-loss test

**Correct option(s):** 4

- Option 1: Incorrect. A product name is not an executed test.
- Option 2: Incorrect. The link does not prove output waveform continuity.
- Option 3: Incorrect. Ownership does not demonstrate continuity.
- Option 4: Correct. It measures the required delivered function.

#### Recall

**What supports the DC link during loss of UPS input?**

Stored energy Correct. The battery or other store supplies the inverter path.

**In double conversion, which stage supplies normal AC output?**

Inverter Correct. It converts the DC-link energy to AC.

**What differentiates maintenance bypass from static bypass?**

Maintenance bypass supports equipment isolation through its own arrangement Correct. Its purpose and switching path differ.

**A UPS on bypass still powers its load. What must be assessed?**

The protection lost in the current mode Correct. Powered service does not imply normal UPS protection.

**Three 100 kW UPS modules carry 180 kW. After one module fails, what nominal capacity remains?**

200 kW Correct. Two remaining modules provide 200 kW.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DCCA-M05 — Stored energy, runtime and battery condition

### DCCA-L05 — Stored energy, runtime and battery condition

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L04

A battery bank converts chemical energy into electrical energy. Its nominal voltage, ampere-hour rating and chemistry are starting descriptors, not a universal runtime guarantee. Multiplying nominal volts by ampere-hours gives a nominal watt-hour estimate. Delivered energy depends on discharge rate, temperature, age, cutoff voltage, cell condition and conversion losses. Use the manufacturer's discharge data for a real selection.

Series-connected cells raise voltage while retaining the string's ampere-hour capacity. Parallel strings increase nominal capacity while adding protection, balancing and fault-management requirements. One weak cell can constrain a series string. A high open-circuit voltage does not prove useful discharge capacity, and a battery-management-system estimate is a model that needs validation.

For a simple energy balance, required stored energy is load power times duration divided by delivery efficiency. A 100 kW load for ten minutes needs 16.67 kWh at the load; at 90% delivery efficiency the source must provide at least 18.52 kWh under the stated discharge conditions. Additional design factors are not invented by the arithmetic: aging, temperature and reserve requirements come from the approved specification and supplier evidence.

Battery condition is maintained through inspection, appropriate electrical tests, trend analysis and controlled replacement. Temperature affects performance and aging, while connections can develop high resistance. Thermal imaging can identify unusual heating under a known load but does not measure every internal defect. Capacity testing provides different information from impedance or conductance trending; select tests for the question being answered.

Charging restores energy but also places demand on the upstream system and produces heat. After a discharge, a system may carry normal load before its reserve is fully restored. Declare that reduced-resilience interval and coordinate generator loading, recharge limits and further work. Different chemistries have different hazards and approved response procedures; a generic battery lesson cannot authorize handling, live measurement, fire response or disposal.

Treat runtime as an observed or supplier-supported curve tied to load and conditions. Record the test setup, starting state, endpoints, duration, output behavior and restoration. An untested calculator estimate belongs in the analytical evidence category, not in a claim of commissioned runtime.

### Separate nominal energy from a runtime claim
A 240 V, 100 Ah string has a nominal 24 kWh arithmetic value. A 60 kW load for 15 minutes needs 15 kWh at the output. At 90% delivery efficiency, the source-energy requirement is 16.67 kWh. The apparent 7.33 kWh difference is not automatically usable reserve because the Ah rating may be specified at a much slower discharge rate and different cutoff.

Use the supplier's discharge table for the intended duration and endpoint, then apply the approved aging and environmental factors. Record whether the quoted bank is new or end-of-life rated and whether any string is unavailable. A series string can be limited by one weak cell even when the total open-circuit voltage looks reasonable.

A runtime acceptance record needs starting charge, load, temperature, measured output, alarm sequence, stopping criterion and recovery. If the test stops after five minutes, claim five minutes at those conditions. Do not extrapolate to fifteen minutes without an explicitly labeled model. Afterward, verify recharge and the return of the required reserve before scheduling another resilience-reducing task.

### Interpret thermography as a measurement, not a colored verdict
A thermal imager observes infrared radiation and estimates surface temperature using assumptions about emissivity, reflected radiation, viewing geometry and atmospheric path. A shiny surface can reflect a nearby warm object and appear hot without having that same physical temperature. Compare suitable like-for-like components under known load and use the instrument's supported method. A bright image region is a diagnostic lead, not automatically a proven loose connection.

Load matters because resistive heating follows current squared times resistance. A connection inspected at light load can look unremarkable yet heat excessively under the required demand. Record current or load, ambient conditions, surface/material assumptions, location and image metadata. Temperature comparisons across unlike materials can be misleading without appropriate correction.

Electrical enclosures introduce access and energy hazards. Thermographic work follows the authorized inspection method and applicable safe-work controls; this course does not provide a live-panel opening procedure. If an anomaly is found, assess it through the approved severity and response process, investigate the cause and verify the correction under comparable conditions. The thermal image complements electrical and physical evidence rather than replacing all of it.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A 48 V bank is nominally rated 100 Ah. A load requires 1 kW for three hours.

**Reasoning:** Nominal energy is 4.8 kWh. The load needs 3 kWh. This comparison is only a first screen: usable capacity at the discharge rate, cutoff, temperature and age plus conversion efficiency must support the requirement.

#### Guided practice

Twelve 2 V, 200 Ah cells are connected in series. What nominal bank voltage and Ah rating result?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** 24 V and 200 Ah. Series voltage adds; Ah capacity does not add across a single string.

#### Independent task

Environment: analytical

Create a runtime acceptance plan and a separate nominal-energy calculation.

**Packaged starter material**

- course_labs/DCCA/README.md
- course_labs/DCCA/scenario.json
- course_labs/DCCA/answers-template.json

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Do not equate nominal energy with guaranteed delivered energy.
- Include load, temperature, starting charge and cutoff assumptions.
- Show the recharge and reduced-resilience period.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0081 · single · diagnosis**

Twelve 2 V cells are connected in series. What nominal voltage results?

Synthetic educational evidence; not field measurements.

Cells: 12
Nominal cell voltage: 2 V
Connection: one series string

1. 12 V
2. 144 V
3. 2 V
4. 24 V

**Correct option(s):** 4

- Option 1: Incorrect. The cell voltage must be included.
- Option 2: Incorrect. Multiplying the cell count by itself is incorrect.
- Option 3: Incorrect. That is one cell voltage.
- Option 4: Correct. Series cell voltages add.

**DCCA-Q0082 · single · diagnosis**

A 48 V, 100 Ah bank has what nominal energy?

Synthetic educational evidence; not field measurements.

Nominal bank voltage: 48 V
Nominal charge rating: 100 Ah

1. 0.48 kWh
2. 4800 kWh
3. 148 kWh
4. 4.8 kWh

**Correct option(s):** 4

- Option 1: Incorrect. This loses a factor of ten.
- Option 2: Incorrect. The Wh-to-kWh conversion is missing.
- Option 3: Incorrect. Adding voltage and capacity is dimensionally invalid.
- Option 4: Correct. Voltage times Ah gives 4800 Wh.

**DCCA-Q0083 · single · calculation**

A 60 kW load needs 15 minutes of support. How much load-side energy is required?

Synthetic educational evidence; not field measurements.

Load: 60 kW
Required interval: 15 min

1. 60 kWh
2. 900 kWh
3. 15 kWh
4. 4 kWh

**Correct option(s):** 3

- Option 1: Incorrect. That would support one hour.
- Option 2: Incorrect. Minutes must be converted to hours.
- Option 3: Correct. Fifteen minutes is one-quarter hour.
- Option 4: Incorrect. Dividing power by time is incorrect.

**DCCA-Q0084 · single · mechanism**

Why is nominal Ah insufficient to establish UPS runtime?

1. Every battery has identical efficiency
2. Discharge rate and operating conditions affect usable capacity
3. Runtime depends only on cabinet height
4. Ah is a voltage unit

**Correct option(s):** 2

- Option 1: Incorrect. Chemistry and conditions differ.
- Option 2: Correct. The rating has defined test conditions.
- Option 3: Incorrect. Physical height does not define usable energy.
- Option 4: Incorrect. Ah measures charge capacity.

**DCCA-Q0085 · single · mechanism**

What happens to Ah rating when identical cells form one series string?

1. It becomes zero
2. It multiplies by cell count
3. It becomes equal to voltage
4. It remains the cell Ah rating

**Correct option(s):** 4

- Option 1: Incorrect. The string retains charge capacity.
- Option 2: Incorrect. That is the voltage behavior, not Ah.
- Option 3: Incorrect. The quantities have different units.
- Option 4: Correct. Series connection increases voltage rather than Ah.

**DCCA-Q0086 · single · mechanism**

What can a weak cell do in a series string?

1. Double the bank's capacity
2. Limit the string's usable discharge
3. Be ignored because other cells bypass it automatically
4. Eliminate all heat generation

**Correct option(s):** 2

- Option 1: Incorrect. Weakness does not add capacity.
- Option 2: Correct. The series current passes through every cell.
- Option 3: Incorrect. A normal series connection does not imply bypass.
- Option 4: Incorrect. The cell can instead become a concern.

**DCCA-Q0087 · single · mechanism**

Which evidence most directly demonstrates delivered runtime?

1. An impedance trend without a discharge result
2. Open-circuit voltage alone
3. A controlled discharge at specified load and endpoints
4. A new-battery invoice

**Correct option(s):** 3

- Option 1: Incorrect. Condition trending is useful but does not directly measure delivered duration.
- Option 2: Incorrect. Voltage alone cannot establish capacity.
- Option 3: Correct. It observes energy delivery under defined conditions.
- Option 4: Incorrect. Purchase does not demonstrate installed performance.

**DCCA-Q0088 · single · mechanism**

After a battery discharge, why declare reduced resilience?

1. Reserve may not be fully recharged
2. A cleared alarm guarantees full capacity
3. Batteries cannot ever recharge
4. The load always becomes zero

**Correct option(s):** 1

- Option 1: Correct. Normal supply restoration does not instantly restore stored energy.
- Option 2: Incorrect. Alarm state may not prove restored energy.
- Option 3: Incorrect. They are designed to recharge within constraints.
- Option 4: Incorrect. IT service may continue.

**DCCA-Q0089 · single · mechanism**

What is the role of a manufacturer's discharge curve?

1. Relate capacity to discharge conditions and endpoints
2. Prove the installed bank has no weak cells
3. Replace all maintenance
4. Guarantee every installed connection is correct

**Correct option(s):** 1

- Option 1: Correct. It supports realistic runtime selection.
- Option 2: Incorrect. Supplier curves do not establish the condition of the actual installed bank.
- Option 3: Incorrect. Condition changes over time.
- Option 4: Incorrect. Installation still needs verification.

**DCCA-Q0090 · single · calculation**

A load needs 9 kWh and delivery efficiency is 90%. What source energy is needed before other factors?

Synthetic educational evidence; not field measurements.

Required load-side energy: 9 kWh
Delivery efficiency: 0.90

1. 19 kWh
2. 8.1 kWh
3. 10 kWh
4. 9 kWh

**Correct option(s):** 3

- Option 1: Incorrect. Adding efficiency as energy is invalid.
- Option 2: Incorrect. Multiplying understates the input need.
- Option 3: Correct. 9 divided by 0.9 equals 10.
- Option 4: Incorrect. That ignores delivery losses.

**DCCA-Q0091 · single · mechanism**

What does thermal imaging of a battery connection reveal?

1. Exact remaining Ah in every cell
2. Surface temperature patterns under the observed conditions
3. Cell chemistry without documentation
4. Guaranteed future runtime

**Correct option(s):** 2

- Option 1: Incorrect. Temperature alone does not measure capacity.
- Option 2: Correct. It can identify unusual heating but not every internal defect.
- Option 3: Incorrect. Appearance is not reliable chemistry identification.
- Option 4: Incorrect. A thermal image cannot establish that.

**DCCA-Q0092 · single · mechanism**

Why coordinate recharge with generator loading?

1. Charging adds upstream power demand
2. Charging produces no electrical load
3. Recharge changes only network traffic
4. Generators operate only at zero current

**Correct option(s):** 1

- Option 1: Correct. The source must carry IT load and recharge demand.
- Option 2: Incorrect. Energy must come from the source.
- Option 3: Incorrect. It is an electrical energy transfer.
- Option 4: Incorrect. They supply load current.

**DCCA-Q0093 · single · mechanism**

Which factor can affect both battery performance and aging?

1. Temperature
2. The UPS display refresh interval
3. The alarm acknowledgment policy alone
4. DNS suffix

**Correct option(s):** 1

- Option 1: Correct. Thermal conditions influence chemistry and available capacity.
- Option 2: Incorrect. Display timing does not directly determine electrochemical performance or aging.
- Option 3: Incorrect. Administrative response can matter operationally but does not define the battery physical aging mechanism.
- Option 4: Incorrect. It is unrelated to electrochemistry.

**DCCA-Q0094 · single · mechanism**

What distinguishes a capacity test from impedance trending?

1. Capacity testing measures only labels
2. They are always identical tests
3. Impedance directly guarantees runtime
4. Capacity testing measures delivered discharge; impedance is a condition indicator

**Correct option(s):** 4

- Option 1: Incorrect. It involves electrical discharge performance.
- Option 2: Incorrect. Their methods and outputs differ.
- Option 3: Incorrect. A trend alone does not prove delivered energy.
- Option 4: Correct. They answer related but different questions.

**DCCA-Q0095 · single · diagnosis**

What must be recorded with a runtime result?

Synthetic educational evidence; not field measurements.

Connection: two identical strings in parallel
Each string: 100 Ah
Use ideal nominal arithmetic before practical derating.

1. An unrelated rack photograph
2. Only the longest observed minute
3. Load, temperature, initial state and cutoff
4. The technician's favorite tool brand

**Correct option(s):** 3

- Option 1: Incorrect. It does not establish the discharge setup.
- Option 2: Incorrect. That omits the test conditions.
- Option 3: Correct. These define the result's applicability.
- Option 4: Incorrect. Preference is not the required boundary.

**DCCA-Q0096 · single · mechanism**

Two identical 100 Ah strings are paralleled in an ideal nominal estimate. What capacity results?

1. 200 Ah
2. Zero Ah
3. 100 Ah at doubled voltage
4. 10 Ah

**Correct option(s):** 1

- Option 1: Correct. Parallel charge capacity adds before practical derating.
- Option 2: Incorrect. Parallel connection does not eliminate capacity.
- Option 3: Incorrect. That describes series behavior incorrectly.
- Option 4: Incorrect. There is no such division.

**DCCA-Q0097 · single · mechanism**

Which response is appropriate to a battery alarm with an unfamiliar chemistry?

1. Follow the approved chemistry-specific response and escalate
2. Apply any remembered procedure
3. Open every cell immediately
4. Dismiss it if IT remains online

**Correct option(s):** 1

- Option 1: Correct. Hazards and procedures differ.
- Option 2: Incorrect. A generic response may be unsuitable.
- Option 3: Incorrect. Handling requires competence and authorization.
- Option 4: Incorrect. Continued service does not remove the hazard.

**DCCA-Q0098 · single · mechanism**

Why track connection condition?

1. Connections only affect software licensing
2. High resistance can create heating and voltage loss
3. Every warm connection proves a fire
4. Resistance cannot change after installation

**Correct option(s):** 2

- Option 1: Incorrect. They carry electrical current.
- Option 2: Correct. Connections are part of the delivery path.
- Option 3: Incorrect. Interpretation requires load and limits.
- Option 4: Incorrect. Mechanical and chemical degradation can alter it.

**DCCA-Q0099 · single · mechanism**

What does a battery state-of-charge estimate represent?

1. A model-based estimate that needs appropriate validation
2. A guarantee of full load support
3. A measurement of rack airflow
4. An authorization for maintenance

**Correct option(s):** 1

- Option 1: Correct. It is not perfect direct knowledge of future runtime.
- Option 2: Incorrect. Usable capacity and conditions still matter.
- Option 3: Incorrect. It concerns stored electrical energy.
- Option 4: Incorrect. Competence and permission are separate.

**DCCA-Q0100 · single · diagnosis**

A shiny battery connection looks hotter on an infrared image than an adjacent insulated surface. What is the strongest next interpretation?

Synthetic educational evidence.

IR survey: unlike surface materials
Current/load: not recorded
Reflected-temperature and emissivity assumptions: not verified.

1. The insulated surface must be unenergized
2. The shiny connection is certainly loose
3. The higher displayed number proves exact internal cell temperature
4. Check emissivity, reflections and comparable load before assigning the cause

**Correct option(s):** 4

- Option 1: Incorrect. Material appearance does not prove energy state.
- Option 2: Incorrect. The image alone does not establish contact resistance or cause.
- Option 3: Incorrect. The imager estimates surface temperature under assumptions.
- Option 4: Correct. Different surfaces can produce misleading apparent-temperature comparisons.

#### Recall

**Twelve 2 V cells are connected in series. What nominal voltage results?**

24 V Correct. Series cell voltages add.

**A 48 V, 100 Ah bank has what nominal energy?**

4.8 kWh Correct. Voltage times Ah gives 4800 Wh.

**A 60 kW load needs 15 minutes of support. How much load-side energy is required?**

15 kWh Correct. Fifteen minutes is one-quarter hour.

**Why is nominal Ah insufficient to establish UPS runtime?**

Discharge rate and operating conditions affect usable capacity Correct. The rating has defined test conditions.

**What happens to Ah rating when identical cells form one series string?**

It remains the cell Ah rating Correct. Series connection increases voltage rather than Ah.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DCCA-M06 — Generators, transfer and fuel autonomy

### DCCA-L06 — Generators, transfer and fuel autonomy

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L05

Standby generation provides longer-duration energy after the short ride-through supplied by a UPS. The complete sequence includes detecting an unacceptable source, starting the engine, reaching acceptable voltage and frequency, transferring permitted loads, accepting load steps and eventually returning to the normal source. Each transition has a duration and a condition. A generator that starts successfully but cannot accept the required step has not demonstrated the required service.

An automatic transfer switch selects a source according to its configured logic. Open-transition transfer disconnects one source before connecting the other; closed-transition arrangements briefly parallel sources under controlled conditions and require a suitable engineered scheme. A static transfer switch uses power electronics for a different class of transfer application. Product names do not replace review of actual transfer time, synchronization, interlocks and load tolerance.

Fuel autonomy is usable fuel divided by consumption at the relevant load, not tank label volume divided by an arbitrary average. Reserve, unusable volume, quality, delivery constraints and pump dependence matter. A large bulk tank is ineffective if the day-tank transfer pump has lost power. A fuel contract supports logistics but is not proof that deliveries remain possible during a regional disruption.

Generators also depend on starter batteries, controls, ventilation, exhaust, cooling and maintenance. Motor starting and UPS recharge can create demand beyond steady IT load. Sequence loads where the approved design requires it and confirm the generator's transient response. Parallel generators introduce synchronization, load sharing and protective coordination; adding engines alone does not prove fault tolerance.

Acceptance should measure the whole path: source event, UPS continuity, generator start, transfer, load acceptance, fuel delivery, alarms and controlled return. Record the operating load and environment. Exercise the response to a failed start or unavailable source through approved simulation or test methods. Operations must track readiness between tests, including inhibited automatic modes, depleted starting energy and overdue defects.

### Build a timed energy-bridge calculation
Assume detection and start command take 3 seconds, the engine reaches accepted source conditions after another 12 seconds, and transfer takes 2 seconds. The ideal sequential bridge is 17 seconds. If proven UPS support at the required load is 30 seconds, the nominal margin is 13 seconds. A second crank attempt taking 15 seconds would exceed that margin, so the stated failed-start requirement is not met by the ideal-sequence calculation.

Fuel duration is a separate calculation. A nominal 3000 L tank with 250 L unusable and 350 L reserved has 2400 L available for the mission. At a supported 300 L/h operating rate, the simple duration is eight hours. The claim still depends on fuel quality, pump power, filters, valves, ventilation and the actual load curve.

Acceptance observes the complete chain from source event to stable delivered load. Record timestamps for detection, crank, ready-to-transfer, switch movement and service response. A running engine is a useful intermediate state, not the final result. During return, confirm controlled retransfer, recharge demand, alarm restoration and automatic readiness for the next event.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A tank contains 2400 L, but 300 L is reserved and 100 L is unusable. Consumption at the design load is 250 L/h.

**Reasoning:** Usable operating fuel is 2000 L; calculated autonomy is eight hours. It remains conditional on the consumption curve and functioning fuel delivery.

#### Guided practice

The engine is running, but its breaker is open and the UPS is discharging. Has the service transfer succeeded?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** No. Engine operation is only one stage; the load has not received the generator source.

#### Independent task

Environment: analytical

Produce a timed source-loss sequence with fuel and auxiliary dependencies.

**Packaged starter material**

- course_labs/DCCA/README.md
- course_labs/DCCA/scenario.json
- course_labs/DCCA/answers-template.json

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Separate start success from load acceptance.
- Use usable fuel and relevant consumption.
- Include failed-start and return-to-normal evidence.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0101 · single · diagnosis**

A generator runs but its output breaker remains open while UPS batteries discharge. What is established?

Synthetic educational evidence; not field measurements.

Engine: running
Generator output breaker: open
UPS: on battery
Load transfer: not confirmed

1. Restored UPS reserve
2. Full fuel autonomy
3. Engine start only
4. Successful load transfer

**Correct option(s):** 3

- Option 1: Incorrect. The batteries are still discharging.
- Option 2: Incorrect. Runtime has not been demonstrated.
- Option 3: Correct. The load has not yet received generator power.
- Option 4: Incorrect. An open output path prevents that conclusion.

**DCCA-Q0102 · single · mechanism**

What distinguishes open-transition transfer?

1. Stored energy becomes unnecessary
2. Both sources always remain paralleled
3. No switching takes place
4. The first source disconnects before the second connects

**Correct option(s):** 4

- Option 1: Incorrect. The load may need ride-through during the gap.
- Option 2: Incorrect. That is not open transition.
- Option 3: Incorrect. A transfer changes the source path.
- Option 4: Correct. This avoids intentional source overlap.

**DCCA-Q0103 · single · calculation**

A tank has 1800 usable litres and consumption is 300 litres per hour. What is calculated autonomy?

Synthetic educational evidence; not field measurements.

Usable fuel: 1800 L
Consumption at required load: 300 L/h

1. 18 hours
2. 6 hours
3. 540000 hours
4. 0.167 hours

**Correct option(s):** 2

- Option 1: Incorrect. That does not follow from the supplied rate.
- Option 2: Correct. Usable fuel divided by hourly consumption gives duration.
- Option 3: Incorrect. Multiplying is dimensionally incorrect.
- Option 4: Incorrect. The ratio is reversed.

**DCCA-Q0104 · single · mechanism**

Why include the fuel transfer pump in a dependency map?

1. Stored bulk fuel may be unavailable without delivery
2. It changes server IP addresses
3. It guarantees unlimited reserve
4. It replaces all fuel filters

**Correct option(s):** 1

- Option 1: Correct. The engine needs fuel at its usable supply point.
- Option 2: Incorrect. The pump is a fuel-system component.
- Option 3: Incorrect. A pump does not create fuel.
- Option 4: Incorrect. Delivery and filtration are different functions.

**DCCA-Q0105 · single · mechanism**

Which demand can increase after a source outage ends?

1. Fiber polarity
2. Rack labels
3. UPS battery recharge
4. Floor area

**Correct option(s):** 3

- Option 1: Incorrect. Polarity does not create an electrical load step.
- Option 2: Incorrect. Labels do not consume meaningful generation capacity.
- Option 3: Correct. Replenishing stored energy adds source demand.
- Option 4: Incorrect. Area does not change at source restoration.

**DCCA-Q0106 · single · mechanism**

What makes a fuel-delivery contract insufficient as sole resilience evidence?

1. Engines run without fuel after starting
2. Regional access and supplier dependencies may still prevent delivery
3. Fuel never requires replenishment
4. Contracts cannot contain any useful terms

**Correct option(s):** 2

- Option 1: Incorrect. They require continuing energy input.
- Option 2: Correct. A contract does not demonstrate physical availability under disruption.
- Option 3: Incorrect. Finite tanks eventually deplete.
- Option 4: Incorrect. They can support preparedness.

**DCCA-Q0107 · single · mechanism**

What should a generator acceptance test include beyond starting?

1. A purchase order
2. Only no-load voltage after starting
3. Load-step response and delivery to the required loads
4. A network speed test alone

**Correct option(s):** 3

- Option 1: Incorrect. Procurement is not a load test.
- Option 2: Incorrect. No-load readiness does not demonstrate acceptance of the required demand.
- Option 3: Correct. The service depends on usable electrical output.
- Option 4: Incorrect. That does not exercise generation delivery.

**DCCA-Q0108 · single · mechanism**

Which auxiliary can prevent generator starting despite a full fuel tank?

1. A full spare-parts shelf
2. A printed floor map
3. Depleted starter battery
4. Correct cable labels

**Correct option(s):** 3

- Option 1: Incorrect. Spares do not prevent starting.
- Option 2: Incorrect. The map is not part of cranking energy.
- Option 3: Correct. Starting energy is a separate dependency.
- Option 4: Incorrect. Labels support work but do not inhibit starting.

**DCCA-Q0109 · single · mechanism**

Why is consumption measured at relevant load?

1. Consumption is identical at every load
2. Fuel use varies with operating demand
3. Load affects only Ethernet traffic
4. Only tank shape determines runtime

**Correct option(s):** 2

- Option 1: Incorrect. Engine behavior is load dependent.
- Option 2: Correct. An unrelated average can misstate autonomy.
- Option 3: Incorrect. Electrical generation demand affects the engine.
- Option 4: Incorrect. Usable fuel and rate both matter.

**DCCA-Q0110 · single · mechanism**

What is required for controlled generator paralleling?

1. Matching rated kW without synchronization
2. Any two closed breakers
3. Synchronization, sharing and appropriate protection
4. Identical asset labels

**Correct option(s):** 3

- Option 1: Incorrect. Equal capacity does not align voltage, frequency and phase.
- Option 2: Incorrect. Uncontrolled connection can be hazardous.
- Option 3: Correct. Parallel sources must operate compatibly.
- Option 4: Incorrect. Identity labels do not align source waveforms.

**DCCA-Q0111 · single · mechanism**

Which event marks successful transfer acceptance?

1. Required loads operate within limits on the alternate source
2. The engine sound changed
3. The alarm list was hidden
4. The start command was sent

**Correct option(s):** 1

- Option 1: Correct. This demonstrates delivered function.
- Option 2: Incorrect. Sound does not prove acceptable electrical output.
- Option 3: Incorrect. Hiding alarms changes no physical state.
- Option 4: Incorrect. A command is not confirmed response.

**DCCA-Q0112 · single · mechanism**

Why track automatic-mode inhibition?

1. It always increases fuel capacity
2. It reduces every load to zero
3. It changes the UPS chemistry
4. The generator may not respond to the next outage

**Correct option(s):** 4

- Option 1: Incorrect. Control mode does not add stored fuel.
- Option 2: Incorrect. IT loads may continue on utility.
- Option 3: Incorrect. The systems have separate functions.
- Option 4: Correct. A maintained engine can still be unavailable through control state.

**DCCA-Q0113 · single · mechanism**

A generator has 10 hours of fuel but cooling fails after 20 minutes. What limits service?

1. The cooling dependency
2. The advertised tank autonomy
3. The number of load circuits
4. The asset tag

**Correct option(s):** 1

- Option 1: Correct. Fuel alone does not define supported runtime.
- Option 2: Incorrect. The engine cannot ignore its cooling requirement.
- Option 3: Incorrect. The stated failure is in cooling.
- Option 4: Incorrect. Identification does not maintain temperature.

**DCCA-Q0114 · single · mechanism**

What must be considered when returning from generator to utility?

1. Deleting the outage record
2. Only the desire to save fuel
3. Source stability, permitted transfer and downstream response
4. Disabling every alarm permanently

**Correct option(s):** 3

- Option 1: Incorrect. The event record should remain.
- Option 2: Incorrect. Efficiency does not override transfer requirements.
- Option 3: Correct. Return is another controlled transition.
- Option 4: Incorrect. That removes useful protection and observation.

**DCCA-Q0115 · single · mechanism**

What does a closed-transition arrangement require that cannot be assumed casually?

1. An engineered and permitted source-paralleling scheme
2. A smaller room label
3. No synchronization consideration
4. Unlimited battery capacity

**Correct option(s):** 1

- Option 1: Correct. Brief overlap still connects sources together.
- Option 2: Incorrect. Labels do not provide interlocks.
- Option 3: Incorrect. Waveform compatibility remains relevant.
- Option 4: Incorrect. Storage is a separate constraint.

**DCCA-Q0116 · single · diagnosis**

Why can motor starting affect a generator?

Synthetic educational evidence; not field measurements.

Tank supports modeled 10 h fuel demand
Engine cooling is unavailable after 20 min

1. All motors start with zero current
2. Transient current demand can disturb voltage and frequency
3. Motors generate no electrical demand
4. Only room humidity matters

**Correct option(s):** 2

- Option 1: Incorrect. That is not a general property.
- Option 2: Correct. Steady-state kW alone misses the load step.
- Option 3: Incorrect. They draw energy to start and run.
- Option 4: Incorrect. Electrical transients are directly relevant.

**DCCA-Q0117 · single · mechanism**

Which test record best supports the transfer-time claim?

1. A manually recalled estimate
2. A fuel receipt
3. Time-correlated source, switch and load measurements
4. The controller's model number

**Correct option(s):** 3

- Option 1: Incorrect. Memory is weaker than synchronized measurements.
- Option 2: Incorrect. It does not record transfer timing.
- Option 3: Correct. The entire sequence must be observable.
- Option 4: Incorrect. A model is not the installed timing result.

**DCCA-Q0118 · single · mechanism**

Why distinguish reserved fuel from usable operating fuel?

1. Policy and physical limits constrain planned consumption
2. Tank labels always include all site policies
3. Reserve fuel increases burn rate automatically
4. Fuel quantities have no relationship to duration

**Correct option(s):** 1

- Option 1: Correct. Not all stored volume is available for the claimed mission.
- Option 2: Incorrect. Labels may state gross capacity only.
- Option 3: Incorrect. The distinction concerns available volume.
- Option 4: Incorrect. They are central to autonomy.

**DCCA-Q0119 · single · mechanism**

What is a load bank useful for?

1. Creating diesel fuel
2. Applying controlled electrical demand during testing
3. Replicating every application dependency
4. Replacing all protective relays

**Correct option(s):** 2

- Option 1: Incorrect. It consumes electrical energy.
- Option 2: Correct. It helps exercise source performance.
- Option 3: Incorrect. A load bank does not reproduce all IT service behavior.
- Option 4: Incorrect. Protection remains necessary.

**DCCA-Q0120 · single · mechanism**

Which recovery observation matters after a failed generator start?

1. A full tank reading without another start verification
2. Cause corrected and automatic readiness demonstrated
3. Ticket closed without testing
4. Alarm acknowledged only

**Correct option(s):** 2

- Option 1: Incorrect. Fuel availability does not prove the original start defect is resolved.
- Option 2: Correct. Clearing a fault alone may not restore readiness.
- Option 3: Incorrect. Administrative closure does not prove function.
- Option 4: Incorrect. Acknowledgment is not repair.

#### Recall

**A generator runs but its output breaker remains open while UPS batteries discharge. What is established?**

Engine start only Correct. The load has not yet received generator power.

**What distinguishes open-transition transfer?**

The first source disconnects before the second connects Correct. This avoids intentional source overlap.

**A tank has 1800 usable litres and consumption is 300 litres per hour. What is calculated autonomy?**

6 hours Correct. Usable fuel divided by hourly consumption gives duration.

**Why include the fuel transfer pump in a dependency map?**

Stored bulk fuel may be unavailable without delivery Correct. The engine needs fuel at its usable supply point.

**Which demand can increase after a source outage ends?**

UPS battery recharge Correct. Replenishing stored energy adds source demand.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DCCA-M07 — Redundancy, independence and maintainability

### DCCA-L07 — Redundancy, independence and maintainability

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L06

Redundancy provides additional capacity or alternatives. Independence describes whether alternatives avoid the same failure causes. Resilience is broader: the service must tolerate disturbance, operate within agreed degraded limits and recover. These ideas are related but cannot be substituted for one another.

Let N be the capacity required for a specified load and state. N+1 adds one unit of the chosen capacity increment. Two complete N paths are often described as 2N. The notation must identify its boundary: 2N UPS equipment can still depend on one upstream switchboard or a shared downstream bus. A design claim about the whole facility cannot be inferred from a component label.

Calculate remaining capacity after the specified outage or maintenance action. Four 100 kW cooling units supporting 250 kW have enough nominal capacity with one unavailable, but two unavailable leave only 200 kW. Then check delivery: valves, ducts, controls, power and hydraulic conditions may prevent the remaining units from delivering their nameplate output where needed.

Concurrent maintainability means a defined maintenance intervention can occur while the required service continues. Fault tolerance adds a specified unplanned fault requirement. The exact terms and certification rules depend on the chosen standard; do not assign an official facility rating from this app's simple arithmetic. Maintenance itself can create a more vulnerable state, so specify which additional failures are tolerated during that window.

Failure-domain analysis traces shared utilities, rooms, routes, control systems, firmware, operating procedures and people. Two fibers in one tray can be cut together. Two cooling loops sharing a controller can receive the same wrong command. Two feeds handled by one unreviewed procedure can be misconfigured together. Diversity can reduce some common causes but introduces complexity, spares and training costs.

Acceptance combines topology review, state analysis and controlled tests. Record what was isolated, remaining capacity, service performance, protective interlocks and restoration. An N+1 claim has practical value only when the additional unit is ready, maintainable and connected to a functioning delivery path.

### Make the required state set explicit
Consider four identical 100 kW units and a 260 kW load. With all units available, nominal margin is 140 kW. With one unavailable, margin is 40 kW. With two unavailable, there is a 60 kW deficit. Saying N+1 is therefore compatible with one-unit loss in this simple model, but says nothing about maintenance plus another failure unless that combined state is included.

Now add a shared controller and one common supply valve. Losing either may prevent all four units from delivering output. Capacity arithmetic and dependency analysis answer different questions and both are necessary. A design change can add controller independence yet retain the valve, so improvements should be recorded by failure mode rather than by a vague resilience score.

For each state, list the unavailable items, available delivery capacity, load, service limit, permitted duration and recovery action. Test only through authorized safe methods and label simulated states. At restoration, verify the final valve, mode and alarm settings; an otherwise successful test can leave the system with less reserve than it had initially.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. Four 100 kW units serve 250 kW. One is isolated for maintenance and another is unavailable through a fault.

**Reasoning:** Only 200 kW remains, so the combined state cannot support the full stated load. The normal N+1 claim does not establish tolerance of maintenance plus another failure.

#### Guided practice

Two UPS systems have separate input breakers but share one bypass bus. Identify the shared failure domain.

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** The bypass bus is common; analyze whether its fault or maintenance can affect both supported paths in each mode.

#### Independent task

Environment: analytical

Create a state table for a dual-feed rack and its upstream dependencies.

**Packaged starter material**

- course_labs/DCCA/README.md
- course_labs/DCCA/scenario.json
- course_labs/DCCA/answers-template.json

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Check normal, each single failure, maintenance and stated combined conditions.
- Separate equipment count from delivery-path independence.
- Do not assign a provider facility rating from simplified models.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0121 · single · mechanism**

What does N denote in an N+1 capacity statement?

1. Every installed unit regardless of need
2. Capacity required for the specified load and state
3. Annual energy consumption
4. Number of network users

**Correct option(s):** 2

- Option 1: Incorrect. N is the requirement, not automatically the installed total.
- Option 2: Correct. The reference condition must be defined.
- Option 3: Incorrect. Capacity count is not energy.
- Option 4: Incorrect. That is unrelated to redundancy notation here.

**DCCA-Q0122 · single · calculation**

Four 100 kW units support 250 kW. With two unavailable, what is the deficit?

Synthetic educational evidence; not field measurements.

Units: 4 × 100 kW
Demand: 250 kW
Unavailable units: 2

1. 150 kW
2. 250 kW
3. 50 kW
4. Zero

**Correct option(s):** 3

- Option 1: Incorrect. That does not match remaining capacity.
- Option 2: Incorrect. Some capacity remains.
- Option 3: Correct. 200 kW remains against 250 kW demand.
- Option 4: Incorrect. The remaining two units cannot meet the load.

**DCCA-Q0123 · single · mechanism**

Two fibers share one conduit. Which event challenges their independence?

1. A single fiber transmitter fails independently
2. One hostname changes
3. One transceiver is replaced
4. One excavation severs the conduit

**Correct option(s):** 4

- Option 1: Incorrect. That normally affects its own optical path rather than both fibers in the conduit.
- Option 2: Incorrect. Naming does not sever the route.
- Option 3: Incorrect. That may affect only its individual link.
- Option 4: Correct. The same physical event can affect both.

**DCCA-Q0124 · single · mechanism**

What does concurrent maintainability concern?

1. Avoiding all maintenance forever
2. Installing the most expensive equipment
3. Performing defined maintenance while required service continues
4. Guaranteeing every possible simultaneous fault

**Correct option(s):** 3

- Option 1: Incorrect. Maintainability assumes maintenance is needed.
- Option 2: Incorrect. Price does not prove the property.
- Option 3: Correct. The maintenance state must preserve the agreed function.
- Option 4: Incorrect. That is a broader unsupported claim.

**DCCA-Q0125 · single · diagnosis**

Why is a 2N UPS label insufficient to rate a whole facility?

Synthetic educational evidence; not field measurements.

Supplier label: 2N UPS
Upstream and cooling independence: not established

1. Other shared dependencies can remain
2. All 2N designs are identical
3. Cooling never affects IT service
4. UPS ratings never matter

**Correct option(s):** 1

- Option 1: Correct. The UPS boundary is narrower than the facility.
- Option 2: Incorrect. Implementation and boundaries differ.
- Option 3: Incorrect. Heat removal is essential.
- Option 4: Incorrect. They matter within their defined scope.

**DCCA-Q0126 · single · mechanism**

Which pair best illustrates a common control dependency?

1. Two racks on different floors
2. Two pumps commanded by one failed controller
3. Two different cable labels
4. Two pumps with separate asset numbers

**Correct option(s):** 2

- Option 1: Incorrect. Location alone does not identify the controller.
- Option 2: Correct. One control fault can affect both.
- Option 3: Incorrect. Labels do not define control authority.
- Option 4: Incorrect. Unique numbers do not establish a shared control fault.

**DCCA-Q0127 · single · diagnosis**

What must be checked after remaining-capacity arithmetic passes?

Synthetic educational evidence; not field measurements.

Remaining nameplate capacity: sufficient
Delivery valves, ducts, controls and power paths: not yet verified

1. Only the total installed count before maintenance
2. Only the room name
3. Only whether all equipment has matching nameplates
4. Whether the capacity can be delivered through surviving paths

**Correct option(s):** 4

- Option 1: Incorrect. Available delivery after the specified loss is the relevant state.
- Option 2: Incorrect. Naming does not verify delivery.
- Option 3: Incorrect. Matching ratings do not prove the surviving distribution path delivers capacity.
- Option 4: Correct. Valves, ducts and controls can still block delivery.

**DCCA-Q0128 · single · mechanism**

During maintenance one protective path is unavailable. What should be explicit?

1. Which additional failures remain tolerable
2. A claim that risk cannot change
3. Automatic indefinite extension of the window
4. An assumption that all alarms are irrelevant

**Correct option(s):** 1

- Option 1: Correct. The risk envelope changes in the maintenance state.
- Option 2: Incorrect. Removing a path can increase vulnerability.
- Option 3: Incorrect. Duration requires controlled acceptance.
- Option 4: Incorrect. Alarms can become more critical.

**DCCA-Q0129 · single · mechanism**

Which observation invalidates an operational N+1 claim?

1. The load is below its design maximum
2. The spare unit is locked out and cannot start
3. The duty units are monitored
4. The spare has a different serial number

**Correct option(s):** 2

- Option 1: Incorrect. That can provide headroom.
- Option 2: Correct. Installed but unavailable capacity is not ready reserve.
- Option 3: Incorrect. Monitoring supports operation.
- Option 4: Incorrect. That is normal identity information.

**DCCA-Q0130 · single · mechanism**

Why can diversity increase operating complexity?

1. Spare parts become unnecessary
2. Different equipment needs different procedures, skills and spares
3. Diversity always removes every fault
4. All diverse products use identical procedures

**Correct option(s):** 2

- Option 1: Incorrect. More variants may require more spares.
- Option 2: Correct. Common-cause reduction has lifecycle costs.
- Option 3: Incorrect. It cannot guarantee that.
- Option 4: Incorrect. Differences can be significant.

**DCCA-Q0131 · single · mechanism**

Which evidence supports physical route diversity?

1. Verified routes and shared-risk review
2. Two identical invoices
3. Two IP addresses
4. Two interface names

**Correct option(s):** 1

- Option 1: Correct. Logical interfaces alone do not reveal common trenches.
- Option 2: Incorrect. Procurement records do not show as-built routes.
- Option 3: Incorrect. Addressing does not prove route separation.
- Option 4: Incorrect. Names can sit on one physical route.

**DCCA-Q0132 · single · mechanism**

What distinguishes redundancy from resilience?

1. They are exact synonyms in all contexts
2. Resilience means no faults can occur
3. Redundancy includes every human process automatically
4. Resilience includes degraded operation and recovery

**Correct option(s):** 4

- Option 1: Incorrect. Their scopes differ.
- Option 2: Incorrect. It concerns response to disturbance.
- Option 3: Incorrect. Equipment count does not ensure processes.
- Option 4: Correct. Extra components are only one possible mechanism.

**DCCA-Q0133 · single · mechanism**

A dual-cord server has each cord on a different rack PDU, but both PDUs share one branch. What is missing?

1. More blanking panels
2. A larger monitor
3. A second server hostname
4. Independent upstream supply paths

**Correct option(s):** 4

- Option 1: Incorrect. Airflow management does not separate feeds.
- Option 2: Incorrect. Display size does not add independence.
- Option 3: Incorrect. Naming does not alter power topology.
- Option 4: Correct. Separate strips still share one branch.

**DCCA-Q0134 · single · mechanism**

What should an isolation test record?

1. The sales proposal alone
2. Actual isolated component and observed service limits
3. Only the technician's arrival time
4. Only the test title

**Correct option(s):** 2

- Option 1: Incorrect. A proposal is design intent rather than test evidence.
- Option 2: Correct. The result must connect stimulus to delivered function.
- Option 3: Incorrect. That omits system behavior.
- Option 4: Incorrect. A title does not show what happened.

**DCCA-Q0135 · single · mechanism**

Which statement about fault tolerance is defensible?

1. It guarantees survival of all imaginable events
2. It removes the need for recovery planning
3. It is determined by rack count
4. It applies to a specified fault set and operating envelope

**Correct option(s):** 4

- Option 1: Incorrect. That is not supportable.
- Option 2: Incorrect. Recovery remains necessary.
- Option 3: Incorrect. Rack count alone does not establish tolerance.
- Option 4: Correct. No finite design claim should silently mean every event.

**DCCA-Q0136 · single · mechanism**

Two otherwise separate paths receive the same erroneous bulk configuration. What caused the joint failure?

1. Independent asset labels
2. Different IP subnets
3. A shared change process or automation authority
4. Too many spare cables

**Correct option(s):** 3

- Option 1: Incorrect. Labels did not prevent shared control.
- Option 2: Incorrect. Subnet separation does not explain the common command.
- Option 3: Correct. Logical independence can be defeated operationally.
- Option 4: Incorrect. The event is not caused by spare count.

**DCCA-Q0137 · single · mechanism**

How should capacity be expressed when one unit is already failed?

1. Use the effective available state
2. Continue using all installed nameplates
3. Report only purchase cost
4. Assume immediate repair without evidence

**Correct option(s):** 1

- Option 1: Correct. The current configuration differs from the nominal design.
- Option 2: Incorrect. Unavailable equipment cannot deliver capacity.
- Option 3: Incorrect. Cost does not establish available output.
- Option 4: Incorrect. Repair time and readiness must be known.

**DCCA-Q0138 · single · mechanism**

What does a shared room create for two redundant systems?

1. Automatic network isolation
2. Guaranteed independent failure
3. Unlimited maintenance access
4. Potential common environmental exposure

**Correct option(s):** 4

- Option 1: Incorrect. Physical room sharing says nothing about traffic policy.
- Option 2: Incorrect. Co-location can correlate failures.
- Option 3: Incorrect. Access can be constrained.
- Option 4: Correct. Fire, water or heat can affect both.

**DCCA-Q0139 · single · mechanism**

Why rehearse restoration after redundancy testing?

1. Restoration is always automatic
2. The initial test result proves every final switch position
3. Records should be deleted after success
4. A successful failure test can leave an unintended degraded state

**Correct option(s):** 4

- Option 1: Incorrect. Some states need controlled action.
- Option 2: Incorrect. It does not.
- Option 3: Incorrect. Records support future assurance.
- Option 4: Correct. The normal configuration must be verified again.

**DCCA-Q0140 · single · mechanism**

What is the best response to a redundancy claim with no stated boundary?

1. Convert it directly to an uptime percentage
2. Accept it as whole-facility fault tolerance
3. Reject all redundant designs
4. Ask which service, components and failure states it covers

**Correct option(s):** 4

- Option 1: Incorrect. A topology label is not observed availability.
- Option 2: Incorrect. That overextends the statement.
- Option 3: Incorrect. The issue is missing definition.
- Option 4: Correct. The claim cannot be evaluated without scope.

#### Recall

**What does N denote in an N+1 capacity statement?**

Capacity required for the specified load and state Correct. The reference condition must be defined.

**Four 100 kW units support 250 kW. With two unavailable, what is the deficit?**

50 kW Correct. 200 kW remains against 250 kW demand.

**Two fibers share one conduit. Which event challenges their independence?**

One excavation severs the conduit Correct. The same physical event can affect both.

**What does concurrent maintainability concern?**

Performing defined maintenance while required service continues Correct. The maintenance state must preserve the agreed function.

**Why is a 2N UPS label insufficient to rate a whole facility?**

Other shared dependencies can remain Correct. The UPS boundary is narrower than the facility.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DCCA-M08 — Heat balance and sensible cooling

### DCCA-L08 — Heat balance and sensible cooling

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L07

Most electrical energy consumed by IT equipment becomes heat inside the facility boundary. Cooling does not destroy that heat; it transports it from the equipment to another location. Begin with a boundary diagram showing the heat source, transfer medium, heat exchanger and final sink. Server fans, room units, pumps and outdoor rejection equipment each move or transform energy and add their own losses.

A simple steady sensible-heat balance is Q = mass_flow × specific_heat × temperature_rise. For air, mass flow equals density times volumetric flow. With consistent SI units, kg/s multiplied by kJ/(kg·K) and K gives kW. The air properties used in a calculation must be stated; altitude and temperature affect density. A larger temperature difference can reduce the airflow needed for the same sensible load, but equipment inlet limits and heat-transfer behavior constrain the usable range.

Sensible cooling lowers temperature without intentionally changing moisture content. Latent cooling removes moisture through condensation. A unit's total cooling rating is therefore not automatically its usable sensible capacity. The sensible heat ratio is sensible capacity divided by total capacity under stated conditions. Data-center IT loads are predominantly sensible, while outside air and people can introduce moisture loads.

The refrigeration cycle moves heat using a working fluid. At a foundation level, the evaporator absorbs heat, the compressor raises pressure, the condenser rejects heat and the expansion device reduces pressure. Chilled-water systems transport cooling between the plant and air-handling equipment. A CRAC commonly incorporates direct-expansion refrigeration; a CRAH commonly uses a chilled-water coil, though actual product terminology should be verified.

Cooling capacity and airflow are different constraints. A room unit may have enough nominal kW yet fail to deliver air to a blocked rack inlet. Conversely, fans can circulate large air volumes without enough heat rejection. Commissioning must check inlet conditions across racks, load distribution, control response, flow and the surviving capacity under specified failures. Do not use room-average temperature as the only protection criterion.

### Calculate heat transport and distinguish bottlenecks
For air with assumed density 1.2 kg/m³ and heat capacity 1.005 kJ/(kg·K), a 24 kW load with a 12 K rise needs 24/(1.2×1.005×12)=1.658 m³/s. If actual flow is only 1.0 m³/s, the ideal required rise becomes 24/(1.2×1.005)=19.90 K. That does not prove a particular inlet temperature, but it reveals the consequence of inadequate mass flow under the stated balance.

A second bottleneck can sit at the coil or final sink. If the air reaches the coil correctly but chilled-water flow is insufficient, the supply temperature can rise. If the coil works but outdoor rejection is unavailable, the circulating system accumulates heat. Follow the energy through every exchanger rather than treating the room unit as the final destination.

When diagnosing a hotspot, compare load, local inlet and exhaust temperatures, air delivery, coil conditions and plant state. Do not lower the supply setpoint first by habit. A blocked rack path may need an airflow correction; a plant-capacity problem needs a different response. The measurements should distinguish those hypotheses.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. Air density is assumed 1.2 kg/m³ and specific heat 1.0 kJ/(kg·K). A 12 kW rack permits a 10 K rise.

**Reasoning:** Required ideal airflow is 12/(1.2×1.0×10) = 1 m³/s. This is a heat-balance result, not proof that the rack’s actual pressure path delivers that flow.

#### Guided practice

A cooling unit is rated 100 kW total with SHR 0.8. What sensible capacity is available at that rating point?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** 80 kW sensible. The remaining 20 kW is latent capacity under the stated conditions.

#### Independent task

Environment: analytical

Build a rack heat-flow diagram and calculate air demand with explicit properties.

**Packaged starter material**

- course_labs/DCCA/README.md
- course_labs/DCCA/scenario.json
- course_labs/DCCA/answers-template.json

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Use consistent units.
- Separate sensible and total capacity.
- Include airflow delivery and inlet measurements in acceptance.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0141 · single · mechanism**

What happens to most IT electrical input within the room boundary?

1. It cancels the cooling load
2. It becomes heat that must be removed
3. It is permanently stored as data
4. It leaves only as visible light

**Correct option(s):** 2

- Option 1: Incorrect. Electrical consumption creates thermal demand.
- Option 2: Correct. Computation does not make the energy disappear.
- Option 3: Incorrect. Data storage does not absorb the full energy indefinitely.
- Option 4: Incorrect. That is not the main energy path.

**DCCA-Q0142 · single · mechanism**

Which equation describes steady sensible heat transfer?

1. Q equals floor height times rack count
2. Q equals humidity divided by area
3. Q equals voltage divided by current
4. Q equals mass flow times specific heat times temperature rise

**Correct option(s):** 4

- Option 1: Incorrect. Geometry alone does not determine heat transfer.
- Option 2: Incorrect. The dimensions do not give heat rate.
- Option 3: Incorrect. That is not a thermal power balance.
- Option 4: Correct. This is the sensible energy balance.

**DCCA-Q0143 · single · calculation**

A 100 kW unit has SHR 0.8 at its rating point. What sensible capacity is rated?

Synthetic educational evidence; not field measurements.

Cooling total capacity: 100 kW
Sensible heat ratio at rating point: 0.80

1. 80 kW
2. 100 kW
3. 20 kW
4. 125 kW

**Correct option(s):** 1

- Option 1: Correct. Sensible capacity is total capacity times SHR.
- Option 2: Incorrect. This assumes SHR equals one.
- Option 3: Incorrect. That is the latent portion.
- Option 4: Incorrect. Dividing reverses the ratio.

**DCCA-Q0144 · single · mechanism**

What does latent cooling remove?

1. Electrical harmonics
2. Only dry-bulb temperature without moisture change
3. Network delay
4. Moisture through condensation

**Correct option(s):** 4

- Option 1: Incorrect. Those are power-quality phenomena.
- Option 2: Incorrect. That describes sensible cooling.
- Option 3: Incorrect. Cooling is not a packet-timing mechanism.
- Option 4: Correct. Latent heat accompanies the moisture phase change.

**DCCA-Q0145 · single · mechanism**

What is the evaporator's basic refrigeration role?

1. Absorb heat from the cooled side
2. Reject all heat outdoors
3. Generate electrical energy
4. Store application data

**Correct option(s):** 1

- Option 1: Correct. The working fluid receives heat there.
- Option 2: Incorrect. That is the condenser-side role.
- Option 3: Incorrect. The cycle consumes work to move heat.
- Option 4: Incorrect. That is unrelated.

**DCCA-Q0146 · single · calculation**

Why can sufficient cooling kW still leave a hot rack?

1. Heat balance never applies
2. Room units eliminate all recirculation
3. Air may not reach the required inlet
4. Every rack receives equal airflow automatically

**Correct option(s):** 3

- Option 1: Incorrect. The balance still applies to actual flow.
- Option 2: Incorrect. Air can bypass or recirculate.
- Option 3: Correct. Capacity and delivery are separate constraints.
- Option 4: Incorrect. Distribution depends on pressure and obstructions.

**DCCA-Q0147 · single · calculation**

Using air density 1.2 kg/m³ and specific heat 1 kJ/kg·K, what flow removes 12 kW at a 10 K rise?

Synthetic educational evidence; not field measurements.

Air density: 1.2 kg/m³
Air cp: 1.0 kJ/(kg·K)
Heat: 12 kW
Temperature rise: 10 K

1. 120 m³/s
2. 1 m³/s
3. 12 m³/s
4. 0.1 m³/s

**Correct option(s):** 2

- Option 1: Incorrect. The relationship was inverted.
- Option 2: Correct. 12 divided by 1.2 times 10 equals one.
- Option 3: Incorrect. The temperature and density terms were omitted.
- Option 4: Incorrect. That is ten times too low.

**DCCA-Q0148 · single · mechanism**

What does a condenser do?

1. Eliminate the need for a heat sink
2. Convert all heat directly into data
3. Reject absorbed heat plus compressor work
4. Absorb heat only from the IT inlet

**Correct option(s):** 3

- Option 1: Incorrect. Heat must still be rejected.
- Option 2: Incorrect. No such function exists.
- Option 3: Correct. The hot side must dispose of both contributions.
- Option 4: Incorrect. That is the cooled-side function.

**DCCA-Q0149 · single · mechanism**

Why state air density in a flow calculation?

1. Volumetric flow must be converted to mass flow
2. All sites have exactly the same density
3. Density determines server IP addresses
4. Density is measured in kW

**Correct option(s):** 1

- Option 1: Correct. Density links volume to transported mass.
- Option 2: Incorrect. Altitude and temperature can alter it.
- Option 3: Incorrect. It is a physical property.
- Option 4: Incorrect. It is mass per volume.

**DCCA-Q0150 · single · mechanism**

What commonly distinguishes a CRAH from a direct-expansion CRAC?

1. A CRAH commonly uses a chilled-water coil
2. Both always have identical refrigerant circuits
3. A CRAH never moves air
4. A CRAC is only a rack label

**Correct option(s):** 1

- Option 1: Correct. Actual equipment configuration must still be verified.
- Option 2: Incorrect. Their heat-transfer arrangements can differ.
- Option 3: Incorrect. Air handling is its function.
- Option 4: Incorrect. It is cooling equipment.

**DCCA-Q0151 · single · mechanism**

Why monitor rack inlets rather than only room average?

1. All room points have identical temperature
2. Inlet conditions do not affect servers
3. Local recirculation can create inlet hotspots
4. Averaging proves every rack is safe

**Correct option(s):** 3

- Option 1: Incorrect. Air paths create variation.
- Option 2: Incorrect. They directly affect cooling capability.
- Option 3: Correct. An average can conceal local violations.
- Option 4: Incorrect. It does not bound individual values.

**DCCA-Q0152 · single · mechanism**

For unchanged heat load, doubling temperature rise in an ideal balance does what to required mass flow?

1. Doubles it
2. Quadruples it
3. Halves it
4. Leaves it unchanged

**Correct option(s):** 3

- Option 1: Incorrect. That reverses the relationship.
- Option 2: Incorrect. No squared dependence is present.
- Option 3: Correct. Flow is inversely proportional to temperature rise.
- Option 4: Incorrect. Temperature rise is a term in the balance.

**DCCA-Q0153 · single · mechanism**

What does the compressor add to a refrigeration system?

1. A second utility source
2. Work that raises refrigerant pressure
3. Free cooling without energy input
4. Battery capacity

**Correct option(s):** 2

- Option 1: Incorrect. It does not provide electrical independence.
- Option 2: Correct. This enables heat rejection at the hot side.
- Option 3: Incorrect. Compression requires work.
- Option 4: Incorrect. It is not an electrical storage device.

**DCCA-Q0154 · single · mechanism**

A unit moves air but its heat-rejection path is unavailable. What is the likely limitation?

1. Automatic source redundancy
2. Reduced IT heat generation to zero
3. Unlimited cooling because fans rotate
4. Air circulation without sustained heat removal

**Correct option(s):** 4

- Option 1: Incorrect. Cooling behavior does not create power paths.
- Option 2: Incorrect. IT continues consuming power.
- Option 3: Incorrect. Fan motion is not proof of heat rejection.
- Option 4: Correct. Moving warm air alone does not reject heat.

**DCCA-Q0155 · single · mechanism**

What does kJ/(kg·K) describe?

1. Specific heat capacity
2. Volumetric airflow
3. Electrical apparent power
4. Relative humidity

**Correct option(s):** 1

- Option 1: Correct. It relates energy to mass and temperature change.
- Option 2: Incorrect. That uses volume per time.
- Option 3: Incorrect. That is measured in VA.
- Option 4: Incorrect. That is a ratio commonly expressed as percent.

**DCCA-Q0156 · single · mechanism**

Why separate indoor and outdoor thermal boundaries?

1. Heat must pass through the complete chain to a sink
2. The indoor coil rating proves outdoor rejection under every condition
3. Outdoor conditions never matter
4. The boundary removes energy conservation

**Correct option(s):** 1

- Option 1: Correct. A working room coil alone is insufficient.
- Option 2: Incorrect. The final sink can limit performance even when the room coil is adequate.
- Option 3: Incorrect. They affect rejection performance.
- Option 4: Incorrect. Conservation still applies.

**DCCA-Q0157 · single · mechanism**

Which observation supports delivered cooling capacity?

1. Stable inlet conditions at stated load with measured flows
2. The room's square meters
3. A cooling-unit brochure alone
4. A fan run command

**Correct option(s):** 1

- Option 1: Correct. It connects equipment output to the required function.
- Option 2: Incorrect. Area does not prove heat removal.
- Option 3: Incorrect. That is a rating under specified conditions.
- Option 4: Incorrect. Commanded operation is not measured performance.

**DCCA-Q0158 · single · mechanism**

What is the sensible heat ratio?

1. Sensible capacity divided by total capacity
2. Cooling cost divided by rent
3. Total capacity divided by electrical voltage
4. Humidity divided by temperature

**Correct option(s):** 1

- Option 1: Correct. It separates temperature-related capacity from the total.
- Option 2: Incorrect. That is a financial ratio.
- Option 3: Incorrect. That has unrelated dimensions.
- Option 4: Incorrect. That is not SHR.

**DCCA-Q0159 · single · mechanism**

Why does a failure-state cooling test need a stated IT load?

1. Every test must use zero load
2. The result depends on heat demand
3. Stating load removes the need for measurements
4. Load never affects room temperature

**Correct option(s):** 2

- Option 1: Incorrect. That cannot demonstrate loaded performance.
- Option 2: Correct. Passing at light load does not prove peak-load support.
- Option 3: Incorrect. Actual response still must be observed.
- Option 4: Incorrect. Electrical demand becomes heat.

**DCCA-Q0160 · single · mechanism**

What is the expansion device's broad function?

1. Raise all room air pressure
2. Increase fiber bandwidth
3. Reduce refrigerant pressure before the evaporator
4. Store diesel fuel

**Correct option(s):** 3

- Option 1: Incorrect. Its role is in the refrigerant circuit.
- Option 2: Incorrect. It has no network role.
- Option 3: Correct. It supports the low-pressure heat-absorption side.
- Option 4: Incorrect. That belongs to generation.

#### Recall

**What happens to most IT electrical input within the room boundary?**

It becomes heat that must be removed Correct. Computation does not make the energy disappear.

**Which equation describes steady sensible heat transfer?**

Q equals mass flow times specific heat times temperature rise Correct. This is the sensible energy balance.

**A 100 kW unit has SHR 0.8 at its rating point. What sensible capacity is rated?**

80 kW Correct. Sensible capacity is total capacity times SHR.

**What does latent cooling remove?**

Moisture through condensation Correct. Latent heat accompanies the moisture phase change.

**What is the evaporator's basic refrigeration role?**

Absorb heat from the cooled side Correct. The working fluid receives heat there.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DCCA-M09 — Air paths, containment and rack inlet conditions

### DCCA-L09 — Air paths, containment and rack inlet conditions

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L08

IT fans pull air through a resistance network: rack doors, equipment passages, filters, cables and room supply/return paths. Air follows pressure differences rather than colored floor plans. Hot-aisle/cold-aisle layout aligns equipment inlets with supply air and exhausts with return paths. Containment reduces mixing, but its effectiveness depends on doors, gaps, penetrations and the interaction with fire protection and access requirements.

Bypass occurs when supply air reaches the return without cooling IT. Recirculation occurs when exhaust re-enters equipment inlets. Both can coexist. Empty rack spaces, missing side seals and unsealed cable openings create paths that defeat intended separation. Blanking panels block unused rack positions, but must not obstruct equipment ventilation. Cable management preserves service access and prevents exhaust blockage.

A raised floor can act as a supply plenum. Tile placement and open area affect local delivery, while underfloor obstructions and leakage alter pressure distribution. Adding perforated tiles everywhere can reduce pressure and worsen airflow at critical racks. In a hard-floor arrangement, overhead or in-row delivery can provide the same basic supply/return separation by different means.

Measure inlet temperatures at representative heights and locations; high-density racks may exhibit vertical gradients. Pair measurements with workload, fan states and room-unit conditions. A cool sensor near a supply outlet cannot prove a remote server inlet is acceptable. Instrument placement must answer the acceptance question, not simply be convenient.

Control should avoid fighting loops. Excessively cold supply can increase energy use and condensation risk; excessive fan flow can increase power and bypass. The correct setting depends on equipment limits, allowable environmental envelope and measured distribution. Adjust under change control, in small justified steps, and retain rollback thresholds. Acceptance means all required inlets stay within the selected limits during normal operation and the specified failure states, not that a room average looks favorable.

### Use a temperature map to test an airflow hypothesis
A rack inlet map reads 23°C at the bottom, 27°C in the middle and 33°C at the top. The return air is 37°C and the supply is 20°C. These values suggest that the upper inlet receives a mixture, but they do not identify the exact leak. Inspect empty U-spaces, side gaps, door orientation and neighboring exhaust paths before selecting the correction.

Suppose approved blanking reduces the upper inlet to 26°C under the same workload. That is useful evidence for the corrected path. Check adjacent racks and room-unit behavior as well: redirected air can change pressures elsewhere. Record the before/after load and fan conditions so a workload reduction is not mistaken for an airflow improvement.

A simple mixing estimate can help explain the mechanism. Ignoring other heat exchange, equal mass flows of 20°C supply and 36°C exhaust mix to about 28°C. Reducing the exhaust fraction lowers inlet temperature without lowering the supply temperature. The model is illustrative; actual flow fractions require measurement or a validated model.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A rack’s bottom inlet is 22°C, middle inlet 25°C and top inlet 34°C while room average is 24°C. Empty upper U-spaces lack blanking panels.

**Reasoning:** The vertical pattern is consistent with local recirculation but is not proof of a single cause. Inspect airflow paths, install approved blanking and seals, then compare inlet measurements under the same load.

#### Guided practice

A team proposes opening every floor tile to fix one hotspot. What should be checked first?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** Plenum pressure, intended delivery and the hotspot path. More openings can reduce delivery elsewhere and increase bypass.

#### Independent task

Environment: analytical

Diagnose a synthetic inlet-temperature map and design a reversible airflow correction.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Distinguish bypass from recirculation.
- Select sensor locations relevant to IT inlets.
- Validate all affected racks after the change.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0161 · single · mechanism**

What is airflow bypass?

1. Exhaust enters equipment inlets
2. Water flows through a CDU
3. Supply air returns without cooling the intended IT load
4. A UPS uses maintenance bypass

**Correct option(s):** 3

- Option 1: Incorrect. That is recirculation.
- Option 2: Incorrect. That is a liquid path.
- Option 3: Correct. The air avoids useful heat pickup.
- Option 4: Incorrect. That is an electrical mode.

**DCCA-Q0162 · single · mechanism**

What is hot-air recirculation?

1. Supply reaches return without load contact
2. A battery recharges
3. A generator transfers source
4. Exhaust re-enters IT inlets

**Correct option(s):** 4

- Option 1: Incorrect. That is bypass.
- Option 2: Incorrect. That is electrical storage recovery.
- Option 3: Incorrect. That is power switching.
- Option 4: Correct. This raises inlet temperature.

**DCCA-Q0163 · single · mechanism**

Why install blanking panels in unused rack positions?

1. Reduce unintended air paths between front and rear
2. Replace every server fan
3. Increase electrical branch capacity
4. Guarantee all cooling failures are harmless

**Correct option(s):** 1

- Option 1: Correct. They help maintain separation.
- Option 2: Incorrect. Equipment still needs designed airflow.
- Option 3: Incorrect. Panels do not change circuit ratings.
- Option 4: Incorrect. Panels cannot provide unlimited heat removal.

**DCCA-Q0164 · single · calculation**

A room averages 24°C but a top server inlet is 34°C. Which reading governs that server's inlet assessment?

Synthetic educational evidence; not field measurements.

Room average: 24°C
Top server inlet: 34°C
Acceptance applies at the equipment inlet.

1. Only the room average
2. Yesterday's setpoint
3. The lowest room reading
4. The local 34°C reading against its specified limit

**Correct option(s):** 4

- Option 1: Incorrect. That conceals the hotspot.
- Option 2: Incorrect. A command is not current measured state.
- Option 3: Incorrect. That is not the server inlet.
- Option 4: Correct. An average cannot erase a local condition.

**DCCA-Q0165 · single · mechanism**

Why can adding many perforated tiles worsen cooling?

1. Every tile has identical flow regardless of pressure
2. More openings always eliminate bypass
3. Tiles always create cold energy
4. It can reduce plenum pressure and divert flow

**Correct option(s):** 4

- Option 1: Incorrect. Flow depends on pressure and resistance.
- Option 2: Incorrect. They can increase bypass.
- Option 3: Incorrect. They distribute air rather than generate cooling.
- Option 4: Correct. Air distribution is a coupled pressure system.

**DCCA-Q0166 · single · mechanism**

What does hot-aisle/cold-aisle layout align?

1. All sensors at one doorway
2. All power cords onto one feed
3. Equipment inlets and exhausts into separated air paths
4. All rack rear doors toward supply

**Correct option(s):** 3

- Option 1: Incorrect. That does not establish inlet coverage.
- Option 2: Incorrect. Electrical source placement is separate.
- Option 3: Correct. Orientation supports useful flow.
- Option 4: Incorrect. Rear exhaust orientation would conflict for typical front-to-back servers.

**DCCA-Q0167 · single · mechanism**

Which obstruction can impair rack cooling?

1. An unused dashboard page
2. Dense cabling across the exhaust path
3. A separate source-tracing table
4. A correctly placed asset label

**Correct option(s):** 2

- Option 1: Incorrect. Software presentation does not create physical resistance.
- Option 2: Correct. It increases resistance and can trap heat.
- Option 3: Incorrect. Documentation does not block air.
- Option 4: Incorrect. That is not normally a major airflow obstruction.

**DCCA-Q0168 · single · mechanism**

What should accompany an inlet temperature survey?

1. Workload and cooling operating state
2. Only the room-unit nameplate temperature
3. Only a room photograph
4. The lowest historical temperature

**Correct option(s):** 1

- Option 1: Correct. The measurements need a reproducible context.
- Option 2: Incorrect. A rated or configured value does not describe actual workload and operating state.
- Option 3: Incorrect. It lacks load and state information.
- Option 4: Incorrect. That does not describe current performance.

**DCCA-Q0169 · single · mechanism**

Why inspect containment penetrations?

1. A closed main door proves every penetration is sealed
2. Penetrations always add cooling capacity
3. Fire and access interfaces never matter
4. Gaps can reconnect supply and exhaust paths

**Correct option(s):** 4

- Option 1: Incorrect. Smaller openings and cable gaps can still connect the air paths.
- Option 2: Incorrect. They can cause mixing instead.
- Option 3: Incorrect. Containment must respect those requirements.
- Option 4: Correct. Containment performance depends on actual sealing.

**DCCA-Q0170 · single · mechanism**

What drives airflow through equipment?

1. The name assigned to an aisle
2. The number of warning stickers
3. Pressure difference across flow resistance
4. Rack ownership

**Correct option(s):** 3

- Option 1: Incorrect. Names do not move air.
- Option 2: Incorrect. Stickers do not establish flow.
- Option 3: Correct. This is the physical transport mechanism.
- Option 4: Incorrect. Ownership is not a pressure source.

**DCCA-Q0171 · single · mechanism**

Which correction best targets recirculation through empty U-spaces?

1. Remove all rear doors without review
2. Approved blanking and sealing followed by measurement
3. Lower every room setpoint indefinitely
4. Increase the UPS rating

**Correct option(s):** 2

- Option 1: Incorrect. Equipment and airflow requirements must be checked.
- Option 2: Correct. It addresses the observed path and verifies the result.
- Option 3: Incorrect. That may mask the path while increasing energy use.
- Option 4: Incorrect. Power capacity does not close air gaps.

**DCCA-Q0172 · single · mechanism**

Why can a sensor beside a supply outlet mislead?

1. Temperature sensors cannot measure air
2. A colder value proves no hotspot exists
3. Supply air is always identical throughout the room
4. It may not represent the equipment inlet conditions

**Correct option(s):** 4

- Option 1: Incorrect. They can when appropriately selected and placed.
- Option 2: Incorrect. Local measurements do not bound remote locations.
- Option 3: Incorrect. Distribution creates variation.
- Option 4: Correct. Location can bias the observation.

**DCCA-Q0173 · single · mechanism**

What is a useful rollback criterion for an airflow change?

1. The change ticket has many pages
2. The room becomes quieter
3. Any specified inlet limit or stability threshold is breached
4. The average temperature improves despite one inlet exceeding its limit

**Correct option(s):** 3

- Option 1: Incorrect. Length does not establish performance.
- Option 2: Incorrect. Noise alone does not prove thermal failure.
- Option 3: Correct. Rollback should be tied to service constraints.
- Option 4: Incorrect. A local mandatory limit cannot be waived by a favorable average.

**DCCA-Q0174 · single · mechanism**

Why validate nearby racks after sealing one air path?

1. Nearby racks generate no heat
2. Sealing always increases every inlet flow
3. Flow redistribution can affect other equipment
4. Only the changed rack can be affected

**Correct option(s):** 3

- Option 1: Incorrect. They still contribute load.
- Option 2: Incorrect. The effects are not universally uniform.
- Option 3: Correct. The room is a coupled system.
- Option 4: Incorrect. Pressure paths connect locations.

**DCCA-Q0175 · single · mechanism**

What should be reviewed when installing containment?

1. Whether all alarms can be removed
2. Whether every rack has identical ownership
3. Fire protection, access and emergency interfaces
4. Only the expected reduction in mixing

**Correct option(s):** 3

- Option 1: Incorrect. Monitoring remains necessary.
- Option 2: Incorrect. Ownership does not resolve safety interfaces.
- Option 3: Correct. Air separation interacts with other facility functions.
- Option 4: Incorrect. Thermal benefit alone does not satisfy fire and access requirements.

**DCCA-Q0176 · single · mechanism**

Why is very cold supply not automatically the best strategy?

1. IT equipment requires freezing air
2. Energy, condensation and equipment constraints must be balanced
3. Temperature has no effect on cooling
4. Cold supply eliminates every airflow defect

**Correct option(s):** 2

- Option 1: Incorrect. That is not a general requirement.
- Option 2: Correct. Colder is not universally more suitable.
- Option 3: Incorrect. It is central to heat transfer.
- Option 4: Incorrect. Poor distribution can remain.

**DCCA-Q0177 · single · mechanism**

What does an unsealed floor cable opening commonly create?

1. A guaranteed extra cooling unit
2. Automatic network redundancy
3. Higher battery runtime
4. An unintended airflow path

**Correct option(s):** 4

- Option 1: Incorrect. It does not add heat-removal machinery.
- Option 2: Incorrect. The opening is physical, not a second path.
- Option 3: Incorrect. It does not add electrical energy.
- Option 4: Correct. It can divert supply away from equipment.

**DCCA-Q0178 · single · mechanism**

Which observation differentiates cooling command from effective state?

1. Measured flow and inlet response
2. The entered setpoint only
3. A supervisor's expectation
4. The controller's brand

**Correct option(s):** 1

- Option 1: Correct. A setpoint alone does not show delivered function.
- Option 2: Incorrect. That is intent, not response.
- Option 3: Incorrect. Expectation is not measurement.
- Option 4: Incorrect. Brand does not reveal current output.

**DCCA-Q0179 · single · mechanism**

What is the purpose of multiple inlet measurement heights?

1. Replace all capacity calculations
2. Inflate the number of alarms
3. Measure only floor loading
4. Detect vertical temperature gradients

**Correct option(s):** 4

- Option 1: Incorrect. Measurement and calculation complement each other.
- Option 2: Incorrect. The purpose is representative observation.
- Option 3: Incorrect. Temperature sensors do not measure structural load.
- Option 4: Correct. One height can miss top-rack recirculation.

**DCCA-Q0180 · single · mechanism**

Which statement about hard-floor cooling is correct?

1. It can separate supply and return without a raised-floor plenum
2. It guarantees zero recirculation
3. It eliminates airflow engineering
4. It cannot cool any server

**Correct option(s):** 1

- Option 1: Correct. Overhead or local delivery can implement the function.
- Option 2: Incorrect. Poor paths can still mix air.
- Option 3: Incorrect. Distribution still matters.
- Option 4: Incorrect. Many designs use hard floors.

#### Recall

**What is airflow bypass?**

Supply air returns without cooling the intended IT load Correct. The air avoids useful heat pickup.

**What is hot-air recirculation?**

Exhaust re-enters IT inlets Correct. This raises inlet temperature.

**Why install blanking panels in unused rack positions?**

Reduce unintended air paths between front and rear Correct. They help maintain separation.

**A room averages 24°C but a top server inlet is 34°C. Which reading governs that server's inlet assessment?**

The local 34°C reading against its specified limit Correct. An average cannot erase a local condition.

**Why can adding many perforated tiles worsen cooling?**

It can reduce plenum pressure and divert flow Correct. Air distribution is a coupled pressure system.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DCCA-M10 — Humidity, dew point and environmental limits

### DCCA-L10 — Humidity, dew point and environmental limits

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L09

Air can contain water vapor. Relative humidity compares the present vapor pressure with saturation at the same temperature, so it changes when temperature changes even if no moisture is added or removed. Dew point describes the temperature at which the air reaches saturation under the relevant pressure. A cold surface below the local dew point can collect condensation.

This distinction matters in data centers because controls can chase the wrong variable. If one system heats air while another maintains a narrow relative-humidity target, unnecessary humidification or dehumidification can result. Interpret dry-bulb temperature, relative humidity and dew point together. Psychrometric relationships are useful for understanding moisture changes, but instrument accuracy and location remain part of the evidence.

Equipment environmental envelopes are product- and class-specific. A recommended operating region supports design and efficiency decisions; an allowable region describes a broader supported envelope under stated conditions. These are not permissions to operate indefinitely at every extreme or to ignore warranty, altitude, contamination and rate-of-change limits. The current applicable equipment specification controls the actual acceptance threshold.

Low humidity can increase electrostatic-discharge concerns in some conditions; high moisture and condensation can create corrosion or electrical problems. Grounding, handling procedures, material selection and contamination control also matter. Do not reduce ESD control to one room humidity number. Similarly, authentic telemetry can be physically wrong because of a biased sensor, bad location or incorrect scaling.

Place sensors to answer the relevant question: air entering IT, air near a cold liquid connection, or conditions in a representative return path. Calibrate and trend them, identify stale data and compare independent observations before changing plant settings. When a surface temperature approaches dew point, evaluate the local margin and approved response. A room-average humidity value cannot prove that every cold surface is free of condensation risk.

### Reason from local dew point rather than one RH number
Consider air with a measured dew point of 14°C. A pipe surface at 18°C has a nominal 4 K margin; a connector at 12°C is below dew point and can condense moisture. The same room can therefore contain both dry and wet-risk surfaces. A room-average RH value cannot settle the connector question without temperature information.

Include uncertainty in a close decision. If the surface measurement is 15°C ±1°C and dew point is 14°C ±1°C, the nominal 1 K margin is not a demonstrated guaranteed positive margin. The worst combinations overlap. Use suitable instruments and the approved operating response rather than treating the displayed decimal as exact.

For control, distinguish adding or removing water from merely changing temperature. Heating air at constant moisture lowers RH but does not dry it in the mass-balance sense. Cooling can raise RH until condensation begins; only then does liquid removal reduce vapor content. This explains why independent humidifiers and cooling units can fight when each follows a narrow RH target without coordinated logic.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. Room air has a measured dew point of 16°C. A coolant connection surface is 13°C.

**Reasoning:** The surface is below dew point, so condensation is possible. The relevant comparison is local surface temperature versus local dew point, not whether the room feels dry.

#### Guided practice

Air is warmed without adding moisture. Does relative humidity generally rise or fall?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** It generally falls because the saturation vapor pressure increases while actual moisture content is unchanged.

#### Independent task

Environment: analytical

Create an environmental acceptance sheet for an air-cooled rack and a nearby liquid interface.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Use the actual equipment envelope rather than a universal invented limit.
- Show dew-point margin for cold surfaces.
- Include sensor uncertainty, placement and stale-data detection.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0181 · single · mechanism**

Air is heated without changing moisture content. What generally happens to relative humidity?

1. It becomes exactly zero
2. It decreases
3. It necessarily increases
4. It always stays unchanged

**Correct option(s):** 2

- Option 1: Incorrect. Moisture remains present.
- Option 2: Correct. Warmer air has a higher saturation vapor pressure.
- Option 3: Incorrect. That reverses the relationship.
- Option 4: Incorrect. Relative humidity depends on temperature.

**DCCA-Q0182 · single · calculation**

A surface is 12°C while local dew point is 15°C. What is possible?

Synthetic educational evidence; not field measurements.

Local dew point: 15°C
Surface temperature: 12°C

1. Automatic battery charging
2. Increased fiber speed
3. Condensation on the surface
4. Guaranteed dry operation

**Correct option(s):** 3

- Option 1: Incorrect. This is a moisture condition.
- Option 2: Incorrect. Condensation does not improve bandwidth.
- Option 3: Correct. The surface is below the saturation temperature.
- Option 4: Incorrect. The dew-point comparison indicates risk.

**DCCA-Q0183 · single · mechanism**

What does dew point represent?

1. The outdoor wind speed
2. Temperature at which the air reaches saturation
3. Maximum safe server voltage
4. Room-average power density

**Correct option(s):** 2

- Option 1: Incorrect. That is unrelated.
- Option 2: Correct. It is tied to the moisture condition.
- Option 3: Incorrect. That is an electrical limit.
- Option 4: Incorrect. That is a different quantity.

**DCCA-Q0184 · single · mechanism**

Why can a narrow RH-only control strategy waste energy?

1. Humidifiers produce no load
2. Temperature changes can trigger unnecessary moisture correction
3. Dehumidification always improves efficiency
4. Relative humidity measures energy directly

**Correct option(s):** 2

- Option 1: Incorrect. They use energy and water.
- Option 2: Correct. RH can change without added or removed water.
- Option 3: Incorrect. It can be unnecessary.
- Option 4: Incorrect. It measures a moisture ratio.

**DCCA-Q0185 · single · mechanism**

Which limit should govern an installed server's environmental acceptance?

1. The coldest possible setpoint
2. A remembered universal temperature
3. Its applicable equipment specification and approved site envelope
4. A neighboring building's target

**Correct option(s):** 3

- Option 1: Incorrect. Colder is not inherently compliant or efficient.
- Option 2: Incorrect. No single number covers every product and condition.
- Option 3: Correct. Product and operating conditions matter.
- Option 4: Incorrect. That may use different equipment and requirements.

**DCCA-Q0186 · single · mechanism**

What distinguishes recommended from allowable environmental regions?

1. Recommended means the equipment cannot work elsewhere
2. They are always identical
3. Allowable means no other constraints apply
4. They serve different operating and support purposes

**Correct option(s):** 4

- Option 1: Incorrect. That overstates the term.
- Option 2: Incorrect. Specifications commonly distinguish them.
- Option 3: Incorrect. Duration and other conditions may still matter.
- Option 4: Correct. Allowable extremes are not automatically the preferred continuous target.

**DCCA-Q0187 · single · mechanism**

Why is humidity alone insufficient for ESD control?

1. Humidity directly repairs damaged components
2. ESD cannot occur in data centers
3. Only CPU clock speed matters
4. Handling, bonding and materials also influence discharge risk

**Correct option(s):** 4

- Option 1: Incorrect. It does not restore damaged electronics.
- Option 2: Incorrect. It can affect sensitive equipment.
- Option 3: Incorrect. Physical handling and electrical potential matter.
- Option 4: Correct. ESD is a system of controls.

**DCCA-Q0188 · single · mechanism**

Which sensor location helps assess condensation at a liquid connector?

1. Representative local air and connector surface measurements
2. Only a power panel current sensor
3. Only a distant doorway
4. Only the roof exterior

**Correct option(s):** 1

- Option 1: Correct. The relevant margin is local.
- Option 2: Incorrect. Current does not measure dew point.
- Option 3: Incorrect. That may not represent the connector environment.
- Option 4: Incorrect. Outdoor conditions may differ from the local interface.

**DCCA-Q0189 · single · mechanism**

What can make digitally authentic temperature data physically incorrect?

1. Correct timestamps alone
2. A successful network ping
3. A valid certificate
4. Sensor bias or wrong scaling

**Correct option(s):** 4

- Option 1: Incorrect. Timing does not repair calibration.
- Option 2: Incorrect. Connectivity does not validate the physical value.
- Option 3: Incorrect. Identity authentication does not establish sensor accuracy.
- Option 4: Correct. Secure transport does not guarantee measurement truth.

**DCCA-Q0190 · single · mechanism**

Why record sensor uncertainty?

1. A small apparent margin may lie within measurement error
2. Uncertainty makes all measurements useless
3. It always equals zero for digital sensors
4. It can be ignored whenever the display has many digits

**Correct option(s):** 1

- Option 1: Correct. Decisions should account for confidence in values.
- Option 2: Incorrect. It can be quantified and managed.
- Option 3: Incorrect. Digital output can still be inaccurate.
- Option 4: Incorrect. Display resolution does not remove measurement uncertainty.

**DCCA-Q0191 · single · mechanism**

A room RH value is acceptable but a cold pipe is below dew point. Which conclusion is sound?

1. The pipe must be dry
2. Local condensation risk remains
3. The humidity sensor is necessarily broken
4. Dew point is irrelevant indoors

**Correct option(s):** 2

- Option 1: Incorrect. The surface comparison contradicts that assumption.
- Option 2: Correct. Room RH alone does not bound every surface condition.
- Option 3: Incorrect. Both readings can be valid.
- Option 4: Incorrect. It applies wherever air and cold surfaces meet.

**DCCA-Q0192 · single · mechanism**

What indicates stale environmental telemetry?

1. A smooth trend with no timestamp information
2. An old source timestamp despite fresh dashboard refreshes
3. A value shown in degrees
4. A valid sensor asset tag

**Correct option(s):** 2

- Option 1: Incorrect. Smoothness can reflect a stable process or repeated stale values; it does not prove age.
- Option 2: Correct. Display refresh is not new measurement.
- Option 3: Incorrect. Units do not establish freshness.
- Option 4: Incorrect. Identity does not prove update time.

**DCCA-Q0193 · single · mechanism**

Why compare an independent observation before a major setpoint change?

1. The original sensor must always be wrong
2. It can distinguish real process change from sensor error
3. Two measurements always agree
4. Independent checks replace every calibration

**Correct option(s):** 2

- Option 1: Incorrect. The comparison tests rather than assumes that.
- Option 2: Correct. Changing the plant based on bad data can worsen conditions.
- Option 3: Incorrect. Disagreement is itself useful evidence.
- Option 4: Incorrect. Calibration remains necessary.

**DCCA-Q0194 · single · mechanism**

Which process directly removes moisture from air?

1. Relabeling the sensor
2. Condensation at a suitable cooling surface
3. Sensible heating alone
4. Increasing a switch's throughput

**Correct option(s):** 2

- Option 1: Incorrect. Labels do not change air properties.
- Option 2: Correct. Water vapor becomes liquid and can be drained.
- Option 3: Incorrect. Heating changes RH but does not remove moisture.
- Option 4: Incorrect. Network performance does not remove water.

**DCCA-Q0195 · single · mechanism**

What should an environmental trend include?

1. Only supplier names
2. Temperature, moisture indicators and operating context
3. Only the lowest value
4. Only the display refresh interval

**Correct option(s):** 2

- Option 1: Incorrect. Names do not show environmental behavior.
- Option 2: Correct. Combined data supports causal interpretation.
- Option 3: Incorrect. That hides other conditions.
- Option 4: Incorrect. Source measurements are needed.

**DCCA-Q0196 · single · mechanism**

Why should a coolant setpoint consider dew-point margin?

1. Warmer coolant always violates server limits
2. Cold surfaces can condense local moisture
3. Dew point controls packet loss directly
4. All liquid systems must use freezing coolant

**Correct option(s):** 2

- Option 1: Incorrect. Equipment specifications define the usable range.
- Option 2: Correct. Liquid temperature can affect surface temperature.
- Option 3: Incorrect. The direct issue is physical condensation.
- Option 4: Incorrect. That is not a universal design requirement.

**DCCA-Q0197 · single · mechanism**

What is dry-bulb temperature?

1. Relative humidity expressed as volts
2. The battery's dry mass
3. Ordinary air temperature measured without deliberate evaporative cooling
4. The lowest annual outdoor temperature

**Correct option(s):** 3

- Option 1: Incorrect. Those are different quantities.
- Option 2: Incorrect. That is unrelated.
- Option 3: Correct. It is distinct from moisture-dependent measures.
- Option 4: Incorrect. That is a climate statistic.

**DCCA-Q0198 · single · mechanism**

What should be done with an environmental alarm that conflicts with nearby readings?

1. Disable it permanently
2. Investigate location, calibration and process differences
3. Assume all sensors measure identical air
4. Change every setpoint immediately

**Correct option(s):** 2

- Option 1: Incorrect. That removes visibility without resolving cause.
- Option 2: Correct. A disagreement needs diagnosis.
- Option 3: Incorrect. Locations can differ.
- Option 4: Incorrect. That can create unnecessary disturbance.

**DCCA-Q0199 · single · mechanism**

Which environmental factor can affect corrosion alongside moisture?

1. The selected temperature unit, Celsius or Fahrenheit
2. Contaminants
3. Rack serial-number length
4. Ethernet port numbering

**Correct option(s):** 2

- Option 1: Incorrect. Changing the display unit does not change the physical corrosion mechanism.
- Option 2: Correct. Moisture and reactive substances can interact.
- Option 3: Incorrect. That is not a physical corrosion factor.
- Option 4: Incorrect. Numbering does not affect corrosion.

**DCCA-Q0200 · single · mechanism**

What is the proper evidence category for a psychrometric spreadsheet?

1. Production validation
2. Physical measurement
3. Provider examination award
4. Analytical model

**Correct option(s):** 4

- Option 1: Incorrect. A calculation alone is not production evidence.
- Option 2: Incorrect. No sensor observation is implied.
- Option 3: Incorrect. It does not issue a credential.
- Option 4: Correct. It computes relationships under assumptions.

#### Recall

**Air is heated without changing moisture content. What generally happens to relative humidity?**

It decreases Correct. Warmer air has a higher saturation vapor pressure.

**A surface is 12°C while local dew point is 15°C. What is possible?**

Condensation on the surface Correct. The surface is below the saturation temperature.

**What does dew point represent?**

Temperature at which the air reaches saturation Correct. It is tied to the moisture condition.

**Why can a narrow RH-only control strategy waste energy?**

Temperature changes can trigger unnecessary moisture correction Correct. RH can change without added or removed water.

**Which limit should govern an installed server's environmental acceptance?**

Its applicable equipment specification and approved site envelope Correct. Product and operating conditions matter.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DCCA-M11 — Liquid cooling and facility-water interfaces

### DCCA-L11 — Liquid cooling and facility-water interfaces

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L10

Liquid cooling moves part of the IT heat into a liquid rather than relying exclusively on room air. Direct-to-chip cold plates contact selected hot components through a thermal interface. Rear-door heat exchangers capture heat from rack exhaust. Immersion places compatible equipment in a specified dielectric fluid. Each arrangement changes service access, materials, contamination management and the boundary between IT and facility systems; none automatically eliminates all air cooling.

A coolant distribution unit often separates a technology cooling loop from a facility water loop through a heat exchanger. It can provide pumps, filtration, temperature control and monitoring. Separation allows different pressure, chemistry and cleanliness requirements, but the heat must still reach a functioning final sink. A CDU with healthy network communications and running pumps can still fail thermally if the facility-side supply is unavailable.

For a liquid, Q = mass flow × specific heat × temperature rise. Using water near ordinary operating conditions and an illustrative specific heat of 4.18 kJ/(kg·K), removing 100 kW with a 10 K rise requires about 2.39 kg/s. Use actual fluid properties for glycol or other mixtures; do not silently apply water values to every coolant. Pressure drop, pump operating point and parallel branch balance determine whether the calculated flow reaches each cold plate.

Compatibility is a system property. Wetted metals, seals, hoses, connectors and coolant chemistry must suit one another and the OEM specification. A leak detector senses the condition at its installed location; it does not prove there are no leaks elsewhere. Quick-disconnect terminology does not guarantee zero spill under every misuse or failure. Procedures must address depressurization, contamination prevention and safe isolation by authorized personnel.

Evaluate dew-point margin at cold surfaces, residual air load, loss of flow, loss of facility water, power interruption and recovery. Instrument temperature at the right boundary and pair it with flow and pressure. Low temperature alone can look favorable while flow has stopped. Acceptance tests must connect heat load to measured transfer and the required protective response, with simulated faults clearly distinguished from physical tests.

### Follow a liquid-cooled rack through a fault
A rack consumes 80 kW and transfers 60 kW into a water loop, leaving 20 kW for room air. At a 10 K liquid rise, ideal water mass flow is 60/(4.18×10)=1.435 kg/s. This calculation establishes a transport demand, not a pump selection. The pump must deliver that flow against the actual circuit resistance, and the exchanger must transfer it at the available temperatures.

If the facility-water loop stops, the technology loop may keep circulating while becoming warmer. A pump-running status can remain true throughout the loss of useful heat rejection. Trend supply and return temperatures, actual flow and IT temperatures to see the progressing energy imbalance. Define the permitted degraded interval from supported equipment and site analysis rather than inventing a generic grace period.

On restoration, verify valve state, pressure, flow distribution, temperature control and leak indication. A cold supply reading at one sensor can coexist with trapped air or a blocked branch elsewhere. Record which branches and load conditions were tested. The return of network communication is only one part of recovery.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A cold-plate loop removes 100 kW using an assumed water specific heat of 4.18 kJ/kg·K and a measured 10 K temperature rise.

**Reasoning:** Ideal mass flow is 100/(4.18×10)=2.39 kg/s. This is approximately 2.39 L/s only if density is close to 1 kg/L. Actual coolant properties, sensor accuracy and branch distribution must be checked.

#### Guided practice

A rack transfers 80% of its 50 kW heat to liquid. How much IT heat remains for air cooling?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** 10 kW remains, before other room loads and auxiliary losses.

#### Independent task

Environment: analytical

Draw both CDU loops and write a loss-of-flow acceptance test.

**Packaged starter material**

- course_labs/DCCA/README.md
- course_labs/DCCA/scenario.json
- course_labs/DCCA/answers-template.json

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Identify the heat exchanger and final sink.
- Calculate residual air load.
- Specify flow, temperature, pressure and leak observations.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0201 · single · calculation**

A 50 kW rack transfers 80% of its heat to liquid. What residual IT air load remains?

Synthetic educational evidence; not field measurements.

Rack total heat: 50 kW
Liquid capture fraction: 80%

1. 50 kW
2. 0 kW
3. 40 kW
4. 10 kW

**Correct option(s):** 4

- Option 1: Incorrect. That ignores liquid heat transfer.
- Option 2: Incorrect. Liquid cooling does not necessarily capture every component's heat.
- Option 3: Incorrect. That is the liquid-captured portion.
- Option 4: Correct. Twenty percent remains in the air path.

**DCCA-Q0202 · single · mechanism**

What is a common purpose of a CDU heat exchanger?

1. Separate facility and technology coolant loops
2. Mix all fluids into one chemistry
3. Generate additional cooling energy from nothing
4. Replace the outdoor heat sink

**Correct option(s):** 1

- Option 1: Correct. The loops can maintain different fluid conditions.
- Option 2: Incorrect. A heat exchanger can transfer heat without mixing.
- Option 3: Incorrect. It transfers heat rather than creating energy.
- Option 4: Incorrect. Rejected heat must still leave the facility.

**DCCA-Q0203 · single · calculation**

Using water specific heat 4.18 kJ/kg·K, what mass flow removes 100 kW at a 10 K rise?

Synthetic educational evidence; not field measurements.

Heat: 100 kW
Water cp: 4.18 kJ/(kg·K)
Rise: 10 K

1. About 41.8 kg/s
2. About 2.39 kg/s
3. About 0.239 kg/s
4. About 23.9 kg/s

**Correct option(s):** 2

- Option 1: Incorrect. This confuses the denominator with the result.
- Option 2: Correct. 100 divided by 41.8 gives the required flow.
- Option 3: Incorrect. This introduces a tenfold error.
- Option 4: Incorrect. This omits the 10 K rise.

**DCCA-Q0204 · single · mechanism**

Why must coolant properties be identified?

1. Nominal pipe size determines specific heat
2. The same supply temperature makes all fluids equivalent
3. Mixtures can differ from water in heat capacity and viscosity
4. Every coolant has identical properties

**Correct option(s):** 3

- Option 1: Incorrect. Specific heat is a material property.
- Option 2: Incorrect. Heat capacity and viscosity can differ at the same temperature.
- Option 3: Correct. Heat transfer and pressure drop depend on the fluid.
- Option 4: Incorrect. Composition changes physical behavior.

**DCCA-Q0205 · single · diagnosis**

A CDU pump runs but facility-water flow is absent. What can fail?

Synthetic educational evidence; not field measurements.

Technology-loop pump: running
Facility-water flow: absent
Heat sink: not available

1. Sustained heat rejection
2. The existence of electrical input
3. The meaning of a temperature unit
4. Every liquid sensor simultaneously by definition

**Correct option(s):** 1

- Option 1: Correct. The technology loop may circulate heat without a usable sink.
- Option 2: Incorrect. The running pump already demonstrates some input.
- Option 3: Incorrect. Units remain valid.
- Option 4: Incorrect. The failed heat sink does not imply all sensors fail.

**DCCA-Q0206 · single · mechanism**

Which system places compatible equipment in a dielectric fluid?

1. Air-side economizer
2. Rear-door heat exchanger
3. Immersion cooling
4. Ordinary chilled-water CRAH

**Correct option(s):** 3

- Option 1: Incorrect. That uses outside air conditions.
- Option 2: Incorrect. That treats rack exhaust rather than immersing the equipment.
- Option 3: Correct. The equipment is immersed in the specified fluid.
- Option 4: Incorrect. The IT remains in air.

**DCCA-Q0207 · single · mechanism**

What does direct-to-chip cooling primarily use?

1. A UPS static bypass
2. Cold plates thermally coupled to selected components
3. Fuel circulation through server boards
4. Only room return air

**Correct option(s):** 2

- Option 1: Incorrect. That is an electrical path.
- Option 2: Correct. Heat crosses the component-to-plate interface.
- Option 3: Incorrect. Fuel is not the specified technology coolant.
- Option 4: Incorrect. That is air cooling rather than direct cold plates.

**DCCA-Q0208 · single · mechanism**

Why assess residual air cooling in a liquid-cooled rack?

1. Not all component heat may enter the liquid loop
2. Liquid systems always remove zero heat
3. All room fans become unnecessary by definition
4. Air temperature cannot affect liquid-cooled equipment

**Correct option(s):** 1

- Option 1: Correct. Memory, power supplies or other components can retain air demand.
- Option 2: Incorrect. They can remove a large fraction.
- Option 3: Incorrect. Residual heat still needs a path.
- Option 4: Incorrect. Some components and surfaces remain air exposed.

**DCCA-Q0209 · single · mechanism**

What determines actual flow through parallel cold-plate branches?

1. The number of monitoring dashboards
2. Pressure distribution and branch resistance
3. Equal IP subnet masks
4. Equal hose length alone guarantees equal flow

**Correct option(s):** 2

- Option 1: Incorrect. Display count does not determine flow.
- Option 2: Correct. The pump total does not guarantee equal branch flow.
- Option 3: Incorrect. Addressing does not balance coolant.
- Option 4: Incorrect. Diameter, fittings, cold plates and pressure conditions also affect branch resistance.

**DCCA-Q0210 · single · mechanism**

What does a dry leak detector prove?

1. No detected leak at that sensor under its detection conditions
2. All connectors are correctly torqued
3. No leak anywhere in the facility
4. All fluid chemistry is acceptable

**Correct option(s):** 1

- Option 1: Correct. Coverage is local and conditional.
- Option 2: Incorrect. Leak status does not prove assembly detail.
- Option 3: Incorrect. One sensor cannot establish universal absence.
- Option 4: Incorrect. Leak detection does not measure chemistry.

**DCCA-Q0211 · single · mechanism**

Why review wetted-material compatibility?

1. Fluid and materials can react or degrade seals
2. Matching external connector dimensions alone
3. All metals are interchangeable in every coolant
4. Compatibility eliminates the need for filtration

**Correct option(s):** 1

- Option 1: Correct. Compatibility affects integrity over time.
- Option 2: Incorrect. Mechanical fit does not establish internal material and chemical compatibility.
- Option 3: Incorrect. Corrosion and compatibility differ.
- Option 4: Incorrect. Particle control is a separate requirement.

**DCCA-Q0212 · single · mechanism**

A coolant temperature remains low while measured flow falls to zero. What should the operator infer?

1. The flow sensor must be wrong
2. Temperature alone does not demonstrate heat transport
3. The IT load must be zero
4. Cooling is necessarily improved

**Correct option(s):** 2

- Option 1: Incorrect. It requires diagnosis, not dismissal.
- Option 2: Correct. Without flow, local readings can lag or misrepresent component conditions.
- Option 3: Incorrect. The supplied evidence does not establish that.
- Option 4: Incorrect. Low flow can reduce heat removal.

**DCCA-Q0213 · single · mechanism**

Which measurement set best supports a liquid heat-balance check?

1. Flow and matched supply/return temperatures
2. Pump command percentage only
3. One ambient temperature only
4. Pipe label and purchase date

**Correct option(s):** 1

- Option 1: Correct. Together they support transported-heat calculation.
- Option 2: Incorrect. Command does not prove delivered flow.
- Option 3: Incorrect. That omits liquid flow and temperature rise.
- Option 4: Incorrect. Those do not measure heat transfer.

**DCCA-Q0214 · single · mechanism**

What should be checked before treating a quick disconnect as spill-free?

1. Whether it is new
2. Whether its hose is short
3. Only the connector's marketing name
4. Its rated operating conditions and approved handling procedure

**Correct option(s):** 4

- Option 1: Incorrect. New equipment can still be mishandled.
- Option 2: Incorrect. Length alone does not establish disconnection behavior.
- Option 3: Incorrect. A name does not establish pressure or misuse limits.
- Option 4: Correct. The term does not guarantee behavior under every condition.

**DCCA-Q0215 · single · mechanism**

Why monitor dew-point margin near cold liquid connections?

1. Every liquid circuit must run below dew point
2. Condensation can occur on cold surfaces
3. It replaces leak detection
4. Dew point determines pump speed directly

**Correct option(s):** 2

- Option 1: Incorrect. That would create avoidable condensation risk.
- Option 2: Correct. The local air moisture condition matters.
- Option 3: Incorrect. Condensation and coolant leaks are different mechanisms.
- Option 4: Incorrect. It is a thermal-moisture constraint, not a speed command.

**DCCA-Q0216 · single · mechanism**

A rear-door heat exchanger is installed. Which function must still be verified?

1. Automatic doubling of server power capacity
2. Automatic elimination of all room cooling
3. Only the presence of a chilled-water connection
4. Heat rejection through its liquid and facility paths

**Correct option(s):** 4

- Option 1: Incorrect. Electrical distribution remains a separate constraint.
- Option 2: Incorrect. Capture fraction and other loads must be assessed.
- Option 3: Incorrect. A connected pipe does not prove usable flow, heat exchange and final rejection.
- Option 4: Correct. Capturing rack heat is only one stage.

**DCCA-Q0217 · single · mechanism**

What is the proper interpretation of a simulated leak alarm test?

1. It demonstrates hose pressure rating
2. It tests the alarm path, not a physical leak's capture behavior
3. It verifies coolant chemistry
4. It proves every leak will be detected

**Correct option(s):** 2

- Option 1: Incorrect. No pressure test was performed.
- Option 2: Correct. The stimulus and fidelity must be stated.
- Option 3: Incorrect. The simulated contact does not measure chemistry.
- Option 4: Incorrect. Coverage and real fluid behavior remain untested.

**DCCA-Q0218 · single · mechanism**

Why include pump power loss in acceptance planning?

1. Heat transport can stop even with cold facility water available
2. It only affects billing records
3. Water always circulates sufficiently without pumps
4. It is identical to a network ping failure

**Correct option(s):** 1

- Option 1: Correct. Flow requires a functioning motive source.
- Option 2: Incorrect. It can affect component temperature.
- Option 3: Incorrect. Natural circulation cannot be assumed.
- Option 4: Incorrect. The physical consequences differ.

**DCCA-Q0219 · single · mechanism**

What does a higher liquid temperature rise imply at unchanged load in the ideal balance?

1. No possible sensor error
2. Guaranteed safe component temperature
3. Necessarily greater total flow
4. Lower mass flow, if fluid properties remain comparable

**Correct option(s):** 4

- Option 1: Incorrect. Measurements still require validation.
- Option 2: Incorrect. Component limits and local distribution still matter.
- Option 3: Incorrect. That reverses the balance.
- Option 4: Correct. Flow and temperature rise trade inversely.

**DCCA-Q0220 · single · mechanism**

Which restoration evidence is strongest after a coolant-flow fault?

1. Pump start command alone
2. Stable flow, temperatures, alarms and IT function under stated load
3. A reopened incident ticket
4. Alarm acknowledgment alone

**Correct option(s):** 2

- Option 1: Incorrect. Actual response must be confirmed.
- Option 2: Correct. Recovery must restore the complete required function.
- Option 3: Incorrect. Administrative state does not prove cooling.
- Option 4: Incorrect. That does not restore flow.

#### Recall

**A 50 kW rack transfers 80% of its heat to liquid. What residual IT air load remains?**

10 kW Correct. Twenty percent remains in the air path.

**What is a common purpose of a CDU heat exchanger?**

Separate facility and technology coolant loops Correct. The loops can maintain different fluid conditions.

**Using water specific heat 4.18 kJ/kg·K, what mass flow removes 100 kW at a 10 K rise?**

About 2.39 kg/s Correct. 100 divided by 41.8 gives the required flow.

**Why must coolant properties be identified?**

Mixtures can differ from water in heat capacity and viscosity Correct. Heat transfer and pressure drop depend on the fluid.

**A CDU pump runs but facility-water flow is absent. What can fail?**

Sustained heat rejection Correct. The technology loop may circulate heat without a usable sink.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DCCA-M12 — Racks, mechanical fit and equipment installation

### DCCA-L12 — Racks, mechanical fit and equipment installation

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L11

A rack is a mechanical, electrical and airflow interface rather than just a storage frame. Standard mounting width and rack-unit height help establish compatibility, but usable depth, rail geometry, rear-door clearance, cable bend space and equipment weight also matter. One rack unit is 1.75 inches, or 44.45 mm. A device that fits the front opening may still obstruct doors or connectors when installed.

Distinguish static load, dynamic moving load and point loading. A cabinet rated for a stationary distributed load may have a lower permitted load while rolling. Floor loading is a separate building-interface constraint; the rack rating does not approve the floor, ramp, route or lift. Obtain the appropriate structural confirmation rather than personally claiming D1 engineering ownership.

Plan equipment placement for stability, airflow and service. Heavy devices commonly belong lower where the approved installation instructions support that arrangement. Extending multiple heavy chassis can shift the center of gravity and create a tipping hazard. Use the required stabilization, lifting aids and authorized handling team. Rails must match the equipment and cabinet; improvised supports can fail even if bolt holes align.

Rack power planning includes source independence, connector type, cable reach, retention, outlet count, phase allocation and supported current. Separate A and B paths intentionally and verify their upstream origins. Cable management should preserve service loops without obstructing air or violating bend limits. Labels identify both ends and the asset relationship; they should remain readable after installation.

Receiving and installation are evidence-producing stages. Check identity, damage, required accessories, approved bill of materials and compatibility before energization. Record serial numbers and port/outlet assignments. After installation, verify bonding, mechanical stability, airflow direction, power-source mapping and out-of-band access under the applicable procedure. Update the inventory and as-built records before accepting the change.

### Build an installation decision from independent constraints
A proposed 4U chassis needs 900 mm depth, weighs 75 kg and requires two supported power connections. The rack has 6U free, but only 820 mm usable depth with the rear door closed. The U-space test passes while the depth test fails. The correct decision is hold or redesign, not force the door shut or bend connectors beyond their limit.

Next check the load path. Rails transfer chassis weight to the cabinet; the cabinet transfers it through feet or casters to floor components and ultimately the structure. Every interface needs suitable evidence. The rack's static rating does not approve rolling the loaded cabinet over a ramp or through a lift. Those conditions belong in the handling and specialist-interface review.

After installation, demonstrate more than boot. Confirm the asset and rail kit, source mapping, cord retention, airflow direction, labels, management access and service clearance. A replaceable fan that cannot be reached without removing an unrelated critical cable is a maintainability defect even if today's temperature is acceptable. Update the rack elevation and connection records to match the physical result.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A 42U rack already uses 30U. New devices require 6U, 4U and 3U, before any reserved spaces.

**Reasoning:** The proposed devices require 13U but only 12U is free, so the arrangement is infeasible before additional airflow or service reservations. Electrical and thermal checks are still needed even if U-space is corrected.

#### Guided practice

A cabinet supports 1000 kg stationary but only 600 kg while moving. It weighs 750 kg loaded. Can it be rolled under those stated ratings?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** No. The moving-load limit is exceeded; an approved handling plan is required.

#### Independent task

Environment: analytical

Prepare a rack elevation and installation acceptance checklist.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Check space, depth, weight, airflow, power and service clearance.
- Keep rack and floor approvals distinct.
- Trace both supply paths and record as-built connections.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0221 · single · mechanism**

What is one rack unit in millimeters?

1. 100 mm
2. 19 mm
3. 44.45 mm
4. 25.4 mm

**Correct option(s):** 3

- Option 1: Incorrect. That is not the standard U height.
- Option 2: Incorrect. Nineteen inches refers to a common mounting width.
- Option 3: Correct. One U is 1.75 inches.
- Option 4: Incorrect. That is one inch rather than one U.

**DCCA-Q0222 · single · diagnosis**

A 42U rack has 30U occupied. Devices need 6U, 4U and 3U. What is the space result?

Synthetic educational evidence; not field measurements.

Rack height: 42U
Occupied: 30U
Proposed devices: 6U + 4U + 3U

1. Exactly enough space
2. A 3U surplus
3. A 13U surplus
4. A 1U shortfall

**Correct option(s):** 4

- Option 1: Incorrect. The arithmetic leaves a deficit.
- Option 2: Incorrect. That does not match the stated values.
- Option 3: Incorrect. Thirteen U is the new demand.
- Option 4: Correct. Thirteen U is required but twelve U is free.

**DCCA-Q0223 · single · mechanism**

Why distinguish static and moving rack-load ratings?

1. Movement can impose different mechanical limits
2. Both ratings are always identical
3. Static ratings apply only to empty racks
4. Moving equipment always weighs less

**Correct option(s):** 1

- Option 1: Correct. A stationary rating does not authorize rolling the same load.
- Option 2: Incorrect. Manufacturers can specify different values.
- Option 3: Incorrect. They can apply to loaded stationary racks.
- Option 4: Incorrect. Mass does not disappear during movement.

**DCCA-Q0224 · single · mechanism**

What must be checked beyond front mounting width?

1. Only the number of licenses
2. Only the server hostname
3. Only the room temperature
4. Depth, rails, rear clearance and service access

**Correct option(s):** 4

- Option 1: Incorrect. Licensing does not determine rail geometry.
- Option 2: Incorrect. Naming does not establish fit.
- Option 3: Incorrect. Thermal conditions do not prove mechanical compatibility.
- Option 4: Correct. Mechanical fit is multidimensional.

**DCCA-Q0225 · single · mechanism**

Why can extending multiple heavy chassis be hazardous?

1. It lowers all equipment mass
2. It can move the center of gravity outside the stable base
3. It automatically disconnects every power source
4. It necessarily improves stability

**Correct option(s):** 2

- Option 1: Incorrect. Mass remains unchanged.
- Option 2: Correct. The cabinet can tip.
- Option 3: Incorrect. Power behavior depends on actual connections.
- Option 4: Incorrect. Extension can do the opposite.

**DCCA-Q0226 · single · mechanism**

A cabinet rating is acceptable. What remains a separate approval?

1. Floor and movement-route suitability
2. Only the number of available mounting holes
3. The count of rack units
4. The rack manufacturer's label

**Correct option(s):** 1

- Option 1: Correct. The cabinet rating does not rate the building route.
- Option 2: Incorrect. Mounting geometry does not approve floor or movement-route loading.
- Option 3: Incorrect. Space count does not approve floor loading.
- Option 4: Incorrect. That already describes the cabinet.

**DCCA-Q0227 · single · mechanism**

What is the purpose of compatible equipment rails?

1. Support the chassis using its approved mounting arrangement
2. Add battery runtime
3. Increase CPU performance
4. Replace rack bonding

**Correct option(s):** 1

- Option 1: Correct. Hole alignment alone is insufficient.
- Option 2: Incorrect. Rails store no electrical energy.
- Option 3: Incorrect. Rails are mechanical supports.
- Option 4: Incorrect. Bonding is a separate electrical requirement.

**DCCA-Q0228 · single · mechanism**

Which placement commonly supports stability when instructions permit?

1. All heavy equipment at the top
2. Heaviest devices at the front edge regardless of instructions
3. All chassis extended permanently
4. Heavier equipment lower in the rack

**Correct option(s):** 4

- Option 1: Incorrect. That can increase tipping risk.
- Option 2: Incorrect. That can move the center of gravity unfavorably and violate the approved arrangement.
- Option 3: Incorrect. That can undermine stability and access.
- Option 4: Correct. This tends to lower the center of gravity.

**DCCA-Q0229 · single · mechanism**

What should receiving inspection verify before acceptance?

1. Whether the dashboard already lists a hostname
2. Only whether the box is large
3. Identity, condition, accessories and approved compatibility
4. Only the delivery driver's name

**Correct option(s):** 3

- Option 1: Incorrect. Inventory entry alone does not inspect the physical asset.
- Option 2: Incorrect. Size does not establish correctness.
- Option 3: Correct. The delivered item must match the intended installation.
- Option 4: Incorrect. That does not verify the equipment.

**DCCA-Q0230 · single · mechanism**

Why preserve cable bend space behind a server?

1. Fiber has no bend constraints
2. Connectors and cables have mechanical limits
3. Power cords automatically reshape safely
4. More bend always improves signal quality

**Correct option(s):** 2

- Option 1: Incorrect. Fiber performance depends on suitable bend radius.
- Option 2: Correct. A closed door can force damaging bends.
- Option 3: Incorrect. Mechanical limits still apply.
- Option 4: Incorrect. Excessive bend can degrade or damage cabling.

**DCCA-Q0231 · single · mechanism**

What makes A/B cord labeling insufficient alone?

1. A/B labels define utility independence automatically
2. Two cords always draw twice the load
3. The upstream sources must also be traced
4. Labels prevent every human error

**Correct option(s):** 3

- Option 1: Incorrect. The full path must be checked.
- Option 2: Incorrect. Load sharing behavior differs.
- Option 3: Correct. Different labels can still share one source.
- Option 4: Incorrect. They support but do not guarantee correct work.

**DCCA-Q0232 · single · mechanism**

Which observation confirms airflow direction compatibility?

1. Equipment inlet and exhaust orientation in the installed rack
2. The server's model name only
3. The rack's purchase date
4. The number of available outlets

**Correct option(s):** 1

- Option 1: Correct. Physical orientation must match the aisle design.
- Option 2: Incorrect. Variants and installation still matter.
- Option 3: Incorrect. Date does not establish airflow direction.
- Option 4: Incorrect. Power outlets do not define air paths.

**DCCA-Q0233 · single · mechanism**

What should be recorded after changing a rack outlet assignment?

1. Asset, outlet, branch and source relationship
2. Nothing if service stayed online
3. Only a total rack count
4. Only the change author's initials

**Correct option(s):** 1

- Option 1: Correct. This preserves traceability.
- Option 2: Incorrect. Normal operation can hide lost independence.
- Option 3: Incorrect. The specific power path is needed.
- Option 4: Incorrect. That omits the effective connection.

**DCCA-Q0234 · single · mechanism**

Why can an apparently empty U-space be unavailable?

1. Rack units cannot be counted
2. A free U guarantees power and cooling
3. Empty spaces always contain hidden servers
4. Airflow, access or future capacity may reserve it

**Correct option(s):** 4

- Option 1: Incorrect. They can be measured.
- Option 2: Incorrect. Other constraints remain.
- Option 3: Incorrect. That is not generally true.
- Option 4: Correct. Usable space is constrained by the design.

**DCCA-Q0235 · single · mechanism**

Which action is appropriate for visibly damaged delivery rails?

1. Hide the damage behind the device
2. Install because the chassis fits
3. Hold installation and resolve the defect
4. Increase fan speed

**Correct option(s):** 3

- Option 1: Incorrect. That conceals a material risk.
- Option 2: Incorrect. Fit does not prove load capacity.
- Option 3: Correct. Support integrity is required.
- Option 4: Incorrect. Cooling does not repair mechanical support.

**DCCA-Q0236 · single · mechanism**

What is a rack elevation useful for?

1. Replacing structural approval
2. Planning and recording equipment positions
3. Calculating every application latency
4. Proving all circuits are independent

**Correct option(s):** 2

- Option 1: Incorrect. The drawing does not certify floor capacity.
- Option 2: Correct. It supports space and service decisions.
- Option 3: Incorrect. It is not a network performance model.
- Option 4: Incorrect. Electrical tracing is also needed.

**DCCA-Q0237 · single · mechanism**

Why keep service loops controlled?

1. Guarantee zero signal loss
2. Eliminate the need for labels
3. Maximize tangled cable volume
4. Allow maintenance without excessive strain or obstruction

**Correct option(s):** 4

- Option 1: Incorrect. Length and connection quality still matter.
- Option 2: Incorrect. Traceability remains necessary.
- Option 3: Incorrect. That impairs service and airflow.
- Option 4: Correct. Extra length must still respect airflow and bend requirements.

**DCCA-Q0238 · single · mechanism**

Which factor can block installation even when U-space is sufficient?

1. A completed rack drawing
2. A verified approved rail kit
3. Connector mismatch or inadequate power capacity
4. A readable asset label

**Correct option(s):** 3

- Option 1: Incorrect. Documentation supports installation rather than blocking it.
- Option 2: Incorrect. That supports compatibility.
- Option 3: Correct. Mechanical space does not satisfy electrical constraints.
- Option 4: Incorrect. That is beneficial.

**DCCA-Q0239 · single · mechanism**

Why validate out-of-band access after installation?

1. Maintenance and recovery may depend on a separate management path
2. It eliminates all security requirements
3. It replaces every application test
4. It proves floor loading

**Correct option(s):** 1

- Option 1: Correct. It must work in the effective installed state.
- Option 2: Incorrect. Management access itself needs protection.
- Option 3: Incorrect. Management access is only one function.
- Option 4: Incorrect. Network access does not measure structural capacity.

**DCCA-Q0240 · single · mechanism**

Which evidence category describes a rack elevation drawn from proposed equipment only?

1. Production operation evidence
2. Design evidence
3. Physical commissioning evidence
4. A complete provider credential

**Correct option(s):** 2

- Option 1: Incorrect. There is no production observation.
- Option 2: Correct. It represents intended arrangement, not an executed installation.
- Option 3: Incorrect. No installed state has been observed.
- Option 4: Incorrect. A drawing does not award certification.

#### Recall

**What is one rack unit in millimeters?**

44.45 mm Correct. One U is 1.75 inches.

**A 42U rack has 30U occupied. Devices need 6U, 4U and 3U. What is the space result?**

A 1U shortfall Correct. Thirteen U is required but twelve U is free.

**Why distinguish static and moving rack-load ratings?**

Movement can impose different mechanical limits Correct. A stationary rating does not authorize rolling the same load.

**What must be checked beyond front mounting width?**

Depth, rails, rear clearance and service access Correct. Mechanical fit is multidimensional.

**Why can extending multiple heavy chassis be hazardous?**

It can move the center of gravity outside the stable base Correct. The cabinet can tip.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DCCA-M13 — Copper cabling, channels and verification

### DCCA-L13 — Copper cabling, channels and verification

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L12

Structured copper cabling separates fixed infrastructure from equipment cords and supports documented, repeatable connectivity. A permanent link normally refers to the installed cabling between defined termination points; a channel includes the relevant patch or equipment cords within its test definition. Use the applicable standard and tester configuration rather than assuming that a passing permanent-link result automatically approves every assembled channel.

Balanced twisted pairs reduce susceptibility to interference by carrying a differential signal. Pair twist and geometry matter. Excessive untwisting, split pairs, crushed cable, poor terminations and inappropriate components can degrade performance even when a simple continuity test passes. Shielded systems add bonding and installation requirements; shielding is not a substitute for correct pair construction and separation from disturbance sources.

A category designation describes a defined performance class of components or installed cabling. Supported application distance depends on the category, frequency, channel construction, environmental conditions and applicable application specification. Do not turn a familiar distance into a universal rule for every Ethernet rate and cable. Verify the actual intended application and installed channel.

A wiremap test checks connection relationships, opens, shorts and certain pair faults. Certification testing evaluates additional transmission properties such as insertion loss, return loss and crosstalk against the selected limits. A link light confirms some physical-layer negotiation but does not certify the channel. A successful low-rate test does not prove margin for a higher-rate application.

Power over Ethernet carries power as well as data, so bundle heating, conductor resistance, connector suitability and supported power class matter. The powered-device demand and source budget must both be evaluated, including redundancy and startup. Record cable identifiers, end locations, termination type, length, test configuration, result and corrective work. Retest after changes that alter the qualified path.

### Diagnose a copper link without collapsing test layers
A new channel negotiates at a lower rate than specified. A continuity tester reports all conductors connected, but a certification result shows poor crosstalk margin. The observations are compatible: continuity tests connectivity, while high-rate signaling depends on pair geometry and transmission properties. Inspect termination untwist, pair assignment, component category and mechanical damage.

Keep the test boundary explicit. A permanent-link result may exclude equipment cords that are part of the final channel. Replacing one cord can fix the application while leaving the fixed installation unchanged. Record what was changed and retest the relevant assembled path; do not claim the original report tested a component installed later.

For PoE, add the power budget. Eight devices at 30 W each require 240 W before any relevant allocation and delivery assumptions. A switch with eight individually capable ports but a 180 W aggregate budget cannot promise all eight at that demand simultaneously. Verify the source budget, device class, cabling and thermal conditions. A healthy data link is necessary but does not prove supported power delivery.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A fixed link passes certification, but an assembled channel with an old damaged patch cord has errors at its intended rate.

**Reasoning:** The permanent-link result does not validate the added cord. Inspect and substitute approved channel components, then test the assembled path against the intended application.

#### Guided practice

A continuity tester passes all conductors, but a certification tester reports a split pair. Why can both observations occur?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** Continuity can show end-to-end connections while the physical pair assignment is wrong, producing excessive crosstalk.

#### Independent task

Environment: analytical

Create a copper acceptance record for a synthetic management-network channel.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Distinguish wiremap, certification and application tests.
- Specify channel components and intended rate.
- Include PoE budget and thermal considerations if power is carried.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0241 · single · mechanism**

What distinguishes a channel test from a permanent-link test?

1. Permanent-link tests include every future cord
2. Channel tests measure only power
3. The terms always describe identical boundaries
4. The tested component boundary

**Correct option(s):** 4

- Option 1: Incorrect. Future changes are outside the original test.
- Option 2: Incorrect. They can assess data transmission properties.
- Option 3: Incorrect. Their definitions differ.
- Option 4: Correct. A channel includes applicable cords beyond the fixed link.

**DCCA-Q0242 · single · mechanism**

Why can a continuity pass coexist with poor high-rate transmission?

1. Correct connectivity does not prove transmission performance
2. Continuity certifies every category parameter
3. Ethernet never uses paired conductors
4. High-rate errors prove no conductors are connected

**Correct option(s):** 1

- Option 1: Correct. Loss and crosstalk can still exceed limits.
- Option 2: Incorrect. It is a narrower check.
- Option 3: Incorrect. Balanced pairs are fundamental to common copper Ethernet.
- Option 4: Incorrect. Connections can exist with inadequate signal quality.

**DCCA-Q0243 · single · mechanism**

What is a split pair?

1. A fiber splice
2. Conductors are connected but assigned across the wrong physical pairs
3. A correctly terminated differential pair
4. A normal channel boundary

**Correct option(s):** 2

- Option 1: Incorrect. This is a copper-pair fault.
- Option 2: Correct. This can pass simple continuity while harming balance.
- Option 3: Incorrect. That is the desired arrangement.
- Option 4: Incorrect. It is a wiring defect.

**DCCA-Q0244 · single · mechanism**

Why limit untwisting at a termination?

1. Untwisting always lowers insertion loss enough to help
2. Pair geometry affects crosstalk and balance
3. Twisted pairs carry no high-frequency signals
4. Twist exists only for appearance

**Correct option(s):** 2

- Option 1: Incorrect. It can worsen other critical parameters.
- Option 2: Correct. Excess untwist degrades the designed structure.
- Option 3: Incorrect. They support data transmission.
- Option 4: Incorrect. It supports electrical performance.

**DCCA-Q0245 · single · mechanism**

What does insertion loss describe?

1. Signal attenuation through the path
2. Only reflected energy
3. The source's DHCP lease duration
4. The number of inserted racks

**Correct option(s):** 1

- Option 1: Correct. The received signal is reduced relative to the input.
- Option 2: Incorrect. Return loss addresses reflections.
- Option 3: Incorrect. That is an application/network service parameter.
- Option 4: Incorrect. That is unrelated.

**DCCA-Q0246 · single · mechanism**

What does return loss relate to?

1. Reflections caused by impedance discontinuities
2. Only PoE battery runtime
3. Total room cooling loss
4. Cable purchase returns

**Correct option(s):** 1

- Option 1: Correct. Mismatch reflects some signal energy.
- Option 2: Incorrect. That is electrical energy storage.
- Option 3: Incorrect. That is thermal.
- Option 4: Incorrect. This is not a commercial metric.

**DCCA-Q0247 · single · mechanism**

What does a link light establish most directly?

1. Future upgrades are guaranteed
2. Every application is functioning
3. All cable parameters meet certification limits
4. Some physical link negotiation has succeeded

**Correct option(s):** 4

- Option 1: Incorrect. Higher rates may have stricter requirements.
- Option 2: Incorrect. Higher-layer delivery remains separate.
- Option 3: Incorrect. A link light is not a certification report.
- Option 4: Correct. It does not certify the complete channel margin.

**DCCA-Q0248 · single · mechanism**

Why verify the intended application rather than assume one universal cable distance?

1. Short cables need no correct termination
2. Every cable category is identical
3. Distance never affects transmission
4. Rate, category and channel conditions affect support

**Correct option(s):** 4

- Option 1: Incorrect. Termination quality matters at any length.
- Option 2: Incorrect. Performance classes differ.
- Option 3: Incorrect. Attenuation and other properties depend on length.
- Option 4: Correct. A familiar distance is not universal for every application.

**DCCA-Q0249 · single · mechanism**

What can crushed cable change?

1. Only the printed label
2. The IP protocol version directly
3. Pair geometry and transmission characteristics
4. The UPS frequency

**Correct option(s):** 3

- Option 1: Incorrect. Damage can affect internal structure.
- Option 2: Incorrect. That is a logical configuration.
- Option 3: Correct. Mechanical damage can alter electrical behavior.
- Option 4: Incorrect. The cable fault is unrelated to source frequency.

**DCCA-Q0250 · single · mechanism**

Why does PoE require more than data-link verification?

1. PoE delivers energy without conductors
2. Data certification guarantees every power class
3. Powered devices never have startup demand
4. Power budget and thermal behavior also matter

**Correct option(s):** 4

- Option 1: Incorrect. It uses the copper path.
- Option 2: Incorrect. Power support has additional requirements.
- Option 3: Incorrect. Startup and peak demand can matter.
- Option 4: Correct. The cable and connectors carry current.

**DCCA-Q0251 · single · diagnosis**

A switch has 300 W available PoE budget and devices require 360 W. What is the issue?

Synthetic educational evidence; not field measurements.

Available aggregate PoE budget: 300 W
Required device demand: 360 W

1. Every device will necessarily draw zero
2. The source power budget is insufficient
3. The rack has too many U-spaces
4. The cable category automatically adds 60 W

**Correct option(s):** 2

- Option 1: Incorrect. Allocation behavior depends on the system.
- Option 2: Correct. Port capability alone does not create aggregate capacity.
- Option 3: Incorrect. Space does not address the electrical budget.
- Option 4: Incorrect. Cabling cannot create source power.

**DCCA-Q0252 · single · mechanism**

Why retain tester limit-set information?

1. Only the operator's name determines pass/fail
2. The tester model alone proves the selected limits
3. Pass/fail depends on the selected standard and configuration
4. All limit sets are identical

**Correct option(s):** 3

- Option 1: Incorrect. The measured parameters and limits are central.
- Option 2: Incorrect. Configuration still matters.
- Option 3: Correct. A result without its limits is ambiguous.
- Option 4: Incorrect. Different applications impose different criteria.

**DCCA-Q0253 · single · mechanism**

Which test best addresses end-to-end conductor assignment?

1. Wiremap
2. Application login test alone
3. Fuel-level inspection
4. Room humidity survey

**Correct option(s):** 1

- Option 1: Correct. It checks the connection relationship.
- Option 2: Incorrect. A login does not reveal the full wire assignment.
- Option 3: Incorrect. That is unrelated to cabling.
- Option 4: Incorrect. That is environmental.

**DCCA-Q0254 · single · mechanism**

A new patch cord is added after permanent-link certification. What should be considered?

1. The old result covers every possible cord
2. The assembled channel needs appropriate verification
3. All fixed cabling must necessarily be replaced
4. Certification becomes meaningless forever

**Correct option(s):** 2

- Option 1: Incorrect. It does not.
- Option 2: Correct. The tested boundary has changed.
- Option 3: Incorrect. The defect may be in the added component.
- Option 4: Incorrect. A properly defined retest can restore evidence.

**DCCA-Q0255 · single · mechanism**

What is crosstalk?

1. A switch management password
2. Desired differential signaling within one pair
3. Unwanted coupling from another signal path
4. A power outage at the utility

**Correct option(s):** 3

- Option 1: Incorrect. That is an access-control value.
- Option 2: Incorrect. That is the intended transmission mechanism.
- Option 3: Correct. It can interfere with the intended pair signal.
- Option 4: Incorrect. That is a different phenomenon.

**DCCA-Q0256 · single · mechanism**

Why follow shielded-cabling bonding requirements?

1. Shielding guarantees no possible interference
2. Shielding makes all installation rules irrelevant
3. Shields replace every protective conductor
4. The installed shield system needs a defined electrical arrangement

**Correct option(s):** 4

- Option 1: Incorrect. No such universal guarantee follows.
- Option 2: Incorrect. It adds rather than removes requirements.
- Option 3: Incorrect. Their role must follow the design.
- Option 4: Correct. Improper installation can undermine intended performance and safety.

**DCCA-Q0257 · single · mechanism**

Which acceptance artifact best supports future troubleshooting?

1. An unlabelled pass screenshot
2. A cable purchase quantity only
3. A rack photograph from the front only
4. Labeled end-to-end records with test results and configuration

**Correct option(s):** 4

- Option 1: Incorrect. It cannot reliably identify the tested path.
- Option 2: Incorrect. Quantity does not show installed performance.
- Option 3: Incorrect. It may not expose the channel relationship.
- Option 4: Correct. It ties a physical path to evidence.

**DCCA-Q0258 · single · mechanism**

What can large PoE bundles introduce?

1. Zero conductor resistance
2. Automatic immunity to poor terminations
3. Guaranteed cooling improvement
4. Additional thermal considerations

**Correct option(s):** 4

- Option 1: Incorrect. Resistance remains present.
- Option 2: Incorrect. Connection quality still matters.
- Option 3: Incorrect. Bundling can impede heat dissipation.
- Option 4: Correct. Current and grouping can raise conductor temperatures.

**DCCA-Q0259 · single · mechanism**

Why is a successful low-rate link not proof of a higher-rate upgrade?

1. An upgrade changes only the screen label
2. Cable length becomes zero after negotiation
3. Higher-rate applications may require greater channel performance
4. Lower rates always use more demanding signaling

**Correct option(s):** 3

- Option 1: Incorrect. It can change signaling demands.
- Option 2: Incorrect. Physical properties remain.
- Option 3: Correct. Existing operation does not establish all future limits.
- Option 4: Incorrect. That is not a general rule.

**DCCA-Q0260 · single · mechanism**

What should happen after repairing a termination that failed certification?

1. Assume all nearby links also pass
2. Close the record based only on appearance
3. Retest the affected defined path and retain the result
4. Erase the original failure evidence

**Correct option(s):** 3

- Option 1: Incorrect. Each path needs its own evidence boundary.
- Option 2: Incorrect. Visual neatness does not prove transmission performance.
- Option 3: Correct. The correction needs verification.
- Option 4: Incorrect. History supports diagnosis and traceability.

#### Recall

**What distinguishes a channel test from a permanent-link test?**

The tested component boundary Correct. A channel includes applicable cords beyond the fixed link.

**Why can a continuity pass coexist with poor high-rate transmission?**

Correct connectivity does not prove transmission performance Correct. Loss and crosstalk can still exceed limits.

**What is a split pair?**

Conductors are connected but assigned across the wrong physical pairs Correct. This can pass simple continuity while harming balance.

**Why limit untwisting at a termination?**

Pair geometry affects crosstalk and balance Correct. Excess untwist degrades the designed structure.

**What does insertion loss describe?**

Signal attenuation through the path Correct. The received signal is reduced relative to the input.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DCCA-M14 — Fiber optics, loss budgets and polarity

### DCCA-L14 — Fiber optics, loss budgets and polarity

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L13

An optical link is a system comprising transmitter, fiber type, connectors, splices and receiver. Single-mode and multimode fibers guide light differently and use compatible optics for particular applications. A connector fitting mechanically does not prove that fiber type, wavelength, polarity, reach or optical power are correct. Parallel-optic applications also depend on lane mapping and the specified connector arrangement.

A loss budget compares available transmitter power with receiver sensitivity, then accounts for path attenuation and engineering margin. Express powers in dBm and gains or losses in dB. If minimum launch power is −3 dBm and receiver sensitivity is −10 dBm, the nominal available loss is 7 dB before required margin. Subtract connector, splice and fiber losses using the appropriate values. Also check receiver overload: a very short or amplified path can deliver too much power for an optic.

Polarity connects each transmit lane to the intended receive lane. Duplex links and parallel-lane systems use different mapping arrangements. Trace the actual end-to-end path, including cassettes and trunks; matching connector color is insufficient. A path can have acceptable loss yet fail because the transmit/receive relationship is wrong.

Contamination on an end face can add loss and reflection or damage a connection. Follow an inspect-clean-inspect process with appropriate tools and safe practices; never view an active optical path directly. A dust cap is useful protection but does not certify cleanliness. Bend radius, pulling tension and installation environment affect integrity; verify the cable manufacturer's limits.

Optical-loss testing establishes end-to-end attenuation at defined wavelengths and references. An OTDR helps locate events along a fiber but has interpretation limits, dead zones and launch/receive requirements. The methods answer different questions and should not be treated as interchangeable. Record fiber identifiers, polarity, wavelength, reference method and results. Application-level error counters and traffic testing add operational evidence after physical acceptance.

### Work an optical budget and a separate polarity check
Assume minimum transmit power is −4 dBm and receiver sensitivity is −11 dBm, giving 7 dB available loss. The planned path has 2 dB fiber loss, four connections totaling 2 dB, and 1 dB required reserve: 5 dB is consumed, leaving 2 dB. If two additional connections add 1.5 dB each, the revised total is 8 dB and the design fails by 1 dB.

This arithmetic still does not establish receiver overload or polarity. Check the maximum transmitter output and minimum path loss against the receiver's upper limit. Then trace each transmit lane through patch cords, trunks and cassettes to the intended receive lane. A low-loss path to the wrong lane remains unusable.

For a failed link, start with compatible optics and media, safe end-face inspection, correct mapping and measured power or loss. Use an OTDR when location of an event matters, with its launch/receive and dead-zone limitations understood. Finish with traffic and error observations at the required rate. Each step narrows a different class of fault.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. Minimum transmitter output is −3 dBm and receiver sensitivity is −10 dBm. Estimated path loss is 4 dB and required margin is 2 dB.

**Reasoning:** The available budget is 7 dB. Path plus margin consumes 6 dB, leaving 1 dB. Separately verify overload, fiber/optic compatibility and polarity.

#### Guided practice

A fiber has acceptable attenuation but both transmitters face one another. What prevents the link?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** Incorrect polarity: each transmit path must reach the intended receiver.

#### Independent task

Environment: analytical

Prepare an optical acceptance sheet with loss budget and lane map.

**Packaged starter material**

- course_labs/DCCA/README.md
- course_labs/DCCA/scenario.json
- course_labs/DCCA/answers-template.json

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Separate dB from dBm.
- Check sensitivity, overload and margin.
- Document clean end faces, polarity and test boundaries.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0261 · single · mechanism**

What does dBm express?

1. Fiber length in meters
2. Absolute optical power relative to one milliwatt
3. Connector count
4. A dimensionless loss ratio only

**Correct option(s):** 2

- Option 1: Incorrect. Length uses distance units.
- Option 2: Correct. It is a power level.
- Option 3: Incorrect. It is not a count.
- Option 4: Incorrect. That is expressed in dB.

**DCCA-Q0262 · single · mechanism**

What does dB commonly express in a link budget?

1. Fiber core diameter
2. Absolute power relative to one watt only
3. Packet rate
4. A gain or loss ratio

**Correct option(s):** 4

- Option 1: Incorrect. That uses length units.
- Option 2: Incorrect. The reference must be specified for absolute power.
- Option 3: Incorrect. That is a traffic quantity.
- Option 4: Correct. It compares power levels logarithmically.

**DCCA-Q0263 · single · diagnosis**

Minimum launch is −3 dBm and sensitivity is −10 dBm. What nominal loss budget is available?

Synthetic educational evidence; not field measurements.

Minimum optical launch: −3 dBm
Receiver sensitivity: −10 dBm

1. 13 dB
2. 3 dB
3. −13 dB
4. 7 dB

**Correct option(s):** 4

- Option 1: Incorrect. The magnitude sum is not the difference.
- Option 2: Incorrect. That ignores receiver sensitivity.
- Option 3: Incorrect. Adding the signed powers is incorrect.
- Option 4: Correct. The difference is minus three minus minus ten.

**DCCA-Q0264 · single · diagnosis**

A 7 dB budget must include 4 dB path loss and 2 dB margin. What headroom remains?

Synthetic educational evidence; not field measurements.

Available optical budget: 7 dB
Path loss: 4 dB
Required reserve: 2 dB

1. 1 dB
2. 6 dB
3. 13 dB
4. 3 dB

**Correct option(s):** 1

- Option 1: Correct. Seven minus four minus two equals one.
- Option 2: Incorrect. That is consumed budget rather than remaining headroom.
- Option 3: Incorrect. Adding losses to available budget is incorrect.
- Option 4: Incorrect. That omits the required margin.

**DCCA-Q0265 · single · mechanism**

Why check receiver overload as well as sensitivity?

1. Sensitivity already defines every upper limit
2. Excessive received power can also violate the optic's limits
3. Receivers accept unlimited optical power
4. Overload concerns only cable length labels

**Correct option(s):** 2

- Option 1: Incorrect. It is a lower reception threshold.
- Option 2: Correct. More power is not always acceptable.
- Option 3: Incorrect. They have operating limits.
- Option 4: Incorrect. It concerns received power.

**DCCA-Q0266 · single · mechanism**

A connector fits but the optic and fiber type are incompatible. What is established?

1. Mechanical fit only
2. Guaranteed link operation
3. Sufficient power margin
4. Correct lane mapping

**Correct option(s):** 1

- Option 1: Correct. Optical compatibility remains unresolved.
- Option 2: Incorrect. Fit does not establish wavelength or mode compatibility.
- Option 3: Incorrect. No loss evidence has been supplied.
- Option 4: Incorrect. Connector fit does not prove polarity.

**DCCA-Q0267 · single · mechanism**

What does fiber polarity ensure?

1. All connectors are clean
2. The rack has two power feeds
3. Transmit lanes reach the intended receive lanes
4. Every fiber has zero attenuation

**Correct option(s):** 3

- Option 1: Incorrect. Mapping does not prove cleanliness.
- Option 2: Incorrect. Optical polarity is separate from electrical supply.
- Option 3: Correct. The end-to-end mapping must be correct.
- Option 4: Incorrect. Polarity does not remove loss.

**DCCA-Q0268 · single · mechanism**

A link has low attenuation but transmit faces transmit. What is the likely issue?

1. Incorrect polarity
2. Insufficient rack floor loading
3. Excessive insertion loss necessarily
4. A guaranteed receiver overload

**Correct option(s):** 1

- Option 1: Correct. The receiver does not see the intended transmitter.
- Option 2: Incorrect. That is unrelated to the optical mapping.
- Option 3: Incorrect. The supplied attenuation is acceptable.
- Option 4: Incorrect. The evidence does not establish excessive received power.

**DCCA-Q0269 · single · mechanism**

Why inspect after cleaning a fiber end face?

1. Cleaning always guarantees a perfect surface
2. A dust cap proves the connector is clean
3. Cleaning can leave or move contamination
4. Inspection adds optical power

**Correct option(s):** 3

- Option 1: Incorrect. It does not.
- Option 2: Incorrect. Caps themselves can carry contamination.
- Option 3: Correct. The result must be verified.
- Option 4: Incorrect. It observes rather than amplifies.

**DCCA-Q0270 · single · mechanism**

What is an OTDR particularly useful for?

1. Assigning IP addresses
2. Locating optical events along a fiber
3. Replacing every end-to-end loss test
4. Measuring electrical branch current

**Correct option(s):** 2

- Option 1: Incorrect. That is a network configuration task.
- Option 2: Correct. It estimates distance to reflections and loss events.
- Option 3: Incorrect. Its measurement purpose and limitations differ.
- Option 4: Incorrect. It is an optical instrument.

**DCCA-Q0271 · single · mechanism**

What does an optical-loss test measure?

1. The cable's floor load
2. End-to-end attenuation under a defined reference method
3. Exact location of every event without further methods
4. The server's application response time

**Correct option(s):** 2

- Option 1: Incorrect. That is mechanical.
- Option 2: Correct. It assesses the path loss.
- Option 3: Incorrect. Location is more directly associated with OTDR analysis.
- Option 4: Incorrect. That is a higher-layer measurement.

**DCCA-Q0272 · single · mechanism**

Why record test wavelength?

1. Wavelength is only a cosmetic label
2. The test wavelength sets room humidity
3. Fiber loss and application behavior depend on wavelength
4. All wavelengths have identical attenuation

**Correct option(s):** 3

- Option 1: Incorrect. It is a physical signal property.
- Option 2: Incorrect. That is unrelated.
- Option 3: Correct. A result applies to specified optical conditions.
- Option 4: Incorrect. They can differ.

**DCCA-Q0273 · single · mechanism**

What should accompany parallel-optic installation?

1. A lane mapping verified across trunks and cassettes
2. Only a low-loss result on one lane
3. Only one successful lane test
4. A copper wiremap result

**Correct option(s):** 1

- Option 1: Correct. Multiple paths must align with the application.
- Option 2: Incorrect. Parallel applications require correct mapping and performance across all required lanes.
- Option 3: Incorrect. Other lanes can still be wrong.
- Option 4: Incorrect. That does not test optical lanes.

**DCCA-Q0274 · single · mechanism**

Why respect fiber bend limits?

1. Bending always improves coupling
2. Bend radius matters only to labels
3. Excess bending can increase loss or damage the cable
4. Fiber is immune to mechanical stress

**Correct option(s):** 3

- Option 1: Incorrect. It can degrade guidance.
- Option 2: Incorrect. It affects the fiber itself.
- Option 3: Correct. The physical path affects optical performance.
- Option 4: Incorrect. It has specified mechanical limits.

**DCCA-Q0275 · single · mechanism**

Which safety practice applies to an unknown optical path?

1. Look directly into the connector
2. Assume invisible light means no power
3. Treat it as potentially active and use approved inspection methods
4. Use a finger to measure wavelength

**Correct option(s):** 3

- Option 1: Incorrect. Activity may be invisible.
- Option 2: Incorrect. Many wavelengths are not visible.
- Option 3: Correct. Direct viewing can expose eyes to optical energy.
- Option 4: Incorrect. That cannot establish safe optical conditions.

**DCCA-Q0276 · single · mechanism**

What is engineering margin in a loss budget?

1. A guarantee of unlimited connectors
2. Reserved allowance for uncertainty and future degradation
3. Extra signal loss that must be installed
4. The difference between rack heights

**Correct option(s):** 2

- Option 1: Incorrect. Added components still consume loss.
- Option 2: Correct. It prevents consuming the entire nominal budget.
- Option 3: Incorrect. Margin is an allowance, not a required attenuator.
- Option 4: Incorrect. That is unrelated.

**DCCA-Q0277 · single · mechanism**

Which record supports fiber repair traceability?

1. Only the technician's preferred wavelength
2. An unlabelled trace file
3. Fiber identity, endpoints, event location and retest results
4. Only the optic invoice

**Correct option(s):** 3

- Option 1: Incorrect. Preference does not define the application.
- Option 2: Incorrect. It cannot reliably identify the repaired fiber.
- Option 3: Correct. It links the intervention to the actual path.
- Option 4: Incorrect. That does not show the installed path.

**DCCA-Q0278 · single · mechanism**

Why are optical error counters useful after physical testing?

1. They directly measure floor vibration
2. They show operational behavior under the actual link
3. Zero errors over one second guarantees lifetime reliability
4. They replace all physical inspection

**Correct option(s):** 2

- Option 1: Incorrect. That is not their primary quantity.
- Option 2: Correct. Physical acceptance and application traffic provide complementary evidence.
- Option 3: Incorrect. The observation interval is limited.
- Option 4: Incorrect. Contamination or margin issues may still need physical diagnosis.

**DCCA-Q0279 · single · mechanism**

What can an OTDR dead zone conceal?

1. Closely spaced events near a strong reflection
2. Battery runtime
3. Only IP routing loops
4. Every event anywhere on the fiber

**Correct option(s):** 1

- Option 1: Correct. Resolution limitations affect interpretation.
- Option 2: Incorrect. That is unrelated to optical traces.
- Option 3: Incorrect. Those are logical network events.
- Option 4: Incorrect. The limitation is not universally total blindness.

**DCCA-Q0280 · single · mechanism**

Which statement about a dust cap is defensible?

1. It corrects polarity automatically
2. It protects an interface but does not certify cleanliness
3. It provides optical gain
4. It guarantees zero contamination

**Correct option(s):** 2

- Option 1: Incorrect. It is not part of the live lane map.
- Option 2: Correct. Inspection remains necessary.
- Option 3: Incorrect. It is protective hardware, not an amplifier.
- Option 4: Incorrect. Caps can be dirty.

#### Recall

**What does dBm express?**

Absolute optical power relative to one milliwatt Correct. It is a power level.

**What does dB commonly express in a link budget?**

A gain or loss ratio Correct. It compares power levels logarithmically.

**Minimum launch is −3 dBm and sensitivity is −10 dBm. What nominal loss budget is available?**

7 dB Correct. The difference is minus three minus minus ten.

**A 7 dB budget must include 4 dB path loss and 2 dB margin. What headroom remains?**

1 dB Correct. Seven minus four minus two equals one.

**Why check receiver overload as well as sensitivity?**

Excessive received power can also violate the optic's limits Correct. More power is not always acceptable.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DCCA-M15 — Cabling architecture, routes and administration

### DCCA-L15 — Cabling architecture, routes and administration

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L14

Cabling architecture organizes connectivity into maintainable boundaries. Define where external carriers enter, where cross-connects occur, how backbone trunks reach distribution areas and how equipment cords reach racks. The chosen standard provides terminology and installation rules; the engineering purpose is stable infrastructure that can grow without uncontrolled point-to-point wiring.

Top-of-rack and end-of-row switching trade cable lengths, switch count, power, failure domains and operational access. Top-of-rack can shorten server copper runs but creates many distributed switches. End-of-row can consolidate switching but requires more horizontal cabling and careful pathway capacity. Neither is universally superior. Evaluate the actual server count, port speeds, oversubscription, growth, spare strategy and maintenance model.

Pathways must support cable capacity, bend limits, segregation, fire interfaces and access. A tray that is physically full can block expansion before ports or rack space run out. Separate logical redundancy from physical route diversity: two circuits through one entry room, riser or trench can fail together. Carrier names alone do not prove different underlying infrastructure.

Administration connects identifiers to physical reality. A useful record links cable ID, both endpoints, ports, pathway, media, test result and service owner. Labels should be durable and readable, and changes should update both ends plus the inventory. Avoid relying on color as the only identifier because colors can be reused or misinterpreted.

Moves, adds and changes need controlled impact review. Verify the correct circuit, preserve other services, inspect connectors, maintain bend limits and retest the changed path. Decommissioning requires identifying abandoned cables and removing them only through approved work; an apparently unused cable can still support an undocumented function. The objective is recoverable, inspectable infrastructure rather than a visually neat arrangement alone.

### Compare topology with an operating-cost and failure view
A 16-rack row needs 24 server connections per rack, or 384 access links. A top-of-rack design distributes switching across 16 locations and shortens local server runs. An end-of-row design concentrates switching and may reduce device count, but needs longer row pathways and can affect more servers when a shared switch is unavailable. Neither result can be chosen from switch count alone.

Add an uplink calculation. If a rack has 24 ports at 10 Gbit/s, their aggregate line rate is 240 Gbit/s. Two 40 Gbit/s uplinks provide 80 Gbit/s before any failover requirement, a 3:1 line-rate ratio. With one uplink unavailable, the ratio becomes 6:1. Whether this is acceptable depends on the traffic requirement, not on the ratio's appearance.

Document physical routes as well as logical links. Two uplinks in one tray share a damage domain; different carrier names may share a duct. Keep endpoint, route, media, test and owner records together so a future move can assess both service mapping and common-cause exposure.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. Two carrier services have different invoices but both enter through the same duct and building entry point.

**Reasoning:** Commercial supplier diversity is not physical route independence. Obtain and verify the route and shared-risk information for the required resilience claim.

#### Guided practice

A row has spare switch ports but its cable tray is at its approved fill limit. Can new cables be accepted solely because ports are free?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** No. Pathway capacity is an independent constraint that must be resolved.

#### Independent task

Environment: analytical

Compare top-of-rack and end-of-row for a synthetic 12-rack deployment.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Discuss failure domain, cabling, power and service access.
- Identify route common causes.
- Produce an endpoint and pathway record.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0281 · single · diagnosis**

Two carriers use the same building-entry duct. What remains common?

Synthetic educational evidence; not field measurements.

Carrier A route: entry duct D1
Carrier B route: entry duct D1
Commercial contracts are separate.

1. Their corporate ownership by definition
2. Their commercial billing systems necessarily
3. The physical entry failure domain
4. Every router configuration

**Correct option(s):** 3

- Option 1: Incorrect. Shared ducting does not prove common ownership.
- Option 2: Incorrect. The evidence concerns physical route sharing.
- Option 3: Correct. One duct event can affect both services.
- Option 4: Incorrect. Different services can use different configurations.

**DCCA-Q0282 · single · mechanism**

What is a typical top-of-rack tradeoff?

1. Short server runs with more distributed switches
2. All failure domains disappear
3. No switches are required
4. Backbone cabling becomes unnecessary

**Correct option(s):** 1

- Option 1: Correct. This changes both cabling and operations.
- Option 2: Incorrect. Rack switches still create dependencies.
- Option 3: Incorrect. Top-of-rack explicitly places switching near racks.
- Option 4: Incorrect. Uplinks still connect the rack to the network.

**DCCA-Q0283 · single · mechanism**

What is a typical end-of-row tradeoff?

1. There is no shared switch risk
2. Power planning becomes irrelevant
3. Consolidated switching with more row cabling
4. Every server cable is always shorter

**Correct option(s):** 3

- Option 1: Incorrect. Consolidation can enlarge a failure domain.
- Option 2: Incorrect. Switches still need suitable power.
- Option 3: Correct. The physical connection distances and pathways change.
- Option 4: Incorrect. Compared with local switching, runs can be longer.

**DCCA-Q0284 · single · mechanism**

Why can cable-tray capacity block expansion?

1. Trays create network addresses
2. Cable diameter is always zero in planning
3. Empty rack units automatically increase tray capacity
4. Pathway fill and installation limits constrain additional cables

**Correct option(s):** 4

- Option 1: Incorrect. They are physical pathways.
- Option 2: Incorrect. Physical volume matters.
- Option 3: Incorrect. The resources are separate.
- Option 4: Correct. Free ports do not guarantee a supported route.

**DCCA-Q0285 · single · mechanism**

Which record best supports circuit tracing?

1. Only the original installation date
2. Only the switch-facing port description
3. Only the customer's name
4. Cable ID, endpoints, ports, route and test result

**Correct option(s):** 4

- Option 1: Incorrect. Date does not identify the current endpoints and path.
- Option 2: Incorrect. One endpoint description omits the remote end and physical route.
- Option 3: Incorrect. That does not locate the physical circuit.
- Option 4: Correct. Together they identify the actual path and evidence.

**DCCA-Q0286 · single · mechanism**

Why identify carrier demarcation points?

1. They define responsibility and service handoff boundaries
2. They eliminate all customer cabling
3. They determine every server's IP address
4. They guarantee complete route diversity

**Correct option(s):** 1

- Option 1: Correct. Troubleshooting and acceptance need clear ownership.
- Option 2: Incorrect. A local path still connects the service.
- Option 3: Incorrect. Address assignment is a separate design decision.
- Option 4: Incorrect. The demarc alone does not reveal the upstream path.

**DCCA-Q0287 · single · mechanism**

What should precede removal of an apparently abandoned cable?

1. Remove all cables not shown on an old drawing
2. Assume an unplugged-looking end is sufficient
3. Cut it because no label is visible
4. Verify identity, ownership and actual service impact

**Correct option(s):** 4

- Option 1: Incorrect. The drawing may be stale; actual use and ownership must be resolved.
- Option 2: Incorrect. The full path and ownership need confirmation.
- Option 3: Incorrect. Missing labels do not prove nonuse.
- Option 4: Correct. Undocumented use can exist.

**DCCA-Q0288 · single · mechanism**

Which design question helps compare ToR and EoR?

1. Which option avoids all documentation
2. Required port count, failure domain and lifecycle operation
3. Which option minimizes switch count without checking uplinks
4. Which name sounds newer

**Correct option(s):** 2

- Option 1: Incorrect. Both need records.
- Option 2: Correct. The topology choice affects several constraints.
- Option 3: Incorrect. Consolidation can introduce bandwidth or failure-domain limits.
- Option 4: Incorrect. Novelty does not establish suitability.

**DCCA-Q0289 · single · mechanism**

Why update both cable ends after a move?

1. Either end may be the starting point for future tracing
2. Only the source end can fail
3. Labels are useful only during installation
4. One end determines all labels automatically

**Correct option(s):** 1

- Option 1: Correct. Partial updates create ambiguity.
- Option 2: Incorrect. Either side can need service.
- Option 3: Incorrect. They remain important in operations.
- Option 4: Incorrect. Physical labels do not update themselves.

**DCCA-Q0290 · single · mechanism**

What does a cross-connect boundary enable?

1. Automatic application authentication
2. Controlled interconnection and service changes
3. Removal of every patch cord
4. Unlimited distance without optical loss

**Correct option(s):** 2

- Option 1: Incorrect. Connectivity does not establish identity policy.
- Option 2: Correct. It organizes connection management.
- Option 3: Incorrect. Cross-connects often use managed patching.
- Option 4: Incorrect. Physical transmission limits remain.

**DCCA-Q0291 · single · mechanism**

Why retain pathway information with circuit records?

1. Shared physical risks may not be visible from endpoints
2. Pathways replace loss testing
3. Pathways determine software versions
4. Endpoints are always sufficient for resilience analysis

**Correct option(s):** 1

- Option 1: Correct. Two independent ports can share a vulnerable route.
- Option 2: Incorrect. Physical route and signal quality are different evidence.
- Option 3: Incorrect. That is unrelated.
- Option 4: Incorrect. They omit intermediate common causes.

**DCCA-Q0292 · single · mechanism**

A patch move maintains link light but connects the wrong service. What failed?

1. Every optical component necessarily
2. The branch electrical rating
3. Endpoint identity verification
4. Room cooling by definition

**Correct option(s):** 3

- Option 1: Incorrect. The link can be physically healthy.
- Option 2: Incorrect. It is unrelated to service selection.
- Option 3: Correct. Physical connectivity is not correct service mapping.
- Option 4: Incorrect. The described failure is logical/physical mapping.

**DCCA-Q0293 · single · mechanism**

What does structured cabling seek to avoid?

1. Every future upgrade
2. All equipment-specific interfaces
3. All use of patch cords
4. Uncontrolled ad hoc connections that are hard to trace and change

**Correct option(s):** 4

- Option 1: Incorrect. Scalability is a goal.
- Option 2: Incorrect. Equipment still needs compatible connections.
- Option 3: Incorrect. Managed patching is a normal function.
- Option 4: Correct. A stable architecture supports lifecycle work.

**DCCA-Q0294 · single · mechanism**

Why consider oversubscription in a rack-switch design?

1. Uplink capacity can constrain aggregate server traffic
2. Every server always sends at line rate
3. Physical port count alone proves aggregate throughput
4. More racks always reduce traffic

**Correct option(s):** 1

- Option 1: Correct. Port count alone does not establish throughput.
- Option 2: Incorrect. Workload assumptions must be stated rather than assumed.
- Option 3: Incorrect. The uplink can be narrower than the sum of access ports.
- Option 4: Incorrect. Aggregate demand can grow.

**DCCA-Q0295 · single · mechanism**

Which activity belongs in a cabling change acceptance?

1. Only photograph neatness
2. Only close the ticket
3. Verify identity, physical performance and intended service
4. Only test an unrelated spare link

**Correct option(s):** 3

- Option 1: Incorrect. Appearance is not complete acceptance.
- Option 2: Incorrect. Administrative closure does not demonstrate function.
- Option 3: Correct. All three boundaries matter.
- Option 4: Incorrect. The changed path needs evidence.

**DCCA-Q0296 · single · mechanism**

What is a shared-risk link group conceptually useful for?

1. Grouping cables only by invoice date
2. Assigning all paths one password
3. Grouping paths exposed to one common failure cause
4. Replacing physical route verification

**Correct option(s):** 3

- Option 1: Incorrect. Dates do not define failure correlation.
- Option 2: Incorrect. That is unrelated and can add risk.
- Option 3: Correct. It supports resilience analysis.
- Option 4: Incorrect. The grouping must be grounded in real paths.

**DCCA-Q0297 · single · mechanism**

Why keep spare capacity visible in cabling plans?

1. Growth can be limited by ports, pathways or cross-connect space
2. Spare capacity removes maintenance needs
3. Installed spare fibers guarantee future optic compatibility
4. Only empty cabinets matter

**Correct option(s):** 1

- Option 1: Correct. Several resources can become bottlenecks.
- Option 2: Incorrect. Infrastructure still ages and changes.
- Option 3: Incorrect. Applications and optics still need review.
- Option 4: Incorrect. Connectivity resources also constrain growth.

**DCCA-Q0298 · single · mechanism**

What can happen if power and communications routes are placed without interface review?

1. Labels become self-correcting
2. Electrical protection becomes unnecessary
3. Every data cable gains bandwidth
4. Interference, access or safety constraints may be violated

**Correct option(s):** 4

- Option 1: Incorrect. Documentation still requires maintenance.
- Option 2: Incorrect. Protection remains essential.
- Option 3: Incorrect. No such benefit follows.
- Option 4: Correct. Separation and installation rules depend on the system.

**DCCA-Q0299 · single · mechanism**

A route drawing differs from field observations. What is the proper response?

1. Resolve and control the as-built discrepancy
2. Use whichever drawing is prettier
3. Assume field conditions cannot change
4. Ignore it if normal traffic works

**Correct option(s):** 1

- Option 1: Correct. Resilience claims need actual route evidence.
- Option 2: Incorrect. Appearance is not authority.
- Option 3: Incorrect. Changes and undocumented work occur.
- Option 4: Incorrect. A hidden common cause may remain.

**DCCA-Q0300 · single · mechanism**

Why include service ownership in cable records?

1. Owner names replace port identifiers
2. Changes and incidents need an accountable contact and impact decision
3. Ownership changes optical attenuation
4. Only owners can generate photons

**Correct option(s):** 2

- Option 1: Incorrect. Both organizational and physical data are needed.
- Option 2: Correct. Technical tracing alone does not establish authority.
- Option 3: Incorrect. It is a governance relation.
- Option 4: Incorrect. Transmitters generate the signal.

#### Recall

**Two carriers use the same building-entry duct. What remains common?**

The physical entry failure domain Correct. One duct event can affect both services.

**What is a typical top-of-rack tradeoff?**

Short server runs with more distributed switches Correct. This changes both cabling and operations.

**What is a typical end-of-row tradeoff?**

Consolidated switching with more row cabling Correct. The physical connection distances and pathways change.

**Why can cable-tray capacity block expansion?**

Pathway fill and installation limits constrain additional cables Correct. Free ports do not guarantee a supported route.

**Which record best supports circuit tracing?**

Cable ID, endpoints, ports, route and test result Correct. Together they identify the actual path and evidence.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DCCA-M16 — Fire hazards, compartments and detection

### DCCA-L16 — Fire hazards, compartments and detection

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L15

Fire protection combines prevention, detection, containment, suppression and human response. The fire triangle describes fuel, oxygen and heat; removing a required element can interrupt combustion, but the appropriate action depends on the material and approved response. Electrical faults, overheated connections, combustible storage and external exposures create different initiating conditions. Housekeeping and maintenance reduce hazards before a detector operates.

Compartmentation limits spread through rated construction and protected penetrations. A cable opening left unsealed can defeat the intended boundary even though the wall itself has a rating. Building fire design remains a specialist and authority-controlled discipline; the data-center operator owns the interface records, impairment reporting and coordination rather than improvising structural fire solutions.

Detection methods observe different phenomena. Smoke detection can use point devices or air-sampling systems; heat detection responds to thermal conditions. Air movement, sampling-pipe layout, obstruction and detector placement affect when a signal is observed. Early-warning detection supports investigation but does not automatically mean suppression should discharge on every initial signal. The cause-and-effect matrix defines the approved response to each stage.

A detection chain includes sensor, panel, power, communications, annunciation, notification and human action. A panel alarm without a received notification is an incomplete operational function. Test each intended stage under approved arrangements while managing unwanted discharge and service disruption. Synthetic signal injection demonstrates selected logic paths; it does not prove actual smoke transport to a detector.

Impairment is a controlled state. If a detector zone is isolated for work, record affected coverage, authority, compensating measures, duration and restoration evidence. An acknowledged alarm remains an unresolved condition until its cause and required response are addressed. Keep emergency exits, signage and access available; equipment uptime never authorizes obstructing life-safety routes.

### Test the detection chain without overstating the result
Suppose a test input creates a local panel alarm at 10:00:00, the gateway records it at 10:00:02, and the duty phone receives it at 10:00:07. The observed notification delay is seven seconds from the injected input under those conditions. If the requirement is ten seconds, that part of the chain passes. The test says nothing about how quickly real smoke would reach the detector because the stimulus bypassed transport and sensing.

A separate approved physical test addresses that earlier part. Keep the two results linked rather than pretending one replaces the other. Also test fault or impairment reporting: a disconnected sampling pipe can remove readiness without a fire alarm. Operators need to distinguish a process event from a protection-system fault.

After work, restore isolated zones and verify their effective normal state. An alarm list that is empty because the entire zone remains disabled is not a successful restoration. Record coverage, compensating arrangements and expiry for every impairment so life-safety dependencies remain visible during ordinary maintenance.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A wall penetration is enlarged for new cables. The fire alarm remains healthy, but the approved firestop has not been restored.

**Reasoning:** The detection system status does not establish compartment integrity. The penetration is an impairment requiring the approved firestop restoration and inspection process.

#### Guided practice

A test alarm appears locally but no duty operator receives notification. Which part of the function has failed?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** The annunciation-to-response chain is incomplete even though sensing or panel logic may have worked.

#### Independent task

Environment: analytical

Build a fire-detection cause-and-effect acceptance matrix.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Separate detection stages from suppression commands.
- Include notification receipt and impairment restoration.
- Distinguish signal simulation from physical detection tests.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0301 · single · mechanism**

Which three elements form the basic fire triangle?

1. Fuel, oxygen and heat
2. Temperature, humidity and airflow
3. Water, pressure and flow
4. Voltage, current and resistance

**Correct option(s):** 1

- Option 1: Correct. Combustion requires the relevant combination.
- Option 2: Incorrect. They affect conditions but are not the fire triangle.
- Option 3: Incorrect. Those describe a hydraulic system.
- Option 4: Incorrect. Those are electrical quantities.

**DCCA-Q0302 · single · mechanism**

A fire-rated wall has an unsealed cable opening. What is compromised?

1. Every detector's calibration necessarily
2. Only the cable inventory
3. The UPS battery rating
4. The intended compartment boundary

**Correct option(s):** 4

- Option 1: Incorrect. The opening does not prove sensor calibration failure.
- Option 2: Incorrect. The physical protection is also affected.
- Option 3: Incorrect. That is unrelated to the penetration.
- Option 4: Correct. The opening can permit spread through the barrier.

**DCCA-Q0303 · single · mechanism**

Why can detector placement affect response?

1. Smoke and heat must reach the sensing location
2. Labels determine smoke movement
3. Every location sees a fire simultaneously
4. Every detector sees the same smoke concentration throughout the room

**Correct option(s):** 1

- Option 1: Correct. Airflow and obstructions influence transport.
- Option 2: Incorrect. Labels do not control transport.
- Option 3: Incorrect. Transport and geometry create differences.
- Option 4: Incorrect. Transport and dilution vary with location and airflow.

**DCCA-Q0304 · single · mechanism**

What does an air-sampling detector depend on?

1. Only the room's average rack height
2. Sampling paths that deliver representative air to the detector
3. A permanently open containment door
4. A direct electrical connection to every server

**Correct option(s):** 2

- Option 1: Incorrect. That does not establish sample delivery.
- Option 2: Correct. Pipe layout and condition affect detection.
- Option 3: Incorrect. That is not a universal requirement.
- Option 4: Incorrect. Sampling does not require that arrangement.

**DCCA-Q0305 · single · diagnosis**

A panel shows an alarm but the duty team receives no message. What failed operationally?

Synthetic educational evidence; not field measurements.

Detector/panel: alarm visible
Duty notification: no message received

1. The notification chain
2. Every smoke sensor necessarily
3. The fire triangle
4. The cable category

**Correct option(s):** 1

- Option 1: Correct. Detection alone has not produced the required human response.
- Option 2: Incorrect. The panel may have received a valid signal.
- Option 3: Incorrect. The physical combustion model is not the failed communications function.
- Option 4: Incorrect. That cannot be concluded from the evidence.

**DCCA-Q0306 · single · mechanism**

What should define the response to staged fire alarms?

1. Whichever response is fastest to improvise
2. The number of open helpdesk tickets
3. A generic server reboot policy
4. The approved cause-and-effect matrix

**Correct option(s):** 4

- Option 1: Incorrect. Unplanned actions can violate safety design.
- Option 2: Incorrect. That does not define life-safety behavior.
- Option 3: Incorrect. Fire response needs its own engineered logic.
- Option 4: Correct. Different stages can require different actions.

**DCCA-Q0307 · single · mechanism**

Why is signal injection not a complete smoke-detection test?

1. It cannot test any alarm logic
2. It bypasses physical smoke transport and sensing
3. It proves every detector is clean
4. It certifies the entire building automatically

**Correct option(s):** 2

- Option 1: Incorrect. It can test parts of the chain.
- Option 2: Correct. It exercises only selected downstream functions.
- Option 3: Incorrect. No physical contamination assessment is implied.
- Option 4: Incorrect. Certification requires broader evidence.

**DCCA-Q0308 · single · mechanism**

What must accompany a detector-zone isolation?

1. Only acknowledging existing alarms before the isolation
2. Authorized impairment controls and restoration plan
3. Permanent deletion of the zone
4. Silence with no record

**Correct option(s):** 2

- Option 1: Incorrect. Acknowledgment does not manage the lost detection coverage or restoration.
- Option 2: Correct. Coverage is reduced during the work.
- Option 3: Incorrect. Temporary work does not justify removing protection.
- Option 4: Incorrect. Untracked impairment creates hidden risk.

**DCCA-Q0309 · single · mechanism**

What is an acknowledged fire alarm?

1. Permission to ignore future alarms
2. Automatic restoration of all detectors
3. A received alarm whose underlying condition may remain
4. Proof that the fire is extinguished

**Correct option(s):** 3

- Option 1: Incorrect. Each alarm requires the defined response.
- Option 2: Incorrect. Isolation and faults can remain.
- Option 3: Correct. Acknowledgment is not repair or clearance.
- Option 4: Incorrect. The action does not establish physical state.

**DCCA-Q0310 · single · mechanism**

Why control combustible storage in technical rooms?

1. It can increase available fuel and obstruct access
2. It improves smoke-detector sensitivity
3. It substitutes for suppression
4. It guarantees higher cooling efficiency

**Correct option(s):** 1

- Option 1: Correct. Housekeeping affects prevention and response.
- Option 2: Incorrect. Additional fuel is not a detection improvement.
- Option 3: Incorrect. Prevention and suppression are complementary.
- Option 4: Incorrect. Stored materials can obstruct airflow.

**DCCA-Q0311 · single · mechanism**

Which action respects the programme's D1 boundary?

1. Coordinate specialist fire-barrier work and retain interface evidence
2. Independently certify wall fire resistance without competence
3. Ignore building interfaces entirely
4. Treat a rack drawing as a fire-engineering approval

**Correct option(s):** 1

- Option 1: Correct. The operator manages the dependency without claiming structural design authority.
- Option 2: Incorrect. That exceeds the defined scope and authority.
- Option 3: Incorrect. Dependencies still affect the data center.
- Option 4: Incorrect. The artifact does not establish that approval.

**DCCA-Q0312 · single · mechanism**

Why keep emergency exits clear during maintenance?

1. Redundant power removes evacuation requirements
2. Life-safety access remains required while work proceeds
3. Clear exits increase UPS kVA
4. Exit access matters only during audits

**Correct option(s):** 2

- Option 1: Incorrect. Electrical resilience does not replace life safety.
- Option 2: Correct. Service work does not remove evacuation needs.
- Option 3: Incorrect. They do not alter electrical ratings.
- Option 4: Incorrect. It matters whenever occupied.

**DCCA-Q0313 · single · mechanism**

Which detector responds primarily to thermal conditions?

1. A rack power meter
2. A fuel-level transmitter
3. Heat detector
4. An optical-loss tester

**Correct option(s):** 3

- Option 1: Incorrect. It measures electrical quantities.
- Option 2: Incorrect. It measures stored fuel quantity.
- Option 3: Correct. Its sensing basis is temperature or related thermal change.
- Option 4: Incorrect. It measures fiber performance.

**DCCA-Q0314 · single · mechanism**

What should a detection test record include?

1. Only the test start time
2. Stimulus, device response, panel state, notification and restoration
3. Only the contractor invoice
4. Only the alarm screenshot

**Correct option(s):** 2

- Option 1: Incorrect. That omits whether required functions worked.
- Option 2: Correct. The result should cover the defined chain.
- Option 3: Incorrect. Payment is not functional evidence.
- Option 4: Incorrect. It may omit notification and final state.

**DCCA-Q0315 · single · mechanism**

Why review airflow when evaluating smoke detection?

1. Air movement can dilute or redirect smoke before detection
2. Smoke moves independently of air in every case
3. Higher airflow guarantees earlier detection everywhere
4. Airflow only affects electrical protection

**Correct option(s):** 1

- Option 1: Correct. Transport affects observation.
- Option 2: Incorrect. That ignores fluid movement.
- Option 3: Incorrect. It can improve or delay arrival depending on paths.
- Option 4: Incorrect. It also affects smoke transport.

**DCCA-Q0316 · single · mechanism**

What is a suitable first interpretation of a detector fault?

1. Suppression must always discharge immediately
2. No action is needed if IT runs
3. A portion of detection capability may be impaired
4. A confirmed fire always exists

**Correct option(s):** 3

- Option 1: Incorrect. Response follows approved cause-and-effect logic.
- Option 2: Incorrect. Life-safety function is independent of IT uptime.
- Option 3: Correct. Fault state must be assessed and managed.
- Option 4: Incorrect. A device fault is not automatically a fire signal.

**DCCA-Q0317 · single · mechanism**

Why distinguish prevention from suppression?

1. They are interchangeable labels
2. Prevention reduces initiation while suppression addresses an event
3. Prevention eliminates the need for detection
4. Suppression prevents every ignition

**Correct option(s):** 2

- Option 1: Incorrect. Their functions differ.
- Option 2: Correct. They act at different stages.
- Option 3: Incorrect. Residual risk remains.
- Option 4: Incorrect. It normally responds after a condition occurs.

**DCCA-Q0318 · single · mechanism**

Which evidence supports restoration after detector maintenance?

1. Correct normal state and required functional checks
2. Absence of complaints
3. Work-order closure alone
4. A new label alone

**Correct option(s):** 1

- Option 1: Correct. The protection must be demonstrably returned to service.
- Option 2: Incorrect. No complaint does not prove detection readiness.
- Option 3: Incorrect. Administrative status is not functional restoration.
- Option 4: Incorrect. Identification does not prove sensing or communication.

**DCCA-Q0319 · single · mechanism**

What can an obstructed sampling pipe cause?

1. Correct firestop installation automatically
2. Reduced or delayed delivery of representative air
3. Increased battery capacity
4. Guaranteed improved sensitivity

**Correct option(s):** 2

- Option 1: Incorrect. Sampling and barrier integrity are separate.
- Option 2: Correct. The detector may not observe the intended zone properly.
- Option 3: Incorrect. That is unrelated.
- Option 4: Incorrect. The restriction can impair sampling.

**DCCA-Q0320 · single · mechanism**

Why avoid a universal response based only on the word alarm?

1. Alarm text replaces the cause-and-effect design
2. All alarms mean immediate suppression discharge
3. Different signals represent different conditions and required actions
4. All alarms are equally harmless

**Correct option(s):** 3

- Option 1: Incorrect. Text alone does not define the whole system behavior.
- Option 2: Incorrect. That is not universally correct.
- Option 3: Correct. The approved response depends on meaning and stage.
- Option 4: Incorrect. Some demand urgent action.

#### Recall

**Which three elements form the basic fire triangle?**

Fuel, oxygen and heat Correct. Combustion requires the relevant combination.

**A fire-rated wall has an unsealed cable opening. What is compromised?**

The intended compartment boundary Correct. The opening can permit spread through the barrier.

**Why can detector placement affect response?**

Smoke and heat must reach the sensing location Correct. Airflow and obstructions influence transport.

**What does an air-sampling detector depend on?**

Sampling paths that deliver representative air to the detector Correct. Pipe layout and condition affect detection.

**A panel shows an alarm but the duty team receives no message. What failed operationally?**

The notification chain Correct. Detection alone has not produced the required human response.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DCCA-M17 — Suppression, interlocks and emergency response

### DCCA-L17 — Suppression, interlocks and emergency response

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L16

Suppression systems apply an agent through an engineered delivery arrangement. Water-based systems remove heat and can be configured in different ways, including preaction arrangements used where unintended water release is a concern. A preaction system still requires understanding its specific detection, valve and sprinkler conditions; the label does not mean water can never enter the protected space unexpectedly.

Gaseous systems use an agent concentration and exposure arrangement suited to the hazard and occupied-space requirements. Agent quantity depends on the protected volume and specified design method, while leakage and openings affect retention. Room-integrity testing and pressure-relief provisions address different aspects of the enclosure response. Never derive a real discharge quantity from a generic classroom formula; the approved design and applicable authority govern it.

The cause-and-effect design may coordinate alarms, ventilation, dampers, door releases, power interfaces and agent release. Each action has consequences. Stopping airflow can help retain agent but can also affect equipment temperature; releasing access locks can preserve escape but change security state. Life safety and the approved fire strategy govern those interfaces. Cybersecurity controls must not casually block a required safety function.

Manual controls, abort arrangements and emergency power-off interfaces vary by site and jurisdiction. Their labels, authority and consequences must be understood before an event. A data-center engineer should know how to summon the authorized response, protect people and provide accurate state information; reading a course does not authorize suppression maintenance or electrical shutdown.

Acceptance includes the approved detection-to-release logic, supervisory faults, notification, interlocks and restoration. Tests must be planned to avoid unintended agent discharge or unsafe energy changes. A simulated release output proves selected logic, not installed nozzle performance or enclosure retention. After a real event, recovery requires authorization, atmosphere and equipment assessment, cause correction, rearming and functional verification rather than simply clearing the panel.

### Read a cause-and-effect matrix as a state machine
An illustrative matrix has three inputs: early warning, confirmed alarm and system trouble. Early warning may notify an operator; confirmed alarm may initiate approved interlocks and release logic; trouble may report reduced readiness. The actual matrix is site-specific and authority-controlled. The lesson is to separate input meaning, required output and operating state rather than equating every signal with one action.

For each output, ask what verifies it. A relay command is not proof that a damper moved; a valve indication may need functional evidence; a sent notification is not receipt. Some tests can use simulation to avoid unintended discharge, while physical delivery and enclosure performance require different approved evidence. Label those boundaries explicitly.

A new cable opening can leave every electronic test passing while reducing gaseous-agent retention. A containment modification can improve thermal separation while changing nozzle or detector interfaces. Change review must therefore include the physical enclosure and life-safety specialists, not only the monitoring screen. Return to service after an event requires authorized assessment and rearming, not simply clearing the alarm history.

### Classify the hazard before interpreting an extinguisher label
Fire classification identifies the burning material and, in some schemes, whether energized electrical equipment is involved. Common distinctions include ordinary solid combustibles, flammable liquids, gases, combustible metals and cooking oils or fats. The class letters and grouping are jurisdiction-specific; do not transfer a letter from one national scheme into another without the applicable approved reference.

The physical mechanism matters more than memorizing one unqualified letter. Water-based agents primarily remove heat, foam can separate suitable liquid fuels from air, some powders interrupt combustion processes, and gaseous agents act through their specified concentration and mechanism. Suitability depends on the actual fuel, energized equipment, people, enclosure and approved product. An agent that controls one hazard can create another, including electrical conduction, oxygen displacement, poor visibility or residue damage.

Portable equipment is therefore selected and located through the site's approved fire-risk and training arrangements. Staff must know whether their role is evacuation, notification or trained initial response; recognizing an extinguisher label is not permission to fight a fire. Preserve an escape route and follow the authorized emergency command. Detailed selection, spacing, discharge design and maintenance remain governed by the applicable authority and qualified specialists.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A gaseous system was designed for a defined room boundary. New cable penetrations and an unreviewed door opening change leakage.

**Reasoning:** Installed cylinder quantity alone no longer establishes retention performance. The enclosure changes require review and the appropriate integrity evidence.

#### Guided practice

A simulated release command activates the alarm relay. Does this prove the nozzle layout delivers the required concentration?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** No. It demonstrates part of the logic path, not physical agent distribution or retention.

#### Independent task

Environment: analytical

Prepare an interface test plan linking suppression to ventilation, access and notification.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Identify authorized test boundaries and safeguards.
- Separate simulated logic from physical performance evidence.
- Include post-event restoration and rearming acceptance.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0321 · single · mechanism**

What does water-based suppression primarily use to control fire?

1. Increasing oxygen concentration
2. Raising electrical voltage
3. Increasing fuel availability
4. Heat removal

**Correct option(s):** 4

- Option 1: Incorrect. That would not be the intended control mechanism.
- Option 2: Incorrect. That is not suppression.
- Option 3: Incorrect. That would worsen the hazard.
- Option 4: Correct. Water absorbs substantial thermal energy.

**DCCA-Q0322 · single · diagnosis**

Why does the term preaction not mean zero water-release risk?

Synthetic educational evidence; not field measurements.

System label: preaction
Actual valve and detection sequence: must be reviewed

1. Actual valve, detection and sprinkler conditions still govern operation
2. Preaction systems contain no water anywhere
3. The term guarantees perfect maintenance
4. Preaction means all detectors are bypassed

**Correct option(s):** 1

- Option 1: Correct. The arrangement must be understood and maintained.
- Option 2: Incorrect. The supply system still uses water.
- Option 3: Incorrect. No product label establishes that.
- Option 4: Incorrect. Detection can be part of the release arrangement.

**DCCA-Q0323 · single · mechanism**

What can changed room leakage affect in a gaseous system?

1. The printed cylinder serial number
2. The optical wavelength of network links
3. The UPS nominal voltage directly
4. Agent retention

**Correct option(s):** 4

- Option 1: Incorrect. Identity remains separate.
- Option 2: Incorrect. That is unrelated.
- Option 3: Incorrect. The leakage change is an enclosure issue.
- Option 4: Correct. Openings can prevent maintaining the intended concentration.

**DCCA-Q0324 · single · mechanism**

Why is cylinder quantity alone insufficient acceptance evidence?

1. Control logic automatically repairs leaks
2. Quantity is never relevant
3. Distribution, enclosure and control conditions also matter
4. Every room has the same volume

**Correct option(s):** 3

- Option 1: Incorrect. It does not restore enclosure integrity.
- Option 2: Incorrect. It is one necessary design input.
- Option 3: Correct. Agent must reach and remain in the intended volume.
- Option 4: Incorrect. Protected spaces differ.

**DCCA-Q0325 · single · mechanism**

What does a simulated release-output test demonstrate?

1. Actual room concentration
2. Enclosure hold time
3. Selected control and signaling functions
4. Nozzle flow performance

**Correct option(s):** 3

- Option 1: Incorrect. No agent distribution was measured.
- Option 2: Incorrect. A logic test does not measure leakage retention.
- Option 3: Correct. It does not physically discharge agent.
- Option 4: Incorrect. That requires appropriate physical evidence.

**DCCA-Q0326 · single · mechanism**

Why coordinate suppression with ventilation?

1. Stopping fans proves equipment will remain cool indefinitely
2. Ventilation has no relationship to fire response
3. Every fan must always run unchanged
4. Air movement can affect agent retention and smoke behavior

**Correct option(s):** 4

- Option 1: Incorrect. Thermal consequences still exist.
- Option 2: Incorrect. It can materially change conditions.
- Option 3: Incorrect. The correct action depends on the design.
- Option 4: Correct. The approved cause-and-effect strategy addresses this interface.

**DCCA-Q0327 · single · mechanism**

What is the primary purpose of approved emergency-response authority?

1. Eliminate the need for drills
2. Make every operator perform every shutdown
3. Replace all technical information
4. Ensure consequential actions follow the site's safety responsibilities

**Correct option(s):** 4

- Option 1: Incorrect. Practice remains useful.
- Option 2: Incorrect. Roles and competence differ.
- Option 3: Incorrect. Responders still need accurate state.
- Option 4: Correct. Knowledge alone is not authorization.

**DCCA-Q0328 · single · mechanism**

Why review access-control behavior during a fire event?

1. Fire detection automatically knows every person's location
2. Every door must remain locked regardless of life safety
3. Escape and responder access must work as designed
4. Access logs become permanently unnecessary

**Correct option(s):** 3

- Option 1: Incorrect. Accountability needs additional processes.
- Option 2: Incorrect. That can conflict with the approved strategy.
- Option 3: Correct. Security and life-safety interfaces interact.
- Option 4: Incorrect. Records can support response and investigation.

**DCCA-Q0329 · single · mechanism**

What must be known about an emergency power-off control?

1. Only whether the button mechanically moves
2. That it can be tested casually during service
3. That it always shuts down every source everywhere
4. Its actual scope, consequences and authorized use

**Correct option(s):** 4

- Option 1: Incorrect. Mechanical travel does not establish the actual shutdown boundary or consequences.
- Option 2: Incorrect. Consequences require controlled testing.
- Option 3: Incorrect. The actual design may be narrower or different.
- Option 4: Correct. Different sites connect different equipment and safety functions.

**DCCA-Q0330 · single · mechanism**

Which factor belongs in gaseous suppression design review?

1. Only server operating-system version
2. Only rack count
3. Protected volume and specified agent method
4. Only the number of installed cylinders without enclosure data

**Correct option(s):** 3

- Option 1: Incorrect. That does not determine the enclosure calculation.
- Option 2: Incorrect. Racks alone do not define the whole protected volume.
- Option 3: Correct. Quantity and concentration depend on defined design conditions.
- Option 4: Incorrect. Quantity cannot be assessed without protected volume, agent method and retention conditions.

**DCCA-Q0331 · single · mechanism**

Why retain pressure-relief considerations?

1. Agent discharge can affect enclosure pressure
2. It increases electrical runtime
3. It eliminates the need for room-integrity assessment
4. Pressure relief is identical to smoke detection

**Correct option(s):** 1

- Option 1: Correct. The enclosure response is part of the engineered system.
- Option 2: Incorrect. That is unrelated.
- Option 3: Incorrect. Pressure and retention are different questions.
- Option 4: Incorrect. These serve different functions.

**DCCA-Q0332 · single · mechanism**

What should follow a real suppression event before return to service?

1. Deletion of all event records
2. Immediate re-entry because the alarm stopped
3. Authorized safety assessment, cause correction and system restoration
4. Automatic restart of every device

**Correct option(s):** 3

- Option 1: Incorrect. Records support investigation and recovery.
- Option 2: Incorrect. Atmosphere and hazards still need assessment.
- Option 3: Correct. Panel clearing alone is insufficient.
- Option 4: Incorrect. Equipment condition and authority must be checked.

**DCCA-Q0333 · single · mechanism**

Which statement about handheld extinguishers is sound?

1. Any extinguisher is suitable for every fire
2. They should be used regardless of escape conditions
3. They replace installed detection systems
4. Selection and use depend on hazard, training and site procedure

**Correct option(s):** 4

- Option 1: Incorrect. Agents and hazards differ.
- Option 2: Incorrect. Personal safety and approved response matter.
- Option 3: Incorrect. They serve a different response role.
- Option 4: Correct. A generic course is not universal authorization.

**DCCA-Q0334 · single · mechanism**

What can a supervisory fault indicate?

1. A condition affecting suppression readiness
2. An application login failure only
3. Guaranteed successful discharge
4. A normal condition requiring no record

**Correct option(s):** 1

- Option 1: Correct. It may not be a fire but still requires response.
- Option 2: Incorrect. Supervisory states concern the protection system.
- Option 3: Incorrect. A fault can reduce readiness.
- Option 4: Incorrect. The meaning must be assessed.

**DCCA-Q0335 · single · mechanism**

Why control tests that could actuate release circuits?

1. Every test should use a full discharge
2. Release circuits have no physical effect
3. Documentation alone prevents all activation
4. Unintended discharge can create safety and operational consequences

**Correct option(s):** 4

- Option 1: Incorrect. That is not always necessary or appropriate.
- Option 2: Incorrect. They can command suppression.
- Option 3: Incorrect. Actual safeguards and verification are needed.
- Option 4: Correct. The test boundary must be positively managed.

**DCCA-Q0336 · single · mechanism**

What does room-integrity evidence principally address?

1. Fiber connector cleanliness
2. Every detector's sensitivity
3. UPS overload capacity
4. Leakage behavior relevant to agent retention

**Correct option(s):** 4

- Option 1: Incorrect. That is a cabling issue.
- Option 2: Incorrect. That requires other evidence.
- Option 3: Incorrect. That is electrical performance.
- Option 4: Correct. It tests the protected enclosure.

**DCCA-Q0337 · single · mechanism**

Why should cyber controls preserve authorized safety-system functions?

1. Every safety signal should bypass all control
2. Network isolation automatically improves every safety outcome
3. Blocking a required response can create physical consequences
4. Safety systems require no security

**Correct option(s):** 3

- Option 1: Incorrect. The design must balance authorized function and protection.
- Option 2: Incorrect. It can interrupt required communications.
- Option 3: Correct. Security must respect the approved functional design.
- Option 4: Incorrect. They still need appropriate protection.

**DCCA-Q0338 · single · mechanism**

What is the role of a cause-and-effect matrix?

1. Define required outputs for specified inputs and states
2. Replace every maintenance record
3. List only equipment purchase prices
4. Guarantee every possible fire is identical

**Correct option(s):** 1

- Option 1: Correct. It makes interlocks and responses testable.
- Option 2: Incorrect. Lifecycle records remain necessary.
- Option 3: Incorrect. That does not define behavior.
- Option 4: Incorrect. It describes approved scenarios and logic.

**DCCA-Q0339 · single · mechanism**

Which observation best supports rearmed readiness after maintenance?

1. Normal supervisory state plus required functional verification
2. No user has complained yet
3. The work order has a green icon
4. The contractor has left the site

**Correct option(s):** 1

- Option 1: Correct. Both state and behavior need evidence.
- Option 2: Incorrect. Absence of complaints is weak evidence.
- Option 3: Incorrect. Administrative status is not system function.
- Option 4: Incorrect. Departure does not prove readiness.

**DCCA-Q0340 · single · mechanism**

A new containment roof changes detector and nozzle interfaces. What is appropriate?

1. Remove all detectors from the area
2. Assume containment is unrelated to fire protection
3. Review the fire-system design interfaces before acceptance
4. Approve solely because temperatures improved

**Correct option(s):** 3

- Option 1: Incorrect. That would impair protection.
- Option 2: Incorrect. It can alter transport and distribution.
- Option 3: Correct. The physical arrangement can affect detection and discharge.
- Option 4: Incorrect. Thermal improvement does not satisfy fire requirements.

#### Recall

**What does water-based suppression primarily use to control fire?**

Heat removal Correct. Water absorbs substantial thermal energy.

**Why does the term preaction not mean zero water-release risk?**

Actual valve, detection and sprinkler conditions still govern operation Correct. The arrangement must be understood and maintained.

**What can changed room leakage affect in a gaseous system?**

Agent retention Correct. Openings can prevent maintaining the intended concentration.

**Why is cylinder quantity alone insufficient acceptance evidence?**

Distribution, enclosure and control conditions also matter Correct. Agent must reach and remain in the intended volume.

**What does a simulated release-output test demonstrate?**

Selected control and signaling functions Correct. It does not physically discharge agent.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DCCA-M18 — Physical access, identity and security zones

### DCCA-L18 — Physical access, identity and security zones

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L17

Physical security starts with assets, threats and required access, then creates layers that delay or prevent unauthorized action. A site boundary, building entrance, technical area and rack can each be a distinct security zone. The objective is controlled movement and accountable access, not simply installing more locks. A critical controls workstation may deserve a different boundary from a public reception area.

Identity, authentication and authorization are separate. A badge identifies a credential; the access system authenticates that credential according to its mechanism; authorization determines which doors and times it permits. A valid employee badge should not automatically grant every technical-room privilege. Apply role-based, time-bounded access and review it when roles change or employment ends.

Visitors and contractors require a lifecycle: sponsor approval, identity verification, defined purpose, induction, escort where required, issue and return of credentials, and recorded departure. Delivery zones separate incoming goods from sensitive equipment areas so that inspection can occur before movement. Tailgating bypasses the intended credential check; training, layout and appropriate detection or staffing can address it.

Door behavior must account for both security and life safety. Fail-safe and fail-secure terminology concerns the locking response to loss of power, but free egress, emergency release and local requirements need separate review. Never choose a lock mode from a slogan without examining the actual door assembly and approved fire strategy. Access control also depends on power, controllers, communications and local fallback behavior.

Logs help establish who used which credential, at which location and time. They do not by themselves prove the named person was present if credentials were shared or stolen. Correlate with other authorized evidence when investigating. Maintain keys, master credentials and emergency access under controlled custody. Test revocation and recovery paths so a failed central service does not create an unplanned lockout or uncontrolled open site.

### Verify the complete credential lifecycle
A contractor needs access to a loading area and one rack row from 08:00 to 17:00 on a defined date. Test entry during the interval, denial at an unrelated controls-room door, and expiry after 17:00. A successful entry at 09:00 proves only the allowed path; the denied and expired cases establish the boundary.

Now disconnect a test controller in an approved environment. Determine whether it uses cached permissions, denies new requests or follows another supported policy. Revoke the credential centrally and verify what actually happens locally. If the controller continues accepting a revoked credential, the response needs an explicit compensating measure and synchronization plan. Do not assume the central database is the door's effective state.

Mechanical keys, escorts and emergency access are additional paths through the same boundary. Include them in custody and review. Logs identify credential use, not automatically the physical person, especially when badges are shared or tailgating occurs. Correlate authorized evidence while preserving emergency egress and the approved life-safety response.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A contractor badge is valid for the loading area but unexpectedly opens the controls room after the job ends.

**Reasoning:** The issue is authorization scope and lifecycle revocation, not merely badge validity. Review the access group, expiration, approval and effective controller state.

#### Guided practice

Two people enter on one badge swipe. What assumption in the log is weakened?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** The event no longer establishes a one-to-one relationship between credential use and each entrant.

#### Independent task

Environment: analytical

Create a zone and access matrix for reception, loading, data hall and controls room.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Separate identity from authorization.
- Include visitor expiry and lost-credential response.
- Verify life-safety interfaces and power-loss behavior through approved tests.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0341 · single · mechanism**

What does authorization determine in an access system?

1. Whether the person has a unique name only
2. The door's mechanical weight
3. Which resources and times a credential may access
4. The number of cameras installed

**Correct option(s):** 3

- Option 1: Incorrect. That concerns identification.
- Option 2: Incorrect. That is a physical specification.
- Option 3: Correct. Identity alone does not define permission.
- Option 4: Incorrect. Surveillance count is separate.

**DCCA-Q0342 · single · diagnosis**

A valid badge opens an unauthorized technical room. Which control is most directly wrong?

Synthetic educational evidence; not field measurements.

Credential status: valid
Approved zones: loading area
Observed entry: controls room

1. Floor cooling capacity
2. Cable attenuation
3. Credential existence
4. Access permission scope

**Correct option(s):** 4

- Option 1: Incorrect. That is unrelated to permission.
- Option 2: Incorrect. That does not define door rights.
- Option 3: Incorrect. The badge is recognized.
- Option 4: Correct. The credential can be valid while its privileges are excessive.

**DCCA-Q0343 · single · mechanism**

Why divide a facility into security zones?

1. Zones automatically identify every person
2. Zone names replace locks and procedures
3. Every zone must use identical permissions
4. Different assets and activities need different access boundaries

**Correct option(s):** 4

- Option 1: Incorrect. Identity verification remains necessary.
- Option 2: Incorrect. Naming alone enforces nothing.
- Option 3: Incorrect. That defeats differentiated control.
- Option 4: Correct. One broad permission is often excessive.

**DCCA-Q0344 · single · mechanism**

What is tailgating?

1. Entering through a controlled boundary using another person's access event
2. Authorized escorted entry recorded by procedure
3. A badge expiring at its scheduled time
4. A camera recording a doorway

**Correct option(s):** 1

- Option 1: Correct. It bypasses individual credential validation.
- Option 2: Incorrect. That can be an approved process.
- Option 3: Incorrect. That is lifecycle control.
- Option 4: Incorrect. That is surveillance.

**DCCA-Q0345 · single · mechanism**

Why should contractor access expire?

1. Expiry proves the contractor never entered
2. Permanent access simplifies all risk
3. Every contractor needs no access
4. Temporary work does not justify indefinite privilege

**Correct option(s):** 4

- Option 1: Incorrect. It only limits future authorization.
- Option 2: Incorrect. It can preserve unnecessary exposure.
- Option 3: Incorrect. Some work requires controlled access.
- Option 4: Correct. Permissions should match the approved period.

**DCCA-Q0346 · single · mechanism**

What does a badge log prove most directly?

1. The door is mechanically sound
2. The credential owner personally entered
3. Every entrant used a separate credential
4. A credential was used at a recorded point and time

**Correct option(s):** 4

- Option 1: Incorrect. A log alone does not inspect hardware.
- Option 2: Incorrect. Sharing or theft can break that assumption.
- Option 3: Incorrect. Tailgating can occur.
- Option 4: Correct. It does not always prove the named person's presence.

**DCCA-Q0347 · single · mechanism**

Why separate a delivery holding area from a sensitive hall?

1. It eliminates all insider risk
2. Deliveries never need inspection
3. It replaces asset inventory
4. Goods can be checked before entering the protected zone

**Correct option(s):** 4

- Option 1: Incorrect. Internal misuse remains possible.
- Option 2: Incorrect. Provenance and condition can matter.
- Option 3: Incorrect. Received assets still need records.
- Option 4: Correct. The boundary supports inspection and custody.

**DCCA-Q0348 · single · mechanism**

What must be reviewed beyond a lock's fail-safe or fail-secure label?

1. Only whether the lock holds under normal power
2. Egress, emergency release and actual door assembly behavior
3. Only the room number
4. Only the supplier's country

**Correct option(s):** 2

- Option 1: Incorrect. Power-loss and emergency egress behavior can differ from the normal state.
- Option 2: Correct. The complete life-safety interface matters.
- Option 3: Incorrect. Naming is not an acceptance test.
- Option 4: Incorrect. Origin does not define the installed response.

**DCCA-Q0349 · single · mechanism**

What should happen after a credential is reported lost?

1. Wait for its next annual review
2. Delete all access logs
3. Grant it broader privileges to find it
4. Revoke or suspend it and verify effective enforcement

**Correct option(s):** 4

- Option 1: Incorrect. Exposure continues meanwhile.
- Option 2: Incorrect. That destroys useful evidence.
- Option 3: Incorrect. That increases risk.
- Option 4: Correct. The system must stop accepting the lost credential.

**DCCA-Q0350 · single · diagnosis**

Why test revocation at the door controller?

Synthetic educational evidence; not field measurements.

Central record: revoked
Door controller: offline with cached permissions

1. A central database always proves every door state
2. Central updates may not yet be effective locally
3. Every controller has no local state
4. A changed central database guarantees every offline controller updated

**Correct option(s):** 2

- Option 1: Incorrect. Communications and local cache behavior matter.
- Option 2: Correct. Distributed state can lag or fail.
- Option 3: Incorrect. Many systems use local decisions or cached data.
- Option 4: Incorrect. Cached permissions can remain until the local enforcement state is corrected.

**DCCA-Q0351 · single · mechanism**

Which access grant follows least privilege?

1. Permanent master access for all visitors
2. Specific zones and times needed for the approved task
3. Every door for every employee
4. Shared administrator badges

**Correct option(s):** 2

- Option 1: Incorrect. Temporary visitors rarely need that authority.
- Option 2: Correct. Scope matches the work.
- Option 3: Incorrect. That exceeds most role needs.
- Option 4: Incorrect. Sharing undermines accountability.

**DCCA-Q0352 · single · mechanism**

What is a useful visitor departure control?

1. Return or disable credentials and record departure
2. Keep the badge active for convenience indefinitely
3. Remove all records of the visit
4. Assume escorting at arrival proves departure

**Correct option(s):** 1

- Option 1: Correct. The temporary access lifecycle must close.
- Option 2: Incorrect. That preserves unnecessary access.
- Option 3: Incorrect. Traceability should be retained appropriately.
- Option 4: Incorrect. The two events are separate.

**DCCA-Q0353 · single · mechanism**

Why manage physical keys as credentials?

1. Keys cannot be copied or lost
2. Keys generate complete electronic logs automatically
3. Only passwords create access risk
4. They can grant access outside electronic revocation paths

**Correct option(s):** 4

- Option 1: Incorrect. They can be.
- Option 2: Incorrect. Mechanical use may be unlogged.
- Option 3: Incorrect. Physical credentials also matter.
- Option 4: Correct. Key custody is part of the security system.

**DCCA-Q0354 · single · mechanism**

A central access server fails. What must have been designed?

1. Permanent denial of all egress
2. Automatic unrestricted entry everywhere
3. Deletion of every controller configuration
4. Defined local behavior and authorized emergency access

**Correct option(s):** 4

- Option 1: Incorrect. That can violate life safety.
- Option 2: Incorrect. That may violate security requirements.
- Option 3: Incorrect. That would undermine recovery.
- Option 4: Correct. The outage should not create an improvised security state.

**DCCA-Q0355 · single · mechanism**

Why review access after a role change?

1. Previous privileges may no longer be justified
2. Role changes affect only payroll
3. Door hardware changes automatically with job title
4. A valid employment contract grants every room

**Correct option(s):** 1

- Option 1: Correct. Authorization should follow current duties.
- Option 2: Incorrect. They can alter access needs.
- Option 3: Incorrect. Permissions must be managed.
- Option 4: Incorrect. Employment does not imply universal need.

**DCCA-Q0356 · single · mechanism**

What is the purpose of an escort requirement?

1. Guarantee the visitor cannot make any mistake
2. Maintain controlled supervision of a visitor's permitted activity
3. Replace identity verification
4. Allow unrestricted entry to all zones

**Correct option(s):** 2

- Option 1: Incorrect. Supervision reduces but does not eliminate risk.
- Option 2: Correct. It limits unsupervised movement.
- Option 3: Incorrect. The visitor still needs to be identified.
- Option 4: Incorrect. The escort follows defined scope.

**DCCA-Q0357 · single · mechanism**

Which evidence best verifies a time-bounded access grant?

1. Only a successful entry during the allowed period
2. Only a badge photograph
3. Approved scope plus tested acceptance and rejection at relevant times
4. Only the access request email

**Correct option(s):** 3

- Option 1: Incorrect. Expiry behavior remains untested.
- Option 2: Incorrect. It does not show permissions.
- Option 3: Correct. Both allowed and denied behavior matter.
- Option 4: Incorrect. Intent is not effective enforcement.

**DCCA-Q0358 · single · mechanism**

Why investigate repeated forced-door events?

1. They always prove a specific person attacked
2. Every such event is necessarily harmless
3. They are equivalent to normal granted access
4. They may indicate a security breach or door defect

**Correct option(s):** 4

- Option 1: Incorrect. Attribution needs evidence.
- Option 2: Incorrect. The cause must be established.
- Option 3: Incorrect. Forced-door status has a different meaning.
- Option 4: Correct. Both require diagnosis.

**DCCA-Q0359 · single · mechanism**

What can shared badges undermine?

1. The electrical supply rating
2. Every camera recording by definition
3. All mechanical door strength
4. Individual accountability

**Correct option(s):** 4

- Option 1: Incorrect. That is unrelated.
- Option 2: Incorrect. Video may still exist, though interpretation changes.
- Option 3: Incorrect. Sharing does not change the door material.
- Option 4: Correct. One credential no longer maps reliably to one user.

**DCCA-Q0360 · single · mechanism**

Which boundary should govern emergency access design?

1. The assumption that outages never happen
2. The shortest possible procedure regardless of authority
3. Security convenience alone
4. Security requirements coordinated with the approved life-safety strategy

**Correct option(s):** 4

- Option 1: Incorrect. Fallback behavior must be planned.
- Option 2: Incorrect. Consequences require defined roles.
- Option 3: Incorrect. It can obstruct emergency needs.
- Option 4: Correct. Neither can be addressed in isolation.

#### Recall

**What does authorization determine in an access system?**

Which resources and times a credential may access Correct. Identity alone does not define permission.

**A valid badge opens an unauthorized technical room. Which control is most directly wrong?**

Access permission scope Correct. The credential can be valid while its privileges are excessive.

**Why divide a facility into security zones?**

Different assets and activities need different access boundaries Correct. One broad permission is often excessive.

**What is tailgating?**

Entering through a controlled boundary using another person's access event Correct. It bypasses individual credential validation.

**Why should contractor access expire?**

Temporary work does not justify indefinite privilege Correct. Permissions should match the approved period.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)
- [NIST SP 800-82 Revision 3 — final OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

## DCCA-M19 — Surveillance, intrusion and physical incident evidence

### DCCA-L19 — Surveillance, intrusion and physical incident evidence

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L18

Surveillance provides observation and evidence; it does not inherently prevent entry. Define the question each camera or sensor must answer: detect a person, recognize activity, identify a credential holder, observe a loading transfer or investigate a cabinet opening. Image usefulness depends on field of view, lighting, motion, resolution at the target, obstruction and timestamp quality rather than a camera's headline pixel count alone.

Recording introduces storage, retention and access requirements. Estimate volume from actual bitrate, camera count and recording duration, then account for redundancy, overhead and growth. Variable bitrate and scene motion can change demand. A recorder that is online but no longer saving usable footage creates a hidden loss of evidence. Test retrieval, export and playback rather than only live view.

Time alignment connects physical events with access logs, network records and operator actions. Unsynchronized clocks can reverse apparent event order or make correlation ambiguous. Preserve original files and metadata under controlled access, and document exports and transformations. An edited clip can support a briefing but should not silently replace original evidence.

Intrusion alarms also need context. Door-held-open, forced-door, motion and enclosure-tamper events represent different states. A maintenance window may explain an event but does not justify disabling every related alarm without tracking the impairment. A useful response identifies location, possible impact, authorized activity, response owner and escalation route.

Physical-security systems themselves require cybersecurity and resilience. Cameras and controllers are networked assets with credentials, firmware, storage and time dependencies. Separate their management permissions, protect remote access and verify backups of required configurations. During a security incident, preserve life safety and operating continuity while containing the affected access or surveillance function through the approved procedure.

### Calculate retention and then test retrieval
Eight cameras average 3 Mbit/s each, giving 24 Mbit/s or 3 MB/s in decimal units. One day produces 259.2 GB before overhead; thirty days produces 7.776 TB. Add the actual storage architecture, reserve, variable bitrate and retention policy rather than assuming the nominal disk label is wholly usable.

The storage calculation is only one acceptance dimension. A loading-bay camera must show the required target under daytime, low-light and movement conditions. A wide view may detect activity while providing too few useful pixels on a face or label for the identification task. Test the actual purpose rather than accepting the maximum sensor resolution as proof.

Retrieve an older sample, export it through the approved process and verify playback and timestamps. A recorder can show live video while its archive has failed or overwritten the required interval. Preserve original evidence and metadata for incidents; use edited clips only as clearly identified derivatives. Time alignment with door and operator logs is essential for a reliable event sequence.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. Four cameras record continuously at 4 Mbit/s each. Ignore overhead for a first estimate and use decimal units.

**Reasoning:** Aggregate rate is 16 Mbit/s = 2 MB/s. One day needs 172,800 MB, or 172.8 GB. Real storage design must add retention duration, redundancy, overhead and measured bitrate variation.

#### Guided practice

Live video works, but playback for yesterday fails. Which function needs investigation?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** Recording, storage, retention or indexing may have failed; live view alone never established evidence retention.

#### Independent task

Environment: analytical

Create a camera acceptance and evidence-retention plan for a loading bay.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Specify the observation task and target conditions.
- Calculate storage with explicit units and assumptions.
- Test export, playback and time correlation.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0361 · single · mechanism**

What should determine a camera's acceptance test?

1. The required observation or identification task
2. Only the advertised resolution
3. Only the number of mounting screws
4. Only the lens focal-length label

**Correct option(s):** 1

- Option 1: Correct. A pixel count alone does not establish useful evidence.
- Option 2: Incorrect. Field of view and conditions also matter.
- Option 3: Incorrect. Mechanical attachment is not the full imaging requirement.
- Option 4: Incorrect. Focal length is one input; actual target visibility also depends on geometry and light.

**DCCA-Q0362 · single · diagnosis**

Four cameras each record at 4 Mbit/s. What aggregate bitrate is used?

Synthetic educational evidence; not field measurements.

Cameras: 4
Rate per camera: 4 Mbit/s

1. 4 Mbit/s
2. 1 Mbit/s
3. 16 Mbit/s
4. 64 Mbit/s

**Correct option(s):** 3

- Option 1: Incorrect. That counts only one camera.
- Option 2: Incorrect. Dividing is incorrect.
- Option 3: Correct. The four streams add.
- Option 4: Incorrect. That squares rather than sums the stated rate.

**DCCA-Q0363 · single · diagnosis**

A 16 Mbit/s aggregate stream is how many decimal MB/s?

Synthetic educational evidence; not field measurements.

Aggregate rate: 16 Mbit/s
Use decimal MB and 8 bits per byte.

1. 2 MB/s
2. 16 MB/s
3. 128 MB/s
4. 0.016 MB/s

**Correct option(s):** 1

- Option 1: Correct. Eight bits make one byte.
- Option 2: Incorrect. That confuses bits with bytes.
- Option 3: Incorrect. The conversion direction is reversed.
- Option 4: Incorrect. That introduces an extra thousandfold conversion.

**DCCA-Q0364 · single · mechanism**

Why is live view insufficient to prove recording readiness?

1. Live view always uses the archive
2. Storage and retrieval can fail independently
3. Recording is unnecessary if cameras are powered
4. A camera online state proves every disk is healthy

**Correct option(s):** 2

- Option 1: Incorrect. It may bypass recording storage.
- Option 2: Correct. The display path is not the full retention function.
- Option 3: Incorrect. Evidence retention can be a requirement.
- Option 4: Incorrect. The systems have separate components.

**DCCA-Q0365 · single · mechanism**

What can unsynchronized timestamps do during an investigation?

1. Guarantee better attribution
2. Increase image resolution
3. Make event correlation and ordering unreliable
4. Remove the need for access logs

**Correct option(s):** 3

- Option 1: Incorrect. Misaligned times can weaken attribution.
- Option 2: Incorrect. Time synchronization does not add pixels.
- Option 3: Correct. Clocks can disagree about when events occurred.
- Option 4: Incorrect. Correlation uses multiple sources.

**DCCA-Q0366 · single · mechanism**

Which record should be preserved when exporting incident footage?

1. Original files and relevant metadata
2. Only a screenshot of the recorder menu
3. Only a verbal summary
4. Only an edited highlight clip

**Correct option(s):** 1

- Option 1: Correct. Exports should retain traceability to the source.
- Option 2: Incorrect. That does not preserve the event.
- Option 3: Incorrect. It is weaker than preserved evidence.
- Option 4: Incorrect. Editing can omit context and metadata.

**DCCA-Q0367 · single · mechanism**

Why can actual storage differ from a simple bitrate estimate?

1. Scene motion, encoding and overhead vary
2. Camera count has no effect
3. Retention duration does not matter
4. Bitrates never change

**Correct option(s):** 1

- Option 1: Correct. The model needs measured assumptions and reserve.
- Option 2: Incorrect. More streams generally add demand.
- Option 3: Incorrect. Longer retention requires more storage.
- Option 4: Incorrect. Variable-rate encoding can change them.

**DCCA-Q0368 · single · mechanism**

What does a door-held-open event differ from?

1. A battery discharge curve
2. Every normal access grant
3. A camera lens specification
4. A forced-door event without the expected authorized opening

**Correct option(s):** 4

- Option 1: Incorrect. That is unrelated.
- Option 2: Incorrect. A held-open condition adds duration context.
- Option 3: Incorrect. That is unrelated to the door state.
- Option 4: Correct. The states imply different causes and responses.

**DCCA-Q0369 · single · mechanism**

Why test footage retrieval periodically?

1. Retrieval tests replace every camera inspection
2. A full disk always guarantees valid footage
3. Usable evidence depends on archive access and integrity
4. Retention policies enforce themselves without configuration

**Correct option(s):** 3

- Option 1: Incorrect. Optical view and hardware still need checks.
- Option 2: Incorrect. It may hold corrupted or irrelevant data.
- Option 3: Correct. Recording claims need functional verification.
- Option 4: Incorrect. Effective settings and storage must be verified.

**DCCA-Q0370 · single · mechanism**

Which condition can defeat an otherwise suitable camera view?

1. A documented camera ID
2. A verified retention setting
3. A tested time source
4. Obstruction or inadequate target lighting

**Correct option(s):** 4

- Option 1: Incorrect. Identification supports maintenance.
- Option 2: Incorrect. That supports evidence availability.
- Option 3: Incorrect. That supports correlation.
- Option 4: Correct. The observation path must remain usable.

**DCCA-Q0371 · single · mechanism**

What is the role of surveillance in physical security?

1. Automatic proof of a person's intent
2. Guaranteed prevention of every intrusion
3. Observation, deterrence and evidence within a layered system
4. Replacement for all access control

**Correct option(s):** 3

- Option 1: Incorrect. Video interpretation has limits.
- Option 2: Incorrect. Cameras may only observe an event.
- Option 3: Correct. It does not automatically prevent all entry.
- Option 4: Incorrect. Entry authorization still needs controls.

**DCCA-Q0372 · single · mechanism**

Why protect camera management credentials?

1. Only the image sensor matters
2. Shared default credentials improve accountability
3. Surveillance devices are networked systems with authority and data
4. Cameras cannot be cyber targets

**Correct option(s):** 3

- Option 1: Incorrect. Management and recording paths also matter.
- Option 2: Incorrect. They undermine individual control.
- Option 3: Correct. Compromise can disable or alter observation.
- Option 4: Incorrect. They often contain software and network services.

**DCCA-Q0373 · single · mechanism**

Which alarm response information is most useful?

1. Only the total camera count
2. Location, meaning, impact and responsible responder
3. Only the device purchase year
4. Only a red icon

**Correct option(s):** 2

- Option 1: Incorrect. That does not identify the affected event.
- Option 2: Correct. This supports an actionable decision.
- Option 3: Incorrect. Age may matter but does not define response.
- Option 4: Incorrect. It lacks context.

**DCCA-Q0374 · single · mechanism**

What should happen when an alarm is suppressed for maintenance?

1. Assume all related sensors remain effective
2. Leave suppression indefinitely
3. Track the impairment, duration and restoration
4. Delete the alarm definition

**Correct option(s):** 3

- Option 1: Incorrect. The impaired boundary must be known.
- Option 2: Incorrect. That creates hidden exposure.
- Option 3: Correct. Coverage is intentionally reduced.
- Option 4: Incorrect. Temporary work does not justify permanent removal.

**DCCA-Q0375 · single · mechanism**

Why distinguish an edited briefing clip from original evidence?

1. File names alone guarantee integrity
2. Editing changes context and can remove metadata
3. Edited clips are always prohibited for every purpose
4. Originals are never useful after export

**Correct option(s):** 2

- Option 1: Incorrect. Content and provenance also matter.
- Option 2: Correct. The original preserves a stronger record.
- Option 3: Incorrect. They can support communication if clearly labeled.
- Option 4: Incorrect. They remain important for verification.

**DCCA-Q0376 · single · mechanism**

A camera sees the door but not faces at entry. Which requirement may fail?

1. Every retention requirement
2. Electrical power availability necessarily
3. Basic motion observation necessarily
4. Identification at the target location

**Correct option(s):** 4

- Option 1: Incorrect. Storage may still work.
- Option 2: Incorrect. The camera can be powered and recording.
- Option 3: Incorrect. It may still detect movement.
- Option 4: Correct. Detection of movement is a different task.

**DCCA-Q0377 · single · mechanism**

What should a recorder backup plan preserve?

1. Only the exterior photograph
2. Only the list of camera IP addresses
3. Only the installer password in plaintext
4. Required configuration and recoverable access to retained evidence

**Correct option(s):** 4

- Option 1: Incorrect. That cannot restore settings or data.
- Option 2: Incorrect. Addresses alone do not restore recording, retention, access and other configuration.
- Option 3: Incorrect. Credential handling needs protection and broader recovery data.
- Option 4: Correct. Recovery needs more than a device replacement.

**DCCA-Q0378 · single · mechanism**

Why correlate access logs with video cautiously?

1. Credential use and visible presence are different observations
2. Correlation removes timestamp uncertainty automatically
3. Video always reveals every face perfectly
4. A badge event always proves the named person acted

**Correct option(s):** 1

- Option 1: Correct. Neither alone proves every aspect of identity or action.
- Option 2: Incorrect. Clock quality must be assessed.
- Option 3: Incorrect. View and conditions limit it.
- Option 4: Incorrect. Credentials can be shared or stolen.

**DCCA-Q0379 · single · mechanism**

Which acceptance evidence checks nighttime usefulness?

1. A daytime still image only
2. A network ping at midnight
3. Representative low-light target observations
4. The camera's purchase price

**Correct option(s):** 3

- Option 1: Incorrect. Lighting conditions differ.
- Option 2: Incorrect. Connectivity does not show image usability.
- Option 3: Correct. Daytime performance does not prove night behavior.
- Option 4: Incorrect. Price is not performance evidence.

**DCCA-Q0380 · single · mechanism**

What should recovery from a surveillance outage demonstrate?

1. Only all alarms are silenced
2. Recording, retrieval, time alignment and required coverage restored
3. Only a ticket is closed
4. Only the login page loads

**Correct option(s):** 2

- Option 1: Incorrect. Silence can hide continued failure.
- Option 2: Correct. A powered recorder alone is insufficient.
- Option 3: Incorrect. Administrative closure is not function.
- Option 4: Incorrect. That tests a narrow interface.

#### Recall

**What should determine a camera's acceptance test?**

The required observation or identification task Correct. A pixel count alone does not establish useful evidence.

**Four cameras each record at 4 Mbit/s. What aggregate bitrate is used?**

16 Mbit/s Correct. The four streams add.

**A 16 Mbit/s aggregate stream is how many decimal MB/s?**

2 MB/s Correct. Eight bits make one byte.

**Why is live view insufficient to prove recording readiness?**

Storage and retrieval can fail independently Correct. The display path is not the full retention function.

**What can unsynchronized timestamps do during an investigation?**

Make event correlation and ordering unreliable Correct. Clocks can disagree about when events occurred.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)
- [NIST SP 800-82 Revision 3 — final OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

## DCCA-M20 — BMS, EPMS and DCIM roles

### DCCA-L20 — BMS, EPMS and DCIM roles

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L19

Building management, electrical power monitoring and infrastructure management systems provide different views of the same facility. A BMS commonly supervises mechanical and environmental equipment, alarms and schedules. EPMS concentrates on electrical measurements, status, events and power quality. DCIM connects assets, locations, capacity, connections and operational information. Product boundaries overlap, so define the required functions instead of assuming a name guarantees them.

These platforms consume data from field devices and other systems. A useful point record includes the physical asset, sensor or register, engineering units, scaling, quality, timestamp and intended use. A temperature value without its location can be misleading; a power value without knowing whether it is instantaneous kW or accumulated kWh can corrupt a capacity calculation. Authentication of a data source does not prove that the transducer is correctly installed.

Control authority must be explicit. A read-only dashboard presents information; a supervisory command can change a setpoint or operating mode; a local controller may continue its own sequence when the supervisory server fails. Determine which layer owns each decision and how command priorities, overrides and communications loss behave. A dashboard should not be granted unnecessary write access merely to make integration easier.

Data quality has several dimensions: correct physical measurement, correct mapping, suitable resolution, freshness, completeness and time alignment. A gateway can be reachable while returning stale values. An asset database can be internally consistent but physically wrong after an undocumented move. Commissioning therefore tests field-to-screen mapping and screen-to-field action where authorized, not just network connectivity.

Operations needs durable records and usable exports. Back up configurations, mappings, user roles and integration settings according to the product's supported method. Test restoration in a safe environment. Keep vendor platforms as the underlying systems; the engineer's job is requirements, integration, supported configuration and lifecycle ownership rather than recreating a BMS or DCIM product from scratch.

### Commission semantics, not only connectivity
A meter exposes register 100 as accumulated energy in 0.1 kWh units and register 110 as instantaneous real power in 0.01 kW units. Mapping register 100 to a kW display creates a plausible increasing number with the wrong meaning. Mapping register 110 without its scale creates a hundredfold error. A successful packet exchange cannot detect either semantic mistake by itself.

Build a point table containing physical asset, source address, data type, scale, units, timestamp, quality and display destination. Apply a known or independently measured condition, then verify the expected value across each layer. For commands, additionally verify authority, range limits, acknowledgment and actual field response under the approved test.

Separate source truth from replicated views. DCIM may own rack location while EPMS owns electrical measurements; a gateway may translate both without owning their physical accuracy. After an asset move or software restore, reconcile those relationships. Back up the supported configuration and prove restoration in an appropriate environment so integration knowledge is not trapped in one running server.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. An EPMS screen reports 120 kW, but the mapped source register is accumulated kWh. The network connection and user login both work.

**Reasoning:** Transport and authentication are successful, but the semantic mapping is wrong. Correct the point definition, units and scaling, then verify against the physical meter under known conditions.

#### Guided practice

A BMS server is unavailable while local PLC loops continue. Is local process control necessarily lost?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** No. The design may preserve local control while losing supervisory visibility or commands; verify the actual architecture and fallback behavior.

#### Independent task

Environment: analytical

Create a point-mapping and authority table spanning one meter, one controller and one DCIM asset.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Include units, scaling, timestamp, quality and physical identity.
- Separate read access from command authority.
- Define backup and restoration evidence for the integration.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0381 · single · mechanism**

Which platform most directly focuses on electrical measurements and events?

1. A visitor badge database
2. EPMS
3. A generic asset floor-plan drawing
4. A video recorder

**Correct option(s):** 2

- Option 1: Incorrect. That manages physical access identities.
- Option 2: Correct. Electrical power monitoring is its principal role.
- Option 3: Incorrect. That does not inherently collect electrical events.
- Option 4: Incorrect. That retains surveillance imagery.

**DCCA-Q0382 · single · mechanism**

What is a common DCIM function?

1. Generate electrical power
2. Suppress every fire physically
3. Replace every local control loop
4. Relate assets, locations, connections and capacity

**Correct option(s):** 4

- Option 1: Incorrect. It is an information and management platform.
- Option 2: Incorrect. It is not the suppression agent.
- Option 3: Incorrect. DCIM is not automatically the process controller.
- Option 4: Correct. It supports infrastructure management.

**DCCA-Q0383 · single · calculation**

A point labeled kW reads an accumulated kWh register. What is wrong?

Synthetic educational evidence; not field measurements.

Display tag: real power, kW
Mapped source: accumulated energy, kWh
Network connection: healthy

1. User authentication necessarily
2. Semantic mapping and units
3. Network reachability necessarily
4. Rack rail compatibility

**Correct option(s):** 2

- Option 1: Incorrect. The login can be valid.
- Option 2: Correct. The displayed quantity is not the intended physical measure.
- Option 3: Incorrect. The data can be transported successfully.
- Option 4: Incorrect. That is unrelated to the point definition.

**DCCA-Q0384 · single · mechanism**

Why include physical location in a sensor record?

1. Location automatically calibrates the sensor
2. The same value has different meaning at different process points
3. Location replaces engineering units
4. Every sensor in a room reads identical conditions

**Correct option(s):** 2

- Option 1: Incorrect. Calibration is separate.
- Option 2: Correct. Interpretation depends on what is measured.
- Option 3: Incorrect. Both are needed.
- Option 4: Incorrect. Spatial differences exist.

**DCCA-Q0385 · single · mechanism**

What does read-only integration limit?

1. Sensor calibration error
2. All data collection
3. The ability to issue state-changing commands
4. Every cyber risk

**Correct option(s):** 3

- Option 1: Incorrect. Permission level does not establish physical accuracy.
- Option 2: Incorrect. Read access permits observation.
- Option 3: Correct. It supports observation without unnecessary control authority.
- Option 4: Incorrect. Read paths still need protection.

**DCCA-Q0386 · single · diagnosis**

A gateway replies to ping but values are hours old. What is established?

Synthetic educational evidence; not field measurements.

Gateway ICMP: replies
Source sample age: several hours

1. Reachability without fresh application data
2. Correct physical calibration
3. Successful control execution
4. Complete monitoring health

**Correct option(s):** 1

- Option 1: Correct. Transport success is not measurement freshness.
- Option 2: Incorrect. Ping does not test calibration.
- Option 3: Incorrect. No command response has been shown.
- Option 4: Incorrect. Stale values undermine the function.

**DCCA-Q0387 · single · mechanism**

Why test field-to-screen mapping?

1. A plausible temperature proves the point belongs to the intended sensor
2. Only the server CPU matters
3. Every mapping is automatic and infallible
4. A plausible displayed value can belong to the wrong asset

**Correct option(s):** 4

- Option 1: Incorrect. Two different locations can produce plausible values, so identity still needs testing.
- Option 2: Incorrect. The data chain includes field devices and configuration.
- Option 3: Incorrect. Integration errors can occur.
- Option 4: Correct. Connectivity alone does not prove identity and semantics.

**DCCA-Q0388 · single · mechanism**

What can local control preserve during BMS-server loss?

1. Every enterprise identity service
2. Every historical trend automatically
3. All remote commands
4. A designed autonomous sequence at the controller

**Correct option(s):** 4

- Option 1: Incorrect. Those are separate dependencies.
- Option 2: Incorrect. History may depend on the unavailable server.
- Option 3: Incorrect. Supervisory commands may be unavailable.
- Option 4: Correct. Supervisory loss need not equal loss of all control.

**DCCA-Q0389 · single · mechanism**

Why identify command ownership?

1. Multiple layers can otherwise issue conflicting or unauthorized actions
2. Ownership changes only the display label
3. A dashboard always outranks every local interlock
4. More write access always improves resilience

**Correct option(s):** 1

- Option 1: Correct. Authority must be explicit.
- Option 2: Incorrect. It affects actual control decisions.
- Option 3: Incorrect. That is not a safe universal rule.
- Option 4: Incorrect. It can enlarge the change and attack surface.

**DCCA-Q0390 · single · mechanism**

Which data-quality field helps detect staleness?

1. The configured polling interval without a source timestamp
2. Source timestamp or age
3. Number of chart tabs
4. Asset purchase price

**Correct option(s):** 2

- Option 1: Incorrect. Polling intent does not prove that a fresh sample was actually produced.
- Option 2: Correct. It indicates when the physical observation was produced.
- Option 3: Incorrect. Display structure does not show source time.
- Option 4: Incorrect. Cost is unrelated to freshness.

**DCCA-Q0391 · single · mechanism**

What should a BMS integration backup include?

1. Only the server hostname
2. Supported configurations, mappings and required access settings
3. Only a dashboard screenshot
4. Only the latest temperature reading

**Correct option(s):** 2

- Option 1: Incorrect. That is insufficient.
- Option 2: Correct. Restoration needs the system's effective configuration.
- Option 3: Incorrect. An image cannot restore configuration.
- Option 4: Incorrect. One sample does not restore the platform.

**DCCA-Q0392 · single · mechanism**

Why does a valid device certificate not prove sensor correctness?

1. Physical measurements need no identity
2. Certificates never have any value
3. Authentication establishes identity rather than measurement accuracy
4. Digital sensors cannot drift

**Correct option(s):** 3

- Option 1: Incorrect. Identity and accuracy are complementary.
- Option 2: Incorrect. They support trust in the communicating identity.
- Option 3: Correct. Calibration and installation remain separate.
- Option 4: Incorrect. They can be biased or misconfigured.

**DCCA-Q0393 · single · mechanism**

An asset was moved but DCIM still shows the old rack. What failed?

1. All local controller logic
2. The concept of capacity management
3. Every electrical meter necessarily
4. Inventory-to-physical-state reconciliation

**Correct option(s):** 4

- Option 1: Incorrect. That cannot be inferred.
- Option 2: Incorrect. Capacity remains useful but needs correct data.
- Option 3: Incorrect. The issue is asset location.
- Option 4: Correct. The database no longer reflects the installation.

**DCCA-Q0394 · single · mechanism**

What is appropriate when product names overlap in capability?

1. Assume every BMS includes every DCIM feature
2. Buy all products without checking overlap
3. Eliminate requirements because names differ
4. Specify required functions and verify implementation

**Correct option(s):** 4

- Option 1: Incorrect. Products vary.
- Option 2: Incorrect. That can duplicate cost and complexity.
- Option 3: Incorrect. Function still matters.
- Option 4: Correct. A label alone is not an acceptance criterion.

**DCCA-Q0395 · single · mechanism**

Why distinguish instantaneous power from accumulated energy?

1. Power has no relation to energy
2. Both always use the same units
3. They answer different operational questions
4. Energy cannot be metered

**Correct option(s):** 3

- Option 1: Incorrect. Energy is power integrated over time.
- Option 2: Incorrect. kW and kWh differ.
- Option 3: Correct. Capacity uses power while consumption integrates over time.
- Option 4: Incorrect. Meters can accumulate energy.

**DCCA-Q0396 · single · mechanism**

Which acceptance tests a permitted command path?

1. A successful login alone
2. A gateway ping alone
3. Authorized command followed by verified field response and restoration
4. A changed screen value alone

**Correct option(s):** 3

- Option 1: Incorrect. Login does not prove command effect.
- Option 2: Incorrect. Reachability does not demonstrate control.
- Option 3: Correct. The complete action must be observed.
- Option 4: Incorrect. The field may not follow.

**DCCA-Q0397 · single · mechanism**

Why retain the vendor platform in this programme?

1. Custom scripts should replace every safety function
2. Platform documentation is unnecessary
3. The engineering task is supported integration and lifecycle ownership
4. Vendor products require no engineering

**Correct option(s):** 3

- Option 1: Incorrect. That can undermine supported behavior and authority.
- Option 2: Incorrect. Supported operation depends on it.
- Option 3: Correct. Recreating the entire product is outside the intended task.
- Option 4: Incorrect. They still need requirements and configuration.

**DCCA-Q0398 · single · mechanism**

What can missing quality flags cause?

1. Sensor units become self-evident
2. Every sample becomes physically wrong
3. Timestamps become unnecessary
4. Bad or uncertain samples may look like valid process values

**Correct option(s):** 4

- Option 1: Incorrect. Units still need definition.
- Option 2: Incorrect. Some may still be correct.
- Option 3: Incorrect. Freshness remains separate.
- Option 4: Correct. The user loses important interpretation context.

**DCCA-Q0399 · single · mechanism**

Why test restoration in a safe environment?

1. A backup is useful only if a supported recovery can succeed
2. Restoration tests award production authority
3. Production disruption is always required
4. Backup success guarantees restoration

**Correct option(s):** 1

- Option 1: Correct. Testing reveals missing configuration or dependencies.
- Option 2: Incorrect. Competence and authorization are separate.
- Option 3: Incorrect. Many recovery checks can use isolated environments.
- Option 4: Incorrect. It does not.

**DCCA-Q0400 · single · mechanism**

Which mapping record best supports troubleshooting?

1. Only the network subnet
2. Only a screenshot without context
3. Physical asset, source address, units, scaling, quality and timestamp
4. Only a friendly display name

**Correct option(s):** 3

- Option 1: Incorrect. It does not identify the point semantics.
- Option 2: Incorrect. It cannot fully reconstruct the mapping.
- Option 3: Correct. It connects physical meaning to digital representation.
- Option 4: Incorrect. Names can be ambiguous.

#### Recall

**Which platform most directly focuses on electrical measurements and events?**

EPMS Correct. Electrical power monitoring is its principal role.

**What is a common DCIM function?**

Relate assets, locations, connections and capacity Correct. It supports infrastructure management.

**A point labeled kW reads an accumulated kWh register. What is wrong?**

Semantic mapping and units Correct. The displayed quantity is not the intended physical measure.

**Why include physical location in a sensor record?**

The same value has different meaning at different process points Correct. Interpretation depends on what is measured.

**What does read-only integration limit?**

The ability to issue state-changing commands Correct. It supports observation without unnecessary control authority.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)
- [NIST SP 800-82 Revision 3 — final OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

## DCCA-M21 — Sensors, calibration and alarm response

### DCCA-L21 — Sensors, calibration and alarm response

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L20

A sensor converts a physical condition into a signal, and a measurement chain turns that signal into an engineering value. The chain may include a transducer, analog input, scaling, gateway, database and display. Each stage can introduce error or delay. A correct network packet can carry an incorrectly scaled current signal; a calibrated sensor can be installed at the wrong physical location.

Calibration compares an instrument with an appropriate reference under stated conditions and records error or uncertainty. Adjustment changes the instrument to improve its response. The two terms are not identical. A calibration label without range, date, traceability and result may be insufficient for the intended measurement. Accuracy, resolution and repeatability are also distinct: many decimal places do not establish correctness.

Alarms should correspond to conditions requiring a defined response. A threshold needs units, direction, persistence, priority, operating-state context and an owner. Hysteresis uses different activation and clearing thresholds to reduce repeated transitions around one value. A delay can reject brief noise but must not hide a condition whose physical consequence develops faster than the delay.

Alarm floods overwhelm attention. Review nuisance alarms, duplicate notifications and consequence-based priorities while preserving necessary protection. Shelving or suppression is a controlled temporary state, not a permanent solution to an unexplained fault. Track who suppressed what, why, until when, and how normal monitoring is restored.

Acceptance starts at the physical stimulus and ends with the required human or automated response. Test mapping, threshold crossing, quality/failure state, timestamp, notification, acknowledgment and return to normal. Distinguish an alarm's clearance from correction of its root cause. Trend the process after intervention to ensure the system is stable rather than merely quiet.

### Derive a scaled measurement and an alarm band
A 4–20 mA transmitter represents 0–100°C. Under an ideal linear mapping, temperature is (current−4)/16×100. At 12 mA the value is 50°C; at 16 mA it is 75°C. Treat values outside the supported signal behavior according to the product's fault scheme rather than automatically converting them into valid process temperatures.

Suppose a high alarm activates at 70°C and clears at 65°C after a specified persistence. A trace of 69, 71, 69, 68, 66°C should not repeatedly clear after activation if the clearing threshold has not been reached. Hysteresis reduces chatter, while persistence filters timing. Both must fit the physical consequence: a long delay is unsuitable if the equipment can exceed a critical limit sooner.

Test the physical or simulated input, mapped value, threshold state, quality, notification and restoration separately. A failed sensor stuck at a normal value can defeat a threshold-only alarm, so include freshness or device-health evidence where appropriate. Record who may shelve the alarm and when suppression expires.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A high-temperature alarm activates at 30°C and clears at 28°C. The measured value oscillates between 29.5°C and 30.5°C after activation.

**Reasoning:** The alarm remains active until the value falls to the clearing threshold. The 2 K hysteresis prevents repeated clear/reactivate cycles near 30°C.

#### Guided practice

A display shows 23.456°C but the sensor uncertainty is ±1°C. Does the third decimal prove millikelvin accuracy?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** No. Display resolution is much finer than demonstrated accuracy.

#### Independent task

Environment: analytical

Write an alarm specification and end-to-end test for a cooling inlet sensor.

**Packaged starter material**

- course_labs/DCCA/README.md
- course_labs/DCCA/scenario.json
- course_labs/DCCA/answers-template.json

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- State thresholds, delay, hysteresis and operating context.
- Test sensor failure and stale data as well as process excursions.
- Verify actual notification and controlled restoration.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0401 · single · mechanism**

What is the difference between calibration and adjustment?

1. Adjustment only adds a label
2. Calibration compares; adjustment changes response
3. They always mean replacing the sensor
4. Calibration changes room temperature

**Correct option(s):** 2

- Option 1: Incorrect. It changes response rather than merely documentation.
- Option 2: Correct. A comparison need not alter the device.
- Option 3: Incorrect. Neither necessarily requires replacement.
- Option 4: Incorrect. It assesses the instrument against a reference.

**DCCA-Q0402 · single · calculation**

A display has three decimal places but ±1°C uncertainty. What do the decimals establish?

1. Perfect repeatability
2. Correct sensor location
3. Display resolution, not equivalent accuracy
4. Millikelvin accuracy

**Correct option(s):** 3

- Option 1: Incorrect. That requires separate evidence.
- Option 2: Incorrect. Formatting does not prove placement.
- Option 3: Correct. Fine formatting does not remove measurement error.
- Option 4: Incorrect. The stated uncertainty contradicts that.

**DCCA-Q0403 · single · calculation**

An alarm activates at 30°C and clears at 28°C. What is the hysteresis band?

Synthetic educational evidence; not field measurements.

High alarm activates: 30°C
Alarm clears: 28°C

1. 58 K
2. 2 K
3. 30 K
4. 0 K

**Correct option(s):** 2

- Option 1: Incorrect. Adding thresholds is not hysteresis.
- Option 2: Correct. The activation and clearing thresholds differ by two degrees.
- Option 3: Incorrect. That is the activation value, not the band.
- Option 4: Incorrect. The thresholds are different.

**DCCA-Q0404 · single · mechanism**

Why can an alarm delay be unsafe if chosen blindly?

1. Every transient is harmless
2. The consequence may develop faster than the delay
3. Delays always improve safety
4. Delay only changes chart appearance

**Correct option(s):** 2

- Option 1: Incorrect. Some brief events matter.
- Option 2: Correct. Filtering must respect process timing.
- Option 3: Incorrect. They can hide urgent conditions.
- Option 4: Incorrect. It affects response timing.

**DCCA-Q0405 · single · mechanism**

What makes an alarm actionable?

1. A meaningful condition with priority, owner and response
2. A generic red icon without location
3. The largest possible alarm count
4. A loud sound alone

**Correct option(s):** 1

- Option 1: Correct. Detection must lead to appropriate action.
- Option 2: Incorrect. That lacks essential context.
- Option 3: Incorrect. More alarms can overwhelm attention.
- Option 4: Incorrect. Sound does not define what to do.

**DCCA-Q0406 · single · mechanism**

Why test sensor-failure alarms separately from process alarms?

1. A failed sensor always reads the actual temperature
2. Sensor failures are only cosmetic
3. Process alarms prove every communication fault is detected
4. Loss of measurement differs from a measured process excursion

**Correct option(s):** 4

- Option 1: Incorrect. It may produce invalid or stale values.
- Option 2: Incorrect. They can remove control visibility.
- Option 3: Incorrect. They test different conditions.
- Option 4: Correct. Both can require different responses.

**DCCA-Q0407 · single · mechanism**

What is alarm shelving?

1. Permanent correction of the physical fault
2. Automatic calibration of the sensor
3. Deletion of every event record
4. A controlled temporary suppression of selected annunciation

**Correct option(s):** 4

- Option 1: Incorrect. The underlying condition may remain.
- Option 2: Incorrect. Shelving does not adjust measurement.
- Option 3: Incorrect. That destroys traceability.
- Option 4: Correct. It requires scope and restoration.

**DCCA-Q0408 · single · mechanism**

Why can an alarm flood reduce safety?

1. More notifications always mean faster response
2. Important conditions compete with excessive notifications
3. Alarm count measures cooling capacity
4. Every duplicate alarm adds new physical evidence

**Correct option(s):** 2

- Option 1: Incorrect. Overload can delay prioritization.
- Option 2: Correct. Human attention and response capacity are limited.
- Option 3: Incorrect. It does not.
- Option 4: Incorrect. Duplicates may repeat the same condition.

**DCCA-Q0409 · single · mechanism**

Which evidence best tests the complete alarm chain?

1. A dashboard refresh only
2. An unexecuted procedure
3. A contact list alone
4. A controlled stimulus observed through field, system and responder stages

**Correct option(s):** 4

- Option 1: Incorrect. That does not exercise sensing or notification.
- Option 2: Incorrect. A plan is not a test result.
- Option 3: Incorrect. The contacts may not receive messages.
- Option 4: Correct. It connects physical condition to response.

**DCCA-Q0410 · single · mechanism**

What can wrong analog scaling cause?

1. Guaranteed network failure
2. Automatic sensor recalibration
3. A valid signal to display an incorrect engineering value
4. Correct units by default

**Correct option(s):** 3

- Option 1: Incorrect. Packets may still flow.
- Option 2: Incorrect. Scaling configuration is not necessarily physical calibration.
- Option 3: Correct. The mapping can be wrong despite successful transport.
- Option 4: Incorrect. Units must be configured and verified.

**DCCA-Q0411 · single · mechanism**

Why record an alarm's operating-state context?

1. Some thresholds or responses differ during approved modes
2. Every mode has identical risk
3. Context replaces a timestamp
4. Context allows all alarms to be ignored

**Correct option(s):** 1

- Option 1: Correct. Normal and maintenance states can have different expectations.
- Option 2: Incorrect. Dependencies and margins can change.
- Option 3: Incorrect. Both matter.
- Option 4: Incorrect. Exceptions must be controlled.

**DCCA-Q0412 · single · mechanism**

What is repeatability?

1. Automatic event notification
2. The number of display digits
3. Guaranteed accuracy against a reference
4. Closeness of repeated measurements under the same conditions

**Correct option(s):** 4

- Option 1: Incorrect. That is an alarm function.
- Option 2: Incorrect. That is resolution.
- Option 3: Incorrect. A biased device can be repeatable.
- Option 4: Correct. It is distinct from agreement with the true value.

**DCCA-Q0413 · single · mechanism**

A calibrated probe is installed in return air but labeled as server inlet. What failed?

1. The concept of temperature measurement
2. The reference instrument necessarily
3. Physical-to-logical mapping
4. Every cooling unit necessarily

**Correct option(s):** 3

- Option 1: Incorrect. The chain needs correction rather than rejection.
- Option 2: Incorrect. The calibration can still be valid.
- Option 3: Correct. Calibration does not correct the wrong measurement location.
- Option 4: Incorrect. The supplied defect is mapping.

**DCCA-Q0414 · single · mechanism**

Why keep a suppression expiry time?

1. Temporary reduced visibility must not become forgotten permanent exposure
2. Expiry increases measurement accuracy
3. All suppressions are acceptable forever
4. Time automatically repairs the sensor

**Correct option(s):** 1

- Option 1: Correct. The state needs controlled closure.
- Option 2: Incorrect. It is a governance control.
- Option 3: Incorrect. That defeats monitoring requirements.
- Option 4: Incorrect. Expiry prompts restoration rather than physical repair.

**DCCA-Q0415 · single · mechanism**

Which observation distinguishes alarm clearance from root-cause correction?

1. Acknowledgment and clearance are identical
2. Clearance always proves permanent repair
3. Root causes are unrelated to observed conditions
4. The condition can recur if the cause remains

**Correct option(s):** 4

- Option 1: Incorrect. Acknowledgment records receipt; clearance reflects state.
- Option 2: Incorrect. That overstates the evidence.
- Option 3: Incorrect. They explain the conditions.
- Option 4: Correct. A cleared threshold alone does not establish durable repair.

**DCCA-Q0416 · single · mechanism**

What should priority reflect?

1. Consequence and required response urgency
2. Alphabetical device order
3. Supplier preference alone
4. Number of characters in the alarm text

**Correct option(s):** 1

- Option 1: Correct. Severity should support operational action.
- Option 2: Incorrect. Names do not define consequence.
- Option 3: Incorrect. Site service and safety context matter.
- Option 4: Incorrect. Text length is irrelevant.

**DCCA-Q0417 · single · mechanism**

Why test notification receipt rather than only message generation?

1. Delivery can fail after the system sends
2. Reception proves the physical sensor is calibrated
3. A contact list can never become stale
4. Sending guarantees reception

**Correct option(s):** 1

- Option 1: Correct. The responder must actually receive the alert.
- Option 2: Incorrect. That remains separate.
- Option 3: Incorrect. People and roles change.
- Option 4: Incorrect. Networks, accounts and routing can fail.

**DCCA-Q0418 · single · mechanism**

What is an appropriate response to a persistent nuisance alarm?

1. Diagnose cause and improve the approved alarm design
2. Disable the entire monitoring system
3. Increase every threshold without analysis
4. Delete historical events

**Correct option(s):** 1

- Option 1: Correct. Repeated suppression does not resolve the issue.
- Option 2: Incorrect. That removes unrelated useful visibility.
- Option 3: Incorrect. That can hide real hazards.
- Option 4: Incorrect. History can help diagnose the problem.

**DCCA-Q0419 · single · mechanism**

Why include measurement range in calibration review?

1. Digital sensors have infinite range
2. Range is only a display preference
3. Any calibration point proves every possible value
4. A calibration may not cover the intended operating range

**Correct option(s):** 4

- Option 1: Incorrect. They have specified limits.
- Option 2: Incorrect. It affects measurement suitability.
- Option 3: Incorrect. Response can vary across range.
- Option 4: Correct. Evidence must fit the use.

**DCCA-Q0420 · single · mechanism**

Which recovery check follows replacement of an alarm sensor?

1. Only that the purchase order closed
2. Only that the alarm is quiet
3. Correct physical reading, mapping, thresholds and notification
4. Only the new serial number

**Correct option(s):** 3

- Option 1: Incorrect. Procurement state is not functional evidence.
- Option 2: Incorrect. Silence can also indicate failure.
- Option 3: Correct. The complete chain must be restored.
- Option 4: Incorrect. Identity is necessary but not sufficient.

#### Recall

**What is the difference between calibration and adjustment?**

Calibration compares; adjustment changes response Correct. A comparison need not alter the device.

**A display has three decimal places but ±1°C uncertainty. What do the decimals establish?**

Display resolution, not equivalent accuracy Correct. Fine formatting does not remove measurement error.

**An alarm activates at 30°C and clears at 28°C. What is the hysteresis band?**

2 K Correct. The activation and clearing thresholds differ by two degrees.

**Why can an alarm delay be unsafe if chosen blindly?**

The consequence may develop faster than the delay Correct. Filtering must respect process timing.

**What makes an alarm actionable?**

A meaningful condition with priority, owner and response Correct. Detection must lead to appropriate action.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)
- [NIST SP 800-82 Revision 3 — final OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

## DCCA-M22 — Capacity planning and controlled changes

### DCCA-L22 — Capacity planning and controlled changes

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L21

Capacity planning converts a service forecast into simultaneous constraints. Track space, weight, power, cooling, network ports and throughput, storage, management capacity and maintenance access. A request is feasible only when every binding constraint is satisfied in the required normal and failure states. Use measured demand, justified peak assumptions and explicit growth reservations; do not treat all nameplates as observed load or all averages as safe peaks.

Diversity describes noncoincident demand, but it is an assumption that must match workload behavior. AI training, batch jobs or recovery events can synchronize demand across many racks. Forecasts should include ranges and trigger points rather than a single precise number with no uncertainty. Stranded capacity occurs when one resource is available but another prevents its use, such as empty rack space with no usable cooling delivery.

A change begins with purpose, scope, affected services and prerequisites. The method of procedure identifies the actual sequence, verification points, hold points, rollback conditions and authority. A rollback must be technically possible within the remaining safe time; writing the word rollback does not make it executable. Some irreversible or slow actions need a recovery alternative rather than a simple reversal.

Before work, verify the effective state: correct asset, topology, backups, access, current alarms, remaining redundancy, spares and personnel. During work, compare each observed result with the expected result before proceeding. An unexpected condition triggers the approved hold or abort process. Afterward, validate service, restore temporary settings, update records and monitor for delayed effects.

Change success includes the intended improvement and absence of unacceptable side effects. A completed installation can still fail acceptance because monitoring is missing, redundancy was reduced or documentation is wrong. Use operational findings to refine the next design and procedure rather than treating ticket closure as the end of engineering.

### Decide feasibility from a resource vector
A proposed server needs 4U, 2.4 kW, 2.4 kW heat removal, two 25 Gbit/s ports and 70 kg supported mass. The destination has 8U, 3 kW power reserve, 2 kW cooling reserve, four suitable ports and approved mechanical capacity. Four constraints pass, but cooling fails by 0.4 kW. The proposal is not mostly acceptable; one mandatory resource is insufficient.

After correcting cooling, check the failure state. If the 3 kW power reserve exists only with both feeds present, it may disappear when one feed carries the total rack demand. State which resources are reserved and which workloads can coincide. A recovery job can synchronize activity that is normally diverse.

Write rollback as a timed sequence with prerequisites. If restoring the old controller takes 18 minutes while the safe degraded window is 12, the plan is infeasible. Reduce load, add supported reserve, change the method or choose another window through accountable review. After the change, validate the service and update the resource records so the next request starts from the real state.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A rack has 10U free and 8 kW electrical headroom, but only 3 kW verified cooling headroom. A proposed 4 kW device fits in 2U.

**Reasoning:** Cooling is the binding constraint. Space and electrical capacity do not compensate for the missing thermal margin; the request must be changed or the cooling constraint resolved.

#### Guided practice

A rollback needs 20 minutes, but the safe degraded-operation window is 10 minutes. Is the plan acceptable as written?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** No. The rollback cannot complete within the stated safe window. Change the method, reserve, load or recovery strategy before execution.

#### Independent task

Environment: analytical

Produce a change package for adding a management server.

**Packaged starter material**

- course_labs/DCCA/README.md
- course_labs/DCCA/scenario.json
- course_labs/DCCA/answers-template.json

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Check all capacity dimensions and failure states.
- Specify executable rollback and hold points.
- Validate effective service and update as-built records.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0421 · single · calculation**

A 4 kW device fits physically, but verified cooling headroom is 3 kW. What limits acceptance?

Synthetic educational evidence; not field measurements.

Device demand: 4 kW
Physical fit: yes
Verified cooling headroom: 3 kW

1. Electrical headroom alone
2. The purchase approval
3. U-space only
4. Cooling capacity

**Correct option(s):** 4

- Option 1: Incorrect. Power availability does not remove heat.
- Option 2: Incorrect. Funding does not establish technical feasibility.
- Option 3: Incorrect. Mechanical fit does not create heat-removal capacity.
- Option 4: Correct. All simultaneous constraints must be satisfied.

**DCCA-Q0422 · single · mechanism**

What is stranded capacity?

1. Every installed spare unit
2. Only unused network addresses
3. A resource that cannot be used because another constraint binds
4. Guaranteed future growth capacity

**Correct option(s):** 3

- Option 1: Incorrect. Spares can provide required resilience.
- Option 2: Incorrect. The concept applies across resources.
- Option 3: Correct. Available space can be stranded by power or cooling limits.
- Option 4: Incorrect. A binding constraint can prevent growth.

**DCCA-Q0423 · single · mechanism**

Why can average demand be inadequate for sizing?

1. Average values are always incorrect
2. Capacity never depends on time
3. Peaks and synchronized events can exceed the average
4. Nameplate values always equal real peaks

**Correct option(s):** 3

- Option 1: Incorrect. They can be accurate but insufficient.
- Option 2: Incorrect. Load changes over time.
- Option 3: Correct. The service must tolerate its required envelope.
- Option 4: Incorrect. They may overstate or differ from workload demand.

**DCCA-Q0424 · single · diagnosis**

A rollback needs 20 minutes but the safe window is 10 minutes. What is wrong?

Synthetic educational evidence; not field measurements.

Rollback duration: 20 min
Safe degraded window: 10 min

1. More signatures create extra time
2. The rollback is infeasible within the stated constraint
3. The rollback is automatically safe because documented
4. The safe window can be ignored

**Correct option(s):** 2

- Option 1: Incorrect. Approval does not alter physical timing.
- Option 2: Correct. A written reversal is not enough.
- Option 3: Incorrect. Documentation does not change duration.
- Option 4: Incorrect. It protects the service or equipment.

**DCCA-Q0425 · single · mechanism**

What should a hold point require?

1. Automatic continuation regardless of result
2. Only a calendar reminder
3. Deletion of unexpected observations
4. Verification of defined conditions before continuing

**Correct option(s):** 4

- Option 1: Incorrect. That defeats the hold.
- Option 2: Incorrect. The actual state must be checked.
- Option 3: Incorrect. Those are important evidence.
- Option 4: Correct. It prevents blind progression.

**DCCA-Q0426 · single · mechanism**

Why check current alarms before maintenance?

1. A signed plan guarantees current health
2. Alarms matter only after work
3. Existing defects can reduce the assumed safety margin
4. Every alarm means all work is forbidden

**Correct option(s):** 3

- Option 1: Incorrect. Conditions can change after approval.
- Option 2: Incorrect. Pre-existing conditions affect feasibility.
- Option 3: Correct. The effective state may differ from the planned state.
- Option 4: Incorrect. The response depends on assessed impact and authority.

**DCCA-Q0427 · single · mechanism**

What is a valid diversity assumption?

1. An arbitrary reduction to make the design fit
2. The number of equipment brands
3. A justified statement about noncoincident demand
4. A guarantee that no peaks ever align

**Correct option(s):** 3

- Option 1: Incorrect. That silently drops capacity requirements.
- Option 2: Incorrect. That is a different use of diversity.
- Option 3: Correct. It must reflect actual workload behavior.
- Option 4: Incorrect. Future behavior needs evidence and bounds.

**DCCA-Q0428 · single · mechanism**

Why preserve maintenance access in capacity planning?

1. Access can always be improvised during an incident
2. Access has no effect after commissioning
3. Only rack height matters
4. Installed equipment must remain serviceable

**Correct option(s):** 4

- Option 1: Incorrect. That can delay or endanger recovery.
- Option 2: Incorrect. Maintenance continues throughout life.
- Option 3: Incorrect. Depth, clearances and routes also matter.
- Option 4: Correct. Filling every space can make required work impractical.

**DCCA-Q0429 · single · mechanism**

Which action follows an unexpected field condition during a controlled change?

1. Rewrite the result to match the plan
2. Silence all alarms and proceed
3. Use the defined hold or abort process
4. Continue to preserve the schedule

**Correct option(s):** 3

- Option 1: Incorrect. That falsifies evidence.
- Option 2: Incorrect. That hides useful state.
- Option 3: Correct. The assumptions must be reassessed.
- Option 4: Incorrect. Schedule does not override failed prerequisites.

**DCCA-Q0430 · single · mechanism**

What should a change acceptance include beyond installation?

1. Only the ticket status
2. Only the delivery receipt
3. Only that the equipment powers on
4. Functional service, monitoring, redundancy and documentation checks

**Correct option(s):** 4

- Option 1: Incorrect. Administrative closure is not performance.
- Option 2: Incorrect. Delivery is not commissioning.
- Option 3: Incorrect. That is a narrow function.
- Option 4: Correct. The intended lifecycle result must be verified.

**DCCA-Q0431 · single · mechanism**

Why use forecast ranges and trigger points?

1. Growth is uncertain and action needs a timely threshold
2. Trigger points replace actual measurements
3. Forecasting eliminates every supply delay
4. Exact-looking numbers guarantee accuracy

**Correct option(s):** 1

- Option 1: Correct. A range supports planning under uncertainty.
- Option 2: Incorrect. They need measured state to act on.
- Option 3: Incorrect. Lead times remain relevant.
- Option 4: Incorrect. Precision does not remove uncertainty.

**DCCA-Q0432 · single · mechanism**

What is a method of procedure?

1. Only a project budget
2. A controlled execution sequence with checks and contingencies
3. An automatic credential
4. A risk assessment without an execution sequence

**Correct option(s):** 2

- Option 1: Incorrect. Cost is one planning input.
- Option 2: Correct. It describes how the work is performed.
- Option 3: Incorrect. A procedure does not award competence.
- Option 4: Incorrect. Risk analysis informs the procedure but does not specify each controlled work step.

**DCCA-Q0433 · single · mechanism**

Why verify the exact asset before intervention?

1. Asset identity is only an inventory concern
2. Labels can never be wrong
3. A rack number alone always identifies every device
4. Similar equipment can support different services and paths

**Correct option(s):** 4

- Option 1: Incorrect. It directly affects execution safety.
- Option 2: Incorrect. They require appropriate confirmation.
- Option 3: Incorrect. Multiple devices can share a rack.
- Option 4: Correct. Wrong-asset work can create an outage.

**DCCA-Q0434 · single · mechanism**

What distinguishes rollback from recovery?

1. Rollback reverses a change; recovery restores required function when simple reversal may not suffice
2. They are always identical operations
3. Recovery never needs backups
4. Rollback is automatically instantaneous

**Correct option(s):** 1

- Option 1: Correct. Some actions cannot be directly undone.
- Option 2: Incorrect. Their mechanisms can differ.
- Option 3: Incorrect. Restoration often depends on them.
- Option 4: Incorrect. It takes time and prerequisites.

**DCCA-Q0435 · single · mechanism**

Why remove temporary overrides after work?

1. They can alter future automatic behavior
2. Every override improves resilience permanently
3. Only the display remembers an override
4. Overrides have no effect once a ticket closes

**Correct option(s):** 1

- Option 1: Correct. A forgotten override changes effective control state.
- Option 2: Incorrect. It may bypass intended logic.
- Option 3: Incorrect. The controller can retain it.
- Option 4: Incorrect. Administrative closure does not change configuration.

**DCCA-Q0436 · single · mechanism**

What does failure-state capacity planning add?

1. It checks demand against surviving resources
2. It assumes all resources remain available
3. It treats spare capacity as free energy
4. It removes the need for load data

**Correct option(s):** 1

- Option 1: Correct. Normal capacity may rely on all units.
- Option 2: Incorrect. That would not test failure states.
- Option 3: Incorrect. Spares have physical and operating constraints.
- Option 4: Incorrect. Demand is still essential.

**DCCA-Q0437 · single · mechanism**

Why retain delayed post-change monitoring?

1. Some effects emerge after load or operating conditions change
2. Successful monitoring proves no future fault
3. Monitoring replaces rollback planning
4. All defects appear in the first second

**Correct option(s):** 1

- Option 1: Correct. Immediate success may miss later problems.
- Option 2: Incorrect. The observation interval is finite.
- Option 3: Incorrect. Both remain useful.
- Option 4: Incorrect. Thermal and workload effects can be delayed.

**DCCA-Q0438 · single · mechanism**

What should a capacity reservation identify?

1. Only the requester's job title
2. Every resource as unlimited
3. Only a vague future project name
4. Resource, amount, owner and validity or review point

**Correct option(s):** 4

- Option 1: Incorrect. Authority alone does not define demand.
- Option 2: Incorrect. That defeats capacity control.
- Option 3: Incorrect. The quantity and resource must be known.
- Option 4: Correct. Otherwise stale reservations can distort planning.

**DCCA-Q0439 · single · mechanism**

Which record supports learning from a change?

1. Only the total email count
2. Expected versus observed behavior and resulting procedure improvements
3. Deletion of near misses
4. Only a success label

**Correct option(s):** 2

- Option 1: Incorrect. Communication volume is not the result.
- Option 2: Correct. Engineering should incorporate operational evidence.
- Option 3: Incorrect. Near misses can reveal weaknesses.
- Option 4: Incorrect. That hides useful detail.

**DCCA-Q0440 · single · mechanism**

What is the correct response to an infeasible requirement combination?

1. Remove the hardest constraint without notice
2. Accept the average result while one mandatory limit fails
3. Declare success because most conditions pass
4. Expose the conflict and evaluate explicit alternatives

**Correct option(s):** 4

- Option 1: Incorrect. That misrepresents the design.
- Option 2: Incorrect. Mandatory constraints apply individually as well as collectively.
- Option 3: Incorrect. All mandatory conditions matter.
- Option 4: Correct. Do not silently drop constraints.

#### Recall

**A 4 kW device fits physically, but verified cooling headroom is 3 kW. What limits acceptance?**

Cooling capacity Correct. All simultaneous constraints must be satisfied.

**What is stranded capacity?**

A resource that cannot be used because another constraint binds Correct. Available space can be stranded by power or cooling limits.

**Why can average demand be inadequate for sizing?**

Peaks and synchronized events can exceed the average Correct. The service must tolerate its required envelope.

**A rollback needs 20 minutes but the safe window is 10 minutes. What is wrong?**

The rollback is infeasible within the stated constraint Correct. A written reversal is not enough.

**What should a hold point require?**

Verification of defined conditions before continuing Correct. It prevents blind progression.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)
- [NIST SP 800-82 Revision 3 — final OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

## DCCA-M23 — Energy metrics and efficiency boundaries

### DCCA-L23 — Energy metrics and efficiency boundaries

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L22

Efficiency decisions require a defined boundary and useful output. Power usage effectiveness is total facility energy divided by IT equipment energy over compatible boundaries and intervals. A PUE of 1.5 means total energy is 1.5 times IT energy; the overhead is 0.5 times IT energy. It does not mean that IT performs useful work efficiently, and it does not measure water use or carbon intensity.

Use energy totals rather than combining unrelated instantaneous values when reporting an interval metric. Meter placement, shared services, estimation and excluded loads must be documented. A changing IT denominator can move PUE without any improvement in the cooling or power system. For example, fixed facility overhead divided by a larger IT load yields a lower ratio even if overhead energy is unchanged.

Electrical and cooling losses create opportunities at multiple points. Consolidating idle IT can reduce its direct energy and the associated cooling demand, but redundancy and performance requirements must remain satisfied. Airflow corrections can reduce unnecessary fan work; optimized setpoints can improve plant efficiency within equipment and moisture constraints. UPS efficiency should be evaluated at the actual load and mode rather than at one favorable rating point.

Metrics complement rather than replace one another. Water-use intensity needs a stated water boundary and IT-energy denominator. Carbon accounting depends on energy quantity, time, source and the chosen accounting method. A low PUE at a water-intensive site is not automatically the best overall result. Compare cost, reliability, water, emissions and service output under the actual local constraints.

An efficiency change needs a baseline and a fair comparison. Normalize for workload, weather and operating state where relevant, retain uncertainty and verify that no constraint was violated. Savings calculated from a model should be labeled estimated until measured. A lower utility bill alone can result from price or workload changes rather than improved engineering efficiency.

### Interpret efficiency ratios with absolute quantities
Facility A uses 900 MWh for IT and 300 MWh overhead, so PUE is 1200/900=1.333. A consolidation project lowers IT energy to 600 MWh and overhead to 240 MWh. Total energy falls from 1200 to 840 MWh, a 360 MWh reduction, but PUE rises to 1.4. The project can save energy even while the ratio worsens because the denominator changed more than overhead.

This example is why useful work, absolute energy and resource boundaries belong beside PUE. If computing output is unchanged, energy per unit of useful work may improve; if output falls, the interpretation differs. Water and carbon need their own quantities and accounting assumptions.

For measurement, sum energy over matched intervals. If one meter includes shared office loads while another site excludes them, direct ratio comparison needs qualification. Keep modeled savings separate from observed savings and normalize relevant workload or weather differences. Finally verify service and resilience: turning off required standby equipment can lower overhead while violating the actual facility requirement.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. A facility uses 1500 MWh while its IT equipment uses 1000 MWh over the same month and boundary.

**Reasoning:** PUE is 1.5. Facility overhead is 500 MWh. This does not establish compute productivity, carbon emissions or water impact.

#### Guided practice

Overhead stays at 300 MWh while IT energy rises from 600 to 900 MWh. What happens to PUE?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** It falls from 1.5 to 1.333 even though overhead did not decrease. Interpret the denominator change before claiming a cooling improvement.

#### Independent task

Environment: analytical

Create an energy improvement proposal with a baseline and acceptance criteria.

**Packaged starter material**

- course_labs/DCCA/README.md
- course_labs/DCCA/scenario.json
- course_labs/DCCA/answers-template.json

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Define meter boundaries and intervals.
- Separate PUE from IT productivity, water and carbon.
- Verify service and resilience constraints alongside savings.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0441 · single · calculation**

A facility uses 1500 MWh and IT uses 1000 MWh over the same interval. What is PUE?

Synthetic educational evidence; not field measurements.

Facility energy: 1500 MWh
IT energy: 1000 MWh
Same period and metering boundary.

1. 500
2. 2.5
3. 1.5
4. 0.667

**Correct option(s):** 3

- Option 1: Incorrect. That is the overhead energy in MWh.
- Option 2: Incorrect. Adding one again double-counts the IT portion.
- Option 3: Correct. Total facility energy divided by IT energy gives the ratio.
- Option 4: Incorrect. The ratio is reversed.

**DCCA-Q0442 · single · calculation**

For PUE 1.5 and IT energy 1000 MWh, what is facility overhead?

1. 500 MWh
2. 2500 MWh
3. 1000 MWh
4. 1500 MWh

**Correct option(s):** 1

- Option 1: Correct. Overhead is total 1500 minus IT 1000.
- Option 2: Incorrect. That double-counts components.
- Option 3: Incorrect. That is IT energy.
- Option 4: Incorrect. That is total facility energy.

**DCCA-Q0443 · single · mechanism**

What does PUE not directly measure?

1. Useful computing productivity
2. Facility-to-IT energy ratio
3. Relative facility overhead under the stated boundary
4. Total energy when IT energy is also known

**Correct option(s):** 1

- Option 1: Correct. IT energy can be consumed by inefficient workloads.
- Option 2: Incorrect. That is its definition.
- Option 3: Incorrect. That is what the ratio helps express.
- Option 4: Incorrect. Multiplication can recover the total.

**DCCA-Q0444 · single · mechanism**

Why match metering intervals for PUE?

1. Any two energy readings are interchangeable
2. Any monthly total can be paired with any instantaneous IT reading
3. Numerator and denominator must describe the same period
4. Instantaneous power always equals monthly energy

**Correct option(s):** 3

- Option 1: Incorrect. Duration matters.
- Option 2: Incorrect. Energy and power or mismatched periods do not form the intended interval ratio.
- Option 3: Correct. Mismatched intervals distort the ratio.
- Option 4: Incorrect. They are different quantities.

**DCCA-Q0445 · single · calculation**

Fixed overhead is 300 MWh and IT energy rises from 600 to 900 MWh. What is the new PUE?

Synthetic educational evidence; not field measurements.

Overhead energy: 300 MWh unchanged
IT energy: 600 → 900 MWh

1. About 1.333
2. 0.333
3. 1.5
4. 4

**Correct option(s):** 1

- Option 1: Correct. Total is 1200 divided by 900.
- Option 2: Incorrect. That is overhead divided by IT, not total divided by IT.
- Option 3: Incorrect. That was the original ratio.
- Option 4: Incorrect. That reverses and misuses the quantities.

**DCCA-Q0446 · single · mechanism**

Why can lower PUE occur without reduced overhead energy?

1. PUE always measures absolute savings
2. Overhead is excluded from PUE
3. IT energy cannot change
4. A larger IT denominator can lower the ratio

**Correct option(s):** 4

- Option 1: Incorrect. It is a ratio.
- Option 2: Incorrect. It is included in total facility energy.
- Option 3: Incorrect. Workload and equipment changes can alter it.
- Option 4: Correct. The arithmetic must be interpreted with absolute values.

**DCCA-Q0447 · single · mechanism**

What is needed to claim measured energy savings?

1. Only a lower electricity price
2. A defensible baseline and comparable measured post-change conditions
3. Only a smaller invoice total
4. Only a modeled estimate

**Correct option(s):** 2

- Option 1: Incorrect. Price changes do not prove reduced energy.
- Option 2: Correct. Other drivers must be considered.
- Option 3: Incorrect. Workload and tariff changes can explain it.
- Option 4: Incorrect. A model is not a measurement.

**DCCA-Q0448 · single · mechanism**

Why evaluate UPS efficiency at actual loading?

1. Efficiency can vary with load and operating mode
2. Every UPS has constant efficiency at all loads
3. Nameplate kVA equals annual energy
4. Loading affects only rack height

**Correct option(s):** 1

- Option 1: Correct. One favorable rating point may not represent use.
- Option 2: Incorrect. Loss components vary.
- Option 3: Incorrect. Capacity is not consumption.
- Option 4: Incorrect. It affects electrical operation.

**DCCA-Q0449 · single · mechanism**

Which condition should accompany an efficiency optimization?

1. Disable all redundancy to minimize power
2. Remove every alarm to reduce nuisance
3. Required service and resilience remain satisfied
4. Ignore inlet limits if the bill falls

**Correct option(s):** 3

- Option 1: Incorrect. That can violate availability requirements.
- Option 2: Incorrect. Monitoring is still needed.
- Option 3: Correct. Savings cannot silently drop mandatory constraints.
- Option 4: Incorrect. Thermal suitability remains mandatory.

**DCCA-Q0450 · single · mechanism**

What does water-use effectiveness require for interpretation?

1. A stated water boundary and denominator
2. Only the number of chillers
3. Only outdoor temperature
4. Only the PUE value

**Correct option(s):** 1

- Option 1: Correct. Different accounting boundaries can change the metric.
- Option 2: Incorrect. Equipment count does not establish consumption.
- Option 3: Incorrect. Climate matters but is not the full metric.
- Option 4: Incorrect. PUE does not measure water.

**DCCA-Q0451 · single · mechanism**

Why is a low PUE not automatically low carbon?

1. Carbon emissions are independent of energy
2. Carbon depends on energy source and accounting conditions
3. IT energy produces no upstream impact
4. PUE already includes every emission factor

**Correct option(s):** 2

- Option 1: Incorrect. Energy supply can be a major contributor.
- Option 2: Correct. The ratio does not encode emissions intensity.
- Option 3: Incorrect. Its electricity supply can have emissions.
- Option 4: Incorrect. It is an energy ratio.

**DCCA-Q0452 · single · calculation**

A lower monthly bill follows a tariff reduction with unchanged kWh. What changed?

1. Cooling performance necessarily improved
2. PUE necessarily improved
3. Cost rather than measured energy efficiency
4. IT productivity necessarily increased

**Correct option(s):** 3

- Option 1: Incorrect. The tariff does not demonstrate thermal behavior.
- Option 2: Incorrect. No facility/IT energy change is stated.
- Option 3: Correct. The energy quantity did not fall.
- Option 4: Incorrect. No output change is stated.

**DCCA-Q0453 · single · mechanism**

Why can airflow management reduce energy use?

1. It can reduce unnecessary fan work and mixing
2. It eliminates all heat generation
3. Blanking panels generate electricity
4. It makes every temperature limit irrelevant

**Correct option(s):** 1

- Option 1: Correct. Better delivery can support efficient operation.
- Option 2: Incorrect. IT still dissipates power.
- Option 3: Incorrect. They alter air paths rather than produce energy.
- Option 4: Incorrect. Equipment constraints remain.

**DCCA-Q0454 · single · mechanism**

What should a modeled savings figure be called before verification?

1. Guaranteed lifetime savings
2. An official facility rating
3. An estimate under stated assumptions
4. Production-proven savings

**Correct option(s):** 3

- Option 1: Incorrect. Future conditions can change.
- Option 2: Incorrect. Savings modeling is not certification.
- Option 3: Correct. It is not yet a measured result.
- Option 4: Incorrect. No production comparison has been made.

**DCCA-Q0455 · single · mechanism**

Why retain absolute energy alongside PUE?

1. PUE includes total energy in its unit
2. Absolute energy cannot be metered
3. The ratio can improve while total consumption rises
4. Absolute energy is always misleading

**Correct option(s):** 3

- Option 1: Incorrect. PUE is dimensionless.
- Option 2: Incorrect. Meters can measure accumulated energy.
- Option 3: Correct. Both magnitude and overhead proportion matter.
- Option 4: Incorrect. It answers a different useful question.

**DCCA-Q0456 · single · mechanism**

Which workload factor matters in before/after comparisons?

1. Only the installed CPU count
2. Only the invoice date
3. Only the project name
4. Useful work performed and demand profile

**Correct option(s):** 4

- Option 1: Incorrect. Installed hardware does not establish the useful work or utilization in each period.
- Option 2: Incorrect. The period matters but workload also matters.
- Option 3: Incorrect. Naming does not establish comparability.
- Option 4: Correct. A lower load can explain lower energy.

**DCCA-Q0457 · single · mechanism**

Why consider weather when assessing cooling savings?

1. Weather never affects heat rejection
2. Outdoor conditions can change plant energy demand
3. Normalization makes all uncertainty disappear
4. Weather changes only rack dimensions

**Correct option(s):** 2

- Option 1: Incorrect. It can strongly affect it.
- Option 2: Correct. A cooler month can reduce consumption without a design improvement.
- Option 3: Incorrect. It improves comparison but retains assumptions.
- Option 4: Incorrect. It affects thermal conditions.

**DCCA-Q0458 · single · mechanism**

What is the direct energy effect of removing a truly unnecessary idle server?

1. Cooling energy becomes exactly zero
2. PUE must always improve
3. Every resilience requirement is automatically preserved
4. Its IT energy and associated facility burden can decrease

**Correct option(s):** 4

- Option 1: Incorrect. Other loads remain.
- Option 2: Incorrect. A smaller denominator can make PUE worse even as total energy falls.
- Option 3: Incorrect. The server's role must be checked.
- Option 4: Correct. The full boundary may benefit.

**DCCA-Q0459 · single · mechanism**

Which comparison best supports a multi-constraint efficiency decision?

1. Maximum advertised cooling capacity alone
2. PUE alone in all locations
3. Purchase price alone
4. Energy, water, emissions, cost and service behavior under stated conditions

**Correct option(s):** 4

- Option 1: Incorrect. Capacity is not overall efficiency or suitability.
- Option 2: Incorrect. It omits several material impacts.
- Option 3: Incorrect. Lifecycle performance and cost matter.
- Option 4: Correct. No single ratio captures every objective.

**DCCA-Q0460 · single · mechanism**

Why document shared-service energy allocation?

1. Every facility uses the same boundary automatically
2. Shared loads are always zero
3. Boundary choices can materially change reported metrics
4. Allocation removes the need for meters

**Correct option(s):** 3

- Option 1: Incorrect. Practices and site arrangements can differ.
- Option 2: Incorrect. They can be substantial.
- Option 3: Correct. Readers need to know what is included.
- Option 4: Incorrect. Measurement and allocation serve different roles.

#### Recall

**A facility uses 1500 MWh and IT uses 1000 MWh over the same interval. What is PUE?**

1.5 Correct. Total facility energy divided by IT energy gives the ratio.

**For PUE 1.5 and IT energy 1000 MWh, what is facility overhead?**

500 MWh Correct. Overhead is total 1500 minus IT 1000.

**What does PUE not directly measure?**

Useful computing productivity Correct. IT energy can be consumed by inefficient workloads.

**Why match metering intervals for PUE?**

Numerator and denominator must describe the same period Correct. Mismatched intervals distort the ratio.

**Fixed overhead is 300 MWh and IT energy rises from 600 to 900 MWh. What is the new PUE?**

About 1.333 Correct. Total is 1200 divided by 900.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DCCA-M24 — Lifecycle cost, growth and sustainable choices

### DCCA-L24 — Lifecycle cost, growth and sustainable choices

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L23

A data-center infrastructure choice commits future operation as well as purchase money. Total cost of ownership includes capital, energy, maintenance, spares, licenses, staffing, downtime exposure, replacement and disposal under a defined study period. Compare alternatives delivering the same required service; a cheaper option with insufficient capacity or recoverability is not an equivalent candidate.

Simple payback divides initial additional cost by annual net savings. It is easy to interpret but ignores cash flows after payback and the time value of money. Net present value discounts future cash flows using a stated rate and period. Neither method removes uncertainty: energy price, load growth, maintenance needs and equipment life should be varied in sensitivity analysis.

Scalability is the ability to expand within a planned architecture. Modular equipment can defer capital and improve loading but may add interfaces, controls or maintenance complexity. Oversizing everything immediately can waste capital and operate equipment inefficiently at low load. Undersizing can force disruptive reconstruction. Define expansion triggers based on actual demand, lead time and reserve rather than selecting one extreme by habit.

Sustainability also includes material use, repairability, water, refrigerants, waste and responsible end-of-life treatment. Extending service life can reduce replacement burden, but obsolete equipment may become inefficient, unsupported or difficult to secure. Decide from the whole lifecycle and required function rather than assuming newest or oldest is always best.

Procurement should preserve evidence and supportability: performance at relevant conditions, compatible interfaces, service access, spares, documentation, security updates and recovery procedures. Contracts should make acceptance criteria clear before delivery. A vendor claim is a source statement; installed measurements are a different evidence category. Retain both, identify the gap and resolve it through appropriate acceptance tests.

### Compare alternatives over a stated horizon
Option A costs 100,000 and uses 20,000 per year in energy and maintenance. Option B costs 125,000 and uses 14,000 per year. The additional cost is 25,000 and annual saving is 6,000, giving simple payback of 4.17 years. Over five years without discounting or replacement, A totals 200,000 and B totals 195,000. Over three years, A is cheaper at 160,000 versus 167,000. The preferred result depends on the study horizon.

Now vary the assumptions. If B's annual saving is only 3,000, its simple payback becomes 8.33 years. If it requires a major replacement in year four, the five-year result changes again. A precise spreadsheet output should not conceal uncertain utilization, energy price, support cost or equipment life.

Only compare options that satisfy the required service. An inexpensive design without the agreed maintenance state is a different product, not a cheaper equivalent. Record repair access, spares, recovery and expansion interfaces alongside financial results. These often determine whether the projected lifecycle cost is achievable.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. Option B costs 20,000 more than A and saves an estimated 5,000 per year in net operating cost. Both meet the stated service requirement.

**Reasoning:** Simple payback is four years. A full choice also considers study period, discount rate, uncertainty, maintenance and replacement effects. The estimate is not yet measured savings.

#### Guided practice

A modular expansion needs 12 months from approval to commissioning. Current reserve is projected to last 8 months. What does the forecast imply?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** The trigger is already too late under those assumptions. Reassess temporary capacity, demand or procurement timing rather than waiting until reserve reaches zero.

#### Independent task

Environment: analytical

Compare two synthetic cooling options over a stated study period.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Use equivalent service constraints.
- Separate capital and recurring costs.
- Perform sensitivity analysis on at least two uncertain inputs.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0461 · single · diagnosis**

An upgrade costs 20,000 and saves 5,000 annually. What is simple payback?

Synthetic educational evidence; not field measurements.

Additional investment: 20,000
Annual net saving: 5,000

1. 15,000 years
2. 25 years
3. 0.25 years
4. 4 years

**Correct option(s):** 4

- Option 1: Incorrect. Subtracting costs does not produce time.
- Option 2: Incorrect. Adding or mis-scaling the values is incorrect.
- Option 3: Incorrect. The ratio is reversed.
- Option 4: Correct. Initial cost divided by annual savings gives four.

**DCCA-Q0462 · single · mechanism**

What does simple payback omit?

1. Annual savings
2. The idea of elapsed time
3. Initial cost
4. Time value of money and later cash flows

**Correct option(s):** 4

- Option 1: Incorrect. That is in the denominator.
- Option 2: Incorrect. That is its output.
- Option 3: Incorrect. That is in the numerator.
- Option 4: Correct. It is a limited screening metric.

**DCCA-Q0463 · single · mechanism**

Why compare options against the same service requirement?

1. Purchase price proves equivalent resilience
2. Requirements are irrelevant to finance
3. Otherwise lower cost may simply buy less required capability
4. Every cheap option is unsuitable

**Correct option(s):** 3

- Option 1: Incorrect. It does not.
- Option 2: Incorrect. They define what value is purchased.
- Option 3: Correct. The alternatives must be functionally comparable.
- Option 4: Incorrect. Some can meet requirements efficiently.

**DCCA-Q0464 · single · mechanism**

What does net present value introduce?

1. Guaranteed future energy prices
2. Discounted future cash flows over a stated period
3. Elimination of every risk
4. A direct measurement of rack temperature

**Correct option(s):** 2

- Option 1: Incorrect. Those remain assumptions.
- Option 2: Correct. It accounts for timing under an assumed rate.
- Option 3: Incorrect. Uncertainty still exists.
- Option 4: Incorrect. It is a financial model.

**DCCA-Q0465 · single · mechanism**

Why perform sensitivity analysis?

1. It makes assumptions unnecessary
2. It replaces all technical acceptance
3. It proves one forecast must occur
4. Uncertain inputs can change the preferred option

**Correct option(s):** 4

- Option 1: Incorrect. It explicitly varies them.
- Option 2: Incorrect. Financial and technical evidence differ.
- Option 3: Incorrect. Scenarios are not predictions of certainty.
- Option 4: Correct. It exposes decision robustness.

**DCCA-Q0466 · single · diagnosis**

An expansion takes 12 months but reserve lasts 8 months. What is the planning issue?

Synthetic educational evidence; not field measurements.

Commissioned expansion lead time: 12 months
Forecast reserve exhaustion: 8 months

1. Lead time exceeds available headroom duration
2. There is a four-month surplus
3. Procurement can wait until capacity is exhausted
4. Lead time affects only accounting

**Correct option(s):** 1

- Option 1: Correct. Action or demand adjustment is needed earlier.
- Option 2: Incorrect. The difference is a shortfall.
- Option 3: Incorrect. That would miss the required date.
- Option 4: Incorrect. It affects service readiness.

**DCCA-Q0467 · single · mechanism**

What is a possible benefit of modular growth?

1. Defer capital and align installed capacity with demand
2. Guarantee zero maintenance
3. Make future compatibility irrelevant
4. Eliminate every interface and control

**Correct option(s):** 1

- Option 1: Correct. Expansion can follow actual need.
- Option 2: Incorrect. Equipment still needs lifecycle work.
- Option 3: Incorrect. Expansion depends on compatible design.
- Option 4: Incorrect. Modules can add interfaces.

**DCCA-Q0468 · single · mechanism**

What is a possible downside of excessive initial oversizing?

1. Capital is tied up and part-load efficiency may suffer
2. It eliminates all common failures
3. It always improves every efficiency metric
4. It guarantees demand forecasts

**Correct option(s):** 1

- Option 1: Correct. Unused capacity has lifecycle costs.
- Option 2: Incorrect. Shared dependencies can remain.
- Option 3: Incorrect. Equipment behavior varies with loading.
- Option 4: Incorrect. Future workload remains uncertain.

**DCCA-Q0469 · single · mechanism**

Which cost belongs in total cost of ownership?

1. Only the initial invoice
2. Maintenance, energy and eventual replacement
3. Only the lowest annual energy bill
4. Only the supplier's advertising budget

**Correct option(s):** 2

- Option 1: Incorrect. That omits recurring and end-of-life costs.
- Option 2: Correct. The study extends beyond purchase.
- Option 3: Incorrect. Other lifecycle costs matter.
- Option 4: Incorrect. That is not the owner's operating cost.

**DCCA-Q0470 · single · mechanism**

Why can old equipment be costly despite zero new purchase cost?

1. Energy, support and failure exposure can remain high
2. Old equipment is always safer
3. Existing equipment consumes no energy
4. Replacement always improves every outcome

**Correct option(s):** 1

- Option 1: Correct. Sunk cost does not eliminate future cost.
- Option 2: Incorrect. Support and condition vary.
- Option 3: Incorrect. It still operates.
- Option 4: Incorrect. That also requires analysis.

**DCCA-Q0471 · single · mechanism**

What can make a new product a poor lifecycle choice?

1. Weak support, incompatible interfaces or difficult recovery
2. A documented maintenance procedure
3. Any higher efficiency rating
4. Its recent release date alone

**Correct option(s):** 1

- Option 1: Correct. Novelty does not ensure suitability.
- Option 2: Incorrect. Documentation supports lifecycle use.
- Option 3: Incorrect. Efficiency can be beneficial but is not the whole decision.
- Option 4: Incorrect. Age alone is not decisive.

**DCCA-Q0472 · single · mechanism**

Why specify acceptance criteria before procurement?

1. Criteria eliminate every contract dispute
2. Suppliers and reviewers need a common measurable target
3. Only price should be agreed beforehand
4. Delivery automatically proves all claims

**Correct option(s):** 2

- Option 1: Incorrect. They reduce ambiguity but cannot guarantee that.
- Option 2: Correct. Ambiguity is harder to resolve after delivery.
- Option 3: Incorrect. Performance and responsibilities matter.
- Option 4: Incorrect. Installed behavior still needs verification.

**DCCA-Q0473 · single · mechanism**

What is the evidence category of a vendor efficiency curve?

1. Supplier-provided performance information under stated conditions
2. Independent installed commissioning evidence
3. An automatic guarantee of savings
4. Production observation at every load

**Correct option(s):** 1

- Option 1: Correct. It is not the site's measured result.
- Option 2: Incorrect. No site test is implied.
- Option 3: Incorrect. Actual operating conditions matter.
- Option 4: Incorrect. The curve has defined test conditions.

**DCCA-Q0474 · single · mechanism**

Why include spare-parts availability in evaluation?

1. Repair time and lifecycle continuity depend on support
2. Spare cost is the only ownership cost
3. Spares eliminate every failure
4. Any spare fits every product

**Correct option(s):** 1

- Option 1: Correct. An efficient device can still be difficult to restore.
- Option 2: Incorrect. Many costs remain.
- Option 3: Incorrect. They support repair rather than prevent all faults.
- Option 4: Incorrect. Compatibility matters.

**DCCA-Q0475 · single · mechanism**

Which factor belongs in end-of-life planning?

1. Safe disposal, data handling and environmental obligations
2. Leaving all credentials active
3. Only removing the asset label
4. Assuming waste has no cost

**Correct option(s):** 1

- Option 1: Correct. Retirement is part of the lifecycle.
- Option 2: Incorrect. Access should be controlled through decommissioning.
- Option 3: Incorrect. That does not complete retirement.
- Option 4: Incorrect. Treatment and disposal can have costs and requirements.

**DCCA-Q0476 · single · mechanism**

Why can water availability affect cooling economics?

1. Water is universally unlimited and free
2. Consumption, treatment and resilience costs vary by site
3. Only electricity price matters
4. PUE already includes every water cost

**Correct option(s):** 2

- Option 1: Incorrect. Local conditions differ.
- Option 2: Correct. Water is a real resource constraint.
- Option 3: Incorrect. Other lifecycle inputs can be material.
- Option 4: Incorrect. It is an energy ratio.

**DCCA-Q0477 · single · mechanism**

What should an expansion trigger include?

1. Only the calendar year
2. Only a sales promotion deadline
3. Only the number of proposals received
4. Demand forecast, lead time and required reserve

**Correct option(s):** 4

- Option 1: Incorrect. Time alone may not reflect demand.
- Option 2: Incorrect. That is not a service-based trigger.
- Option 3: Incorrect. Procurement activity does not establish capacity need.
- Option 4: Correct. Waiting until exhaustion is often too late.

**DCCA-Q0478 · single · mechanism**

How should an estimated cost saving be reported?

1. With assumptions, study period and uncertainty
2. Without the baseline
3. As guaranteed measured savings
4. Only as a percentage without scope

**Correct option(s):** 1

- Option 1: Correct. The reader must understand its basis.
- Option 2: Incorrect. The comparison needs a reference.
- Option 3: Incorrect. An estimate is not a measurement.
- Option 4: Incorrect. The denominator and boundary matter.

**DCCA-Q0479 · single · mechanism**

What is a repairability consideration?

1. Whether components can be serviced with available skills and parts
2. Whether documentation can be discarded
3. Whether the device is the newest model
4. Only exterior appearance

**Correct option(s):** 1

- Option 1: Correct. Maintainability affects lifetime cost and downtime.
- Option 2: Incorrect. Documentation supports repair.
- Option 3: Incorrect. Newness alone is insufficient.
- Option 4: Incorrect. Appearance does not establish serviceability.

**DCCA-Q0480 · single · mechanism**

Which procurement choice best supports recoverability?

1. Supported backups, restoration procedures and replacement compatibility
2. A large marketing claim without test conditions
3. A proprietary interface with no documented recovery
4. The lowest purchase price regardless of support

**Correct option(s):** 1

- Option 1: Correct. Recovery needs an executable path.
- Option 2: Incorrect. Claims require verifiable scope.
- Option 3: Incorrect. That weakens the recovery case.
- Option 4: Incorrect. That can increase restoration risk.

#### Recall

**An upgrade costs 20,000 and saves 5,000 annually. What is simple payback?**

4 years Correct. Initial cost divided by annual savings gives four.

**What does simple payback omit?**

Time value of money and later cash flows Correct. It is a limited screening metric.

**Why compare options against the same service requirement?**

Otherwise lower cost may simply buy less required capability Correct. The alternatives must be functionally comparable.

**What does net present value introduce?**

Discounted future cash flows over a stated period Correct. It accounts for timing under an assumed rate.

**Why perform sensitivity analysis?**

Uncertain inputs can change the preferred option Correct. It exposes decision robustness.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DCCA-M25 — Integrated facility acceptance and trusted recovery

### DCCA-L25 — Integrated facility acceptance and trusted recovery

Estimated study time: 55 minutes before independent work. Prerequisite chapters: DCCA-L24

An integrated acceptance test asks whether the data center delivers its required service when several systems interact. Component tests remain necessary, but the overall chain can fail at interfaces: generator start without cooling restart, network failover without identity service, accurate sensors mapped to the wrong screen, or a restored controller with unsafe stale settings. Build the test from a service requirement rather than a list of products.

Define initial conditions, load, stimulus, expected transitions, measurement points, pass limits, abort conditions and restoration. Synchronize relevant timestamps and retain raw evidence. Include the normal state, specified single failures, planned maintenance and the agreed recovery sequence. A test is only valid within its stated boundary; a simulated utility-loss contact is different from physically removing the source, and neither automatically proves every regional outage scenario.

Recovery has two dimensions: restoring function and restoring trust. After a suspected compromise, powering a server back on may reintroduce the same unauthorized configuration or credential. Preserve appropriate evidence, contain through approved boundaries, identify known-good software and configuration, restore required identities and secrets, and verify both physical process behavior and security state. The exact response belongs to the site incident plan and authorized team.

The physical process remains the priority constraint. A containment action that disconnects a supervisory network can remove visibility or command paths; determine local controller behavior and safe degraded operation before treating network isolation as universally harmless. Coordinate facilities, controls, network, security and service owners through a common event timeline and decision record.

Close the lifecycle loop after restoration. Reconcile inventories and diagrams, rearm alarms, remove temporary overrides, restore redundancy, confirm backups and record unresolved risk. Compare the observed failure with the original design assumptions. Improvement may require architecture, monitoring, training, spares or procedure changes. The final claim should state exactly what was designed, simulated, physically tested or observed in production; passing this course establishes study progress rather than unrestricted operating authority.

### Assemble an evidence chain for one integrated claim
The claim is: after loss of the normal source, a controls historian continues collecting valid samples while the facility enters the approved generator-supported state. Required evidence includes UPS continuity, generator transfer, network and identity availability, database writes, sample freshness, time alignment, cooling continuity and operator notification. A green power panel proves only one part.

Define the test load and stimulus precisely. If utility loss is represented by an injected controller input, state which electrical effects were not exercised. Observe the sequence and retain source records rather than only a final pass slide. Include an abort threshold for unsafe temperature, unstable power or lost process visibility under the approved plan.

Recovery then checks both function and trust. Restore normal sources, recharge reserve, reconcile buffered data, remove temporary overrides and verify approved configurations and credentials. Record every unresolved issue with an owner. The final statement should say what passed under which conditions and what remains simulated, analytical or awaiting authorized physical evidence.

#### Worked demonstrations

**Engineering demonstration**

Synthetic educational case. During a synthetic source-loss exercise, UPS output remains stable and the generator accepts load, but a cooling controller loses its configuration and no pumps restart.

**Reasoning:** Electrical continuity alone does not meet the integrated thermal service requirement. The controller’s recovery dependency and supported backup/restore path must be resolved, then the integrated sequence retested within approved boundaries.

#### Guided practice

A server restored from backup is online but retains a compromised administrator credential. Is trusted recovery complete?

**Hint:** Separate required function, measured state, shared dependencies and evidence quality before choosing an action.

**Worked solution:** No. Functional startup is not restoration of authorized state. Credential and configuration trust must be re-established and verified.

#### Independent task

Environment: analytical

Write an integrated acceptance and recovery dossier for a synthetic controls service.

**Packaged starter material**

**Evidence to produce**

- Annotated engineering decision sheet with calculations, assumptions and an evidence plan.
- Show the reasoning and identify what remains unmeasured; a checker pass alone is not acceptance of a real installation.

**Acceptance criteria**

- Trace requirements through power, cooling, communications, identity and control.
- Distinguish simulated stimuli from physical execution.
- Verify restored function, trust, monitoring and redundancy before closure.

Synthetic analytical work is not an executed facility intervention or proof of equipment performance.

#### Chapter practice

**DCCA-Q0481 · single · diagnosis**

A generator transfers successfully but cooling does not restart. What does the integrated test show?

Synthetic educational evidence; not field measurements.

UPS continuity: passed
Generator transfer: passed
Cooling restart: failed

1. That component tests have no value
2. A guaranteed network defect
3. The complete service requirement has not been met
4. Full facility acceptance

**Correct option(s):** 3

- Option 1: Incorrect. They remain necessary but insufficient alone.
- Option 2: Incorrect. The cause may lie in control or cooling recovery.
- Option 3: Correct. Electrical continuity alone does not assure thermal continuity.
- Option 4: Incorrect. One required dependency failed.

**DCCA-Q0482 · single · mechanism**

What should define an integrated test's starting point?

1. A required service and explicit operating conditions
2. The shortest possible checklist
3. The most expensive product
4. The supplier with the longest warranty

**Correct option(s):** 1

- Option 1: Correct. The test must assess a meaningful outcome.
- Option 2: Incorrect. Completeness depends on requirements.
- Option 3: Incorrect. Price does not define service acceptance.
- Option 4: Incorrect. Warranty is not the test objective.

**DCCA-Q0483 · single · mechanism**

Why specify abort conditions before testing?

1. Unexpected states may threaten safety or service
2. Abort conditions guarantee no unexpected event
3. They replace restoration planning
4. Every test should continue regardless of harm

**Correct option(s):** 1

- Option 1: Correct. The team needs a controlled stop decision.
- Option 2: Incorrect. They govern response rather than prediction.
- Option 3: Incorrect. Both are needed.
- Option 4: Incorrect. That violates the controlled boundary.

**DCCA-Q0484 · single · mechanism**

What distinguishes a simulated source-loss signal from physical source removal?

1. Simulation cannot test any logic
2. They prove exactly the same conditions in every system
3. The stimulus bypasses some real electrical behavior
4. Physical removal automatically proves every outage scenario

**Correct option(s):** 3

- Option 1: Incorrect. It can test selected responses.
- Option 2: Incorrect. Actual paths and transients can differ.
- Option 3: Correct. The evidence has a narrower fidelity boundary.
- Option 4: Incorrect. It still has a defined scope.

**DCCA-Q0485 · single · mechanism**

Why synchronize test timestamps?

1. Synchronization repairs faulty equipment
2. Cross-system transitions need reliable correlation
3. All devices naturally share exact time
4. Time alignment removes every causal uncertainty

**Correct option(s):** 2

- Option 1: Incorrect. It improves observation rather than physical function.
- Option 2: Correct. Otherwise event order can be ambiguous.
- Option 3: Incorrect. Clock drift and settings can differ.
- Option 4: Incorrect. It helps but does not prove causation alone.

**DCCA-Q0486 · single · diagnosis**

A restored server is online with a compromised credential still active. What remains incomplete?

Synthetic educational evidence; not field measurements.

Restored server: online
Previously compromised administrator credential: still active

1. The existence of a backup
2. Restoration of trust
3. Every cooling function necessarily
4. Basic power delivery necessarily

**Correct option(s):** 2

- Option 1: Incorrect. A backup may have been used successfully.
- Option 2: Correct. Function can return while unauthorized access remains possible.
- Option 3: Incorrect. The credential evidence does not establish that.
- Option 4: Incorrect. The server is already online.

**DCCA-Q0487 · single · mechanism**

What should be verified before isolating a controls network during an incident?

1. Local control behavior and safe degraded operation
2. That no operational coordination is needed
3. That all controllers immediately stop safely
4. Only the number of packets

**Correct option(s):** 1

- Option 1: Correct. Isolation can affect physical visibility and authority.
- Option 2: Incorrect. Facilities and control owners must be involved.
- Option 3: Incorrect. That cannot be assumed.
- Option 4: Incorrect. Traffic count alone does not establish process consequence.

**DCCA-Q0488 · single · mechanism**

Which recovery source is preferable for configuration?

1. Any file with a familiar name
2. The newest file regardless of provenance
3. An unverified internet example
4. A verified known-good baseline appropriate to the system

**Correct option(s):** 4

- Option 1: Incorrect. Naming does not establish trust.
- Option 2: Incorrect. Recent files can be compromised or incorrect.
- Option 3: Incorrect. It may not match the installation.
- Option 4: Correct. Recovery must avoid reintroducing the suspected state.

**DCCA-Q0489 · single · mechanism**

Why preserve raw test evidence?

1. Screenshots always contain every relevant field
2. It supports independent review of claims and timing
3. Raw evidence makes analysis unnecessary
4. A pass label proves all raw observations

**Correct option(s):** 2

- Option 1: Incorrect. They can omit context and source data.
- Option 2: Correct. Summaries can omit important detail.
- Option 3: Incorrect. Interpretation is still needed.
- Option 4: Incorrect. The underlying result must be available.

**DCCA-Q0490 · single · mechanism**

What belongs in post-recovery closure?

1. Restored alarms, redundancy, records and removal of temporary overrides
2. Only silencing alarms
3. Only a successful login
4. Only deleting the incident ticket

**Correct option(s):** 1

- Option 1: Correct. The effective normal state must be re-established.
- Option 2: Incorrect. Silence can hide unresolved conditions.
- Option 3: Incorrect. That tests a narrow function.
- Option 4: Incorrect. Records should be retained.

**DCCA-Q0491 · single · mechanism**

Why test identity dependencies with a controls service?

1. Identity never affects OT systems
2. Successful ping proves authentication
3. Access or authentication failure can interrupt required operation
4. Every controller uses the same identity mechanism

**Correct option(s):** 3

- Option 1: Incorrect. Many depend on accounts or certificates.
- Option 2: Incorrect. It does not exercise login or authorization.
- Option 3: Correct. Power and network alone may not deliver the application.
- Option 4: Incorrect. Architectures differ.

**DCCA-Q0492 · single · mechanism**

What is the proper claim after an analytical recovery exercise?

1. Guaranteed future recovery time
2. A reviewed recovery design or simulation under stated assumptions
3. Production-proven recovery
4. Unrestricted operating authorization

**Correct option(s):** 2

- Option 1: Incorrect. Real conditions can differ.
- Option 2: Correct. No physical execution is implied.
- Option 3: Incorrect. There was no production observation.
- Option 4: Incorrect. Competence and authority are separate.

**DCCA-Q0493 · single · mechanism**

Why compare observed failures with design assumptions?

1. Every failure is solely operator error
2. The findings can reveal missing dependencies or unsuitable margins
3. Tests exist only to produce green status
4. Design documents are never revised

**Correct option(s):** 2

- Option 1: Incorrect. Architecture and equipment can contribute.
- Option 2: Correct. Operations should improve engineering.
- Option 3: Incorrect. They are also learning and assurance mechanisms.
- Option 4: Incorrect. They should track justified changes.

**DCCA-Q0494 · single · mechanism**

What should an integrated test measure at the application boundary?

1. Only room-average temperature
2. Only rack power LEDs
3. The required transactions or process function under the stimulus
4. Only switch port link state

**Correct option(s):** 3

- Option 1: Incorrect. That omits the application result.
- Option 2: Incorrect. They do not establish application delivery.
- Option 3: Correct. Infrastructure indicators alone can miss service failure.
- Option 4: Incorrect. That proves a narrower transport condition.

**DCCA-Q0495 · single · mechanism**

Why retain a common incident timeline across teams?

1. Chronology alone proves malicious intent
2. Power, controls, network and security events can interact
3. A common timeline replaces technical logs
4. Every team sees the same evidence automatically

**Correct option(s):** 2

- Option 1: Incorrect. Attribution needs additional evidence.
- Option 2: Correct. Shared chronology supports coordination and diagnosis.
- Option 3: Incorrect. It should link to them.
- Option 4: Incorrect. They often observe different systems.

**DCCA-Q0496 · single · mechanism**

What does a successful backup job fail to prove?

1. That some backup process ran
2. That restoration yields the required functioning and trusted system
3. That a file was created in every implementation
4. That backups have no value

**Correct option(s):** 2

- Option 1: Incorrect. The job result may support that narrow fact.
- Option 2: Correct. Restore testing is a separate step.
- Option 3: Incorrect. Details depend on the backup system.
- Option 4: Incorrect. They are essential inputs when usable.

**DCCA-Q0497 · single · mechanism**

Which question exposes a recovery dependency?

1. What services must already work before this component can be restored?
2. Which component has the highest nameplate power
3. How many backup files exist, without checking what restores them
4. How many slides describe the system?

**Correct option(s):** 1

- Option 1: Correct. Recovery order can contain hidden prerequisites.
- Option 2: Incorrect. Power rating alone does not define restoration dependency order.
- Option 3: Incorrect. File count does not reveal prerequisites such as identity, licenses or network services.
- Option 4: Incorrect. Presentation length does not reveal dependencies.

**DCCA-Q0498 · single · mechanism**

Why test the return to normal after a fault exercise?

1. Restoration is never observable
2. The test ends when the first alarm appears
3. A passed failure phase guarantees every final state
4. The exercise can leave reduced capacity or temporary settings

**Correct option(s):** 4

- Option 1: Incorrect. It can be measured and checked.
- Option 2: Incorrect. That omits the response and recovery chain.
- Option 3: Incorrect. It does not.
- Option 4: Correct. Recovery is part of acceptance.

**DCCA-Q0499 · single · mechanism**

What should be done with unresolved risk at closure?

1. Record it with scope, owner and explicit acceptance or further action
2. Omit it to keep the report concise
3. Assume no news means acceptance
4. Convert it into a guaranteed capability

**Correct option(s):** 1

- Option 1: Correct. It must not disappear behind ticket status.
- Option 2: Incorrect. That misstates readiness.
- Option 3: Incorrect. Authority must be explicit.
- Option 4: Incorrect. That reverses the evidence.

**DCCA-Q0500 · single · mechanism**

Which statement accurately describes completing this learning bank?

1. Proof of production ownership across every facility
2. Permission to perform electrical switching
3. Automatic award of the provider credential
4. Evidence of study and assessed knowledge, requiring separate practical proof and authorization

**Correct option(s):** 4

- Option 1: Incorrect. No production observations are implied.
- Option 2: Incorrect. Authority and competence require separate controls.
- Option 3: Incorrect. The provider has its own process.
- Option 4: Correct. A quiz does not establish all hands-on capability.

#### Recall

**A generator transfers successfully but cooling does not restart. What does the integrated test show?**

The complete service requirement has not been met Correct. Electrical continuity alone does not assure thermal continuity.

**What should define an integrated test's starting point?**

A required service and explicit operating conditions Correct. The test must assess a meaningful outcome.

**Why specify abort conditions before testing?**

Unexpected states may threaten safety or service Correct. The team needs a controlled stop decision.

**What distinguishes a simulated source-loss signal from physical source removal?**

The stimulus bypasses some real electrical behavior Correct. The evidence has a narrower fidelity boundary.

**Why synchronize test timestamps?**

Cross-system transitions need reliable correlation Correct. Otherwise event order can be ambiguous.

#### References

- [Schneider Electric University: DCCA public scope](https://www.se.com/ww/en/about-us/university/)
- [US DOE/FEMP: Energy-efficient data center design, 2024](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)
- [NIST SP 800-82 Revision 3 — final OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
