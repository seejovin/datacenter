# Controls Advanced — overview notes

These are short introductory overviews, including overviews of advanced topics. They are introductory companion notes. The new detailed course books are in docs/academy, with their own source mappings and scope limits. Answers follow each question. Practical assignment briefs require further instruction and execution.

## L-OT-01 — Requirements, control narratives and interface design

Overview · Target topic stage: Applied · 45 estimated overview study minutes · Prerequisites: DC-11, DC-15

Translate a facility function into states, transitions and measurable acceptance limits.

### Learning objectives

- Translate a facility function into states, transitions and measurable acceptance limits.
- Trace commands and alarms through interfaces, authority and common dependencies.
- Review normal, degraded, maintenance and restart behavior before implementation.

A control narrative explains what the installation must do, under what conditions, and who may change its behavior. Start with the physical service: maintaining an agreed supply temperature, reporting a breaker state, or limiting a laboratory pump command. Then identify inputs, outputs, limits, equipment constraints and operators. A statement such as “provide resilient cooling” is incomplete until the expected load, permitted interruption, measurement location and required response are stated. Product selection follows the agreed function; installing a familiar controller does not resolve an ambiguous requirement.

Represent operation as named states. A small pump example may have Stopped, Starting, Running, Stopping, Faulted and Maintenance states. Specify entry conditions, actions while active, exit conditions and time limits. “Start command present” is different from “running feedback received.” A transition to Running should depend on the approved proof of operation; expiration of a start timer should produce the specified response. State priority also matters: a maintenance selection, supervisory request and local protective trip can occur together. The design must make the intended precedence testable.

A permissive is a condition required before an action may proceed. An interlock constrains or prevents action when specified conditions apply. A protective function may be implemented in independent equipment and must retain its authority. Do not silently turn every software alarm into a protective trip, or assume that acknowledging an alarm resets an interlock. For each item record whether it inhibits starting, stops running equipment, latches a fault, requires manual reset or merely informs an operator. Define how input quality affects these decisions.

Use a cause-and-effect matrix to make combinations visible. Rows describe initiating conditions; columns describe commands, alarms, mode changes and reset requirements. Include lost feedback, stale measurements, communications failure, loss of controller power and return of power. A restarted controller should not accidentally reuse an old supervisory command merely because that value was retained. Define how commands expire, how ownership is re-established and which state survives a restart. A safe default is application-specific and must respect the approved equipment sequence.

Interfaces need more than a list of protocol names. For every exchanged point record identity, engineering units, range, direction, update expectation, quality representation, source authority and consumer. Add the relationship between command, acknowledgment, equipment feedback and measured process result. A command acknowledgment establishes that a message was accepted; it does not establish that a valve moved or that water flowed. A dependency model should include controller power, switch power, I/O racks, network paths, time sources and supervisory services as well as mechanical equipment.

Turn requirements into tests before building the application. If the laboratory requirement says a missing running indication must be alarmed within five seconds, define the timing origin, clock accuracy, allowed scan variation and observable output. Test immediately before and after the threshold as well as the usual case. Review common-cause failures: two pumps controlled by one I/O rack are not independent simply because their motors have different labels. Record open assumptions and ask an appropriate reviewer to accept the design boundary.

The curriculum assigns BAS200 and Schneider engineering instruction as the taught route. This lesson prepares and assesses the reasoning used in that training. A functional design becomes portfolio evidence only when its requirements, implementation and test results agree. During operation, unexpected alarm sequences or maintenance difficulties should cause a controlled revision of the narrative and affected tests, preserving a visible history of why behavior changed.

### Worked example

An illustrative sequence requires running feedback within 5.0 s of an accepted start. The command is accepted at 10:00:00.000; feedback arrives at 10:00:05.400. A 100 ms controller task cannot justify accepting this as on time. The observed delay is 5.4 s, beyond the specified limit. Hold acceptance, determine whether equipment response, filtering or the requirement is wrong, and obtain a reviewed correction. Do not simply extend the timer to make the failed test pass.

### Guided practice

A pump is in Maintenance, a remote start is pending, and power is restored. Write the design questions that must be settled before running the test.

**Hint:** Separate command ownership, retained state and independent protection.

**Worked solution:** Resolve whether Maintenance survives power loss, who may release it, whether the remote request expires, which permissives must be reacquired, and what independent protection enforces. Define the expected output and alarm for the combined state before executing a bounded simulation.

#### L-OT-01-Q1 — A start is acknowledged but flow remains zero. What has been established?

1. The pump is delivering its design flow.
2. The flow sensor must be faulty.
3. Message acceptance only; verify feedback and process response.

**Answer:** 3

- Option 1: Acknowledgment does not measure flow.
- Option 2: Several faults can explain zero flow; evidence is needed.
- Option 3: Acknowledgment and physical outcome are separate requirements.

#### L-OT-01-Q2 — Two controllers use separate network links but one power supply. Which design finding is valid?

1. All redundancy must be removed.
2. The shared supply is a common dependency requiring assessment.
3. Two links prove controller independence.

**Answer:** 2

- Option 1: A dependency finding calls for analysis and correction, not arbitrary removal.
- Option 2: Trace each claimed independent function to power and supporting services.
- Option 3: Link diversity does not eliminate shared power loss.

#### L-OT-01-Q3 — The requirement says alarm within five seconds; the measured delay is 5.4 seconds. What disposition is justified?

1. Hold acceptance and investigate against the approved requirement.
2. Round down because the trend looks normal.
3. Change the timer without review.

**Answer:** 1

- Option 1: Failure against a stated limit needs diagnosis and authorized resolution.
- Option 2: Rounding hides the failed criterion.
- Option 3: Changing requirements to fit results destroys traceability.

#### L-OT-01-Q4 — An operator acknowledges a protective trip alarm. What should determine whether equipment can restart?

1. The fact that the alarm is acknowledged.
2. Return of supervisory communications alone.
3. The approved reset and protection sequence.

**Answer:** 3

- Option 1: Acknowledgment does not automatically release a trip.
- Option 2: Restored communication does not by itself satisfy the required protection reset and restart sequence.
- Option 3: Awareness, reset and permission to restart are different states.

#### L-OT-01-Q5 — A supplier lists Modbus TCP support without a point map. What remains unresolved?

1. Nothing; a protocol name guarantees interoperability.
2. Point semantics, addressing, quality, authority and timing.
3. Only the TCP port number.

**Answer:** 2

- Option 1: A shared transport does not define a common application model.
- Option 2: Interoperability depends on the actual exchanged information and behavior.
- Option 3: A reachable transport endpoint still lacks the point map, data representation and application behavior.

#### L-OT-01-Q6 — A restart test replays an old start request. Which design omission is most relevant?

1. Command expiry and ownership after restart.
2. The width of the trend chart.
3. The number of training certificates.

**Answer:** 1

- Option 1: Restart behavior must define retained commands and renewed authority.
- Option 2: Presentation does not govern retained control state.
- Option 3: Attendance does not define application behavior.

### Independent assignment

Environment: analytical

Produce WP-OT-01 for a bounded cooling-control function.

**Steps**

- Define service, operating envelope and authority.
- Draft states, transitions, point list and cause/effect matrix.
- Review normal, fault, maintenance and restart test cases.

**Deliverables**

- Approved functional design
- Requirement-to-command/alarm/test matrix
- Dependency and assumption register

**Acceptance Criteria**

- Every command and alarm traces to a requirement and test.
- Combined-state precedence and restart are explicit.
- Reviewer dispositions resolve or retain every assumption.

Analytical design evidence alone does not demonstrate a commissioned controller.

### Sources

- [BAS200 — Control Sequence Fundamentals](https://courses.smartbuildingsacademy.com/products/control-sequence-fundamentals)
- [Schneider building management training](https://www.se.com/uk/en/work/services/training/ecobuildings/building-management-training/)

## L-OT-02 — Instrumentation, I/O and measurement assurance

Overview · Target topic stage: Applied · 45 estimated overview study minutes · Prerequisites: L-OT-01, DC-12

Calculate scaling and measurement uncertainty for a representative control loop.

### Learning objectives

- Calculate scaling and measurement uncertainty for a representative control loop.
- Diagnose sensor, wiring and configuration faults using physical and digital evidence.
- Retain as-found and as-left evidence when recommissioning a measurement.

Measurement assurance begins with the engineering decision that consumes the measurement. A temperature sensor used for room trending may tolerate a different uncertainty and response time from a sensor used to regulate a small laboratory thermal loop. Select range, accuracy, response, environmental rating, installation position and supported interface against that decision. Resolution is the smallest displayed increment; accuracy concerns closeness to the reference. A display showing two decimal places does not make an installed sensor accurate to one hundredth of a degree.

Trace the complete measurement chain: physical quantity, sensing element, transmitter, wiring, input module, raw conversion, engineering scaling, point mapping and presentation. Record the units at every conversion. A four-to-twenty milliampere transmitter uses a nonzero live minimum, which can support fault diagnosis when the selected equipment reports an out-of-range current. The exact fault currents and status codes are product-dependent. Do not apply assumed thresholds without checking the selected transmitter and input documentation. A current value is neither a temperature nor proof of correct sensor placement until its configuration and installation are verified.

For a linear transmitter, engineering value equals lower engineering range plus the signal fraction multiplied by engineering span. A 4–20 mA transmitter representing 0–100 °C gives 50 °C at 12 mA: the fraction is (12−4)/(20−4)=0.5. Scaling 0–20 mA instead would report 60 °C. Both are plausible temperatures, making this error harder to detect than a blank screen. Verify at several points including the useful operating region; agreement at one point can conceal slope or offset errors.

Wiring faults and measurement faults can resemble each other. An open circuit, reversed connection, incorrect supply, damaged shield arrangement or wrong input type may produce a bad status, saturation or intermittent noise. Use a safe low-energy training loop and suitable calibrated instruments under competent supervision. Follow the equipment instructions for terminal connections, isolation, shielding and grounding. Do not experiment on an energized electrical distribution measurement circuit. Current transformers and other power-measurement interfaces require their own specialist procedures and authority.

Uncertainty should accompany acceptance decisions. List the reference instrument uncertainty, transmitter specification, input conversion contribution and important installation effects. Use a stated method for combining them. Summing absolute bounds gives a conservative worst-case estimate; root-sum-square assumptions require appropriate independence and statistical interpretation. If a process must stay within a narrow band, measurement uncertainty consumes part of that band. Comparing two sensors is useful, but agreement does not prove accuracy if both share the same installation error or calibration source.

Calibration records need as-found readings before adjustment and as-left readings after correction. Record asset identity, serial number, range, reference instrument, traceability information, date, method, ambient conditions and person performing the work. An as-found error may change the interpretation of historical alarms and previous operating decisions. Adjustment without retaining the original readings removes evidence of the fault. After calibration, verify the controller, supervisory display, alarm thresholds and historian so that a corrected instrument is not undermined by a stale scaling configuration elsewhere.

A field measurement is trustworthy only within its declared limits. Authentication can establish which device sent a value, but it cannot establish that the probe is in the right pipe or that its impulse line is clear. Commission a representative real sensing and actuation loop for OT-02; software signal injection is useful preparation and a separate evidence class. The independent assessment must distinguish at least one physical or wiring fault from a scaling or mapping fault and document the retest that closes each finding.

### Worked example

At 4, 12 and 20 mA a configured 0–100 °C input reports 0.2, 50.3 and 100.4 °C. Relative to ideal scaling, the errors are +0.2, +0.3 and +0.4 °C. If the illustrative allowed total error is ±0.5 °C and the test reference contributes a conservative ±0.2 °C bound, the top point cannot demonstrate compliance using simple worst-case bounds: 0.4+0.2=0.6 °C. Improve measurement confidence or correct and retest; do not report an unqualified pass.

### Guided practice

A transmitter label says 0–10 bar at 4–20 mA; the BMS reads 6 bar at 12 mA. What should you inspect?

**Hint:** Calculate the expected value before assuming a pressure fault.

**Worked solution:** The expected value is 5 bar. Trace transmitter range, input type, controller scaling, gateway mapping and BMS units. Compare with a suitable pressure reference under the approved procedure. Preserve as-found settings and readings before correction.

#### L-OT-02-Q1 — A 0–100 °C, 4–20 mA transmitter produces 12 mA. What is the ideal scaled value?

1. 60 °C.
2. 12 °C.
3. 50 °C.

**Answer:** 3

- Option 1: Sixty results from incorrectly treating the signal as 0–20 mA.
- Option 2: Current and temperature are different quantities.
- Option 3: The signal is halfway through its sixteen-milliampere span.

#### L-OT-02-Q2 — The display resolution is 0.01 °C. What accuracy can be claimed from that fact?

1. The sensor never needs calibration.
2. No installed accuracy claim follows from resolution alone.
3. The complete loop is accurate to ±0.01 °C.

**Answer:** 2

- Option 1: Fine display increments do not eliminate drift.
- Option 2: Sensor, conversion, installation and reference uncertainties remain.
- Option 3: Resolution is not total measurement accuracy.

#### L-OT-02-Q3 — An adjustment was made without saving as-found readings. What evidence is lost?

1. The original error and its possible effect on earlier decisions.
2. Only evidence of the final calibrated state.
3. Nothing if the as-left value looks reasonable.

**Answer:** 1

- Option 1: As-found data supports fault attribution and retrospective evaluation.
- Option 2: As-left readings can preserve the final state, but cannot reconstruct the missing original error.
- Option 3: A corrected value cannot reconstruct the previous error.

#### L-OT-02-Q4 — Authenticated telemetry disagrees with a calibrated local reference. What should happen?

1. Accept the authenticated value automatically.
2. Disable authentication to improve accuracy.
3. Investigate the physical measurement and conversion chain.

**Answer:** 3

- Option 1: Authenticity does not establish correct placement or calibration.
- Option 2: Removing authentication does not repair measurement error.
- Option 3: Source identity and physical correctness are separate properties.

#### L-OT-02-Q5 — Observed error is 0.4 °C and a conservative reference bound is 0.2 °C; limit is 0.5 °C. Can worst-case compliance be demonstrated?

1. Yes; subtract the reference bound.
2. No; the combined bound reaches 0.6 °C.
3. Yes; ignore the reference uncertainty.

**Answer:** 2

- Option 1: Uncertainty cannot be removed by favorable subtraction.
- Option 2: Under the stated conservative method the acceptance margin is insufficient.
- Option 3: Reference uncertainty is part of the test confidence.

#### L-OT-02-Q6 — Software injection verifies scaling. What additional evidence is required for OT-02?

1. A representative real loop with wiring, calibration and fault diagnosis.
2. A second screenshot of the same simulation.
3. A course badge alone.

**Answer:** 1

- Option 1: The curriculum distinguishes physical instrumentation from simulated values.
- Option 2: Repeating a screenshot does not exercise installation faults.
- Option 3: Attendance does not demonstrate the required physical work.

### Independent assignment

Environment: physical_lab

Wire, calibrate and recommission one safe low-energy sensing loop.

**Steps**

- Record range, reference and expected scaling.
- Measure at multiple points and retain as-found values.
- Diagnose an instructor-introduced wiring or scaling fault.
- Correct and verify controller, display and history.

**Deliverables**

- Loop diagram and calibration record
- Raw readings with uncertainty method
- Fault diagnosis and as-left retest

**Acceptance Criteria**

- Scaling and units agree throughout the chain.
- Acceptance accounts for measurement uncertainty.
- Physical and digital fault causes are distinguished.

Low-energy laboratory evidence does not authorize power-system measurements or live-site electrical work.

### Sources

- [Schneider Control Panels & Field Equipment](https://www.se.com/uk/en/work/services/training/ecobuildings/building-management-training/)
- [Siemens TIA-PRO1 / selected input documentation](https://www.sitrain-learning.siemens.com/en/rw1105/Online-Training-SIMATIC-Programming-1-in-TIA-Portal)

## L-OT-03 — PLC/DDC programming and the Siemens application lifecycle

Overview · Target topic stage: Applied · 45 estimated overview study minutes · Prerequisites: L-OT-01, L-OT-02

Explain task execution, state retention and typed reusable control blocks.

### Learning objectives

- Explain task execution, state retention and typed reusable control blocks.
- Test a supported PLC/DDC application through faults, restart and controlled change.
- Plan Siemens engineering and service progression with explicit tool-access gates.

A PLC or direct digital controller executes an application within a vendor-supported runtime. Engineering begins with the reviewed sequence, I/O list and task model. Cyclic execution often reads an input image, evaluates logic and updates outputs, but event tasks, direct I/O access and communications can create different timing relationships. Read the selected controller documentation and observe the actual task behavior. A simulation that updates every variable immediately can hide a stale-input or scheduling defect that appears on the physical controller.

In the selected Siemens route, organization blocks establish execution contexts; functions perform reusable operations; function blocks retain instance state; and data blocks hold application data. These distinctions matter when two identical pumps use one reusable block. Each pump needs appropriate independent state: sharing a timer or fault latch unintentionally can couple their behavior. Define typed interfaces with engineering units, valid ranges, quality and ownership. An integer raw input should not be treated as a floating-point engineering value without a deliberate conversion and range check.

Implement the approved sequence as explicit states and transitions. A start timeout should start on the specified event, stop or reset as designed, and behave predictably when the command is withdrawn. A retained variable survives selected restart conditions; it is not necessarily still valid for the current physical plant. Decide which settings persist, which transient states are recomputed and which commands expire. At startup, establish input quality and required permissives before issuing outputs. Test the sequence with adverse combinations, including communications loss during Starting and an input returning after a fault.

Separate application version, library version, hardware configuration, firmware and engineering-tool version. A project archive without the required library or supported device configuration may not reproduce the approved application. Use version control for exportable text and an artifact register for vendor project files. Record checksums, dependencies, release notes and the signed review or approval appropriate to the site. Online changes deserve impact analysis: a small source edit can alter retained data layouts, initialization or timing even when the changed line looks harmless.

The curriculum retains TIA-PRO1, practical use, TIA-PRO2, sufficient SCL fundamentals and practical use before TIA-PRO3. TIA-SCL1 is assigned when the assessed gap requires it; completing PRO2 is not a universal formal prerequisite for SCL1. Missing Siemens service outcomes remain required through assessed TIA-SERV2 and TIA-SERV3 teaching. Do not purchase duplicate tracks merely to collect attendance, but do not treat engineering attendance as proof of service competence. CODESYS foundations and selected Schneider DDC application engineering support the same outcome without replacing the chosen Siemens platform.

PLCSIM Advanced requires explicit instruction and access for virtual CPU setup, interface configuration, process-model connection, timing, fault reproduction and restoration. Virtual exercises included with a programming course do not automatically close that assignment. A process model should expose its assumptions: ideal sensors, no actuator wear and simplified network timing change what the test can demonstrate. Record which faults were represented and which physical behaviors remain untested. A simulator is a learning environment, not a new runtime to install in place of the selected vendor controller.

Commission by observing commands, actual I/O feedback and process results against the sequence. A successful download only shows that a transfer completed. After a controlled change, test affected behavior and credible regressions; after restoration, verify the approved project, parameter values, device identity, communications, alarms and physical function. During service, preserve diagnostics before resets when the operating situation permits. Independent acceptance requires an unfamiliar bounded fault, a justified diagnosis and a functional retest rather than a memorized sequence of tool clicks.

### Worked example

A cyclic task runs every 100 ms and accepts a start at t=0. A five-second timeout is tested at scans around 4.9, 5.0 and 5.1 s. The specification must define whether the alarm is due by 5.0 s or within one task interval after a five-second elapsed condition. A trace at 5.1 s is not automatically a pass. Resolve timing semantics with the reviewer and measure the implemented behavior, including input filter delay.

### Guided practice

Two pump instances share one start timer; starting pump B resets pump A’s timeout. How would you correct and assess the design?

**Hint:** Identify instance data before changing the sequence itself.

**Worked solution:** Give each pump block its own timer/state instance, preserve the approved external interface, test overlapping starts and each independent timeout, then test restart and communications-loss behavior. Review data-layout and download effects before applying a change to physical equipment.

#### L-OT-03-Q1 — Starting pump B resets pump A’s timer. What design issue best explains this?

1. Too many independent data blocks.
2. A mandatory property of all PLCs.
3. Unintended sharing of instance state.

**Answer:** 3

- Option 1: Independent instance state is normally the remedy here.
- Option 2: The symptom follows the application design, not an unavoidable controller rule.
- Option 3: Reusable code should preserve separate state where independent behavior is required.

#### L-OT-03-Q2 — A retained start command survives a restart. What must the application establish before acting?

1. That the engineering laptop is connected.
2. Validity, ownership, mode and required permissives.
3. Only that the variable is nonzero.

**Answer:** 2

- Option 1: Laptop connectivity is not a start permissive unless expressly designed.
- Option 2: Retained data may no longer represent current operational intent.
- Option 3: A stored value alone does not establish authority.

#### L-OT-03-Q3 — The archived project lacks its library version. What is the consequence?

1. Reproducible restoration is not yet demonstrated.
2. Restoration is reproducible if the project opens without an error.
3. All libraries can be replaced by the newest release without review.

**Answer:** 1

- Option 1: The approved application depends on matching artifacts and compatibility.
- Option 2: Opening a project does not establish matching approved libraries, generated behavior or successful restoration.
- Option 3: Library changes can alter behavior and require validation.

#### L-OT-03-Q4 — A learner completed PRO2 but has weak SCL fundamentals. What does the curriculum require?

1. Skip SCL because attendance proves competence.
2. Repeat every Siemens course automatically.
3. Assess the gap and assign SCL teaching before advanced application work.

**Answer:** 3

- Option 1: Course completion does not establish all prerequisites.
- Option 2: The curriculum avoids unnecessary duplication while retaining outcomes.
- Option 3: Progression follows usable knowledge and practical evidence.

#### L-OT-03-Q5 — A PRO course included virtual exercises. Is the PLCSIM Advanced assignment automatically closed?

1. Yes; only the simulator name matters.
2. No; explicit setup, integration, timing and recovery teaching must be evidenced.
3. Yes; any virtual exercise covers every simulator capability.

**Answer:** 2

- Option 1: Product naming does not demonstrate instruction or assessment.
- Option 2: The assigned simulation outcomes and access are separate gates.
- Option 3: Different exercises cover different functions and limits.

#### L-OT-03-Q6 — A restored controller accepts its project download. What remains to be verified?

1. Parameters, identities, I/O, sequence, alarms and physical function.
2. Only that the HMI can reconnect.
3. Nothing; download success proves commissioning.

**Answer:** 1

- Option 1: Functional restoration includes the entire approved application chain.
- Option 2: An HMI connection does not verify parameter values, I/O, sequence and physical function.
- Option 3: A successful transfer can still leave incorrect configuration or behavior.

### Independent assignment

Environment: physical_lab

Implement, change and restore a reviewed application on the selected controller.

**Steps**

- Build typed blocks and independent instances.
- Test sequence, task timing, input faults and restart.
- Make an approved logic change with regression tests.
- Restore the approved archive and verify physical I/O/function.

**Deliverables**

- Versioned project and dependency manifest
- Task/state traces and fault matrix
- Change, rollback and restoration results

**Acceptance Criteria**

- Each instance behaves independently.
- Restart and bad-input behavior matches the narrative.
- Restoration includes functional retest.

Vendor simulation supports preparatory evidence; physical controller and supervised process work remain separate requirements.

### Sources

- [TIA-PRO1](https://www.sitrain-learning.siemens.com/en/rw1105/Online-Training-SIMATIC-Programming-1-in-TIA-Portal)
- [TIA-PRO2](https://www.sitrain-learning.siemens.com/en/rw73126/Online-Training-SIMATIC-Programming-2-in-TIA-Portal)
- [TIA-SCL1](https://www.sitrain-learning.siemens.com/en/rw6449/Online-Training-SIMATIC-Programming-1-with-SCL-in-TIA-Portal)
- [TIA-PRO3](https://www.sitrain-learning.siemens.com/en/rw24951/Online-Training-SIMATIC-Programming-3-in-TIA-Portal)
- [TIA-SERV2 and assessed service gaps](https://www.sitrain-learning.siemens.com/en/rw48055/SIMATIC-Service-2-in-TIA-Portal)
- [TIA-SERV3](https://www.sitrain-learning.siemens.com/en/rw96384/SIMATIC-Service-3-in-TIA-Portal)

## L-OT-04 — Feedback control, dynamics and bounded tuning

Overview · Target topic stage: Advanced · 60 estimated overview study minutes · Prerequisites: L-OT-03

Interpret sampled process response, delay and interactions before changing tuning.

### Learning objectives

- Interpret sampled process response, delay and interactions before changing tuning.
- Explain saturation, anti-windup, deadband and safe fallback.
- Compare measured control performance with a declared model and acceptance limits.

Feedback control compares a measured variable with a desired value and adjusts an actuator to reduce the error. The controller does not act on the real process directly; it acts on a sampled and possibly filtered representation. Define the controlled variable, manipulated variable, disturbance and operating envelope before selecting an algorithm. For a training water loop these might be supply temperature, valve demand, heat input and permitted temperature/flow limits. The required action direction must be verified: increasing a cooling valve command should have the intended effect on the measured temperature in the selected arrangement.

Process gain describes how much the output changes for a given input change near an operating point. Time constant describes the speed of a simplified response, while transport delay describes an initial interval before a change becomes observable. A first-order approximation reaches about 63 percent of its final change after one time constant once its delay has elapsed. Real plants can be nonlinear and have several interacting lags. A useful model states its operating range, fitted data and deviations rather than claiming that one parameter set represents every load condition.

Proportional action responds to current error. Integral action accumulates error and can remove a persistent offset, but it can also continue accumulating when the actuator has reached its limit. This is integral windup. Anti-windup constrains or reconciles the integral state with achievable actuator output. Derivative action responds to change and can amplify noisy measurement signals; implementation, filtering and whether derivative acts on measurement or error affect behavior. Do not transfer numeric tuning parameters between products without checking their definitions, units and algorithm forms.

Sampling and filtering change the apparent process. A heavily filtered temperature may look smooth while concealing a rapidly rising actual condition. A controller sampling slowly relative to the important dynamics cannot recover missing information by increasing gain. A deadband avoids reacting to small changes, while hysteresis defines different switching thresholds in opposite directions. These are useful for reducing chatter in appropriate sequences, but a wide band can violate service limits. Staging, minimum run times and equipment cycling limits should be designed together with continuous control.

Commission tuning on a safe laboratory representation with approved limits and stop criteria. Begin with a known baseline, verify sensor quality and actuator direction, then apply a bounded setpoint or load disturbance. Record time-aligned setpoint, measurement, output, mode, quality and limiting flags. Evaluate overshoot, settling behavior, persistent error, actuator saturation and recovery. A smooth trend alone is not sufficient: the actuator may remain at its limit while a mild test load conceals lack of capacity. Compare disturbances at more than one operating point.

Interacting loops require clear ownership. A CDU loop and plant loop can oppose each other if both aggressively manipulate the same thermal condition using different delayed measurements. Identify which loop regulates which variable, their update times, authority limits and coordination signals. Loss of a supervisory connection must lead to the approved local behavior, not an accidental frozen output. A sensor fault should trigger a designed fallback supported by equipment constraints; the correct fallback is not universally zero output or maximum output.

The advanced assessment combines measured response with a declared model. Explain where the model underpredicts delay or ignores a physical constraint, and show how that affects the tuning decision. Retain the original and revised parameters, the reason for change and the rollback method. BAS200, Schneider HVAC teaching, selected TIA advanced functions and T-LAB-06 provide the required taught and demonstrated route. The app’s worked calculations establish reasoning; they do not replace commissioning a representative real loop or authorize tuning a live cooling plant.

### Worked example

A safe training process begins at 20 °C and settles at 24 °C after a small actuator step. It first responds after 8 s and reaches 22.52 °C at 38 s. The observed change is 4 °C; 63 percent is approximately 2.52 °C. A simple first-order-plus-delay fit therefore estimates delay 8 s and time constant 30 s. This is a local model, not a guarantee at a different flow or heat load.

### Guided practice

A loop output remains at 100 percent for five minutes, then overshoots badly when load falls. What evidence would distinguish windup from a faulty sensor?

**Hint:** Retain controller state and an independent measurement.

**Worked solution:** Inspect integral/limiting status, command versus actuator feedback and a suitable reference temperature. Check whether the integral keeps accumulating while saturated. Test an approved anti-windup configuration on the safe model or rig and compare recovery, retaining sensor-quality evidence.

#### L-OT-04-Q1 — A process responds after 8 s and reaches 63 percent of its final change at 38 s. What time constant fits the simple model?

1. About 38 s.
2. About 8 s.
3. About 30 s.

**Answer:** 3

- Option 1: Thirty-eight seconds includes the delay.
- Option 2: Eight seconds describes the observed dead time.
- Option 3: Subtract the initial delay from the elapsed time to the 63-percent point.

#### L-OT-04-Q2 — The actuator is saturated but integral action continues accumulating. What risk follows?

1. Elimination of all sensor faults.
2. Delayed recovery and overshoot when the constraint clears.
3. Guaranteed faster settling.

**Answer:** 2

- Option 1: Controller integration cannot repair physical measurement faults.
- Option 2: Windup stores a demand that the actuator could not realize.
- Option 3: More accumulated error can worsen recovery.

#### L-OT-04-Q3 — A trend is smooth after strong filtering. What remains possible?

1. Important fast process changes are being hidden.
2. The physical process has become inherently stable.
3. Sampling rate no longer matters.

**Answer:** 1

- Option 1: Filtering changes the observed signal and introduces dynamics.
- Option 2: A smoother observation does not prove physical stability.
- Option 3: Sampling still limits observable behavior.

#### L-OT-04-Q4 — Two loops manipulate the same condition with different delays. What should be reviewed?

1. Only whether both controllers use identical PID gains.
2. Whether both gains can be maximized.
3. Control ownership, interaction and coordinated timing.

**Answer:** 3

- Option 1: Identical numeric gains do not resolve different dynamics, authority or product algorithm definitions.
- Option 2: Increasing gain without a process model can destabilize operation.
- Option 3: Interacting controllers can oppose or amplify each other.

#### L-OT-04-Q5 — A sensor fails during cooling control. Which fallback is correct?

1. Always maximum output.
2. The reviewed equipment-specific fallback within protective limits.
3. Always zero output.

**Answer:** 2

- Option 1: Maximum output may also violate equipment or process limits.
- Option 2: Fallback must reflect process consequences and OEM constraints.
- Option 3: Stopping may violate the required thermal function.

#### L-OT-04-Q6 — A fitted model matches one test load. What claim is defensible?

1. It represents that tested operating region within stated error.
2. It proves all plant conditions.
3. It replaces physical commissioning.

**Answer:** 1

- Option 1: Models need bounded validation and explicit assumptions.
- Option 2: Nonlinearity and changing dynamics limit extrapolation.
- Option 3: Simulation and physical response are distinct evidence classes.

### Independent assignment

Environment: physical_lab

Commission a safe thermal or fluid loop and justify a bounded tuning improvement.

**Steps**

- Measure a baseline disturbance response.
- Fit and declare a simple local model.
- Test saturation, delay and a sensor fault.
- Apply a reviewed parameter change and compare metrics.

**Deliverables**

- Time-aligned traces and parameter sets
- Model assumptions and residuals
- Fallback, rollback and improvement report

**Acceptance Criteria**

- Control remains within agreed process/equipment limits.
- Saturation recovery and bad-sensor response are demonstrated.
- Measured improvement exceeds test uncertainty.

The laboratory model does not establish live-plant tuning authority or full D3 mechanical engineering.

### Sources

- [BAS200 — Control Sequence Fundamentals](https://courses.smartbuildingsacademy.com/products/control-sequence-fundamentals)
- [Schneider HVAC Applications & Programming](https://www.se.com/uk/en/work/services/training/ecobuildings/building-management-training/)
- [TIA-PRO3 and T-LAB-06 feedback-control teaching](https://www.sitrain-learning.siemens.com/en/rw24951/Online-Training-SIMATIC-Programming-3-in-TIA-Portal)

## L-OT-05 — Power controls, EPMS and independent protection

Overview · Target topic stage: Advanced · 60 estimated overview study minutes · Prerequisites: L-OT-01, L-OT-02, DC-12

Distinguish power measurements, equipment status, control requests and protection.

### Learning objectives

- Distinguish power measurements, equipment status, control requests and protection.
- Validate EPMS event meaning, timing and degraded-data behavior.
- Assess a simulated transfer or load-shedding sequence within explicit authority.

Power monitoring integrates electrical observations with operating decisions. Start by distinguishing four information classes: measured quantities such as current or power; status such as breaker position; alarms such as a loss of communication; and control requests such as an approved supervisory command. They are not interchangeable. A breaker auxiliary contact can indicate a mechanical position, while a voltage measurement provides different evidence about the circuit. The correct interpretation depends on the approved electrical design, selected equipment and actual sensing points.

An EPMS collects, presents and retains information from meters and intelligent electronic devices. A protective relay performs assigned protection functions under its own approved design. Some devices combine several functions, but that does not grant the supervisory application authority to change protection settings. Define the supported interface, allowed operations, roles and independent protective behavior. The near-term curriculum concerns D6 integration and D7 security with D2 interface knowledge; specialist protection design and electrical switching remain separate competencies and authorizations.

Measurement configuration needs source/version traceability. Current and voltage transformer ratios, phase association, sign convention, units, scaling and aggregation intervals can change the meaning of a displayed value. Compare configured quantities with an appropriate authorized reference and expected physical relationships. An apparent negative power flow may represent real reverse flow, a wiring/configuration issue or a sign convention. Do not “correct” the sign by editing a dashboard until the underlying interpretation is established. Live electrical measurement work requires the applicable specialist procedure.

Event order depends on time quality and timestamp origin. A device may timestamp an event at its source; a server may timestamp receipt. Network delay and collection interval can make receipt order differ from occurrence order. Record the relevant clock source, synchronization health, resolution and uncertainty. If one device clock is uncertain by two seconds, two alarms separated by half a second cannot be ordered confidently from those timestamps alone. Preserve raw events and quality indicators instead of rewriting times to fit an expected narrative.

A transfer or load-management sequence needs explicit prerequisites, permitted actions, feedback, timeout behavior and abort criteria. Use a safe simulation or authorized supervised test. Represent the independent protective layer and do not disable it to force the desired outcome. Test stale status, unavailable telemetry, loss of supervisory communication and return after interruption. A retained “source healthy” value must not silently become fresh just because the application restarted. The design should describe whether the function holds, inhibits action or delegates to an independent controller under each condition.

Capacity and restart dependencies matter during recovery. Simultaneously restarting many loads can exceed an agreed operating envelope even when their steady-state consumption fits. The controls engineer must communicate the proposed sequence and measured results to the responsible power specialist. A load-shedding request should have known priority, authority and restoration rules; it should not be a generic write permission to every device. Maintain audit records linking a request to the authorizing work, actual response and returned operating state.

For OT-05, combine PME instruction, SEL eCOM 202, industrial timing and the designated power/control laboratory teaching. The independent assignment validates measured/status/alarm correctness and a bounded transfer or load-management case. Include a negative test where stale or contradictory evidence prevents acceptance. The result is integration evidence at its stated fidelity. Passing this lesson does not demonstrate high-voltage switching competence, relay-coordination design or permission to alter live protective equipment.

### Worked example

A device event is stamped 12:00:00.500 with ±0.100 s time uncertainty; a second event is stamped 12:00:00.900 with ±0.700 s uncertainty. The possible intervals overlap: [00.400,00.600] and [00.200,01.600]. The timestamps alone cannot prove event order. Investigate source synchronization and additional sequence evidence before naming a causal first event.

### Guided practice

EPMS shows Source B healthy, but its last successful update was twenty minutes ago. A simulated transfer decision is due now. What should the test expect?

**Hint:** Use the approved freshness requirement and authority model.

**Worked solution:** Mark the status stale and follow the designed degraded-state behavior, such as inhibiting the supervisory request while independent equipment retains its specified function. Verify a current authorized source before accepting the status. Retain the failed-data test and resulting alarm.

#### L-OT-05-Q1 — EPMS is healthy but the relay interface is unavailable. What protection claim can be made?

1. A healthy dashboard proves all relay functions.
2. Protection should be bypassed until telemetry returns.
3. Only the independently verified protection design and state support a protection claim.

**Answer:** 3

- Option 1: The display does not test relay behavior.
- Option 2: Telemetry loss does not authorize defeating protection.
- Option 3: Supervisory availability and protective function are separate matters.

#### L-OT-05-Q2 — A server receipt timestamp follows another event by 0.5 s. What might reverse the apparent order?

1. A different alarm severity assigned after receipt.
2. Different collection delays or uncertain source clocks.
3. A different engineering-unit scale on a numeric point.

**Answer:** 2

- Option 1: Severity classifies the event; it does not account for source-to-server timing differences in chronological evidence.
- Option 2: Timestamp origin and path delay affect inferred chronology.
- Option 3: Scaling can change a value interpretation but does not explain the stated receipt-versus-occurrence timing difference.

#### L-OT-05-Q3 — A source-healthy status is twenty minutes old. How should it be used for a new decision?

1. As stale evidence under the approved degraded-data logic.
2. As current because its value is still true.
3. As proof that all power is lost.

**Answer:** 1

- Option 1: Freshness is part of the point meaning.
- Option 2: A retained Boolean does not establish current condition.
- Option 3: Stale data means unknown current state, not a specific physical failure.

#### L-OT-05-Q4 — A meter displays negative power unexpectedly. What is the appropriate next step?

1. Multiply the display by minus one immediately.
2. Conclude the meter is malicious.
3. Check physical context, polarity/phase configuration and sign convention under authorized procedures.

**Answer:** 3

- Option 1: A presentation edit can hide a real configuration fault.
- Option 2: Unexpected values alone do not establish malicious activity.
- Option 3: Several legitimate or erroneous causes must be distinguished.

#### L-OT-05-Q5 — All loads fit at steady state. What still matters for a restoration sequence?

1. Nothing; steady-state capacity proves every restart.
2. Transient demand and restart dependencies.
3. Only the sum of asset names.

**Answer:** 2

- Option 1: Transient and sequencing constraints remain.
- Option 2: Starting behavior can differ from normal operation.
- Option 3: Names do not quantify electrical behavior.

#### L-OT-05-Q6 — A controls learner completes the simulated load-shedding case. What evidence does it establish?

1. Bounded simulated integration evidence with declared limits.
2. Authorization to switch live electrical distribution.
3. Complete protection-engineering qualification.

**Answer:** 1

- Option 1: The environment and function tested define the claim.
- Option 2: Site authority requires separate competence and authorization.
- Option 3: A controls simulation does not cover specialist protection design.

### Independent assignment

Environment: simulation

Validate an EPMS interface and a safely represented transfer/load-management sequence.

**Steps**

- Document measurement, status, alarm and command semantics.
- Validate point values and timestamp quality.
- Inject stale status and communication loss.
- Demonstrate approved sequencing and restoration.

**Deliverables**

- Point and authority matrix
- Raw event/quality records
- Sequence and degraded-state test report

**Acceptance Criteria**

- Independent protection remains outside unauthorized supervisory control.
- Stale or contradictory evidence cannot silently pass as current.
- Recovery verifies correct point meaning and sequence.

Simulated switching is not physical switching authority; D2 protection design remains a specialist boundary.

### Sources

- [Schneider Introduction to EcoStruxure Power Monitoring Expert](https://www.se.com/uk/en/work/services/training/ecobuildings/building-management-training/)
- [SEL eCOM 202 — Introduction to IEC 61850](https://selinc.com/selu/courses/ecom/202/)
- [RUGGEDCOM advanced timing instruction](https://www.sitrain-learning.siemens.com/DE/en/rw75347/Advanced-Switching-and-Routing-in-Industrial-Networks-with-RUGGEDCOM-Face-to-face-Training)

## L-OT-06 — Cooling sequences, staging and process verification

Overview · Target topic stage: Advanced · 60 estimated overview study minutes · Prerequisites: L-OT-03, L-OT-04

Design and assess lead/lag, staging and maintenance transitions.

### Learning objectives

- Design and assess lead/lag, staging and maintenance transitions.
- Trace commands through actuator feedback to a credible thermal or hydraulic result.
- Test degraded cooling behavior while retaining OEM limits and specialist boundaries.

Cooling control coordinates several physical functions rather than merely maintaining a temperature number. In an air system, fan operation, airflow path, coil or heat-exchanger behavior and sensor placement influence the observed condition. In a liquid system, flow, pressure, temperatures, valves, pumps and the CDU or plant interface interact. Begin with the approved mechanical design and OEM operating envelope. D6 owns the controls and interface assessment here; specialist hydraulic sizing, refrigerant work and full mechanical engineering belong to the relevant D3 competency and authority.

A sequence should define equipment availability, lead selection, lag start conditions, staging delays, minimum run or off times, rotation rules and failed-start behavior. Availability is more than “not alarmed”: a unit may be isolated for maintenance or lack a valid measurement. Lead rotation can balance use, but rotating into an unavailable unit is a control defect. Transitions should account for the process response while avoiding excessive cycling. Use an explicit state model so that competing demand, maintenance and fault inputs produce predictable outcomes.

Command, feedback and process response form a chain of evidence. A valve demand of fifty percent does not prove half of design flow; valve characteristics and pressure conditions matter. A running contact does not prove that a pump produces the intended flow. Compare available position/speed feedback with pressure, flow and temperatures where the approved instrumentation supports it. Sensor plausibility rules can detect contradictions, but they must respect operating modes: a no-flow indication may be expected in an intentionally stopped branch.

Staging should use meaningful conditions and time behavior. A high temperature might indicate excess load, insufficient flow, a failed sensor, a blocked air path or an upstream plant problem. Starting every available unit without diagnosis can create a new constraint. Design escalation and fallback based on consequence and available evidence. Hysteresis and persistence timers can reduce chatter, but they must not mask a condition that requires prompt action. Test both threshold crossings and return conditions, including behavior after a short communication interruption.

Liquid-cooling interfaces need explicit ownership between plant and CDU control. Define which controller regulates a temperature, pressure or flow variable; who may request a changed setpoint; and how limits are enforced. A leak-detection input requires an approved response considering equipment design and containment arrangements. Do not invent a universal action such as stopping every pump. The control narrative must retain OEM protective functions and the responsible specialist’s decision about isolation, continued circulation or controlled shutdown.

Maintenance changes the available operating envelope. Before removing a unit, establish which loads remain supported, which shared dependencies remain and what conditions abort the work. Verify the actual installed path, not only the DCIM drawing. On return, recommission signals, actuator direction, mode selection, setpoints, alarms and lead/lag participation. A repaired pump left permanently in manual mode may appear healthy while defeating automatic redundancy. Record temporary overrides, their authority, expiry and removal verification.

Assess the sequence using a safe physical representation plus declared computational models where appropriate. Introduce a failed sensor, stuck or unavailable actuator and communications interruption, then demonstrate command/feedback/process consistency and recovery. Compare measured thermal response with the expected bounds and state the unrepresented plant dynamics. BAS200, Schneider HVAC and field-equipment teaching, Siemens application work and the curriculum’s modelling assignments provide the required learning route. An advanced app score shows decision understanding; the work package closes only with the prescribed test evidence and review.

### Worked example

In a training rig, water flow is 0.5 kg/s and measured temperature rise is 4 K. Using water heat capacity 4.18 kJ/(kg·K), the estimated heat transport is 0.5 × 4.18 × 4 = 8.36 kW. This consistency check assumes the stated fluid properties, steady conditions and representative measurements. If the load is independently known to be 16 kW, investigate flow, sensors, transient storage or another heat path rather than accepting a green pump icon.

### Guided practice

After maintenance, the lag pump has correct running feedback but never starts automatically. Identify the evidence to inspect.

**Hint:** Trace availability, mode and start transition before adjusting thresholds.

**Worked solution:** Review local/remote and manual/auto state, maintenance inhibit, permissives, lead/lag membership, start condition, output command and timestamps. Test a bounded demand transition with approved limits; verify actual flow and then restore normal rotation and records.

#### L-OT-06-Q1 — Valve demand is 50 percent. What flow can be concluded?

1. Exactly half of design flow.
2. Zero flow by definition.
3. No fixed fraction without the valve and system characteristics.

**Answer:** 3

- Option 1: Linear demand does not guarantee linear flow.
- Option 2: A midrange command does not inherently mean closed.
- Option 3: Command position and resulting hydraulic flow have a nonlinear, system-dependent relationship.

#### L-OT-06-Q2 — A repaired pump runs locally but never joins automatic lag operation. What should be checked?

1. Whether all alarm thresholds can be disabled.
2. Mode, maintenance inhibit, permissives and staging membership.
3. Only the accumulated run-hour counter.

**Answer:** 2

- Option 1: Removing alarms does not repair missing logic participation.
- Option 2: Automatic participation depends on the full sequence state.
- Option 3: Run hours may influence rotation, but do not establish automatic mode, availability and start permissives.

#### L-OT-06-Q3 — A leak detector activates. Which response belongs in the application?

1. The reviewed equipment-specific leak sequence retaining protective limits.
2. Always stop every pump in the facility.
3. Ignore the detector when IT load is high.

**Answer:** 1

- Option 1: Consequences and OEM design determine the authorized action.
- Option 2: A universal shutdown can create additional hazards or service loss.
- Option 3: Load does not justify disregarding a required protective response.

#### L-OT-06-Q4 — At 0.5 kg/s water flow and 4 K rise, what approximate heat transport follows?

1. 0.836 kW.
2. 83.6 kW.
3. 8.36 kW.

**Answer:** 3

- Option 1: This is a factor-of-ten scaling error.
- Option 2: This is a factor-of-ten scaling error.
- Option 3: Use mass flow times 4.18 kJ/(kg·K) times temperature difference.

#### L-OT-06-Q5 — Two controllers regulate the same CDU temperature aggressively. What concern arises?

1. Elimination of all thermal delay.
2. Conflicting authority and interacting loop behavior.
3. Guaranteed redundancy regardless of implementation.

**Answer:** 2

- Option 1: Physical transport and thermal inertia remain.
- Option 2: Competing loops can destabilize or frustrate each other.
- Option 3: Two controllers do not automatically provide independent resilient control.

#### L-OT-06-Q6 — A failed temperature sensor reports high. What should a staging test assess?

1. Quality/plausibility handling and the approved degraded sequence.
2. Whether every unit can be started without limits.
3. Whether the alarm can be hidden.

**Answer:** 1

- Option 1: A false high must not bypass equipment constraints or designed fallback.
- Option 2: Unbounded staging can introduce new process constraints.
- Option 3: Hiding the observation does not resolve the failed sensor.

### Independent assignment

Environment: physical_lab

Commission cooling sequence behavior on a safe represented process.

**Steps**

- Define normal, maintenance, fault and restart states.
- Exercise lead/lag and bounded staging transitions.
- Introduce sensor, actuator and communications faults.
- Restore automatic participation and verify process response.

**Deliverables**

- Sequence/state model
- Command, feedback and process traces
- Override register and recommissioning report

**Acceptance Criteria**

- OEM limits and independent protection are retained.
- Failed data produces the reviewed fallback.
- Restored equipment participates correctly in automatic operation.

A safe rig and declared models do not establish full-scale hydraulic performance or live mechanical-work authority.

### Sources

- [BAS200 — Control Sequence Fundamentals](https://courses.smartbuildingsacademy.com/products/control-sequence-fundamentals)
- [Schneider HVAC Applications & Programming and field equipment](https://www.se.com/uk/en/work/services/training/ecobuildings/building-management-training/)
- [Siemens application and advanced control teaching](https://www.sitrain-learning.siemens.com/en/rw24951/Online-Training-SIMATIC-Programming-3-in-TIA-Portal)

## L-OT-07 — Supervisory systems, alarms, historians and protected interfaces

Overview · Target topic stage: Applied · 45 estimated overview study minutes · Prerequisites: L-OT-01, DC-11, DC-13

Build an operator view from verified point identity, quality and freshness.

### Learning objectives

- Build an operator view from verified point identity, quality and freshness.
- Test alarms, roles, history and independent protective interfaces.
- Restore useful supervisory function after an application or host failure.

A supervisory application connects people to the control system. Its engineering task is to present enough trustworthy information for a correct action, while preserving the authority and autonomy of local controllers and independent protective equipment. Build the point model before drawing graphics. Each point needs a stable identity, equipment association, units, quality, expected update behavior and source. Use consistent names that remain meaningful in alarms, trends, reports and exported records. A attractive mimic can still be operationally wrong if its points refer to the wrong equipment.

Quality and freshness belong in the operator view. A last-known measurement may be useful historical context, but it must not appear indistinguishable from a current good measurement. Separate the age of the source observation, the time received and the time rendered on screen. A communications heartbeat can remain healthy while one device value is frozen. Conversely, a steady physical temperature can produce an unchanged value without being stale. Freshness design must therefore consider the selected protocol’s sampling, change-reporting and health semantics rather than relying only on whether the number changes.

An alarm is a condition requiring a defined response. Document initiating logic, priority, delay, deadband, latching, acknowledgment, reset and escalation. An acknowledged alarm may remain active; an inactive alarm may remain unacknowledged in the event record. Excessive duplicate or chattering alarms can obscure the initiating problem. Test delivery to the intended role, including communication failure and operator-session loss. Suppression or shelving should follow the site’s defined authority, reason, duration and audit requirements; it must not silently remove independent protective functions.

Historian engineering decides which observations are retained and with what meaning. Sampling, deadband, aggregation and store-and-forward behavior influence the record. A plotted line between two samples does not prove that every intermediate value was observed. Store source timestamps and quality where the selected platform supports them, and document any transformation. If a database connection fails, a local buffer may preserve data only within its capacity and supported configuration. Test a bounded interruption and reconcile the returned history rather than assuming a working live display proves historical continuity.

Roles should express operational duties. Viewing trends, acknowledging alarms, changing setpoints, editing logic and administering identities have different consequences. Test positive and negative permissions using separate representative accounts. A service account that collects data should not inherit broad configuration rights merely for convenience. Record dependencies on identity services, time, database connectivity, licenses and host storage. During an identity outage, emergency access must follow a reviewed process with bounded scope and audit, not an undocumented shared password.

Electronic security and fire-monitoring interfaces require especially clear boundaries. BMS may display an alarm or status from an independent system, but that does not transfer fire-system design, reset or life-safety authority to the BMS engineer. Test what happens when the interface or BMS fails: the independent function must behave according to its approved design. Keep the protective-system specialist involved in defining authorized test stimuli and observations. Never infer that a simulated status test proves the physical protective function.

Use Schneider EBO and PME for the selected supervisory functions and Inductive University for the retained Ignition route. Build a small operator view with verified points, a useful alarm response and a historian query. Then interrupt a host or service in the isolated lab and restore the supported backup, identities, point configuration and data path. Acceptance asks whether the operator can again make the correct decision from current information and retained history. A login page loading successfully is only one observation in that larger functional test.

### Worked example

A historian stores one sample every 10 s. Values at 12:00:00 and 12:00:10 are both 22 °C. The graph draws a flat line, but this does not exclude a two-second spike between samples. To assess a requirement that detects a three-second excursion, verify the acquisition and alarm path timing independently of the display’s trend interval. Choose storage and event capture that preserve the evidence required by the use case.

### Guided practice

After a database outage the live screen works, but the trend has a gap. What should be investigated?

**Hint:** Separate acquisition, buffering, persistence and rendering.

**Worked solution:** Inspect gateway store-and-forward status, buffer capacity, database errors, timestamp/quality mapping and recovery backlog. Compare source counts with stored records over the outage window. Verify whether data were lost, delayed or filtered before accepting historian recovery.

#### L-OT-07-Q1 — A BMS value has not changed for ten minutes. Is it necessarily stale?

1. Yes; every valid measurement must change.
2. No; an unchanged number always proves health.
3. No; inspect source freshness and protocol health semantics.

**Answer:** 3

- Option 1: Physical conditions may remain steady.
- Option 2: Unchanged values alone cannot establish data health.
- Option 3: A steady process and a frozen data path can look identical without quality evidence.

#### L-OT-07-Q2 — An alarm is acknowledged but its initiating condition remains. What state is plausible?

1. Deleted from all history.
2. Active and acknowledged.
3. Necessarily cleared and safe to restart.

**Answer:** 2

- Option 1: Alarm acknowledgment should not erase the audit record.
- Option 2: Awareness and process condition are separate state dimensions.
- Option 3: Acknowledgment does not remove the initiating cause.

#### L-OT-07-Q3 — A graph connects two ten-second samples. What does the connecting line prove?

1. Only an interpolation or rendering choice unless intermediate data exist.
2. Every intermediate physical value was measured.
3. The alarm path samples at the same rate.

**Answer:** 1

- Option 1: Rendered continuity is not evidence of continuous acquisition.
- Option 2: Unobserved intervals may contain excursions.
- Option 3: Alarm acquisition and trend storage can have different timing.

#### L-OT-07-Q4 — The data collector can edit all setpoints. What should be reviewed?

1. Whether password rotation alone removes the excess authority.
2. Whether every operator should get the same rights.
3. Whether collection requires those write privileges.

**Answer:** 3

- Option 1: Credential renewal does not remove write privileges from the assigned role.
- Option 2: Broad shared privileges increase consequence without establishing need.
- Option 3: Collection and control functions should have deliberate permissions.

#### L-OT-07-Q5 — The fire-alarm interface is disconnected during an authorized lab test. What is the key boundary?

1. The test authorizes live fire-system changes.
2. Independent protective function retains its specified behavior and authority.
3. BMS automatically becomes the replacement fire controller.

**Answer:** 2

- Option 1: A bounded interface test grants no new field authority.
- Option 2: The monitoring interface must not silently disable or assume protection.
- Option 3: A monitoring display is not automatically an approved protective system.

#### L-OT-07-Q6 — A restored Ignition gateway displays current values but history is missing. What disposition is appropriate?

1. Functional recovery remains incomplete for the historian requirement.
2. Declare full recovery because login succeeds.
3. Delete the history requirement.

**Answer:** 1

- Option 1: Required telemetry/history and application behavior must be restored together.
- Option 2: A working interface is only one component.
- Option 3: Requirements cannot be discarded to fit a failed restore.

### Independent assignment

Environment: simulation

Build and restore a useful supervisory operator view in supported software.

**Steps**

- Verify points and naming against the source list.
- Test stale data, alarm state and role permissions.
- Interrupt the historian/database path within agreed limits.
- Restore the supported application and reconcile history.

**Deliverables**

- Point/role/alarm matrix
- Data continuity and quality checks
- Functional restoration report

**Acceptance Criteria**

- Current and stale values are distinguishable.
- Alarm delivery and negative permissions pass.
- Independent protective authority remains explicit.

A software interface test does not establish physical sensor accuracy or protective-system commissioning.

### Sources

- [Schneider EBO Introduction → Operators → engineering route](https://www.se.com/uk/en/work/services/training/ecobuildings/building-management-training/)
- [Inductive University — Ignition courses](https://inductiveuniversity.com/courses/)
- [Inductive University — Using Store and Forward](https://inductiveuniversity.com/video/using-store-and-forward)

## L-OT-08 — Sunbird DCIM, CMMS and recoverable operational records

Overview · Target topic stage: Advanced · 60 estimated overview study minutes · Prerequisites: DC-16, L-OT-07

Reconcile asset and dependency records with physical evidence before a capacity decision.

### Learning objectives

- Reconcile asset and dependency records with physical evidence before a capacity decision.
- Use CMMS work history to improve an actual maintenance outcome.
- Restore DCIM/CMMS applications, records, roles and integrations as a functional service.

Operational records are engineering models of installed reality. A DCIM record may describe a server, rack position, power outlets, network ports, upstream dependencies and reserved capacity. A CMMS record may describe an asset, maintenance strategy, job plan, work order, measurements and failure history. These models support decisions only when identity, relationships and status remain trustworthy. A successful import can still create duplicate assets or connect them to the wrong parent. Engineering acceptance therefore includes reconciliation with independent installation and operating evidence.

Capacity is constrained by several dimensions. A rack with spare physical units may lack power margin, cooling support, weight allowance or suitable network connections. A displayed pair of power feeds may share an upstream dependency omitted from the model. Evaluate the actual proposed placement under normal and required maintenance/failure conditions. Distinguish measured load, nameplate values, planning assumptions and reservations. Do not add them indiscriminately or treat an unused reservation as measured consumption. Record the governing constraint and the basis of the decision.

Sunbird dcTrack and Power IQ remain the selected DCIM learning route. End-user teaching supports navigation, records, moves/adds/changes, capacity views and reporting; administrator teaching supports the agreed site setup, workflows and application lifecycle. The curriculum requires more than screenshots: confirm the provider teaches the selected measurements, freshness behavior, permissions, integrations, backups, supported restoration and troubleshooting needed for the case. Published training roles do not automatically establish every one of these programme requirements. Record the agreed product/version scope and continuing laboratory access.

For CMMS, follow the selected supported product’s work-management route. The curriculum names Maximo introduction, one Fundamentals of Work Management route, and Advanced Work Management outcomes. Assets and locations should align with how maintenance is performed and recorded. A job plan defines repeatable work; a preventive-maintenance definition creates work according to its configured strategy; a work order captures the actual execution and findings. Closing a work order records a workflow transition, not proof that the equipment meets its acceptance criteria.

Use failure codes and work history to investigate recurrence, but inspect data quality before drawing conclusions. Ten work orders may describe ten events, duplicate entries for one event or different symptoms of one unresolved cause. Compare recurrence over a defined exposure such as operating hours or cycles, not just raw monthly count when utilization changed. Pair maintenance records with engineering observations. A change to inspection frequency should follow a justified failure mechanism and measured outcome, retaining the actual equipment work and test result.

Application administration is distinct from work management. Define identities, roles, imports, integrations, configuration, health monitoring, update procedures and backups for DCIM and CMMS. A database restore may leave connectors pointing to the wrong environment or service credentials invalid. Test record consistency, attachment availability, workflow state, measurement freshness and external links after restoration. Avoid restoring a training application into live integrations without an approved cutover plan. Maintain an integration inventory so that the backup’s functional dependencies are visible.

The OT-08 assignment combines a corrected capacity or maintenance decision with application recovery. Uncover an incorrect shared dependency, verify it, obtain the appropriate correction and reconcile the records. Investigate a recurring fault, perform the authorized maintenance on represented or supervised equipment, and evaluate recurrence using comparable evidence. Then restore the application and usable records in an isolated environment. A DCIM or CMMS course certificate supports the teaching record; it does not replace practical acceptance, a provider-exam credential or production experience.

### Worked example

DCIM shows two 6 kW feeds supporting a proposed 8 kW rack. Physical reconciliation finds both feeds share one upstream 10 kW path already carrying 4 kW elsewhere. The proposed combined load would be 12 kW on that path, before applying any additional required operating margin. Hold the placement decision, confirm ratings and policy with the responsible specialist, then change the placement or infrastructure through approved work. Editing the dependency diagram alone does not increase capacity.

### Guided practice

Three pump repairs occurred in 1,000 operating hours before a change and two in 200 hours after it. Has reliability clearly improved?

**Hint:** Normalize the observation and consider the small sample.

**Worked solution:** Observed rates are 3 per 1,000 hours before and 10 per 1,000 hours after. The raw count fell but exposure also fell sharply. Investigate comparable failure definitions and operating conditions; the small sample does not establish a statistically reliable improvement. Retain actual maintenance and verification evidence.

#### L-OT-08-Q1 — A rack has free units but both feeds share a constrained upstream path. What governs placement?

1. Rack units alone.
2. The number of green DCIM icons.
3. All applicable constraints and the verified dependency model.

**Answer:** 3

- Option 1: Physical space does not create upstream electrical capacity.
- Option 2: Display status cannot replace dependency analysis.
- Option 3: Space, power, cooling and resilience constraints must all be satisfied.

#### L-OT-08-Q2 — A work order is closed. What proves the repair restored function?

1. The fact that all labor hours were entered.
2. Recorded equipment acceptance measurements and appropriate review.
3. The closed status alone.

**Answer:** 2

- Option 1: Labor reporting documents effort, not that the equipment passed its functional acceptance tests.
- Option 2: Workflow completion and engineering acceptance are distinct.
- Option 3: A status transition can occur without a successful test.

#### L-OT-08-Q3 — Repairs fall from three in 1,000 hours to two in 200 hours. What should be concluded?

1. The observed rate rose; compare conditions and acknowledge limited evidence.
2. Reliability certainly improved because two is less than three.
3. The equipment has achieved zero failures.

**Answer:** 1

- Option 1: Exposure-normalized rates are 3 versus 10 per 1,000 hours.
- Option 2: Raw counts ignore the different operating exposure.
- Option 3: Two recorded repairs contradict a zero-failure claim.

#### L-OT-08-Q4 — A restored CMMS opens but integration credentials fail. Is service restoration complete?

1. Yes; only the home page matters.
2. Yes; work history can be discarded.
3. No; required integrations and record consistency remain unverified.

**Answer:** 3

- Option 1: Login is only a narrow application-health observation.
- Option 2: Required history is part of the maintenance evidence.
- Option 3: The operational service includes its dependencies and usable records.

#### L-OT-08-Q5 — Sunbird advertises end-user and administrator training. What must still be confirmed?

1. That every programme outcome is automatically taught.
2. The agreed products, versions, lifecycle outcomes and lab access.
3. That every public visitor is certified.

**Answer:** 2

- Option 1: A broad title does not prove detailed coverage.
- Option 2: Programme requirements must be matched to the selected delivery.
- Option 3: A training listing is not a certification award.

#### L-OT-08-Q6 — A dependency error is corrected in DCIM. What physical claim follows?

1. The record changed; installed state and capacity still require verification.
2. The cables physically moved themselves.
3. The upstream rating increased.

**Answer:** 1

- Option 1: Model correction and infrastructure correction are separate actions.
- Option 2: Editing records does not move installed connections.
- Option 3: A database update cannot change equipment ratings.

### Independent assignment

Environment: simulation

Reconcile DCIM dependencies and complete a CMMS maintenance/recovery case.

**Steps**

- Find and verify a plausible incorrect asset/dependency record.
- Make an approved capacity or maintenance decision.
- Execute authorized represented or supervised maintenance and verify function.
- Restore application, records, permissions and integrations.

**Deliverables**

- Before/after dependency evidence
- Work order with actual test results
- Application recovery and reconciliation report

**Acceptance Criteria**

- Both a justified hold/rejection and acceptance after correction are recorded.
- Maintenance claims link to equipment evidence.
- Restored records and integrations support correct decisions.

Software records alone do not establish physical maintenance; real work must use the proper authority and evidence class.

### Sources

- [Sunbird End-User and System Administration Training](https://www.sunbirddcim.com/dcim-training-services)
- [Maximo Fundamentals of Work Management — MAX4350G](https://www.ibm.com/training/course/maximo-manage-fundamentals-of-work-management-MAX4350G)
- [Maximo Advanced Work Management — MAX4352G](https://www.ibm.com/training/course/maximo-manage-advanced-work-management-MAX4352G)

## L-OT-09 — Industrial point semantics, gateways and time

Overview · Target topic stage: Advanced · 60 estimated overview study minutes · Prerequisites: L-OT-07, DC-13

Diagnose protocol integration using point meaning, quality and freshness.

### Learning objectives

- Diagnose protocol integration using point meaning, quality and freshness.
- Distinguish serial, session and event-delivery failures from physical process faults.
- Validate gateway transformations and restored alarm/history across named protocol families.

A controls network is successful when the intended observation or action reaches the correct application with its meaning intact. Packet delivery is necessary but insufficient. Start with a point contract: source device, object or register, data type, units, range, quality, time semantics, expected update behavior, direction and authority. At every gateway or application transformation, record how that contract changes. A float assembled with the wrong word order can be syntactically valid yet physically impossible; a stale cached value can be perfectly formatted and still unsuitable for a current decision.

Modbus TCP and Modbus RTU share an application model but have different transport behavior. TCP integration includes server connection, transaction matching and gateway unit addressing where applicable. RTU adds serial settings, device addresses, frame timing and physical bus diagnosis. Register notation in manuals may use human-facing numbering while protocol addresses use offsets; the device map is authoritative for the selected implementation. Multi-register values require explicit signedness, scaling and word order. A CRC-valid RTU response demonstrates frame integrity at that stage, not correct register interpretation or a calibrated sensor.

BACnet/IP uses IP networking for BACnet communication; BACnet MS/TP uses a token-passing serial data link with its own addressing and timing behavior. Device identity, object/property selection and supported services matter above the transport. Discovery behavior across IP subnet boundaries needs a supported design; simply opening a unicast port may not satisfy the selected discovery arrangement. For MS/TP, examine node configuration, baud rate, wiring and token behavior using appropriate tools and procedures. A working IP gateway does not prove a healthy serial segment behind it.

OPC UA communicates typed information with status and timestamps as well as values. Inspect namespace identity, node mapping, certificate trust, session state, monitored-item configuration and the distinction between source and server timestamps. MQTT uses brokered publication and subscription; topic permissions, session behavior, retained messages, message expiry and application payload timestamps influence interpretation. Delivery quality-of-service levels describe protocol delivery behavior, not whether a reported measurement is fresh or physically correct. A retained message may be useful initial context, but it must be assessed against the application’s freshness requirement.

IEC 61850 MMS and GOOSE need separate test evidence. MMS supports the selected client/server information exchange; GOOSE is used for event-oriented messaging with its own publisher/subscriber dataset and timing expectations. Verify the configured data model, dataset membership, subscription, quality and network support with the selected IED instructions. Do not assume a successful MMS read validates a GOOSE application. SNMP and syslog add management observations: counter type, collection interval, severity mapping, transport and timestamp origin affect the conclusions drawn from them.

Time services also remain separate. NTP, PTP and IRIG-B have different interfaces, deployment requirements and performance characteristics. Precision depends on implementation, distribution, clock quality and the complete path, not the acronym. Record synchronization health and uncertainty and test loss and return of the time source. Network redundancy likewise does not guarantee data freshness: a session may need to reconnect or a gateway cache may survive a path failure. Assess the application at the required interval during failover.

OT-09 integrates these families in the controls application; CN-03 carries their explicit transport and timing register. Reuse the teaching once, but retain separate implementation and fault results for each required family. After diagnosis, verify the actual point, command outcome, alarm and historical record. A protocol simulator can represent selected behavior, while fieldbus wiring, IED timing and physical process correctness require their appropriate lab or supervised evidence. Record these limits beside every successful test.

### Worked example

A gateway polls a temperature every 2 s, publishes a value at 12:00:10, and the receiving application displays it at 12:00:11. The embedded source timestamp is 12:00:02 because polling has failed. Apparent transport age is 1 s, but observation age is 9 s. If the use case permits at most 5 s, this point fails freshness even though messages continue arriving.

### Guided practice

A Modbus value becomes plausible only after swapping two words. Can the change be accepted immediately?

**Hint:** Plausibility is a hypothesis, not a register-map substitute.

**Worked solution:** Check the selected device register map and data type, capture raw registers, compare a known test value or authorized reference, and document the approved word order. Retest multiple values, quality/fault behavior and downstream alarms/history before accepting the mapping.

#### L-OT-09-Q1 — Messages arrive every second but the source timestamp is nine seconds old; limit is five seconds. What is the result?

1. Freshness passes because packets arrive.
2. The physical sensor is certainly broken.
3. Freshness fails despite continuing transport.

**Answer:** 3

- Option 1: Receipt frequency does not prove new observations.
- Option 2: Polling, caching or mapping can also explain the stale source.
- Option 3: Age of the observation governs this specified decision.

#### L-OT-09-Q2 — A CRC-valid RTU response is received. What remains unproven?

1. That the received RTU response passed its CRC check.
2. Correct register interpretation and physical measurement accuracy.
3. That a frame was received at all.

**Answer:** 2

- Option 1: This narrow frame-integrity observation is already established by the premise.
- Option 2: Frame integrity is only one layer of evidence.
- Option 3: The valid received response already establishes that narrow observation.

#### L-OT-09-Q3 — An MMS read succeeds. What GOOSE claim follows?

1. None without separate publisher/subscriber and timing tests.
2. All GOOSE subscriptions are verified.
3. Every protective function is commissioned.

**Answer:** 1

- Option 1: MMS and GOOSE use different application behavior and tests.
- Option 2: A successful client/server read does not exercise GOOSE.
- Option 3: Protection commissioning is broader and requires authority.

#### L-OT-09-Q4 — MQTT delivers a retained value after reconnect. What should the consumer check?

1. Only whether the topic string is long.
2. Whether retained means newly measured.
3. Payload/source age, quality and the application freshness policy.

**Answer:** 3

- Option 1: Topic length does not establish measurement freshness.
- Option 2: Retained delivery is not a new physical sample.
- Option 3: Retention can replay an earlier observation.

#### L-OT-09-Q5 — A BACnet/IP gateway is reachable but MS/TP devices are intermittent. Where should diagnosis extend?

1. Nowhere; gateway ping proves all endpoints.
2. The serial segment, node settings and token/physical behavior.
3. Only the public internet DNS.

**Answer:** 2

- Option 1: IP reachability does not validate serial communication.
- Option 2: The gateway separates transport domains and can hide downstream faults.
- Option 3: Unrelated external DNS does not explain the stated segment behavior.

#### L-OT-09-Q6 — A point looks plausible after an undocumented word swap. What disposition is appropriate?

1. Verify against the device map and known values before acceptance.
2. Accept because plausibility is sufficient.
3. Change all devices to the same swap.

**Answer:** 1

- Option 1: Mapping must be justified and tested, not guessed.
- Option 2: Several incorrect interpretations can appear plausible.
- Option 3: Different devices can use different representations.

### Independent assignment

Environment: simulation

Create a point contract and integration/fault record for every CN-03 family used by the controls case.

**Steps**

- Record raw identity, type, units, quality and time.
- Introduce mapping, serial/session and freshness faults.
- Compare observed transport with application meaning.
- Restore current observations, alarms and retained history.

**Deliverables**

- Protocol/point coverage register
- Raw and decoded trace pairs
- Restoration and fidelity statement

**Acceptance Criteria**

- No protocol family is marked implemented from another family’s successful test.
- Stale values cannot masquerade as current.
- Mappings are supported by product/version evidence.

Simulation cannot prove physical serial wiring, IED protection timing or installed process correctness.

### Sources

- [Modbus application protocol specification](https://www.modbus.org/docs/Modbus_Application_Protocol_V1_1b3.pdf)
- [The BACnet Institute courses](https://thebacnetinstitute.org/)
- [OPC Foundation — DataValue](https://reference.opcfoundation.org/specs/OPC-10000-4/7.11)
- [OASIS MQTT 5.0](https://docs.oasis-open.org/mqtt/mqtt/v5.0/os/mqtt-v5.0-os.html)
- [SEL eCOM 202](https://selinc.com/selu/courses/ecom/202/)

## L-OT-10 — Commissioning, sustained operations and trusted OT recovery

Overview · Target topic stage: Advanced · 60 estimated overview study minutes · Prerequisites: L-OT-03, L-OT-07, L-OT-08, L-OT-09, DC-17

Plan a controls operating campaign with maintenance, change, diagnosis and improvement.

### Learning objectives

- Plan a controls operating campaign with maintenance, change, diagnosis and improvement.
- Restore trusted controller and supervisory function from compatible approved artifacts.
- Recommission points, sequence, alarms and authority after recovery.

Commissioning establishes that an installation satisfies its approved requirements under the tested conditions. Sustained operation asks whether that function remains correct as equipment ages, work occurs and the environment changes. Build an operating baseline that includes controller and supervisory versions, project archives, configurations, I/O and calibration records, point maps, network dependencies, roles, alarms and known limitations. Link the baseline to the requirements and acceptance tests that justified it. A backup file without this context may be technically readable but unsuitable for restoring the approved service.

Day-to-day work should use observations that reveal degrading function. Review data freshness, alarm patterns, controller diagnostics, storage and database health, clock synchronization, backup results and temporary overrides. Distinguish a collection failure from a process failure before escalating. Record enough context to support later diagnosis: mode, load, recent work, timestamps and the affected equipment. A recurring nuisance alarm is an engineering finding, not merely an annoyance to suppress. Investigate its source, consequence and operator response before changing its logic.

Maintenance includes actual work on the represented equipment and the applications that support it. Plan prerequisite conditions, authority, isolation where applicable, tools, spares, expected findings, stop criteria and acceptance checks. Preserve as-found measurements and configuration before adjustment. Following the work, verify physical response and all affected digital representations. A replaced sensor with correct local readings can still leave wrong scaling in the controller or historian. Reconcile the CMMS record only after the required equipment and application tests are complete.

A controlled change has a reason, reviewed scope, supported artifacts, implementation steps, measurable checks and a rollback decision. Define the point beyond which the proposed rollback cannot safely restore the prior state. A database schema migration, controller firmware change or altered data layout may require more than copying an old project file. Test the rollback in an isolated compatible environment when the consequence warrants it. Keep the operating team informed of changed alarms, modes and procedures through the required handover process.

Incident recovery introduces a trust question in addition to availability. Determine which artifacts, identities and hosts can be trusted, preserve evidence appropriate to the incident, and coordinate with the security and operations authorities. Reinstalling the application on an unchanged compromised host may restore its screen while retaining the cause. Verify source provenance, compatible versions, credentials, certificates, project/configuration integrity and network restrictions. Restoration order should follow functional dependencies so that required identity, time, storage and communications exist when the application needs them.

Recommission after restoration. Verify point identity, units, quality and freshness; command authority; controller modes and permissives; alarm behavior; history; and the actual process response available in the declared environment. Test a representative negative permission and a known bad-input condition. A restored configuration should not silently re-enable an expired vendor account or reintroduce a temporary override. Compare the recovered installation to the accepted baseline, documenting deliberate deviations and their approval rather than treating every difference as either harmless or malicious.

The OT-10 operating campaign combines a controlled change and rollback, an actual maintenance task, a cross-layer fault, trusted recovery and a measured improvement. Reuse Siemens service, Sunbird and CMMS teaching, the required recovery lessons and CN-06 evidence. Use an exposure or operating-condition baseline when claiming improvement. A laboratory campaign can demonstrate disciplined execution within its scope; supervised field and production evidence require the corresponding environment and authority. Portfolio acceptance is a review of linked results across the lifecycle, not an automatic consequence of passing the app’s knowledge quiz.

### Worked example

A gateway backup is from Monday; its database schema was upgraded Wednesday; the incident occurs Friday. Restoring Monday’s gateway against Friday’s database is not automatically compatible. Build a recovery set containing supported gateway version, database restore point or migration path, drivers, module versions, credentials and certificates. Verify the combination in isolation and reconcile the intended recovery-point loss before cutover.

### Guided practice

A recovered BMS shows green values, but a temporary maintenance override is still active. What should be done before acceptance?

**Hint:** Recover the intended operating state, not just the saved bytes.

**Worked solution:** Identify the override’s authority, reason and expiry; follow the approved removal or renewed authorization procedure. Verify automatic sequence, alarms, affected points and process response. Record why the recovered baseline differed and update the recovery checklist to test overrides explicitly.

#### L-OT-10-Q1 — A controller archive exists but the tool and firmware compatibility are unknown. What is the recovery status?

1. Fully recoverable because a file exists.
2. No need to retain any version information.
3. Usable restoration is not yet demonstrated.

**Answer:** 3

- Option 1: File presence is weaker than a tested restoration.
- Option 2: Version dependencies affect behavior and compatibility.
- Option 3: A recovery set must be executable on a compatible supported environment.

#### L-OT-10-Q2 — A new sensor reads correctly locally but the historian is wrong. Where should the maintenance assessment continue?

1. Nowhere; local correctness proves every downstream value.
2. Scaling, mapping, units and history configuration across the chain.
3. Only the sensor purchase invoice.

**Answer:** 2

- Option 1: Downstream configuration can remain incorrect.
- Option 2: Recommissioning follows the observation to each required consumer.
- Option 3: Procurement evidence does not diagnose data transformation.

#### L-OT-10-Q3 — A backup predates a database schema upgrade. What is necessary before combining it with current data?

1. A supported compatibility or migration plan tested in isolation.
2. Assume all schema versions are interchangeable.
3. Rename the backup to today’s date.

**Answer:** 1

- Option 1: Application and database versions form a recovery dependency.
- Option 2: Schema changes can break restoration or corrupt interpretation.
- Option 3: A filename change does not alter compatibility.

#### L-OT-10-Q4 — An application is restored on a suspected compromised host. What remains unresolved?

1. Only the dashboard theme.
2. Nothing if the page loads.
3. The trustworthiness of the underlying environment and identities.

**Answer:** 3

- Option 1: Appearance does not establish trust.
- Option 2: Service availability alone does not establish eradication.
- Option 3: Recovery must address the incident’s persistence and authority paths.

#### L-OT-10-Q5 — A restored backup re-enables an expired vendor account. What should acceptance require?

1. Share it with every operator.
2. Reconcile identities and verify the approved access state.
3. Keep it because it was in the backup.

**Answer:** 2

- Option 1: Expanding shared access worsens traceability and control.
- Option 2: Restoration must recover current authorized function, not obsolete privilege.
- Option 3: Historical configuration can conflict with current authority.

#### L-OT-10-Q6 — A change reduced alarms during a much lighter load week. What can be claimed?

1. An observation requiring comparable conditions before an improvement claim.
2. Proven improvement under every operating condition.
3. That all protective alarms are unnecessary.

**Answer:** 1

- Option 1: Load and exposure can confound the apparent result.
- Option 2: One unbalanced comparison cannot support broad performance claims.
- Option 3: Alarm reduction is not a reason to remove required protection.

### Independent assignment

Environment: physical_lab

Complete the controls domain operating campaign.

**Steps**

- Establish and operate an accepted baseline.
- Perform authorized maintenance and a reviewed change/rollback.
- Diagnose an unfamiliar cross-layer fault.
- Restore trusted controller/application artifacts and recommission.
- Measure a bounded improvement under comparable conditions.

**Deliverables**

- Operating log and maintenance results
- Change/rollback and incident recovery records
- Recommissioning and improvement evidence

**Acceptance Criteria**

- All nine lifecycle responsibilities have linked evidence.
- Recovery verifies points, sequence, alarms, history and authority.
- Claims identify simulation, physical and supervised limits.

Field cutover, protective work and production incident authority require separate supervised authorization.

### Sources

- [Siemens TIA-SERV3 and service progression](https://www.sitrain-learning.siemens.com/en/rw96384/SIMATIC-Service-3-in-TIA-Portal)
- [Inductive University — Restoring Ignition Gateway Backups](https://inductiveuniversity.com/videos/restoring-ignition-gateway-backups/8.1)
- [Sunbird administration and recovery scope](https://www.sunbirddcim.com/dcim-training-services)
- [Selected CMMS administration/recovery route](https://www.ibm.com/training/course/maximo-manage-advanced-work-management-MAX4352G)

## L-CN-01 — Controls-network requirements, reference design and supplier review

Overview · Target topic stage: Applied · 45 estimated overview study minutes · Prerequisites: L-OT-01, DC-13

Derive a controls-network basis of design from process and operational requirements.

### Learning objectives

- Derive a controls-network basis of design from process and operational requirements.
- Review supplier assumptions against point flows, failure domains and acceptance tests.
- Create reusable templates without treating unverified defaults as approved designs.

A controls-network basis of design translates facility functions into communication and operating requirements. Start with the consuming process: which measurements, commands, alarms and engineering actions are required, and what consequence follows if they are late, incorrect or unavailable? Separate control loops that must remain local from supervisory functions that can tolerate a longer interruption. Define service boundaries, normal and degraded operating modes, expected growth, supported products and who owns each interface. A topology diagram is an output of this reasoning, not its substitute.

Build a data-flow inventory. For each flow record the source and destination roles, protocol family, direction, purpose, authority, expected rate, acceptable age, loss behavior and required security controls. Include engineering workstations, backup services, time sources, identity, licensing, databases, historian replication and remote access. These supporting flows are easily omitted when the design focuses only on PLC-to-BMS traffic. An application can lose useful function while its primary device connection remains healthy because one of these dependencies failed.

Set quantitative requirements at the application level. A five-second freshness limit must account for sensing, polling or subscription behavior, gateway processing, queues, network delivery and application rendering. Do not assign all five seconds to the network and ignore the other stages. For a recovery requirement, identify the timing origin and completion condition: link restoration, session re-establishment, first valid observation and returned operator function are different milestones. Include clock uncertainty when the test depends on event order.

Map failure domains before selecting redundancy. Two paths may share a cabinet supply, cable route, switch software defect, firewall pair or management dependency. Identify required maintenance states as well as failures; a system that tolerates one failure may not tolerate the same failure while a component is deliberately removed. Supplier statements such as “redundant network” need an explicit fault model and supported configuration. Obtain evidence for the selected firmware and platform, not an unrelated product brochure.

A functional design turns the basis of design into addressing, VLAN/VRF boundaries, routing, access policy, time distribution, management, observability and protocol integration. Reusable templates should expose site-specific parameters and constraints. A template carrying an old subnet, certificate identity or permitted vendor source can create a plausible but unsafe installation. Treat template versions as controlled artifacts; review generated configurations and compare them with the approved flow inventory. Include a method for detecting drift after commissioning.

Supplier review should check submittals, firmware assumptions, interface compatibility, capacity calculations, environmental suitability, support status and test reports. Distinguish a vendor claim, a demonstrated result and an unresolved assumption. A test report that measures switch convergence with no application attached does not close a telemetry recovery requirement. Ask for the relevant raw observations and test conditions. Accept, conditionally accept where permitted, hold or reject with a reason tied to the requirement; do not reject a product simply because it differs from a familiar brand.

CN-01 reuses the controls/facility assignments and DCID, with T-LAB design review providing guided instruction. The independent work produces one reviewed design package linking requirements to data flows, configuration intent and tests. Record the actual tutor or reviewer, source versions and outstanding decisions. The same package supports later CN commissioning, cybersecurity and operating evidence. A good reference design can be reused, but each implementation still needs its own verified assumptions, site authority and acceptance results.

### Worked example

A freshness budget is 5.0 s. Worst-case source sampling is 1.0 s, gateway polling 2.0 s, application processing/rendering 0.8 s and a reserved uncertainty margin 0.4 s. The remaining network/queue allowance is 0.8 s. These are illustrative conservative allocations, not a measured guarantee; verify whether phase relationships and concurrent loading justify the model, then test end-to-end age.

### Guided practice

A supplier reports 200 ms switch failover, while the BMS takes 12 seconds to show valid data after the fault. How should the submittal be assessed?

**Hint:** Match the tested milestone to the required service.

**Worked solution:** The switch result does not establish application recovery. Inspect session retry, polling, gateway cache and quality behavior; measure time to the first valid sufficiently fresh observation and operator function. Hold the application acceptance item until its own criterion passes or an approved design change resolves it.

#### L-CN-01-Q1 — A five-second freshness requirement exists. Which budget is appropriate?

1. Give the network five seconds and ignore the other stages.
2. Measure only the ping round-trip time.
3. Allocate sensing, gateway, network, application and uncertainty contributions.

**Answer:** 3

- Option 1: Other delays would then exceed the overall allowance.
- Option 2: ICMP timing does not measure the observation pipeline.
- Option 3: End-to-end age includes all relevant stages.

#### L-CN-01-Q2 — A supplier demonstrates 200 ms link failover but data recovers in 12 s. What is established?

1. The supplier result must be fabricated.
2. A 200 ms link recovery was observed; application recovery needs its own assessment.
3. Every application requirement passed.

**Answer:** 2

- Option 1: The results can both be accurate but cover different scopes.
- Option 2: Different layers have different recovery milestones; a pass additionally requires an approved acceptance criterion.
- Option 3: Fast convergence can coexist with slow session or polling recovery.

#### L-CN-01-Q3 — Two links share a cabinet power supply. What should the basis of design include?

1. The common supply in the failure and maintenance model.
2. A claim of complete independence based on cable count.
3. No power dependencies because this is networking.

**Answer:** 1

- Option 1: Supporting infrastructure can defeat apparent path diversity.
- Option 2: Two cables do not remove a shared supply.
- Option 3: Network service depends on power and other supporting systems.

#### L-CN-01-Q4 — A reused template contains a previous site’s vendor-access subnet. What action is justified?

1. Deploy because templates are always trusted.
2. Delete the review history.
3. Hold deployment and reconcile parameters against approved flows.

**Answer:** 3

- Option 1: A familiar template can carry stale authority.
- Option 2: Review history is needed to understand and correct the defect.
- Option 3: Reusable artifacts still require context and parameter validation.

#### L-CN-01-Q5 — A product differs from the designer’s favorite brand but meets supported requirements. How should review proceed?

1. Accept without checking firmware or interfaces.
2. Assess evidence against requirements and document disposition.
3. Reject solely because the brand is unfamiliar.

**Answer:** 2

- Option 1: Compatibility and support assumptions still need verification.
- Option 2: Engineering review evaluates the specified function and evidence.
- Option 3: Preference alone is not a requirement failure.

#### L-CN-01-Q6 — The design omits identity and time services. What risk remains?

1. A primary link may stay healthy while the application loses useful function.
2. No risk because only PLC packets matter.
3. Guaranteed improvement from fewer services.

**Answer:** 1

- Option 1: Supporting dependencies can determine availability and event meaning.
- Option 2: Applications often require more than their device traffic.
- Option 3: Omitting dependencies from documentation does not remove them physically.

### Independent assignment

Environment: analytical

Create WP-CN-01 as the reviewed controls-network design package.

**Steps**

- Derive process and operator requirements.
- Build data-flow and dependency inventories.
- Review supplier submittals and firmware assumptions.
- Link design intent to measurable tests and dispositions.

**Deliverables**

- Basis of design and functional design
- Data-flow/telemetry architecture
- Submittal and assumption register

**Acceptance Criteria**

- Every required flow has purpose, authority and acceptance criteria.
- Common dependencies and degraded states are explicit.
- A reviewer records acceptance and unresolved assumptions.

Design review does not demonstrate installed performance, field cutover authority or professional experience.

### Sources

- [Existing controls/facility teaching and CN-01 design review](https://www.se.com/uk/en/work/services/training/ecobuildings/building-management-training/)
- [Industrial network engineering teaching](https://www.sitrain-learning.siemens.com/DE/en/rw7781/Switching-and-Routing-in-Industrial-Networks-with-RUGGEDCOM-Online-Training)
- [NIST SP 800-82 Rev. 3](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

## L-CN-02 — Industrial Layer 2/3 resilience and security mechanisms

Overview · Target topic stage: Advanced · 60 estimated overview study minutes · Prerequisites: L-CN-01, DC-13

Compare PRP, HSR, REP, spanning tree and gateway redundancy as distinct mechanisms.

### Learning objectives

- Compare PRP, HSR, REP, spanning tree and gateway redundancy as distinct mechanisms.
- Apply addressing, segmentation and supported link/device security to a controls design.
- Test each resilience mechanism at the application level without inferring zero loss.

Controls-network resilience is a set of mechanisms applied to a defined fault model. Begin with addressing, VLANs, routing boundaries and the required flow inventory. VLAN separation organizes Layer 2 domains; routing and policy control communication between them. A VRF can separate routing tables, but its name alone does not establish complete isolation. Verify intended paths and rejected paths, including management traffic. Industrial devices may have limited feature support, so configuration must follow the selected model and firmware rather than generic enterprise assumptions.

Spanning-tree mechanisms prevent forwarding loops in supported bridged topologies and change the active path after relevant events. RSTP and MSTP have their own roles, configuration and convergence behavior. REP is a Cisco ring/segment mechanism with designated edge roles and an intentionally blocked path under normal operation. A topology change can alter the forwarding state. It is not interchangeable with spanning tree or a universal zero-loss guarantee. Follow the matching industrial-switch guide, verify segment roles and test the selected VLAN load-balancing arrangement separately where used.

Parallel Redundancy Protocol sends duplicate frames across two independent LANs from appropriately attached nodes. The receiver accepts the useful copy and handles the duplicate according to the supported implementation. The two LANs must retain their intended separation and fault independence; casually bridging them together defeats the design assumptions. A singly attached device may require a supported redundancy box arrangement. Assess what happens when one LAN fails and when a shared supporting component fails. PRP does not make the endpoint application or its power supply redundant.

High-availability Seamless Redundancy uses a ring arrangement in which suitable nodes send traffic in both directions and handle duplicates. Its forwarding behavior and equipment roles differ from PRP’s two-LAN architecture. Supported coupling, RedBox or QuadBox arrangements need their own design and tests. Do not infer that a device supporting one protocol necessarily supports the other in the intended role. Record each mechanism as taught, practiced and independently assessed; a single generic “industrial redundancy” tick is not sufficient for CN-02.

Layer 3 gateway redundancy such as HSRP or VRRP addresses another problem: maintaining the selected default-gateway function. Routing convergence, upstream reachability and application sessions still need assessment. A gateway can remain active while its usable upstream path is impaired unless tracking and policy are correctly designed. Spine–leaf uplinks or dual routed paths are useful only within their supported failure model. Include asymmetric paths, access-control behavior and management reachability during the tested transition.

Security controls must fit the platform and operational requirement. Port security can constrain learned identities but requires handling for approved replacements. Loop-prevention protections can reduce accidental topology damage when configured for the actual edge role. MACsec protects supported Ethernet links; it requires compatible endpoints, keying and lifecycle design and does not replace application authorization. Assess its selected implementation rather than assuming every industrial switch supports it. ACLs and inter-VLAN policy should implement the approved flows and preserve essential diagnostic visibility.

Use RC-SWIROR, the assigned Cisco REP packet and RC-ASWIROR for the curriculum’s industrial mechanisms, retaining selected SCALANCE security teaching and professional networking prerequisites. Independent assessment measures actual observation freshness, command behavior and recovery during each supported fault. Record packet loss, duplicate handling, timing and application effect. An emulated topology may prove configuration reasoning but cannot establish a physical switch’s timing or vendor-specific hardware behavior. State those limits beside the result and maintain separate open teaching or equipment gaps.

### Worked example

A lab PRP endpoint sends 1,000 numbered observations over both LANs. During a bounded LAN-A failure, the consumer receives 1,000 unique observations through the surviving design, while a capture sees duplicate copies before the fault. Record unique application delivery separately from captured frame count. This test supports the stated single-LAN case only; it does not test endpoint failure, shared power loss or every traffic load.

### Guided practice

A REP ring reconverges quickly, but an application drops a session. Can it be accepted against an uninterrupted-service requirement?

**Hint:** Measure the application requirement rather than assigning a property from the protocol name.

**Worked solution:** No. Preserve the topology and session traces, determine whether loss/retry behavior can meet the approved service requirement, and revise the supported design or requirement through review. Do not describe REP as inherently lossless to dismiss the observed interruption.

#### L-CN-02-Q1 — Two PRP LANs are casually bridged together. What is the concern?

1. The design automatically gains a third independent path.
2. Every endpoint becomes redundant.
3. The intended separation and duplicate/failure assumptions are undermined.

**Answer:** 3

- Option 1: An uncontrolled bridge does not create independent resilience.
- Option 2: Endpoint and power failures remain separate.
- Option 3: PRP depends on its supported two-LAN architecture and attachment roles.

#### L-CN-02-Q2 — A switch supports PRP. What can be assumed about HSR operation?

1. HSR and PRP are identical names for one topology.
2. Nothing beyond the product’s documented supported HSR roles and configuration.
3. Every HSR role is automatically supported.

**Answer:** 2

- Option 1: PRP dual LANs and HSR ring behavior differ.
- Option 2: Different protocols and roles require explicit support.
- Option 3: Feature support cannot be inferred across mechanisms.

#### L-CN-02-Q3 — A REP transition loses one application session. What does this show?

1. The application effect must be evaluated against its own acceptance limit.
2. The trace can be ignored because REP guarantees zero loss.
3. All ring topologies are unusable.

**Answer:** 1

- Option 1: Measured service behavior governs acceptance.
- Option 2: REP is not a universal zero-loss claim.
- Option 3: One result calls for scoped diagnosis, not rejection of every topology.

#### L-CN-02-Q4 — The active default gateway has lost its upstream route. What should the design assess?

1. Only whether the virtual address still responds locally.
2. Whether gateway redundancy removes every dependency.
3. Tracking, routing and end-to-end reachability during gateway failover.

**Answer:** 3

- Option 1: Local response is weaker than required path availability.
- Option 2: Gateway redundancy has a bounded role.
- Option 3: A reachable gateway can still provide no usable upstream service.

#### L-CN-02-Q5 — MACsec is enabled on a link. What remains necessary?

1. Assuming every connected device is trustworthy.
2. Application authorization and the wider security design.
3. Removing all role checks.

**Answer:** 2

- Option 1: A protected link can carry unauthorized or incorrect application activity.
- Option 2: Link protection does not authorize application operations.
- Option 3: Authorization remains a distinct control.

#### L-CN-02-Q6 — One lab test demonstrates PRP during a LAN failure. What claim is justified?

1. That measured single-LAN case at the recorded load and configuration.
2. All endpoint and shared-power failures are covered.
3. The learner has production cutover authority.

**Answer:** 1

- Option 1: Acceptance must retain the tested fault and environment boundaries.
- Option 2: The test did not exercise those separate failure modes.
- Option 3: Laboratory evidence does not grant site authority.

### Independent assignment

Environment: emulation

Build WP-CN-02 with a separate row and fault test for each required mechanism.

**Steps**

- Document VLAN/VRF, routing and management boundaries.
- Implement supported resilience roles in the selected environments.
- Test PRP, HSR, REP, RSTP/MSTP and HSRP/VRRP separately as applicable to the assigned coverage.
- Verify allowed/rejected flows and application recovery.

**Deliverables**

- Mechanism-by-mechanism teaching/practice register
- Configurations and topology states
- Application timing and fault results

**Acceptance Criteria**

- No mechanism inherits another mechanism’s pass.
- Fault and maintenance assumptions are explicit.
- Platform support and physical timing limitations are recorded.

Emulation cannot establish unsupported vendor features or hardware timing; physical evidence remains required for those claims.

### Sources

- [RC-SWIROR — Switching and Routing with RUGGEDCOM](https://www.sitrain-learning.siemens.com/DE/en/rw7781/Switching-and-Routing-in-Industrial-Networks-with-RUGGEDCOM-Online-Training)
- [Cisco REP teaching packet and matching implementation guide](https://www.cisco.com/c/en/us/td/docs/switches/lan/industrial/software/configuration/guide/b-configuring-resilient-ethernet-protocol/m-how-to-configure-rep.html)
- [RC-ASWIROR — Advanced RUGGEDCOM](https://www.sitrain-learning.siemens.com/DE/en/rw75347/Advanced-Switching-and-Routing-in-Industrial-Networks-with-RUGGEDCOM-Face-to-face-Training)
- [NIST OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

## L-CN-03 — Industrial protocols, serial interfaces and timing diagnosis

Overview · Target topic stage: Advanced · 60 estimated overview study minutes · Prerequisites: L-CN-02, L-OT-09

Create independent transport, mapping and timing tests for every named protocol family.

### Learning objectives

- Create independent transport, mapping and timing tests for every named protocol family.
- Diagnose serial, discovery, subscription and clock faults from bounded evidence.
- Assign product-specific teaching gaps rather than declaring implementation from orientation.

CN-03 makes protocol coverage explicit. Maintain separate rows for BACnet/IP, BACnet MS/TP, Modbus TCP, Modbus RTU, OPC UA, MQTT, IEC 61850 MMS, IEC 61850 GOOSE, SNMP, syslog, NTP, PTP, IRIG-B and selected vendor interfaces. Each row records the actual product/version, taught lesson, supported configuration, test endpoint, normal observation, introduced fault and acceptance result. A demonstration of one IP protocol must not close the serial protocols or timing interfaces. Reuse OT-09 point semantics while adding transport-specific implementation evidence.

For Modbus TCP, correlate request and response behavior with connection health, selected unit identifier and the actual register map. For RTU, establish baud rate, parity, stop-bit arrangement, device addressing, framing and supported bus topology. A gateway can answer over TCP while its serial queue is overloaded or its downstream device is absent. Measure request rate and response time rather than assuming a faster poll setting improves freshness. Reads that overlap or repeatedly time out can increase load and worsen the useful update interval.

BACnet/IP testing should verify device/object identity, supported services and the configured discovery path. Broadcast-related behavior across subnets requires the supported BACnet design, not indiscriminate forwarding. MS/TP testing adds serial node settings, physical wiring and token behavior; duplicate addressing or a marginal connection can cause intermittent symptoms. Keep BACnet device identity distinct from link-layer addressing. Retain explicit instruction for MS/TP field diagnosis where the introductory courses do not establish it.

For OPC UA, test endpoint selection, certificate trust, namespace/node mapping, session/subscription recovery and value quality with source timestamps. A successful secure connection can still subscribe to the wrong node. For MQTT, verify topic filters and permissions, publication rate, retained-message interpretation, session behavior and expiry supported by the selected version. Test disconnect and reconnect with a known old message. For IEC 61850, use the selected IED model and configuration to assess MMS information exchange separately from GOOSE dataset/subscriber behavior, quality and timing. Device-specific commissioning instruction is required beyond orientation.

Management protocols need careful interpretation. An SNMP counter difference divided by the measured interval gives a rate only if the counter type, wrap/reset behavior and polling times are understood. SNMPv3 security configuration should match the approved identities and supported protection. Syslog records have facility/severity and timestamp semantics; their delivery and source authenticity depend on the selected transport and configuration. A missing log can mean no event, lost transport, filtering or failed collection. Correlate with other evidence before asserting absence.

Time distribution has three separate required interfaces. NTP synchronizes clocks over a packet network within its implementation and operating limits. PTP uses a different timing architecture with profiles, clock roles and path characteristics that must match the application. IRIG-B is a time-code interface whose physical/electrical format and device compatibility must be verified. No acronym guarantees a particular accuracy. Test reference loss, holdover behavior, return of synchronization and quality alarms; distinguish timestamp resolution from demonstrated uncertainty. Time uncertainty can invalidate event-order claims even when every device displays the same second.

The teaching route reuses BACnet Institute lessons, the assigned Modbus orientation, OPC UA/MQTT learning, SEL eCOM 202 and RUGGEDCOM timing. Add a named instructor session for missing Modbus integration, MS/TP diagnosis or MMS/GOOSE commissioning. Record access to devices, serial analyzers, captures and timing references before treating a gap as closed. The independent task diagnoses an unfamiliar fault and restores the application observation or action, including retained alarms/history. Where an interface is simulated, preserve that evidence label and keep its physical implementation requirement open.

### Worked example

A 32-bit management counter rises from 4,294,967,200 to 304 over a 2 s interval, with verified wrap and no reset. The increment is (2^32 − 4,294,967,200) + 304 = 400 units, or 200 units/s. Without checking counter width, reset/discontinuity information and actual interval, a naive subtraction would produce a large negative rate. The unit may be octets or packets; inspect the object definition.

### Guided practice

A gateway polls 30 serial devices; each successful transaction occupies approximately 100 ms before overhead. Can every device reliably update once per second?

**Hint:** Calculate the lower bound before changing retries.

**Worked solution:** One sequential pass already needs about 3 s before additional overhead or retries. A one-second per-device guarantee is unsupported by this schedule. Review grouping, rate requirements, supported parallel segments, device behavior and failure/retry budgets, then measure end-to-end freshness.

#### L-CN-03-Q1 — Thirty sequential serial transactions each take 100 ms before overhead. What is the minimum pass time?

1. About 0.3 s.
2. Exactly 1 s because polling is configured that way.
3. About 3 s before overhead and retries.

**Answer:** 3

- Option 1: This misses a factor of ten.
- Option 2: A requested interval cannot override serial service time.
- Option 3: Thirty times 0.1 seconds is three seconds.

#### L-CN-03-Q2 — A 32-bit counter wraps from 4,294,967,200 to 304 with no reset. What increment occurred?

1. 304 units only.
2. 400 units.
3. A negative increment of about four billion.

**Answer:** 2

- Option 1: The pre-wrap portion also contributes.
- Option 2: Ninety-six units reach the wrap, followed by 304 more.
- Option 3: Unsigned counter wrap must be handled using its defined width.

#### L-CN-03-Q3 — OPC UA establishes a trusted secure session but shows the wrong pump temperature. What remains possible?

1. Incorrect namespace/node or asset mapping.
2. Certificate trust guarantees point identity is correct.
3. The network must be physically disconnected.

**Answer:** 1

- Option 1: Secure transport and correct application mapping are distinct.
- Option 2: Trust does not select the intended engineering point automatically.
- Option 3: A functioning session contradicts that narrow diagnosis.

#### L-CN-03-Q4 — A PTP clock displays nanoseconds. What accuracy is established?

1. One-nanosecond accuracy across the facility.
2. Perfect time after reference loss.
3. None from display resolution alone; measure uncertainty and path behavior.

**Answer:** 3

- Option 1: Clock/profile/network behavior must be verified.
- Option 2: Holdover has limits that require assessment.
- Option 3: Resolution and synchronization accuracy differ.

#### L-CN-03-Q5 — No syslog message appears during a suspected event. What conclusion is justified?

1. The collector must be compromised.
2. Investigate event generation, filtering, transport and collection before asserting no event.
3. The event definitely did not occur.

**Answer:** 2

- Option 1: Compromise is one hypothesis requiring evidence.
- Option 2: Absence of a record has several possible causes.
- Option 3: Missing telemetry is not proof of physical absence.

#### L-CN-03-Q6 — A learner watched Modbus orientation. What closes TCP/RTU implementation coverage?

1. Named guided instruction plus independent device/gateway configuration and diagnosis.
2. The introductory video alone.
3. A successful BACnet quiz.

**Answer:** 1

- Option 1: The curriculum explicitly retains product-specific integration gaps.
- Option 2: Orientation does not establish field or gateway commissioning depth.
- Option 3: Different protocol evidence cannot substitute.

### Independent assignment

Environment: physical_lab

Complete WP-CN-03 with separate protocol and timing evidence.

**Steps**

- Build the thirteen named protocol/time interface rows plus selected vendor interfaces.
- Configure and observe normal behavior with known point values.
- Diagnose addressing, serial, mapping, subscription and time faults.
- Restore application freshness, commands and history.

**Deliverables**

- Protocol-specific teaching and access register
- Raw captures/serial/time observations
- Independent diagnosis and retest results

**Acceptance Criteria**

- Each required family has its own supported test or remains explicitly open.
- Transport success is separated from point/process correctness.
- Timing claims include uncertainty and reference-loss behavior.

A simulator can represent individual interfaces but cannot establish real serial wiring or physical time-distribution performance.

### Sources

- [The BACnet Institute — existing assigned courses](https://thebacnetinstitute.org/)
- [Modbus application protocol](https://www.modbus.org/docs/Modbus_Application_Protocol_V1_1b3.pdf)
- [Modbus serial-line specification](https://www.modbus.org/docs/Modbus_over_serial_line_V1_02.pdf)
- [SEL eCOM 202](https://selinc.com/selu/courses/ecom/202/)
- [RUGGEDCOM advanced timing](https://www.sitrain-learning.siemens.com/DE/en/rw75347/Advanced-Switching-and-Routing-in-Industrial-Networks-with-RUGGEDCOM-Face-to-face-Training)
- [SNMP user-based security model](https://www.rfc-editor.org/rfc/rfc3414)
- [The Syslog Protocol — RFC 5424](https://www.rfc-editor.org/rfc/rfc5424)

## L-CN-04 — Secure management, remote access and observability

Overview · Target topic stage: Applied · 45 estimated overview study minutes · Prerequisites: L-CN-01, DC-17

Design bounded management and vendor access with an independent recovery path.

### Learning objectives

- Design bounded management and vendor access with an independent recovery path.
- Collect trustworthy network evidence without confusing visibility with control authority.
- Test monitoring thresholds and rejected access against the operational requirement.

Management access is a powerful operational dependency. Inventory the functions needed to configure, diagnose, back up and recover switches, firewalls, controllers and supporting hosts. Separate routine observation from configuration and high-consequence actions. Assign named identities and roles appropriate to those functions. A management subnet is useful organization, but it is not a complete security design: the permitted source, destination, authentication method, command scope, logging and emergency process must all be defined.

Out-of-band access provides a recovery path outside the failed primary management route when its design and supporting dependencies allow it. A console server connected through the same failed switch and power supply may not deliver the intended independence. Trace its network, power, identity and remote-entry dependencies. Test the actual recovery task under a bounded primary-path failure. Record which failures it tolerates and which still require local access. Emergency credentials or break-glass methods need custody, audit and restoration of normal access after use.

Remote vendor access should begin with a specific approved work purpose and time window. Use the selected VPN or equivalent access design with authenticated entry, restricted destinations and appropriate session records. IPsec can protect traffic between configured peers, but a working tunnel does not establish that every route or firewall rule inside it is authorized. Test permitted and denied paths, including attempts to reach unrelated systems. Remove or expire the access when the work is complete and verify the effective state rather than only closing the ticket.

Observability combines several perspectives. An NMS can report device health and counters; packet collection can reveal protocol behavior; an OT-monitoring system may interpret asset and industrial-protocol activity; application logs show what services accepted or rejected. Packet brokers and capture points affect what traffic is visible. A SPAN or mirror session may drop packets under load or omit traffic outside its configured scope. Record location, direction, filter, time source, tool version and capture loss indicators before treating the capture as complete evidence.

Thresholds need an operational reason. A fixed alarm on any packet loss may create noise in a tolerant management service yet be too weak for a function requiring timely delivery. Relate thresholds to acceptable observation age, session recovery, device capacity and consequence. Use baselines across relevant modes rather than one quiet snapshot. Hysteresis, persistence and escalation can improve actionability, but the design must preserve detection of meaningful failures. Test both the event and the notification path to the responsible role.

Firewall and access diagnosis should use a bounded hypothesis. Compare the intended flow with routing, policy, state/session information and application logs. Avoid responding to every failed connection by allowing all traffic. A drop may be the desired enforcement of an unauthorized request. Preserve enough evidence to distinguish a policy defect, asymmetric path, identity problem, application refusal or unreachable endpoint. Commands that can affect fragile devices require the selected platform’s operating procedure; passive collection and read-only queries are preferable starting points where they can answer the question.

CN-04 reuses the assigned NGFW, SCALANCE and network-management teaching, with selected-platform OOB, VPN, monitoring and packet-collection demonstrations. The assessment does not require every vendor mentioned in the role source. It requires a supported implementation with meaningful positive and negative tests. Recover management after a primary-path fault, show that an approved remote task succeeds within scope, and show that an out-of-scope request is rejected. Link the raw evidence to the work package and retain the access revocation and post-work verification.

### Worked example

A management workflow permits a vendor from 14:00 to 15:00 to read diagnostics on one test controller. At 14:30 the approved read succeeds; a write and access to a neighboring controller are rejected. At 15:01 the same read is rejected after access expiry. These three outcomes assess purpose, scope and time. A tunnel-up screenshot alone would demonstrate none of those restrictions.

### Guided practice

A packet capture has no failed request, while the client log shows repeated timeouts. How should the evidence be interpreted?

**Hint:** First establish what the capture point could actually see.

**Worked solution:** Check capture placement, direction, filters, mirroring scope and loss indicators, then compare synchronized client, firewall and server observations. Absence at an incomplete capture point does not prove the client sent nothing. Use a bounded additional capture if needed.

#### L-CN-04-Q1 — An OOB console path shares the failed switch and power supply. What should be concluded?

1. All OOB paths are inherently independent.
2. Console access removes every power dependency.
3. Its claimed independence is not established for that fault.

**Answer:** 3

- Option 1: The label OOB does not prove the architecture.
- Option 2: Console equipment still requires supporting power and connectivity.
- Option 3: Recovery access has its own physical and service dependencies.

#### L-CN-04-Q2 — An IPsec tunnel is up. What remains to be tested?

1. Whether all networks can be advertised to the vendor.
2. Authorized routes, permitted/rejected operations and access expiry.
3. Nothing; tunnel state proves least privilege.

**Answer:** 2

- Option 1: Route scope should follow the approved task.
- Option 2: Encrypted connectivity and authorized scope are different properties.
- Option 3: A tunnel can carry excessive or incorrect access.

#### L-CN-04-Q3 — A mirror capture lacks packets seen in an endpoint log. What is a valid hypothesis?

1. Capture scope or overload omitted relevant traffic.
2. The endpoint log is certainly forged.
3. Packets cannot be lost by a capture arrangement.

**Answer:** 1

- Option 1: Visibility depends on placement, filtering and capacity.
- Option 2: Conflicting evidence needs investigation before attribution.
- Option 3: Mirroring and capture systems have practical limits.

#### L-CN-04-Q4 — A denied firewall request targets an unrelated controller. What might the denial indicate?

1. A fault requiring allow-all immediately.
2. Proof that the approved task cannot work.
3. Correct enforcement of the approved access scope.

**Answer:** 3

- Option 1: Broadening policy can destroy a correct boundary.
- Option 2: Unrelated denied traffic does not show the permitted task failed.
- Option 3: A negative test should reject out-of-scope traffic.

#### L-CN-04-Q5 — An alarm threshold was copied from a different service. What should justify it here?

1. The default threshold shipped in a monitoring template.
2. This function’s consequences, timing limits and measured baseline.
3. The fact that the number is round.

**Answer:** 2

- Option 1: A default needs evaluation against this service, consequence and measured operating conditions.
- Option 2: Thresholds should support a defined operational decision.
- Option 3: Convenient numbers are not engineering acceptance criteria.

#### L-CN-04-Q6 — The vendor ticket is closed but credentials still work. What remains necessary?

1. Revoke/expire access and verify the effective state.
2. Assume closure automatically enforced access removal.
3. Give the account a more descriptive name.

**Answer:** 1

- Option 1: Administrative workflow and technical enforcement must agree.
- Option 2: A ticket state may not change actual credentials or policy.
- Option 3: Renaming does not remove authorization.

### Independent assignment

Environment: emulation

Build and independently assess bounded management and observation workflows.

**Steps**

- Document management identities and approved flows.
- Demonstrate OOB recovery from a primary-path failure.
- Perform scoped VPN access with positive and negative tests.
- Validate monitoring thresholds, capture scope and expiry.

**Deliverables**

- Management/access matrix
- Capture provenance and event records
- OOB and revocation test report

**Acceptance Criteria**

- Read, write and administration permissions are distinguished.
- Out-of-scope and expired access are rejected.
- Visibility limitations are recorded with every capture.

Emulated recovery does not prove physical console independence or live-site remote-work authority.

### Sources

- [NIST SP 800-82 Rev. 3](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [Industrial network operation and diagnostics](https://www.sitrain-learning.siemens.com/DE/en/rw7781/Switching-and-Routing-in-Industrial-Networks-with-RUGGEDCOM-Online-Training)
- [Syslog protocol reference](https://www.rfc-editor.org/rfc/rfc5424)

## L-CN-05 — Virtualised OT services, databases and telemetry restoration

Overview · Target topic stage: Advanced · 60 estimated overview study minutes · Prerequisites: L-CN-04, L-OT-07

Diagnose host, virtual network, storage, identity and database dependencies of OT services.

### Learning objectives

- Diagnose host, virtual network, storage, identity and database dependencies of OT services.
- Use bounded relational queries to explain missing or delayed observations.
- Restore the application and usable telemetry/history rather than only the virtual machine.

Virtualisation changes where dependencies live; it does not remove them. A BMS or historian virtual machine relies on host compute, memory, storage, virtual switching, physical uplinks and often shared identity, time and backup services. Begin with a dependency diagram that connects the operator function to these components. Record which failures are isolated to one guest and which affect several guests. Two application VMs on one host or datastore may share the exact failure that the application designer expected to tolerate.

Trace a data path through the guest interface, virtual switch, uplink, network policy, remote service and return route. VLAN tagging and virtual-switch configuration must match the selected design. A guest can have a valid IP address yet be attached to the wrong port group or virtual network. Host firewall, endpoint security and identity policies can also affect service behavior. Compare a known working flow with the failed flow using approved read-only observations before changing broad host or network settings.

Storage symptoms often appear as application delays. High datastore latency, an exhausted volume, a paused database or a write queue can delay historian persistence while live acquisition continues. Separate source observation time, arrival time and commit time where available. A backlog that is draining is different from a collection path that is still failing. Check the selected platform’s buffering and retention behavior and verify whether late data preserve original timestamps. Do not treat a graph that eventually fills in as evidence that the live service met its timing requirement during the outage.

Relational queries can clarify the problem if their semantics are explicit. Join point observations to a trusted asset/point inventory using stable keys. A left join can retain required points that have no observations; an inner join can hide them. Filter for the intended time window and acceptable quality before computing freshness or completeness. Record time zone and timestamp type. Null means missing or unknown in its context, not automatically zero. Duplicate joins can inflate counts, while aggregate averages can conceal gaps and bad-quality records.

Use a least-privilege read-only database identity for diagnosis. Limit the time window and returned rows, parameterize inputs and inspect query cost on the selected platform. Do not run unbounded exploratory queries on an operational historian merely because they do not write data; expensive reads can still affect service. Retain the query text, parameters, execution time, result provenance and relevant schema version. A query is an analytical instrument whose assumptions need review just like a measurement tool.

Recovery requires an application-consistent plan. A VM snapshot is not automatically a complete backup strategy or a safe rollback across external databases and identity systems. Determine which data and configurations are inside the guest and which are external. Record supported backup methods, recovery-point objectives, version compatibility, certificates, service accounts, drivers, licenses and integration endpoints. Restore into an isolated network first when appropriate, avoiding duplicate identities or unintended writes to live controllers. Then validate the required sequence of services and a controlled cutover.

CN-05 reuses Hyper-V, server, Ignition and database teaching with Track 1 SQL/Linux foundations. The independent case diagnoses a cross-layer fault and restores current telemetry plus usable history. Acceptance includes point identity, quality, missing-data detection, permissions, timestamps and application behavior. Record which data were lost, recovered late or deliberately excluded and compare that outcome with the approved recovery requirements. Booting a guest and opening a login page are useful milestones; neither closes the required operational restoration by itself.

### Worked example

Inventory contains points P1, P2 and P3. In the last five minutes, valid observations exist for P1 and P2 only. A query beginning from observations with an inner join returns two healthy points and hides P3. Begin from required points and left-join the latest qualifying observation so P3 remains visible with a null timestamp. Treat that null as missing evidence and report it; do not replace it with “current time.”

### Guided practice

After a VM restore, current values return but source timestamps repeat and the database backlog grows. What should be tested?

**Hint:** Separate observation generation, transport, buffering and commit.

**Worked solution:** Inspect source freshness, gateway polling, store-and-forward status, database write errors/latency and the restored service identities. Compare known source events with retained records and timestamp origins. Accept only after required current data and history consistency are verified against the recovery limits.

#### L-CN-05-Q1 — Two historian VMs use one datastore. What dependency remains?

1. The VMs are fully independent because they have different names.
2. Virtualisation eliminates storage failures.
3. A shared storage failure can affect both services.

**Answer:** 3

- Option 1: Names do not create infrastructure independence.
- Option 2: Virtual services still depend on physical storage.
- Option 3: Application instances can share host/storage failure domains.

#### L-CN-05-Q2 — A query inner-joins inventory to recent observations. What can disappear?

1. All SQL permission checks.
2. Required points with no matching observations.
3. Only points with too many alarm acknowledgments.

**Answer:** 2

- Option 1: Join choice does not remove database authorization.
- Option 2: An inner join excludes unmatched rows and can hide missing telemetry.
- Option 3: The described join does not specifically identify alarm acknowledgment behavior.

#### L-CN-05-Q3 — A required point’s latest timestamp is null. What is appropriate?

1. Report missing qualifying evidence and investigate.
2. Replace it with current time to show freshness.
3. Assume the measured value is zero.

**Answer:** 1

- Option 1: Null does not establish a recent observation or a physical value.
- Option 2: Inventing a timestamp hides the failure.
- Option 3: Missing data is not a zero measurement.

#### L-CN-05-Q4 — A read-only query scans years of production history. What risk still exists?

1. No risk because the query cannot write.
2. Automatic corruption of every record.
3. Resource load and service impact from an expensive read.

**Answer:** 3

- Option 1: Query cost can affect operational service.
- Option 2: Impact must be assessed; corruption is not implied by reading.
- Option 3: Read-only permissions do not bound CPU, I/O or locking behavior.

#### L-CN-05-Q5 — A VM snapshot excludes the external historian database. What claim is valid?

1. External dependencies do not matter after boot.
2. It is not by itself a complete application recovery set.
3. It guarantees all telemetry history is backed up.

**Answer:** 2

- Option 1: Useful service depends on restored external components.
- Option 2: The application’s required data may exist outside the guest.
- Option 3: A guest snapshot cannot be assumed to capture an external database.

#### L-CN-05-Q6 — Late history fills after an outage. What timing claim follows?

1. Historical recovery may succeed while the live freshness requirement failed.
2. The live service necessarily met its timing limit throughout.
3. Late records must always be deleted.

**Answer:** 1

- Option 1: Persistence and real-time availability are separate requirements.
- Option 2: Later backfill cannot retroactively deliver a timely operational observation.
- Option 3: Retention policy and quality should govern treatment of late data.

### Independent assignment

Environment: simulation

Diagnose and restore the complete virtualised OT telemetry service.

**Steps**

- Map host, virtual network, storage, identity and database dependencies.
- Query inventory versus qualifying observations with bounded read-only access.
- Introduce a host/service/storage or identity fault.
- Restore the application and reconcile current data and history.

**Deliverables**

- Dependency map and service baseline
- Queries with parameters/provenance
- Recovery-point, freshness and data-consistency results

**Acceptance Criteria**

- Missing points remain visible in the analysis.
- No synthetic timestamp conceals absent data.
- Application recovery includes external dependencies and required history.

A virtual lab does not prove physical host resilience or production restoration authority.

### Sources

- [Inductive University and assigned server/virtualisation/database teaching](https://inductiveuniversity.com/courses/)
- [Ignition — Using Store and Forward](https://inductiveuniversity.com/video/using-store-and-forward)
- [Ignition — Restoring Gateway Backups](https://inductiveuniversity.com/videos/restoring-ignition-gateway-backups/8.1)

## L-CN-06 — Controls-network commissioning and day-two ownership

Overview · Target topic stage: Advanced · 60 estimated overview study minutes · Prerequisites: L-CN-02, L-CN-03, L-CN-04, L-CN-05, DC-16

Commission controls-network readiness through protocol, telemetry and failover tests.

### Learning objectives

- Commission controls-network readiness through protocol, telemetry and failover tests.
- Diagnose packet loss, duplicate addressing, routing, policy and time faults systematically.
- Maintain golden configurations, firmware, rollback and a functional handover.

Commissioning starts with an approved design and a known installation state. Verify inventory, device identity, firmware, physical or represented links, addressing, routing, security policy, time and management access before testing the application. Network readiness is not simply a collection of green interfaces. The expected endpoints must communicate through the intended paths, with the intended privileges, and support the required point semantics. Record deviations before testing so that an unexpected result can be tied to the actual environment rather than an obsolete diagram.

Create a test matrix from requirements. Include allowed and rejected flows, protocol compatibility, point identity and units, source quality/freshness, alarms, time behavior and recovery after selected failures. Define the stimulus, observation points, timing origin, numerical limits and abort conditions. A failover test should measure the gap in useful observations or commands as well as link and routing state. Preserve independent time uncertainty where it affects acceptance. Use authorized simulated faults or controlled lab changes; real factory witness tests, site acceptance and cutover require the assigned supervisor and site authority.

Diagnosis is a sequence of hypotheses supported or rejected by observations. Packet loss can arise from physical errors, congestion, policing, mismatched settings or collection artifacts. Latency may be in the network, a serial queue, the endpoint or application processing. A duplicate IP can produce intermittent association with the wrong device even while some pings succeed. Compare ARP/neighbor observations, device identity and packet traces against the inventory. Do not immediately reboot every device and erase the evidence that distinguishes the cause.

Routing errors and firewall drops require context. Confirm source address, destination, path and return route, then inspect the approved policy and observed session behavior. An asymmetric route can confuse stateful processing, while a correct deny rule may reject an unauthorized flow exactly as intended. Time drift can make event logs appear contradictory without any actual packet reordering. Trace source and receipt timestamps and clock health before reconstructing the fault sequence. Restore only the configuration changes justified by the diagnosis and required authority.

Day-two ownership keeps the accepted design usable. Maintain golden configurations, supported firmware records, device backups, certificate/credential lifecycle, spare compatibility and change history. A golden configuration is the approved baseline for a defined device and context, not a universal file copied everywhere. Compare drift with approved changes and investigate unexplained differences. Verify backups by restoration on a compatible environment, including secrets handled by the supported process and any dependencies outside the exported configuration.

A change plan needs prechecks, implementation, service validation, rollback triggers and post-change observation. Specify the time available to decide and execute rollback within the work window. Some changes alter state that a configuration copy cannot reverse, so define a supported recovery alternative. During handover, provide as-built records, operating limits, alarm response, known defects, recovery procedures and evidence locations. The receiving operator should demonstrate a representative diagnostic or recovery task instead of merely signing receipt of a document.

CN-06 consolidates the commissioning and sustaining responsibilities rather than postponing them until the end of study. Reuse the controller, BMS, industrial networking and recovery teaching already assigned. Independently diagnose an unfamiliar fault, perform a controlled change and rollback, restore a golden baseline and verify useful telemetry and authority. The work package should show what the learner executed, what was simulated and what a supervisor observed. Laboratory acceptance and production authorization remain separate evidence claims even when the test procedure is similar.

### Worked example

A maintenance window ends at 02:00. Rollback needs 12 minutes and final verification needs 8 minutes. If the plan requires completion by 02:00, the latest rollback decision is 01:40, before any additional contingency margin. Discovering a defect at 01:55 leaves insufficient planned time. Set an earlier decision point and stop criteria before beginning the change.

### Guided practice

A controller intermittently answers with two different MAC addresses for one IP. Which checks should precede a broad network restart?

**Hint:** Preserve identity and neighbor evidence.

**Worked solution:** Compare the approved inventory, ARP/neighbor history, switch attachment information and bounded captures to identify a duplicate address or legitimate documented redundancy behavior. Confirm actual device identity before isolating the authorized fault source; retest telemetry and update records after correction.

#### L-CN-06-Q1 — An IP address alternates between two unexpected MAC addresses. What should be investigated?

1. Only the sensor calibration range.
2. Whether all switches can be rebooted at once.
3. Duplicate addressing or another documented identity/attachment explanation.

**Answer:** 3

- Option 1: Measurement scaling does not explain competing network identities for one address.
- Option 2: A broad restart can destroy useful evidence and enlarge impact.
- Option 3: Identity evidence can explain intermittent communication with the wrong endpoint.

#### L-CN-06-Q2 — A failover test records link recovery but no telemetry age. What remains unassessed?

1. Nothing; link state covers all layers.
2. The application’s useful-data recovery requirement.
3. The link recovery milestone that was already recorded.

**Answer:** 2

- Option 1: A lower-layer milestone does not establish end-to-end function.
- Option 2: Application sessions, polling and quality can recover later than links.
- Option 3: The premise establishes that this lower-layer milestone was observed; useful application data still need assessment.

#### L-CN-06-Q3 — Rollback takes 12 min and verification 8 min; window ends 02:00. Latest decision without extra margin?

1. 01:40.
2. 01:48.
3. 01:55.

**Answer:** 1

- Option 1: Twenty minutes are required for rollback plus verification.
- Option 2: This leaves only twelve minutes and omits verification.
- Option 3: Five minutes is insufficient for the planned work.

#### L-CN-06-Q4 — A golden configuration belongs to another site. How should it be used?

1. As an automatically approved replacement.
2. Without its version history.
3. As a controlled template requiring context-specific review.

**Answer:** 3

- Option 1: A baseline is approved for a defined context.
- Option 2: History supports compatibility and authority decisions.
- Option 3: Addresses, identities, policy and hardware assumptions may differ.

#### L-CN-06-Q5 — Logs show an impossible event order and one clock is unsynchronized. What should be assessed first?

1. Whether the firewall must be disabled.
2. Timestamp origin and clock uncertainty before asserting causality.
3. Whether logs can be manually reordered to match expectations.

**Answer:** 2

- Option 1: The stated observation does not justify removing enforcement.
- Option 2: Time quality affects the interpretation of event order.
- Option 3: Rewriting evidence hides the uncertainty.

#### L-CN-06-Q6 — A learner signs a handover after receiving files. What stronger acceptance evidence is needed?

1. A representative operating or recovery task using the handover material.
2. Only a second signature from the same learner.
3. A checksum proving the handover archive was copied intact.

**Answer:** 1

- Option 1: Usable handover is demonstrated through the intended operational task.
- Option 2: Repeated signatures do not test usability.
- Option 3: Transfer integrity is useful, but it does not demonstrate that the material supports the intended operating task.

### Independent assignment

Environment: emulation

Complete WP-CN-06 commissioning and operating campaign.

**Steps**

- Establish as-built readiness and acceptance criteria.
- Test protocol, point, policy and failover behavior.
- Diagnose an unfamiliar cross-layer fault.
- Execute reviewed change, rollback and golden-baseline restoration.
- Handover through an operator demonstration.

**Deliverables**

- Commissioning test matrix and raw results
- Fault hypothesis and disposition log
- Change, backup, rollback and handover pack

**Acceptance Criteria**

- Service-level timing and quality are measured.
- Rollback decision fits the work window.
- Field authority and evidence environment are explicit.

Actual FWT/SAT, physical cutovers and live operational work require appropriate supervision and site authorization.

### Sources

- [RC-SWIROR and assigned industrial network service teaching](https://www.sitrain-learning.siemens.com/DE/en/rw7781/Switching-and-Routing-in-Industrial-Networks-with-RUGGEDCOM-Online-Training)
- [Selected industrial-switch guide](https://www.cisco.com/c/en/us/td/docs/switches/lan/industrial/software/configuration/guide/b-configuring-resilient-ethernet-protocol/m-how-to-configure-rep.html)
- [Existing recovery lessons — Items 39–45](https://inductiveuniversity.com/videos/restoring-ignition-gateway-backups/8.1)

## L-CN-07 — Network automation, Git and operational analytics

Overview · Target topic stage: Advanced · 60 estimated overview study minutes · Prerequisites: L-CN-05, L-CN-06

Apply reviewed Git/API automation to inventory, backup, validation and bounded deployment.

### Learning objectives

- Apply reviewed Git/API automation to inventory, backup, validation and bounded deployment.
- Design idempotency, failure handling and rollback around the actual device behavior.
- Produce reproducible operational analytics with explicit data provenance and limits.

Automation makes engineering decisions repeatable, including bad decisions if the inputs and authority are wrong. Begin with a narrowly defined task such as collecting inventory, checking configuration drift or validating a backup. Describe the expected inputs, permitted devices, operation, output and failure behavior. Reuse the curriculum’s Python/Bash, APIs, Git and testing foundations and Item 50 network automation teaching. CN-07 applies those skills to the existing controls-network lifecycle rather than requiring a second introductory programming course.

Use a reviewed source of intended state. An inventory should carry stable device identity, role, management endpoint, platform/version and ownership. Keep credentials in the selected secret-management mechanism, not in a Git repository or exported report. Validate types and allowed values before rendering configuration: a subnet, VLAN identifier or device role should not be accepted merely because it is a string. Reject unknown targets and ambiguous identifiers. Separate data obtained from a device from the policy that authorizes a change to that device.

Git records changes to source artifacts and supports review, but committing a file does not authorize deployment. A pull request or equivalent review should expose the reason, generated difference, affected targets, validation results and rollback approach. Pin the relevant dependencies or document supported versions so the same source can produce the same intended result. Vendor binary projects and sensitive backups may need controlled artifact storage with hashes and an index rather than ordinary text diffs. Preserve the connection between reviewed intent and executed artifact.

Idempotency means repeating an operation under the defined conditions should converge on the intended state without accumulating unintended changes. Do not assume every device API or command has that property. An API that appends an ACL entry, restarts a service or advances a work-order state may repeat side effects when retried. Distinguish safe reads, state-setting operations and action requests. Use supported transaction or request identifiers where available, and inspect the result before retrying an ambiguous timeout. A timeout can mean the response was lost after the action succeeded.

Limit the scope of execution. Begin with read-only collection, then a small approved test target and canary validation before broader work. Define prechecks, stop conditions, concurrency, rate limits, postchecks and a supported rollback or recovery path. A syntactically valid configuration may still remove management access or violate an application flow. Test negative input, partial device failure and an unexpected response. Record exactly which targets changed and which remained unknown; do not collapse a partially completed run into a single green status.

Operational analytics should preserve the meaning of its input. Normalize timestamps, units and device identity using documented rules. Retain missing, stale and bad-quality states rather than replacing them with convenient values. Calculate rates over comparable intervals and explain counter resets or changed device populations. A report claiming reduced packet loss after a change must account for load and observation coverage. Publish the query/script version, parameters, source snapshot or reference, execution time and limitations so another reviewer can reproduce the conclusion.

The assigned Ansible Network Getting Started sections support guided use after the taught automation foundations: basic concepts, network differences, first command/playbook, inventory and subsequent topics. Use one suitable supported tool rather than collecting tool names. The independent CN-07 work demonstrates inventory, backup, validation and a bounded approved deployment with rejected unsafe input, partial failure handling and rollback. Automation evidence belongs to Release 5 while reusing network, security and operating work from earlier releases. An app exercise does not itself connect to devices or grant execution authority.

### Worked example

A deployment targets three lab devices. A changes successfully, B rejects the configuration, and C times out after receiving the request. The run status is partial failure, with C unknown until verified. Do not blindly retry C if the operation is not idempotent. Read back its effective state, compare with the reviewed intent, then follow the predeclared stop/rollback decision for the group.

### Guided practice

An inventory row contains an unexpected device role and a management address outside the approved lab range. What should the automation do?

**Hint:** Validation happens before connection or rendering.

**Worked solution:** Reject the row with a clear reason, make no connection to the unapproved target, and record the failed validation. Add the case to the input contract and demonstrate that valid inventory still produces the expected bounded output. A human review must resolve the source data before any later execution.

#### L-CN-07-Q1 — A configuration file is committed to Git. What deployment authority follows?

1. Every connected device may now be changed.
2. Review is unnecessary because history exists.
3. None beyond the separately approved execution process.

**Answer:** 3

- Option 1: A repository commit does not authorize operational changes.
- Option 2: Tracked changes can still be incorrect or unauthorized.
- Option 3: Version history and permission to execute are distinct.

#### L-CN-07-Q2 — An API times out after a non-idempotent action request. What should happen before retry?

1. Assume no action occurred.
2. Verify effective state or supported request status.
3. Repeat until a success message appears.

**Answer:** 2

- Option 1: Transport timeout does not establish server-side failure.
- Option 2: The action may have succeeded while the response was lost.
- Option 3: Blind retries can repeat side effects.

#### L-CN-07-Q3 — One target succeeds, one fails and one is unknown. How should the run be reported?

1. Partial failure with per-target state and the declared next action.
2. Full success because one target changed.
3. Full rollback even if no rollback was executed.

**Answer:** 1

- Option 1: Honest state reporting supports safe recovery and review.
- Option 2: One success does not establish completion.
- Option 3: An unexecuted rollback cannot be claimed.

#### L-CN-07-Q4 — A row names an address outside the approved lab range. What is the correct behavior?

1. Connect to discover whether it is safe.
2. Silently substitute a nearby address.
3. Reject it before connecting and record the validation failure.

**Answer:** 3

- Option 1: Discovery itself can cross the approved scope.
- Option 2: Inventing a target corrupts intent and can affect the wrong device.
- Option 3: The target boundary is an input authorization constraint.

#### L-CN-07-Q5 — Packet-loss percentage fell after a change while monitoring coverage halved. What should the report state?

1. Missing devices have zero loss.
2. The coverage change limits comparison and must be investigated.
3. A proven improvement without qualification.

**Answer:** 2

- Option 1: No observation is not a zero-loss measurement.
- Option 2: Changed observation population can bias the apparent result.
- Option 3: The evidence does not support that unqualified conclusion.

#### L-CN-07-Q6 — An automation appends an ACL rule each run. Is it idempotent under repeated execution?

1. No, unless supported logic prevents unintended repeated additions.
2. Yes, because the input inventory is unchanged.
3. Yes, because all network APIs are idempotent.

**Answer:** 1

- Option 1: Repeated appends can change state beyond the intended result.
- Option 2: Identical inputs can still cause repeated side effects when the operation appends rather than converges.
- Option 3: API operations differ and must be assessed.

### Independent assignment

Environment: emulation

Create WP-CN-07 as a reviewed and reproducible automation workflow.

**Steps**

- Validate bounded inventory and collect read-only evidence.
- Create versioned backup and drift/analytics output.
- Review an intended change and execute on an approved lab canary.
- Reject malformed/out-of-scope input and handle partial failure.
- Demonstrate supported rollback and reproducible reporting.

**Deliverables**

- Git history and reviewed intent
- Execution manifest with per-target outcomes
- Negative-input, failure and rollback evidence
- Analytics query/version/provenance report

**Acceptance Criteria**

- No unapproved target is contacted.
- Ambiguous action results are verified before retry.
- Actual changed state and rollback results match the report.

Laboratory automation demonstrates bounded execution; production credentials and change authority are not provided by this app.

### Sources

- [Ansible Network Getting Started](https://docs.ansible.com/projects/ansible/latest/network/getting_started/index.html)
- [NIST OT security guidance](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

## L-CN-08 — AI agents and MCP-connected evidence-based diagnostics

Overview · Target topic stage: Advanced · 60 estimated overview study minutes · Prerequisites: L-CN-04, L-CN-05, L-CN-07

Design a read-only diagnostic assistant with bounded evidence retrieval and provenance.

### Learning objectives

- Design a read-only diagnostic assistant with bounded evidence retrieval and provenance.
- Test unsupported conclusions, untrusted inputs and access restrictions independently.
- Keep diagnosis proposals separate from reviewed execution authority.

CN-08 is a required programme outcome after telemetry, APIs and operational analytics are usable. The initial assistant retrieves approved evidence and proposes diagnoses; it does not operate the plant. Model Context Protocol can expose tools or resources through a defined interface, but the protocol name does not make the data trustworthy or the operations safe. Establish the task, permitted sources, tool schemas, identities, query limits and prohibited operations before selecting a model or connector. Record the actual instructor session under T-LAB-05 and the laboratory access arrangement.

Start with a read-only evidence service over a small sanitized laboratory dataset. Useful operations might retrieve an asset record, a bounded time range of point observations or an approved configuration version. Enforce target, time-window and row limits in the service, not only in a prompt. The service identity should lack configuration-write permission. Avoid exposing arbitrary shell execution or unrestricted SQL as a convenient diagnostic tool. Even reads need resource limits and access checks because sensitive data disclosure or expensive queries can affect the system.

Every observation should carry provenance: source identity, collection time, source timestamp where applicable, quality, query parameters, dataset or configuration version and an immutable reference or checksum when appropriate. The assistant should distinguish direct observations, derived calculations and hypotheses. A citation must resolve to the actual supporting record, not merely to a real but unrelated document. Missing evidence should produce an explicit unknown or a bounded next query. Confidence-sounding language is not a substitute for a supported causal chain.

Create a diagnostic structure that asks what happened, what evidence supports it, what alternatives remain and what observation would discriminate among them. For stale EPMS data, possible causes include source polling failure, gateway caching, network loss, database delay and clock error. A healthy switch counter does not eliminate the other causes. The assistant should retain alternative explanations until relevant evidence rules them out. Compare its output with an instructor’s known case truth and with a competent learner’s manual investigation, using the same available evidence.

Operational text is untrusted input. An asset note, log line or retrieved document may contain a sentence instructing the assistant to ignore its limits, reveal credentials or change a configuration. Treat that sentence as data to analyze, not as authority. Test such content in a harmless laboratory record and verify that the assistant neither follows it nor expands its permitted tools. Also test ordinary misleading inputs: wrong units, contradictory timestamps, stale records, a fabricated asset identifier and a missing source. Prompt-injection resistance and ordinary diagnostic accuracy are separate assessment dimensions.

Execution belongs to a separate reviewed workflow. A proposed firewall change or controller restart should state the supporting evidence, expected effect, risk, prerequisites, approval authority, validation and rollback. The diagnostic assistant remains unable to execute it in this initial assignment. Human approval inside a chat is not automatically sufficient if the site requires another authority or change process. If a future system adds actuation, that is a new design and assurance task with distinct permissions and tests, not a hidden extension of the read-only exercise.

Evaluate both usefulness and failure behavior. Count grounded correct conclusions, unsupported claims, appropriate abstentions and rejected out-of-scope requests on a disclosed case set. Retain prompts, tool calls, returned evidence and model/service versions without exposing secrets. A small laboratory score does not prove reliability under every fault, and model updates may change behavior. The required portfolio result is a bounded diagnostic workflow with demonstrated provenance, rejected unsafe input and access limits. This study app supplies the teaching and assignment; it does not claim to connect an AI agent to operational infrastructure or include external model access.

### Worked example

Known case: gateway polls stopped at 10:00, messages continue from cache, and the source timestamp remains 09:59:58. A model says “the switch is down” using only the stale-value record. That is unsupported: stale data alone does not identify the failed layer. A grounded answer states stale source evidence, lists plausible collection/cache/path causes, and requests approved gateway-poll and path observations. In a separate test, an asset note requesting a configuration write must be treated as untrusted data and the write must remain unavailable.

### Guided practice

Design four independent tests for a read-only assistant diagnosing a telemetry gap.

**Hint:** Include useful diagnosis, lack of evidence, untrusted text and an actual permission boundary.

**Worked solution:** Use a known supported fault with resolvable source citations; a case lacking enough evidence where the assistant should abstain or request a bounded query; a log containing an instruction to bypass limits that must be ignored as authority; and a direct out-of-scope/write request that the service rejects. Preserve tool logs and verify the identity lacks write rights independently of the model response.

#### L-CN-08-Q1 — A retrieved asset note says to disable a firewall. What authority does it carry?

1. The same authority as the approved change process.
2. Automatic authority because it came through MCP.
3. None; it is untrusted operational data, not an execution instruction.

**Answer:** 3

- Option 1: A data record is not an authorized operational request.
- Option 2: A protocol transports content without making it authoritative.
- Option 3: Retrieved content must not override the task and access boundaries.

#### L-CN-08-Q2 — The assistant cites a real document that does not support its conclusion. Is the conclusion grounded?

1. Yes; confident wording compensates for missing support.
2. No; the cited evidence must support the specific claim.
3. Yes; any real URL is sufficient.

**Answer:** 2

- Option 1: Style does not establish evidence.
- Option 2: Provenance includes relevance and a traceable evidential relationship.
- Option 3: A valid link can still be irrelevant.

#### L-CN-08-Q3 — A prompt says read-only, but the service credential can write configuration. What is missing?

1. Enforced least privilege at the service and tool boundary.
2. Only a longer prompt.
3. Nothing; the model will always obey.

**Answer:** 1

- Option 1: Technical permissions must support the declared boundary.
- Option 2: Prompt text alone does not remove write capability.
- Option 3: Model behavior is not a substitute for access enforcement.

#### L-CN-08-Q4 — A stale value is the only observation. Can the assistant conclude the switch failed?

1. Yes; staleness uniquely identifies a switch fault.
2. Yes; choosing one cause makes the report clearer.
3. No; multiple collection, cache, path and time explanations remain.

**Answer:** 3

- Option 1: Staleness has several possible causes.
- Option 2: Clarity cannot justify inventing a causal conclusion.
- Option 3: Diagnosis must retain alternatives until discriminating evidence exists.

#### L-CN-08-Q5 — A read-only database query is unbounded. What control remains necessary?

1. Allow all schemas to maximize usefulness.
2. Time, row, target and resource limits with authorized access.
3. No controls because it cannot modify records.

**Answer:** 2

- Option 1: Broader data access must have a justified scope.
- Option 2: Read operations can expose data or consume operational resources.
- Option 3: Read-only does not mean consequence-free.

#### L-CN-08-Q6 — The assistant proposes a useful controller restart. What should happen in this assignment?

1. Keep it a proposal for the separate authorized change/response workflow.
2. Execute through a hidden write tool.
3. Treat model confidence as site authorization.

**Answer:** 1

- Option 1: Diagnosis and execution authority are deliberately separate.
- Option 2: Adding actuation would violate the declared read-only design.
- Option 3: Confidence is not permission or a reviewed operating procedure.

### Independent assignment

Environment: simulation

Build WP-CN-08 as a read-only assistant over approved laboratory evidence.

**Steps**

- Assign and record T-LAB-05 instruction, tool/model versions and access.
- Expose bounded evidence retrieval with enforced read-only permissions.
- Evaluate known faults, missing evidence and contradictory data.
- Inject harmless untrusted instructions and request prohibited operations.
- Review supported diagnoses and separately document any proposed action.

**Deliverables**

- Tool/identity/data-flow design
- Ground-truth cases and citation/provenance records
- Model/tool transcripts and rejected-input evidence
- Evaluation and limitation report

**Acceptance Criteria**

- Every asserted fact resolves to relevant permitted evidence.
- Unsupported causality is rejected or qualified.
- Write and out-of-scope requests fail at the enforced boundary.
- No operational action is executed by the diagnostic assistant.

A small sanitized lab evaluation does not establish production AI reliability, operational authority or employer experience requirements.

### Sources

- [NIST AI Risk Management Framework](https://airc.nist.gov/airmf-resources/airmf/)
- [Model Context Protocol — Security Best Practices](https://modelcontextprotocol.io/docs/2025-11-25/tutorials/security/security_best_practices)
- [Existing API/automation foundation](https://docs.ansible.com/projects/ansible/latest/network/getting_started/index.html)
