# Engineering — overview notes

These are short introductory overviews, including overviews of advanced topics. They are introductory companion notes. The new detailed course books are in docs/academy, with their own source mappings and scope limits. Answers follow each question. Practical assignment briefs require further instruction and execution.

## DC-11 — BMS, EPMS, DCIM and the operational picture

Overview · Target topic stage: Foundation · 20 estimated overview study minutes · Prerequisites: DC-01

Distinguish monitoring, control, asset records and maintenance, then connect them to a facility decision.

### Learning objectives

- Distinguish BMS, EPMS, DCIM, historian and CMMS functions.
- Trace an operational observation to its physical source and decision.
- Explain why a healthy dashboard does not establish healthy equipment.

A data center needs a trustworthy operational picture: what equipment exists, how it is connected, what it is doing, and what action is required. Several applications contribute to that picture. Their names are useful starting points, but actual functions depend on the chosen product, integration and site design.

A **building management system (BMS)** commonly supervises mechanical plant, environmental conditions and building services. Local controllers may continue their programmed operation if the supervisory server fails. Whether they actually do so is an architectural requirement to test; the name BMS does not guarantee autonomy. A supervisory display and a controller executing a sequence have different responsibilities.

An **electrical power monitoring system (EPMS)** collects electrical measurements, equipment states, alarms and, where supported, power-quality or event records. It helps operators understand the electrical distribution system. It is not automatically the electrical protection system. A protective relay must perform its specified protective function independently of a remote dashboard where the design requires that independence.

**Data-center infrastructure management (DCIM)** connects infrastructure records with monitoring and capacity planning. It can associate a server with a rack, outlets, network connections and upstream dependencies. A capacity decision is only as trustworthy as those records and measurements. A diagram showing two feeds does not establish that the installed feeds have independent upstream paths.

A **historian** records time-series and event data for trends and investigation. A **computerised maintenance management system (CMMS)** organises assets, work orders, maintenance schedules, procedures and work history. A closed work order is a record of claimed work; acceptance requires evidence that the equipment or function was restored correctly.

Consider one temperature observation. The physical temperature influences a sensor, an input converts the signal, a controller interprets it, a communications path transfers it, and a display presents it. A historian may retain it, DCIM may associate it with a rack, and a CMMS work order may follow. Faults can enter at every step: a misplaced sensor, wrong units, stale communication, a bad asset association or an incorrect threshold.

For each important point, record its identity, units, source, update expectation, quality indication and operational meaning. For each alarm, identify the responsible responder and expected action. Acknowledging an alarm records awareness; it does not necessarily remove its cause.

During commissioning, verify the full chain against approved requirements, using safe simulated stimuli or authorised field tests. During operation, reconcile conflicting observations and inspect trend quality. During recovery, restore the application, its usable records, interfaces and permissions, then verify that the required decisions can again be made from current evidence.

### Worked example

**Example — a rack appears to have spare capacity.** DCIM records server A on power path A and server B on path B. A planned inspection finds both actually connected to the same rack PDU. The live load measurement can be accurate while the dependency model is wrong.

The correct response is to hold the proposed placement decision, reconcile the physical connection with the approved design, calculate the effect of the shared failure path, and obtain an authorised correction. Update the records after verifying the installed result. Saving an edited diagram alone does not create electrical independence.

### Guided practice

A cooling-unit alarm is visible in BMS. DCIM identifies the racks it serves, and CMMS shows a recent fan replacement. What does each system contribute, and what further evidence do you need before closing the fault?

**Hint:** Separate the observation, dependency record, work history and actual restored function.

**Worked solution:** BMS supplies the alarm and relevant trends; DCIM supplies the claimed equipment-to-rack dependencies; CMMS supplies the maintenance record. Verify point quality, controller/drive feedback, appropriate physical airflow or temperature response and affected-rack conditions. Check the work and connections against the approved design. Close only against the defined acceptance criteria, then reconcile all affected records.

#### DC-11-Q1 — Which system is primarily associated with work orders and maintenance history?

1. EPMS
2. CMMS
3. A protective relay
4. A network access switch

**Answer:** 2

- Option 1: EPMS concentrates on electrical monitoring and related events.
- Option 2: CMMS organises maintenance work and its records.
- Option 3: A protective relay detects specified electrical conditions and performs protection functions.
- Option 4: A switch forwards network traffic; it does not serve as the maintenance register.

#### DC-11-Q2 — A dashboard is green after a communications outage. What is the strongest next check?

1. Assume the plant is healthy because no alarm is shown.
2. Restart all field controllers immediately.
3. Verify point freshness and quality, then compare critical values with an independent appropriate observation.
4. Hide the outage alarm to prevent confusion.

**Answer:** 3

- Option 1: A dashboard can retain old values or lack coverage.
- Option 2: A restart may disrupt functioning control and destroys useful state without diagnosing the problem.
- Option 3: Freshness and independent observations test whether the display still represents the process.
- Option 4: Hiding an alarm changes presentation, not the underlying problem.

#### DC-11-Q3 — DCIM shows two independent power paths, but inspection finds a shared upstream component. Which statements are justified? Select all that apply.

1. The DCIM representation must be reconciled with installed reality.
2. The shared component should be evaluated as a common dependency.
3. Renaming the second feed restores independence.
4. A correct live power measurement proves the dependency map is correct.

**Answer:** 1, 2

- Option 1: Correct: engineering decisions require a model that matches the installation.
- Option 2: Correct: the shared component may defeat the intended failure tolerance.
- Option 3: Labels cannot change physical topology.
- Option 4: Measurement accuracy and dependency accuracy are distinct.

#### DC-11-Q4 — What does acknowledgement of an alarm normally establish?

1. The physical cause has been eliminated.
2. The protective system has been bypassed.
3. A responder has recorded awareness, according to the application workflow.
4. The sensor has been calibrated.

**Answer:** 3

- Option 1: Cause clearance requires separate evidence.
- Option 2: Acknowledgement is not authority to bypass protection.
- Option 3: Acknowledgement records recognition; exact workflow depends on the system.
- Option 4: Calibration requires an appropriate measurement procedure.

### Sources

- [NIST SP 800-82 Rev. 3 — Guide to Operational Technology Security (final)](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [US DOE — Best Practices Guide for Energy-Efficient Data Center Design (2024)](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DC-12 — EPMS point quality: units, scaling and freshness

Overview · Target topic stage: Applied · 20 estimated overview study minutes · Prerequisites: DC-02, DC-11

Decide whether an electrical reading is current, correctly interpreted and suitable for an operating decision.

### Learning objectives

- Distinguish source authenticity, physical accuracy and data freshness.
- Apply a declared point scaling rule without confusing watts and kilowatts.
- Define end-to-end acceptance checks for a restored EPMS point.

A number on an EPMS screen becomes operational evidence only when its meaning and quality are known. Treat a point as a small data contract: physical source, quantity, address or object, data type, units, scaling, expected update interval, quality state and permitted use. Missing contract details make a plausible number surprisingly easy to misinterpret.

**Units and scaling** turn an encoded value into an engineering quantity. Suppose a fictional meter defines a register as an unsigned integer with a scale of 0.1 kW per count. A raw value of 1,250 represents 125.0 kW. It does not represent 1,250 kW or 125 W. Some real devices instead expose a floating-point value, a separate exponent or an already-scaled reading. Register interpretation comes from the correct device and firmware documentation, not from a universal rule about the protocol.

**Freshness** asks when the underlying measurement was obtained. A web page can refresh every second while displaying a measurement that has not changed for ten minutes because communication stopped. Acquisition time, gateway receipt time, database insertion time and screen-render time are different events. If the source provides no measurement timestamp, record that limitation and use known polling behaviour, receipt age and diagnostics rather than inventing source precision.

**Quality** describes whether the value is usable. Missing, stale, out-of-range, substituted and uncertain values need explicit treatment. An unchanged value is not automatically stale: a stable load can produce repeated equal readings. Conversely, a changing timestamp does not prove a changing physical input was measured correctly.

**Accuracy and authenticity are separate.** A properly authenticated message can faithfully transmit a miscalibrated sensor or incorrect meter configuration. A plausible value can also come from the wrong circuit because its point mapping is wrong. Verify identity, meaning, calibration/configuration and the communications path as separate claims.

For diagnosis, first identify the decision at risk: capacity planning, fault investigation or an operating action. Preserve current observations and compare the display with source-side values and another appropriate reference under authorised procedures. Do not treat software visibility as permission to access live electrical equipment.

After correcting a mapping or restoring communications, verify a known point, units, scaling, quality transitions and alarm behaviour. Demonstrate that new samples arrive within the stated timing requirement and reach the historian. Test the loss-of-data indication with a safe simulated fault. Record the outage interval; a smooth line drawn across missing samples should not be presented as measured history.

This is an engineering extension to monitoring foundations. The synthetic numbers in this lesson are learning examples, not a vendor register map or a switching procedure.

### Worked example

**Example — a plausible frozen load.** A fictional meter supplies 0.1 kW per count and the last valid sample is 1,250 counts. At 14:00:30 the screen shows 125.0 kW, but its last successful poll was at 13:59:50. The lesson requirement is a maximum receipt age of 15 seconds.

The scaling is correct; the receipt age is 40 seconds and fails the stated requirement. This proves the displayed value is too old for that use, not that the actual load is 125.0 kW now or that it has changed. Investigate the collection path, use the approved alternative observation, and verify new valid polls after correction.

### Guided practice

A fictional register specifies 10 W per count and returns 8,400. The screen displays 84 kW with a recent browser refresh, but the last valid poll was 90 seconds ago. The maximum permitted sample receipt age is 20 seconds. What is right, what is wrong, and what would you verify after repair?

**Hint:** Calculate the physical quantity separately from the age check.

**Worked solution:** 8,400 × 10 W = 84,000 W = 84 kW, so the scaling is right. The 90-second age exceeds the 20-second requirement, so current loading is unknown from this reading. After repair verify the correct source and point, units, new valid samples within 20 seconds, explicit stale-quality behaviour on simulated loss, and arrival of the corrected values in the historian.

#### DC-12-Q1 — A fictional meter defines 0.01 kW per count. A raw value is 12,500. What should be displayed?

1. 12.5 kW
2. 125 kW
3. 1,250 kW
4. 125 W

**Answer:** 2

- Option 1: This would apply a 0.001 kW/count scale.
- Option 2: 12,500 × 0.01 kW = 125 kW.
- Option 3: This is ten times the specified value.
- Option 4: The scale is in kW, so converting the answer to W gives 125,000 W.

#### DC-12-Q2 — A page refreshes at 10:05, but its last successful point poll was 10:01. What does page refresh alone establish?

1. The physical measurement was taken at 10:05.
2. The meter is calibrated.
3. The browser has refreshed its presentation.
4. The last value remains valid for all decisions.

**Answer:** 3

- Option 1: Page refresh time is not acquisition time.
- Option 2: Calibration cannot be inferred from a refresh.
- Option 3: Only presentation refresh is established; source freshness needs separate evidence.
- Option 4: Usability depends on the specific age and quality requirements.

#### DC-12-Q3 — A measurement arrives over an authenticated channel. Which defects can still make its engineering interpretation wrong? Select all that apply.

1. Incorrect current-transformer ratio configured in the meter.
2. A dashboard point mapped to the wrong circuit.
3. A sensor with a calibration error.
4. The fact that the channel is authenticated, by itself.

**Answer:** 1, 2, 3

- Option 1: Authentication does not correct the meter configuration.
- Option 2: Authentication does not correct an asset/point association.
- Option 3: Authentication does not remove a physical measurement error.
- Option 4: Authentication is useful evidence about a source/channel; it is not itself a defect.

#### DC-12-Q4 — After restoring polling, which result best supports acceptance?

1. The service process is running.
2. One plausible value appears once.
3. Ping succeeds to the meter.
4. Correctly mapped and scaled fresh samples, tested quality transitions, expected alarms and historian delivery meet the declared requirements.

**Answer:** 4

- Option 1: A process can run while reading nothing useful.
- Option 2: One plausible value does not verify timing, mapping or fault handling.
- Option 3: Ping does not verify application polling or meaning.
- Option 4: This checks the end-to-end function and the failure indications needed by operators.

### Sources

- [NIST SP 800-82 Rev. 3 — Guide to Operational Technology Security (final)](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [Modbus Organization — Introduction to Modbus](https://www.modbus.org/introduction-to-modbus)
- [US DOE — Best Practices Guide for Energy-Efficient Data Center Design (2024)](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DC-13 — Reachability is not application delivery

Overview · Target topic stage: Applied · 20 estimated overview study minutes · Prerequisites: DC-08

Follow a monitoring transaction from network path to valid application data, and choose tests that narrow the fault.

### Learning objectives

- State exactly what a successful ping does and does not prove.
- Separate transport, application, data and process evidence.
- Choose a bounded next test from a fault observation.

An operator reports: “The meter pings, so the network is fine.” A successful ping is useful evidence, but the conclusion is too broad. It establishes that an ICMP echo exchange succeeded between the tested endpoints at that time. It does not establish that the intended application connection, request, response, interpretation or physical action succeeded.

Work through the chain of evidence. **Physical and link state** concern interfaces, cabling, optics, negotiated operation and errors. **Network reachability** concerns addresses, routes and applicable policy. **Transport** concerns the intended TCP or UDP service and its behaviour. **Application delivery** concerns an actual protocol transaction to the correct destination. **Semantic correctness** concerns whether the returned object or register means what the application thinks it means. **Process correctness** concerns whether the observation or commanded result matches the physical system.

Imagine an EPMS poller talking to a meter through a firewall. The firewall may allow ICMP while rejecting the application flow. A TCP connection may succeed although the application rejects the requested register. A gateway may answer the network request while its downstream serial device is unavailable. A valid response may contain the wrong point because the poller used the wrong unit identifier or address. Even a correctly interpreted measurement needs freshness and physical plausibility checks.

Choose tests to discriminate among these possibilities. Reproduce the symptom from the actual poller or a permitted equivalent source, because a laptop on another subnet may take a different path and encounter different rules. Check the expected destination, port, protocol and timing against the approved design. Inspect application logs and existing firewall counters. Where authorised, a packet capture can show requests, responses, resets, retries or application errors; it does not by itself validate a physical measurement.

Avoid changing several layers at once. A broad temporary allow rule may conceal the fault and expand access. A device restart may erase useful state. Record one hypothesis, the least disruptive observation that could disprove it, and the resulting conclusion. Use bounded testing appropriate to the device and environment; this lesson does not require scanning a live OT network.

After correction, accept the service against its actual requirement: the expected source obtains the expected point with correct meaning and timing, interruptions are indicated correctly, and unwanted paths remain blocked. For a control command, additionally verify authorised command acceptance, relevant feedback and the intended physical outcome. “Connection established” and “job completed correctly” are different claims.

These are transferable engineering habits. They support later networking and industrial-security study without assuming that a foundational troubleshooting exercise demonstrates production ownership.

### Worked example

**Example — ICMP works after a firewall change.** An EPMS server can ping a meter, but its approved TCP polling connection times out. The meter's local display still changes with the known lab load. The firewall logs show the server-to-meter application flow denied after the change.

This evidence supports a policy mismatch on the polling path. Correct or roll back the specific authorised rule through the change procedure. Verify the intended transaction, sample freshness and historian delivery, then verify that an unapproved source still cannot reach the service. The local display and ping were valuable clues, but neither proved EPMS delivery.

### Guided practice

A TCP connection to a lab gateway succeeds. The gateway returns an application exception for the requested register. A colleague proposes replacing the cable. What should you investigate first, and what remains unproven?

**Hint:** Use the response already received to identify which layers have supplied evidence.

**Worked solution:** Investigate the exact application exception, requested device/unit, function and register mapping against the documented configuration. A returned application response is evidence that this transaction reached an application endpoint; it does not prove every cable condition is perfect. The requested data, its meaning and freshness remain unproven. Check downstream-device access if the exception points there rather than replacing unrelated hardware first.

#### DC-13-Q1 — What does a successful ping most directly demonstrate?

1. An ICMP echo exchange succeeded along the tested path at that time.
2. Every application port is permitted.
3. The current meter reading is accurate.
4. The control sequence has completed.

**Answer:** 1

- Option 1: This is the bounded claim supported by echo request/reply evidence.
- Option 2: Application flows can have different policies and endpoint behaviour.
- Option 3: ICMP does not test a physical quantity.
- Option 4: A process sequence requires application and physical evidence.

#### DC-13-Q2 — A gateway returns a documented “illegal data address” application exception. Which is the best first investigation?

1. Replace every switch in the path.
2. Check the requested register/object against the device map and selected endpoint.
3. Disable all firewall rules.
4. Declare the physical measurement correct.

**Answer:** 2

- Option 1: The application response offers a more specific lead than replacing all network equipment.
- Option 2: The error points toward request semantics or device mapping.
- Option 3: A received application response does not justify removing access controls.
- Option 4: No valid requested measurement has been demonstrated.

#### DC-13-Q3 — Which checks support acceptance of a restored monitoring flow? Select all that apply.

1. Expected application responses arrive from the required source path.
2. Correctly interpreted values meet the freshness requirement.
3. Unapproved source paths remain blocked where required.
4. The display colour alone matches the design mock-up.

**Answer:** 1, 2, 3

- Option 1: This tests the intended application path.
- Option 2: This tests whether the data is useful for its intended purpose.
- Option 3: Restoration must preserve the required security boundary.
- Option 4: Colour is presentation evidence, not delivery or security evidence.

#### DC-13-Q4 — A maintenance laptop can query a meter, while the EPMS server cannot. What is a defensible next step?

1. Conclude that the EPMS server hardware is broken.
2. Assume both use identical network policy.
3. Compare source-specific route, firewall policy and application configuration using the actual poller path.
4. Continuously restart the meter until both work.

**Answer:** 3

- Option 1: Several source-specific causes remain possible.
- Option 2: Different sources can encounter different routes and rules.
- Option 3: This tests differences relevant to the observed asymmetry.
- Option 4: Repeated restarts are disruptive and do not isolate the differing path.

### Sources

- [IETF RFC 792 — Internet Control Message Protocol](https://www.rfc-editor.org/rfc/rfc792.html)
- [Modbus Organization — Introduction to Modbus](https://www.modbus.org/introduction-to-modbus)
- [NIST SP 800-82 Rev. 3 — Guide to Operational Technology Security (final)](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

## DC-14 — Hardware management, BMCs and recovery paths

Overview · Target topic stage: Foundation · 20 estimated overview study minutes · Prerequisites: DC-07, DC-08

Understand the server management plane, its power and network dependencies, and the evidence needed after firmware maintenance.

### Learning objectives

- Distinguish a host operating system from its BMC management plane.
- Identify common dependencies that can defeat out-of-band recovery.
- Define a model-specific firmware-change and return-to-service check.

A server contains several cooperating computing systems. The host processor and operating system run workloads. A **baseboard management controller (BMC)** provides supported management functions such as hardware health information, event logs, remote console, power control or firmware services. Exact capabilities depend on hardware, firmware, licensing and configuration; do not assume that every product implements every feature.

Because a BMC can function independently of the host operating system, it may remain useful when the host crashes or cannot boot. That independence has limits. The BMC still needs suitable power and a working management path. Host “power off” does not necessarily remove standby power from the BMC. Conversely, a total loss of its required power cannot be fixed simply by attempting another remote login.

**Out-of-band (OOB) management** provides management access outside the host's ordinary workload path. Some servers have a dedicated management port; others can share a network interface. A dedicated port alone does not prove an independent recovery system. Trace the management switches, power feeds, routing, access gateway, credentials, directory services and any remote-access dependencies. Two paths can still fail together if both need the same unavailable switch or identity service.

The management plane holds significant authority. Someone able to control power, attach virtual media or change firmware can affect service even without logging into the host operating system. Restrict access to approved administration paths, use appropriate identities and supported protections, and retain useful logs. Redfish is a DMTF management standard; availability of a standard does not establish a specific server's implementation, security settings or correctness.

Firmware maintenance starts with identification: exact model, installed versions, approved target release, compatibility and known dependencies. Determine whether the action needs a reboot, affects management availability, changes configuration or prevents downgrade. Obtain the approved image through the established vendor process and verify applicable authenticity/integrity evidence. A copied configuration file is not automatically a complete recovery plan.

Before work, confirm workload arrangements, redundancy state, authority, maintenance window and a feasible failure response. After work, verify more than a version string: host boot, hardware health, expected devices, management access, required configuration, telemetry and the service that depends on the server. A firmware update can complete while leaving a boot-order or interface problem.

In hardware engineering, a sound result is a justified accept, hold or reject decision based on the model's requirements and test evidence. Use OEM maintenance procedures and the required supervision for physical work. A component that looks removable is not thereby safe or supported to replace while powered.

### Worked example

**Example — an unreachable host with a reachable BMC.** The host stops responding to its production address, but the approved BMC console shows a boot-device error. This narrows the fault toward host boot/storage or its configuration; it does not prove that the entire production network is healthy.

Preserve BMC events and console evidence, check the approved recovery procedure, and investigate the boot dependency. After an authorised correction, verify boot, storage health, management controls and the actual workload service. Do not close the incident merely because the console now shows a login prompt.

### Guided practice

A design labels two management switches “redundant,” but both are powered by the same rack PDU and require one directory server for administrator login. Identify two common dependencies and propose acceptance checks.

**Hint:** Recovery access depends on power and authority as well as connectivity.

**Worked solution:** The shared rack PDU is a power dependency; the sole directory service is an authentication dependency. In an authorised lab or planned test, demonstrate the declared management-access behaviour when a management path or authentication dependency is unavailable. Validate an approved emergency-access mechanism, its logging and later credential handling. Review how the shared power failure is treated in the required design.

#### DC-14-Q1 — A host operating system has crashed. Which statement is most accurate?

1. Its BMC must also have stopped.
2. Its BMC may remain available if its own power and management dependencies are working.
3. Its BMC guarantees the workload is still running.
4. A BMC requires the host desktop to be logged in.

**Answer:** 2

- Option 1: The BMC is a separate management subsystem.
- Option 2: This captures its potential independence and its remaining dependencies.
- Option 3: Management availability is not workload availability.
- Option 4: BMC management does not generally depend on a logged-in host desktop.

#### DC-14-Q2 — Which findings weaken a claim of independent recovery access? Select all that apply.

1. Both management switches share one required power source.
2. Both access paths depend on the failed production router.
3. Emergency credentials are only retrievable from the failed service.
4. The management port has a different label from the production port.

**Answer:** 1, 2, 3

- Option 1: One power failure can remove both switches.
- Option 2: The same routing failure can remove both access paths.
- Option 3: An unavailable credential dependency can prevent recovery access.
- Option 4: A label establishes neither independence nor a shared technical dependency.

#### DC-14-Q3 — After an approved firmware update, which evidence is strongest for return to service?

1. The progress bar reached 100%.
2. The firmware filename contains the word stable.
3. The version, configuration, boot, hardware health, management access and required dependent service pass the agreed checks.
4. The operator remembers performing this on another model.

**Answer:** 3

- Option 1: The update mechanism completing is only one part of acceptance.
- Option 2: A filename is not provenance, compatibility or functional evidence.
- Option 3: These checks cover the changed platform and its required function.
- Option 4: Different models can have different procedures and constraints.

#### DC-14-Q4 — A fan module has a handle and can be reached without tools. What establishes whether it may be replaced while the equipment is running?

1. Its appearance.
2. An online video of a different server.
3. The number of spare fans in the storeroom.
4. The exact OEM procedure, installed configuration, operating state and authorised maintenance conditions.

**Answer:** 4

- Option 1: Appearance does not establish safe removal.
- Option 2: A different model is insufficient evidence for this equipment.
- Option 3: Spare inventory does not establish hot-swap support.
- Option 4: The model-specific procedure and current conditions determine the permitted method.

### Sources

- [DMTF — Redfish standard and management resources](https://www.dmtf.org/standards/redfish)
- [NIST SP 800-193 — Platform Firmware Resiliency Guidelines](https://csrc.nist.gov/pubs/sp/800/193/final)
- [NIST SP 800-82 Rev. 3 — Guide to Operational Technology Security (final)](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

## DC-15 — Sensors, actuators and control authority

Overview · Target topic stage: Foundation · 20 estimated overview study minutes · Prerequisites: DC-05, DC-11

Trace a control loop from physical measurement to outcome and distinguish supervisory requests from local control and protection.

### Learning objectives

- Identify the process, sensor, controller, actuator and feedback in a cooling loop.
- Distinguish command, equipment feedback and process effect.
- Explain why failure responses and protective boundaries must be specified.

A control system changes a physical process to keep it within required conditions. In a simple cooling example, the **process** is air or liquid removing heat; a **sensor** measures a relevant temperature; a **controller** compares that measurement with the desired condition; and an **actuator** changes a valve, fan or pump. New measurements report the resulting process behaviour, closing the feedback loop.

A **setpoint** is a desired target used by the control logic. The **process variable** is the measured condition. Their difference helps the controller decide what to do, but the response also depends on the chosen control method, limits, timing and operating mode. Raising a command does not always improve the process: an already saturated actuator has no remaining range, and an incorrectly located sensor may hide the condition that matters.

Separate three observations. A **command** is what the controller requested. **Equipment feedback** reports what the device or mechanism indicates it did, such as a drive running status or valve position. The **process effect** is the resulting temperature, flow or pressure. A drive can report running while a mechanical or hydraulic defect prevents the required flow. A command and status bit can therefore agree while cooling performance is wrong.

A PLC or DDC commonly executes local logic, while a BMS provides supervisory visibility and authorised requests. Define who has authority in each state: local automatic control, manual maintenance operation, remote supervisory control and restart. A maintenance override needs a purpose, owner, time limit or removal condition, visible indication and restoration check. An undocumented override can make an otherwise correct control sequence ineffective.

An **interlock** constrains an action based on conditions. A **permissive** commonly establishes a condition required before an action is allowed. Exact semantics belong in the approved sequence and vendor implementation. Neither label makes a function an independently engineered safety protection. Required protective functions must retain their intended authority and independence.

The system must also define responses to bad inputs and failures. On sensor loss, holding the last value, selecting a substitute or moving an actuator to a stated position can each have different consequences. There is no universal safe position for every fan, valve or pump. Derive behaviour from the actual process, equipment limits, hazards and operating requirements.

Commission the approved sequence in normal operation, mode transitions, communications loss, representative input faults and restart. Use safe models or authorised low-energy apparatus before field work. Record timing and actual response, then compare them with acceptance limits. Completing a simulation demonstrates the modelled behaviour, not that real plant has been commissioned.

### Worked example

**Example — a valve command is not cooling proof.** In a simulated cooling coil, the controller requests 80% valve opening and the actuator reports 80% position. The air leaving the coil remains too warm. Possible causes include insufficient chilled-water flow, warmer-than-required supply water, coil fouling, measurement error or an inappropriate load condition.

Do not declare success from matching percentages. Check the available upstream conditions, relevant flow/temperature evidence and sensor validity, then isolate the hypothesis that best explains the observations. The example identifies diagnostic reasoning; it is not an instruction to manipulate live plant.

### Guided practice

In a lab model, a fan receives a 60% command and its drive reports running, but the measured airflow is below requirement. List what is established and three plausible remaining fault classes.

**Hint:** Keep request, device indication and physical performance separate.

**Worked solution:** The command and reported run status are established within the lab evidence. Required airflow is not. Remaining classes include a mechanical/air-path issue, an incorrect drive or operating configuration, and an airflow measurement problem. Check the approved sequence, independent appropriate process evidence and the model limits before changing settings.

#### DC-15-Q1 — In a temperature-control loop, which component converts the controller output into a physical adjustment?

1. Historian
2. Actuator
3. CMMS work order
4. Dashboard legend

**Answer:** 2

- Option 1: A historian stores records rather than actuating the process.
- Option 2: An actuator changes a physical mechanism such as a valve position.
- Option 3: A work order organises work; it is not the process actuator.
- Option 4: The legend explains presentation.

#### DC-15-Q2 — A pump command is ON and the drive reports running. What remains to be demonstrated for cooling acceptance?

1. That the screen can display the word ON.
2. That the operator remembers issuing the command.
3. That required physical flow and cooling conditions are achieved within the acceptance limits.
4. That all sensors always have identical values.

**Answer:** 3

- Option 1: Presentation does not prove physical performance.
- Option 2: Issuing a command does not prove its outcome.
- Option 3: Actual process performance is the relevant remaining evidence.
- Option 4: Different sensors can correctly measure different physical conditions.

#### DC-15-Q3 — Which controls are appropriate for a maintenance override? Select all that apply.

1. Recorded purpose and authorised owner.
2. Visible indication and a defined removal condition.
3. Verification that normal control is restored afterwards.
4. Leaving it hidden so the dashboard looks normal.

**Answer:** 1, 2, 3

- Option 1: Ownership and purpose establish accountability for the temporary state.
- Option 2: The temporary state must be visible and bounded.
- Option 3: Removal alone does not prove the normal sequence works again.
- Option 4: Hidden overrides can conceal loss of intended control.

#### DC-15-Q4 — Which statement about sensor-loss response is sound?

1. Every valve must fully close.
2. Every controller should reboot repeatedly.
3. The response must be engineered for the specific process, constraints, hazards and required operating state.
4. Holding the last reading is always safe.

**Answer:** 3

- Option 1: A fully closed valve may remove required cooling or cause other consequences.
- Option 2: Repeated rebooting is not a general failure strategy.
- Option 3: Failure behaviour is a process-specific engineering decision.
- Option 4: The last reading may cease to represent the process.

### Sources

- [NIST SP 800-82 Rev. 3 — Guide to Operational Technology Security (final)](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [US DOE — Best Practices Guide for Energy-Efficient Data Center Design (2024)](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)

## DC-16 — Controlled maintenance and a usable rollback

Overview · Target topic stage: Applied · 20 estimated overview study minutes · Prerequisites: DC-04, DC-11

Plan a bounded change around dependencies, degraded operation, stop conditions and observable return to service.

### Learning objectives

- Define preconditions, stop conditions and acceptance criteria for a change.
- Distinguish a backup from a feasible rollback or recovery procedure.
- Identify evidence required before restoring normal service status.

Maintenance is an intentional transition through a different operating state. A redundant system may have reduced failure tolerance while one component is unavailable. A change can also affect shared services such as time, credentials, monitoring or network management. Plan against the effective dependencies and current condition, not just the normal-state diagram.

Start with the required outcome: what defect or improvement justifies the work, what must remain available, and what evidence will establish success? Define the exact assets, configuration baseline, authorised actions and expected impacts. Confirm that upstream and downstream owners understand the change. For physical or hazardous work, the approved isolation, supervision and site procedures control execution.

**Preconditions** state what must be true before starting: verified identity of the target, acceptable load, required redundancy, usable backups, access, qualified people and a suitable work window. **Stop conditions** state when to pause or abort: an unexpected dependency, loss of required monitoring, a failed redundancy check, or remaining time below that needed for recovery. An operator needs these conditions before the situation becomes urgent.

A **backup** is restoration material. A **rollback** is a feasible method of returning to a previous acceptable state. They are not interchangeable. A firmware downgrade may be unsupported; a database migration may alter data irreversibly; a controller restore may lose later valid changes. Specify versions, tools, credentials, dependencies, expected duration and the post-rollback tests. If exact rollback is impossible, define the approved recovery alternative and its consequences before proceeding.

Execute in observable stages. Record the initial condition, the action, its result and any deviation. Avoid treating an expected alarm as a reason to suppress every alarm. Preserve the indicators needed to detect unexpected consequences. Where possible, prove the changed component before changing the next one, while respecting the architecture's actual failover behaviour.

**Return to service** requires function, protection and records to agree. Verify the intended service, correct measurements, alarms, access controls, redundancy and normal operating mode. Remove temporary accounts, overrides or bypasses under the approved procedure. Update configuration records and the CMMS work order with evidence, unresolved defects and any follow-up action.

A failed change is useful engineering evidence if the team detects the failure, limits its consequences and restores the required state. Measure actual recovery duration and compare it with the plan. Revise unrealistic estimates and missing dependencies. A ticket marked successful is an administrative outcome; demonstrated operation within the required limits is the engineering outcome.

### Worked example

**Example — a lab poller upgrade fails acceptance.** The maintenance plan allows a 20-minute window, requires rollback to begin with at least 8 minutes remaining, and has a verified previous configuration plus a tested 6-minute restore. The new version starts, but after 11 minutes point quality remains invalid.

There are 9 minutes left. Follow the stated rollback decision now rather than consuming the restoration margin with unbounded troubleshooting. Restore the approved version/configuration, verify current samples, alarms and historian delivery, then record the failed upgrade and its evidence. The 6-minute result is a lab measurement, not a guarantee for other environments.

### Guided practice

A controller maintenance plan says only “back up first; revert if necessary.” Name five missing items needed to make the plan reviewable.

**Hint:** Consider authority, starting state, time, actual restoration method and evidence.

**Worked solution:** Missing items include authorised scope and target identification; required operating/redundancy preconditions; the exact supported restore method and dependencies; rollback trigger and latest decision time; and post-restore acceptance tests. Also record hazards/supervision where applicable, backup verification, communications, and temporary-state cleanup.

#### DC-16-Q1 — Why is a configuration backup insufficient by itself as a rollback plan?

1. A backup always contains malware.
2. Restoration may require unavailable tools, credentials, compatible versions or more time than allowed.
3. Rollback must always be performed by replacing all hardware.
4. Configuration files have no engineering value.

**Answer:** 2

- Option 1: A backup must be assessed, but infection is not inevitable.
- Option 2: A feasible rollback includes the method, dependencies, compatibility, timing and validation.
- Option 3: Hardware replacement is only one possible recovery method.
- Option 4: Configuration backups are valuable restoration material.

#### DC-16-Q2 — One of two required alternate service paths is removed for authorised maintenance. What should be evaluated?

1. Only whether its label is correct.
2. Whether the remaining path meets required load and whether the current state has reduced failure tolerance or common dependencies.
3. Whether the ticket has enough comments.
4. Whether the unavailable path still appears green on an old screenshot.

**Answer:** 2

- Option 1: Identification matters, but capacity and failure tolerance matter too.
- Option 2: Maintenance changes the system state and may reduce fault tolerance.
- Option 3: Comment volume does not demonstrate engineering suitability.
- Option 4: An old image cannot establish present availability.

#### DC-16-Q3 — Which are useful predeclared stop conditions? Select all that apply.

1. Unexpected loss of the remaining required service path.
2. A discovered dependency that invalidates the approved method.
3. Insufficient remaining time for the required recovery procedure.
4. An operator prefers the new dashboard colour.

**Answer:** 1, 2, 3

- Option 1: This can invalidate continued safe/service operation.
- Option 2: An invalid method needs reassessment before execution continues.
- Option 3: Preserving recovery time is part of containing change risk.
- Option 4: Colour preference is not a relevant operational stop condition here.

#### DC-16-Q4 — What is the strongest basis for closing a maintenance work order?

1. The elapsed time matches the estimate.
2. The technician has uploaded a screenshot of the installer.
3. Required function, normal modes, access controls, redundancy and updated records pass the defined checks, with defects recorded.
4. No one has called to complain yet.

**Answer:** 3

- Option 1: An on-time change can still fail requirements.
- Option 2: Installer evidence covers only part of the work.
- Option 3: This aligns actual operation, security and records with the acceptance criteria.
- Option 4: Absence of complaints is not a controlled test.

### Sources

- [NIST SP 800-82 Rev. 3 — Guide to Operational Technology Security (final)](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [NIST SP 800-193 — Platform Firmware Resiliency Guidelines](https://csrc.nist.gov/pubs/sp/800/193/final)

## DC-17 — Trust boundaries and trusted recovery

Overview · Target topic stage: Applied · 20 estimated overview study minutes · Prerequisites: DC-10, DC-13

Protect operational authority, contain compromise without losing required control, and validate trust as well as restored service.

### Learning objectives

- Identify identities and administrative paths that cross trust boundaries.
- Explain why segmentation and backups alone do not establish recovery readiness.
- Separate functional restoration from restoration of trustworthy authority.

Cybersecurity protects the required operation of the facility and the authority to change it. Begin with functions and consequences: who or what can observe, configure, command, update, shut down or restore a system? Include human accounts, device identities, service accounts, keys and remote-support mechanisms. A network diagram without these authority paths leaves important attack paths invisible.

A **trust boundary** is a point where assumptions about identity, authority or acceptable behaviour change. A vendor session entering an engineering workstation crosses such a boundary. So can a monitoring application using credentials to query field devices, or a management service reaching a BMC. Define the required interaction, constrain it to appropriate identities and functions, and record what evidence can show misuse.

Segmentation reduces permitted communication and can limit the scope of a compromise. It does not correct excessive permissions on an allowed path. A firewall may correctly allow an engineering workstation to reach controllers while stolen credentials allow a malicious logic change. Protect endpoints, administrative sessions, project files, firmware and recovery material as well as the traffic paths.

Detection must combine digital and process evidence. An unexpected account, configuration change or new connection is significant, but diagnosis also asks what changed physically and which services remain trustworthy. Preserve relevant logs, timestamps and state where feasible. A system reboot can restore availability while removing evidence or leaving the compromised authority intact.

Containment in OT must account for continued physical operation. Disconnecting a supervisory system can be appropriate in one architecture and disruptive in another. Use the approved incident procedure, local control behaviour and authorised operators to select a bounded response. Establish what must keep running, which access can be removed and how the team will observe the process during degraded operation.

**Trusted recovery** restores both function and justified confidence in the system. Select restoration material with known provenance and integrity; assess whether it predates compromise. Remove malicious changes and persistence, rebuild affected components where necessary, and revoke or replace compromised credentials and keys. Restore dependencies in a workable order, including network access, time, identity and backup services.

Then validate two separate claims. Functional tests show the required measurements, sequences, alarms and services work. Security tests show that approved authority works, removed authority remains removed, expected configurations are present and monitoring can observe further misuse. Neither claim implies the other.

This lesson uses tabletop reasoning and isolated laboratory examples. Its certificate tags indicate conceptual relevance; completing it is not a standards-conformance assessment, production incident qualification or permission to test a live environment.

### Worked example

**Example — an unauthorised controller change.** A lab controller runs an unexpected project, and its engineering account is known to be compromised. Restoring the approved project recovers the expected sequence, but the same account can immediately change it again.

A complete response must address the account and its remaining sessions or other retained authority, verify trusted restoration material and the affected host/controller state, then test both the physical model's sequence and rejection of the removed access. Record the actual evidence and remaining uncertainty. “The temperature looks normal” is only part of the result.

### Guided practice

An isolated lab historian is rebuilt from a backup after account compromise. Data collection resumes, but the old administrator token still authenticates. Is recovery complete? Specify the next acceptance checks.

**Hint:** Availability and administrative trust are separate claims.

**Worked solution:** No. Data collection demonstrates partial functional recovery, while the old token demonstrates retained compromised authority. Revoke or replace affected credentials/tokens and assess related persistence or delegated authority. Verify the approved restoration baseline, successful intended access, denied old access, collection freshness, timestamps, alarm/history function and visibility of the recovery actions.

#### DC-17-Q1 — Which question best identifies an important trust boundary?

1. Which dashboard colour is preferred?
2. Where does a vendor identity gain authority to change an operational system?
3. How many icons fit on the home page?
4. Which cabinet is closest to the door?

**Answer:** 2

- Option 1: Presentation colour does not identify an authority transition.
- Option 2: The point where external identity acquires operational authority is a critical boundary.
- Option 3: Icon count does not describe security authority.
- Option 4: Physical location can matter, but this question alone does not identify the authority transition.

#### DC-17-Q2 — A restored controller executes the correct sequence, but a stolen account can still modify it. Which conclusion is justified?

1. Recovery is complete because the sequence works.
2. Functional restoration is demonstrated within the test, but compromised authority remains unresolved.
3. The firewall must be turned off.
4. The backup must be deleted immediately.

**Answer:** 2

- Option 1: Retained malicious authority can compromise the system again.
- Option 2: This separates the two claims supported by the evidence.
- Option 3: Removing network controls does not address the retained account.
- Option 4: Backup disposition requires assessment; deletion does not fix authority.

#### DC-17-Q3 — Which checks support trusted recovery? Select all that apply.

1. Required process/service behaviour meets defined tests.
2. Compromised credentials and retained sessions or equivalent authority are addressed and denied as required.
3. Restored configurations and software have justified provenance/integrity.
4. Any accessible backup is used without considering the compromise timeline.

**Answer:** 1, 2, 3

- Option 1: Function must be verified after restoration.
- Option 2: Removed authority must remain removed.
- Option 3: Trustworthy restoration material is part of justified recovery.
- Option 4: A backup may preserve compromise or incompatible state.

#### DC-17-Q4 — Why should an OT containment decision consider local control behaviour?

1. Because disconnecting any network always makes the plant safe.
2. Because cyber incidents never affect physical systems.
3. Because the chosen isolation can change supervision, control or visibility and must preserve required safe/degraded operation.
4. Because all controllers stop immediately when the BMS is disconnected.

**Answer:** 3

- Option 1: Isolation can have different effects depending on the architecture.
- Option 2: OT compromise can affect physical processes.
- Option 3: Containment must consider actual operational dependencies and consequences.
- Option 4: Controller behaviour depends on the approved design and implementation.

### Sources

- [NIST SP 800-82 Rev. 3 — Guide to Operational Technology Security (final)](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [NIST SP 800-193 — Platform Firmware Resiliency Guidelines](https://csrc.nist.gov/pubs/sp/800/193/final)

## DC-18 — PUE, capacity and the cost of a useful service

Overview · Target topic stage: Foundation · 20 estimated overview study minutes · Prerequisites: DC-02, DC-05

Calculate PUE correctly, recognise its limits and evaluate efficiency alongside capacity, reliability and useful output.

### Learning objectives

- Calculate PUE from matching facility and IT energy measurements.
- Explain why lower PUE alone does not prove lower total energy or better useful-work efficiency.
- Separate available capacity from energy consumption and lifecycle cost.

An efficiency measure is useful when it answers a precise question. **Power usage effectiveness (PUE)** compares total data-center energy with the energy delivered to IT equipment over the same measurement period and a consistent boundary:

**PUE = total data-center energy ÷ IT equipment energy.**

If the facility uses 1,500 MWh while IT equipment uses 1,000 MWh, PUE is 1.50. The non-IT energy is 500 MWh. That overhead equals 50% of IT energy but one-third of total facility energy. State the denominator whenever presenting a percentage. Mixing yesterday's facility total with today's IT total does not produce a meaningful comparison.

PUE describes infrastructure overhead relative to IT consumption. It does not measure useful computation, application performance, carbon intensity, water use or reliability. A site can achieve a lower ratio while consuming more energy because its IT load rose. A successful reduction in IT energy can even raise PUE if some facility overhead remains fixed, despite reducing total consumption. Judge the intended outcome using the actual totals and useful service, not the ratio alone.

A short-interval ratio can help investigate operation, but it should not be presented as annual performance. Weather, load, operating mode, measurement location and data quality affect comparisons. Record the period, boundary and completeness of the measurements. Distinguish a design prediction or model result from measured operation.

**Capacity** is the ability to support a required load within constraints. Spare nameplate power does not necessarily mean a rack can accept another server: branch-circuit loading, failure-state capacity, cooling delivery, rack space, network resources or maintenance conditions may be limiting. Evaluate the constraint that binds under the required normal and degraded states. Unused redundancy reserved for a failure is not automatically spare sellable capacity.

**Cost** combines more than energy price. At a simple flat tariff, energy cost is kWh multiplied by currency per kWh. Real tariffs may also include demand, time-of-use and other charges. Equipment, installation, licensing, maintenance, staffing, spares, outage consequences and replacement affect lifecycle cost. The lowest purchase price can create a more expensive operating system.

Optimisation should therefore start with a bounded proposal: what energy or capacity improvement is expected, which constraints must remain satisfied, and how will it be measured? Establish a baseline, control or account for relevant changes in load and conditions, test within authorised limits, and verify service, thermal margins and recoverability afterwards. A lower fan setting is not a successful improvement if it creates hot spots or removes needed failure tolerance.

Use PUE as one instrument in that evaluation, alongside absolute energy, useful output, water/carbon measures where relevant, capacity and operational evidence.

### Worked example

**Example — lower PUE, higher consumption.** Period A uses 1,500 MWh total and 1,000 MWh in IT: PUE = 1.50, with 500 MWh overhead. Period B uses 1,680 MWh total and 1,200 MWh in IT: PUE = 1.40, with 480 MWh overhead.

PUE improves and absolute overhead falls by 20 MWh, but total energy rises by 180 MWh. Whether the change is beneficial depends on the useful service delivered, required performance, cost and other constraints. At the same assumed flat energy tariff of €0.15/kWh, the simplified energy charges are €225,000 and €252,000; these exclude demand charges and other costs.

### Guided practice

A monthly report gives 900 MWh facility energy and 600 MWh IT energy. Calculate PUE and overhead energy. Another report claims 300 kW of spare electrical capacity, but the required failure case has only 80 kW headroom. Can 200 kW of new IT load be accepted from these facts alone?

**Hint:** Energy ratios and failure-state capacity answer different questions.

**Worked solution:** PUE = 900/600 = 1.50; non-IT overhead = 300 MWh. A 200 kW addition cannot be accepted against an 80 kW required failure-state margin. Further capacity/design work is needed, along with cooling, distribution and other constraint checks. The favourable-looking energy ratio does not remove the capacity shortfall.

#### DC-18-Q1 — A site uses 2,400 MWh total and 1,600 MWh for IT in the same period. What is PUE?

1. 0.67
2. 1.50
3. 800
4. 2.40

**Answer:** 2

- Option 1: This reverses the numerator and denominator.
- Option 2: 2,400 ÷ 1,600 = 1.50.
- Option 3: 800 MWh is overhead energy, not the dimensionless ratio.
- Option 4: The stated numbers do not yield this ratio.

#### DC-18-Q2 — PUE falls from 1.5 to 1.3. What can you conclude from those ratios alone?

1. Total facility energy definitely fell.
2. Useful computation definitely increased.
3. Non-IT energy per unit of IT energy fell, assuming comparable boundaries and valid data.
4. The site is now resilient to all failures.

**Answer:** 3

- Option 1: Total energy also depends on the amount of IT energy.
- Option 2: PUE does not measure useful computation.
- Option 3: That is the relationship represented by a lower PUE.
- Option 4: PUE is not a resilience measure.

#### DC-18-Q3 — Which can prevent adding a server despite apparent spare upstream power? Select all that apply.

1. Insufficient required failure-state electrical headroom.
2. Insufficient local cooling delivery.
3. Insufficient allowable rack space or supported loading.
4. A low PUE by itself.

**Answer:** 1, 2, 3

- Option 1: Required degraded-state capacity must still be met.
- Option 2: The new heat load needs adequate cooling at the relevant location.
- Option 3: Physical and equipment constraints also apply.
- Option 4: A ratio alone does not establish a capacity limit.

#### DC-18-Q4 — At an assumed flat €0.20/kWh, what is the energy-only cost of 50 MWh?

1. €10
2. €1,000
3. €10,000
4. €100,000

**Answer:** 3

- Option 1: This treats MWh as if it were kWh.
- Option 2: This is ten times too small.
- Option 3: 50 MWh = 50,000 kWh; × €0.20 = €10,000. Other charges are excluded.
- Option 4: This is ten times too large.

### Sources

- [US DOE — Best Practices Guide for Energy-Efficient Data Center Design (2024)](https://www.energy.gov/sites/default/files/2024-07/best-practice-guide-data-center-design_0.pdf)
