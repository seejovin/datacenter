# Facility — overview notes

These are short introductory overviews, including overviews of advanced topics. They are introductory companion notes. The new detailed course books are in docs/academy, with their own source mappings and scope limits. Answers follow each question. Practical assignment briefs require further instruction and execution.

## DC-01 — The data center as a working system

Overview · Target topic stage: Foundation · 20 estimated overview study minutes · Prerequisites: none

Trace the dependencies that keep an IT service available, observable, and recoverable.

### Learning objectives

- Distinguish a component being healthy from a service being delivered.
- Trace power, heat, data, and control dependencies.
- Describe normal, degraded, failed, and restored operating states.

### Start with the required service
A data center exists to support useful computation, storage, and communication within agreed constraints. A server being powered on is only one condition. Its application may also require working storage, network paths, name resolution, accurate time, identities, and remote services. Physical infrastructure must continually supply electrical energy and remove heat. People, procedures, spares, and trustworthy records make the installation maintainable and recoverable.

Separate four flows when drawing a system. **Power** travels through sources and distribution to equipment. **Heat** travels from components into air or liquid and ultimately to an external sink. **Data** carries application traffic and management messages. **Control** uses measurements and logic to influence equipment. These flows interact but are not interchangeable: a green network link does not establish that a temperature measurement is fresh or that a valve moved.

### Identify dependencies and authority
For each required function, ask what it consumes, what it produces, what controls it, and how its failure becomes visible. A cooling pump consumes power, moves fluid, and may depend on a local controller. A supervisory server can display its status without being the controller that keeps it running. Losing the display and losing pump operation are different events, although loss of visibility can still require an operational response.

Physical dependencies extend beyond the system you own. Building and site interfaces matter, but awareness of an interface is not responsibility for designing the building. In this programme, D1 civil, structural, and architectural engineering remains outside owned scope. Power and cooling knowledge initially supports sound integration; deeper engineering develops through the long-term track.

### Think in operating states
Describe normal service, planned maintenance, degraded operation, failure, and recovery separately. A redundant device may allow continued service after one failure while leaving no spare capacity for maintenance. Restoration requires more than making the last alarm disappear: confirm that the required function, protection, observability, and intended redundancy are back.

Use a small dependency table with columns for function, supporting assets, loss consequence, available evidence, owner, and recovery prerequisite. It becomes the basis for commissioning tests and incident reasoning. During a fault, compare the intended design with the effective state. Installed equipment can be healthy while an incorrect configuration, unavailable dependency, or stale measurement prevents successful operation.

This lesson uses analytical examples. Completing it demonstrates understanding of dependency reasoning, not experience operating a production facility.

### Worked example

**Scenario:** A supervisory dashboard freezes while local cooling controllers continue regulating temperature. The application service remains available.

1. The immediate confirmed loss is monitoring freshness, not cooling itself.
2. Check timestamps, controller-local trends, and an independent approved measurement source before inferring the physical state.
3. Identify which alarms and remote commands are unavailable, and use the site's degraded-monitoring procedure.
4. After communication returns, verify fresh values and alarm delivery. Continued cooling alone does not prove the supervisory path recovered.

### Guided practice

A server responds to ping, but users cannot read stored files. Name three dependencies to investigate and one observation that would narrow the fault.

**Hint:** Treat ICMP reachability as evidence about one network exchange, not the complete storage service.

**Worked solution:** Investigate the file service, storage path/volume health, and authentication/authorization; DNS may also matter. An authenticated read of a known test file exercises more of the required service than ping. Correlate its error with service and storage logs before changing anything.

#### DC-01-Q1 — A server responds to ping. What has this established?

1. The complete user service works.
2. An ICMP exchange succeeded at that time.
3. All application dependencies are healthy.
4. Its stored data is correct.

**Answer:** 2

- Option 1: Ping does not execute the user workflow.
- Option 2: Correct: the evidence is bounded to the observed network exchange.
- Option 3: Dependencies can fail despite reachability.
- Option 4: Reachability says nothing about data correctness.

#### DC-01-Q2 — A monitoring server fails while autonomous cooling controllers remain healthy. Which conclusion is justified?

1. All cooling has stopped.
2. No operational response is needed.
3. Visibility may be impaired although local control continues.
4. Every displayed value remains valid indefinitely.

**Answer:** 3

- Option 1: Local control may operate independently.
- Option 2: Reduced visibility can change the permitted operating state.
- Option 3: Correct: distinguish observation and control functions.
- Option 4: Freshness expires when updates stop.

#### DC-01-Q3 — Which two observations support recovery after an OT communications outage? Select two.

1. New timestamps and appropriate value quality appear.
2. Historical alarms have been deleted.
3. A planned test confirms alarm delivery.
4. The dashboard uses green colours.

**Answer:** 1, 3

- Option 1: Correct: this supports restoration of fresh measurements.
- Option 2: Deleting history removes useful evidence.
- Option 3: Correct: this checks an operational function.
- Option 4: Colour is presentation and can be stale or misconfigured.

#### DC-01-Q4 — Why record a building dependency even when building engineering is outside your scope?

1. It gives you authority to redesign the building.
2. Dependencies outside ownership cannot affect service.
3. It replaces the building engineer’s acceptance work.
4. Its loss can affect your system, so interfaces and ownership need to be clear.

**Answer:** 4

- Option 1: Recording an interface does not grant authority.
- Option 2: External dependencies can dominate service availability.
- Option 3: Each owner retains its acceptance responsibilities.
- Option 4: Correct: ownership and dependency awareness are distinct.

### Sources

- [Schneider Electric University — DCCA topic overview](https://www.se.com/us/en/about-us/university/)
- [NIST SP 800-82 Rev. 3 — final OT security guide](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

## DC-02 — Power, energy, and the meaning of capacity

Overview · Target topic stage: Foundation · 20 estimated overview study minutes · Prerequisites: DC-01

Use kW, kVA, power factor, and kWh correctly before making capacity decisions.

### Learning objectives

- Calculate energy from a stated load and duration.
- Distinguish real power, apparent power, and power factor.
- Check both kW and kVA constraints without treating a rating as a measurement.

### Four quantities with different jobs
**Real power**, measured in watts or kilowatts, is the rate of electrical energy converted into useful work and heat. **Energy**, measured in kilowatt-hours, accumulates over time. A constant 8 kW load running for 3 hours consumes 24 kWh. If demand changes, add the energy used in each interval; do not multiply one instantaneous reading by a month and call it measured consumption.

**Apparent power**, measured in volt-amperes or kVA, expresses the product of RMS voltage and RMS current. In a single-phase circuit, apparent power is voltage times current. **True power factor** is real power divided by apparent power: PF = kW / kVA. Consequently, kVA = kW / PF. This definition includes the combined influence of phase displacement and waveform distortion. Power factor is not the same as equipment efficiency.

Equipment may have independent kW and kVA ratings. Both constraints matter. A UPS rated 10 kVA and 9 kW cannot supply an 11 kVA load merely because that load consumes only 8.8 kW. Conversely, staying within 10 kVA does not permit exceeding 9 kW. Voltage, phase arrangement, allowable current, protective devices, environmental conditions, and vendor limits also constrain the installation.

### Ratings, observations, and assumptions
A nameplate supplies rated information, not proof of actual demand. A dashboard supplies observations only if its meter, scaling, units, timestamps, and measurement location are correct. Separate measured demand, design demand, reserved capacity, permitted operating limit, and contingency demand in every capacity record.

Efficiency compares useful output power with input power at a defined boundary. A 96% efficient conversion stage supplying 48 kW draws 50 kW under that stated condition; approximately 2 kW is lost, largely as heat. Power factor instead relates real and apparent input power. Neither number alone describes battery runtime, redundancy, or overall service reliability.

### Reason through the limiting condition
A capacity check should identify the worst required operating state. In normal operation two paths may share a load. After one path fails, the surviving path may carry much more. Use documented engineering limits for that state and retain uncertainty and growth margins explicitly. The examples here are arithmetic exercises; final circuit sizing and protective-device selection require the responsible electrical engineer and applicable installation rules.

For operational evidence, record what was measured, where, over what interval, and under what load state. This prevents precise calculations built on the wrong boundary from becoming misleading engineering conclusions.

### Worked example

**Example:** A hypothetical load is 8 kW at true PF 0.8. Its apparent power is 8 / 0.8 = **10 kVA**. Over 6 constant-load hours it uses **48 kWh**.

A UPS rated 9 kW / 10 kVA reaches its apparent-power ceiling at this load even though it has 1 kW of arithmetic real-power headroom. That is not spare usable capacity for arbitrary additions. This comparison also excludes required margins and transient constraints, which still need assessment.

### Guided practice

A load consumes 6 kW at PF 0.75 for 4 hours. Calculate kVA and kWh. A proposed unit is rated 7 kVA / 6.3 kW: does the load fit both ratings?

**Hint:** Compute apparent power separately from accumulated energy, then compare both power ratings.

**Worked solution:** Apparent power = 6 / 0.75 = 8 kVA. Energy = 6 × 4 = 24 kWh. It does not fit: 8 kVA exceeds 7 kVA, even though 6 kW is below 6.3 kW.

#### DC-02-Q1 — A constant 12 kW load runs for 2.5 hours. How much energy does it use?

1. 4.8 kWh
2. 14.5 kWh
3. 30 kWh
4. 30 kVA

**Answer:** 3

- Option 1: Dividing power by time is not the energy calculation.
- Option 2: Adding unlike quantities is invalid.
- Option 3: Correct: 12 × 2.5 = 30 kWh.
- Option 4: kVA measures apparent power, not energy.

#### DC-02-Q2 — An 8 kW load has PF 0.8. A unit is rated 9 kW / 9 kVA. Which statement is correct?

1. The kVA rating is exceeded.
2. Both ratings are satisfied.
3. Only the kW rating is exceeded.
4. PF increases its capacity to 11.25 kVA.

**Answer:** 1

- Option 1: Correct: 8 / 0.8 = 10 kVA, above 9 kVA.
- Option 2: The real-power comparison passes but the apparent-power comparison fails.
- Option 3: 8 kW is below 9 kW.
- Option 4: PF does not increase the equipment rating.

#### DC-02-Q3 — A device has PF 0.95 and conversion efficiency 0.90. What does efficiency describe?

1. The ratio of kW to kVA.
2. The percentage of time it is available.
3. Its battery state of charge.
4. Useful output power divided by input power at a defined boundary.

**Answer:** 4

- Option 1: That defines true power factor.
- Option 2: Availability is a different measurement.
- Option 3: Battery charge is not conversion efficiency.
- Option 4: Correct: the boundary and operating point must be specified.

#### DC-02-Q4 — Which two items are necessary for a defensible capacity assessment? Select two.

1. Measured demand and its measurement boundary.
2. Only the number of empty rack units.
3. Required surviving-path load after a relevant failure.
4. An assumption that nameplate ratings equal actual consumption.

**Answer:** 1, 3

- Option 1: Correct: demand must be tied to a location and operating condition.
- Option 2: Physical space alone does not establish electrical capacity.
- Option 3: Correct: contingency demand can be the binding limit.
- Option 4: Rated and measured values must remain distinct.

### Sources

- [Schneider Electric University — DCCA topic overview](https://www.se.com/us/en/about-us/university/)
- [LBNL Center of Expertise — data center energy toolkit](https://datacenters.lbl.gov/)

## DC-03 — Power distribution and transfer states

Overview · Target topic stage: Foundation · 20 estimated overview study minutes · Prerequisites: DC-02

Understand what UPS systems, generators, distribution, and transfer devices contribute to continuity.

### Learning objectives

- Trace a conceptual power path to an IT load.
- Explain the different continuity roles of UPS energy storage and a generator.
- Identify evidence needed across transfer and restoration states.

### Follow the complete path
A conceptual power path may include an external supply, switchgear, a UPS, downstream distribution, rack power distribution, and server power supplies. A generator and transfer arrangement provide an alternative source according to the site design. Real installations differ; a simplified block diagram establishes functional relationships and must never be used as a switching instruction.

Distribution delivers energy at the required voltage and capacity, with protection and isolation appropriate to the installation. A UPS can condition supply and provide stored-energy support within its topology and operating limits. A generator provides longer-duration energy when started, stable, connected, and supplied with the resources it needs. A transfer device selects or transfers between sources under defined conditions. These devices perform different functions and are not substitutes for one another.

### Timing creates continuity
After utility loss, a UPS may bridge the interval before an alternative source is available. Battery runtime depends on load, battery condition, temperature, configuration, and manufacturer performance data; dividing a nominal battery energy label by load is only an idealized estimate. Generator readiness includes more than an engine-running signal. Voltage, frequency, protective state, transfer conditions, and downstream acceptance matter.

IT power may survive while cooling pumps or fans experience a different interruption. Service continuity therefore requires evaluating both the electrical timeline and the thermal response. The time before an unacceptable temperature depends on the installation and load; it must not be invented from a generic rule.

### Recognize operating modes
Normal conversion, stored-energy operation, static bypass, and maintenance bypass have different implications. The details depend on the UPS design. A bypass path may keep the load supplied while reducing the conditioning or stored-energy protection available. 'Load energized' and 'load has its intended protection' are distinct conditions.

Return to normal is another controlled transition. A site may require source stability, load checks, coordination with cooling, and verification of restored reserves. A successful one-time transfer says little about degraded batteries, missed alarms, or an incorrectly recorded distribution path.

### Evidence and responsibility
For a paper exercise, construct an event timeline: initial source loss, UPS state, alternative-source readiness, transfer result, cooling state, and restored normal state. List what each observation proves and what remains unknown. Commissioning records should tie acceptance criteria to the actual operating modes tested.

Hands-on switching, isolation, battery work, generator testing, and changes to protection belong to authorized personnel following approved site procedures. Your foundation task is to understand the architecture, interpret evidence, identify dependencies, and recognize when the required operating state is not established.

### Worked example

**Scenario:** A recorded test shows utility loss at 10:00:00, UPS stored-energy operation, generator ready at 10:00:18, and successful transfer at 10:00:23. Server power remains stable.

This supports the electrical continuity claim for that tested load and configuration. It does **not** by itself prove cooling continuity or adequate battery endurance under a longer generator delay. Inspect cooling trends and the actual UPS runtime evidence; also confirm the normal protected state was restored after the test.

### Guided practice

A report says “generator running, therefore rack load protected.” Identify two missing observations.

**Hint:** Trace from the alternative source all the way to the load, then ask which protection state is active.

**Worked solution:** Missing evidence includes generator output within required limits and successful transfer/delivery to the load. Also establish UPS operating mode, downstream voltage/load, and available reserve. An engine-running signal alone proves none of those downstream conditions.

#### DC-03-Q1 — What is the usual conceptual role of UPS stored energy during generator startup?

1. It provides unlimited backup duration.
2. It bridges a finite supply interruption within its limits.
3. It guarantees every cooling device remains powered.
4. It removes all transfer-state risks.

**Answer:** 2

- Option 1: Storage has finite usable energy.
- Option 2: Correct: continuity depends on load, runtime, and successful alternative-source availability.
- Option 3: Cooling power paths require separate verification.
- Option 4: The complete sequence still needs validation.

#### DC-03-Q2 — A generator engine is running. Which additional evidence is most relevant before claiming it supplies the IT load?

1. Its paint colour matches the drawing.
2. The UPS dashboard is reachable.
3. The fuel tank has a label.
4. Acceptable electrical output, transfer state, and downstream delivery are verified.

**Answer:** 4

- Option 1: Appearance does not establish the electrical state.
- Option 2: Dashboard reachability does not prove source selection.
- Option 3: Identification alone does not prove supply.
- Option 4: Correct: follow the source-to-load chain.

#### DC-03-Q3 — A UPS is on a bypass path and the load is energized. What should the operator determine?

1. Which protection functions and backup capability remain in that specific mode.
2. Whether energized means all intended protections are automatically present.
3. Whether all alarms can now be ignored.
4. Whether generator maintenance can proceed without assessment.

**Answer:** 1

- Option 1: Correct: bypass implications depend on topology and operating state.
- Option 2: Energization and protection are separate conditions.
- Option 3: Alarms may indicate a degraded state.
- Option 4: Concurrent maintenance requires an explicit assessment.

#### DC-03-Q4 — A transfer test maintains server power. Which two checks strengthen the continuity assessment? Select two.

1. Confirm cooling behaviour during and after the transition.
2. Delete abnormal events so the report is clear.
3. Confirm restoration of the intended protected configuration.
4. Assume future loads behave identically.

**Answer:** 1, 3

- Option 1: Correct: power continuity alone is not service continuity.
- Option 2: Abnormal events need explanation and preservation.
- Option 3: Correct: recovery includes returning required reserves and protections.
- Option 4: The claim remains bounded to tested conditions.

### Sources

- [Schneider Electric University — DCCA topic overview](https://www.se.com/us/en/about-us/university/)
- [LBNL Center of Expertise — data center energy toolkit](https://datacenters.lbl.gov/)

## DC-04 — Redundancy, independence, and maintenance

Overview · Target topic stage: Foundation · 20 estimated overview study minutes · Prerequisites: DC-03

Test redundancy claims against capacity, shared dependencies, and the actual operating state.

### Learning objectives

- Interpret N, N+1, and 2N as bounded capacity descriptions.
- Identify common-cause failures across redundant components.
- Recalculate resilience during maintenance or an existing failure.

### Define what N means
N is the capacity or number of units needed to meet a specified demand under stated conditions. If two identical 50 kW cooling units are needed to support a 90 kW design load at the relevant conditions, N is two units. A third equivalent available unit creates N+1 unit capacity for that stated model. Two complete capacity sets are commonly described as 2N. These labels summarize an aspect of a design; they do not establish a service-availability percentage.

Check usable rather than merely installed capacity. Environmental derating, disabled units, control constraints, distribution bottlenecks, and operating policy can change what is available. A plant with three installed units may have only two in service. If the load grows beyond what two can supply, its original N+1 claim may no longer hold.

### Spare capacity is not independence
Redundant equipment can share a power source, control panel, sensor, network path, pipe, firmware defect, maintenance procedure, or physical exposure. A single failure at that shared dependency can defeat several nominally separate components. A common-cause failure affects multiple elements through the same underlying event or condition. Independence must be assessed for the failures relevant to the service.

Dual server power supplies connected to different rack PDUs are only as independent as their upstream paths. Likewise, two cooling pumps sharing an unavailable electrical panel may offer no protection against loss of that panel. Avoid replacing architecture tracing with a device count.

### Maintenance changes the system
When one N+1 unit is intentionally unavailable, the remaining units may meet demand but have no spare unit for another failure. That is a degraded state even if every dashboard value looks normal. An acceptable maintenance window requires a defined operating envelope, current equipment condition, change controls, contingency response, and a restoration plan.

Concurrent maintainability concerns whether required maintenance can occur without interrupting the supported service under the defined conditions. Fault tolerance concerns continued operation following specified faults. Neither can be inferred from a single redundancy label. The assessment must include paths, controls, isolation boundaries, and the sequence of actions.

### Make a claim you can test
Write a bounded statement: 'At a 90 kW heat load under these inlet and ambient conditions, removal of any one of these three units leaves sufficient cooling capacity, with these dependencies available.' Then list tests and evidence for capacity, automatic response, alarms, and return to the intended state.

A useful review asks four questions: what can fail, what remains, whether what remains is sufficient, and how you know. This method also applies to network uplinks, management services, controller pairs, and recovery infrastructure.

### Worked example

**Example:** Three independently controllable cooling units each provide 50 kW under the stated conditions. Required load is 90 kW.

With all three available, losing one leaves 100 kW: the capacity model tolerates that one-unit loss. During maintenance of one unit, losing another leaves 50 kW, below demand. Moreover, if all units share one failed supply, the spare unit count does not help. Capacity and dependency checks answer different questions.

### Guided practice

Four equal units can each deliver 30 kW at the specified conditions. Demand is 85 kW. How many units constitute N, and what remains after one unit is maintained and another fails?

**Hint:** Find the smallest whole number of units that meets demand, then count the units actually available.

**Worked solution:** N = 3 units because 2 × 30 = 60 kW is insufficient and 3 × 30 = 90 kW is sufficient. Four available units provide N+1 capacity. Maintenance plus another loss leaves 2 × 30 = 60 kW, insufficient for 85 kW.

#### DC-04-Q1 — Three 40 kW units support a 70 kW demand under specified conditions. What capacity description fits all three available units?

1. N, because 120 kW is installed.
2. 2N, because one can fail.
3. N+1, because two are required and one is additional.
4. Unlimited fault tolerance.

**Answer:** 3

- Option 1: N is based on the required count, which is two.
- Option 2: 2N would require two complete capacity sets for the stated unit model.
- Option 3: Correct: two units meet 70 kW and the third provides an additional unit.
- Option 4: Capacity and fault tolerance are finite and bounded.

#### DC-04-Q2 — Two redundant controllers share one unprotected power supply. What is the main weakness?

1. They use too many IP addresses.
2. Loss of the shared supply may disable both.
3. They must always execute identical logic incorrectly.
4. Controller redundancy eliminates the power dependency.

**Answer:** 2

- Option 1: Address consumption is not the stated availability issue.
- Option 2: Correct: the common dependency can defeat both controllers.
- Option 3: Identical logic does not imply incorrect logic.
- Option 4: Redundancy does not erase shared dependencies.

#### DC-04-Q3 — An N+1 unit is removed for maintenance, leaving exactly N available. What changed?

1. Demand necessarily fell.
2. The remaining units gained extra ratings.
3. The system automatically became 2N.
4. It may still meet demand but has lost its extra unit reserve.

**Answer:** 4

- Option 1: Maintenance does not reduce demand automatically.
- Option 2: Ratings are not increased by removing a unit.
- Option 3: Removing equipment cannot create a second full capacity set.
- Option 4: Correct: normal output can coexist with reduced resilience.

#### DC-04-Q4 — Which two details belong in a defensible one-unit-failure claim? Select two.

1. Specified demand and operating conditions.
2. A promise of zero downtime forever.
3. Required shared dependencies and remaining capacity.
4. Only the number of purchased devices.

**Answer:** 1, 3

- Option 1: Correct: capacity depends on these boundaries.
- Option 2: No finite test supports that unlimited promise.
- Option 3: Correct: these establish whether the surviving system can work.
- Option 4: Purchased count is not enough to establish capability.

### Sources

- [Schneider Electric University — DCCA topic overview](https://www.se.com/us/en/about-us/university/)
- [NIST SP 800-82 Rev. 3 — final OT security guide](https://csrc.nist.gov/pubs/sp/800/82/r3/final)

## DC-05 — Air cooling and the heat-removal path

Overview · Target topic stage: Foundation · 20 estimated overview study minutes · Prerequisites: DC-02

Follow heat from IT equipment to the external sink and distinguish local airflow problems from plant capacity.

### Learning objectives

- Trace the air-cooled heat-removal chain.
- Distinguish recirculation from bypass airflow.
- Use rack-inlet evidence to investigate hot spots.

### Heat must travel somewhere
IT equipment converts most of its electrical input into heat in or near the equipment. Cooling does not destroy this heat; it moves it. In an air-cooled arrangement, server fans move air across internal components. Warm exhaust returns to a cooling unit, which transfers heat into a refrigerant or water circuit. The complete chain eventually rejects heat to an external sink. Different designs use different intermediate equipment, but every stage must support the required heat flow.

A room unit's fans do not themselves prove adequate heat removal. The coil, refrigerant or water conditions, controls, and ultimate heat rejection all matter. An operating fan can circulate air that is too warm. Equally, ample central capacity cannot correct every poor distribution pattern at the rack.

### Separate supply and exhaust
Cold aisles normally face equipment air inlets; hot aisles receive exhaust. Orientation must follow the actual equipment airflow direction. Containment and blanking panels help preserve separation. **Recirculation** occurs when warm exhaust reaches an equipment inlet again. **Bypass** occurs when supplied cool air returns toward the cooling system without performing useful cooling through the intended equipment.

These mechanisms explain why a cold room average can coexist with a hot top-of-rack inlet. The sensor location is part of the measurement's meaning. A return-air value, room-wall sensor, rack inlet, and internal processor temperature describe different points in the heat path and have different acceptable limits.

### Capacity and delivery are separate checks
Plant capacity is the ability to remove heat under stated conditions. Delivery is whether the required coolant reaches the correct equipment at the correct conditions. Increasing cooling output without understanding airflow may waste energy and fail to resolve a local hot spot. Investigate the distribution and measurements first: inlet trends, workload changes, equipment airflow direction, blocked paths, and containment condition.

A steady-flow teaching model is **heat-transfer rate = mass flow rate × specific heat × temperature rise**. In symbols, Q̇ = ṁ × cₚ × ΔT, with Q̇ in kW, ṁ in kg/s, cₚ in kJ/(kg·K), and ΔT in K. It relates the rate of transported heat to coolant flow and temperature difference. For air, density and specific heat assumptions matter. A larger temperature difference by itself is not a diagnosis: it could reflect increased heat load, reduced flow, or changed entering conditions.

### Operate to documented limits
Use the installed equipment's specified environmental envelope and the site's operating criteria. Do not turn a generic temperature range into a universal setpoint. During planned changes or failures, evaluate local limits, available capacity, time response, and recovery evidence.

Document where temperatures are measured and whether readings are fresh. The required result is acceptable conditions at equipment, sustained through the defined operating states, with sufficient visibility to identify developing problems.

### Worked example

**Scenario:** Room average temperature remains 22°C, but the top server inlet rises from 23°C to 31°C after a rack rearrangement. The lower inlets remain near their earlier values.

The spatial pattern makes a local airflow or measurement change plausible. Check the sensor identity and location, airflow orientation, missing blanking panels, and exhaust recirculation using approved observations. This evidence does not yet establish that the entire plant lacks cooling capacity. Compare with the installed equipment's actual inlet limits before deciding the operational response.

### Guided practice

An inlet becomes warmer while central supply temperature is unchanged. Give two physical hypotheses and one useful confirming observation.

**Hint:** Think about how air travels from the supply to that particular inlet.

**Worked solution:** Hypotheses include warm exhaust recirculation and reduced local supply caused by an obstruction or changed distribution. Compare inlet temperatures across height and adjacent racks, inspect approved airflow indicators or arrangement records, and correlate the change with rack work and fan state. Verify the sensor first.

#### DC-05-Q1 — Fans are running but supply air is getting warmer. What is the best conclusion?

1. Cooling is adequate because airflow exists.
2. Heat-transfer and heat-rejection stages still need investigation.
3. The server cannot generate heat while fans run.
4. The sensor must be defective.

**Answer:** 2

- Option 1: Air motion alone does not establish heat removal.
- Option 2: Correct: trace the complete thermal chain and verify measurements.
- Option 3: IT continues generating heat during fan operation.
- Option 4: Sensor error is possible but not established.

#### DC-05-Q2 — What describes exhaust recirculation?

1. Cool air returns without passing through the intended IT load.
2. Heat is destroyed by a cooling coil.
3. Warm server exhaust re-enters an equipment inlet.
4. Two independent chillers operate together.

**Answer:** 3

- Option 1: That describes bypass airflow.
- Option 2: Heat is transferred, not destroyed.
- Option 3: Correct: recirculation raises entering-air temperature.
- Option 4: Chiller count does not define recirculation.

#### DC-05-Q3 — A room average is acceptable but one rack inlet is too hot. Which response best fits the evidence?

1. Ignore the inlet because averages are more reliable.
2. Treat the room average as proof of every rack condition.
3. Immediately assume a shortage of total plant capacity.
4. Verify the inlet reading and investigate local airflow and load.

**Answer:** 4

- Option 1: An average can hide a local limit violation.
- Option 2: Different locations can have different conditions.
- Option 3: A local problem does not establish global capacity shortage.
- Option 4: Correct: verify and localize before concluding.

#### DC-05-Q4 — Which two actions in a paper design help preserve intended supply/exhaust separation? Select two.

1. Align rack layouts with actual equipment airflow direction.
2. Assume all equipment exhausts in the same direction.
3. Account for blanking and containment integrity.
4. Use only one room sensor regardless of layout.

**Answer:** 1, 3

- Option 1: Correct: supply must reach actual inlets.
- Option 2: Equipment direction needs verification.
- Option 3: Correct: gaps can create unwanted mixing paths.
- Option 4: One point cannot characterize every rack condition.

### Sources

- [Schneider Electric University — DCCA topic overview](https://www.se.com/us/en/about-us/university/)
- [LBNL Center of Expertise — data center energy toolkit](https://datacenters.lbl.gov/)

## DC-06 — Liquid cooling and heat balance

Overview · Target topic stage: Foundation · 20 estimated overview study minutes · Prerequisites: DC-05

Understand coolant loops, CDU boundaries, flow, and the remaining air-cooling load.

### Learning objectives

- Explain the heat path through a liquid-to-liquid CDU.
- Calculate a simplified liquid heat balance.
- Recognize why liquid cooling retains electrical, controls, and heat-rejection dependencies.

### Move heat from the component
Direct-to-chip cooling uses cold plates to transfer heat from selected components into a circulating fluid. It does not necessarily capture every watt produced by a server. Memory, power electronics, storage, and other components may still require air cooling depending on the product. Always establish the actual thermal capture fraction and residual load for the installed design.

A coolant distribution unit, or CDU, can provide circulation, heat exchange, and controlled coolant conditions. In a common liquid-to-liquid arrangement, the technology cooling loop serving IT equipment exchanges heat with a facility-water loop through a heat exchanger. The fluids can remain hydraulically separate while heat crosses between them. This helps manage different fluid-quality, pressure, and material-compatibility requirements. Not every liquid-cooling design uses this exact arrangement.

A liquid-to-air CDU instead rejects heat into air. That changes the heat path, but the facility must still remove the rejected heat. Installing a CDU is not equivalent to adding unlimited heat-rejection capacity.

### Read the heat balance
For a steady, single-phase liquid stream, a useful approximation is **Q = ṁ × cp × ΔT**. Q is thermal power in kW, ṁ is mass flow in kg/s, cp is specific heat in kJ/(kg·K), and ΔT is the return-minus-supply temperature difference in kelvin or degrees Celsius. For a water-like teaching fluid, cp can be approximated as 4.18 kJ/(kg·K). Actual coolant properties depend on composition and temperature.

At unchanged heat load, lower flow produces a larger temperature rise in this simplified model. This relationship does not guarantee that component temperatures remain acceptable. The cold plate, flow distribution, supply temperature, fouling, and operating limits still matter. Nor can the equation diagnose a problem from temperature difference alone; measurements and assumptions must be checked together.

### Dependencies move rather than disappear
Liquid cooling depends on pump power, working controls, acceptable fluid quality, available heat rejection, and suitable connections and materials. Monitor the quantities needed to distinguish failure modes: supply and return temperatures, flow or differential pressure as appropriate, leak indications, pump state, and component temperatures. A pump-running command is not proof of effective flow.

Condensation becomes possible when a surface is below the surrounding air's dew point. The permitted supply conditions must follow the equipment and system design. More aggressive cooling is not automatically safer.

This foundation lesson develops analytical understanding. Fluid selection, pressure changes, connection work, leak response, and component service require the product-specific procedures and responsible engineering authority.

### Worked example

**Example:** In a simplified steady water loop, mass flow is 2 kg/s, cp is 4.18 kJ/(kg·K), and return temperature is 10°C above supply.

Q = 2 × 4.18 × 10 = **83.6 kW** transported by that measured stream. This is a calculated estimate under stated assumptions, not a measured CDU performance certification. If a rack consumes 100 kW and 80% of its heat is captured by liquid in the specified design, approximately **20 kW** remains for other heat-removal paths.

### Guided practice

Using cp = 4.18 kJ/(kg·K), a loop transports 41.8 kW with a 5°C rise. What mass flow does the simplified model require? What does a pump-running bit fail to prove?

**Hint:** Rearrange Q = ṁ × cp × ΔT. Distinguish commanded operation from a physical result.

**Worked solution:** ṁ = 41.8 / (4.18 × 5) = 2 kg/s. A pump-running bit does not prove sufficient flow through every required cold plate or that heat rejection is available; verify the relevant physical measurements and distribution.

#### DC-06-Q1 — For water-like cp = 4.18 kJ/(kg·K), 1 kg/s flow and a 10°C rise transport approximately what heat rate?

1. 4.18 kW
2. 10 kWh
3. 41.8 kW
4. 418 kVA

**Answer:** 3

- Option 1: This omits the temperature rise.
- Option 2: The calculation gives a heat rate, not energy.
- Option 3: Correct: 1 × 4.18 × 10 = 41.8 kW.
- Option 4: kVA is an electrical apparent-power unit and the arithmetic is incorrect.

#### DC-06-Q2 — In a liquid-to-liquid CDU with a heat exchanger, what can cross between hydraulically isolated loops?

1. Heat, without requiring the two fluids to mix.
2. All dissolved contaminants by design.
3. Electrical application traffic.
4. Unlimited cooling capacity independent of the facility.

**Answer:** 1

- Option 1: Correct: the heat exchanger transfers energy across the separation.
- Option 2: Fluid separation helps avoid mixing; contamination transfer is not the intended function.
- Option 3: This is a thermal boundary, not an application network.
- Option 4: The facility side remains capacity-limited.

#### DC-06-Q3 — A specified design captures 75% of a 120 kW rack load in liquid. Approximately what remains outside that liquid capture?

1. 0 kW because liquid is installed.
2. 30 kW.
3. 90 kW.
4. 120 kWh.

**Answer:** 2

- Option 1: Partial capture leaves a residual load.
- Option 2: Correct: 120 × 0.25 = 30 kW.
- Option 3: 90 kW is the captured portion.
- Option 4: kWh is energy, not heat rate.

#### DC-06-Q4 — Which two observations help assess whether a liquid loop is performing its function? Select two.

1. Only the controller login page responding.
2. Relevant flow and supply/return temperature evidence.
3. Acceptable cooled-component temperatures.
4. Only the pump-start command being true.

**Answer:** 2, 3

- Option 1: Reachability does not prove heat transport.
- Option 2: Correct: these support a bounded heat-transport assessment.
- Option 3: Correct: the ultimate cooling result must be acceptable.
- Option 4: A command does not prove physical flow.

### Sources

- [Vertiv — Understanding coolant distribution units](https://www.vertiv.com/en-us/insights/articles/educational-articles/understanding-coolant-distribution-units-cdus-for-liquid-cooling/)
- [Schneider Electric University — DCCA topic overview](https://www.se.com/us/en/about-us/university/)

## DC-07 — Rack capacity is a set of constraints

Overview · Target topic stage: Foundation · 20 estimated overview study minutes · Prerequisites: DC-04, DC-05

Assess space, power, cooling, connectivity, and maintenance access together.

### Learning objectives

- Distinguish free rack space from usable deployment capacity.
- Calculate surviving-path demand for a simplified dual-feed rack.
- Specify acceptance evidence for a proposed rack addition.

### An empty slot is not a capacity approval
Rack units describe vertical mounting space. They do not establish electrical headroom, heat-removal ability, weight support, cable capacity, service access, or network performance. A rack is deployable only when the proposed equipment fits every relevant constraint in its intended operating states.

Start with the equipment bill of materials and installation requirements. Record expected and design power, supported power-supply modes, inlet airflow or coolant needs, weight, dimensions, mounting compatibility, cable interfaces, and service clearances. Validate structural and site-loading interfaces with the responsible owner; this programme does not assume building-structure design responsibility.

### Count the contingency load
In a simplified dual-feed rack, power supplies may share normal demand across A and B. If either path must support the full rack after loss of the other, each surviving path needs adequate permitted capacity for that demand. Two 10 kW paths do not automatically provide a resilient 20 kW rack. The answer depends on feed arrangement, load behaviour, and the required failure state.

Also trace upstream constraints. A rack branch may have headroom while a shared upstream element is already at its limit. Conversely, a large upstream supply does not increase a branch's permitted loading. Real installations require checks of voltage, phase loading, current limits, protective devices, connector ratings, and applicable rules; do not infer approval from a single kW sum.

### Coordinate heat and connectivity
Adding 4 kW of IT demand adds approximately that order of heat to be removed, with the exact accounting boundary stated. Central cooling capacity, local delivery, and the rack's equipment limits must all support it. For liquid-cooled equipment, reserve suitable flow, pressure, coolant quality, connection arrangements, and residual air-cooling capacity.

Connectivity introduces its own limits: available ports, optics compatibility, cable reach, bandwidth under failure, management access, and storage requirements. A powered server with nowhere suitable to send traffic does not satisfy deployment readiness. Cable routing should preserve bend-radius requirements, airflow, identification, and maintainability.

### Plan acceptance and later removal
A deployment record should show the before-and-after allocation, required contingency state, approved owner decisions, and acceptance observations. Establish correct asset identity, A/B connections, management access, health telemetry, and representative service performance. Retain a rollback and removal plan that restores allocation records as well as hardware state.

This habit turns capacity management into lifecycle engineering. Reserved capacity, installed capacity, measured demand, and usable spare capacity remain separate values, and changes are reconciled with the effective installation.

### Worked example

**Example:** A rack draws 8 kW. For this paper model, each independent A/B path has a documented usable limit of 12 kW, and either path must support the full rack. An addition raises demand to 13 kW.

Normal equal sharing would be 6.5 kW per path, but loss of one path requires 13 kW on the survivor. The addition therefore fails the stated contingency criterion even though both normal values are below 12 kW. Cooling, connector, phase, and upstream checks would still be required even if this arithmetic passed.

### Guided practice

A 7 kW rack has two independent paths each permitted to supply 10 kW in the required failure state. A planned addition is 2 kW. What is the surviving-path demand, and what other two capacity areas still need evidence?

**Hint:** The survivor supplies the total rack load in this model.

**Worked solution:** The surviving-path demand is 9 kW, within the stated 10 kW arithmetic limit. Still verify local and central cooling, connectivity, physical fit/service access, and detailed electrical constraints. Passing one calculation does not approve the deployment.

#### DC-07-Q1 — A rack has 12 empty rack units. What can be concluded?

1. It can accept any 12U equipment set.
2. Only vertical space availability has been described.
3. It has 12 kW spare power.
4. Cooling capacity must be sufficient.

**Answer:** 2

- Option 1: Other physical, electrical, thermal, and network constraints remain.
- Option 2: Correct: U is a space measure.
- Option 3: Rack units are not power units.
- Option 4: Space does not determine heat-removal capacity.

#### DC-07-Q2 — A 14 kW rack normally shares load equally across two paths, each with a 10 kW usable limit. Either path must support full demand on failure. What is the result?

1. It passes because each normally carries 7 kW.
2. It passes because total path ratings are 20 kW.
3. The surviving path would need 14 kW and exceeds its limit.
4. Only rack height matters.

**Answer:** 3

- Option 1: Normal loading does not test the required failure condition.
- Option 2: Adding redundant path ratings can overstate resilient capacity.
- Option 3: Correct: compare the full failure-state demand with one remaining path.
- Option 4: Electrical and thermal limits remain relevant.

#### DC-07-Q3 — Why inspect both branch and upstream limits?

1. Either can constrain the proposed deployment.
2. The larger rating cancels the smaller one.
3. They measure the same physical point.
4. Upstream constraints stop mattering after installation.

**Answer:** 1

- Option 1: Correct: every required part of the delivery path must support its load.
- Option 2: Limits are not cancelled by another component rating.
- Option 3: They describe different boundaries.
- Option 4: Changes in demand can overload upstream dependencies.

#### DC-07-Q4 — Which two evidence items strengthen acceptance of a rack change? Select two.

1. A photo showing unused space.
2. Verified feed mapping and post-change health observations.
3. Updated capacity allocation and tested representative service behaviour.
4. An assumption that every supply shares load equally.

**Answer:** 2, 3

- Option 1: A photo alone does not establish operational readiness.
- Option 2: Correct: intended connections and actual health both matter.
- Option 3: Correct: records and delivered function need reconciliation.
- Option 4: Supply behaviour must match the actual design.

### Sources

- [Schneider Electric University — DCCA topic overview](https://www.se.com/us/en/about-us/university/)
- [LBNL Center of Expertise — data center energy toolkit](https://datacenters.lbl.gov/)

## DC-08 — Cabling, optics, and evidence of a good link

Overview · Target topic stage: Foundation · 20 estimated overview study minutes · Prerequisites: DC-01

Match media to requirements and distinguish continuity, standards compliance, and delivered service.

### Learning objectives

- Select media using distance, interfaces, environment, and power requirements.
- Distinguish cable verification, qualification, and certification.
- Separate optical loss evidence from network service evidence.

### Choose for the actual interface
Cabling carries signals within physical and electrical limits. Copper twisted-pair systems are useful where the supported Ethernet interface, channel length, environment, and optional power delivery fit the application. Fiber carries optical signals and avoids an electrical signal path through the fiber itself. It remains dependent on suitable transceivers, connector condition, polarity, reach, and the complete optical budget.

Select the interface and media together. Connector shape alone is not compatibility. For optical links, check the required fiber type, wavelength, transmitter and receiver specifications, lane arrangement, supported reach, and vendor interoperability requirements. For copper, match the cabling category or class and the complete channel to the required application and installation environment. Generic distance rules cannot replace the actual interface specification.

### Installation quality affects operation
Bend radius, pulling tension, contamination, poor termination, damaged patch cords, and incorrect labeling can create faults. Cable management must preserve service access and airflow while keeping routes identifiable. Separate physical paths can improve resilience only when their shared exposures are understood; two differently coloured patch leads in one vulnerable route are not independent routes.

Cabling work has a lifecycle. Record endpoints, ports, route identifiers, media type, length information, and test results. Update these records after changes. An undocumented patch can turn a straightforward recovery into an extended tracing exercise or cause work on the wrong circuit.

### Match the test to the claim
Verification checks basic properties such as wire mapping or continuity. Qualification asks whether a link can support a particular network application. Certification compares an installed cabling link against the relevant standard's test limits using the appropriate test method and configuration. Passing a basic continuity test does not establish category performance.

For fiber, insertion-loss measurement evaluates end-to-end optical loss under a defined method. An optical time-domain reflectometer can help locate events and characterize a path. These tests provide different evidence and are not universally interchangeable. An acceptable optical path still needs compatible transceivers and correct network configuration.

### Carry acceptance up the stack
A link-up indicator establishes a limited physical/network state. Error counters, negotiated parameters, traffic tests, and an application transaction answer different questions. A good acceptance record states the cable test limit and configuration, includes identifiable results, verifies the intended network settings, and demonstrates the required service under representative conditions.

This lesson concerns planning and interpreting evidence. Fiber inspection and field testing require appropriate equipment and trained handling; never look into a connector to decide whether it is active.

### Worked example

**Scenario:** A new link comes up but errors increase under load. Its handover record contains only a continuity pass.

The record does not establish compliance with the required cabling performance. Review the specified channel and interface, obtain the appropriate certification or optical test evidence, and inspect relevant transceiver and port counters. A replacement cable resolving symptoms is useful evidence, but preserve the original observations and root-cause findings rather than declaring every layer proven by one successful ping.

### Guided practice

A contractor supplies a “wiremap pass” for a link whose contract requires standards-based cabling certification. What evidence is missing, and what additional test proves the intended application is usable?

**Hint:** Physical cabling compliance and application delivery are separate acceptance claims.

**Worked solution:** Missing evidence includes the certification results under the specified category/class, test limit, and link/channel configuration, with cable identity and instrument details. Then validate the intended network settings and a representative application transaction; neither claim alone proves the other.

#### DC-08-Q1 — A basic wiremap test reports the expected pin mapping and no opens or shorts. What remains unproven?

1. Continuity of the tested conductors during this test.
2. The pin-to-pin mapping reported by this test.
3. Compliance with all required category/class performance limits.
4. The absence of an open circuit detected by this test.

**Answer:** 3

- Option 1: The stated wiremap result provides this bounded continuity evidence.
- Option 2: The reported pin mapping is precisely what this test checks.
- Option 3: Correct: performance certification requires additional measurements, a suitable tester, and the applicable limits.
- Option 4: The stated test result reports no detected opens; it does not establish long-term reliability or full performance.

#### DC-08-Q2 — Two transceivers use physically matching connectors. What follows?

1. They are automatically compatible.
2. Their speed, wavelength, fiber, and other interface requirements still need checking.
3. They can always use any fiber type.
4. Optical loss is irrelevant.

**Answer:** 2

- Option 1: Shape alone does not establish optical compatibility.
- Option 2: Correct: the whole interface specification matters.
- Option 3: Fiber requirements vary by interface.
- Option 4: Excessive loss can prevent a usable link.

#### DC-08-Q3 — A cable is certified and the switch port is up. Which best verifies the required file service?

1. A photograph of the patch panel.
2. Only the cable jacket colour.
3. Repeating the same continuity test.
4. An authorized representative file-service transaction with expected results.

**Answer:** 4

- Option 1: A photo aids records but does not execute the service.
- Option 2: Colour does not establish function.
- Option 3: Continuity does not exercise application dependencies.
- Option 4: Correct: it tests the intended service at a higher layer.

#### DC-08-Q4 — Which two records help assess route resilience? Select two.

1. Actual cable routes and common physical exposures.
2. Only different cable colours.
3. Shared termination and upstream dependencies.
4. Only the count of patch leads.

**Answer:** 1, 3

- Option 1: Correct: common exposures can defeat both paths.
- Option 2: Colour does not establish separation.
- Option 3: Correct: separation must continue through relevant dependencies.
- Option 4: Count does not identify a shared failure point.

### Sources

- [Fluke Networks — cabling certification](https://www.flukenetworks.com/expertise/learn-about/cabling-certification)
- [Fluke Networks — fiber testing](https://www.flukenetworks.com/expertise/learn-about/fiber-testing)
- [Schneider Electric University — DCCA topic overview](https://www.se.com/us/en/about-us/university/)

## DC-09 — Fire protection and life-safety interfaces

Overview · Target topic stage: Foundation · 20 estimated overview study minutes · Prerequisites: DC-01

Understand detection, notification, suppression, and their interfaces without assuming design or operating authority.

### Learning objectives

- Distinguish fire detection, alarm notification, and suppression functions.
- Recognize why a BMS indication is not the fire-protection system itself.
- Describe controlled testing and restoration evidence at system interfaces.

### Distinct functions and owners
Fire detection identifies conditions that may indicate a fire. Notification communicates alarms and required response. Suppression or extinguishing systems act according to their specific approved design. These functions may interact with doors, ventilation, equipment shutdown, and other building systems through defined interfaces. They are related functions, but a status message on a dashboard is not equivalent to a functioning detection or suppression system.

The approved fire strategy, applicable requirements, and responsible specialists define what equipment must do. This course teaches interface awareness and operational reasoning. It does not confer authority to design fire protection, alter release logic, isolate a detector, defeat an interlock, or operate suppression controls. Civil, structural, and architectural engineering remain outside this programme's owned scope.

### Follow the cause-and-effect relationship
A cause-and-effect matrix records which defined conditions produce which approved outputs. For example, an alarm may need to be reported to designated responders and to a supervisory system; other actions depend on the actual design. Never infer the required sequence from a generic data-center diagram or assume that every facility uses the same suppression agent or release logic.

Monitoring interfaces have direction and authority. A BMS may receive status while the dedicated system retains the protective function. Determine whether a link is monitoring-only, whether commands exist, how communication loss is indicated, and which record is authoritative for the safety function. Avoid creating a hidden dependency on a general-purpose dashboard for a function intended to be independent.

### Manage abnormal and test states
Alarm, fault, supervisory, disabled, and test indications can have different meanings in a particular system. Learn the vendor and site definitions instead of treating every non-green state as identical. A disabled input is not restored simply because a screen no longer displays its earlier alarm. The physical function and configuration must match the approved state.

Testing requires the responsible specialists, approved scope, communications, and a controlled method that accounts for downstream consequences. Your analytical task is to verify that the test plan identifies expected indications, recipients, timestamps, interfaces, restoration checks, and evidence. Do not invent field test steps or activate equipment through the learning app.

### Protect people and preserve evidence
During an actual emergency, follow the site's life-safety and evacuation procedures. During a paper review, identify dependencies such as power, communications, and status monitoring, then ask how their failure is detected. Cybersecurity changes to connected monitoring equipment must preserve the required protective functions and response arrangements.

Acceptance concerns the specified end-to-end behaviour and restored operating state, not just successful message transport or the disappearance of an alarm banner.

### Worked example

**Scenario:** A BMS integration test receives “fire alarm” from a dedicated panel. The dashboard and historian show the event correctly.

That is evidence about the tested monitoring interface. It does not establish detector performance, suppression readiness, all notification paths, or the complete approved cause-and-effect sequence. The handover must identify exactly what was tested and retain the responsible specialists' separate acceptance records. After the authorized test, verify the integration's normal status and removal of any approved temporary test condition.

### Guided practice

A change report says “fire system passed because the BMS received one alarm.” Rewrite the claim accurately and name two additional evidence categories that belong to the responsible fire-system acceptance.

**Hint:** Bound the demonstrated result to the path actually tested.

**Worked solution:** Accurate claim: “The specified alarm indication reached the BMS during the documented integration test.” Separate acceptance evidence may cover detector function, required notification, approved cause-and-effect outputs, suppression-system readiness, and restoration. These require the responsible specialist’s procedures and records.

#### DC-09-Q1 — A BMS displays a fire alarm from a dedicated panel. What is established by that test alone?

1. All suppression equipment will work.
2. The tested alarm monitoring path delivered the indication.
3. Every detector is correctly installed.
4. The whole fire strategy is compliant.

**Answer:** 2

- Option 1: Suppression performance needs separate evidence.
- Option 2: Correct: keep the claim bounded to the demonstrated interface.
- Option 3: One integration event does not inspect every detector.
- Option 4: Compliance cannot be inferred from one message.

#### DC-09-Q2 — Who defines the actual required fire-system cause-and-effect sequence?

1. The learning app’s generic diagram.
2. Whoever has BMS administrator access.
3. The approved design and responsible fire-protection specialists under applicable requirements.
4. The person who most recently acknowledged an alarm.

**Answer:** 3

- Option 1: A teaching diagram is not a site design.
- Option 2: Technical access does not confer design authority.
- Option 3: Correct: use the actual approved requirements and accountable owners.
- Option 4: Acknowledgement does not grant engineering authority.

#### DC-09-Q3 — After an authorized interface test, what should restoration establish?

1. Only that the dashboard is closed.
2. That all event records are erased.
3. That every future emergency has been prevented.
4. The specified normal state and removal of approved temporary test conditions are verified.

**Answer:** 4

- Option 1: Closing a screen changes no physical or configuration state.
- Option 2: Event records support traceability.
- Option 3: No test provides that guarantee.
- Option 4: Correct: restoration must address the actual controlled state.

#### DC-09-Q4 — Which two items belong in an interface test plan? Select two.

1. Expected indications and designated recipients.
2. Unapproved suppression activation steps.
3. Defined restoration checks and retained evidence.
4. Permission to ignore the site’s emergency procedure.

**Answer:** 1, 3

- Option 1: Correct: define the intended communication and response boundary.
- Option 2: Tests require approved methods and responsible specialists.
- Option 3: Correct: the test must leave the intended state verified.
- Option 4: Site emergency procedures remain applicable.

### Sources

- [NIST SP 800-53 Rev. 5 — physical and environmental protection controls](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final)
- [NIST SP 800-82 Rev. 3 — final OT security guide](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [Schneider Electric University — DCCA topic overview](https://www.se.com/us/en/about-us/university/)

## DC-10 — Physical access, accountability, and recovery

Overview · Target topic stage: Foundation · 20 estimated overview study minutes · Prerequisites: DC-01, DC-09

Treat access control as a system of identity, authorization, physical behaviour, monitoring, and lifecycle operations.

### Learning objectives

- Distinguish credential authentication from authorized physical presence.
- Trace access-control dependencies and emergency interfaces.
- Specify evidence for access changes and revocation.

### The objective is controlled physical access
Physical security protects people, equipment, information, and required operations. A badge reader is one component. The complete system includes identity verification, permission approval, credentials, door hardware, controllers, communications, monitoring, response, and records. A valid credential presentation does not prove that the person using it is the rightful holder or that only one person entered.

Define access by role, location, time, purpose, and required supervision. A visitor, equipment vendor, facilities technician, and network engineer may need different zones and conditions. Least privilege applies to doors as well as accounts: access should be sufficient for the approved task and removed when no longer required. Physical access and remote administrative access are separate permissions; neither should automatically grant the other.

### Authentication is one event in a chain
A reader supplies credential information to a decision process. The controller checks available rules and causes the permitted door action. Door-position and other sensors can provide feedback. The monitoring system records events and supports response. Examine how the system behaves when its server, network, power, or time source is unavailable. Some controllers retain local decisions or cached permissions; the actual product configuration determines the behaviour.

Door lock behaviour under power loss and emergency conditions must follow the approved safety and security design. Terms such as fail-safe and fail-secure describe a lock's behaviour for a defined failure, but they do not alone establish complete egress behaviour. Do not impose a universal rule across all doors or modify hardware based on a lesson.

### Shared credentials destroy useful evidence
A shared badge weakens attribution: a log can show use of the credential without identifying the actual person. Tailgating bypasses the one-credential, one-person assumption. Stolen credentials, contractor turnover, propped doors, and incorrect zone permissions create different failure modes and require different detection and response arrangements.

Investigating an event means correlating authorized records: credential events, door state, maintenance work, relevant video where permitted, and personnel information. A timestamp mismatch can misorder the sequence. Absence of an event can reflect a collection failure rather than absence of physical entry.

### Operate the lifecycle
For an access change, retain the request, approval, affected identity, zones, validity interval, and verification. For revocation, establish that the required controllers received and enforced the change, including the defined handling of offline devices. Periodically reconcile current permissions with actual roles.

Recovery after a controller or server failure should restore known-good configuration, correct identities and permissions, synchronized time, event collection, and tested door behaviour under the approved procedure. These are operational results to verify, not assumptions implied by a successful login.

### Worked example

**Scenario:** A contractor's central account is disabled, but one door controller was offline during the change and retained cached permissions.

The central status alone is insufficient evidence of effective revocation at that door. Identify the controller's documented offline behaviour and the site's approved compensating response. After communications recover, confirm the update is applied and verify the required denial through an authorized test. Preserve the change and event records with consistent timestamps.

### Guided practice

A log shows one valid badge event, but an authorized observation shows two people entering. What assumption failed, and what should the record avoid claiming?

**Hint:** Separate credential use from the number and identity of people crossing the door.

**Worked solution:** The assumption that one successful credential event equals one authorized person entering failed; tailgating or an approved escorted arrangement must be investigated. The event record alone must not claim that both people were independently authenticated or authorized.

#### DC-10-Q1 — A valid badge opens a door. What is not established by that event alone?

1. The credential was accepted under the controller’s rules.
2. A credential event occurred.
3. The actual bearer was its rightful owner and every entrant was authorized.
4. The event may support an investigation.

**Answer:** 3

- Option 1: That is the bounded authentication/authorization decision observed.
- Option 2: The log can establish the recorded credential event.
- Option 3: Correct: bearer identity and additional entrants need other controls or evidence.
- Option 4: The event remains useful when interpreted with its limits.

#### DC-10-Q2 — A central account is disabled while a controller is offline. What should be verified?

1. Whether cached access remains effective and how the revocation reaches that controller.
2. Only the central dashboard colour.
3. That every offline controller must deny all access by universal design.
4. That network recovery alone proves every permission is correct.

**Answer:** 1

- Option 1: Correct: effective state can lag the central desired state.
- Option 2: Presentation is not enforcement evidence.
- Option 3: Offline behaviour is product- and configuration-specific.
- Option 4: Recovery needs permission and behaviour verification.

#### DC-10-Q3 — How should door behaviour during power loss or an emergency be determined?

1. Always lock every door regardless of egress requirements.
2. Always unlock every door regardless of the site design.
3. Let a generic quiz answer override the approved design.
4. Use the approved life-safety/security design and actual hardware behaviour.

**Answer:** 4

- Option 1: A universal locking rule can conflict with required egress.
- Option 2: A universal unlocking rule ignores defined security and hardware requirements.
- Option 3: A learning exercise does not define field authority.
- Option 4: Correct: assess the complete approved arrangement.

#### DC-10-Q4 — Which two items support accountable access changes? Select two.

1. A shared badge issued to the entire team.
2. An approved request naming identity, zones, and validity.
3. Verification that affected enforcement points apply the intended change.
4. Removing event history after every change.

**Answer:** 2, 3

- Option 1: Shared credentials weaken individual attribution.
- Option 2: Correct: authorization should be explicit and bounded.
- Option 3: Correct: desired configuration must match effective enforcement.
- Option 4: History supports audit, diagnosis, and recovery.

### Sources

- [NIST SP 800-53 Rev. 5 — physical and environmental protection controls](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final)
- [NIST SP 800-82 Rev. 3 — final OT security guide](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [Schneider Electric University — DCCA topic overview](https://www.se.com/us/en/about-us/university/)
