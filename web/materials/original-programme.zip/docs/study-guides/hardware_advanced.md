# Hardware Advanced — overview notes

These are short introductory overviews, including overviews of advanced topics. They are introductory companion notes. The new detailed course books are in docs/academy, with their own source mappings and scope limits. Answers follow each question. Practical assignment briefs require further instruction and execution.

## L-HW-01 — Engineer a compatible server and accelerator configuration

Overview · Target topic stage: Applied · 55 estimated overview study minutes · Prerequisites: DC-07, DC-14

Select conventional and accelerated nodes from measurable requirements, supported combinations and evidence of installed behaviour.

### Learning objectives

- Trace a hardware selection to measurable capacity and recovery requirements.
- Evaluate NUMA, memory population and PCIe bottlenecks.
- Check accelerator, NIC, HBA and firmware compatibility as a system.
- Distinguish storage capacity, endurance and power-loss protection.
- Assess facility limits and common dependencies in a hardware proposal.
- Justify acceptance or rejection using a versioned compatibility matrix.

A hardware design begins with the service it must support. “Buy the fastest server” is not a requirement. A historian node might need to ingest a stated number of values per second, retain a specified interval, recover within a defined time, and continue collecting during an agreed maintenance state. An accelerator node may require a supported GPU population, sufficient host memory, particular network interfaces and a cooling envelope. Write each requirement with units, operating conditions and a test. Separate mandatory limits from preferences so an inexpensive proposal cannot quietly exchange reliability for performance.

**Map the path through the machine.** A CPU executes instructions and controls access to memory and connected devices. More cores help only if the software and data path can use them. Memory capacity establishes what fits; bandwidth and latency influence how quickly the workload proceeds. ECC provides specified error detection and correction capabilities; it does not make every memory fault harmless. Record supported DIMM types, quantities, slot order and speed rules from the actual server documentation. An unsupported mix may fail to boot or operate below the proposed configuration.

In a NUMA system, processors have differing access paths to memory and devices. A process using memory or a NIC attached to another processor may traverse an interconnect. That can explain inconsistent latency without a failed component. Draw which CPU owns each memory bank and PCIe slot, then compare intended placement with the operating system's discovered topology. NUMA-aware placement is an optimisation to test, not permission to ignore the support matrix or reserve all resources for one workload.

PCIe is another shared path. A mechanically long slot does not prove that all its possible lanes are electrically connected. A card can negotiate a lower generation or width because of slot wiring, risers, firmware or a fault. Bandwidth estimates are useful upper bounds: eight lanes provide roughly half the encoded link capacity of sixteen equivalent lanes. Actual application throughput is lower and depends on transfers, contention and software. Check supported bifurcation, occupied slots, required processors and the effect of installing a second card. A proposed GPU can displace the only supported HBA slot and break the storage design.

**Treat accelerated hardware as a supported assembly.** GPU, CPU, memory, NIC or DPU, riser, cable, power distribution inside the chassis, firmware and drivers form a compatibility chain. Matching connectors or fitting the chassis is insufficient. Record each part number and applicable revision, supported operating mode, driver/firmware relationship, power requirement and replacement method. Compare conventional and accelerated nodes explicitly; a successful conventional-server test cannot establish the accelerated node's thermal behaviour or interconnect performance. This programme covers their physical deployment and reliable operation without adding an independent workload-orchestration specialism.

Storage selection has several independent dimensions. Raw capacity is the sum of device ratings; usable capacity reflects protection, formatting and reserves. Endurance concerns writes over a stated life under stated conditions. Controller or drive power-loss protection concerns what happens to acknowledged writes when power disappears. Neither a large cache nor a high endurance rating proves the other properties. For a first approximation, daily net new retained data multiplied by retention duration estimates logical capacity in an append-only retention model. Total host writes multiplied by physical write amplification estimates media writes under the stated workload assumptions; repeated overwrites need not increase retained capacity. Use measured workloads and the vendor's rating conventions before acceptance.

Facilities constraints belong in the decision. Obtain approved rack weight, rail compatibility, service clearance, airflow direction, outlet and feed assignments, power envelope and cooling interface requirements. Rated PSU capacity is not measured IT demand. Two PSUs connected to one failed upstream path do not provide the intended independence. An accelerated-node design that exceeds the agreed rack envelope must be held for coordinated redesign; a hardware engineer cannot approve changes to hazardous power or coolant systems merely to make the purchase fit.

Build a compatibility matrix with one row per requirement or interface: proposed configuration, source and revision, evidence, limitation and disposition. Include support life, spare availability, restore-media access and replacement lead time because recovery depends on them. Reject a plausible but unsupported proposal in the review, describe the correction and reassess it against the same requirements. After delivery, reconcile physical labels, BMC inventory and OS discovery with the accepted BOM. Acceptance is a reasoned conclusion about the installed system under tested conditions, not a photograph of unopened boxes or a supplier's generic performance claim.

### Worked example

**Decision exercise — a node that fits but cannot deliver.** A synthetic requirement calls for 512 GB RAM, two supported GPUs, a storage HBA, at least 20 GB/s host-to-device transfer in a defined test, and maximum measured input of 1.8 kW. Proposal A has 512 GB RAM and enough chassis space, but its selected riser runs the required GPU slot at PCIe 4.0 ×8. The encoded one-direction upper bound is approximately 15.75 GB/s before transaction overhead; this path cannot support the stated 20 GB/s test. Its second GPU also occupies the HBA's only supported slot. Hold A even if the sales quotation calls it an AI server.

Proposal B uses a vendor-supported riser and GPU/HBA population with a ×16 link on the required path. This removes the demonstrated incompatibilities but does not automatically establish throughput. Installed evidence shows 512 GB in approved slots, both GPUs and the HBA at expected widths, 22 GB/s in the specified transfer test and 1.62 kW maximum during the agreed representative load. Accept B for those criteria if the remaining thermal, recovery and support tests pass. Preserve the raw test conditions; the result is not a guarantee for every GPU workload.

### Guided practice

A 3.84 TB SSD is rated at one drive write per day over the relevant warranty conditions. The proposed workload produces 5 TB of host writes daily. What decision and additional evidence are appropriate?

**Hint:** Calculate the daily host-write demand relative to rated capacity, then distinguish a rating comparison from a final endurance prediction.

**Worked solution:** 5 / 3.84 is about 1.30 drive writes per day. Hold the claim that the device meets a one-DWPD requirement under those conditions. Check the exact model rating, warranty workload definition, measured write volume, amplification and required life; assess an appropriately rated device or workload change. Retest after correction and document capacity, performance and power-loss protection separately.

#### L-HW-01-Q1 — A proposal promises “high performance” but the service requires a recoverable historian. Which missing item most directly prevents an engineering acceptance test?

1. A precise workload, retention and restoration requirement with units
2. A specification for rack colour and exterior dimensions only
3. A larger marketing core count
4. A support contract that does not state the service restoration criterion

**Answer:** 1

- Option 1: A measurable requirement defines what the installed system must demonstrate.
- Option 2: Exterior dimensions help physical integration but do not define the required workload or restoration result.
- Option 3: Core count alone does not express workload or restoration needs.
- Option 4: Support arrangements matter, but they do not define the historian workload and recovery acceptance test.

#### L-HW-01-Q2 — A PCIe 4.0 ×8 path has an encoded upper bound near 15.75 GB/s in one direction. A required transfer test demands 20 GB/s through that path. What follows?

1. It is adequate because all overhead improves throughput.
2. It cannot meet that requirement through this path even before overhead.
3. It will pass if more RAM is installed elsewhere.
4. The connector length guarantees ×16 operation.

**Answer:** 2

- Option 1: Protocol overhead consumes capacity; it does not create it.
- Option 2: The upper bound is already below the requirement, so the proposal must change.
- Option 3: Additional memory does not increase this path’s lane bandwidth.
- Option 4: Mechanical fit does not establish the negotiated lane width.

#### L-HW-01-Q3 — Two GPUs and an HBA each appear on a server’s approved options list. What must still be established? Select all that apply.

1. The combined population, riser and slot arrangement are supported.
2. The selected firmware and driver combination is supported.
3. Individual approval guarantees every simultaneous combination.
4. A matching physical connector removes the need for part-number checks.

**Answer:** 1, 2

- Option 1: Shared lanes, power and placement can constrain combinations.
- Option 2: System compatibility includes the software and firmware supporting the hardware.
- Option 3: Independent options can have mutually exclusive configurations.
- Option 4: Connector fit is only one part of compatibility.

#### L-HW-01-Q4 — A designer adds battery-backed controller cache and claims this doubles SSD endurance. What is the best assessment?

1. Accept, because protection against power loss doubles media life.
2. Reject the inference; write endurance and cache power-loss protection are distinct properties.
3. Accept if both components have the same supplier.
4. Reject all caching regardless of supported design.

**Answer:** 2

- Option 1: Protection of acknowledged writes does not imply a particular endurance increase.
- Option 2: Evaluate endurance against workload and rating, and protection against the supported failure behaviour.
- Option 3: Brand identity cannot establish an endurance multiplier.
- Option 4: Supported caching can be useful; the unsupported claim is the issue.

#### L-HW-01-Q5 — A dual-PSU node is connected to two outlets on the same upstream feed. What does this prove?

1. Independent upstream power has been provided.
2. PSU capacity equals the node’s measured demand.
3. The connections still share an upstream failure dependency.
4. Cooling capacity can be inferred from the outlet count.

**Answer:** 3

- Option 1: Two outlets do not establish independent failure paths.
- Option 2: Capacity and measured consumption are different quantities.
- Option 3: Trace both paths to evaluate the shared component.
- Option 4: Outlet count does not establish heat-removal capability.

#### L-HW-01-Q6 — After correcting an unsupported GPU/riser combination, which record supports acceptance?

1. The original failed proposal with a new date
2. A generic supplier benchmark
3. The revised BOM and source versions linked to installed inventory and passing required tests
4. Only a screenshot showing that the OS booted

**Answer:** 3

- Option 1: A date change does not record the correction or its effect.
- Option 2: An unrelated benchmark does not show this installation meets its requirements.
- Option 3: The trace connects the correction to the accepted configuration and measured outcome.
- Option 4: Booting does not establish compatibility, transfer performance or recovery.

### Independent assignment

Environment: physical_lab

Review and verify a conventional node and an accelerated-node proposal against measurable service and recovery requirements. Obtain actual installed-hardware evidence for available equipment; keep inaccessible accelerated hardware open.

**Steps**

- Write requirements and a testable service envelope.
- Read exact OEM population, riser, power, thermal and firmware documents; record revisions.
- Prepare two candidate BOMs and reject one plausible incompatible combination without installing it.
- Inspect an authorised node and compare physical, BMC and host inventories.
- Run approved representative tests and compare to requirements.
- Review a corrected proposal and record acceptance, hold or escalation with retest evidence.

**Deliverables**

- Requirements/BOM and compatibility matrix for conventional and accelerated nodes
- NUMA/PCIe and storage dependency sketch
- Physical/BMC/OS inventory reconciliation
- Raw test results and signed decision record
- Engineering decision record: requirement and source/version; approved design or method; observations and raw evidence; consequence; accept/proceed, permitted conditional acceptance, reject/hold or escalate; correction/retest; competence and authority boundary.

**Acceptance Criteria**

- Every mandatory interface has an applicable source and test or explicit open evidence requirement.
- At least one justified rejection and one justified acceptance use the same requirement set.
- Installed identity and topology agree with the accepted BOM.
- Facility limits and recovery dependencies are reviewed by the appropriate owners.

App study and synthetic decisions are learning evidence only. Perform physical tasks on authorised equipment using the exact OEM procedure and qualified supervision where required. Record unavailable hardware and unperformed tests as open requirements. Neither a paper review nor an emulator establishes physical competence or production authority.

### Sources

- [NVIDIA GPU debug guidelines](https://docs.nvidia.com/deploy/gpu-debug-guidelines/index.html)
- [DMTF Redfish standards and inventory model](https://www.dmtf.org/standards/redfish)

## L-HW-02 — Receive, rack and hand over real hardware

Overview · Target topic stage: Applied · 55 estimated overview study minutes · Prerequisites: L-HW-01, DC-08

Integrate equipment physically while proving identity, installation quality and actual power and network dependencies.

### Learning objectives

- Validate equipment identity and receiving condition before installation.
- Choose an authorised model-specific lifting and rail method.
- Check rack weight, clearance, airflow and service access.
- Verify power-path and cable assignments against the installed system.
- Coordinate liquid-cooling interfaces within qualified authority.
- Distinguish a physical deployment acceptance record from a rack model.

Receiving is the first opportunity to detect an installation that will never match its design. Compare the shipment, purchase record and approved BOM: model, service tag or serial number, part revisions, supplied rails, cables, power supplies, accessories and licences where relevant. Inspect packaging and equipment for damage, tampering and contamination according to the receiving procedure. Record discrepancies before signing unconditional acceptance. A sealed box establishes neither authenticity nor the internal configuration. Escalate doubtful provenance through the supplier and asset-control process instead of connecting an unexplained device to management networks.

**Plan the installation around the exact equipment.** The model-specific installation manual governs lifting arrangements, rack compatibility, rail attachment, tool requirements and permitted service positions. A server can be within a person's imagined lifting ability yet require a lifting aid or coordinated handling because of mass, reach or instability. Confirm trained personnel, approved equipment, clear access and the permitted method before moving it. Never learn whether an improvised rail arrangement works by letting the chassis carry its own weight. The authorised physical demonstration is part of this curriculum; reading these principles cannot replace it.

Electrostatic precautions protect sensitive components during receiving, staging and replacement. Use the approved workstation, packaging and personnel grounding arrangements for the site and task. Keep modules in their protective packaging until required. ESD precautions do not replace electrical isolation or mechanical handling rules, and a wrist strap is not permission to work on an energised assembly. Identify which parts may be handled by the learner, which require a qualified technician, and which must remain sealed. Stop the proposed task when its safety or service authority is unclear.

A rack elevation is a plan with physical consequences. Check the equipment's occupied units, mass, loading and stability constraints against the approved rack arrangement. Verify front and rear clearance, rail travel, door closure and safe removal of serviceable components. Airflow direction must agree with the rack's supply and return design. Cables, packaging or missing required blanking arrangements can create recirculation or obstruction. Installing the server in the correct U position does not compensate for a rear door that cannot close or an inaccessible emergency service path. D1 structural work remains outside this programme's owned engineering scope; obtain an authorised interface decision when rack or floor limits matter.

**Trace connections rather than trusting labels.** Record the server PSU, cord, rack PDU outlet and approved upstream feed association. Verify connector and cord suitability through the approved design and exact OEM requirements. Dual supplies provide only the redundancy supported by their configuration and actual dependencies. With qualified supervision and an approved test, demonstrate the allowed maintenance state instead of assuming the second cord will carry the load. Do not open a hazardous distribution panel or improvise a live electrical test to prove a path.

Network and management connections need equally careful records. Label both ends with a stable scheme, record switch ports and VLAN or service assignments, preserve cable bend and strain limits, and inspect for obstructed fans or moving rails. The BMC management port may be dedicated or shared depending on the platform; confirm the configured mode and intended management boundary. A link light verifies limited physical activity, not correct addressing, authorised exposure, time synchronisation or ability to reach the required service. Commission those functions separately.

Liquid-cooled hardware adds explicit interfaces between equipment, rack manifolds and the facility cooling service. Connection types, cleanliness, approved fluids, pressure/temperature envelope, leak detection and commissioning methods must come from the selected design and OEM procedures. A qualified person performs or supervises the authorised connection and leak-check work. The learner records the identity, approved method and outcome without claiming competence for unobserved work. Never disconnect an unfamiliar coupling merely because another product describes its connector as dry-break.

Handover combines installed evidence with service tests. Reconcile receiving records, rack elevation, cable and power maps, BMC identity, initial inventory and required alarms. Photographs are useful when permitted, but should avoid exposing passwords, access badges or unrelated sensitive information. Record any temporary arrangements with owner and expiry, or hold acceptance if they violate a mandatory requirement. Include a deliberate paper review of an incorrect installation proposal, its correction and subsequent inspection. The final decision must establish what was physically installed and observed, what functions were tested, and which requirements remain open; a completed virtual rack drawing cannot satisfy the real deployment requirement.

### Worked example

**Installation review — two cords, one dependency.** A synthetic handover record assigns a 36 kg server to rack R4/U12–13, with PSU1 on A-PDU/08 and PSU2 on B-PDU/08. Inspection finds both cords on A-PDU because the B cord was too short. The team also proposes sliding out the server without confirming the rail latch or rack stabilisation procedure.

Hold the installation. The correct elevation and successful boot do not establish either the required feed arrangement or the safe service method. Obtain the approved cord and model-specific rail/lifting instructions; have authorised personnel correct the routing and inspect strain, airflow and service travel. Record the actual outlets and evidence for the permitted single-feed operating test. Accept the corrected physical package only after the required feed, inventory, management and service-access tests pass. The 36 kg figure is exercise data, not a universal lifting rule.

### Guided practice

You receive a supported server model with a different rail-kit part number than the approved BOM. It appears to fit. What must happen before the chassis is loaded?

**Hint:** Appearance establishes less than an OEM compatibility statement.

**Worked solution:** Hold physical installation, record the discrepancy and check the exact rack/server/rail combination against the OEM documentation. Obtain an approved compatible kit or formally reviewed design correction. Demonstrate installation with the required trained personnel or lift, inspect locking and service positions, and retain physical evidence. Do not experimentally load an unverified arrangement.

#### L-HW-02-Q1 — The box label matches the purchase order, but the internal service tag differs. What is the appropriate disposition?

1. Connect it immediately because the outer label is correct.
2. Hold and reconcile identity/provenance before operational connection.
3. Replace the service tag label yourself.
4. Ignore the mismatch if the device powers on.

**Answer:** 2

- Option 1: The mismatch leaves asset identity unresolved.
- Option 2: The receiving record must explain which asset was supplied before trust and support decisions.
- Option 3: Relabelling hides rather than resolves the discrepancy.
- Option 4: A successful power-on does not establish provenance.

#### L-HW-02-Q2 — A rail kit fits the rack holes but is absent from the approved combination. Which action is justified?

1. Load the server slowly as a compatibility test.
2. Use tape to restrain the chassis.
3. Obtain the exact supported rail/rack/server method before loading.
4. Assume all rails from one vendor are interchangeable.

**Answer:** 3

- Option 1: Loading an unverified support arrangement is not an acceptable validation method.
- Option 2: An improvised restraint is not an approved rail system.
- Option 3: Mechanical support must be established through the model-specific procedure.
- Option 4: Vendor identity does not guarantee mechanical compatibility.

#### L-HW-02-Q3 — A rack elevation is correct, but rear cabling prevents the server’s required service access. Is installation complete?

1. Yes, because U position is the only acceptance criterion.
2. No; revise the routing and verify clearances and airflow against the approved method.
3. Yes, if the equipment operates with the rear door temporarily open.
4. No; replace every cable without checking requirements.

**Answer:** 2

- Option 1: Installed location is only one physical requirement.
- Option 2: Serviceability and airflow are part of the installation’s functional design.
- Option 3: Temporary operation does not establish the required service clearance and approved physical arrangement.
- Option 4: Correction should address the demonstrated issue using approved cable requirements.

#### L-HW-02-Q4 — A server survives removal of one PSU input during an authorised test. What additional evidence is needed before claiming independent feeds?

1. Only the number of PSUs
2. The actual cord/outlet/upstream dependency mapping
3. A photograph showing two PSU modules but no cable endpoints
4. The host operating system version alone

**Answer:** 2

- Option 1: Two supplies can share an upstream failure point.
- Option 2: The mapping establishes whether the tested cords provide the intended independent paths.
- Option 3: Two modules do not establish independent upstream dependencies.
- Option 4: The OS version does not establish electrical path independence.

#### L-HW-02-Q5 — A liquid-cooling connector resembles one used in an earlier lab. Which statements are justified? Select all that apply.

1. Use the exact OEM connection and leak-check procedure.
2. Record qualified supervision and the limits of the learner’s task.
3. Disconnect it live because its shape suggests a dry-break mechanism.
4. Assume every coolant is compatible with the seals.

**Answer:** 1, 2

- Option 1: Connector, pressure, cleanliness and fluid requirements are model-specific.
- Option 2: Physical observations and authority must be recorded accurately.
- Option 3: Similarity does not establish permission or safe operating conditions.
- Option 4: Fluid compatibility must be explicitly established.

#### L-HW-02-Q6 — Which package meets the physical-evidence intent of HW-02?

1. A simulated rack elevation only
2. A receipt and a quiz score only
3. Witnessed authorised installation, reconciled connection records and passing handover tests
4. A generic installation video watched twice

**Answer:** 3

- Option 1: A model supports planning but does not demonstrate physical deployment.
- Option 2: Receiving and knowledge checks do not establish installation performance.
- Option 3: This records actual execution and verification against the approved method.
- Option 4: Demonstration prepares the learner; it does not prove their own physical work.

### Independent assignment

Environment: physical_lab

Install and hand over one real server or storage device. Include accelerated-rack interface review, and obtain supervised equipment access for physical tasks that cannot be performed on the first device.

**Steps**

- Reconcile receiving identity, condition and BOM; record a proposed discrepancy.
- Review OEM rails, lifting, ESD, clearance and connection requirements with the supervisor.
- Stage and install authorised equipment using the approved method.
- Trace cable and power endpoints; coordinate any liquid connection with qualified personnel.
- Test inventory, required management exposure and approved service/maintenance behaviour.
- Correct a discovered or paper-proposed installation defect, reinspect and obtain review.

**Deliverables**

- Receiving and provenance record
- Approved installation method and authority record
- Rack elevation, cable map, power assignment and permitted photos
- Raw handover test records and correction/retest decision
- Engineering decision record: requirement and source/version; approved design or method; observations and raw evidence; consequence; accept/proceed, permitted conditional acceptance, reject/hold or escalate; correction/retest; competence and authority boundary.

**Acceptance Criteria**

- The learner has performed the relevant physical tasks under the required supervision.
- Actual endpoints and device identity agree with the as-built records.
- No unsupported handling, connection or service arrangement is accepted.
- Unavailable accelerator or liquid-interface tasks remain explicitly open.

App study and synthetic decisions are learning evidence only. Perform physical tasks on authorised equipment using the exact OEM procedure and qualified supervision where required. Record unavailable hardware and unperformed tests as open requirements. Neither a paper review nor an emulator establishes physical competence or production authority.

### Sources

- [NVIDIA AI Rack and Interconnect certification learning route](https://www.nvidia.com/en-us/learn/certification/ai-rack-and-interconnect-professional/)
- [DMTF Redfish education](https://redfish.dmtf.org/education)

## L-HW-03 — Commission the boot chain and management plane

Overview · Target topic stage: Applied · 55 estimated overview study minutes · Prerequisites: L-HW-01, L-HW-02, DC-17

Build a recoverable, restricted BMC and firmware baseline whose reported health matches the installed hardware.

### Learning objectives

- Reconcile physical, BMC and host identity during bring-up.
- Constrain management identities, certificates and network exposure.
- Explain what Secure Boot and TPM evidence can and cannot establish.
- Use Redfish resource discovery and least privilege for management.
- Decide whether to update firmware using compatibility and recovery evidence.
- Accept commissioning only after independent function and recovery checks.

Bring-up converts installed hardware into a supported operational platform. Start by recording the physical service tag, installed components and accepted BOM, then compare them with BMC inventory and host discovery. Differences can result from incorrect hardware, stale inventory, disabled devices or a management fault. Resolve the cause before declaring a baseline. Save boot settings, storage-controller configuration, management-network mode, firmware versions and driver versions with timestamps and source revisions. The baseline is both a commissioning record and an input to later diagnosis and recovery.

UEFI or BIOS settings influence the boot path, device availability and platform behaviour. Select the approved boot mode, media order, storage mode and relevant virtualisation or device settings for the supported installation. A convenient setting changed during troubleshooting can persist unnoticed and alter the system's security or recovery behaviour. Record why each non-default setting is necessary. Boot approved installation or diagnostic media obtained from a trusted source and verified using the available provenance and integrity mechanisms. A checksum fetched from the same untrusted location as the image is not independent proof of origin.

**Protect management as an administrative path.** The BMC can expose console, virtual media, power control and hardware configuration independently of the host OS. A healthy host firewall does not establish BMC isolation. Verify dedicated versus shared management NIC mode, approved addressing, access paths and protocols. Use identifiable administrative accounts, minimal permissions, controlled emergency access and credential rotation according to the site design. Remove or disable unused default access as supported. Store secrets in the approved credential mechanism; exclude them from screenshots, exported JSON and public repository evidence.

Certificates connect a management endpoint to an expected identity when the client validates the appropriate trust chain and name. An encrypted session with verification disabled does not provide the same identity assurance. Plan initial trusted enrolment, certificate renewal, time synchronisation and access after expiry or identity-service failure. Log who performed a change and preserve events in a location that remains useful when the BMC is reset. Remote virtual media and console access deserve explicit permissions because they can change the booted environment.

Secure Boot verifies applicable signed boot components according to platform policy; it is not a claim that every signed programme is trustworthy or that every peripheral firmware component is measured. TPM functions can support protected keys and measured-boot evidence, but their presence alone is not a full attestation decision. Identify the actual feature, configuration, evidence consumer and response to failure. Keep recovery keys and authorised alternate access available through an independently recoverable route. A motherboard or TPM replacement may change access to sealed secrets, so recovery planning belongs in initial commissioning.

**Use Redfish deliberately.** Redfish offers a resource-oriented management interface. Begin with authenticated, supported read-only discovery of the service root and linked resources instead of assuming a hard-coded server identifier. Record what this BMC actually exposes and which schema/profile or OEM extensions apply. Read inventory, health and logs, handle missing properties explicitly, and use scoped sessions with approved lifecycle management. A standard containing an update feature does not prove that a particular firmware implements it. Any write, reset or update is a separate controlled operation, not a side effect of evidence collection.

Firmware decisions require a chain of reasoning. Identify the specific issue or vulnerability, affected models, dependencies, required intermediate versions, driver compatibility, expected interruption and validation tests. Check vendor-supported downgrade or recovery rules before the window. Some updates are irreversible or require an OEM recovery procedure; label that boundary explicitly rather than promising a rollback that has never been supported. Preserve trusted packages and recoverable configuration, arrange console or local access if management fails, and test the procedure on representative authorised equipment before broader use.

Commissioning ends with evidence from several layers. Confirm the device boots the approved system, supported components enumerate, required paths function, management access is restricted as intended, logs and time are useful, and recovery methods work within their declared limits. NIST firmware-resiliency guidance frames protection, detection and recovery as related needs; the lesson's test campaign applies those ideas to a particular installation. If the BMC reports green but the host misses a required HBA, hold acceptance and resolve the discrepancy. An accepted version number or update-complete message is one observation, not a substitute for restored service and trustworthy administrative control.

### Worked example

**Update disposition — the newest package is not the only criterion.** A synthetic BMC baseline is version 4.2 with host driver 7.1 and NIC firmware 3.4. The approved advisory requires BMC 4.4 for a relevant issue. The OEM sequence states that 4.3 must be installed first, and returning from 4.4 to 4.2 is unsupported. A plan proposing a direct update and “roll back if needed” is rejected.

The corrected plan uses the supported sequence on a representative lab node, retains configuration and a trusted recovery package, and confirms access to the OEM recovery procedure and local console. After update, inventory and time agree, unapproved management traffic is denied, authorised sessions and remote console work, and host/storage function passes. The recorded disposition can be accept for the tested baseline, with the explicit limitation that firmware downgrade is unsupported. A failed production update would follow the documented recovery/escalation path, not an invented reverse update.

### Guided practice

A Redfish inventory collector returns no temperature property for a supported resource. A developer proposes writing zero so the report remains green. How should collection and acceptance change?

**Hint:** An absent value has different meaning from a measured zero.

**Worked solution:** Represent the reading as unavailable with resource identity, timestamp and diagnostic detail. Check the implemented schema/OEM capability and use a supported alternate observation where needed. Do not manufacture a normal reading. The inventory collector should remain read-only, and any unmet acceptance measurement remains open until a valid observation is obtained.

#### L-HW-03-Q1 — The physical HBA is present but missing from the host after bring-up; BMC health is green. Which decision is justified?

1. Accept because the BMC is authoritative for every function.
2. Hold the required storage function and investigate inventory, slot, firmware and driver evidence.
3. Remove the missing HBA from the BOM without review.
4. Declare a cybersecurity incident solely from this observation.

**Answer:** 2

- Option 1: The BMC summary does not prove host enumeration or storage function.
- Option 2: The discrepancy needs evidence and functional retesting before acceptance.
- Option 3: Changing requirements to match an unexplained fault defeats acceptance.
- Option 4: There are several non-security causes; investigate without assuming one.

#### L-HW-03-Q2 — The host firewall blocks public traffic, but the BMC uses a shared NIC. What must still be verified?

1. Nothing; the host firewall always controls BMC traffic.
2. The BMC’s actual management mode, address, access controls and exposure.
3. Only the host desktop password.
4. Only the serial number printed on the chassis.

**Answer:** 2

- Option 1: BMC traffic can be independent of host firewall enforcement.
- Option 2: Management is a separate administrative path with its own controls.
- Option 3: Host credentials do not establish BMC permissions.
- Option 4: Identity is important but does not demonstrate isolation.

#### L-HW-03-Q3 — A server has a TPM and Secure Boot enabled. Which claim is defensible?

1. All installed software and peripheral firmware are guaranteed benign.
2. Defined platform features are present; their scope and actual evidence still need assessment.
3. Recovery keys can be discarded safely.
4. No firmware verification is necessary.

**Answer:** 2

- Option 1: These mechanisms have specific coverage and trust assumptions.
- Option 2: Presence and configuration are inputs to a scoped trust assessment.
- Option 3: Recovery dependencies remain important, especially after platform changes.
- Option 4: Firmware trust must still be considered within the supported design.

#### L-HW-03-Q4 — A read-only evidence script sees a missing Redfish sensor property. What should it do?

1. Replace the missing value with zero.
2. Reset the BMC automatically until the field appears.
3. Report unavailable data and the relevant resource/capability information.
4. Assume the newest schema is fully implemented.

**Answer:** 3

- Option 1: Zero would be fabricated measurement data.
- Option 2: A reset is a disruptive write outside a read-only collection role.
- Option 3: Missing data should remain explicit and diagnosable.
- Option 4: The device’s implementation, not the newest standard alone, determines capability.

#### L-HW-03-Q5 — A supported security update prohibits downgrade. Which statements are justified? Select all that apply.

1. Document the unsupported rollback boundary.
2. Test and arrange a supported recovery or replacement route.
3. Promise a reverse update to reassure the reviewer.
4. Ignore the update because every change must be reversible in software.

**Answer:** 1, 2

- Option 1: The real limitation belongs in the change decision.
- Option 2: Recovery may require a different supported method, local access or replacement.
- Option 3: An invented rollback creates false confidence.
- Option 4: A non-downgradable update can still be justified through risk and recovery planning.

#### L-HW-03-Q6 — The firmware updater reports success. What is still required before release?

1. Close the task immediately.
2. Validate identity, approved settings, management restrictions, host function and recovery evidence.
3. Reboot repeatedly without a test plan.
4. Delete the previous baseline and logs.

**Answer:** 2

- Option 1: Update completion does not establish system acceptance.
- Option 2: Commissioning tests the resulting operational and trust state.
- Option 3: Unplanned reboots can create disruption without useful evidence.
- Option 4: Previous evidence is essential to understanding the change and recovery.

### Independent assignment

Environment: physical_lab

Commission an authorised physical BMC/host baseline, execute a supported update when available, and test the documented recovery route without assuming firmware downgrade support.

**Steps**

- Capture physical, BMC and OS inventory plus firmware/driver/settings baseline.
- Watch the required OEM and Redfish demonstrations; pin actual video titles and implementation versions.
- Establish restricted management access, verified endpoint identity, logging and approved emergency recovery access.
- Perform read-only Redfish inventory and document unsupported properties.
- Review, stage and execute an authorised supported firmware update; test recovery as approved.
- Revalidate functional and trust requirements and obtain a reasoned update/continue/hold decision.

**Deliverables**

- Versioned bring-up baseline
- Management-access and certificate test record
- Read-only inventory with missing-property handling
- Approved update sequence, recovery evidence and acceptance decision
- Engineering decision record: requirement and source/version; approved design or method; observations and raw evidence; consequence; accept/proceed, permitted conditional acceptance, reject/hold or escalate; correction/retest; competence and authority boundary.

**Acceptance Criteria**

- Physical and management identity agree, and host function is demonstrated.
- Unapproved management access is denied while approved and recovery access are tested.
- Update sequence and rollback/recovery limits match OEM support.
- The reviewer can distinguish an update result from completed commissioning.

App study and synthetic decisions are learning evidence only. Perform physical tasks on authorised equipment using the exact OEM procedure and qualified supervision where required. Record unavailable hardware and unperformed tests as open requirements. Neither a paper review nor an emulator establishes physical competence or production authority.

### Sources

- [DMTF Redfish standard and implemented resources](https://www.dmtf.org/standards/redfish)
- [NIST SP 800-193 — platform firmware resiliency](https://csrc.nist.gov/pubs/sp/800/193/final)

## L-HW-04 — Commission storage and survive a degraded data path

Overview · Target topic stage: Applied · 55 estimated overview study minutes · Prerequisites: L-HW-03, DC-13

Evaluate usable capacity, write integrity and remaining fault tolerance before changing a storage system.

### Learning objectives

- Calculate usable capacity and reserve without confusing raw device ratings.
- Compare redundancy, replication, snapshots and independent backups.
- Assess controller caching, endurance and acknowledged-write protection.
- Validate multipath service with an application-level failure test.
- Evaluate remaining fault tolerance during replacement and rebuild.
- Accept storage repair only after integrity and independent restoration tests.

Storage engineering is a service-integrity problem as well as a capacity problem. Begin with the required data, access pattern, latency envelope, retention, tolerated interruption and restoration objectives. Identify where acknowledged writes reside at each stage: application, operating-system cache, controller cache and media. Record which layers can buffer or reorder data and what protects them during the specified failure. A benchmark that repeatedly reads cached data cannot demonstrate durable-write behaviour, and a successful disk discovery cannot establish that the application sees the intended protected volume.

**Calculate capacity in the units used by the requirement.** An array's raw capacity is the total nominal capacity of participating devices. A conventional RAID 6 group with equal-size devices typically devotes the equivalent of two devices to distributed parity, so its nominal data capacity is approximately the smallest member capacity multiplied by the number of members minus two. Formatting, metadata, reserves, unequal devices and the actual implementation change the usable result. A hot spare is not normally counted as an active data member before a failure. State decimal TB versus binary TiB explicitly; they describe different numeric values for the same byte count.

Protection choices answer different questions. Mirroring or parity can sustain specified device failures. Multipathing can sustain specified access-path failures. Replication can copy data to another system, often including erroneous or malicious changes unless the design prevents that. Snapshots can retain historical states, but may share the original controller, credentials, media or capacity pool. An independent backup provides a separately recoverable source only if its data, catalogue, keys, access and restore process remain available after the relevant failure. RAID is not a substitute for that restoration route.

Controller caching improves some workloads but introduces an acceptance obligation. Determine whether acknowledged writes are preserved under supported loss-of-power conditions and what happens when a cache protection device is unhealthy. A controller may change policy or performance when protection is unavailable; record the supported behaviour rather than forcing an unsafe performance mode. SSD endurance and power-loss protection remain distinct. Select supported drives and firmware, calculate expected write demand, and confirm the controller's compatibility and replacement procedure. A drive marketed for high throughput may be unsuitable for the required write workload or enclosure.

**Trace the full I/O path.** A host may use local storage, a RAID controller, an HBA, Ethernet storage or a Fibre Channel fabric. Record initiator and target identities, volume identifiers, access permissions, path grouping and the array's supported access behaviour. Multipath software combines paths to a logical device; multiple visible paths do not necessarily create multiple independent failure domains. Two paths through one failed switch or controller can disappear together. Match driver, firmware, timeout, failover and path-selection settings to the supported stack, and avoid exposing each underlying path as an unrelated writable disk.

Commission with synthetic data and predefined limits. Create a supported configuration, record identifiers, write a representative data set and retain an independent integrity reference. Measure application-level throughput and latency under stated conditions. Under an approved plan, introduce one safe path or device failure and observe I/O continuity, errors, timeout duration and alerts. Restore the path or replace the approved device, then verify the return to the intended protection state. The relevant question is whether the required data function survives within limits, not merely whether a link indicator changes colour.

Rebuild is a distinct maintenance state with its own exposure. In a conventional RAID 5 group with one failed member, no further complete member failure is tolerated during the degraded state. A conventional RAID 6 group with one failed member can usually tolerate one additional complete member failure; other errors, implementation limits and shared failures still matter. A rebuild percentage is progress, not proof of data integrity or available performance. Review concurrent workload, existing media warnings, spare suitability, estimated duration and independent restore readiness before approving another maintenance action.

An advanced repair decision keeps the data and controller problem separate. A replacement controller may need a supported configuration-import or migration procedure; blindly initialising unfamiliar disks can destroy the very configuration being recovered. Preserve device order and identities where required, capture evidence, and follow the exact OEM process. After repair, compare integrity, application behaviour, access controls and protection state with the acceptance criteria. Then perform an independent restoration exercise from approved backup to a separate authorised target. A green array after rebuild proves neither that all application data is correct nor that a future loss can be recovered.

### Worked example

**Capacity and repair disposition.** A synthetic design has eight 4 TB drives in one RAID 6 group plus one separate 4 TB hot spare. Nominal group data capacity is (8 − 2) × 4 = 24 TB before formatting and implementation reserves. If the project reserves 20% of that nominal data space, its planning allocation is 19.2 TB; do not call all 36 TB of installed media usable data capacity.

One active member fails. The hot spare begins rebuilding. Under the stated conventional RAID 6 model, the group can tolerate one further complete member failure while one is absent, but this does not guarantee survival of every correlated error. A request to remove a second healthy drive “because RAID 6 tolerates two” is held: it consumes the remaining complete-drive margin and is unnecessary exposure. Verify the replacement procedure, existing errors and backup restoration readiness. Once rebuild, integrity and application tests pass, accept the corrected state and record the independently restored data set as a separate recovery result.

### Guided practice

An iSCSI host shows two paths, both through switch S1. An authorised S1 outage stops application I/O for 75 seconds against a 20-second limit. The array itself remains healthy. What should the engineer conclude?

**Hint:** Separate array health, path count, shared dependency and application acceptance.

**Worked solution:** The required path resilience failed. Two paths shared S1, and the measured 75-second interruption exceeded the 20-second criterion. Hold that acceptance claim, redesign the required independent path and supported timeout/failover behaviour with the network and storage owners, then retest actual I/O and integrity. A healthy array and restored ping do not change the failed measurement.

#### L-HW-04-Q1 — Eight 4 TB active members form a conventional RAID 6 group; one additional 4 TB drive is a hot spare. What is nominal group data capacity before reserves and formatting?

1. 36 TB
2. 32 TB
3. 24 TB
4. 20 TB

**Answer:** 3

- Option 1: This counts all installed raw media, including parity and spare.
- Option 2: This is active raw capacity before parity allowance.
- Option 3: (8 − 2) × 4 TB = 24 TB nominal data capacity.
- Option 4: This subtracts three active-device equivalents without the stated reason.

#### L-HW-04-Q2 — A snapshot is stored on the same array and controlled by the same compromised administrator. What restoration claim is justified?

1. It guarantees recovery from destruction of that array.
2. It is automatically independent of the compromised control plane.
3. Its usefulness depends on surviving shared media and administrative failure; an independent restore route is still needed.
4. Snapshots can never support any recovery.

**Answer:** 3

- Option 1: The snapshot shares the array’s failure exposure.
- Option 2: Shared administrative authority may affect both current and historical data.
- Option 3: Assess the actual failure and trust boundaries rather than the feature name.
- Option 4: Snapshots can be useful within their supported failure scope.

#### L-HW-04-Q3 — Controller cache protection fails and the supported controller switches to a slower protected policy. What should happen?

1. Force unsafe caching to recover the benchmark number.
2. Assess the supported degraded mode and service impact, repair protection and retest.
3. Declare every acknowledged write lost without evidence.
4. Ignore the alert because all disks are online.

**Answer:** 2

- Option 1: Performance does not justify defeating required write integrity.
- Option 2: The decision must preserve supported integrity while addressing capacity and repair.
- Option 3: The controller may preserve integrity by changing policy; inspect evidence.
- Option 4: Disk presence does not establish controller cache health.

#### L-HW-04-Q4 — Two storage paths are visible, but both use one switch. Which statements are justified? Select all that apply.

1. The switch is a common dependency.
2. A safe application I/O failure test is needed for the required service criterion.
3. Two paths prove survival of switch loss.
4. A successful ping after recovery proves no data interruption occurred.

**Answer:** 1, 2

- Option 1: Both paths can fail with the shared switch.
- Option 2: The service requirement concerns I/O continuity, timing and integrity.
- Option 3: Path count does not establish independent failure domains.
- Option 4: Ping does not measure historical application continuity or data integrity.

#### L-HW-04-Q5 — One member of a conventional RAID 5 group has failed and rebuild is incomplete. How much tolerance remains for another complete member failure in that group?

1. Two more drives
2. One more drive
3. No further complete member failure under that model
4. Unlimited if a hot spare was present

**Answer:** 3

- Option 1: RAID 5 does not provide this member-failure tolerance.
- Option 2: The single complete-member margin is already consumed.
- Option 3: The degraded group has consumed its complete-member redundancy.
- Option 4: A spare starts replacement/rebuild; it is not instant restored redundancy.

#### L-HW-04-Q6 — A controller replacement restores a green array. What best closes the repair and recovery evidence?

1. Only the green status screenshot
2. An undocumented reinitialisation of every disk
3. Passing integrity/application/protection tests plus a separately demonstrated backup restoration
4. A note that RAID is a backup

**Answer:** 3

- Option 1: Status is one observation and cannot prove full integrity or recoverability.
- Option 2: Reinitialisation can destroy required configuration and data.
- Option 3: Repair and independent recovery have distinct acceptance criteria.
- Option 4: RAID handles specified failures; it is not an independent backup.

### Independent assignment

Environment: physical_lab

Create a supported storage configuration using synthetic data, demonstrate a safe drive/path fault, replacement/rebuild and a separate independent restoration.

**Steps**

- Record host/controller/drive identities, firmware, capacity, protection and restore requirements.
- Watch the OEM storage commissioning and repair demonstration T-LAB-03.
- Create supported storage; retain synthetic-data checksums and a separate approved backup.
- Measure defined I/O behaviour and introduce one authorised safe drive or path failure.
- Document reduced protection, execute the supported replacement/rebuild, and retest integrity and application performance.
- Restore the data independently to an authorised separate target and review a proposed unsafe second maintenance action.

**Deliverables**

- Capacity/endurance/protection calculation
- Supported storage and multipath configuration
- Failure/rebuild timeline and raw integrity/I/O evidence
- Independent restoration record and accept/hold/retest decision
- Engineering decision record: requirement and source/version; approved design or method; observations and raw evidence; consequence; accept/proceed, permitted conditional acceptance, reject/hold or escalate; correction/retest; competence and authority boundary.

**Acceptance Criteria**

- Capacity and remaining fault tolerance are stated accurately for the actual implementation.
- Required application behaviour and integrity pass before and after the fault.
- The replacement path is supported and does not blindly initialise required data.
- Independent restoration succeeds; rebuild is not counted as a backup test.

App study and synthetic decisions are learning evidence only. Perform physical tasks on authorised equipment using the exact OEM procedure and qualified supervision where required. Record unavailable hardware and unperformed tests as open requirements. Neither a paper review nor an emulator establishes physical competence or production authority.

### Sources

- [Red Hat Enterprise Linux 9 — configuring device mapper multipath](https://docs.redhat.com/en/documentation/red_hat_enterprise_linux/9/html/configuring_device_mapper_multipath/index)
- [DMTF Redfish storage resources](https://www.dmtf.org/standards/redfish)

## L-HW-05 — Recover the host services that make hardware useful

Overview · Target topic stage: Applied · 55 estimated overview study minutes · Prerequisites: L-HW-03, L-HW-04, DC-11

Build reproducible Linux or Windows infrastructure services and prove restored network or OT function after host loss.

### Learning objectives

- Define a reproducible supported host and driver baseline.
- Trace DNS, time, identity, storage and database dependencies.
- Validate least-privilege service accounts and management agents.
- Distinguish a virtual-machine boot from restored infrastructure service.
- Use dependency evidence to accept or reject a hardware-replacement diagnosis.
- Restore required service and data in a justified dependency order.

An installed server contributes value only when its required service works. The D5 scope therefore includes the operating systems, drivers, management software and bounded supporting services needed to operate and validate the physical installation. This is not an instruction to build an unrelated cloud platform. Select a concrete function such as an OT historian, infrastructure backup service, directory/DNS support or a management virtual machine. Define its required clients, data, permissions, timing and recovery behaviour, then show how those requirements depend on the underlying host.

**Create a reproducible baseline.** Record the supported hardware, firmware, OS edition/build, installation media provenance, storage layout, drivers, agent versions and necessary host settings. Use documented installation steps or reviewed automation so a second operator can repeat the build without hidden local files. Keep secrets out of source control and capture how an authorised installer obtains them. Document licences and activation dependencies where they affect restoration. A script that succeeds only on its author's laptop is not yet a reproducible recovery method.

Install the host's approved network, storage and device drivers. A generic driver may permit boot while omitting required performance, management or recovery functions. Compare actual discovered devices with the supported baseline, inspect errors, and validate required I/O. For a virtualised service, record both host and guest dependencies: virtual controller/NIC types, memory reservations, storage placement, required integration services and time behaviour. Hypervisor convenience features can alter the expected backup or management behaviour, so test their configured function instead of assuming a running guest has every required integration enabled.

**Draw the dependency order before a failure.** Name resolution may be needed to locate a database; the application may need directory authentication; certificates may depend on trustworthy time; backup restoration may depend on a catalogue and an encryption key. Some dependencies form a loop: the credentials needed to restore a directory service may be available only through that same failed directory. Break that loop using the approved independent recovery identity and protected procedure. Document dependencies at the actual implementation level rather than writing a universal rule such as “DNS always starts first.”

Time is a service input, not merely a convenient clock display. Incorrect time can break certificate checks, authentication, event correlation or the interpretation of historian records. Record the approved source, client behaviour, permitted offset and response when synchronisation is lost. Do not solve an authentication failure by disabling every trust check. Likewise, a database listening on its port is not proof that the application schema, permissions and historical records were restored. Test the required query, write and authorised client function with controlled data.

Service accounts and agents have operational as well as security requirements. Grant only the rights needed for the assigned task, record owners and renewal/rotation procedures, and monitor failed authentication or service expiry. A management agent can report healthy while the application account has lost database permission. Avoid installing every optional agent because more software can add conflicts, privileges and maintenance dependencies. Each installed component should have a purpose, supported version, update procedure and recovery owner.

**Diagnose through competing explanations.** When a historian stops updating, a failed disk is one possibility; stale DNS, expired credentials, wrong time, missing database permissions or a blocked service path are others. Collect a timeline and compare host health, disk/path evidence, service logs, name resolution, authentication and application transactions. Prefer low-risk observations that distinguish causes. Replacing a healthy server can consume the maintenance window and reproduce the same dependency failure on new hardware. Accept a hardware-replacement proposal only when the observations support it or when a documented containment/recovery decision justifies replacement despite remaining uncertainty.

Restoration must recover the required service, its data and its administrative control. Rebuild the host from approved sources; restore supported drivers and configuration; make independent recovery dependencies available; recover storage/database/application state in the required order; then reconnect authorised clients. Use synthetic or approved test data to verify current writes, historical reads, time interpretation, alarms and role boundaries. Measure the interval from declared failure to accepted usable service, including identity or licence delays rather than excluding them from the clock.

Complete the exercise by repeating a defined part of the build or restoration with another operator or a clean environment. Record which assumptions failed and update the runbook. Keep an unavailable dependency in the assessment rather than arranging every prerequisite silently in advance. A booted operating system, a hypervisor's green VM icon and a reachable web page are intermediate observations. The acceptance record must show the specified network or OT function and data are correct, recoverable and accessible only to the intended authority.

### Worked example

**A proposed disk replacement misses the fault.** In a synthetic historian incident, CPU load is 18%, storage paths are healthy and the application has not recorded new values for 26 minutes. Its service log shows database login failures beginning immediately after account rotation. An approved test using the intended service identity fails, while a separate authorised diagnostic identity can query the database. Replacing the host disk is not supported by this evidence.

Hold the hardware-replacement proposal. Correct the service's credential reference through the approved secret-management process, without broadening its privileges. Verify new writes, a historical read, expected timestamp handling and denied unauthorised access. If accepted service returns at minute 34, record 34 minutes of restoration time from the declared failure, not just the eight minutes spent applying the correction. Then test rotation in the staging baseline and update the recovery dependency record so the same omission is detectable before the next change.

### Guided practice

A restored OT application VM boots but cannot resolve its database name. Its backup catalogue and emergency credentials were also hosted on the failed physical node. Write the next recovery priorities.

**Hint:** Identify the hidden dependency loop and the missing functional result.

**Worked solution:** Use the approved independently protected recovery route to obtain credentials, catalogue and configuration. Recover the required name-resolution and database dependencies in the actual design’s order, then restore application connectivity, identity and data. Verify current and historical OT function and permissions before acceptance. Revise the design to avoid the demonstrated dependency loop and repeat the failed-dependency test; a booted VM is only an intermediate milestone.

#### L-HW-05-Q1 — Which item most directly undermines a claimed reproducible host build?

1. A versioned media and driver manifest
2. A required unrecorded file available only on the original engineer’s laptop
3. Documented secret retrieval through the approved vault
4. A repeated installation on a clean authorised node

**Answer:** 2

- Option 1: Versioned inputs support repeatability.
- Option 2: The hidden dependency prevents another operator from reliably reproducing the build.
- Option 3: Secrets should be retrieved securely rather than committed into scripts.
- Option 4: A repeat test provides evidence of reproducibility.

#### L-HW-05-Q2 — The credentials required to restore the identity server can be retrieved only after that identity server works. What is this?

1. A sufficient recovery design
2. A circular recovery dependency requiring an independent approved access route
3. Proof that identity is unnecessary
4. A reason to publish all passwords in the repository

**Answer:** 2

- Option 1: The failed service blocks access needed to recover itself.
- Option 2: The loop needs protected emergency access and a tested recovery procedure.
- Option 3: Identity remains necessary; its recovery dependencies need redesign.
- Option 4: Publishing credentials creates exposure and is not an approved recovery mechanism.

#### L-HW-05-Q3 — A monitoring agent reports green, but the historian service account cannot write to its database. Which conclusion is supported?

1. All application functions are healthy.
2. The agent’s observation does not establish the service account’s required permissions or transaction success.
3. The agent must be malicious.
4. Grant every account administrator rights.

**Answer:** 2

- Option 1: Agent status covers only what it actually observes.
- Option 2: Validate the application identity and transaction directly.
- Option 3: A coverage gap does not establish malicious activity.
- Option 4: Broad privilege escalation fails least privilege and may not solve the actual fault.

#### L-HW-05-Q4 — A recovered VM boots and responds to ping. What is still needed for an OT historian acceptance claim?

1. Only a desktop screenshot
2. Current-value ingestion, historical-data reads, correct time interpretation and authorised/denied access tests
3. A successful hypervisor heartbeat with no application transactions
4. An extra reboot with no observations

**Answer:** 2

- Option 1: A desktop does not demonstrate historian function.
- Option 2: These tests exercise the required service and its trust boundaries.
- Option 3: Heartbeat supports guest liveness but not historian data, timing or role correctness.
- Option 4: An unplanned reboot adds little evidence and may disrupt recovery.

#### L-HW-05-Q5 — Disk health and I/O are normal, but service logs show login failure immediately after a credential change. What is the strongest next action?

1. Replace all drives.
2. Investigate the service identity and credential reference using approved diagnostics.
3. Disable all authentication.
4. Declare the host recovered because the hardware is healthy.

**Answer:** 2

- Option 1: The observations do not currently support a disk-replacement diagnosis.
- Option 2: The timeline and observed failure point discriminate the identity hypothesis.
- Option 3: Disabling authentication violates required access controls.
- Option 4: Healthy hardware alone does not restore the failed service.

#### L-HW-05-Q6 — Which measurements belong in a host-loss restoration assessment? Select all that apply.

1. Time to accepted required service, including dependency delays
2. Correct current and retained data plus intended administrative authority
3. Only the time until the first boot logo
4. Only the number of files in the backup folder

**Answer:** 1, 2

- Option 1: The restoration objective concerns usable accepted service, not a selected easy interval.
- Option 2: Data and control are necessary parts of the recovered function.
- Option 3: Boot is only an intermediate milestone.
- Option 4: File count does not establish correctness, access or recoverability.

### Independent assignment

Environment: physical_lab

Deploy and reproduce a bounded Linux/Windows infrastructure-service baseline, then recover its required OT/network function after an authorised host-loss exercise.

**Steps**

- Select the required service and define data, role, time and restoration criteria.
- Capture supported OS/driver/agent/media and configuration manifests with secure secret retrieval.
- Build on authorised hardware and demonstrate the required service under guided instruction.
- Map DNS, time, identity, storage, database, licence and backup dependencies.
- Perform an approved host-loss restoration including one unavailable dependency.
- Test current/historical function, least privilege and repeatability; accept or reject a proposed hardware diagnosis from evidence.

**Deliverables**

- Reproducible host/service baseline and dependency diagram
- Role and current/historical service test evidence
- Host-loss recovery timeline with failed-dependency correction
- Hardware-versus-service diagnosis and reviewer decision
- Engineering decision record: requirement and source/version; approved design or method; observations and raw evidence; consequence; accept/proceed, permitted conditional acceptance, reject/hold or escalate; correction/retest; competence and authority boundary.

**Acceptance Criteria**

- A clean build or rebuild is repeatable without hidden manual prerequisites.
- The required service and data pass after host recovery, with intended access and time behaviour.
- At least one unavailable dependency is diagnosed and corrected.
- A hardware-replacement decision is supported or rejected using competing-cause evidence.

App study and synthetic decisions are learning evidence only. Perform physical tasks on authorised equipment using the exact OEM procedure and qualified supervision where required. Record unavailable hardware and unperformed tests as open requirements. Neither a paper review nor an emulator establishes physical competence or production authority.

### Sources

- [Microsoft — Hyper-V integration services](https://learn.microsoft.com/en-us/windows-server/virtualization/hyper-v/manage/manage-hyper-v-integration-services)
- [Microsoft — Active Directory forest recovery procedures](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/manage/forest-recovery-guide/ad-forest-recovery-procedures)

## L-HW-06 — Design acceptance tests and diagnose non-routine hardware faults

Overview · Target topic stage: Advanced · 70 estimated overview study minutes · Prerequisites: L-HW-05, DC-05, DC-06

Use bounded load, correlated measurements and competing hypotheses to release or hold a hardware installation.

### Learning objectives

- Derive acceptance tests and stop limits from requirements before execution.
- Interpret latency, throughput and error measurements with stated conditions.
- Correlate memory, PCIe, NIC, GPU and thermal evidence.
- Distinguish hardware faults from configuration, software and upstream causes.
- Design a safe discriminating fault experiment and preserve raw results.
- Justify release or hold after correction and representative retesting.

Commissioning tests should expose whether the installation meets its requirements, not merely generate an impressive load graph. Begin with an acceptance matrix that links each required function to equipment identity, test method, instrumentation, operating conditions, limit, stop condition and reviewer. Separate an OEM diagnostic pass from the project's service-performance requirement. A component may pass a diagnostic yet be unsuitable for the intended workload, while a slow application can result from an upstream service even when the component is healthy. Both results matter, but they justify different decisions.

**Choose what to measure before running the test.** For memory, record installed and available capacity, supported population, reported errors and the scope of the chosen diagnostic. For PCIe devices, compare expected and negotiated generation/width, device enumeration and relevant error events. For storage, retain data integrity, throughput, latency distribution and protection state. For network paths, measure application-relevant transfer and errors at the host and network boundaries. For accelerators, include supported device diagnostics, interconnect status and a bounded representative compute or transfer test. A virtual GPU exercise does not measure the physical accelerator's actual performance.

Average values can conceal the failure a requirement was meant to prevent. If 99 requests complete in 2 ms and one takes 202 ms, the mean is 4 ms, but the single delayed request may violate a deadline. Record the required percentile or worst-case metric, sample count, duration, warm-up and workload definition. A percentile from ten samples has limited precision; a single short pass does not establish a month-long reliability claim. Compare like-for-like conditions and keep the raw observations so another reviewer can recalculate the result.

Load must be bounded by the approved equipment and service envelope. Establish temperature, power, error, interruption and duration stop limits with the relevant owners. Confirm monitoring works before applying load, and identify who can stop the test. Do not obstruct cooling, disable protective functions or run uncontrolled burn-in on a live service to manufacture a fault. A safe introduced fault may be a lab-only configuration mismatch, a permitted cable/path removal or an instructor-provided diagnostic data set. A synthetic trace develops reasoning but must remain labelled analytical evidence rather than a physical test.

**Correlate measurements on a useful timeline.** A throughput drop accompanied by thermal throttling, rising inlet temperature and increased fan response suggests a different investigation from a drop accompanied by PCIe link retraining and corrected bus errors. A GPU error identifier is a starting point for vendor-guided triage, not an automatic replacement order. Capture system logs and supported diagnostic bundles before resetting evidence, record driver/firmware versions and recent changes, and compare the same interval across host, BMC and network observations. Check clocks and sampling delays before inferring which event happened first.

Construct competing hypotheses and identify an observation that distinguishes them. Low throughput might result from the wrong link width, a driver mismatch, remote NUMA placement, network congestion, a slow source disk or a defective device. A read-only topology check can disprove a proposed sixteen-lane path before a disruptive swap is considered. A supported local transfer test may separate a host-device issue from a remote network path. Change one controlled variable where feasible, state what each possible result would mean, and include a way to restore the baseline. Do not interpret every improvement after a reboot as proof of a hardware defect.

Diagnosis also depends on measurement quality. A sensor may be unavailable, stale or labelled for a different location; verify identity, units and freshness. A counter can be cumulative since boot and should not be mistaken for errors per minute. A benchmark may use cached data or saturate its generator before reaching the component under test. Record these limitations and redesign inadequate tests. An acceptance plan that says “no red lights” misses performance, integrity, supported degradation and recoverability even when the dashboard has no alarms.

After correction, repeat the relevant failed test and enough related checks to show the correction did not break required behaviour. Compare before/after results under equivalent conditions; verify supported configuration and remaining protection. Decide accept, permitted conditional acceptance, hold/reject or escalation against the predefined criteria. If a required physical test could not be performed, leave it open rather than averaging it into a passing quiz score. The strongest advanced evidence explains why a plausible incorrect diagnosis was rejected, why the selected correction fits the observations, and why the retest supports release within the declared operating envelope.

### Worked example

**Discriminating a slow path.** A synthetic server must transfer at least 20 GB/s over a specified host/GPU path and remain below the project's approved thermal limit during the test. It achieves 11.8 GB/s. The recorded temperature is within the approved limit with no throttling indication, and the GPU diagnostic reports no component fault. Topology evidence shows PCIe 4.0 ×8 where the supported design expects ×16.

Reject the immediate GPU-replacement proposal: the narrowed link is a competing explanation with direct evidence. Review riser placement and firmware configuration using the OEM method; do not reseat live hardware without permission. After the supported correction, the link is ×16 and the identical transfer test reaches 22.1 GB/s. That is a 10.3 GB/s improvement, about 87% relative to the original result, but the acceptance claim should state the actual test and threshold rather than promise every workload improves 87%. Retest affected storage/NIC enumeration and retain raw before/after results before release.

### Guided practice

An acceptance report lists only mean latency of 4 ms. The requirement is “no request above 100 ms” for the defined trial. The retained samples are 99 requests at 2 ms and one at 202 ms. What disposition and correction are required?

**Hint:** Calculate the mean, but evaluate the stated requirement using the individual observations.

**Worked solution:** The mean is (99 × 2 + 202) / 100 = 4 ms, yet the 202 ms request violates the specified 100 ms maximum. Hold the criterion, preserve the data and investigate the correlated host/storage/network timeline. Correct the test report to show the required maximum and conditions, diagnose and correct the cause, then repeat the representative trial with the same acceptance rule.

#### L-HW-06-Q1 — A team starts a maximum-load test before deciding thermal stop limits. What is the appropriate response?

1. Continue and choose limits after seeing the result.
2. Stop or hold execution until approved limits, monitoring and authority are defined.
3. Use only the processor thermal limit and leave chassis, GPU and service limits undefined.
4. Treat the highest observed temperature as automatically acceptable.

**Answer:** 2

- Option 1: Post-hoc limits can rationalise an unacceptable result and leave the test uncontrolled.
- Option 2: A bounded test requires predefined safe and service limits.
- Option 3: One component limit does not bound the whole system or its service behaviour.
- Option 4: Observation alone does not establish an approved limit.

#### L-HW-06-Q2 — A trial has 99 requests at 2 ms and one at 202 ms; the maximum allowed is 100 ms. Which result is correct?

1. Mean 4 ms and the maximum criterion passes.
2. Mean 4 ms and the maximum criterion fails.
3. Mean 202 ms and the criterion passes.
4. No latency conclusion can be drawn from recorded samples.

**Answer:** 2

- Option 1: A low mean does not erase the 202 ms violation.
- Option 2: The arithmetic mean is 4 ms, but one sample exceeds the specified maximum.
- Option 3: The maximum is 202 ms; that is not the mean and it exceeds the limit.
- Option 4: The defined trial provides enough evidence to identify this violation.

#### L-HW-06-Q3 — A throughput drop coincides with bus-link retraining while thermal evidence remains within the approved envelope. Which next observation is most discriminating?

1. Compare expected and negotiated PCIe width/generation and associated logs.
2. Replace the fan assembly solely because the transfer result is low.
3. Replace every GPU without preserving logs.
4. Ignore the bus events because averages are normal.

**Answer:** 1

- Option 1: Topology and link events directly test a plausible path problem.
- Option 2: The recorded thermal evidence does not yet support a fan diagnosis; investigate the correlated bus-path evidence.
- Option 3: Unfocused replacement loses evidence and may reproduce the fault.
- Option 4: Correlated events can matter even when averages conceal them.

#### L-HW-06-Q4 — A remote transfer is slow. Which statements are justified? Select all that apply.

1. A supported local transfer test can help separate host/device limits from remote-path effects.
2. Source storage, NUMA placement and network congestion are competing causes.
3. Slow transfer proves the GPU is defective.
4. A reboot that improves performance proves the original cause was hardware.

**Answer:** 1, 2

- Option 1: A controlled comparison can distinguish where a bottleneck lies.
- Option 2: The end-to-end transfer depends on several layers.
- Option 3: Performance alone does not identify the faulty layer.
- Option 4: Reboots change many states and do not isolate a cause.

#### L-HW-06-Q5 — Which fault exercise is suitable when physical thermal fault injection is not authorised?

1. Block the live server’s air intake.
2. Disable shutdown protection.
3. Use an instructor-provided labelled thermal trace for reasoning and keep physical validation open.
4. Claim a paper trace is a measured production fault.

**Answer:** 3

- Option 1: Obstructing cooling can violate the approved equipment envelope.
- Option 2: Protective functions are not disabled for an unauthorised experiment.
- Option 3: A synthetic or supplied trace supports diagnosis learning without misrepresenting evidence.
- Option 4: Evidence fidelity must be stated accurately.

#### L-HW-06-Q6 — A correction makes one benchmark pass. What best supports release?

1. Retain only the latest passing score and omit the earlier test conditions.
2. Repeat the relevant failed and affected functional tests under comparable conditions, then assess predefined criteria.
3. Approve every future workload automatically.
4. Accept without checking that the new configuration is supported.

**Answer:** 2

- Option 1: Without comparable conditions and failed evidence, the reviewer cannot establish what the correction changed.
- Option 2: Retesting establishes the corrected result and relevant side effects.
- Option 3: One bounded test cannot establish unrestricted performance.
- Option 4: Support and compatibility remain acceptance requirements.

### Independent assignment

Environment: physical_lab

Plan and execute an authorised bounded hardware diagnostic/load campaign, diagnose one safe introduced fault, correct it and defend the release or hold decision.

**Steps**

- Translate requirements into memory, storage, PCIe/NIC/GPU, thermal and service acceptance criteria.
- Review OEM diagnostics, monitoring and explicit stop limits with the supervisor.
- Capture a clean baseline and perform the representative bounded load.
- Introduce an authorised safe fault or separately labelled instructor trace; construct competing hypotheses.
- Use discriminating observations, apply the supported correction and repeat the relevant tests.
- Critique a “green dashboard only” report and issue an evidence-based acceptance disposition.

**Deliverables**

- Reviewed test/stop-limit matrix
- Raw timestamped diagnostic and representative-load results
- Competing-hypothesis investigation with evidence provenance
- Correction/retest comparison and reviewer disposition
- Engineering decision record: requirement and source/version; approved design or method; observations and raw evidence; consequence; accept/proceed, permitted conditional acceptance, reject/hold or escalate; correction/retest; competence and authority boundary.

**Acceptance Criteria**

- Tests use predefined service and equipment limits rather than post-hoc thresholds.
- Diagnosis distinguishes at least two plausible causes.
- Required physical measurements retain their actual device identity and conditions.
- Release is justified by supported corrected configuration and passing required tests.

App study and synthetic decisions are learning evidence only. Perform physical tasks on authorised equipment using the exact OEM procedure and qualified supervision where required. Record unavailable hardware and unperformed tests as open requirements. Neither a paper review nor an emulator establishes physical competence or production authority.

### Sources

- [NVIDIA GPU node triage](https://docs.nvidia.com/deploy/gpu-debug-guidelines/gpu-node-triage.html)
- [Linux kernel — EDAC error reporting](https://docs.kernel.org/driver-api/edac.html)

## L-HW-07 — Turn hardware telemetry into sustaining-engineering decisions

Overview · Target topic stage: Advanced · 70 estimated overview study minutes · Prerequisites: L-HW-06, DC-16, DC-18

Operate a reviewed health campaign that detects deterioration, preserves context and verifies whether maintenance worked.

### Learning objectives

- Build an operating record that reconciles physical and management inventory.
- Interpret cumulative counters, rates and missing telemetry correctly.
- Evaluate ECC, storage endurance and path-error trends against model-specific guidance.
- Prioritise maintenance using consequence, exposure and recovery capability.
- Review firmware or configuration changes through controlled evidence.
- Verify recurrence and effectiveness after maintenance or improvement.

Sustaining engineering keeps an accepted system within its intended operating envelope as equipment, software and service demand change. The daily task is not to obtain a green dashboard screenshot. It is to notice meaningful change, determine its significance and maintain an accurate record of the installed system. Begin with inventory identity, component location, supported firmware, warranty or support status, spare availability and the services that depend on each node. Reconcile CMMS/DCIM records, BMC discovery and actual hardware after every authorised change. A replacement recorded under the old serial number can misdirect later support and sanitisation decisions.

**Give each observation context.** Record source, units, timestamp, collection interval, reset behaviour and expected availability. A cumulative counter of 120 errors says something different from 120 new errors during the last hour. When counters reset after a reboot or component replacement, calculating a negative rate is a data-processing error rather than miraculous repair. Track the reset and begin a new comparable interval. Missing telemetry should become an observability fault; silently carrying forward the last green value creates a false impression that the equipment is still being measured.

Memory errors require platform-specific interpretation. Corrected ECC events show that a reported error was handled by the applicable mechanism; they are not proof that deterioration can be ignored indefinitely. Uncorrected, deferred and fatal reports have different meanings depending on the platform and OS. Repeated events associated with one location warrant investigation against OEM guidance, workload, firmware, temperature and physical mapping. Never assign a universal “replace after ten errors” rule without the relevant product guidance. Keep the event records and any OEM case reference needed to explain the resulting disposition.

Storage health likewise combines multiple observations. Capacity free space, media endurance indicators, controller/cache protection, rebuild status, path errors and application latency describe different aspects of service risk. A drive's reported life-used percentage is not a precise universal calendar prediction. Check its vendor definition and compare change under a representative write workload. A projection can help schedule review, but include uncertainty and support limits. A spare on the shelf is useful only if its part number, capacity, firmware, shelf condition and installation method are suitable when required.

**Connect hardware and facility evidence.** Rising component temperature may follow increased load, an airflow obstruction, a fan problem, an incorrect sensor interpretation or a changed room condition. Link events across BMC, host and relevant facility observations, with known time alignment. A model-specific temperature warning should not be suppressed simply because room average temperature remains normal. Similarly, host network errors may involve a NIC, optic, cable, switch port or firmware rather than the server board. Preserve competing explanations until a discriminating test supports the diagnosis.

Prioritisation considers consequence, likelihood indicators, exposure duration and recoverability. A deteriorating component in an already degraded array can deserve faster attention than the same warning in a fully protected spare test system. Review service redundancy, allowed maintenance windows, replacement lead time and the independent recovery route. Decide whether to continue with monitoring, plan a repair, restrict use, hold a change or escalate. Conditional acceptance must identify the permitted condition, owner, expiry and trigger for stopping; it must not quietly waive a mandatory safety or integrity requirement.

Firmware compliance is more than counting devices on the highest version. Maintain an approved baseline per supported configuration, an exception record and the reason for each update or hold. Review applicable advisories, dependencies, service impact and supported recovery. Stage changes on representative equipment and compare post-change behaviour with the baseline. Use least-privilege read-only collection for routine evidence; any configuration or firmware action needs separate authority. Automation can make inventory and trend checks repeatable, but must handle missing data, unexpected device identity and failed access explicitly.

The operating campaign needs a complete story: normal checks, a detectable deterioration, diagnosis, reviewed correction and proof that the correction worked. Define recurrence criteria before closing the task. “No alert today” is weak evidence if collection stopped yesterday. Compare equivalent load and observation duration, inspect the relevant raw counters and confirm collection coverage. Where an optimisation is attempted, measure its improvement without compromising another required function. A lower fan speed or reduced energy reading is not success if it causes unaccepted component temperatures or hidden throttling.

End each campaign with a reviewed decision record linked to the work package: requirement/source, observations, consequence, disposition, correction, retest and limitations. Preserve both a rejected plausible incorrect proposal and a justified accepted one. This concentrates D5's advanced effort on sound engineering judgment while retaining the mandatory hands-on work. It does not convert routine checklist throughput into an equal independent hardware specialism or allow paper review to replace the physical repair and recovery requirements.

### Worked example

**A trend changes the maintenance decision.** A synthetic DIMM counter reads 12 corrected events at Monday 08:00, 14 at Tuesday 08:00 and 62 at Wednesday 08:00. With no reset and continuous collection, the daily increments are 2 and 48. That is a change in observed rate, not proof that the module will fail at a predictable time. Relevant OEM guidance and support evidence are still required.

An initial proposal says “ignore all corrected errors.” Reject that blanket conclusion. Check mapping to the physical DIMM, related host/BMC events, temperature, workload and approved firmware. The supported investigation identifies the affected location and calls for an authorised replacement. After correction, a new component identity and counter baseline are recorded. Under comparable load, no recurrence appears during the predefined observation period and service tests pass. Accept the maintenance result within that interval; retain the raw evidence and a future recurrence trigger rather than claiming permanent freedom from memory faults.

### Guided practice

A drive reports life-used values of 40% and 46% thirty days apart under a stable measured workload. A planner says this guarantees exactly 270 days remain. What is a defensible interpretation?

**Hint:** Calculate the straight-line estimate, then distinguish it from a guaranteed lifetime.

**Worked solution:** The observed change is 6 percentage points per 30 days, or 0.2 points/day. A simple projection to 100% gives (100 − 46)/0.2 = 270 days under unchanged assumptions. It is a planning estimate only; check the exact vendor indicator definition, workload stability, endurance limits, errors, spare lead time and required safety margin. Schedule evidence-based maintenance review and monitor the trend instead of promising a failure date.

#### L-HW-07-Q1 — A replaced server board leaves a new BMC identity but the asset system retains the old identity without explanation. What must happen?

1. Ignore it because the hostname is unchanged.
2. Reconcile the physical, management, support and asset records with the authorised replacement.
3. Change the hardware’s identity arbitrarily to match the spreadsheet.
4. Delete the maintenance history.

**Answer:** 2

- Option 1: Hostname continuity does not resolve hardware identity and support traceability.
- Option 2: The record must connect old and new components and the actual service.
- Option 3: Identity should be accurately recorded, not fabricated.
- Option 4: History explains the change and is needed for later review.

#### L-HW-07-Q2 — A cumulative counter falls from 900 to 4 after a reboot. How should the rate calculation handle it?

1. Report −896 errors as a health improvement.
2. Mark the reset and start a new comparable interval.
3. Add 900 fictional errors to preserve the graph.
4. Assume the sensor is permanently unusable.

**Answer:** 2

- Option 1: Negative errors are an artefact of crossing a reset boundary.
- Option 2: Counter semantics and reset context are needed for meaningful rates.
- Option 3: Fabricated events would corrupt the record.
- Option 4: The sensor may remain useful once its reset behaviour is handled.

#### L-HW-07-Q3 — Corrected ECC events accelerate at one reported location. Which statement is best?

1. Corrected events never require investigation.
2. Replace after exactly ten events on every platform.
3. Investigate mapping, trends and competing causes using applicable OEM guidance.
4. Disable ECC reporting to restore a green dashboard.

**Answer:** 3

- Option 1: Correction does not establish that continued deterioration is harmless.
- Option 2: Universal thresholds ignore model-specific reporting and guidance.
- Option 3: The decision needs actual event context and supported interpretation.
- Option 4: Suppressing evidence does not resolve the underlying condition.

#### L-HW-07-Q4 — A drive is deteriorating while its array is already degraded. Which factors should influence maintenance priority? Select all that apply.

1. Remaining protection and data-service consequence
2. Suitable spare lead time and verified independent recovery
3. Only whether the supplier has a generally strong reliability reputation
4. Only whether the dashboard average is green

**Answer:** 1, 2

- Option 1: The same warning has different consequence when protection is reduced.
- Option 2: Repair and recovery capability affect exposure and the appropriate schedule.
- Option 3: General reputation does not establish the current device condition, exposure or recovery route.
- Option 4: Averages and status summaries can hide the relevant deterioration.

#### L-HW-07-Q5 — A compliance report labels every device below the newest firmware noncompliant. What is missing?

1. A supported approved baseline, applicable advisories and reviewed exceptions per configuration
2. A more frequent scan that still compares only with the newest release
3. Permission to bypass all staging tests
4. A universal rule that older firmware is always safer

**Answer:** 1

- Option 1: Compliance is against the approved supported requirement, informed by actual risk and dependencies.
- Option 2: Frequency does not correct the missing supported, configuration-specific baseline.
- Option 3: Staging remains important for controlled change.
- Option 4: Neither old nor new is inherently appropriate without context.

#### L-HW-07-Q6 — No warning recurs after maintenance, but telemetry collection stopped during the same period. What can be accepted?

1. The maintenance has conclusively eliminated the fault.
2. Only that no observations were collected; restore monitoring and complete the defined retest.
3. The absence of data is proof of zero errors.
4. All future maintenance can be cancelled.

**Answer:** 2

- Option 1: No observation cannot establish absence of recurrence.
- Option 2: The effectiveness criterion remains untested until valid monitoring resumes.
- Option 3: Zero and missing data have different meanings.
- Option 4: Future plans require evidence, not an observability gap.

### Independent assignment

Environment: physical_lab

Run a hardware operating campaign with normal checks, a deterioration event, a reviewed correction and an effectiveness review; retain actual monitoring and physical records.

**Steps**

- Reconcile physical/management/CMMS inventory and the approved firmware, support and spare baseline.
- Define daily checks, collection coverage, counter semantics and model-specific escalation criteria.
- Collect an operating history and introduce an authorised alert condition or clearly labelled supplied event trace.
- Investigate competing causes and justify the maintenance/continue/escalate decision.
- Review and perform a supported firmware/configuration correction or link the authorised physical repair package.
- Retest function and recurrence under comparable conditions; update inventory, procedures and capacity records.

**Deliverables**

- Operating and inventory history
- Deterioration trend with raw events and observation coverage
- Reviewed change/maintenance record
- Effectiveness, recurrence and measured-improvement assessment
- Engineering decision record: requirement and source/version; approved design or method; observations and raw evidence; consequence; accept/proceed, permitted conditional acceptance, reject/hold or escalate; correction/retest; competence and authority boundary.

**Acceptance Criteria**

- Missing values and counter resets are handled explicitly.
- The maintenance decision uses model-specific evidence and the current protection state.
- A reviewed change includes supported recovery and post-change tests.
- The claimed improvement is measured without violating another requirement.

App study and synthetic decisions are learning evidence only. Perform physical tasks on authorised equipment using the exact OEM procedure and qualified supervision where required. Record unavailable hardware and unperformed tests as open requirements. Neither a paper review nor an emulator establishes physical competence or production authority.

### Sources

- [Linux kernel — EDAC event concepts](https://docs.kernel.org/driver-api/edac.html)
- [NVIDIA GPU debug guidelines](https://docs.nvidia.com/deploy/gpu-debug-guidelines/index.html)
- [DMTF Redfish education](https://redfish.dmtf.org/education)

## L-HW-08 — Replace components without losing the service boundary

Overview · Target topic stage: Advanced · 70 estimated overview study minutes · Prerequisites: L-HW-07, L-HW-04

Review maintenance states and perform a real authorised FRU replacement with identity, compatibility and return-to-service evidence.

### Learning objectives

- Assess service exposure and authority before a hardware maintenance action.
- Identify a supported FRU and model-specific hot or cold replacement method.
- Verify the intended component and isolation state before removal.
- Coordinate drive, memory, NIC, fan, PSU and accelerator replacement differences.
- Reject an incompatible part or unsupported replacement proposal.
- Accept return to service only after physical and functional retesting.

A field-replaceable unit is a component designed to be replaced through a specified service process. The term does not mean that every person may replace it in every operating state. Begin by identifying the failed or suspect part, the required service, the current protection state and the authority for the proposed work. Review workload migration, application shutdown, operator coordination and the independent recovery route. A technically correct component replacement can still violate the service requirement if it is performed while another dependency is already unavailable.

**Select the method from the exact model documentation.** Hot-swap capability depends on the component, chassis, configuration and supported procedure. A release handle or front-access position does not prove that removal while energised is permitted. A PSU module may be replaceable while another supported supply carries the load, while a DIMM or accelerator in the same chassis may require shutdown and isolation. Record the prerequisites, waiting periods, ESD arrangements, lifting requirements and trained-personnel roles. Do not open sealed PSU internals or hazardous electrical assemblies as part of a server-module exercise.

Check the spare before the window. Confirm OEM part number or formally supported substitute, hardware revision, capacity, speed/type, firmware constraints and accessory requirements. Similar appearance can conceal different fan direction, power rating, sector format, memory population rules or NIC functionality. Record where the spare came from, its identity and inspection result. A replacement drive that is nominally “the same size” may still fail the controller's actual capacity or supported-model requirement. A spare whose required firmware cannot be installed through the planned procedure is not ready merely because it is on the shelf.

**Verify the target using more than one clue.** Match the asset, chassis, physical slot or bay and component serial/identifier to the authorised work order and current diagnostic evidence. Use the supported identify function where available and confirm what the indicator means on this model. Do not remove a drive solely because someone remembers which light was flashing yesterday. Record the pre-maintenance baseline and stop if the physical identity differs from the plan. When the procedure requires isolation, establish and verify it through the approved method; a guest OS shutdown does not necessarily remove standby power or BMC operation.

Different component classes create different dependencies. A drive replacement may leave the group degraded until rebuild and integrity checks complete. Memory replacement can alter capacity, channel population and platform settings; verify the resulting supported layout. A NIC or HBA replacement can change MAC/WWN identities, driver behaviour, storage access or network admission. Fans require correct airflow and supported operation during any permitted removal interval. PSU modules require sufficient remaining supported capacity at the actual operating conditions. Accelerator replacement may involve power cabling, mechanical support, interconnect topology and, for selected hardware, qualified liquid-interface work.

Perform the authorised method with the specified supervision and handling controls. Keep removed parts identified and protected, separate failed parts from ready spares, and retain custody when they may contain data or credentials. A returned drive or controller cache may require the retirement process before leaving organisational control. Record any deviation and its approval rather than reconstructing an idealised checklist afterward. If the available lab allows only a fan replacement, that real activity is valuable, but memory, storage, accelerator and other required classes remain open where their physical assessments have not been demonstrated.

**Return to service is a test campaign.** Verify physical seating, locks, cable routing and any required covers or airflow arrangement. Confirm BMC and host inventory, component health, supported firmware, restored capacity and absence of relevant new errors. Re-establish identities, storage paths and network permissions through the approved process. Run the required functional workload and maintenance-state tests. A replacement acknowledged by the BMC is not enough if the server now has half its required RAM or the application cannot reach its storage.

Record the new baseline and watch for recurrence over the defined period. Update the asset system, spare inventory, warranty/support case, cable records and runbook where affected. Compare the accepted result with the initial diagnosis: did replacement resolve the measured fault, or did the same symptom persist because the cause was elsewhere? Reject a plausible incompatible-part or unsupported hot-swap proposal on paper, then evaluate the corrected method without executing the unsafe proposal. The work package closes through actual authorised replacement, measured restored function and a reviewed engineering decision, not through a knowledge quiz or a photograph of an unused spare.

### Worked example

**A hot-swap proposal fails the capacity check.** In a synthetic node, two supported PSU modules are installed. Under the stated operating conditions each can supply 1.2 kW at its DC output, while the required workload produces a measured combined DC load of 1.5 kW at those outputs. The work order proposes removing one module while the workload continues, claiming “two supplies means either can always be removed.”

Hold that proposal. Remaining DC output capacity would be 1.2 kW, below the 1.5 kW DC load; the model's detailed power-redundancy and derating rules also need checking. Arrange an approved service reduction or shutdown and follow the exact OEM replacement method. If a different supported design provides adequate remaining capacity, validate it rather than assuming it. After replacement, verify both module identities, expected health, actual feed assignments and the required workload/function. Acceptance must cover both the physical module work and the restored service state.

### Guided practice

An approved NIC replacement introduces a new MAC address. The host detects the NIC and its link is up, but network admission rejects it and the management service remains unavailable. Is the task ready for closure?

**Hint:** Trace the changed identity through its required external dependencies.

**Worked solution:** No. Physical detection and link are intermediate checks. Confirm the supported card/driver/configuration, update the authorised admission and inventory records through the approved process, test intended and denied access, and verify the management service. Record the new identity and passing service/path tests before acceptance. Do not disable admission controls globally to hide the missing integration.

#### L-HW-08-Q1 — A server has a suspect fan while another required cooling component is already unavailable. What should the work order evaluate first?

1. Only the fan’s purchase price
2. Current service exposure, permitted maintenance state and authorised supported method
3. How quickly a technician can pull the module
4. Whether the technician has completed a similar repair on another model

**Answer:** 2

- Option 1: Cost alone does not establish whether the current state permits the work.
- Option 2: Existing degradation changes the consequence and permissible method.
- Option 3: Speed does not replace a safe supported maintenance plan.
- Option 4: Past experience does not establish that this model and current degraded state permit the proposed work.

#### L-HW-08-Q2 — A memory module has an accessible latch. Does this establish hot-swap permission?

1. Yes, because accessible parts are always hot-swappable.
2. No; the exact model and configuration procedure determines the required state.
3. Yes, if the BMC remains reachable.
4. No memory module can ever be serviced by anyone.

**Answer:** 2

- Option 1: Mechanical accessibility does not establish live-removal support.
- Option 2: Use the supported procedure and verify isolation where required.
- Option 3: BMC reachability does not prove a memory-service state is permitted.
- Option 4: Authorised supported service is possible, but not inferred from appearance.

#### L-HW-08-Q3 — The identify light indicates bay 4 but the work order lists the serial now observed in bay 5. What should happen?

1. Pull bay 4 immediately.
2. Pull both bays to avoid ambiguity.
3. Stop and reconcile current physical identity and diagnostic evidence before removal.
4. Edit the work order afterward to match whichever part was removed.

**Answer:** 3

- Option 1: The conflicting identity must be resolved before action.
- Option 2: Removing additional parts can destroy remaining protection.
- Option 3: Multiple identifiers prevent an avoidable wrong-component removal.
- Option 4: Retrospective edits do not authorise the action or resolve the initial discrepancy.

#### L-HW-08-Q4 — A replacement HBA is detected by the OS but has a new WWN. What remains to be checked?

1. Only that the replacement was supplied in OEM packaging
2. Approved storage access, mapping, multipath behaviour and actual application I/O
3. Only whether the server boots
4. Nothing; HBA identities never affect storage access

**Answer:** 2

- Option 1: Provenance matters, but it does not demonstrate storage identity, mapping and actual I/O.
- Option 2: Changed identity can affect access and integration despite successful enumeration.
- Option 3: Boot may use a different path from the required application storage.
- Option 4: Storage access often depends on initiator identity and configuration.

#### L-HW-08-Q5 — A required workload draws 1.5 kW at the PSU DC outputs; either remaining PSU supplies at most 1.2 kW DC under the stated conditions. Which proposal is justified?

1. Remove one supply at full required load because two are installed.
2. Hold that live-removal plan and arrange a supported workload reduction or shutdown.
3. Ignore the measurements because the PSU is new.
4. Approve removal because the two installed nameplate ratings total 2.4 kW.

**Answer:** 2

- Option 1: The remaining supply cannot meet the stated demand.
- Option 2: The maintenance method must satisfy capacity and OEM operating rules.
- Option 3: Age does not change the demonstrated capacity requirement.
- Option 4: The maintenance state has only one remaining module; the original combined capacity is not available then.

#### L-HW-08-Q6 — Which evidence is needed after an authorised FRU replacement? Select all that apply.

1. Physical and inventory checks for the correct installed component
2. Required functional tests, restored protection and recurrence observation
3. Only the shipping receipt
4. Only a quiz score about the component

**Answer:** 1, 2

- Option 1: The record must show which part is actually installed and correctly integrated.
- Option 2: Return to service includes behaviour and the intended protection state.
- Option 3: A receipt proves procurement, not installation or recovery.
- Option 4: Knowledge evidence does not demonstrate physical work.

### Independent assignment

Environment: physical_lab

Perform one real authorised FRU replacement using the exact OEM method; plan and obtain supervised access for the remaining required component classes.

**Steps**

- Review the current service/protection state and decide whether the proposed maintenance is permissible.
- Watch the mandatory model-specific T-LAB-01 replacement demonstration; confirm scope and authority.
- Validate the spare and reconcile target identity using the supported method.
- Perform the real replacement with the required shutdown/isolation, ESD and supervision.
- Reconcile changed identities/configuration and run required function, protection and recurrence checks.
- Reject an incompatible or unsupported proposal in review, then approve the corrected method and record all unperformed physical classes.

**Deliverables**

- Authorised maintenance method and target/spare identity record
- Witnessed physical replacement evidence
- Pre/post configuration and functional test results
- Updated inventory/custody records and accept/hold/retest decision
- Engineering decision record: requirement and source/version; approved design or method; observations and raw evidence; consequence; accept/proceed, permitted conditional acceptance, reject/hold or escalate; correction/retest; competence and authority boundary.

**Acceptance Criteria**

- The learner performs actual authorised physical replacement, not only simulation.
- No hot-swap permission is inferred from appearance.
- Required service and protection are restored and tested.
- Unperformed drive, memory, NIC, fan, PSU or accelerator requirements remain explicitly open as applicable.

App study and synthetic decisions are learning evidence only. Perform physical tasks on authorised equipment using the exact OEM procedure and qualified supervision where required. Record unavailable hardware and unperformed tests as open requirements. Neither a paper review nor an emulator establishes physical competence or production authority.

### Sources

- [Dell — model-specific manuals selector](https://www.dell.com/support/home/en-us?app=manuals)
- [NVIDIA AI Rack and Interconnect learning route](https://www.nvidia.com/en-us/learn/certification/ai-rack-and-interconnect-professional/)

## L-HW-09 — Restore trustworthy hardware service and execute a refresh

Overview · Target topic stage: Advanced · 70 estimated overview study minutes · Prerequisites: L-HW-08, L-HW-05, DC-17

Recover from host, controller, boot, firmware or management loss while testing unavailable dependencies and remaining administrative authority.

### Learning objectives

- Define restoration objectives and a dependency-aware recovery sequence.
- Distinguish host, boot-media, controller, firmware and management failure routes.
- Preserve data and identity during supported configuration recovery.
- Restore trusted administrative authority as well as service availability.
- Plan refresh and migration around compatibility, reduced protection and fallback.
- Reject partial restoration claims using functional, integrity and timing evidence.

Recovery is an engineered sequence for restoring an agreed function after a defined failure. State what has failed, what remains trustworthy, the data-loss tolerance and the time objective. Identify the event that starts the clock and the acceptance criteria that stop it. A hardware refresh follows similar logic even when the old equipment has not failed: the service must move to a supported target without losing required data, authority or recovery options. Keep the failure and migration assumptions explicit so a successful easy exercise is not presented as proof for a harder scenario.

**Choose the route for the actual failure.** A failed boot device may require rebuilding the OS while preserving an intact separate data set. A failed host may require a replacement node with compatible drivers, firmware and device access. A controller failure can require a supported configuration-import or migration process rather than array initialisation. Management-plane loss can leave a host running but remove the normal console, power and firmware route. A failed firmware update may have a vendor recovery procedure or require OEM service; an unsupported downgrade is not a valid fallback just because the old package is available.

Preserve useful evidence before making irreversible changes. Record component identities, disk placement where relevant, configuration exports, logs, event times and symptoms. If compromise is suspected, coordinate incident response and containment while maintaining the required safety and operational functions. Rebuilding immediately can destroy evidence or restore the same compromised administrative dependency. Select approved recovery media and packages, verify their provenance and integrity, and document why the source and credentials are trusted. A backup labelled “latest” is not automatically suitable if its origin, access or consistency is uncertain.

**Restore prerequisites without hidden loops.** Recovery may need power, network access, storage paths, DNS, time, identity, certificates, licences, database logs, backup catalogues and encryption keys. Build an ordered dependency map for the actual system. Identify which tasks can run in parallel and which must wait for a predecessor. Provide protected independent access to essential recovery material so the failed host is not the only place it can be obtained. During the assessment, deliberately make one authorised dependency unavailable and measure how the runbook handles that condition.

Data restoration depends on the type of source and failure. A copied filesystem, database backup and application export have different consistency and restore requirements. Follow the supported database/application method, recover the required point where supported, and validate both retained records and new transactions. Do not assume a RAID import or controller replacement proves application consistency. Preserve keys and identity material only through approved mechanisms, and rotate or replace compromised credentials as required. Motherboard, TPM or BMC replacement can change protected-key access or management identity; plan that effect before relying on the recovery path.

Availability and trust are separate acceptance dimensions. Verify that the intended operators and services can act, unauthorised or retired identities cannot, logs are useful, time is acceptable and management exposure matches the design. A newly installed BMC with a default account left enabled can make the application available while leaving recovery incomplete. A clean OS over an unassessed management plane may also fail the defined trust requirement. Use applicable NIST firmware-resiliency principles and the exact OEM capability to frame what protection, detection and recovery evidence is actually available; do not claim more attestation than the platform supports.

**Treat refresh as a controlled change.** Compare old and target hardware for processor features, memory, drivers, NIC/HBA identities, storage geometry, firmware, hypervisor/OS support, licences and facility envelopes. Establish backups and an accepted target before cutover, then define the permitted period of reduced redundancy. Specify a decision deadline and fallback route based on data consistency. Returning to the old server is not always safe after writes have continued on the new one; the plan must explain how the authoritative data set is selected and reconciled. Retain the old system securely until release criteria permit retirement.

Measure restoration as an end-to-end outcome. Include dependency delays, data verification and access testing in the elapsed time. Run representative required network or OT functions, check historical and current data, compare configuration with the approved baseline and confirm remaining protection. Report which objectives passed, failed or could not be tested. A recovery that exceeds the time objective may still teach valuable corrections, but it must not be relabelled passing by starting the clock late.

Close with a review that rejects a plausible partial-restoration claim and then accepts the corrected result against the same requirements. Update the runbook, recovery inventory and lessons from the failed dependency. Demonstrate a repeat or independent operator handover to expose hidden setup. The curriculum's advanced recovery requirement is therefore stronger than restoring a VM file: it requires usable service, correct data, supported hardware state and trustworthy administrative authority under the declared failure and evidence conditions.

### Worked example

**Recovery timing exposes a hidden dependency.** A synthetic requirement permits 60 minutes from host failure to accepted historian service. Replacement hardware preparation takes 15 minutes. Network/management preparation takes 12 minutes and can run in parallel, so the first phase finishes at minute 15. Data and application restoration then take 25 minutes, followed by 10 minutes of function and authority tests: the planned critical path is 15 + 25 + 10 = 50 minutes.

The exercise discovers that the backup encryption key is available only through the failed node's normal identity service. An authorised recovery process adds 20 minutes before data restoration can begin. Actual acceptance occurs at minute 70, so the time objective fails even though the restored service is correct. Hold the performance claim, establish the approved independently protected key-recovery route and repeat the same dependency-loss scenario. If accepted service then returns at minute 50 with intended access and data, accept that measured result while retaining the failed trial as evidence of the correction.

### Guided practice

A controller has been replaced and the array is online. The application reads current data, but the last day of historical records is missing and the old emergency administrator remains active despite a required revocation. Can “hardware recovery complete” be signed?

**Hint:** Compare the claim with the declared service, data-loss and authority criteria rather than the controller status.

**Worked solution:** No. Determine whether the missing history exceeds the approved data-loss tolerance, investigate the supported restore sources and recover/reconcile the required records. Revoke or replace the old administrative access through the approved procedure and verify intended and denied operations. Recheck protection and service function, then record elapsed time and acceptance only after all mandatory recovery dimensions pass.

#### L-HW-09-Q1 — Hardware preparation takes 15 minutes and network preparation 12 minutes in parallel; restore takes 25 minutes afterward and acceptance 10 more. What is the planned critical path?

1. 62 minutes
2. 50 minutes
3. 37 minutes
4. 25 minutes

**Answer:** 2

- Option 1: Adding both parallel tasks overstates their combined elapsed time.
- Option 2: max(15,12) + 25 + 10 = 50 minutes.
- Option 3: This omits a required phase or combines dependencies incorrectly.
- Option 4: Restoration alone excludes prerequisite and acceptance time.

#### L-HW-09-Q2 — After controller failure, the replacement utility offers to initialise all attached drives. The supported recovery procedure has not been checked. What should happen?

1. Initialise immediately to make the status green.
2. Hold the action, preserve identities/configuration evidence and obtain the supported recovery method.
3. Assume every controller imports every array automatically.
4. Discard the backup because physical disks are still present.

**Answer:** 2

- Option 1: Initialisation can destroy required configuration or data.
- Option 2: Controller recovery must preserve the relevant data and follow supported instructions.
- Option 3: Compatibility and import procedures vary.
- Option 4: Physical media survival does not establish readable or consistent data.

#### L-HW-09-Q3 — A replacement motherboard changes access to a TPM-sealed recovery secret. What should the plan have included?

1. An independently protected approved recovery-key route and a tested platform-change procedure
2. Only another copy of the same inaccessible encrypted file
3. A rule that all motherboard swaps preserve every key automatically
4. Publication of all recovery secrets in GitHub

**Answer:** 1

- Option 1: Platform changes can affect sealed access, so recovery dependencies must be arranged and tested.
- Option 2: Another inaccessible copy does not remove the dependency.
- Option 3: Protected-key behaviour depends on the implementation and policy.
- Option 4: Secrets require authorised protection, not public distribution.

#### L-HW-09-Q4 — The application works after rebuilding, but a default BMC administrator remains enabled contrary to requirements. What is the correct result?

1. Recovery is fully accepted because the web page loads.
2. Availability may be restored, but the required administrative-trust criterion remains open.
3. Delete all logs and ignore the account.
4. Disable every account including approved recovery access.

**Answer:** 2

- Option 1: Service availability alone does not meet the trust requirement.
- Option 2: Correct access and verify intended and denied operations before full acceptance.
- Option 3: Removing evidence does not correct the exposure.
- Option 4: Recovery must preserve approved control while removing unauthorised access.

#### L-HW-09-Q5 — A refresh plan says “switch back to the old node” after users have written new data on the target. What is missing?

1. Only the old node's successful pre-migration diagnostic result
2. A defined authoritative data set, consistency/reconciliation process and decision deadline
3. An unconditional assumption that both copies are identical
4. Permission to erase both nodes

**Answer:** 2

- Option 1: A healthy old node does not establish that its data remains authoritative after writes on the target.
- Option 2: Fallback after writes requires a supported data-consistency plan.
- Option 3: Post-cutover writes can make the old state stale.
- Option 4: Erasing both systems is not a recovery plan.

#### L-HW-09-Q6 — Which results are required before accepting the recovered hardware service? Select all that apply.

1. Required current and retained data, functional performance and remaining protection
2. Intended administrative authority and measured end-to-end restoration time
3. Only the first successful ping
4. Only a firmware installation-success message

**Answer:** 1, 2

- Option 1: These establish the required usable data service and hardware state.
- Option 2: Trust and time are independent mandatory dimensions of the recovery claim.
- Option 3: Ping cannot prove data, permissions or application function.
- Option 4: An update message does not establish full restoration.

### Independent assignment

Environment: physical_lab

Rebuild or replace a failed authorised lab node and restore its required service from approved sources, including an unavailable recovery dependency and a reviewed refresh/fallback decision.

**Steps**

- Define the failure, time/data objectives, trust criteria and evidence to preserve.
- Confirm supported routes for host/boot/controller/firmware/BMC failure on the chosen model.
- Prepare trusted media, configuration, protected keys and an independent access route.
- Execute the authorised rebuild/restoration while making one agreed dependency unavailable.
- Validate current/historical data, required function, remaining protection and administrative authority; measure full elapsed time.
- Correct the failed dependency, repeat the scenario and review a refresh plan including post-write fallback.

**Deliverables**

- Dependency-aware recovery and refresh plan
- Trusted-source and identity/configuration records
- Failed-dependency timeline and supported recovery evidence
- Functional/integrity/authority acceptance with correction and repeat result
- Engineering decision record: requirement and source/version; approved design or method; observations and raw evidence; consequence; accept/proceed, permitted conditional acceptance, reject/hold or escalate; correction/retest; competence and authority boundary.

**Acceptance Criteria**

- A real authorised node is rebuilt or replaced and its required service recovered.
- An unavailable dependency is tested rather than silently prepared in advance.
- Data, function, support/protection and administrative trust pass their independent criteria.
- Measured recovery objectives are reported honestly, including failed trials and limits.

App study and synthetic decisions are learning evidence only. Perform physical tasks on authorised equipment using the exact OEM procedure and qualified supervision where required. Record unavailable hardware and unperformed tests as open requirements. Neither a paper review nor an emulator establishes physical competence or production authority.

### Sources

- [NIST SP 800-193 — platform firmware resiliency](https://csrc.nist.gov/pubs/sp/800/193/final)
- [PostgreSQL — backup and restore](https://www.postgresql.org/docs/current/backup.html)
- [Microsoft — AD forest recovery planning](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/manage/forest-recovery-guide/ad-forest-recovery-determine-how-to-recover)

## L-HW-10 — Relocate and retire hardware with verifiable custody

Overview · Target topic stage: Advanced · 70 estimated overview study minutes · Prerequisites: L-HW-09, DC-10

Keep required services intact while validating media sanitisation, management reset and the final asset disposition.

### Learning objectives

- Identify retained-service dependencies before relocation or retirement.
- Select an approved media-sanitisation method for the actual device and destination.
- Distinguish operation verification from the final sanitisation acceptance decision.
- Assess cryptographic-erase prerequisites and residual key dependencies.
- Remove management identities and reconcile custody beyond the main data disks.
- Release a retired asset only after evidence supports every required disposition criterion.

Relocation and retirement are controlled lifecycle changes. Begin by identifying the asset, its components, the data and credentials it may contain, and the services that still depend on it. A server marked “unused” can still host DNS, a licence service, a backup catalogue, a time source or the only approved recovery image. Confirm ownership and retention requirements with the responsible people before removing connections or destroying data. For a relocation, define the target rack, supported handling, power/network assignments, maintenance window and destination acceptance tests. For retirement, define the authorised final destination and evidence required before release.

**Protect the continuing service first.** Export and back up required configuration and data using supported methods, then validate their restoration to the intended retained environment. Move or remove service dependencies through approved changes. Reconcile clients, monitoring, support records, certificates, addressing and access permissions. A successful shutdown proves only that the old node stopped; it does not establish that the replacement service, historical records or emergency access still work. Keep the retirement action separate from the recovery acceptance so a premature disposal cannot remove the last usable rollback source.

Sanitisation decisions depend on the actual medium, information sensitivity, intended reuse or disposal, and the organisation's approved requirements. NIST SP 800-88 Rev. 2 is the curriculum's current reference. Its clear, purge and destroy categories represent different sanitisation outcomes and techniques; they are not interchangeable labels for deleting files. Select the permitted method using that guidance and the applicable device/OEM or referenced technical specification. Record the exact model, firmware, supported command or process and the reason it fits the disposition. This app supplies the reasoning exercise, not a universal destructive command for every device.

A host-visible overwrite may not reach every physical location on flash media because the device can remap storage internally. A filesystem format or deleted partition therefore does not automatically establish the required sanitisation result. Cryptographic erase can be suitable only when the applicable encryption and key-management prerequisites are established. Determine whether relevant data was encrypted as required, whether the implementation is trusted for the purpose, and whether usable key copies or related secrets remain elsewhere. Do not equate deleting an account password with sanitising all media-encryption keys. If the evidence cannot support the selected method, hold the release and choose an approved alternative.

**Verify the operation and validate the decision.** Operation status and errors show whether the approved process completed as intended; acceptance also considers whether that process was appropriate for the device and required protection. Retain supported tool logs, identifiers, operator, time, method and anomalies. Perform the prescribed checks and review their limitations rather than assuming that reading one empty directory proves the entire device is sanitised. A successful command against an unidentified drive cannot establish which asset was processed. Where destruction is required, use an authorised service and retain traceable evidence; do not claim to have witnessed a process that was only promised.

Retirement covers more than the main disks. BMC storage, configuration, remote-management accounts, certificates, logs, boot media, controller cache, removable devices and relevant licence/support records can matter. Use the supported reset or removal methods for the actual equipment, then verify the resulting management identity and access state. Revoke retired credentials and certificates through the relevant authority where required; merely disconnecting the cable leaves the credential valid elsewhere. Preserve any evidence or retained records that must remain available, but avoid copying unnecessary sensitive material into the portfolio.

Chain of custody connects each asset or medium to the process and destination. Record who held it, where it moved, when responsibility changed and which serial or other stable identifier was checked. Keep failed or incomplete sanitisation items segregated and clearly controlled. Reconcile the manifest with the sanitisation record and recipient acknowledgement before closing the work order. A batch total is insufficient when one serial is missing; the unidentified item may be the one that still contains data. Paperwork must describe the observed process, not substitute for it.

For a relocation, protect media and mechanical components during the approved move and repeat the required installation, inventory, path, health and service tests at the destination. Changes in power feeds, network identities, airflow or management access can invalidate assumptions that were true in the old rack. For retirement, release only when required service continuity, data disposition, credential removal, custody and asset-status criteria pass. Hold any unresolved item with an owner and next action.

The practical assessment uses sacrificial lab media and synthetic data, under explicit authorisation, so the learner performs and validates a real supported method without endangering required records. A paper critique is also mandatory: reject an inadequate retirement claim, identify the missing evidence, obtain the correction and justify the final accepted result. Where media, destruction service or qualified supervision is unavailable, leave that physical requirement open. The outcome is an auditable engineering decision about actual assets, not a quiz-generated assertion that unseen data has been destroyed.

### Worked example

**A complete-looking disposal batch is incomplete.** A synthetic manifest lists twelve drives, D01–D12, plus the server's BMC and boot device. Eleven sanitisation records match D01–D11; the twelfth record says only “one SSD passed.” A shipping receipt lists twelve drives, and the asset system marks the whole server retired. The BMC still accepts its previous emergency account.

Hold the release claim. Eleven matched records out of twelve data drives is 91.7% traceable coverage, but a percentage cannot authorise release of the unidentified drive. Reconcile D12's actual identity and custody, complete its approved process and obtain the matching verification/validation evidence. Apply the supported BMC reset and required credential revocation, then verify the resulting access state and boot-media disposition. Only after every required item and continuing-service check is accepted should the final custody and asset records close. The example does not claim that physical destruction occurred; that would require its own actual evidence.

### Guided practice

A sacrificial lab SSD is quick-formatted and now shows an empty filesystem. The proposed certificate says “all confidential data purged,” but there is no device model, sanitisation-method evidence or key-management assessment. How should the reviewer respond?

**Hint:** An empty filesystem is an observation with limited scope, not proof of a selected sanitisation outcome.

**Worked solution:** Reject the purge claim and keep the device controlled. Identify the exact SSD and approved disposition requirement; choose a supported method with applicable OEM/technical guidance, perform it on the authorised sacrificial device, retain completion/error records and carry out the required verification and validation. Record the supported conclusion and limitations, then reconcile identity and custody. Do not infer purge from a quick format or invent a universal command.

#### L-HW-10-Q1 — An old server is scheduled for retirement but holds the only backup catalogue and recovery key access path. What must happen first?

1. Destroy its disks to reduce clutter.
2. Move and test the required recovery dependencies through an approved process before release.
3. Mark the asset inactive and assume recovery is unaffected.
4. Copy the keys into a public portfolio document.

**Answer:** 2

- Option 1: Destruction would remove required continuing-service dependencies.
- Option 2: Retirement must preserve tested recovery capability before eliminating the old source.
- Option 3: Administrative status does not move the dependency.
- Option 4: Recovery material must remain protected through approved mechanisms.

#### L-HW-10-Q2 — A quick format leaves an SSD’s filesystem empty. Which claim is justified?

1. Every remapped physical location is proven sanitised.
2. The filesystem appears empty; the required sanitisation outcome still needs an approved supported method and evidence.
3. The device has definitely been physically destroyed.
4. All encryption keys everywhere have been revoked.

**Answer:** 2

- Option 1: Host-visible formatting does not establish all physical media coverage.
- Option 2: The observation is narrower than a sanitisation acceptance decision.
- Option 3: Formatting does not physically destroy the device.
- Option 4: Filesystem state does not establish external key or identity state.

#### L-HW-10-Q3 — A tool reports successful sanitisation but no device identifier was retained. What is missing?

1. Only a second screenshot of the same unidentified success message
2. Traceability that proves which required asset received the approved completed process
3. Permission to copy the same result to every asset
4. Nothing; one success message covers the whole batch

**Answer:** 2

- Option 1: Repeating an unbound result does not establish the device identity or asset traceability.
- Option 2: Process evidence must be tied to the actual device and disposition requirement.
- Option 3: Reusing one result would fabricate evidence for other assets.
- Option 4: A single unbound result cannot establish batch completion.

#### L-HW-10-Q4 — Before accepting a cryptographic-erase method, which factors matter? Select all that apply.

1. Whether the relevant data was protected by the required encryption and implementation
2. Whether usable relevant keys or copies remain accessible outside the erased location
3. Only whether the user account password changed
4. Only whether the disk label contains the word encrypted

**Answer:** 1, 2

- Option 1: The method relies on applicable encryption and implementation prerequisites.
- Option 2: Remaining usable key material can defeat the intended result.
- Option 3: An account password is not necessarily the data-encryption key or all of its copies.
- Option 4: A label is not evidence of the required cryptographic state.

#### L-HW-10-Q5 — All main data drives have accepted records, but the retired BMC still accepts its previous administrative account. What follows?

1. The complete asset retirement claim remains open until required management reset/revocation and verification are performed.
2. Disk sanitisation automatically disables every BMC account.
3. The account is harmless because a cable is currently unplugged.
4. Approve retirement because the next owner is expected to change the BMC password

**Answer:** 1

- Option 1: Retirement includes applicable residual management data and identity requirements.
- Option 2: The BMC is a separate management subsystem.
- Option 3: Disconnection does not revoke credentials or establish future access state.
- Option 4: A future expectation does not meet the current required reset and revocation criterion.

#### L-HW-10-Q6 — Eleven of twelve drives have matched accepted sanitisation records. One drive’s identity is unresolved. What is the appropriate batch disposition?

1. Round 91.7% to 100% and release every drive.
2. Hold the unresolved item and reconcile identity, method evidence and custody before its release.
3. Assume the missing drive is the safest one.
4. Claim physical destruction without observing or receiving traceable evidence.

**Answer:** 2

- Option 1: Percentages cannot waive an individual mandatory disposition requirement.
- Option 2: Each asset needs a supported traceable release decision.
- Option 3: No evidence supports that assumption.
- Option 4: Unseen or undocumented destruction cannot be claimed.

### Independent assignment

Environment: physical_lab

Use explicitly authorised sacrificial lab media and synthetic data to execute and validate a supported sanitisation method, then complete a whole-asset relocation/retirement review.

**Steps**

- Identify the actual assets/media, retained-service dependencies, authority and approved disposition requirement.
- Watch the decommissioning demonstration and study T-SEC-03B with the exact device/OEM sanitisation instructions.
- Prepare synthetic data on sacrificial media and obtain explicit lab authorisation for the destructive exercise.
- Execute the supported method, retain device-bound operation records and perform the prescribed verification/validation.
- Apply applicable BMC/configuration reset and identity revocation; reconcile custody and continuing-service checks.
- Reject an incomplete batch claim, correct missing evidence and obtain a reviewed release/hold decision; do not claim unseen disposal.

**Deliverables**

- Dependency and approved disposition plan
- Device-bound sanitisation method, operation and validation records
- Management reset/revocation and retained-service evidence
- Custody manifest and reviewed final asset decision
- Engineering decision record: requirement and source/version; approved design or method; observations and raw evidence; consequence; accept/proceed, permitted conditional acceptance, reject/hold or escalate; correction/retest; competence and authority boundary.

**Acceptance Criteria**

- The practical method is performed on authorised sacrificial media with synthetic data.
- Evidence identifies the actual device and supports the selected sanitisation outcome.
- Residual management identities/configuration and custody are reconciled.
- No asset is released on an unsupported percentage or unobserved destruction claim.

App study and synthetic decisions are learning evidence only. Perform physical tasks on authorised equipment using the exact OEM procedure and qualified supervision where required. Record unavailable hardware and unperformed tests as open requirements. Neither a paper review nor an emulator establishes physical competence or production authority.

### Sources

- [NIST SP 800-88 Rev. 2 — media sanitisation](https://csrc.nist.gov/pubs/sp/800/88/r2/final)
- [NIST SP 800-88 Rev. 2 — full publication](https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-88r2.pdf)
- [Dell — model-specific manuals selector](https://www.dell.com/support/home/en-us?app=manuals)
