# Full-course authoring contract

Course files live in `content/academy/CODE.json`. Existing overview IDs remain unchanged.
Each course is independently authored from public primary sources and the user's
curriculum, without copying paid courses or actual examination questions.

Required JSON shape:

```json
{
  "schema_version": 1,
  "id": "CODE",
  "title": "Course title",
  "kind": "exam_preparation",
  "blueprint": {"title":"Source scope", "version":"version or public outline checked date", "checked_on":"2026-09-19", "url":"https://...", "scope_note":"What is and is not verified", "limitations":[]},
  "prerequisites": {"course_ids":[], "overview_ids":[], "external":[]},
  "objectives": [{"id":"CODE-O01", "text":"Atomic assessable objective", "source_ref":"Actual source section; authored ID if provider supplies no ID", "module_ids":["CODE-M01"], "lesson_ids":["CODE-L01"], "capability_ids":["NET-03"], "coverage":"authored"}],
  "modules": [{"id":"CODE-M01", "title":"Module title", "objective_ids":["CODE-O01"], "lesson_ids":["CODE-L01"]}],
  "lessons": [{"id":"CODE-L01", "module_id":"CODE-M01", "title":"Focused lesson", "objective_ids":["CODE-O01"], "prerequisites":[], "minutes":45, "body":"Detailed original Markdown teaching", "worked_examples":[{"title":"Example", "scenario":"Supplied facts/config/output", "solution":"Stepwise mechanism and reasoning"}], "guided_practice":{"prompt":"Exercise", "hint":"Hint", "solution":"Worked solution"}, "independent_task":{"environment":"analytical / emulator / vendor / physical", "brief":"Task", "starter_artifacts":[], "deliverables":[], "acceptance_criteria":[], "limitations":"Fidelity and external access"}, "sources":[{"title":"Primary reference", "url":"https://..."}], "cards":[{"id":"CODE-L01-C01", "front":"Prompt", "back":"Answer", "tags":["CODE"]}]}],
  "questions": [{"id":"CODE-Q0001", "module_id":"CODE-M01", "objective_id":"CODE-O01", "lesson_ids":["CODE-L01"], "type":"single", "prompt":"Question", "exhibit":"Optional supplied configuration, table or log", "options":["A","B","C","D"], "correct":[1], "explanations":["Why A", "Why B", "Why C", "Why D"], "difficulty":"foundation / applied / advanced", "cognitive_skill":"mechanism / implementation / calculation / diagnosis / design / operations / recovery", "case_id":"Optional shared testlet identity"}],
  "sources":[{"title":"Primary source", "url":"https://..."}],
  "external_requirements":["Actual provider course/exam or physical access requirements"]
}
```

`kind` may be `engineering_extension` for a noncredential curriculum course, or `milestone_integration` for ISA Expert. It is an integration review
bank, never a fabricated extra provider exam. Question types are `single`, `multi`
and `order`; `correct` always contains zero-based option indices. For `order`,
all options must appear once in the correct sequence. Assessments persist the
actual selected index sequence. Optional exhibits must be marked synthetic where
not captured from a real lab. Do not claim commands or software were executed
unless they actually were. Include product/version assumptions for configurations.

At least 500 independently meaningful questions per credential bank. Do not
inflate counts using wording, host-name, option-order or numeric substitutions.
Shared testlets are encouraged when each question assesses a different decision
from the supplied evidence. Every answer needs specific reasoning and plausible
distractors. At least substantial diagnostic/implementation/design assessment must
use configurations, event records, calculations, diagrams or concrete case data.
No actual exam questions or exam dumps.

No arbitrary word cap or fixed number of lessons per outcome. Split large domains
into the modules and chapters needed to teach them. An external course link is
not authored instruction. Each objective needs mechanisms, appropriate worked
demonstration, guided practice and a meaningful independent assessment. Retain
vendor courses and external practical gates without using them to disguise missing
theoretical teaching. Record uncertainty and unresolved source access explicitly.

Optional local lab assets go in `course_labs/CODE/`, with instructions and a
standard-library Python check where appropriate. Never connect to live equipment.
Purely simulated outputs are labelled; field/production claims require real work.
