"""Pure learning operations, validated progress, and portable Anki exports.

Learning progress describes study activity. It is never a certification award,
authorization to operate equipment, or evidence of production competence.
"""

from __future__ import annotations

import copy
import csv
import hashlib
import html
import io
import json
import re
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

MAX_PROGRESS_BYTES = 16 * 1024 * 1024
MAX_ATTEMPTS = 20000
MAX_RESULTS = 200
SCHEMA_VERSION = 1
CONTENT_DIR = Path(__file__).resolve().parent.parent / "content"
_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:\-/]{0,127}$")
_FIELDS = {"schema_version", "revision", "completed", "attempts", "reviews", "evidence", "credentials"}
EVIDENCE_ENVIRONMENTS = ("analytical", "simulation", "emulation", "vendor_simulation", "physical_lab", "supervised_field", "production")
EVIDENCE_REVIEW_STATUSES = ("self_reported", "awaiting_review", "reviewed")


def _fail(message: str) -> None:
    raise ValueError(message)


def _text(value: Any, name: str, maximum: int = 500, allow_empty: bool = False) -> str:
    if not isinstance(value, str) or len(value) > maximum or (not allow_empty and not value.strip()):
        _fail(f"{name} must be {'a possibly empty' if allow_empty else 'a nonempty'} string of at most {maximum} characters.")
    return value


def _identifier(value: Any, name: str) -> str:
    if not isinstance(value, str) or not _ID.fullmatch(value):
        _fail(f"{name} must be a valid identifier (letters, digits, _, -, ., :, /; at most 128 characters).")
    return value


def _integer(value: Any, name: str, minimum: int = 0, maximum: int = 10**12) -> int:
    if type(value) is not int or not minimum <= value <= maximum:
        _fail(f"{name} must be an integer between {minimum} and {maximum}.")
    return value


def _list(value: Any, name: str, maximum: int) -> list:
    if not isinstance(value, list) or len(value) > maximum:
        _fail(f"{name} must be a list with at most {maximum} entries.")
    return value


def _timestamp(value: Any, name: str) -> str:
    _text(value, name, 64)
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        _fail(f"{name} must be an ISO 8601 timestamp.")
    if parsed.tzinfo is None:
        _fail(f"{name} must include a timezone, such as +00:00 or Z.")
    return value


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def default_progress() -> dict:
    return {"schema_version": SCHEMA_VERSION, "revision": 0, "completed": [], "attempts": [], "reviews": {}, "evidence": [], "credentials": []}


def _validate_attempt(value: Any) -> dict:
    if not isinstance(value, dict):
        _fail("Each attempt must be an object.")
    required = {"id", "timestamp", "mode", "question_ids", "answers", "results", "score", "total"}
    if set(value) != required:
        _fail("An attempt must contain exactly: " + ", ".join(sorted(required)) + ".")
    _identifier(value["id"], "Attempt ID")
    _timestamp(value["timestamp"], "Attempt timestamp")
    _text(value["mode"], "Attempt mode", 64)
    ids = _list(value["question_ids"], "Question IDs", MAX_RESULTS)
    for item in ids:
        _identifier(item, "Question ID")
    if len(ids) != len(set(ids)):
        _fail("An attempt cannot contain duplicate question IDs.")
    if not isinstance(value["answers"], dict) or set(value["answers"]) != set(ids):
        _fail("Attempt answers must contain exactly its question IDs.")
    for qid, selected in value["answers"].items():
        _list(selected, f"Answer for {qid}", 32)
        for index in selected:
            _integer(index, "Answer index", 0, 31)
        if len(selected) != len(set(selected)):
            _fail("Answer selections must not contain duplicate indexes.")
    results = _list(value["results"], "Attempt results", MAX_RESULTS)
    found = []
    for result in results:
        if not isinstance(result, dict) or set(result) != {"question_id", "lesson_id", "objective", "correct"}:
            _fail("Each result must contain question_id, lesson_id, objective, and correct.")
        found.append(_identifier(result["question_id"], "Result question ID"))
        _identifier(result["lesson_id"], "Result lesson ID")
        _text(result["objective"], "Result objective", 300)
        if type(result["correct"]) is not bool:
            _fail("Result correct must be true or false.")
    if len(found) != len(set(found)) or set(found) != set(ids):
        _fail("Attempt results must match its question IDs exactly once each.")
    _integer(value["total"], "Attempt total", 1, MAX_RESULTS)
    _integer(value["score"], "Attempt score", 0, value["total"])
    if value["total"] != len(ids) or value["score"] != sum(r["correct"] for r in results):
        _fail("Attempt score and total must match its individual results.")
    return copy.deepcopy(value)


def _validate_evidence(value: Any) -> dict:
    required = {"id", "timestamp", "title", "environment", "review_status"}
    optional = {"lesson_id", "notes", "url"}
    if not isinstance(value, dict) or not required.issubset(value) or set(value) - required - optional:
        _fail("Evidence requires id, timestamp, title, environment, review_status; optional fields: lesson_id, notes, url.")
    _identifier(value["id"], "Evidence ID")
    _timestamp(value["timestamp"], "Evidence timestamp")
    _text(value["title"], "Evidence title", 200)
    if value["environment"] not in EVIDENCE_ENVIRONMENTS:
        _fail("Evidence environment must be one of: " + ", ".join(EVIDENCE_ENVIRONMENTS))
    if value["review_status"] not in EVIDENCE_REVIEW_STATUSES:
        _fail("Evidence review status must be one of: " + ", ".join(EVIDENCE_REVIEW_STATUSES))
    if "lesson_id" in value and value["lesson_id"]:
        _identifier(value["lesson_id"], "Evidence lesson ID")
    if "notes" in value:
        _text(value["notes"], "Evidence notes", 6000, allow_empty=True)
    if "url" in value:
        _text(value["url"], "Evidence URL", 2000, allow_empty=True)
        if value["url"] and urlparse(value["url"]).scheme not in ("https", "http"):
            _fail("Evidence links must use https:// or http://.")
    return copy.deepcopy(value)


def normalize_progress(payload: dict | str | bytes) -> dict:
    """Validate untrusted backup/device data without silently coercing errors.

    Bounded lists/strings protect import and rendering. Schema v1 is exact;
    unknown fields and future schemas require an explicit migration.
    """
    if isinstance(payload, bytes):
        if len(payload) > MAX_PROGRESS_BYTES:
            _fail("Progress backup exceeds the 16 MB limit.")
        try:
            payload = payload.decode("utf-8-sig")
        except UnicodeDecodeError:
            _fail("Progress backup must use UTF-8 encoding.")
    if isinstance(payload, str):
        if len(payload.encode("utf-8")) > MAX_PROGRESS_BYTES:
            _fail("Progress backup exceeds the 16 MB limit.")
        try:
            payload = json.loads(payload)
        except (json.JSONDecodeError, RecursionError):
            _fail("Progress backup is not valid JSON.")
    if not isinstance(payload, dict):
        _fail("Progress backup must be a JSON object.")
    try:
        size = len(json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8"))
    except (ValueError, TypeError, RecursionError):
        _fail("Progress contains unsupported or invalid JSON values.")
    if size > MAX_PROGRESS_BYTES:
        _fail("Progress backup exceeds the 16 MB limit.")
    if type(payload.get("schema_version")) is not int or payload.get("schema_version") != SCHEMA_VERSION:
        _fail("Unsupported progress schema. This application accepts schema_version 1.")
    if set(payload) != _FIELDS:
        _fail("Progress fields do not match schema 1. Required fields: " + ", ".join(sorted(_FIELDS)))
    _integer(payload["revision"], "Progress revision")
    for field, maximum in (("completed", 10000), ("credentials", 100)):
        entries = _list(payload[field], field, maximum)
        for value in entries:
            _identifier(value, field + " identifier")
        if len(entries) != len(set(entries)):
            _fail(f"{field} must not contain duplicate IDs.")
    attempts = _list(payload["attempts"], "Attempts", MAX_ATTEMPTS)
    attempt_ids = set()
    for attempt in attempts:
        _validate_attempt(attempt)
        if attempt["id"] in attempt_ids:
            _fail("Progress contains a duplicate attempt ID.")
        attempt_ids.add(attempt["id"])
    reviews = payload["reviews"]
    if not isinstance(reviews, dict) or len(reviews) > 10000:
        _fail("Reviews must be an object with at most 10000 cards.")
    for card_id, review in reviews.items():
        _identifier(card_id, "Review card ID")
        if not isinstance(review, dict) or set(review) != {"rating", "last_reviewed", "due", "interval_days", "count"}:
            _fail("Each review requires rating, last_reviewed, due, interval_days, count.")
        if review["rating"] not in ("again", "hard", "good", "easy"):
            _fail("Review rating must be again, hard, good, or easy.")
        _timestamp(review["last_reviewed"], "Last review")
        _timestamp(review["due"], "Review due date")
        interval = review["interval_days"]
        if type(interval) not in (int, float) or not 0 < interval <= 36500:
            _fail("Review interval_days must be a positive number no greater than 36500.")
        _integer(review["count"], "Review count", 1, 1000000)
    evidence = _list(payload["evidence"], "Evidence", 1000)
    evidence_ids = set()
    for record in evidence:
        _validate_evidence(record)
        if record["id"] in evidence_ids:
            _fail("Progress contains duplicate evidence IDs.")
        evidence_ids.add(record["id"])
    return copy.deepcopy(payload)


def _bumped(progress: dict) -> dict:
    result = copy.deepcopy(progress)
    result["revision"] += 1
    return result


def mark_complete(progress: dict, lesson_id: str) -> dict:
    _identifier(lesson_id, "Lesson ID")
    if lesson_id in progress["completed"]:
        return copy.deepcopy(progress)
    result = _bumped(progress)
    result["completed"].append(lesson_id)
    return result


def record_attempt(progress: dict, attempt: dict) -> dict:
    clean = _validate_attempt(attempt)
    prior = next((item for item in progress["attempts"] if item["id"] == clean["id"]), None)
    if prior is not None:
        if prior != clean:
            _fail("An existing attempt ID cannot be reused for different results.")
        return copy.deepcopy(progress)
    if len(progress["attempts"]) >= MAX_ATTEMPTS:
        _fail("Attempt history reached 20000 entries. Export a backup before starting a new progress record.")
    result = _bumped(progress)
    result["attempts"].append(clean)
    return normalize_progress(result)


def add_evidence(progress: dict, record: dict) -> dict:
    item = copy.deepcopy(record)
    item.setdefault("timestamp", utc_now())
    item.setdefault("id", "ev-" + hashlib.sha256(json.dumps(item, sort_keys=True).encode()).hexdigest()[:20])
    item = _validate_evidence(item)
    if any(existing["id"] == item["id"] for existing in progress["evidence"]):
        _fail("Evidence ID already exists.")
    result = _bumped(progress)
    result["evidence"].append(item)
    return normalize_progress(result)


def add_credential(progress: dict, credential_id: str) -> dict:
    """Record a user's self-reported credential; never award one from quiz data."""
    _identifier(credential_id, "Credential ID")
    if credential_id in progress["credentials"]:
        return copy.deepcopy(progress)
    result = _bumped(progress)
    result["credentials"].append(credential_id)
    return result


def record_review(progress: dict, card_id: str, rating: str, now: str | None = None) -> dict:
    """Save a built-in flashcard rating and its next fixed-interval review date."""
    _identifier(card_id, "Card ID")
    if rating not in ("again", "hard", "good", "easy"):
        _fail("Review rating must be again, hard, good, or easy.")
    when = now or utc_now()
    _timestamp(when, "Review timestamp")
    reviewed = datetime.fromisoformat(when.replace("Z", "+00:00"))
    delay = {"again": timedelta(minutes=10), "hard": timedelta(days=1), "good": timedelta(days=3), "easy": timedelta(days=7)}[rating]
    result = _bumped(progress)
    result["reviews"][card_id] = {"rating": rating, "last_reviewed": when, "due": (reviewed + delay).isoformat(), "interval_days": delay.total_seconds() / 86400, "count": progress["reviews"].get(card_id, {}).get("count", 0) + 1}
    return result


def grade_question(question: dict, selected: list[int] | tuple[int, ...] | set[int]) -> bool:
    """Exact-set scoring for choices; exact-sequence scoring for ordered tasks."""
    if not isinstance(selected, (list, tuple, set)) or not selected:
        return False
    if any(type(index) is not int or index < 0 or index >= len(question["options"]) for index in selected):
        return False
    if len(selected) != len(set(selected)):
        return False
    if question.get("type") == "single" and len(selected) != 1:
        return False
    if question.get("type") == "order":
        return not isinstance(selected, set) and list(selected) == question["correct"]
    return set(selected) == set(question["correct"])


def load_lessons() -> list[dict]:
    lessons = []
    names = ["facility.json", "engineering.json", "network_advanced.json", "hardware_advanced.json",
             "controls_advanced.json", "security_advanced.json", "integration_advanced.json"]
    for name in names:
        path = CONTENT_DIR / name
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as error:
            raise ValueError(f"Could not read lesson catalog {name}: {error}") from error
        if not isinstance(data, list):
            _fail(f"{name} must contain an array of lessons.")
        lessons.extend(data)
    validate_catalog(lessons)
    return lessons


def validate_catalog(lessons: list[dict]) -> None:
    if not isinstance(lessons, list) or not lessons:
        _fail("The lesson catalog must be a nonempty array.")
    ids, questions, cards = set(), set(), {}
    for lesson in lessons:
        if not isinstance(lesson, dict):
            _fail("Each lesson must be an object.")
        lid = _identifier(lesson.get("id"), "Lesson ID")
        if lid in ids:
            _fail(f"Duplicate lesson ID: {lid}")
        ids.add(lid)
        for field in ("title", "domain", "level", "summary", "body", "worked_example"):
            _text(lesson.get(field), f"{lid}: {field}", 60000)
        if lesson["level"] not in ("Foundation", "Applied", "Advanced"):
            _fail(f"{lid}: unsupported proficiency level.")
        _integer(lesson.get("minutes"), f"{lid}: minutes", 1, 600)
        for field in ("objectives", "prerequisites", "certificates", "curriculum_refs", "lifecycle"):
            values = _list(lesson.get(field), f"{lid}: {field}", 100)
            if field == "objectives" and not values:
                _fail(f"{lid}: at least one objective is required.")
            for value in values:
                _text(value, f"{lid}: {field} entry", 500)
        practice = lesson.get("guided_practice")
        if not isinstance(practice, dict):
            _fail(f"{lid}: guided_practice must be an object.")
        for field in ("prompt", "hint", "solution"):
            _text(practice.get(field), f"{lid}: guided practice {field}", 20000)
        qlist = _list(lesson.get("questions"), f"{lid}: questions", 100)
        if not qlist:
            _fail(f"{lid}: at least one question is required.")
        for question in qlist:
            qid = _identifier(question.get("id"), f"{lid}: question ID")
            if qid in questions:
                _fail(f"Duplicate question ID: {qid}")
            questions.add(qid)
            for field in ("objective", "prompt", "difficulty"):
                _text(question.get(field), f"{qid}: {field}", 4000)
            if question.get("type") not in ("single", "multi"):
                _fail(f"{qid}: type must be single or multi.")
            options = _list(question.get("options"), f"{qid}: options", 32)
            explanations = _list(question.get("explanations"), f"{qid}: explanations", 32)
            if len(options) < 2 or len(options) != len(explanations):
                _fail(f"{qid}: provide at least two options and one explanation per option.")
            for option in options + explanations:
                _text(option, f"{qid}: option/explanation", 6000)
            correct = _list(question.get("correct"), f"{qid}: correct answers", 32)
            if not correct or len(correct) != len(set(correct)):
                _fail(f"{qid}: correct answer indexes must be nonempty and unique.")
            for index in correct:
                _integer(index, f"{qid}: correct index", 0, len(options) - 1)
            if question["type"] == "single" and len(correct) != 1:
                _fail(f"{qid}: a single-answer question must have exactly one correct option.")
        for card in _list(lesson.get("cards"), f"{lid}: cards", 200):
            cid = _identifier(card.get("id"), f"{lid}: card ID")
            for field in ("front", "back"):
                _text(card.get(field), f"{cid}: {field}", 10000)
            for tag in _list(card.get("tags"), f"{cid}: tags", 30):
                _text(tag, f"{cid}: tag", 200)
            signature = (card["front"], card["back"])
            if cid in cards and cards[cid] != signature:
                _fail(f"Conflicting flashcard content under ID {cid}.")
            cards[cid] = signature
        for source in _list(lesson.get("sources"), f"{lid}: sources", 100):
            _text(source.get("title"), f"{lid}: source title", 1000)
            _text(source.get("url"), f"{lid}: source URL", 2000)
            if urlparse(source["url"]).scheme not in ("https", "http"):
                _fail(f"{lid}: source links must use HTTPS or HTTP.")
    graph = {lesson["id"]: lesson["prerequisites"] for lesson in lessons}
    visiting, visited = set(), set()
    def visit(lid: str) -> None:
        if lid in visiting:
            _fail(f"Prerequisite cycle detected at {lid}.")
        if lid in visited:
            return
        visiting.add(lid)
        for dependency in graph[lid]:
            if dependency not in ids:
                _fail(f"{lid}: unknown prerequisite {dependency}.")
            visit(dependency)
        visiting.remove(lid)
        visited.add(lid)
    for lid in graph:
        visit(lid)


def objective_stats(lessons: list[dict], progress: dict) -> list[dict]:
    """Historical assessment results by exact domain and objective.

    Known question metadata is authoritative. Case-only IDs remain visible under
    Integrated cases instead of being silently attributed to unrelated lessons.
    """
    lesson_by_id = {lesson["id"]: lesson for lesson in lessons}
    question_by_id = {q["id"]: (lesson, q) for lesson in lessons for q in lesson["questions"]}
    grouped: dict[tuple[str, str], dict] = {}
    for attempt in progress["attempts"]:
        for result in attempt["results"]:
            known = question_by_id.get(result["question_id"])
            if known:
                lesson, question = known
                domain, objective, lid = lesson["domain"], question["objective"], lesson["id"]
            else:
                lid = result["lesson_id"]
                # A cross-domain case is assessed separately. Its prerequisite
                # lesson is a reading link, not evidence of the domain tested.
                domain = "Integrated cases"
                objective = result["objective"]
            key = (domain, objective)
            entry = grouped.setdefault(key, {"domain": domain, "objective": objective, "correct": 0, "total": 0, "accuracy": 0.0, "latest": attempt["timestamp"], "lesson_ids": set()})
            entry["correct"] += int(result["correct"])
            entry["total"] += 1
            entry["lesson_ids"].add(lid)
            if datetime.fromisoformat(attempt["timestamp"].replace("Z", "+00:00")) > datetime.fromisoformat(entry["latest"].replace("Z", "+00:00")):
                entry["latest"] = attempt["timestamp"]
    for entry in grouped.values():
        entry["accuracy"] = round(100 * entry["correct"] / entry["total"], 1)
        entry["lesson_ids"] = sorted(entry["lesson_ids"])
    return sorted(grouped.values(), key=lambda item: (item["accuracy"], item["domain"], item["objective"]))


def recommend_lessons(lessons: list[dict], progress: dict, limit: int = 3) -> list[dict]:
    """Recommend available lessons; recent wrong answers drive scoped revision.

    A lesson never inherits weakness merely because it shares a broad domain.
    Only its actual question IDs influence its diagnostic priority.
    """
    completed = set(progress["completed"])
    latest: dict[str, tuple[datetime, bool]] = {}
    for attempt in progress["attempts"]:
        when = datetime.fromisoformat(attempt["timestamp"].replace("Z", "+00:00"))
        for result in attempt["results"]:
            existing = latest.get(result["question_id"])
            if existing is None or when >= existing[0]:
                latest[result["question_id"]] = (when, result["correct"])
    candidates = []
    for order, lesson in enumerate(lessons):
        if not set(lesson["prerequisites"]).issubset(completed):
            continue
        attempted = [latest[q["id"]][1] for q in lesson["questions"] if q["id"] in latest]
        weakness = 1 - sum(attempted) / len(attempted) if attempted else 0
        done = lesson["id"] in completed
        if done and weakness < 0.2:
            continue
        if attempted and weakness >= 0.2:
            reason = "Review objectives missed in your latest answers."
            rank = (0, -weakness, order)
        else:
            reason = "Prerequisites complete; continue the guided learning path." if lesson["prerequisites"] else "Start here: no prerequisites required."
            rank = (1, 0, order)
        item = copy.deepcopy(lesson)
        item["recommendation_reason"] = reason
        item["recommendation_type"] = "review" if done else "learn"
        candidates.append((rank, item))
    return [item for _, item in sorted(candidates, key=lambda pair: pair[0])[:max(0, limit)]]


def _tag(value: str) -> str:
    return re.sub(r"[^\w:\-]", "_", value.strip(), flags=re.UNICODE)


def _html_text(value: str) -> str:
    return html.escape(value, quote=True).replace("\r\n", "\n").replace("\r", "\n").replace("\n", "<br>").replace("\t", "    ")


def _export_cards(lessons: list[dict]) -> list[dict]:
    result = {}
    for lesson in lessons:
        source = "; ".join(f'<a href="{html.escape(s["url"], quote=True)}">{_html_text(s["title"])}</a>' for s in lesson.get("sources", []))
        for card in lesson.get("cards", []):
            cid = card["id"]
            entry = {"id": cid, "front": _html_text(card["front"]), "back": _html_text(card["back"]), "sources": set(), "tags": set()}
            if cid in result:
                prior = result[cid]
                if (prior["front"], prior["back"]) != (entry["front"], entry["back"]):
                    _fail(f"Conflicting flashcard content under ID {cid}.")
                entry = prior
            if source:
                entry["sources"].add(source)
            entry["tags"].update(_tag(tag) for tag in card.get("tags", []))
            entry["tags"].update({_tag("lesson::" + lesson["id"]), _tag("domain::" + lesson["domain"]), _tag("level::" + lesson["level"])})
            entry["tags"].update(_tag("certificate::" + code) for code in lesson.get("certificates", []))
            result[cid] = entry
    return [dict(entry, source="<br>".join(sorted(entry["sources"])), tags=sorted(entry["tags"])) for entry in result.values()]


def flashcard_export(lessons: list[dict]) -> str:
    """UTF-8-ready TSV. Import into a note type with NoteID as its first field.

    NoteID is deliberately stable: import matching can update existing notes
    without creating duplicates, even after wording or certificate mappings change.
    """
    output = io.StringIO(newline="")
    output.write("#separator:tab\n#html:true\n#tags column:5\n#columns:NoteID\tFront\tBack\tSource\tTags\n")
    writer = csv.writer(output, delimiter="\t", lineterminator="\n")
    for card in _export_cards(lessons):
        writer.writerow([card["id"], card["front"], card["back"], card["source"], " ".join(card["tags"])])
    return output.getvalue()


def anki_package(lessons: list[dict]) -> bytes:
    """Create an import-ready deck with stable model, deck and note identities."""
    import genanki

    model = genanki.Model(
        1837642501,
        "Data Center Learning v1",
        fields=[{"name": name} for name in ("NoteID", "Front", "Back", "Source")],
        templates=[{"name": "Recall", "qfmt": '<div class="front">{{Front}}</div>', "afmt": '{{FrontSide}}<hr id="answer"><div class="back">{{Back}}</div><div class="source">{{Source}}</div>'}],
        css=".card{font-family:Arial,sans-serif;font-size:20px;text-align:left;color:#24221f;background:#faf8f4;line-height:1.5;padding:24px}.source{font-size:12px;color:#777;margin-top:24px}a{color:#b65830}hr{border:0;border-top:1px solid #d7d1c8;margin:22px 0}",
    )
    deck = genanki.Deck(1837642502, "Data Center")
    for card in _export_cards(lessons):
        deck.add_note(genanki.Note(model=model, fields=[card["id"], card["front"], card["back"], card["source"]], tags=card["tags"], guid=genanki.guid_for("datacenter.learning.v1", card["id"])))
    with tempfile.TemporaryDirectory() as temporary:
        target = Path(temporary) / "Data-Center.apkg"
        genanki.Package(deck).write_to_file(str(target))
        return target.read_bytes()
