"""A small offline-capable browser store; no learner files on the web server.

Call with outgoing=None until the component reports ready. Validate and hydrate
its progress once, then send current progress on each rerun. A write is confirmed
only when saved_revision equals the outgoing revision. external_change means a
different tab changed progress: hydrate that payload before making further edits.
"""

from pathlib import Path
from typing import Any

import streamlit.components.v1 as components

_component = components.declare_component(
    "datacenter_device_store",
    path=str(Path(__file__).resolve().parent.parent / "components" / "device_store"),
)


def render_device_store(outgoing: dict | None = None, key: str = "datacenter-device-store", restore_token: str | None = None) -> dict[str, Any] | None:
    """Render the store; a new restore_token permits one explicit replacement.

    Set restore_token only after the user requests a reset or after validating an
    imported backup. It recovers corrupt storage and resolves intentional restore
    operations without permitting routine reruns to overwrite newer tab state.
    """
    result = _component(outgoing=outgoing, restore_token=restore_token, key=key, default=None)
    return result if isinstance(result, dict) else None
