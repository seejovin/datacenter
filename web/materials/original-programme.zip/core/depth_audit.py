"""Authored teaching status is independent of links and learner checkpoints."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TEACHING_STATES = {"not_authored", "overview_only", "detailed_authored", "reviewed"}
ASSESSMENT_STATES = {"not_authored", "introductory_mcq_only", "detailed_authored", "reviewed"}


def load_depth_audit():
    return json.loads((ROOT / "content/course_depth_audit.json").read_text(encoding="utf-8"))


def validate_depth_audit(audit, lessons):
    by_id = {lesson["id"]: lesson for lesson in lessons}
    course_ids, requirement_ids = set(), set()
    for course in audit["courses"]:
        if course["id"] in course_ids:
            raise ValueError("Duplicate course identity")
        course_ids.add(course["id"])
        if type(course.get("full_blueprint_leaf_audit")) is not bool:
            raise ValueError("Record whether the full blueprint leaf audit has been performed")
        for requirement in course["requirements"]:
            rid = requirement["id"]
            if rid in requirement_ids:
                raise ValueError("Duplicate course requirement identity")
            requirement_ids.add(rid)
            links = requirement["current_lesson_ids"]
            if not set(links) <= by_id.keys():
                raise ValueError(f"{rid}: unresolved lesson link")
            if requirement["teaching_state"] not in TEACHING_STATES or requirement["assessment_state"] not in ASSESSMENT_STATES:
                raise ValueError(f"{rid}: unsupported content state")
            # A mapping to an overview cannot be promoted into full instruction.
            # Detailed content requires its own objective and artifact records.
            for field in ("teaching_state", "assessment_state"):
                if requirement[field] in {"detailed_authored", "reviewed"}:
                    detailed = requirement.get("detailed_lesson_ids", [])
                    if not detailed or not set(detailed) <= by_id.keys():
                        raise ValueError(f"{rid}: detailed content requires resolvable instructional lessons")
                    if any(by_id[lid].get("content_class", "overview") != "detailed_instruction" for lid in detailed):
                        raise ValueError(f"{rid}: overview lessons cannot establish detailed teaching or assessment")
                    if not requirement.get("objective_ids") or not requirement.get("artifact_ids"):
                        raise ValueError(f"{rid}: detailed content requires explicit objectives and artifacts")
                    for key, registry in (("objective_ids", "objective_register"), ("artifact_ids", "artifact_register")):
                        known = {record["id"] for record in audit.get(registry, [])}
                        if not set(requirement[key]) <= known:
                            raise ValueError(f"{rid}: unresolved {key}; labels alone are not evidence")
                    if requirement[field] == "reviewed" and not requirement.get("review_record_ids"):
                        raise ValueError(f"{rid}: review status requires review records")
                    if requirement[field] == "reviewed":
                        reviews = {record["id"]:record for record in audit.get("review_register", [])}
                        if not set(requirement["review_record_ids"]) <= reviews.keys():
                            raise ValueError(f"{rid}: unresolved review records")
                        if not all(reviews[i].get("reviewer") and reviews[i].get("decision") == "accepted" and rid in reviews[i].get("requirement_ids", []) for i in requirement["review_record_ids"]):
                            raise ValueError(f"{rid}: review records do not accept this requirement")


def course_status_rows(audit):
    """Do not calculate exam readiness from an incomplete objective register."""
    rows = []
    for course in audit["courses"]:
        requirements = course["requirements"]
        rows.append({
            "Course": course["id"],
            "Detailed teaching": "Incomplete" if any(r["teaching_state"] in {"not_authored", "overview_only"} for r in requirements) else "Authored areas require scope review",
            "Detailed assessments": "Incomplete" if any(r["assessment_state"] in {"not_authored", "introductory_mcq_only"} for r in requirements) else "Authored areas require scope review",
            "Full objective audit": "Recorded" if course["full_blueprint_leaf_audit"] else "Not complete",
            "Completeness percentage": "Not established",
        })
    return rows
