"""Course catalogue, assessment selection and objective-level study evidence.

These records describe authored material and study activity. Neither chapter
completion nor a question-bank percentage awards an external qualification.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import csv
import io
import json
from pathlib import Path
import random
import re

ROOT = Path(__file__).resolve().parents[1]
COURSE_ORDER = ("DCCA", "IC32", "CDCP", "CDFOS", "CCNP-DC", "GICSP", "GRID",
                "CISSP", "CDCS", "IC33", "IC34", "IC37", "ISA-EXPERT", "CCIE-DC",
                "NETWORK-ENGINEERING", "HARDWARE-ENGINEERING", "CONTROLS-ENGINEERING")
CREDENTIAL_IDS = COURSE_ORDER[:14]
DOMAINS = {"DCCA":"systems", "CDCP":"systems", "CDFOS":"operations", "CDCS":"systems",
           "CCNP-DC":"network", "CCIE-DC":"network", "NETWORK-ENGINEERING":"network",
           "HARDWARE-ENGINEERING":"hardware", "CONTROLS-ENGINEERING":"controls"}
_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:\-/]{0,127}$")


def load_courses(directory: Path | None = None, *, validate: bool = True) -> list[dict]:
    directory = directory or ROOT / "content" / "academy"
    courses = [json.loads(p.read_text(encoding="utf-8")) for p in sorted(directory.glob("*.json"))]
    courses.sort(key=lambda c: (COURSE_ORDER.index(c["id"]) if c["id"] in COURSE_ORDER else 99, c["id"]))
    if validate:
        validate_courses(courses)
    return courses


def validate_courses(courses: list[dict], *, release: bool = False) -> None:
    """Reject broken content and assessment links; do not infer semantic completeness."""
    seen: set[str] = set()
    course_ids = {c["id"] for c in courses}

    def require(ok, message):
        if not ok:
            raise ValueError(message)

    def identity(value):
        require(isinstance(value, str) and _ID.fullmatch(value), f"Invalid academy ID: {value}")
        require(value not in seen, f"Duplicate academy ID: {value}")
        seen.add(value)

    def nonempty(value, label):
        require(isinstance(value, str) and value.strip(), f"Missing {label}")

    def sources(values, label):
        require(isinstance(values, list) and bool(values), f"{label}: sources required")
        for s in values:
            nonempty(s.get("title"), f"{label} source title")
            require(isinstance(s.get("url"), str) and s["url"].startswith(("https://", "http://")),
                    f"{label}: invalid source URL")

    all_lessons = {l["id"] for c in courses for l in c["lessons"]}
    for course in courses:
        cid = course["id"]
        identity(cid)
        require(course.get("schema_version") == 1, f"{cid}: unsupported course schema")
        nonempty(course.get("title"), f"{cid} title")
        require(course.get("kind") in ("exam_preparation", "milestone_integration", "engineering_extension"),
                f"{cid}: unsupported course kind")
        for field in ("title", "version", "checked_on", "url", "scope_note"):
            nonempty(course["blueprint"].get(field), f"{cid} blueprint {field}")
        require(isinstance(course["blueprint"].get("limitations"), list), f"{cid}: limitations must be listed")
        for field in ("course_ids", "overview_ids", "external"):
            require(isinstance(course["prerequisites"].get(field), list), f"{cid}: prerequisite {field}")
        if release:
            require(set(course["prerequisites"]["course_ids"]) <= course_ids, f"{cid}: missing course prerequisites")
        objectives = {o["id"]: o for o in course["objectives"]}
        modules = {m["id"]: m for m in course["modules"]}
        lessons = {l["id"]: l for l in course["lessons"]}
        require(bool(objectives) and bool(modules) and bool(lessons), f"{cid}: empty course structure")
        for objective in course["objectives"]:
            identity(objective["id"])
            nonempty(objective.get("text"), f"{objective['id']} text")
            nonempty(objective.get("source_ref"), f"{objective['id']} source reference")
            require(bool(objective["lesson_ids"]) and set(objective["lesson_ids"]) <= lessons.keys(), f"{objective['id']}: lesson links")
            require(bool(objective["module_ids"]) and set(objective["module_ids"]) <= modules.keys(), f"{objective['id']}: module links")
        for module in course["modules"]:
            identity(module["id"])
            nonempty(module.get("title"), f"{module['id']} title")
            require(bool(module["lesson_ids"]) and set(module["lesson_ids"]) <= lessons.keys(), f"{module['id']}: lesson links")
            require(bool(module["objective_ids"]) and set(module["objective_ids"]) <= objectives.keys(), f"{module['id']}: objective links")
        for lesson in course["lessons"]:
            lid = lesson["id"]
            identity(lid)
            require(lesson["module_id"] in modules, f"{lid}: unknown module")
            require(lid in modules[lesson["module_id"]]["lesson_ids"], f"{lid}: asymmetric module membership")
            require(bool(lesson["objective_ids"]) and set(lesson["objective_ids"]) <= objectives.keys(), f"{lid}: unknown objectives")
            require(type(lesson["minutes"]) is int and 0 < lesson["minutes"] <= 1440, f"{lid}: study estimate")
            if release:
                require(set(lesson["prerequisites"]) <= all_lessons, f"{lid}: unknown prerequisites")
            for field in ("title", "body"):
                nonempty(lesson.get(field), f"{lid} {field}")
            require(bool(lesson.get("worked_examples")), f"{lid}: worked examples required")
            for example in lesson["worked_examples"]:
                for field in ("title", "scenario", "solution"):
                    nonempty(example.get(field), f"{lid} worked example {field}")
            for field in ("prompt", "hint", "solution"):
                nonempty(lesson["guided_practice"].get(field), f"{lid} guided {field}")
            for field in ("environment", "brief", "limitations"):
                nonempty(lesson["independent_task"].get(field), f"{lid} independent {field}")
            for field in ("deliverables", "acceptance_criteria", "starter_artifacts"):
                require(isinstance(lesson["independent_task"].get(field), list), f"{lid} independent {field}")
            require(bool(lesson["independent_task"]["deliverables"]) and bool(lesson["independent_task"]["acceptance_criteria"]),
                    f"{lid}: task deliverables/acceptance criteria required")
            sources(lesson["sources"], lid)
            for card in lesson["cards"]:
                identity(card["id"])
                for field in ("front", "back"):
                    nonempty(card.get(field), f"{card['id']} {field}")
        q_objectives, q_lessons = set(), set()
        signatures = set()
        for q in course["questions"]:
            identity(q["id"])
            require(q["module_id"] in modules and q["objective_id"] in objectives, f"{q['id']}: unknown module/objective")
            require(bool(q["lesson_ids"]) and set(q["lesson_ids"]) <= lessons.keys(), f"{q['id']}: unknown lessons")
            require(q["module_id"] in objectives[q["objective_id"]]["module_ids"], f"{q['id']}: objective belongs to another module")
            require(bool(set(q["lesson_ids"]) & set(objectives[q["objective_id"]]["lesson_ids"])), f"{q['id']}: objective has no linked teaching chapter")
            require(lessons[q["lesson_ids"][0]]["module_id"] == q["module_id"], f"{q['id']}: primary chapter belongs to another module")
            require(q["type"] in ("single", "multi", "order"), f"{q['id']}: unsupported question type")
            nonempty(q.get("prompt"), f"{q['id']} prompt")
            signature = re.sub(r"\s+", " ", q["prompt"].strip().casefold()) + "|" + re.sub(r"\s+", " ", q.get("exhibit", "").strip().casefold())
            require(signature not in signatures, f"{q['id']}: duplicate stem/exhibit")
            signatures.add(signature)
            options, correct, explanations = q["options"], q["correct"], q["explanations"]
            require(2 <= len(options) <= 32 and len(options) == len(explanations), f"{q['id']}: options/explanations mismatch")
            require(len(set(options)) == len(options), f"{q['id']}: duplicate options")
            for text in options + explanations:
                nonempty(text, f"{q['id']} option/explanation")
            require(bool(correct) and len(set(correct)) == len(correct) and all(type(x) is int and 0 <= x < len(options) for x in correct),
                    f"{q['id']}: invalid answer key")
            require(q["type"] != "single" or len(correct) == 1, f"{q['id']}: single-answer key")
            require(q["type"] != "order" or sorted(correct) == list(range(len(options))), f"{q['id']}: order requires every option")
            require(q["difficulty"] in ("foundation", "applied", "advanced"), f"{q['id']}: difficulty")
            require(q["cognitive_skill"] in ("mechanism", "implementation", "calculation", "diagnosis", "design", "operations", "recovery"), f"{q['id']}: cognitive skill")
            q_objectives.add(q["objective_id"])
            q_lessons.update(q["lesson_ids"])
        if release:
            require(q_objectives == objectives.keys(), f"{cid}: objectives without questions: {objectives.keys()-q_objectives}")
            require(q_lessons == lessons.keys(), f"{cid}: lessons without questions: {lessons.keys()-q_lessons}")
            minimum = 1000 if cid == "CCNP-DC" else 500 if cid in CREDENTIAL_IDS else 0
            require(len(course["questions"]) >= minimum, f"{cid}: requires {minimum} questions")
        for item in course.get("provider_objectives", []):
            identity(item["id"])
            nonempty(item.get("text"), f"{item['id']} source topic")
            require(bool(item.get("lesson_ids")) and set(item["lesson_ids"]) <= lessons.keys(), f"{item['id']}: provider lesson links")
            require(bool(item.get("module_ids")) and set(item["module_ids"]) <= modules.keys(), f"{item['id']}: provider module links")
            require(bool(item.get("question_ids")) and set(item["question_ids"]) <= {q["id"] for q in course["questions"]}, f"{item['id']}: provider question links")
            nonempty(item.get("source_ref"), f"{item['id']} source reference")
        if release:
            for lesson in course["lessons"]:
                for artifact in lesson["independent_task"]["starter_artifacts"]:
                    require(isinstance(artifact, str), f"{lesson['id']}: artifact path must be a string")
                    path = (ROOT / artifact).resolve()
                    require(path.is_relative_to(ROOT) and path.is_file(), f"{lesson['id']}: missing packaged artifact {artifact}")
        sources(course["sources"], cid)
    if release:
        require(set(COURSE_ORDER) <= course_ids, f"Missing programme courses: {set(COURSE_ORDER)-course_ids}")
    graph = {l["id"]: l["prerequisites"] for c in courses for l in c["lessons"]}
    graph.update({c["id"]: c["prerequisites"]["course_ids"] for c in courses})
    visited, visiting = set(), set()
    def visit(lid):
        require(lid not in visiting, f"Course lesson prerequisite cycle at {lid}")
        if lid in visited or lid not in graph:
            return
        visiting.add(lid)
        for p in graph[lid]:
            visit(p)
        visiting.remove(lid)
        visited.add(lid)
    for lid in graph:
        visit(lid)


def question_index(courses: list[dict]) -> dict[str, dict]:
    return {q["id"]: {**q, "course_id": c["id"], "lesson_id": q["lesson_ids"][0],
                       # Persist the stable objective ID, avoiding thousands of repeated long strings.
                       "objective": q["objective_id"], "domain": DOMAINS.get(c["id"], "security")}
            for c in courses for q in c["questions"]}


def learning_units(courses: list[dict]) -> list[dict]:
    """Projection for existing Anki/progress consumers; original IDs remain stable."""
    questions = question_index(courses)
    return [{**l, "domain": DOMAINS.get(c["id"], "security"), "level": "Course",
             "course_id": c["id"], "certificates": [c["id"]],
             "questions": [questions[q["id"]] for q in c["questions"] if l["id"] == q["lesson_ids"][0]]}
            for c in courses for l in c["lessons"]]


def latest_results(progress: dict) -> dict[str, dict]:
    # Stored append order reflects the learner's sequence, including imported history.
    return {r["question_id"]: r for a in progress["attempts"] for r in a["results"]}


def assessment_rows(course: dict, progress: dict) -> list[dict]:
    latest = latest_results(progress)
    rows = []
    for obj in course["objectives"]:
        questions = [q for q in course["questions"] if q["objective_id"] == obj["id"]]
        answered = [q for q in questions if q["id"] in latest]
        correct = sum(latest[q["id"]]["correct"] for q in answered)
        rows.append({"Objective ID": obj["id"], "Objective": obj["text"], "Source section": obj["source_ref"],
                     "Questions": len(questions), "Attempted": len(answered), "Latest correct": correct,
                     "Coverage %": round(100 * len(answered) / len(questions), 1) if questions else 0,
                     "Accuracy %": round(100 * correct / len(answered), 1) if answered else None})
    return rows


def chapter_status(course: dict, lesson_id: str, progress: dict) -> dict:
    questions = [q for q in course["questions"] if lesson_id in q["lesson_ids"]]
    latest = latest_results(progress)
    answered = sum(q["id"] in latest for q in questions)
    correct = sum(latest.get(q["id"], {}).get("correct", False) for q in questions)
    return {"questions": len(questions), "answered": answered, "correct": correct,
            "accuracy": 100 * correct / answered if answered else 0,
            "checkpoint_eligible": bool(questions) and answered == len(questions) and correct / len(questions) >= .8}


def select_questions(questions: list[dict], progress: dict, size: int, mode: str, seed: str) -> list[dict]:
    """Objective-balanced practice; questions are never counted twice in one set."""
    latest = latest_results(progress)
    if mode == "Unanswered":
        questions = [q for q in questions if q["id"] not in latest]
    elif mode == "Previously incorrect":
        questions = [q for q in questions if q["id"] in latest and not latest[q["id"]]["correct"]]
    elif mode == "Completed chapter checkpoints":
        questions = [q for q in questions if set(q["lesson_ids"]) <= set(progress["completed"])]
    rng = random.Random(seed)
    buckets = defaultdict(list)
    for q in questions:
        buckets[q["objective_id"]].append(q)
    for bucket in buckets.values():
        rng.shuffle(bucket)
    keys = list(buckets)
    rng.shuffle(keys)
    selected = []
    while keys and len(selected) < size:
        for key in keys[:]:
            selected.append(buckets[key].pop())
            if not buckets[key]:
                keys.remove(key)
            if len(selected) == size:
                break
    return selected


def course_rows(courses: list[dict]) -> list[dict]:
    return [{"Course": c["id"], "Title": c["title"], "Modules": len(c["modules"]),
             "Chapters": len(c["lessons"]), "Objectives": len(c["objectives"]), "Questions": len(c["questions"]),
             "Flashcards": sum(len(l["cards"]) for l in c["lessons"]),
             "Teaching words": sum(len(l["body"].split()) for l in c["lessons"]),
             "Scope version": c["blueprint"]["version"], "Kind": c["kind"],
             "Source limitations": " | ".join(c["blueprint"]["limitations"])} for c in courses]


def rows_csv(rows: list[dict]) -> str:
    output = io.StringIO()
    if rows:
        writer = csv.DictWriter(output, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return output.getvalue()


def provider_rows(course: dict) -> list[dict]:
    """Expose a source crosswalk without treating mapped support as exam readiness."""
    return [{"ID": p["id"], "Published reference": p.get("source_ref", p.get("provider_ref", "")),
             "Topic": p["text"], "Version": p.get("source_version", course["blueprint"]["version"]),
             "Chapters": ", ".join(p["lesson_ids"]),
             "Supporting question IDs": ", ".join(p.get("question_ids", [])),
             "Mapping state": p.get("coverage", "authored"),
             "Remaining requirements": "; ".join(p.get("gaps", [])),
             "Source": p.get("source_url", course["blueprint"]["url"])}
            for p in course.get("provider_objectives", [])]


def capability_course_rows(programme: dict, courses: list[dict]) -> list[dict]:
    rows = []
    for outcome in programme["outcomes"]:
        linked_courses, linked_lessons, linked_questions = set(), set(), set()
        for course in courses:
            objective_ids = {o["id"] for o in course["objectives"] if outcome["id"] in o.get("capability_ids", [])}
            if not objective_ids:
                continue
            linked_courses.add(course["id"])
            linked_lessons.update(lid for o in course["objectives"] if o["id"] in objective_ids for lid in o["lesson_ids"])
            linked_questions.update(q["id"] for q in course["questions"] if q["objective_id"] in objective_ids)
        rows.append({"Outcome": outcome["id"], "Requirement": outcome["title"],
                     "Authored courses": ", ".join(sorted(linked_courses)),
                     "Supporting chapters": len(linked_lessons), "Supporting distinct questions": len(linked_questions),
                     "Chapter IDs": ", ".join(sorted(linked_lessons)),
                     "Work package": outcome["work_package"],
                     "Practical acceptance": "Requires actual execution, evidence and appropriate independent review"})
    return rows
