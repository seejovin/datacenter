"""Requirement traceability. Mapping is neither authored teaching nor acceptance."""
from __future__ import annotations

import csv
import io
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_OUTCOMES = {f"{prefix}-{number:02d}" for prefix in ("NET", "HW", "OT", "SEC")
                     for number in range(1, 11)} | {f"CN-{number:02d}" for number in range(1, 9)}


def load_programme() -> dict:
    return json.loads((ROOT / "content/programme.json").read_text(encoding="utf-8"))


def load_cases() -> list[dict]:
    return [case for name in ("cases.json", "cases_advanced.json")
            for case in json.loads((ROOT / "content" / name).read_text(encoding="utf-8"))]


def validate_programme(programme: dict, lessons: list[dict]) -> None:
    by_id = {lesson["id"]: lesson for lesson in lessons}
    outcomes = programme["outcomes"]
    ids = [outcome["id"] for outcome in outcomes]
    if len(ids) != len(set(ids)) or set(ids) != EXPECTED_OUTCOMES:
        raise ValueError("Programme must retain all 40 engineering and eight controls-network outcomes exactly once.")
    for outcome in outcomes:
        for field in ("title", "scope", "teaching_requirements", "practical_requirement", "work_package", "source_ref"):
            if not outcome.get(field):
                raise ValueError(f"{outcome['id']}: missing {field}")
        if not outcome.get("acceptance_criteria") or not outcome.get("lesson_ids"):
            raise ValueError(f"{outcome['id']}: lessons and acceptance criteria are required")
        if not set(outcome["lesson_ids"]) <= by_id.keys():
            raise ValueError(f"{outcome['id']}: unresolved lesson links")
        if outcome["work_package"] != "WP-" + outcome["id"]:
            raise ValueError(f"{outcome['id']}: work-package identity changed")
    for course in programme["course_register"]:
        if not set(course.get("lesson_ids", [])) <= by_id.keys():
            raise ValueError(f"Course {course['id']}: unresolved lesson links")


def outcome_rows(programme: dict, lessons: list[dict], progress: dict) -> list[dict]:
    by_id = {lesson["id"]: lesson for lesson in lessons}
    completed = set(progress["completed"])
    rows = []
    for outcome in programme["outcomes"]:
        links = [lid for lid in outcome["lesson_ids"] if lid in by_id]
        notes = [entry for entry in progress["evidence"] if entry.get("lesson_id") in links]
        rows.append({
            "Outcome": outcome["id"], "Requirement": outcome["title"], "Domain": outcome["domain"],
            "Lessons": ", ".join(links),
            "Target topic stages": ", ".join(level for level in ("Foundation", "Applied", "Advanced")
                               if any(by_id[lid]["level"] == level for lid in links)),
            "Requirement mapping": "Mapped",
            "Detailed teaching": "Not established by overview links",
            "Assessment coverage": "Overview checks only; incomplete",
            "Course completion": "Not established",
            "Overview checkpoints": f"{sum(lid in completed for lid in links)} / {len(links)}",
            "Related evidence notes": len(notes),
            "Work package": outcome["work_package"],
            "Releases": ", ".join(str(r) for r in outcome["portfolio_releases"]),
            "Practical acceptance": "External review required",
        })
    return rows


def rows_csv(rows: list[dict]) -> str:
    output = io.StringIO(newline="")
    if rows:
        writer = csv.DictWriter(output, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return output.getvalue()


def evidence_packet(outcome: dict) -> str:
    """Downloadable assignment, not a fabricated demonstration or review."""
    criteria = "\n".join(f"- [ ] {item}" for item in outcome["acceptance_criteria"])
    return f"""# {outcome['work_package']} — {outcome['title']}

Status: UNPERFORMED / UNREVIEWED. Complete with real observations; do not pre-fill results.

## Requirement and instruction

Source: {outcome['source_ref']}

{outcome['scope']}

Required teaching: {outcome['teaching_requirements']}

Practical requirement: {outcome['practical_requirement']}

## Acceptance checklist

{criteria}

## Traceability

Requirement ID: {outcome['id']}
Work package: {outcome['work_package']}
Lesson IDs: {', '.join(outcome['lesson_ids'])}
Portfolio releases: {', '.join(str(x) for x in outcome['portfolio_releases'])}
Project requirement / design revision:
Test or event ID:
Evidence IDs, file paths and checksums:
Claim ID and bounded wording:

## Execution plan — approve before work

Environment and fidelity (analytical / computational simulation / network emulation / vendor simulation / physical lab / supervised field / production):
Equipment, model, software, firmware and licence versions:
Instructor demonstration and prerequisite evidence:
Role, owner, reviewer and required permissions:
Work boundary, dependencies, isolation and stop conditions:
Baseline, numerical acceptance limits, units and source of each limit:
Stimulus / safe fault / maintenance event:
Expected process, network, hardware and security behaviour:
Rollback and recovery plan with success criteria:

## Results — fill only after execution

Timestamp/timezone and measurement clock uncertainty:
Before / during / after values with units:
Raw evidence reference for each claim:
Observed behaviour, uncertainty and competing explanations:
Rejected method or failed test and why it failed:
Correction, retest and recovery observations:
Lifecycle duties actually demonstrated:
Remaining gaps and environment limits:

## Review and acceptance

Learner proposal: ACCEPT / HOLD / REJECT, with reasons:
Independent reviewer, role, date and review record link:
Reviewer disposition and unresolved conditions:
Permitted claim (no broader than the evidence):

A completed app quiz, self-reported note or generated template does not constitute
independent practical acceptance, a provider credential or authority for live work.
"""


def study_sequence(lessons: list[dict]) -> list[dict]:
    """Order existing overviews; target stage is preference, never course depth."""
    rank = {"Foundation": 0, "Applied": 1, "Advanced": 2}
    remaining = {lesson["id"]: lesson for lesson in lessons}
    emitted, result = set(), []
    while remaining:
        ready = [lesson for lesson in remaining.values() if set(lesson["prerequisites"]) <= emitted]
        if not ready:
            raise ValueError("Cannot schedule lessons: unresolved or cyclic prerequisites")
        lesson = min(ready, key=lambda item: (rank[item["level"]], list(remaining).index(item["id"])))
        result.append(lesson)
        emitted.add(lesson["id"])
        del remaining[lesson["id"]]
    return result
