"""Selection and due-date ordering for the app's built-in flashcards."""
from datetime import datetime, timezone


def review_queue(cards, reviews, now, include_scheduled=False):
    """Return distinct due cards, new cards, and optionally later cards.

    Progress records have already passed normalize_progress. Compare aware
    datetimes rather than their strings so imported timezone offsets sort correctly.
    """
    distinct = {card['id']: card for card in reversed(cards)}
    stats = dict(new=0, due=0, scheduled=0, reviewed=0, total=len(distinct))
    ranked = []
    for card in distinct.values():
        record = reviews.get(card['id'])
        if record is None:
            stats['new'] += 1
            ranked.append((1, datetime.min.replace(tzinfo=timezone.utc), card['id'], card))
            continue
        stats['reviewed'] += 1
        due = datetime.fromisoformat(record['due'].replace('Z', '+00:00'))
        if due <= now:
            stats['due'] += 1
            ranked.append((0, due, card['id'], card))
        else:
            stats['scheduled'] += 1
            if include_scheduled:
                ranked.append((2, due, card['id'], card))
    return [row[3] for row in sorted(ranked, key=lambda row: row[:3])], stats
