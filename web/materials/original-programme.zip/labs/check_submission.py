"""Read-only checks for four fictional datasets. No operational commands."""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path

EXPECTED = {
    "network": {"accepted":["R1","R2","R8"],"rejected":["R3","R4","R5","R6","R7"],"accepted_not_found":["R8"],"additional_prefix_exceeds_limit":True,"application_accepted":False},
    "hardware": {"candidate_a_configuration":"reject","candidate_b_configuration":"accept","memory_gib":1024,"mirrored_capacity_tb":12.8,"network_payload_ceiling_gbps":23,"candidate_b_service_acceptance":"hold"},
    "controls": {"engineering_kw":125,"initial_age_seconds":12,"initial_freshness_accepted":False,"minimum_post_change_age_seconds":2,"maximum_post_change_age_seconds":4,"post_change_freshness_accepted":True,"reference_comparison_accepted":True},
    "security": {"chronological_event_ids":["E2","E1","E3","E4"],"earliest_observed_misuse":"E1","containment_proposal":"B","accepted_recovery_packages":["P2"],"incident_fully_closed":False},
}

def assess(lab, submission):
    if not isinstance(submission, dict) or set(submission) != set(EXPECTED[lab]):
        raise ValueError("Use exactly the answer fields shown in submission_templates.json for this lab.")
    results = {}
    for key, expected in EXPECTED[lab].items():
        answer = submission[key]
        if isinstance(expected, bool):
            correct = type(answer) is bool and answer == expected
        elif isinstance(expected, (int, float)):
            correct = type(answer) in (int, float) and math.isclose(answer, expected, rel_tol=1e-6, abs_tol=1e-6)
        elif isinstance(expected, list):
            valid_list = isinstance(answer, list) and all(isinstance(x, str) for x in answer) and len(answer)==len(set(answer))
            correct = valid_list and (answer == expected if key=="chronological_event_ids" else set(answer)==set(expected))
        else:
            correct = isinstance(answer, str) and answer.casefold() == expected.casefold()
        results[key] = correct
    return results

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("lab", choices=EXPECTED)
    parser.add_argument("submission", type=Path)
    args = parser.parse_args()
    try:
        if args.submission.stat().st_size > 100_000:
            raise ValueError("Submission must be at most 100 KB.")
        submission = json.loads(args.submission.read_text(encoding="utf-8"))
        results = assess(args.lab, submission)
    except (OSError, ValueError, TypeError) as error:
        parser.error(str(error))
    for key, correct in results.items():
        print(f"{'MATCH' if correct else 'REVIEW'}  {key}")
    print(f"{sum(results.values())}/{len(results)} dataset conclusions matched. Reasoning and practical competence require separate review.")
    return 0 if all(results.values()) else 1

if __name__ == "__main__":
    raise SystemExit(main())
