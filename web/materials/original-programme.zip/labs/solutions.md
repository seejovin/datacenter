# Worked solutions — open after an independent attempt

## Network

Accept R1, R2 and R8. R3 is longer than /24, R4 is outside 10.24/16,
R5 has the wrong origin, R6 is Invalid, and R7 is outside the permitted scope.
R8 has NotFound validation status: local policy accepts it, but there is no
positive RPKI attestation. Three accepted routes equal the limit; an additional
distinct accepted prefix exceeds it. Plan a justified limit adjustment rather
than disabling controls. Application acceptance fails: 4% failed requests exceeds
1%, despite acceptable p95 latency and a successful ping. Static policy reasoning
does not demonstrate control-plane convergence or applied vendor configuration.

## Hardware

Reject A's proposed configuration: DDR4 is unsupported and the firmware pair is
not approved. Accept B's configuration *against the supplied matrix*, subject to
the remaining real installation and test gates. Its memory is 16 × 64 = 1,024 GiB.
Four mirrored pairs of 3.2 TB drives provide 12.8 TB before filesystem overhead;
the two copies do not double usable capacity. Its network payload ceiling is
25 × 0.92 = 23 Gb/s. A 4 GB/s storage component result equals 32 Gb/s and does not
remove that network ceiling. Hold B's service acceptance: 19 Gb/s meets throughput,
but 8 ms exceeds the 5 ms p99 limit, and failed-path data integrity is unverified.
An accepted design proposal and a held operating service are consistent decisions.

## Controls

1,250 × 0.1 = 125 kW. Initial sample age is 12 seconds, which fails the 5-second
limit; ping says nothing about freshness. The 15-second polling setting conflicts
with the intended 2 seconds. After change the nominal age is 3 seconds. With the
sample clock's ±1-second offset and an exact observation clock, actual age is
between 2 and 4 seconds; the worst case passes. Difference from the reference is
|125 − 125.4| = 0.4 kW, within 1.0 kW. This supplied snapshot passes these two
criteria; additional points, operating ranges, alarms, authority and sustained
delivery still require verification.

## Security

Corrected UTC order is E2 (10:00:30), E1 (10:01:00), E3 (10:01:50), E4
(10:02:00). Subtract the signed clock offset. E1 is the earliest *observed*
unauthorised action; E2's session is not sufficient by itself to declare misuse.
Proposal B satisfies the stated containment constraints. P2 alone satisfies all
recovery criteria. P1 lacks verified clean provenance; P3 lacks credential
replacement and functional proof. The incident remains open because root cause
and persistence are unresolved. These records do not prove who acted, the actual
initial compromise time, or that unseen systems are unaffected.
