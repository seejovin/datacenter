# Independent synthetic lab assignments

Do not open the solutions first. Keep a calculation or evidence reference for
each answer. A correct number without its assumptions is an incomplete packet.

## Network — an edge policy review

Read `data/network.json`. Evaluate each route against *every* rule; RPKI valid
status alone is insufficient. Keep route IDs in your accepted/rejected sets.
Identify the route that passes the local prefix and origin policy while its
validation state provides no positive attestation. Count accepted prefixes and
compare the count with the configured limit. Would one additional distinct
allowed prefix exceed it? Finally evaluate the application after the path-change
event. Distinguish BGP convergence, ICMP success and user-request restoration.

Submit: `accepted`, `rejected`, `accepted_not_found`,
`additional_prefix_exceeds_limit`, `application_accepted`.
Write separate reasons for rejection, an approved rollback design and the
boundary between this static review and real route-policy emulation. All routes
and AS numbers are confined to the fictional isolated laboratory.

## Hardware — approve a server configuration

Read `data/hardware.json`. Treat its compatibility matrix as the fictional
manufacturer's controlling release. Check candidate A and candidate B against
memory technology, supported firmware pairing, balanced population, capacity,
storage and network requirements. Calculate usable mirrored data capacity without
counting parity as backup. Compare throughput using decimal GB/s and Gb/s, then
apply the stated link efficiency. Reconcile the attractive component benchmark
with the end-to-end measurement. Judge the configuration and the measured
acceptance separately.

Submit: `candidate_a_configuration`, `candidate_b_configuration`,
`memory_gib`, `mirrored_capacity_tb`, `network_payload_ceiling_gbps`,
`candidate_b_service_acceptance`.
Explain your hold/reject/correct/retest decisions. Plan a real model-specific
installation, diagnostic baseline and supervised repair to close physical gaps.

## Controls — commission an EPMS point

Read `data/controls.json`. Apply the configured representation and engineering
unit scale. At the declared observation time, determine sample age independently
of gateway reachability. Compare observed and intended polling configuration.
For the post-change sample, propagate clock-offset uncertainty into the age
interval; do not claim sub-second precision from an uncertain clock. Evaluate
the supplied reference-meter comparison against the absolute acceptance limit.
Explain why a single valid point does not approve every point or control loop.

Submit: `engineering_kw`, `initial_age_seconds`, `initial_freshness_accepted`,
`minimum_post_change_age_seconds`, `maximum_post_change_age_seconds`,
`post_change_freshness_accepted`, `reference_comparison_accepted`.
Supply the point trace, original configuration, approved correction, retest and
rollback evidence plan. No real EPMS or PLC was commissioned by this exercise.

## Security — bound an incident and prove restoration

Read `data/security.json`. Convert source timestamps using the declared offsets
before ordering the events. Determine the *earliest observed* misuse; do not
infer a compromise start time or identify a person from account names alone.
Select the containment proposal that respects required OT telemetry, isolates
the affected BMC management path and revokes the compromised privileged session.
Assess candidate recovery packages against the stated trust and functional
criteria. A recent backup's date and a green ping are insufficient evidence.

Submit: `chronological_event_ids`, `earliest_observed_misuse`,
`containment_proposal`, `accepted_recovery_packages`, `incident_fully_closed`.
Create a hypothesis table with corroborating and missing evidence, acquisition
records, operator coordination and rollback criteria. Explain why approved
restoration can coexist with an open root-cause investigation.
