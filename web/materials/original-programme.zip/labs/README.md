# Synthetic evidence labs

These four self-contained data exercises supply observations to analyse before
you attempt the corresponding equipment work. They require Python 3.12 and no
accounts, network connection, vendor simulator or additional package.

1. Read the assignment in `labs/assignments.md`.
2. Inspect the relevant JSON file in `labs/data/`.
3. Copy its answer structure from `labs/submission_templates.json` to your own
   JSON file. Fill the answers and explain your reasoning in a separate note.
4. Run `python labs/check_submission.py LAB_ID your-answer.json` from the project
   root. LAB_ID is `network`, `hardware`, `controls` or `security`.
5. Compare with `labs/solutions.md` after your independent attempt, then record
   the result in Programme → Practical workbench as **analytical** evidence.

The checker reads local files only. It checks the supplied dataset's conclusions;
it does not grade your reasoning, operate equipment or accept a portfolio outcome.
All assets, logs, thresholds and events are fictional. Each threshold is an
exercise requirement, not a universal vendor limit or certification pass mark.

| Lab | Linked study | Reasoning practised |
|---|---|---|
| network | L-NET-04, L-NET-04X | Prefix/origin policy, invalid route rejection, application restoration |
| hardware | L-HW-01, L-HW-06 | Compatibility, bottlenecks and accept/hold/reject decisions |
| controls | L-CN-03, L-CN-06, L-OT-05 | Scaling, freshness, clock uncertainty and point-level acceptance |
| security | L-SEC-08, L-SEC-09 | Incident chronology, containment dependencies and trusted recovery |

These exercises are narrower than their linked work packages. Complete the
remaining vendor, physical, independent and operating-campaign assignments too.
